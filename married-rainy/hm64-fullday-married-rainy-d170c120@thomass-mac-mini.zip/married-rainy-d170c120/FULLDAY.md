# HM64 full-day lab — the cast table and the dog to the end of the game day

## 1. The day without a cast (every dog line, stay-awake push every 33 s)

- 99 lines ran of 99; dog at READY: [-197.27, 222.24]
- Clock at READY: 06:48 – 06:52. Followed to 10198 VIs = 170 s after READY (the limit).
- Same paths as the dog-watch run? cast hashes of the first 33 s: **98505 equal, 0 different**.
- Ended by something else than the limit / the end of the day: 0
- The dog's visible changes over that time: 165 per line.
- **The dog leaves its spot** (moved 4 units or more) on 87 of 99 lines; earliest 3 s after READY, median 53 s.
- Its tile leaves the visibility grid (not on screen, not animating) on 31 lines.

## 2. Cast blocks (every cast held to the limit, or the end of the day)

| block | cast frames (s after READY) | lines | casts planned | done | job errors | hash check ok / failed / none | ended: as planned / beach check / other | bites per cast | casts with a Nut on some bite |
|---|---|---|---|---|---|---|---|---|---|
| 4 | 80.2 – 120.3 · heavy | 51 | 33267 | 32548 | 0 | 31540 / 0 / 1008 | 32548 / 0 / 0 | 4.7 | 1709 (5.3%) |

Blocks not started: 5 (141384 casts). Data so far: 29.9 MB.

## 3. The beach check

- 32548 casts: **32548 ran to the limit / the end of the day on the beach at the dock end**, 0 were stopped by the beach check, 0 ended another way.
- Cast hash = the dog-watch run's state at that frame: 31540 equal, **0 different**, 1008 not compared (cast frames inside a stay-awake push).

## 4. Bites and Nuts by game hour (on the held casts)

- 153397 bites; released 4 polls after the bite: s 60062, m 47222, l 44395, N 1718 (N Nut, s / m / l fish size, d the day ended before the catch, x miss, h held through, o other; a / b = the two release probes differ).
- The two release probes of bites 1-2 gave different catches on 0 bites.
- Nut by bite number: bite 1: 266, bite 2: 434, bite 3: 453, bite 4: 258, bite 5+: 307.

| game hour | bites | Nut bites | Nut share |
|---|---|---|---|
| 13:00 | 545 | 2 | 0.37% |
| 14:00 | 8449 | 40 | 0.47% |
| 15:00 | 21422 | 291 | 1.36% |
| 16:00 | 18936 | 209 | 1.10% |
| 17:00 | 31918 | 300 | 0.94% |
| 18:00 | 9369 | 0 | 0.00% |
| 19:00 | 37462 | 874 | 2.33% |
| 20:00 | 23479 | 2 | 0.01% |
| 21:00 | 1178 | 0 | 0.00% |
| 22:00 | 518 | 0 | 0.00% |
| 23:00 | 103 | 0 | 0.00% |
| 00:00 | 18 | 0 | 0.00% |

These are bites of casts HELD since the cast frame, not fresh casts at that hour: a later hour is
reached only by holding through every earlier bite.

## 5. Do the held casts run into each other?

- 153397 bite states, 29089 distinct (81.0% shared): a shared state has the same future, so its later bites need not be simulated twice.

## 6. The dog after the cast

- Visible changes recorded from the cast to the end of its run: 60 per cast; on the released paths (the 4 s after each bite): 4.2 per bite.
- The dog leaves its spot at some point of the run in 28414 of 32548 casts (87%).

## 7. Against the dog-watch run's cast table (same state hash)

- 0 casts are in both: bite times and Nut flags **equal in 0, different in 0**.

