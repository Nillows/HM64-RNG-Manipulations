# Dog-watch report: married-lineup2-rainy-62991249

99 dog lines with traces (40 s after READY), 911 (line, READY offset) variants; route-weighted. Clock = the dock-end tap ±3 VI; logs from 1.0 s after READY; runner: changes >= 12 VI, reaction 10-25 VI, 15% missed. Odds: cast >= 2 s after the window, ±150 ms.

## What the dog does while you wait (after READY, route-weighted)

- dog's tile on the visibility grid (it animates only then): 99% of the time
- visible changes per minute: 61; changes lasting >= 12 VI: 88%
- facing on screen (share of the wait): SW 40%, NE 17%, SE 13%, W 9%, NW 9%, E 7%, N 5%; animations readable (dog faces S / N / NE / E / SE): 43%
- the dog moves (units, max over the trace): median 0.0
- decision (actionState change) -> next visible change: median 0 VI (p10 0, p90 30); animation set -> displayed: median 0 VI

## Telling the lines apart (simulated runners)

| logging | window | right line on top | posterior on it | >= 90% sure | lines left | logs | Nut (no logs -> logs) | known line |
|---|---|---|---|---|---|---|---|---|
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 3 s | 36% | 29% | 20% | 48.6 | 0.3 | 7.3% -> 16.0% | 41.2% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 5 s | 50% | 46% | 41% | 40.7 | 0.8 | 5.0% -> 21.4% | 40.1% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 10 s | 52% | 49% | 43% | 39.8 | 1.5 | 5.4% -> 20.8% | 37.5% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 15 s | 64% | 60% | 53% | 30.0 | 2.3 | 4.8% -> 22.2% | 35.7% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 20 s | 73% | 68% | 63% | 24.6 | 3.5 | 4.7% -> 21.3% | 30.5% |
| gear, arrows only (no arrow = same facing) | 3 s | 22% | 17% | 6% | 49.1 | 0.1 | 7.0% -> 11.3% | 40.8% |
| gear, arrows only (no arrow = same facing) | 5 s | 36% | 30% | 18% | 44.0 | 0.3 | 5.0% -> 15.6% | 40.0% |
| gear, arrows only (no arrow = same facing) | 10 s | 40% | 33% | 20% | 42.5 | 0.4 | 6.2% -> 17.4% | 38.1% |
| gear, arrows only (no arrow = same facing) | 15 s | 52% | 48% | 36% | 31.1 | 0.6 | 6.8% -> 20.9% | 37.7% |
| gear, arrows only (no arrow = same facing) | 20 s | 62% | 57% | 46% | 27.3 | 1.0 | 5.1% -> 20.8% | 31.5% |
| your logging (arrows always, letters for long animations facing S/N/E) | 3 s | 29% | 25% | 16% | 69.3 | 0.4 | 5.7% -> 13.4% | 39.6% |
| your logging (arrows always, letters for long animations facing S/N/E) | 5 s | 50% | 43% | 38% | 54.6 | 0.8 | 5.6% -> 20.0% | 40.6% |
| your logging (arrows always, letters for long animations facing S/N/E) | 10 s | 56% | 51% | 46% | 46.8 | 1.8 | 4.9% -> 21.4% | 37.4% |
| your logging (arrows always, letters for long animations facing S/N/E) | 15 s | 65% | 58% | 51% | 37.3 | 2.5 | 5.1% -> 23.0% | 36.9% |
| your logging (arrows always, letters for long animations facing S/N/E) | 20 s | 70% | 64% | 56% | 31.3 | 3.8 | 4.7% -> 20.7% | 30.3% |
| arrows only (facing track + durations) | 3 s | 13% | 10% | 5% | 88.6 | 0.1 | 5.8% -> 9.2% | 40.6% |
| arrows only (facing track + durations) | 5 s | 26% | 21% | 17% | 78.0 | 0.2 | 7.0% -> 13.0% | 41.5% |
| arrows only (facing track + durations) | 10 s | 30% | 23% | 15% | 73.7 | 0.3 | 6.6% -> 14.1% | 37.6% |
| arrows only (facing track + durations) | 15 s | 44% | 37% | 26% | 57.0 | 0.6 | 4.7% -> 15.5% | 35.9% |
| arrows only (facing track + durations) | 20 s | 58% | 52% | 42% | 41.9 | 1.0 | 4.6% -> 18.7% | 30.7% |
| every change, letter + arrow | 3 s | 69% | 64% | 44% | 12.4 | 1.4 | 6.3% -> 28.6% | 40.1% |
| every change, letter + arrow | 5 s | 90% | 89% | 81% | 2.8 | 3.1 | 5.4% -> 36.4% | 39.9% |
| every change, letter + arrow | 10 s | 95% | 95% | 90% | 1.6 | 6.8 | 5.6% -> 36.1% | 37.8% |
| every change, letter + arrow | 15 s | 95% | 93% | 86% | 1.3 | 10.5 | 6.4% -> 35.1% | 36.5% |
| every change, letter + arrow | 20 s | 96% | 94% | 88% | 1.5 | 14.5 | 4.6% -> 29.9% | 31.1% |
| every animation change, letter only | 3 s | 74% | 69% | 49% | 11.8 | 1.4 | 6.4% -> 32.3% | 40.8% |
| every animation change, letter only | 5 s | 91% | 89% | 76% | 1.9 | 3.1 | 5.3% -> 35.5% | 38.9% |
| every animation change, letter only | 10 s | 97% | 96% | 91% | 1.2 | 6.8 | 6.1% -> 35.6% | 37.0% |
| every animation change, letter only | 15 s | 96% | 95% | 88% | 1.3 | 10.3 | 4.7% -> 33.7% | 35.1% |
| every animation change, letter only | 20 s | 94% | 93% | 86% | 1.3 | 14.1 | 4.8% -> 29.9% | 31.1% |
| Space at every change | 3 s | 14% | 9% | 0% | 50.8 | 1.4 | 5.8% -> 8.2% | 40.0% |
| Space at every change | 5 s | 41% | 29% | 6% | 18.5 | 3.1 | 7.2% -> 19.4% | 40.1% |
| Space at every change | 10 s | 83% | 78% | 55% | 3.1 | 6.7 | 6.0% -> 32.3% | 37.7% |
| Space at every change | 15 s | 95% | 92% | 82% | 1.4 | 10.7 | 5.9% -> 33.7% | 35.7% |
| Space at every change | 20 s | 94% | 93% | 85% | 1.6 | 14.5 | 4.5% -> 30.1% | 31.3% |

Readability: *your logging* follows Thomas's TV check (facing always readable; animations only while the dog
faces S, N, NE, E or SE, and only animations lasting >= 1 s are logged). The other rows are for comparison.

## Duds before the cast (reset early)

Dud = the best cast for what your logs leave is under the threshold; you reset instead of casting. Odds per attempt; 'kept' = attempts you cast.

| logging | window | threshold | attempts called dud | Nut on kept attempts | Nut the resets threw away | all-cast Nut |
|---|---|---|---|---|---|---|
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 3 s | 5% | 0% | 16.0% | 0.00 pts | 16.0% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 3 s | 8% | 60% | 31.5% | 3.51 pts | 16.0% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 5 s | 5% | 0% | 21.4% | 0.00 pts | 21.4% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 5 s | 8% | 51% | 36.7% | 3.50 pts | 21.4% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 10 s | 5% | 0% | 20.8% | 0.00 pts | 20.8% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 10 s | 8% | 50% | 36.2% | 2.74 pts | 20.8% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 15 s | 5% | 2% | 22.6% | 0.00 pts | 22.2% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 15 s | 8% | 39% | 32.6% | 2.36 pts | 22.2% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 20 s | 5% | 2% | 21.7% | 0.00 pts | 21.3% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 20 s | 8% | 32% | 28.8% | 1.68 pts | 21.3% |
| gear, arrows only (no arrow = same facing) | 3 s | 5% | 0% | 11.3% | 0.00 pts | 11.3% |
| gear, arrows only (no arrow = same facing) | 3 s | 8% | 59% | 20.7% | 2.82 pts | 11.3% |
| gear, arrows only (no arrow = same facing) | 5 s | 5% | 0% | 15.6% | 0.00 pts | 15.6% |
| gear, arrows only (no arrow = same facing) | 5 s | 8% | 53% | 27.7% | 2.64 pts | 15.6% |
| gear, arrows only (no arrow = same facing) | 10 s | 5% | 0% | 17.4% | 0.00 pts | 17.4% |
| gear, arrows only (no arrow = same facing) | 10 s | 8% | 52% | 29.1% | 3.29 pts | 17.4% |
| gear, arrows only (no arrow = same facing) | 15 s | 5% | 1% | 21.1% | 0.00 pts | 20.9% |
| gear, arrows only (no arrow = same facing) | 15 s | 8% | 38% | 30.0% | 2.38 pts | 20.9% |
| gear, arrows only (no arrow = same facing) | 20 s | 5% | 2% | 21.2% | 0.00 pts | 20.8% |
| gear, arrows only (no arrow = same facing) | 20 s | 8% | 34% | 27.3% | 2.85 pts | 20.8% |

### Early dud signs, your logging, 10 s window, dud = best cast under 5%

3% of attempts are duds at this threshold (if the line were known). A sign = what you log in a 1-s slot after READY; seen = share of attempts showing it; dud share = how many of those are duds.

| you log | seconds after READY | seen | dud share |
|---|---|---|---|
| numpad 0 idle | 4-5 | 1.3% | 1% |
| faces N | 8-9 | 1.0% | 0% |
| numpad 0 idle | 5-6 | 1.7% | 0% |
| numpad 2 stand | 7-8 | 7.0% | 0% |
| numpad 4 walk | 5-6 | 2.0% | 0% |
| numpad 5 run | 6-7 | 2.0% | 0% |
| numpad 3 rollover | 9-10 | 3.8% | 0% |
| faces SE | 4-5 | 2.0% | 0% |
| numpad 0 idle | 1-2 | 3.9% | 0% |
| numpad 2 stand | 4-5 | 8.8% | 0% |
| numpad 9 shoulder | 4-5 | 6.8% | 0% |
| numpad 0 idle | 9-10 | 5.9% | 0% |
| numpad 7 sniff | 1-2 | 5.6% | 0% |
| numpad 3 rollover | 6-7 | 5.6% | 0% |
| numpad 0 idle | 3-4 | 5.5% | 0% |
| numpad 2 stand | 5-6 | 4.9% | 0% |
| numpad 3 rollover | 7-8 | 4.6% | 0% |
| numpad 8 bark | 1-2 | 4.5% | 0% |
| numpad 2 stand | 6-7 | 4.3% | 0% |
| numpad 2 stand | 9-10 | 4.3% | 0% |

### Early dud signs, your logging, 10 s window, dud = best cast under 8%

3% of attempts are duds at this threshold (if the line were known). A sign = what you log in a 1-s slot after READY; seen = share of attempts showing it; dud share = how many of those are duds.

| you log | seconds after READY | seen | dud share |
|---|---|---|---|
| numpad 0 idle | 4-5 | 1.3% | 1% |
| faces N | 8-9 | 1.0% | 0% |
| numpad 0 idle | 5-6 | 1.7% | 0% |
| numpad 2 stand | 7-8 | 7.0% | 0% |
| numpad 4 walk | 5-6 | 2.0% | 0% |
| numpad 5 run | 6-7 | 2.0% | 0% |
| numpad 3 rollover | 9-10 | 3.8% | 0% |
| faces SE | 4-5 | 2.0% | 0% |
| numpad 0 idle | 1-2 | 3.9% | 0% |
| numpad 2 stand | 4-5 | 8.8% | 0% |
| numpad 9 shoulder | 4-5 | 6.8% | 0% |
| numpad 0 idle | 9-10 | 5.9% | 0% |
| numpad 7 sniff | 1-2 | 5.6% | 0% |
| numpad 3 rollover | 6-7 | 5.6% | 0% |
| numpad 0 idle | 3-4 | 5.5% | 0% |
| numpad 2 stand | 5-6 | 4.9% | 0% |
| numpad 3 rollover | 7-8 | 4.6% | 0% |
| numpad 8 bark | 1-2 | 4.5% | 0% |
| numpad 2 stand | 6-7 | 4.3% | 0% |
| numpad 2 stand | 9-10 | 4.3% | 0% |
