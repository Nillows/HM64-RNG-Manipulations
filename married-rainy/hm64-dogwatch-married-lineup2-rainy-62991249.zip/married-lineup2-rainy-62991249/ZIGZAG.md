# Dog-spot lab (dogwatch): married-lineup2-rainy-62991249.SaveRAM

Zig-zag route with the zigzag-fast recipe of route delays, dog-neutral (no dog-wake rule or key: every first / second cut is walked and kept, lines are anchored at the beach load and matched by game state at READY).

## The save

- file `married-lineup2-rainy-62991249.SaveRAM` (sha256 629912496c6211d0)
- spring 9, year 1; weather 2; 6:00 at the house load; rod in hand: True
- dog at the house load: **beach** (map 9) x -197.27, z 222.24, facing 0, flags ACTIVE
- dog on screen at the load of: beach
- repeatable (two cold boots give the same record): **yes**
- reference route (mash 10/s START→A, house U276 V52, crossroads C80, beach D86 B134), map loads: house VI 1036, farm +412, crossroads +350, ranch +236, beach +230; READY 339 VIs after the beach load at x -92.0, z 194.0

## Failure map: where the recipe never reaches READY

Mass = uniform choices over this preset's grids (mash phase per rate, rates pooled; house U, V; crossroads C; first cut D; any second cut B). Each stage starts from the mass kept by the stage before.

| stage | runs | never reached | mass kept | outside the band (slower; or faster for a 5-9-frame preset) | never reached (mass) | where Jack stopped (most common) |
|---|---|---|---|---|---|---|
| menus | 144 | 0 | 0.6675 | 0.3325 | 0.0000 | - |
| house | 2548 | 462 | 0.2879 | 0.2586 | 0.1210 | 364× map 87 x≈96 z≈80; 28× map 87 x≈-24 z≈120; 28× map 87 x≈-32 z≈128 |
| crossroads | 360 | 10 | 0.2639 | 0.0160 | 0.0080 | 10× map 78 x≈120 z≈0 |
| ranch | 12 | 0 | 0.2639 | 0.0000 | 0.0000 | - |
| beach | 384 | 0 | 0.2639 | 0.0000 | 0.0000 | - |

- **mass of the recipe that reaches the dock end: 0.2639** (the D grid includes 82–83, which never clear the small wall on the dog-beach save)

| first cut D | P(some B reaches the dock end) | B in the window (VIs: count of beach states) | why the other B stop (D without a window) |
|---|---|---|---|
| 84 | 1.000 | 22: 192 | - |
| 86 | 1.000 | 22: 192 | - |

Second cut B by first cut D (share of the beach-state mass that reaches the dock end; else why Jack stopped, and where):

- D 84: 112–121 no READY (map 9 x≈-208 z≈120) · 122–143 READY · 144–151 no READY (map 9 x≈-224 z≈224)
- D 86: 112–117 no READY (map 9 x≈-208 z≈128) · 118–139 READY · 140–151 no READY (map 9 x≈-224 z≈224)

| 1st cut (web app bands) | share of the D grid | P(a 2nd cut reaches the dock end) |
|---|---|---|
| tight | 1.000 | 1.000 |

## Lines (dog-neutral: anchored at the beach load, matched by game state at READY)

- 99 lines from 192 beach states; lines per beach state (count of states): 3: 6, 4: 175, 5: 11; **0 of 192 beach states collapse to one line** (every first and second cut of that state shares one RNG trajectory, offset in time only)
- largest READY offset inside a line: 64 VIs; members not matched to any path: 0

## Cut timing, split as the web app does (cast spread 150 ms)

| preset | share of routes | release bite 1 | hold to bite 2 | either (upper bound) |
|---|---|---|---|---|
| All | 1.000 | 6.08% at 21.07 s | 4.30% at 7.57 s | 8.65% at 27.7 s |
| 1st cut tight | 1.000 | 6.08% at 21.07 s | 4.30% at 7.57 s | 8.65% at 27.7 s |
| 1st cut tight · 2nd cut early | 0.545 | 6.47% at 21.17 s | 4.63% at 7.63 s | 8.91% at 27.77 s |
| 1st cut tight · 2nd cut middle | 0.182 | 6.48% at 21.07 s | 4.60% at 7.53 s | 9.05% at 27.67 s |
| 1st cut tight · 2nd cut late | 0.273 | 6.32% at 20.93 s | 4.43% at 7.4 s | 8.95% at 27.53 s |
| 1st cut mid | 0.000 | - | - | - |
| 1st cut mid · 2nd cut early | 0.000 | - | - | - |
| 1st cut mid · 2nd cut middle | 0.000 | - | - | - |
| 1st cut mid · 2nd cut late | 0.000 | - | - | - |
| 1st cut loose | 0.000 | - | - | - |
| 1st cut loose · 2nd cut early | 0.000 | - | - | - |
| 1st cut loose · 2nd cut middle | 0.000 | - | - | - |
| 1st cut loose · 2nd cut late | 0.000 | - | - | - |

## Lineup: stability

- 99 lines; the heaviest holds 5.0% of the routes; 21 lines hold 50% and 51 hold 90% (fewer = steadier dog)
- one beach start (beach state + wait) across the full pier width: lines (count of starts) 3: 6, 4: 175, 5: 11; how the second cuts split: B 118-119 + B 120-123 + B 122-139 + B 126-143 (173 starts); B 118-143 + B 120-123 + B 122-139 (4 starts); B 118-119 + B 120-123 + B 122-139 + B 126-127 + B 128-143 (4 starts); B 118-119 + B 120-123 + B 122-123 + B 124-139 + B 126-143 (4 starts)
- one wait + second cut across the beach states (the route before the beach): lines (count) 7: 22, 8: 138, 14: 80, 15: 172, 16: 4

## Lineup: does the dog keep drawing after READY (standing at the pier, no cast)?

- routes whose line has the dog drawing after READY: **100.0%**; extra draws over 39 s (above the 1-per-game-frame clock), route-weighted mean 20654; dog's tile visible 99% of the time

## Lineup: where the dog activates (its tile enters the camera's view; until then it draws nothing)

First VI after the beach load (share of routes): 205: 0.3%, 207: 0.9%, 209: 3.7%, 211: 6.3%, 213: 6.3%, 215: 6.2%, 217: 6.3%, 219: 6.2%, 221: 6.3%, 223: 6.3%, 225: 6.3%, 227: 6.2%, 229: 6.2%, 231: 6.3%, 233: 6.3%, 235: 6.3%, 237: 6.0%, 239: 5.4%, 241: 2.6%

| Jack at the activation (x, z; 8-unit cells) | share of routes | lines | release bite 1 | hold to bite 2 |
|---|---|---|---|---|
| x -456…-448, z 160…168 | 0.727 | 91 | 6.12% at 21.03 s (cover 0.97) | 4.26% at 7.53 s (cover 0.95) |
| x -448…-440, z 152…160 | 0.182 | 96 | 6.48% at 21.2 s (cover 0.96) | 4.73% at 7.67 s (cover 0.95) |
| x -448…-440, z 144…152 | 0.091 | 88 | 6.68% at 21.13 s (cover 0.96) | 4.72% at 7.6 s (cover 0.92) |

## Lineup: beach wait W (VIs Jack stands still at the beach load before his first step)

| W (VIs) | share of routes | lines | release bite 1 | hold to bite 2 |
|---|---|---|---|---|
| 0 | 0.062 | 26 | 9.31% at 20.2 s (cover 0.88) | 6.90% at 7.57 s (cover 0.83) |
| 2 | 0.062 | 25 | 9.12% at 21.23 s (cover 0.97) | 9.02% at 7.57 s (cover 0.95) |
| 4 | 0.062 | 26 | 11.24% at 11.7 s (cover 0.99) | 7.80% at 17.3 s (cover 0.99) |
| 6 | 0.062 | 26 | 7.66% at 20.07 s (cover 1.00) | 5.01% at 3.67 s (cover 1.00) |
| 8 | 0.062 | 25 | 8.51% at 24.63 s (cover 1.00) | 7.46% at 9.8 s (cover 1.00) |
| 10 | 0.062 | 27 | 9.71% at 24.53 s (cover 1.00) | 16.77% at 9.8 s (cover 1.00) |
| 12 | 0.062 | 25 | 9.84% at 9.43 s (cover 1.00) | 11.06% at 9.83 s (cover 1.00) |
| 14 | 0.062 | 25 | 11.15% at 8.17 s (cover 1.00) | 5.88% at 27.0 s (cover 1.00) |
| 16 | 0.062 | 27 | 8.30% at 8.2 s (cover 1.00) | 5.72% at 27.87 s (cover 1.00) |
| 18 | 0.062 | 27 | 6.54% at 10.07 s (cover 1.00) | 8.08% at 7.23 s (cover 1.00) |
| 20 | 0.062 | 26 | 8.83% at 31.03 s (cover 0.94) | 8.17% at 20.23 s (cover 0.94) |
| 22 | 0.062 | 27 | 12.89% at 4.03 s (cover 0.93) | 8.78% at 20.6 s (cover 0.93) |
| 24 | 0.062 | 27 | 9.68% at 20.93 s (cover 0.99) | 6.75% at 20.07 s (cover 0.99) |
| 26 | 0.062 | 27 | 11.27% at 21.83 s (cover 0.93) | 10.07% at 20.03 s (cover 0.93) |
| 28 | 0.062 | 27 | 9.36% at 24.37 s (cover 0.93) | 6.48% at 23.1 s (cover 0.93) |
| 30 | 0.062 | 28 | 9.75% at 21.93 s (cover 0.90) | 9.88% at 23.2 s (cover 0.92) |

## Lineup: first cut D (VIs of down-right after the beach load, before the cut down-left)

D 84 = the earliest cut that clears the small wall (scrapes its corner: Jack pushed to x -451.6); D 86 = one game frame later (clears the corner: x -452.0, still the wall column of the dog's view grid).

| first cut | share of routes | lines | of them shared with the other cut | dog wakes, VI after the beach load - W (share) | release bite 1 | hold to bite 2 |
|---|---|---|---|---|---|---|
| D 84 | 0.500 | 95 | 90 | 211 (82%), 207 (9%), 209 (9%) | 5.98% at 21.07 s (cover 0.97) | 4.33% at 7.57 s (cover 0.94) |
| D 86 | 0.500 | 94 | 90 | 209 (82%), 207 (9%), 205 (9%) | 6.20% at 21.1 s (cover 0.96) | 4.28% at 7.57 s (cover 0.96) |

## Lineup: wait band x second cut (full pier width; early / middle / late = dock-end spot z ≤178 / ≤190 / >190)

| wait | 2nd cut | share of routes | lines | release bite 1 | hold to bite 2 |
|---|---|---|---|---|---|
| wait 0-9 | any | 0.313 | 47 | 7.04% at 11.7 s (cover 0.95) | 5.63% at 7.53 s (cover 0.95) |
| wait 0-9 | Early | 0.170 | 47 | 7.70% at 11.77 s (cover 0.93) | 6.20% at 7.6 s (cover 0.93) |
| wait 0-9 | Middle | 0.057 | 37 | 7.68% at 20.1 s (cover 0.98) | 6.25% at 7.5 s (cover 0.98) |
| wait 0-9 | Late | 0.085 | 37 | 7.30% at 19.97 s (cover 0.98) | 5.93% at 7.4 s (cover 0.98) |
| wait 10-19 | any | 0.313 | 48 | 7.14% at 8.17 s (cover 1.00) | 6.47% at 9.83 s (cover 1.00) |
| wait 10-19 | Early | 0.170 | 47 | 7.68% at 8.23 s (cover 1.00) | 7.22% at 9.87 s (cover 1.00) |
| wait 10-19 | Middle | 0.057 | 37 | 7.74% at 8.17 s (cover 1.00) | 6.64% at 9.8 s (cover 1.00) |
| wait 10-19 | Late | 0.085 | 36 | 7.43% at 8.03 s (cover 1.00) | 6.35% at 9.67 s (cover 1.00) |
| wait 20-30 | any | 0.375 | 55 | 8.30% at 21.9 s (cover 0.94) | 6.15% at 20.13 s (cover 0.94) |
| wait 20-30 | Early | 0.205 | 55 | 8.74% at 22.0 s (cover 0.94) | 6.53% at 20.17 s (cover 0.94) |
| wait 20-30 | Middle | 0.068 | 43 | 9.19% at 21.9 s (cover 0.94) | 6.54% at 20.07 s (cover 0.94) |
| wait 20-30 | Late | 0.102 | 43 | 8.85% at 21.77 s (cover 0.94) | 6.23% at 19.97 s (cover 0.94) |
| any wait | any | 1.000 | 99 | 6.08% at 21.07 s (cover 0.97) | 4.30% at 7.57 s (cover 0.95) |
| any wait | Early | 0.545 | 99 | 6.47% at 21.17 s (cover 0.96) | 4.63% at 7.63 s (cover 0.95) |
| any wait | Middle | 0.182 | 91 | 6.48% at 21.07 s (cover 0.97) | 4.60% at 7.53 s (cover 0.95) |
| any wait | Late | 0.273 | 91 | 6.32% at 20.93 s (cover 0.97) | 4.43% at 7.4 s (cover 0.95) |

## Menus (mash until the house loads)

| style | presses/s | held VIs | house arrival VI (count of phases) |
|---|---|---|---|
| START+A | 15.0 | 2 | 1038×2, 1040×2 |
| START+A | 12.0 | 2 | 1042×2, 1044×2, 1046×1 |
| START+A | 10.0 | 3 | 1042×2, 1044×2, 1046×2 |
| START+A | 8.6 | 3 | 1042×1, 1044×1, 1046×1, 1048×1, 1050×1, 1052×1, 1054×1 |
| START+A | 7.5 | 4 | 1038×2, 1040×2, 1042×2, 1044×2 |
| START+A | 6.7 | 4 | 1038×1, 1040×2, 1042×2, 1044×2, 1046×1, 1056×1 |
| START+A | 6.0 | 5 | 1052×2, 1054×2, 1056×2, 1058×2, 1060×2 |
| START+A | 5.5 | 5 | 1050×2, 1052×2, 1054×2, 1056×2, 1058×2, 1060×1 |
| START+A | 5.0 | 6 | 1054×2, 1056×2, 1058×2, 1060×2, 1064×2, 1074×2 |
| START>A | 15.0 | 2 | 1038×2, 1040×2 |
| START>A | 12.0 | 2 | 1042×2, 1044×2, 1046×1 |
| START>A | 10.0 | 3 | 1036×1, 1038×1, 1040×1, 1042×1, 1044×1, 1046×1 |
| START>A | 8.6 | 3 | 1042×1, 1044×2, 1046×2, 1048×2 |
| START>A | 7.5 | 4 | 1038×2, 1040×2, 1042×2, 1044×2 |
| START>A | 6.7 | 4 | 1038×1, 1040×2, 1042×2, 1044×2, 1046×1, 1056×1 |
| START>A | 6.0 | 5 | 1052×2, 1054×2, 1056×2, 1058×2, 1060×2 |
| START>A | 5.5 | 5 | 1050×2, 1052×2, 1054×2, 1056×2, 1058×2, 1060×1 |
| START>A | 5.0 | 6 | 1042×2, 1044×2, 1046×2, 1048×2, 1052×2, 1062×2 |

## House (up-left U, down-left V, down) — farm arrival, VIs after the house load: count of (U, V) runs

412:28, 414:112, 416:336, 418:357, 420:266, 422:189, 424:196, 426:147, 428:70, 430:84, 432:84, 434:63, 436:56, 438:56, 440:35, 442:7, None:462

## Crossroads (left, cut down-left at C) — ranch arrival, VIs after the farm load: count of runs

586:100, 588:80, 590:100, 592:50, 594:20, None:10

## Beach (first cut D, second cut B; VIs after the beach load)

| D | dog first moved, VIs after the beach load (count) | B reaching the dock end (total) | READY windows (B) |
|---|---|---|---|
| 84 | None×192 | 4224 | 122–143 |
| 86 | None×192 | 4224 | 118–139 |

## Dog lines: 99 (members = beach state × D × B that reach the dock end)

- casts evaluated: 44934 distinct states; repeat checks agree 231, disagree 0

| line | weight | members | beach draw | READY spread (VIs) | casts | Nut casts b1 / b2 |
|---|---|---|---|---|---|---|
| c676f2cca2a60139 | 0.050 | 342 | 7825 | 44 | 1197 | 23 / 22 |
| a2f340545ff0005a | 0.039 | 314 | 7825 | 28 | 1197 | 35 / 12 |
| 2eda5984c7d9b8b0 | 0.039 | 262 | 7792 | 30 | 1197 | 18 / 18 |
| c3f39ea592373b8b | 0.038 | 254 | 7792 | 44 | 1197 | 24 / 25 |
| 7850edf15dec5992 | 0.027 | 220 | 7777 | 30 | 1197 | 24 / 8 |
| 8f9539f76191fc70 | 0.023 | 182 | 7792 | 38 | 1197 | 28 / 7 |
| 972c266f92f2c488 | 0.022 | 220 | 7772 | 44 | 1197 | 25 / 13 |
| 891e8e8bdea912fc | 0.022 | 178 | 7772 | 38 | 1197 | 33 / 16 |
| e125893dba704976 | 0.022 | 176 | 7825 | 22 | 1197 | 22 / 18 |
| e28e570535248f2b | 0.022 | 176 | 7825 | 22 | 1197 | 26 / 20 |
| f0d83cefbbcbd46c | 0.022 | 176 | 7825 | 22 | 1197 | 24 / 18 |
| d8354fca83d36cb1 | 0.022 | 176 | 7808 | 22 | 1197 | 11 / 26 |
| acb9acafe2e66462 | 0.021 | 126 | 7792 | 44 | 1197 | 26 / 23 |
| b967db8fa52cebf2 | 0.020 | 202 | 7772 | 44 | 1197 | 18 / 13 |
| 8844276137d9998a | 0.020 | 158 | 7825 | 22 | 1197 | 18 / 11 |
| f938ffee507b61aa | 0.019 | 138 | 7825 | 22 | 1197 | 21 / 23 |
| 08443b972d7d3e5a | 0.019 | 156 | 7772 | 64 | 1197 | 24 / 33 |
| 9e2f8fe3c761e47c | 0.019 | 106 | 7792 | 22 | 1197 | 22 / 25 |
| d6de9cf2bd33aff2 | 0.017 | 132 | 7792 | 38 | 1197 | 29 / 9 |
| 74d0fcbeed7a9672 | 0.017 | 114 | 7772 | 44 | 1197 | 26 / 12 |
| 62b5cc35ed80cfcc | 0.017 | 88 | 7792 | 22 | 1197 | 44 / 13 |
| aeb846f70510cc71 | 0.017 | 88 | 7792 | 22 | 1197 | 25 / 20 |
| eceaa12e69f318df | 0.017 | 88 | 7792 | 22 | 1197 | 48 / 13 |
| f4d6079342dc61a9 | 0.017 | 88 | 7792 | 22 | 1197 | 26 / 18 |
| ee2a6e0cf1099af7 | 0.016 | 84 | 7792 | 22 | 1197 | 29 / 8 |
| e9413c1268e4bcdc | 0.015 | 96 | 7858 | 22 | 1197 | 19 / 14 |
| 80cbc93c16086eb8 | 0.015 | 76 | 7792 | 22 | 1197 | 26 / 18 |
| f476e7f81e168336 | 0.014 | 90 | 7858 | 30 | 1197 | 11 / 26 |
| 06786333a60fd62a | 0.014 | 88 | 7858 | 22 | 1197 | 33 / 20 |
| 55b7f554a887701e | 0.014 | 88 | 7858 | 22 | 1197 | 35 / 16 |
| 5bfb813019292fdb | 0.014 | 88 | 7858 | 22 | 1197 | 27 / 18 |
| 70729cfbd025f250 | 0.014 | 88 | 7858 | 22 | 1197 | 28 / 18 |
| b4efbb03e97f6dd3 | 0.014 | 88 | 7858 | 22 | 1197 | 32 / 17 |
| cac2d1423b1da381 | 0.014 | 88 | 7858 | 22 | 1197 | 28 / 17 |
| e6623befef030c9e | 0.014 | 88 | 7858 | 22 | 1197 | 29 / 4 |
| e9bc9d7a5f855f6b | 0.014 | 88 | 7858 | 22 | 1197 | 26 / 16 |
| ef6119e68f925c23 | 0.014 | 88 | 7858 | 22 | 1197 | 24 / 11 |
| f6f5af8663f27583 | 0.014 | 88 | 7858 | 22 | 1197 | 17 / 14 |
| ffaa1d0f7c5b60d2 | 0.014 | 88 | 7858 | 22 | 1197 | 35 / 25 |
| 381f5bd14f2bf310 | 0.013 | 84 | 7858 | 22 | 1197 | 17 / 17 |

## Lucky Timer, whole pool (aim = time after READY at the dock end; cast spread 1 s.d.)

| spread | release bite 1 | hold to bite 2 | either (smart, upper bound) | coverage at best |
|---|---|---|---|---|
| 0 ms | 7.0% at 21.13 s | 5.9% at 7.57 s | 9.8% at 27.63 s | 0.967 |
| 100 ms | 6.4% at 21.1 s | 4.7% at 7.6 s | 9.0% at 27.63 s | 0.967 |
| 150 ms | 6.1% at 21.07 s | 4.3% at 7.57 s | 8.6% at 27.7 s | 0.967 |
| 250 ms | 5.6% at 21.07 s | 4.0% at 7.47 s | 8.1% at 27.7 s | 0.967 |

- **Member recast check** (casts from members' own routes vs the shared line table): agree 701, disagree 20, no table entry 0

  - ['d8354fca83d36cb1', '7d70bcc09bf40163@w8', 84, 138, 598, [1700, False, 2306, False], [1742, False, 3914, False]]
  - ['b967db8fa52cebf2', '3d3cbfeb84d85897@w26', 86, 118, 406, [754, False, 896, False], [620, False, 1356, False]]
  - ['b967db8fa52cebf2', '3d3cbfeb84d85897@w26', 86, 118, 448, [1364, False, 1576, True], [1042, False, 2236, False]]
  - ['b967db8fa52cebf2', '3d3cbfeb84d85897@w26', 86, 118, 698, [1388, False, 2746, False], [992, False, 1066, False]]
  - ['f938ffee507b61aa', '7d70bcc09bf40163@w26', 86, 135, 646, [1620, False, 1700, False], [962, False, 1620, False]]
  - ['f938ffee507b61aa', '7d70bcc09bf40163@w26', 86, 135, 832, [1636, False, 1716, False], [1052, False, 1772, False]]
  - ['f938ffee507b61aa', '3d3cbfeb84d85897@w28', 84, 133, 714, [1362, False, 2306, False], [1362, False, 2612, False]]
  - ['70729cfbd025f250', 'f163e981fb7b9570@w10', 84, 139, 1032, [1100, False, 1410, False], [1100, False, 1672, False]]
  - ['eafe51a5093f4bd7', '42972af4762a7f76@w18', 86, 138, 1146, [1422, False, 2362, False], [1422, False, 2372, False]]
  - ['2eda5984c7d9b8b0', '3d3cbfeb84d85897@w24', 84, 128, 1388, [1696, False, 2382, False], [2378, False, 3190, False]]
  - ['2eda5984c7d9b8b0', '3d3cbfeb84d85897@w24', 84, 128, 1580, [2394, False, 3206, False], [2700, False, 3206, False]]
  - ['a2f340545ff0005a', '3d3cbfeb84d85897@w8', 86, 134, 2166, [2624, False, 2772, False], [2470, False, 3282, False]]
  - ['a2f340545ff0005a', '3d3cbfeb84d85897@w8', 86, 134, 2306, [2492, False, 2788, False], [2788, False, 3294, False]]
  - ['d8354fca83d36cb1', '3d3cbfeb84d85897@w12', 84, 138, 1838, [4062, False, 4308, False], [5908, False, 8654, False]]
  - ['b967db8fa52cebf2', '7d70bcc09bf40163@w16', 84, 129, 1882, [2026, False, 3826, False], [3026, False, 3236, False]]
  - ['b967db8fa52cebf2', '7d70bcc09bf40163@w16', 84, 129, 1968, [2662, False, 3252, False], [2858, False, 4056, False]]
  - ['b967db8fa52cebf2', '7d70bcc09bf40163@w16', 84, 129, 2188, [2626, False, 4030, False], [2474, False, 2766, False]]
  - ['b967db8fa52cebf2', '7d70bcc09bf40163@w16', 84, 138, 1484, [1722, False, 2706, False], [1718, False, 1778, False]]
  - ['b967db8fa52cebf2', '7d70bcc09bf40163@w16', 84, 138, 1812, [3754, False, 4168, False], [2360, False, 4076, False]]
  - ['b967db8fa52cebf2', '7d70bcc09bf40163@w16', 84, 138, 1966, [4060, False, 4376, False], [2602, False, 3388, False]]
