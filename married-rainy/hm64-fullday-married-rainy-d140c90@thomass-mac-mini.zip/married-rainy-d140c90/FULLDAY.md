# HM64 full-day lab — the cast table and the dog to the end of the game day

## 1. The day without a cast (every dog line, stay-awake push every 33 s)

- 99 lines ran of 99; dog at READY: [-197.27, 222.24]
- Clock at READY: 06:48 – 06:52. Followed to 8398 VIs = 140 s after READY (the limit).
- Same paths as the dog-watch run? cast hashes of the first 33 s: **98505 equal, 0 different**.
- Ended by something else than the limit / the end of the day: 0
- The dog's visible changes over that time: 140 per line.
- **The dog leaves its spot** (moved 4 units or more) on 87 of 99 lines; earliest 3 s after READY, median 53 s.
- Its tile leaves the visibility grid (not on screen, not animating) on 20 lines.

## 2. Cast blocks (every cast held to the limit, or the end of the day)

| block | cast frames (s after READY) | lines | casts planned | done | job errors | hash check ok / failed / none | ended: as planned / beach check / other | bites per cast | casts with a Nut on some bite |
|---|---|---|---|---|---|---|---|---|---|
| 2 | 40.1 – 80.2 · heavy | 51 | 36004 | 36004 | 0 | 34933 / 0 / 1071 | 36004 / 0 / 0 | 6.0 | 1314 (3.6%) |
| 3 | 40.1 – 80.2 · other | 48 | 18305 | 18305 | 0 | 17297 / 0 / 1008 | 18305 / 0 / 0 | 5.8 | 599 (3.3%) |
| 4 | 80.2 – 90.3 · heavy | 41 | 8368 | 8368 | 0 | 8368 / 0 / 0 | 8368 / 0 / 0 | 3.7 | 312 (3.7%) |
| 5 | 80.2 – 90.3 · other | 25 | 4249 | 4249 | 0 | 4249 / 0 / 0 | 4249 / 0 / 0 | 3.6 | 192 (4.5%) |

Blocks not started: 2 (69370 casts). Data so far: 70.3 MB.

## 3. The beach check

- 66926 casts: **66926 ran to the limit / the end of the day on the beach at the dock end**, 0 were stopped by the beach check, 0 ended another way.
- Cast hash = the dog-watch run's state at that frame: 64847 equal, **0 different**, 2079 not compared (cast frames inside a stay-awake push).

## 4. Bites and Nuts by game hour (on the held casts)

- 369501 bites; released 4 polls after the bite: m 130663, s 124880, l 111533, N 2425 (N Nut, s / m / l fish size, d the day ended before the catch, x miss, h held through, o other; a / b = the two release probes differ).
- The two release probes of bites 1-2 gave different catches on 0 bites.
- Nut by bite number: bite 1: 753, bite 2: 445, bite 3: 347, bite 4: 321, bite 5+: 559.

| game hour | bites | Nut bites | Nut share |
|---|---|---|---|
| 10:00 | 4317 | 75 | 1.74% |
| 11:00 | 17573 | 821 | 4.67% |
| 12:00 | 48790 | 1 | 0.00% |
| 13:00 | 67241 | 2 | 0.00% |
| 14:00 | 65541 | 285 | 0.43% |
| 15:00 | 51619 | 935 | 1.81% |
| 16:00 | 52432 | 280 | 0.53% |
| 17:00 | 41983 | 11 | 0.03% |
| 18:00 | 17177 | 0 | 0.00% |
| 19:00 | 2718 | 15 | 0.55% |
| 20:00 | 65 | 0 | 0.00% |
| 21:00 | 18 | 0 | 0.00% |
| 22:00 | 27 | 0 | 0.00% |

These are bites of casts HELD since the cast frame, not fresh casts at that hour: a later hour is
reached only by holding through every earlier bite.

## 5. Do the held casts run into each other?

- 369501 bite states, 51435 distinct (86.1% shared): a shared state has the same future, so its later bites need not be simulated twice.

## 6. The dog after the cast

- Visible changes recorded from the cast to the end of its run: 66 per cast; on the released paths (the 4 s after each bite): 4.8 per bite.
- The dog leaves its spot at some point of the run in 56025 of 66926 casts (84%).

## 7. Against the dog-watch run's cast table (same state hash)

- 0 casts are in both: bite times and Nut flags **equal in 0, different in 0**.

