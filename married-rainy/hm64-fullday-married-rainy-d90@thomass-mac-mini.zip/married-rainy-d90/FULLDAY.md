# HM64 full-day lab — the cast table and the dog to the end of the game day

## 1. The day without a cast (every dog line, stay-awake push every 33 s)

- 99 lines ran of 99; dog at READY: [-197.27, 222.24]
- Clock at READY: 06:48 – 06:52. Followed to 5398 VIs = 90 s after READY (the limit).
- Same paths as the dog-watch run? cast hashes of the first 33 s: **98505 equal, 0 different**.
- Ended by something else than the limit / the end of the day: 0
- The dog's visible changes over that time: 89 per line.
- **The dog leaves its spot** (moved 4 units or more) on 56 of 99 lines; earliest 3 s after READY, median 37 s.
- Its tile leaves the visibility grid (not on screen, not animating) on 9 lines.

## 2. Cast blocks (every cast held to the limit, or the end of the day)

| block | cast frames (s after READY) | lines | casts planned | done | job errors | hash check ok / failed / none | ended: as planned / beach check / other | bites per cast | casts with a Nut on some bite |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 0.1 – 40.1 · heavy | 51 | 45356 | 45356 | 0 | 44285 / 0 / 1071 | 45356 / 0 / 0 | 6.6 | 2227 (4.9%) |
| 1 | 0.1 – 40.1 · other | 48 | 24014 | 24014 | 0 | 23006 / 0 / 1008 | 24014 / 0 / 0 | 6.7 | 989 (4.1%) |

Blocks not started: 0 (0 casts). Data so far: 75.8 MB.

## 3. The beach check

- 69370 casts: **69370 ran to the limit / the end of the day on the beach at the dock end**, 0 were stopped by the beach check, 0 ended another way.
- Cast hash = the dog-watch run's state at that frame: 67291 equal, **0 different**, 2079 not compared (cast frames inside a stay-awake push).

## 4. Bites and Nuts by game hour (on the held casts)

- 461964 bites; released 4 polls after the bite: m 159647, l 154540, s 144489, N 3288 (N Nut, s / m / l fish size, d the day ended before the catch, x miss, h held through, o other; a / b = the two release probes differ).
- The two release probes of bites 1-2 gave different catches on 0 bites.
- Nut by bite number: bite 1: 1433, bite 2: 857, bite 3: 379, bite 4: 319, bite 5+: 300.

| game hour | bites | Nut bites | Nut share |
|---|---|---|---|
| 07:00 | 12340 | 242 | 1.96% |
| 08:00 | 39795 | 771 | 1.94% |
| 09:00 | 57836 | 1329 | 2.30% |
| 10:00 | 54029 | 28 | 0.05% |
| 11:00 | 66400 | 918 | 1.38% |
| 12:00 | 124689 | 0 | 0.00% |
| 13:00 | 102486 | 0 | 0.00% |
| 14:00 | 4036 | 0 | 0.00% |
| 15:00 | 111 | 0 | 0.00% |
| 16:00 | 214 | 0 | 0.00% |
| 18:00 | 28 | 0 | 0.00% |

These are bites of casts HELD since the cast frame, not fresh casts at that hour: a later hour is
reached only by holding through every earlier bite.

## 5. Do the held casts run into each other?

- 461964 bite states, 32973 distinct (92.9% shared): a shared state has the same future, so its later bites need not be simulated twice.

## 6. The dog after the cast

- Visible changes recorded from the cast to the end of its run: 68 per cast; on the released paths (the 4 s after each bite): 4.9 per bite.
- The dog leaves its spot at some point of the run in 43843 of 69370 casts (63%).

## 7. Against the dog-watch run's cast table (same state hash)

- 44377 casts are in both: bite times and Nut flags **equal in 44377, different in 0**.

