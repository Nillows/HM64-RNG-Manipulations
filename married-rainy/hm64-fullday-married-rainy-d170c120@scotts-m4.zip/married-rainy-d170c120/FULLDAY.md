# HM64 full-day lab — the cast table and the dog to the end of the game day

## 1. The day without a cast (every dog line, stay-awake push every 33 s)

- 99 lines ran of 99; dog at READY: [-197.27, 222.24]
- Clock at READY: 06:48 – 06:52. Followed to 10198 VIs = 170 s after READY (the limit).
- Same paths as the dog-watch run? cast hashes of the first 33 s: **98505 equal, 0 different**.
- Ended by something else than the limit / the end of the day: 0
- The dog's visible changes over that time: 165 per line.
- **The dog leaves its spot** (moved 4 units or more) on 87 of 99 lines; earliest 3 s after READY, median 53 s.
- Its tile leaves the visibility grid (not on screen, not animating) on 31 lines.

## 2. Cast blocks (every cast held to the limit, or the end of the day)

| block | cast frames (s after READY) | lines | casts planned | done | job errors | hash check ok / failed / none | ended: as planned / beach check / other | bites per cast | casts with a Nut on some bite |
|---|---|---|---|---|---|---|---|---|---|
| 4 | 80.2 – 120.3 · heavy | 51 | 33267 | 719 | 0 | 656 / 0 / 63 | 719 / 0 / 0 | 4.0 | 1 (0.1%) |
| 5 | 80.2 – 120.3 · other | 48 | 17705 | 17705 | 0 | 16697 / 0 / 1008 | 17705 / 0 / 0 | 4.6 | 815 (4.6%) |

Blocks not started: 4 (123679 casts). Data so far: 15.5 MB.

## 3. The beach check

- 18424 casts: **18424 ran to the limit / the end of the day on the beach at the dock end**, 0 were stopped by the beach check, 0 ended another way.
- Cast hash = the dog-watch run's state at that frame: 17353 equal, **0 different**, 1071 not compared (cast frames inside a stay-awake push).

## 4. Bites and Nuts by game hour (on the held casts)

- 84411 bites; released 4 polls after the bite: s 35463, m 25597, l 22526, N 825 (N Nut, s / m / l fish size, d the day ended before the catch, x miss, h held through, o other; a / b = the two release probes differ).
- The two release probes of bites 1-2 gave different catches on 0 bites.
- Nut by bite number: bite 1: 146, bite 2: 213, bite 3: 206, bite 4: 135, bite 5+: 125.

| game hour | bites | Nut bites | Nut share |
|---|---|---|---|
| 13:00 | 281 | 0 | 0.00% |
| 14:00 | 4197 | 20 | 0.48% |
| 15:00 | 11775 | 139 | 1.18% |
| 16:00 | 10321 | 129 | 1.25% |
| 17:00 | 16075 | 157 | 0.98% |
| 18:00 | 4898 | 0 | 0.00% |
| 19:00 | 22210 | 380 | 1.71% |
| 20:00 | 13709 | 0 | 0.00% |
| 21:00 | 616 | 0 | 0.00% |
| 22:00 | 270 | 0 | 0.00% |
| 23:00 | 59 | 0 | 0.00% |

These are bites of casts HELD since the cast frame, not fresh casts at that hour: a later hour is
reached only by holding through every earlier bite.

## 5. Do the held casts run into each other?

- 84411 bite states, 15349 distinct (81.8% shared): a shared state has the same future, so its later bites need not be simulated twice.

## 6. The dog after the cast

- Visible changes recorded from the cast to the end of its run: 53 per cast; on the released paths (the 4 s after each bite): 3.9 per bite.
- The dog leaves its spot at some point of the run in 16456 of 18424 casts (89%).

## 7. Against the dog-watch run's cast table (same state hash)

- 0 casts are in both: bite times and Nut flags **equal in 0, different in 0**.

