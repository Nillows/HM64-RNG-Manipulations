# Dog-spot lab (dogwatch): beach-lineup2-52cfd712.SaveRAM

Zig-zag route with the zigzag-fast recipe of route delays, dog-neutral (no dog-wake rule or key: every first / second cut is walked and kept, lines are anchored at the beach load and matched by game state at READY).

## The save

- file `beach-lineup2-52cfd712.SaveRAM` (sha256 52cfd712095494d3)
- spring 4, year 1; weather 1; 6:00 at the house load; rod in hand: True
- dog at the house load: **beach** (map 9) x -198.51, z 223.49, facing 0, flags ACTIVE
- dog on screen at the load of: beach
- repeatable (two cold boots give the same record): **yes**
- reference route (mash 10/s START→A, house U276 V52, crossroads C80, beach D86 B134), map loads: house VI 1036, farm +412, crossroads +350, ranch +236, beach +230; READY 339 VIs after the beach load at x -92.0, z 194.0

## Failure map: where the recipe never reaches READY

Mass = uniform choices over this preset's grids (mash phase per rate, rates pooled; house U, V; crossroads C; first cut D; any second cut B). Each stage starts from the mass kept by the stage before.

| stage | runs | never reached | mass kept | outside the band (slower; or faster for a 5-9-frame preset) | never reached (mass) | where Jack stopped (most common) |
|---|---|---|---|---|---|---|
| menus | 144 | 0 | 0.6675 | 0.3325 | 0.0000 | - |
| house | 2548 | 462 | 0.2733 | 0.2733 | 0.1210 | 364× map 87 x≈96 z≈80; 28× map 87 x≈-24 z≈120; 28× map 87 x≈-32 z≈128 |
| crossroads | 792 | 22 | 0.2505 | 0.0152 | 0.0076 | 22× map 78 x≈120 z≈0 |
| ranch | 60 | 0 | 0.2505 | 0.0000 | 0.0000 | - |
| beach | 1920 | 0 | 0.2505 | 0.0000 | 0.0000 | - |

- **mass of the recipe that reaches the dock end: 0.2505** (the D grid includes 82–83, which never clear the small wall on the dog-beach save)

| first cut D | P(some B reaches the dock end) | B in the window (VIs: count of beach states) | why the other B stop (D without a window) |
|---|---|---|---|
| 84 | 1.000 | 22: 960 | - |
| 86 | 1.000 | 22: 960 | - |

Second cut B by first cut D (share of the beach-state mass that reaches the dock end; else why Jack stopped, and where):

- D 84: 112–121 no READY (map 9 x≈-208 z≈120) · 122–143 READY · 144–151 no READY (map 9 x≈-224 z≈224)
- D 86: 112–117 no READY (map 9 x≈-208 z≈128) · 118–139 READY · 140–151 no READY (map 9 x≈-224 z≈224)

| 1st cut (web app bands) | share of the D grid | P(a 2nd cut reaches the dock end) |
|---|---|---|
| tight | 1.000 | 1.000 |

## Lines (dog-neutral: anchored at the beach load, matched by game state at READY)

- 120 lines from 960 beach states; lines per beach state (count of states): 3: 81, 4: 833, 5: 46; **0 of 960 beach states collapse to one line** (every first and second cut of that state shares one RNG trajectory, offset in time only)
- largest READY offset inside a line: 98 VIs; members not matched to any path: 0

## Cut timing, split as the web app does (cast spread 150 ms)

| preset | share of routes | release bite 1 | hold to bite 2 | either (upper bound) |
|---|---|---|---|---|
| All | 1.000 | 6.49% at 0.3 s | 7.37% at 36.8 s | 10.71% at 19.9 s |
| 1st cut tight | 1.000 | 6.49% at 0.3 s | 7.37% at 36.8 s | 10.71% at 19.9 s |
| 1st cut tight · 2nd cut early | 0.545 | 6.64% at 0.37 s | 7.73% at 36.87 s | 10.73% at 19.93 s |
| 1st cut tight · 2nd cut middle | 0.182 | 7.27% at 0.1 s | 7.73% at 36.77 s | 10.78% at 21.97 s |
| 1st cut tight · 2nd cut late | 0.273 | 6.35% at 0.13 s | 7.57% at 36.63 s | 10.74% at 19.73 s |
| 1st cut mid | 0.000 | - | - | - |
| 1st cut mid · 2nd cut early | 0.000 | - | - | - |
| 1st cut mid · 2nd cut middle | 0.000 | - | - | - |
| 1st cut mid · 2nd cut late | 0.000 | - | - | - |
| 1st cut loose | 0.000 | - | - | - |
| 1st cut loose · 2nd cut early | 0.000 | - | - | - |
| 1st cut loose · 2nd cut middle | 0.000 | - | - | - |
| 1st cut loose · 2nd cut late | 0.000 | - | - | - |

## Lineup: stability

- 120 lines; the heaviest holds 12.2% of the routes; 7 lines hold 50% and 30 hold 90% (fewer = steadier dog)
- one beach start (beach state + wait) across the full pier width: lines (count of starts) 3: 81, 4: 833, 5: 46; how the second cuts split: B 118-119 + B 120-123 + B 122-139 + B 126-143 (825 starts); B 118-143 + B 120-123 + B 122-139 (81 starts); B 118-119 + B 120-123 + B 122-123 + B 124-139 + B 126-143 (21 starts); B 118-119 + B 120-123 + B 122-139 + B 126-137 + B 138-143 (13 starts)
- one wait + second cut across the beach states (the route before the beach): lines (count) 18: 26, 19: 14, 20: 18, 21: 38, 22: 32, 23: 18, 24: 12, 25: 2, 26: 16, 27: 18, 28: 62, 29: 4, 30: 36, 31: 74, 32: 18, 33: 14, 34: 14

## Lineup: does the dog keep drawing after READY (standing at the pier, no cast)?

- routes whose line has the dog drawing after READY: **100.0%**; extra draws over 39 s (above the 1-per-game-frame clock), route-weighted mean 172; dog's tile visible 100% of the time

## Lineup: where the dog activates (its tile enters the camera's view; until then it draws nothing)

First VI after the beach load (share of routes): 205: 0.3%, 207: 0.9%, 209: 3.7%, 211: 6.3%, 213: 6.3%, 215: 6.2%, 217: 6.3%, 219: 6.3%, 221: 6.2%, 223: 6.3%, 225: 6.2%, 227: 6.3%, 229: 6.2%, 231: 6.2%, 233: 6.3%, 235: 6.2%, 237: 6.0%, 239: 5.4%, 241: 2.6%

| Jack at the activation (x, z; 8-unit cells) | share of routes | lines | release bite 1 | hold to bite 2 |
|---|---|---|---|---|
| x -456…-448, z 160…168 | 0.727 | 112 | 6.55% at 0.23 s (cover 0.92) | 7.38% at 36.73 s (cover 1.00) |
| x -448…-440, z 152…160 | 0.182 | 116 | 6.64% at 0.4 s (cover 0.92) | 7.78% at 36.9 s (cover 1.00) |
| x -448…-440, z 144…152 | 0.091 | 111 | 6.68% at 0.33 s (cover 0.92) | 7.85% at 36.87 s (cover 1.00) |

## Lineup: beach wait W (VIs Jack stands still at the beach load before his first step)

| W (VIs) | share of routes | lines | release bite 1 | hold to bite 2 |
|---|---|---|---|---|
| 0 | 0.062 | 43 | 6.94% at 0.43 s (cover 0.92) | 7.19% at 36.9 s (cover 1.00) |
| 2 | 0.062 | 41 | 7.42% at 0.5 s (cover 0.94) | 8.52% at 36.83 s (cover 1.00) |
| 4 | 0.062 | 41 | 7.64% at 0.53 s (cover 0.95) | 8.78% at 36.83 s (cover 1.00) |
| 6 | 0.062 | 40 | 7.98% at 0.47 s (cover 0.93) | 8.11% at 36.8 s (cover 1.00) |
| 8 | 0.062 | 40 | 7.72% at 0.43 s (cover 0.93) | 7.71% at 21.93 s (cover 0.99) |
| 10 | 0.062 | 42 | 7.37% at 0.43 s (cover 0.93) | 8.06% at 21.93 s (cover 0.99) |
| 12 | 0.062 | 43 | 7.66% at 0.37 s (cover 0.93) | 8.43% at 21.9 s (cover 1.00) |
| 14 | 0.062 | 43 | 7.40% at 0.33 s (cover 0.91) | 8.52% at 21.97 s (cover 0.98) |
| 16 | 0.062 | 43 | 6.91% at 8.0 s (cover 0.94) | 7.90% at 22.03 s (cover 0.96) |
| 18 | 0.062 | 44 | 6.84% at 2.73 s (cover 0.94) | 7.62% at 19.83 s (cover 0.99) |
| 20 | 0.062 | 45 | 6.85% at 2.7 s (cover 0.94) | 7.87% at 36.87 s (cover 1.00) |
| 22 | 0.062 | 45 | 6.95% at 0.1 s (cover 0.91) | 8.52% at 36.8 s (cover 1.00) |
| 24 | 0.062 | 46 | 6.07% at 0.1 s (cover 0.91) | 7.68% at 36.73 s (cover 1.00) |
| 26 | 0.062 | 47 | 6.47% at 5.63 s (cover 0.96) | 7.62% at 36.67 s (cover 1.00) |
| 28 | 0.062 | 44 | 6.54% at 0.1 s (cover 0.92) | 7.87% at 36.53 s (cover 1.00) |
| 30 | 0.062 | 45 | 6.46% at 0.13 s (cover 0.92) | 7.63% at 36.47 s (cover 1.00) |

## Lineup: first cut D (VIs of down-right after the beach load, before the cut down-left)

D 84 = the earliest cut that clears the small wall (scrapes its corner: Jack pushed to x -451.6); D 86 = one game frame later (clears the corner: x -452.0, still the wall column of the dog's view grid).

| first cut | share of routes | lines | of them shared with the other cut | dog wakes, VI after the beach load - W (share) | release bite 1 | hold to bite 2 |
|---|---|---|---|---|---|---|
| D 84 | 0.500 | 116 | 111 | 211 (82%), 209 (9%), 207 (9%) | 6.49% at 0.27 s (cover 0.92) | 7.33% at 36.8 s (cover 1.00) |
| D 86 | 0.500 | 115 | 111 | 209 (82%), 207 (9%), 205 (9%) | 6.50% at 0.3 s (cover 0.92) | 7.41% at 36.8 s (cover 1.00) |

## Lineup: wait band x second cut (full pier width; early / middle / late = dock-end spot z ≤178 / ≤190 / >190)

| wait | 2nd cut | share of routes | lines | release bite 1 | hold to bite 2 |
|---|---|---|---|---|---|
| wait 0-9 | any | 0.312 | 62 | 7.51% at 0.47 s (cover 0.93) | 8.02% at 36.83 s (cover 1.00) |
| wait 0-9 | Early | 0.170 | 62 | 7.73% at 0.53 s (cover 0.93) | 8.45% at 36.9 s (cover 1.00) |
| wait 0-9 | Middle | 0.057 | 52 | 8.01% at 0.43 s (cover 0.93) | 8.61% at 36.8 s (cover 1.00) |
| wait 0-9 | Late | 0.085 | 52 | 7.95% at 0.27 s (cover 0.93) | 8.37% at 36.67 s (cover 1.00) |
| wait 10-19 | any | 0.312 | 68 | 6.84% at 8.0 s (cover 0.95) | 8.02% at 21.97 s (cover 0.98) |
| wait 10-19 | Early | 0.170 | 67 | 7.43% at 8.07 s (cover 0.95) | 8.35% at 22.07 s (cover 0.98) |
| wait 10-19 | Middle | 0.057 | 55 | 7.59% at 0.17 s (cover 0.91) | 8.43% at 27.4 s (cover 0.99) |
| wait 10-19 | Late | 0.085 | 57 | 7.24% at 7.83 s (cover 0.95) | 8.20% at 21.83 s (cover 0.98) |
| wait 20-30 | any | 0.375 | 74 | 6.43% at 0.1 s (cover 0.91) | 7.43% at 36.67 s (cover 1.00) |
| wait 20-30 | Early | 0.205 | 73 | 6.81% at 0.2 s (cover 0.91) | 7.70% at 36.77 s (cover 1.00) |
| wait 20-30 | Middle | 0.068 | 62 | 8.17% at 0.1 s (cover 0.91) | 7.72% at 36.63 s (cover 1.00) |
| wait 20-30 | Late | 0.102 | 63 | 5.66% at 22.23 s (cover 0.99) | 7.62% at 36.53 s (cover 1.00) |
| any wait | any | 1.000 | 120 | 6.49% at 0.3 s (cover 0.92) | 7.37% at 36.8 s (cover 1.00) |
| any wait | Early | 0.545 | 120 | 6.64% at 0.37 s (cover 0.92) | 7.73% at 36.87 s (cover 1.00) |
| any wait | Middle | 0.182 | 112 | 7.27% at 0.1 s (cover 0.92) | 7.73% at 36.77 s (cover 1.00) |
| any wait | Late | 0.273 | 112 | 6.35% at 0.13 s (cover 0.92) | 7.57% at 36.63 s (cover 1.00) |

## Menus (mash until the house loads)

| style | presses/s | held VIs | house arrival VI (count of phases) |
|---|---|---|---|
| START+A | 15.0 | 2 | 1038×2, 1040×2 |
| START+A | 12.0 | 2 | 1042×2, 1044×2, 1046×1 |
| START+A | 10.0 | 3 | 1042×2, 1044×2, 1046×2 |
| START+A | 8.6 | 3 | 1042×1, 1044×1, 1046×1, 1048×1, 1050×1, 1052×1, 1054×1 |
| START+A | 7.5 | 4 | 1038×2, 1040×2, 1042×2, 1044×2 |
| START+A | 6.7 | 4 | 1038×1, 1040×2, 1042×2, 1044×2, 1046×1, 1056×1 |
| START+A | 6.0 | 5 | 1052×2, 1054×2, 1056×2, 1058×2, 1060×2 |
| START+A | 5.5 | 5 | 1050×2, 1052×2, 1054×2, 1056×2, 1058×2, 1060×1 |
| START+A | 5.0 | 6 | 1054×2, 1056×2, 1058×2, 1060×2, 1064×2, 1074×2 |
| START>A | 15.0 | 2 | 1038×2, 1040×2 |
| START>A | 12.0 | 2 | 1042×2, 1044×2, 1046×1 |
| START>A | 10.0 | 3 | 1036×1, 1038×1, 1040×1, 1042×1, 1044×1, 1046×1 |
| START>A | 8.6 | 3 | 1042×1, 1044×2, 1046×2, 1048×2 |
| START>A | 7.5 | 4 | 1038×2, 1040×2, 1042×2, 1044×2 |
| START>A | 6.7 | 4 | 1038×1, 1040×2, 1042×2, 1044×2, 1046×1, 1056×1 |
| START>A | 6.0 | 5 | 1052×2, 1054×2, 1056×2, 1058×2, 1060×2 |
| START>A | 5.5 | 5 | 1050×2, 1052×2, 1054×2, 1056×2, 1058×2, 1060×1 |
| START>A | 5.0 | 6 | 1042×2, 1044×2, 1046×2, 1048×2, 1052×2, 1062×2 |

## House (up-left U, down-left V, down) — farm arrival, VIs after the house load: count of (U, V) runs

412:40, 414:160, 416:480, 418:510, 420:300, 422:310, 424:320, 426:130, 428:100, 430:160, 432:80, 434:90, 436:80, 438:80, 440:50, 442:40, 444:40, 446:10, None:660

## Crossroads (left, cut down-left at C) — ranch arrival, VIs after the farm load: count of runs

586:310, 588:248, 590:310, 592:155, 594:62, None:31

## Beach (first cut D, second cut B; VIs after the beach load)

| D | dog first moved, VIs after the beach load (count) | B reaching the dock end (total) | READY windows (B) |
|---|---|---|---|
| 84 | None×1104 | 24288 | 122–143 |
| 86 | None×1104 | 24288 | 118–139 |

## Dog lines: 120 (members = beach state × D × B that reach the dock end)

- casts evaluated: 16722 distinct states; repeat checks agree 332, disagree 0

| line | weight | members | beach draw | READY spread (VIs) | casts | Nut casts b1 / b2 |
|---|---|---|---|---|---|---|
| f8ce1cfe56f98246 | 0.122 | 5058 | 1087 | 66 | 1197 | 22 / 43 |
| e21fcd41689718cf | 0.090 | 3822 | 1088 | 72 | 1197 | 29 / 31 |
| f45e322baa600a73 | 0.071 | 2866 | 1090 | 66 | 1197 | 72 / 70 |
| f7d417e8aed174ed | 0.070 | 2674 | 1098 | 82 | 1197 | 55 / 38 |
| e33cf3235c94133d | 0.060 | 2480 | 1098 | 76 | 1197 | 31 / 27 |
| bbabf75a86be3921 | 0.060 | 2492 | 1089 | 98 | 1197 | 19 / 35 |
| 38f94e2363a8b83c | 0.053 | 2312 | 1087 | 74 | 1197 | 3 / 19 |
| ddfc4481a1f0a5d8 | 0.053 | 2136 | 1089 | 44 | 1197 | 17 / 43 |
| fe86df512c80848c | 0.051 | 2214 | 1090 | 66 | 1197 | 61 / 48 |
| fcf8ac10fedceacd | 0.045 | 1948 | 1091 | 56 | 1197 | 19 / 35 |
| e7f008abfb3f3a12 | 0.038 | 1580 | 1086 | 44 | 1197 | 55 / 57 |
| 5ff8eaade721111c | 0.037 | 1498 | 1086 | 44 | 1197 | 20 / 35 |
| f8ce65dafb66879e | 0.019 | 906 | 1096 | 44 | 1197 | 16 / 35 |
| de826fc9ac693be1 | 0.017 | 824 | 1098 | 80 | 1197 | 42 / 62 |
| f33c711c19ab865c | 0.016 | 796 | 1113 | 44 | 1197 | 66 / 39 |
| f0049bd70c7456cc | 0.013 | 670 | 1116 | 22 | 1197 | 8 / 44 |
| f330c9c6b6b4f2ea | 0.012 | 470 | 1098 | 60 | 1197 | 52 / 53 |
| dfcd89548ae6d504 | 0.011 | 390 | 1098 | 60 | 1197 | 4 / 25 |
| fe2560ba15804cc8 | 0.010 | 328 | 1098 | 28 | 1197 | 16 / 35 |
| f167efa659ba4357 | 0.010 | 594 | 1105 | 22 | 1197 | 48 / 53 |
| fe919794516a7761 | 0.006 | 236 | 1113 | 22 | 1197 | 63 / 66 |
| af37d3b76551b757 | 0.006 | 200 | 1098 | 54 | 1197 | 49 / 63 |
| e5f624cc735c995a | 0.005 | 184 | 1098 | 82 | 1197 | 4 / 19 |
| b583632954fca348 | 0.005 | 176 | 1098 | 22 | 1197 | 61 / 48 |
| fad380c6c8db912d | 0.005 | 410 | 1087 | 44 | 1197 | 47 / 25 |
| 6134c669624dc6fe | 0.005 | 260 | 1104 | 56 | 1197 | 22 / 43 |
| d973f1af62cdc778 | 0.004 | 152 | 1118 | 44 | 1197 | 17 / 35 |
| 0b0e1e6059a8367f | 0.003 | 124 | 1086 | 88 | 1197 | 45 / 61 |
| fb6f64a707f9b9c0 | 0.003 | 104 | 1101 | 28 | 1197 | 61 / 63 |
| 3a158c12fd5cb28e | 0.002 | 88 | 1101 | 22 | 1197 | 65 / 48 |
| 66eeee2231aa85d1 | 0.002 | 88 | 1101 | 22 | 1140 | 61 / 48 |
| 67f841b1f34d7837 | 0.002 | 88 | 1101 | 22 | 938 | 5 / 35 |
| 6ee55ef1f207f5f0 | 0.002 | 88 | 1101 | 22 | 1109 | 48 / 52 |
| 97681756b301fc0f | 0.002 | 88 | 1101 | 22 | 1037 | 55 / 38 |
| b8ca855931ec4b4f | 0.002 | 88 | 1101 | 22 | 1155 | 63 / 48 |
| c424bb477a0aed84 | 0.002 | 88 | 1101 | 22 | 938 | 5 / 35 |
| dd320ed79783f254 | 0.002 | 88 | 1101 | 22 | 0 | 0 / 0 |
| e21ad5228e5d3764 | 0.002 | 88 | 1101 | 22 | 915 | 20 / 25 |
| eefade72778171be | 0.002 | 88 | 1101 | 22 | 937 | 5 / 35 |
| f52e255253b17612 | 0.002 | 88 | 1101 | 22 | 1041 | 55 / 39 |

## Lucky Timer, whole pool (aim = time after READY at the dock end; cast spread 1 s.d.)

| spread | release bite 1 | hold to bite 2 | either (smart, upper bound) | coverage at best |
|---|---|---|---|---|
| 0 ms | 8.7% at 1.77 s | 9.2% at 36.87 s | 12.8% at 21.97 s | 0.983 |
| 100 ms | 6.7% at 0.3 s | 7.7% at 36.8 s | 10.9% at 19.9 s | 0.994 |
| 150 ms | 6.5% at 0.3 s | 7.4% at 36.8 s | 10.7% at 19.9 s | 0.994 |
| 250 ms | 6.4% at 0.2 s | 6.9% at 21.8 s | 10.6% at 19.93 s | 0.994 |

- **Member recast check** (casts from members' own routes vs the shared line table): agree 1779, disagree 2, no table entry 0

  - ['f167efa659ba4357', '81e0a083c12c6a06@w16', 84, 130, 886, [1620, False, 3752, False], [1620, False, 3796, False]]
  - ['fe86df512c80848c', 'fd6c2b4bec9f1ebc@w4', 84, 139, 420, [1896, False, 2286, False], [1388, False, 1988, False]]
