# Dog-watch report: beach-lineup2-52cfd712

120 dog lines with traces (40 s after READY), 1410 (line, READY offset) variants; route-weighted. Clock = the dock-end tap ±3 VI; logs from 1.0 s after READY; runner: changes >= 12 VI, reaction 10-25 VI, 15% missed. Odds: cast >= 2 s after the window, ±150 ms.

## What the dog does while you wait (after READY, route-weighted)

- dog's tile on the visibility grid (it animates only then): 100% of the time
- visible changes per minute: 59; changes lasting >= 12 VI: 90%
- facing on screen (share of the wait): SW 38%, SE 19%, E 14%, NE 13%, NW 9%, N 6%, W 1%; animations readable (dog faces S / N / NE / E / SE): 52%
- the dog moves (units, max over the trace): median 0.0
- decision (actionState change) -> next visible change: median 0 VI (p10 0, p90 30); animation set -> displayed: median 0 VI

## Telling the lines apart (simulated runners)

| logging | window | right line on top | posterior on it | >= 90% sure | lines left | logs | Nut (no logs -> logs) | known line |
|---|---|---|---|---|---|---|---|---|
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 3 s | 30% | 22% | 3% | 48.9 | 0.2 | 7.5% -> 10.9% | 22.1% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 5 s | 33% | 24% | 5% | 47.7 | 0.4 | 7.6% -> 11.8% | 22.1% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 10 s | 53% | 43% | 16% | 31.7 | 1.3 | 7.0% -> 15.2% | 21.5% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 15 s | 66% | 57% | 34% | 26.2 | 2.3 | 7.3% -> 15.9% | 20.2% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 20 s | 68% | 59% | 38% | 24.2 | 4.0 | 7.1% -> 16.4% | 20.0% |
| gear, arrows only (no arrow = same facing) | 3 s | 31% | 19% | 2% | 49.8 | 0.0 | 7.1% -> 10.2% | 22.3% |
| gear, arrows only (no arrow = same facing) | 5 s | 29% | 19% | 2% | 48.4 | 0.0 | 7.1% -> 10.1% | 21.4% |
| gear, arrows only (no arrow = same facing) | 10 s | 44% | 34% | 10% | 38.9 | 0.2 | 7.1% -> 12.7% | 21.0% |
| gear, arrows only (no arrow = same facing) | 15 s | 59% | 49% | 30% | 28.9 | 0.6 | 6.9% -> 15.0% | 19.8% |
| gear, arrows only (no arrow = same facing) | 20 s | 63% | 53% | 31% | 28.6 | 1.0 | 7.6% -> 16.0% | 20.2% |
| your logging (arrows always, letters for long animations facing S/N/E) | 3 s | 26% | 13% | 2% | 99.2 | 0.2 | 7.5% -> 9.9% | 22.1% |
| your logging (arrows always, letters for long animations facing S/N/E) | 5 s | 30% | 17% | 3% | 92.1 | 0.5 | 7.7% -> 10.9% | 21.9% |
| your logging (arrows always, letters for long animations facing S/N/E) | 10 s | 43% | 30% | 11% | 72.0 | 1.4 | 7.5% -> 13.9% | 21.6% |
| your logging (arrows always, letters for long animations facing S/N/E) | 15 s | 62% | 45% | 21% | 47.9 | 2.8 | 7.6% -> 15.7% | 20.1% |
| your logging (arrows always, letters for long animations facing S/N/E) | 20 s | 62% | 49% | 30% | 41.2 | 4.4 | 6.5% -> 15.5% | 19.4% |
| arrows only (facing track + durations) | 3 s | 14% | 6% | 0% | 118.6 | 0.0 | 7.8% -> 8.0% | 22.4% |
| arrows only (facing track + durations) | 5 s | 15% | 7% | 1% | 117.1 | 0.0 | 6.9% -> 7.3% | 22.0% |
| arrows only (facing track + durations) | 10 s | 29% | 19% | 6% | 93.1 | 0.2 | 7.1% -> 11.0% | 21.6% |
| arrows only (facing track + durations) | 15 s | 40% | 29% | 14% | 76.4 | 0.6 | 7.1% -> 12.9% | 19.6% |
| arrows only (facing track + durations) | 20 s | 50% | 37% | 22% | 65.7 | 1.0 | 7.1% -> 14.0% | 20.0% |
| every change, letter + arrow | 3 s | 72% | 61% | 43% | 19.8 | 1.2 | 7.1% -> 17.5% | 22.0% |
| every change, letter + arrow | 5 s | 84% | 80% | 66% | 3.5 | 2.5 | 7.2% -> 20.1% | 21.8% |
| every change, letter + arrow | 10 s | 90% | 87% | 74% | 2.2 | 6.3 | 7.6% -> 20.7% | 21.4% |
| every change, letter + arrow | 15 s | 92% | 88% | 74% | 1.9 | 10.5 | 7.4% -> 19.4% | 20.0% |
| every change, letter + arrow | 20 s | 89% | 87% | 74% | 1.8 | 14.4 | 7.1% -> 19.0% | 19.6% |
| every animation change, letter only | 3 s | 73% | 65% | 45% | 17.3 | 1.2 | 7.9% -> 18.2% | 22.0% |
| every animation change, letter only | 5 s | 87% | 82% | 67% | 4.2 | 2.4 | 7.3% -> 20.3% | 22.2% |
| every animation change, letter only | 10 s | 92% | 88% | 75% | 1.9 | 6.3 | 7.4% -> 21.1% | 21.8% |
| every animation change, letter only | 15 s | 91% | 88% | 77% | 1.8 | 10.2 | 6.7% -> 19.1% | 19.7% |
| every animation change, letter only | 20 s | 92% | 88% | 74% | 1.8 | 14.0 | 6.9% -> 18.8% | 19.3% |
| Space at every change | 3 s | 32% | 13% | 0% | 67.2 | 1.3 | 7.3% -> 10.6% | 22.2% |
| Space at every change | 5 s | 50% | 32% | 5% | 33.2 | 2.5 | 7.7% -> 14.0% | 21.6% |
| Space at every change | 10 s | 84% | 76% | 55% | 4.9 | 6.4 | 7.3% -> 19.6% | 21.2% |
| Space at every change | 15 s | 84% | 80% | 65% | 3.0 | 10.8 | 7.1% -> 19.2% | 19.7% |
| Space at every change | 20 s | 86% | 80% | 64% | 3.0 | 14.2 | 6.8% -> 18.1% | 18.8% |

Readability: *your logging* follows Thomas's TV check (facing always readable; animations only while the dog
faces S, N, NE, E or SE, and only animations lasting >= 1 s are logged). The other rows are for comparison.

## Duds before the cast (reset early)

Dud = the best cast for what your logs leave is under the threshold; you reset instead of casting. Odds per attempt; 'kept' = attempts you cast.

| logging | window | threshold | attempts called dud | Nut on kept attempts | Nut the resets threw away | all-cast Nut |
|---|---|---|---|---|---|---|
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 3 s | 5% | 0% | 10.9% | 0.00 pts | 10.9% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 3 s | 8% | 0% | 10.9% | 0.00 pts | 10.9% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 5 s | 5% | 1% | 12.0% | 0.00 pts | 11.8% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 5 s | 8% | 1% | 12.0% | 0.00 pts | 11.8% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 10 s | 5% | 0% | 15.3% | 0.00 pts | 15.2% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 10 s | 8% | 0% | 15.3% | 0.00 pts | 15.2% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 15 s | 5% | 1% | 16.0% | 0.00 pts | 15.9% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 15 s | 8% | 1% | 16.0% | 0.00 pts | 15.9% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 20 s | 5% | 0% | 16.4% | 0.00 pts | 16.4% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 20 s | 8% | 3% | 16.7% | 0.26 pts | 16.4% |
| gear, arrows only (no arrow = same facing) | 3 s | 5% | 0% | 10.2% | 0.00 pts | 10.2% |
| gear, arrows only (no arrow = same facing) | 3 s | 8% | 0% | 10.2% | 0.00 pts | 10.2% |
| gear, arrows only (no arrow = same facing) | 5 s | 5% | 0% | 10.2% | 0.00 pts | 10.1% |
| gear, arrows only (no arrow = same facing) | 5 s | 8% | 0% | 10.2% | 0.00 pts | 10.1% |
| gear, arrows only (no arrow = same facing) | 10 s | 5% | 0% | 12.7% | 0.00 pts | 12.7% |
| gear, arrows only (no arrow = same facing) | 10 s | 8% | 0% | 12.7% | 0.00 pts | 12.7% |
| gear, arrows only (no arrow = same facing) | 15 s | 5% | 0% | 15.0% | 0.00 pts | 15.0% |
| gear, arrows only (no arrow = same facing) | 15 s | 8% | 16% | 16.4% | 1.26 pts | 15.0% |
| gear, arrows only (no arrow = same facing) | 20 s | 5% | 0% | 16.0% | 0.00 pts | 16.0% |
| gear, arrows only (no arrow = same facing) | 20 s | 8% | 17% | 18.1% | 1.01 pts | 16.0% |

### Early dud signs, your logging, 10 s window, dud = best cast under 5%

0% of attempts are duds at this threshold (if the line were known). A sign = what you log in a 1-s slot after READY; seen = share of attempts showing it; dud share = how many of those are duds.

| you log | seconds after READY | seen | dud share |
|---|---|---|---|
| numpad 1 sit | 9-10 | 17.2% | 0% |
| numpad 0 idle | 2-3 | 15.5% | 0% |
| numpad 5 run | 4-5 | 13.9% | 0% |
| numpad 4 walk | 6-7 | 13.9% | 0% |
| numpad 1 sit | 8-9 | 11.1% | 0% |
| faces NE | 5-6 | 8.6% | 0% |
| numpad 7 sniff | 1-2 | 6.4% | 0% |
| numpad 2 stand | 9-10 | 6.2% | 0% |
| numpad 2 stand | 5-6 | 6.2% | 0% |
| faces NW | 6-7 | 4.2% | 0% |
| faces SE | 8-9 | 3.8% | 0% |
| numpad 2 stand | 6-7 | 3.6% | 0% |
| numpad 0 idle | 1-2 | 3.0% | 0% |
| numpad 6 sleep | 9-10 | 3.0% | 0% |
| numpad 0 idle | 5-6 | 2.7% | 0% |
| faces NW | 5-6 | 2.4% | 0% |
| numpad 2 stand | 8-9 | 2.0% | 0% |
| numpad 9 shoulder | 6-7 | 2.0% | 0% |
| faces N | 5-6 | 2.0% | 0% |
| numpad 0 idle | 9-10 | 1.9% | 0% |

### Early dud signs, your logging, 10 s window, dud = best cast under 8%

0% of attempts are duds at this threshold (if the line were known). A sign = what you log in a 1-s slot after READY; seen = share of attempts showing it; dud share = how many of those are duds.

| you log | seconds after READY | seen | dud share |
|---|---|---|---|
| numpad 1 sit | 9-10 | 17.2% | 0% |
| numpad 0 idle | 2-3 | 15.5% | 0% |
| numpad 5 run | 4-5 | 13.9% | 0% |
| numpad 4 walk | 6-7 | 13.9% | 0% |
| numpad 1 sit | 8-9 | 11.1% | 0% |
| faces NE | 5-6 | 8.6% | 0% |
| numpad 7 sniff | 1-2 | 6.4% | 0% |
| numpad 2 stand | 9-10 | 6.2% | 0% |
| numpad 2 stand | 5-6 | 6.2% | 0% |
| faces NW | 6-7 | 4.2% | 0% |
| faces SE | 8-9 | 3.8% | 0% |
| numpad 2 stand | 6-7 | 3.6% | 0% |
| numpad 0 idle | 1-2 | 3.0% | 0% |
| numpad 6 sleep | 9-10 | 3.0% | 0% |
| numpad 0 idle | 5-6 | 2.7% | 0% |
| faces NW | 5-6 | 2.4% | 0% |
| numpad 2 stand | 8-9 | 2.0% | 0% |
| numpad 9 shoulder | 6-7 | 2.0% | 0% |
| faces N | 5-6 | 2.0% | 0% |
| numpad 0 idle | 9-10 | 1.9% | 0% |
