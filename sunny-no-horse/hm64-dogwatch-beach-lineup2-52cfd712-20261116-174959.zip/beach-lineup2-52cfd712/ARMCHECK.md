# Replay: existing rows vs the same jobs on the other emulator build

| file | jobs in the existing run | replayed | same job on both | **rows differing** | only in existing | only in replay | error rows (existing / replay) |
|---|---|---|---|---|---|---|---|
| Z1_menus.jsonl | 18 | 18 | 18 | **0** | 0 | 0 | 0 / 0 |
| Z2_house.jsonl | 10 | 7 | 7 | **0** | 3 | 0 | 0 / 0 |
| Z3_cross.jsonl | 31 | 22 | 22 | **0** | 9 | 0 | 0 / 0 |
| Z4_ranch.jsonl | 80 | 60 | 60 | **0** | 20 | 0 | 0 / 0 |
| Z5_beach.jsonl | 1104 | 960 | 960 | **0** | 144 | 0 | 0 / 0 |
| Z6_lines.jsonl | 1648 | 1648 | 1648 | **0** | 0 | 0 | 0 / 0 |

By content (job labels depend on how a run was split into steps):

| what | existing | replay | on both | **differing** |
|---|---|---|---|---|
| Z5 beach walks (beach state, D, B) | 90528 | 78720 | 78720 | **0** |

Z0_record.json (reference route record, without code / save name): **same**

**81435 jobs / walks / casts that both have; 0 differ.**
