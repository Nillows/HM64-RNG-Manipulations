# HM64 full-day lab — the cast table and the dog to the end of the game day

## 1. The day without a cast (every dog line, stay-awake push every 33 s)

- 120 lines ran of 120; dog at READY: [-198.51, 223.49]
- Clock at READY: 06:48 – 06:52. Followed to 8398 VIs = 140 s after READY (the limit).
- Same paths as the dog-watch run? cast hashes of the first 33 s: **119400 equal, 0 different**.
- Ended by something else than the limit / the end of the day: 0
- The dog's visible changes over that time: 145 per line.
- **The dog leaves its spot** (moved 4 units or more) on 92 of 120 lines; earliest 8 s after READY, median 101 s.
- Its tile leaves the visibility grid (not on screen, not animating) on 6 lines.

## 2. Cast blocks (every cast held to the limit, or the end of the day)

| block | cast frames (s after READY) | lines | casts planned | done | job errors | hash check ok / failed / none | ended: as planned / beach check / other | bites per cast | casts with a Nut on some bite |
|---|---|---|---|---|---|---|---|---|---|
| 2 | 40.1 – 80.2 · heavy | 30 | 8947 | 8947 | 0 | 8317 / 0 / 630 | 8947 / 0 / 0 | 5.4 | 343 (3.8%) |
| 3 | 40.1 – 80.2 · other | 90 | 11191 | 11191 | 0 | 9301 / 0 / 1890 | 11191 / 0 / 0 | 5.3 | 401 (3.6%) |

Blocks not started: 4 (42660 casts). Data so far: 20.7 MB.

## 3. The beach check

- 20138 casts: **20138 ran to the limit / the end of the day on the beach at the dock end**, 0 were stopped by the beach check, 0 ended another way.
- Cast hash = the dog-watch run's state at that frame: 17618 equal, **0 different**, 2520 not compared (cast frames inside a stay-awake push).

## 4. Bites and Nuts by game hour (on the held casts)

- 107461 bites; released 4 polls after the bite: s 43428, l 37566, m 25723, N 744 (N Nut, s / m / l fish size, d the day ended before the catch, x miss, h held through, o other; a / b = the two release probes differ).
- The two release probes of bites 1-2 gave different catches on 0 bites.
- Nut by bite number: bite 1: 608, bite 2: 125, bite 3: 11.

| game hour | bites | Nut bites | Nut share |
|---|---|---|---|
| 10:00 | 1766 | 0 | 0.00% |
| 11:00 | 5050 | 306 | 6.06% |
| 12:00 | 8512 | 435 | 5.11% |
| 13:00 | 8834 | 3 | 0.03% |
| 14:00 | 11984 | 0 | 0.00% |
| 15:00 | 21437 | 0 | 0.00% |
| 16:00 | 26319 | 0 | 0.00% |
| 17:00 | 16872 | 0 | 0.00% |
| 18:00 | 6645 | 0 | 0.00% |
| 19:00 | 42 | 0 | 0.00% |

These are bites of casts HELD since the cast frame, not fresh casts at that hour: a later hour is
reached only by holding through every earlier bite.

## 5. Do the held casts run into each other?

- 107461 bite states, 7234 distinct (93.3% shared): a shared state has the same future, so its later bites need not be simulated twice.

## 6. The dog after the cast

- Visible changes recorded from the cast to the end of its run: 76 per cast; on the released paths (the 4 s after each bite): 4.8 per bite.
- The dog leaves its spot at some point of the run in 16178 of 20138 casts (80%).

## 7. Against the dog-watch run's cast table (same state hash)

- 0 casts are in both: bite times and Nut flags **equal in 0, different in 0**.

