# HM64 full-day lab — the cast table and the dog to the end of the game day

## 1. The day without a cast (every dog line, stay-awake push every 33 s)

- 120 lines ran of 120; dog at READY: [-198.51, 223.49]
- Clock at READY: 06:48 – 06:52. Followed to 6598 VIs = 110 s after READY (the limit).
- Same paths as the dog-watch run? cast hashes of the first 33 s: **119400 equal, 0 different**.
- Ended by something else than the limit / the end of the day: 0
- The dog's visible changes over that time: 111 per line.
- **The dog leaves its spot** (moved 4 units or more) on 68 of 120 lines; earliest 8 s after READY, median 101 s.
- Its tile leaves the visibility grid (not on screen, not animating) on 3 lines.

## 2. Cast blocks (every cast held to the limit, or the end of the day)

| block | cast frames (s after READY) | lines | casts planned | done | job errors | hash check ok / failed / none | ended: as planned / beach check / other | bites per cast | casts with a Nut on some bite |
|---|---|---|---|---|---|---|---|---|---|
| 2 | 40.1 – 60.2 · heavy | 14 | 4407 | 4407 | 0 | 4407 / 0 / 0 | 4407 / 0 / 0 | 4.0 | 197 (4.5%) |

Blocks not started: 3 (43938 casts). Data so far: 3.7 MB.

## 3. The beach check

- 4407 casts: **4407 ran to the limit / the end of the day on the beach at the dock end**, 0 were stopped by the beach check, 0 ended another way.
- Cast hash = the dog-watch run's state at that frame: 4407 equal, **0 different**, 0 not compared (cast frames inside a stay-awake push).

## 4. Bites and Nuts by game hour (on the held casts)

- 17648 bites; released 4 polls after the bite: s 6596, l 6102, m 4753, N 197 (N Nut, s / m / l fish size, d the day ended before the catch, x miss, h held through, o other; a / b = the two release probes differ).
- The two release probes of bites 1-2 gave different catches on 0 bites.
- Nut by bite number: bite 1: 128, bite 2: 64, bite 3: 5.

| game hour | bites | Nut bites | Nut share |
|---|---|---|---|
| 10:00 | 876 | 0 | 0.00% |
| 11:00 | 2374 | 142 | 5.98% |
| 12:00 | 2537 | 55 | 2.17% |
| 13:00 | 1881 | 0 | 0.00% |
| 14:00 | 3332 | 0 | 0.00% |
| 15:00 | 6427 | 0 | 0.00% |
| 16:00 | 218 | 0 | 0.00% |
| 17:00 | 1 | 0 | 0.00% |
| 18:00 | 2 | 0 | 0.00% |

These are bites of casts HELD since the cast frame, not fresh casts at that hour: a later hour is
reached only by holding through every earlier bite.

## 5. Do the held casts run into each other?

- 17648 bite states, 1674 distinct (90.5% shared): a shared state has the same future, so its later bites need not be simulated twice.

## 6. The dog after the cast

- Visible changes recorded from the cast to the end of its run: 61 per cast; on the released paths (the 4 s after each bite): 5.2 per bite.
- The dog leaves its spot at some point of the run in 2745 of 4407 casts (62%).

## 7. Against the dog-watch run's cast table (same state hash)

- 0 casts are in both: bite times and Nut flags **equal in 0, different in 0**.

