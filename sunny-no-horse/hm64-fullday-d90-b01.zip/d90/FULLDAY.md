# HM64 full-day lab — the cast table and the dog to the end of the game day

## 1. The day without a cast (every dog line, stay-awake push every 33 s)

- 120 lines ran of 120; dog at READY: [-198.51, 223.49]
- Clock at READY: 06:48 – 06:52. Followed to 5398 VIs = 90 s after READY (the limit).
- Same paths as the dog-watch run? cast hashes of the first 33 s: **119400 equal, 0 different**.
- Ended by something else than the limit / the end of the day: 0
- The dog's visible changes over that time: 93 per line.
- **The dog leaves its spot** (moved 4 units or more) on 19 of 120 lines; earliest 8 s after READY, median 30 s.
- Its tile leaves the visibility grid (not on screen, not animating) on 3 lines.

## 2. Cast blocks (every cast held to the limit, or the end of the day)

| block | cast frames (s after READY) | lines | casts planned | done | job errors | hash check ok / failed / none | ended: as planned / beach check / other | bites per cast | casts with a Nut on some bite |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 0.1 – 40.1 · heavy | 30 | 17223 | 17223 | 0 | 16593 / 0 / 630 | 17223 / 0 / 0 | 4.7 | 1133 (6.6%) |
| 1 | 0.1 – 40.1 · other | 90 | 21837 | 21837 | 0 | 19947 / 0 / 1890 | 21837 / 0 / 0 | 4.7 | 1282 (5.9%) |

Blocks not started: 0 (0 casts). Data so far: 39.1 MB.

## 3. The beach check

- 39060 casts: **39060 ran to the limit / the end of the day on the beach at the dock end**, 0 were stopped by the beach check, 0 ended another way.
- Cast hash = the dog-watch run's state at that frame: 36540 equal, **0 different**, 2520 not compared (cast frames inside a stay-awake push).

## 4. Bites and Nuts by game hour (on the held casts)

- 184153 bites; released 4 polls after the bite: s 79938, l 64027, m 37773, N 2415 (N Nut, s / m / l fish size, d the day ended before the catch, x miss, h held through, o other; a / b = the two release probes differ).
- The two release probes of bites 1-2 gave different catches on 0 bites.
- Nut by bite number: bite 1: 1253, bite 2: 990, bite 3: 172.

| game hour | bites | Nut bites | Nut share |
|---|---|---|---|
| 08:00 | 18705 | 0 | 0.00% |
| 09:00 | 26115 | 1246 | 4.77% |
| 10:00 | 24433 | 1039 | 4.25% |
| 11:00 | 17370 | 130 | 0.75% |
| 12:00 | 31975 | 0 | 0.00% |
| 13:00 | 47580 | 0 | 0.00% |
| 14:00 | 17723 | 0 | 0.00% |
| 15:00 | 249 | 0 | 0.00% |
| 16:00 | 3 | 0 | 0.00% |

These are bites of casts HELD since the cast frame, not fresh casts at that hour: a later hour is
reached only by holding through every earlier bite.

## 5. Do the held casts run into each other?

- 184153 bite states, 6019 distinct (96.7% shared): a shared state has the same future, so its later bites need not be simulated twice.

## 6. The dog after the cast

- Visible changes recorded from the cast to the end of its run: 77 per cast; on the released paths (the 4 s after each bite): 5.2 per bite.
- The dog leaves its spot at some point of the run in 26389 of 39060 casts (68%).

## 7. Against the dog-watch run's cast table (same state hash)

- 16674 casts are in both: bite times and Nut flags **equal in 16669, different in 5**.
  - ('e7f008ab', 2050, [(340, False), (896, False), (1632, False)], [(340, False), (896, False), (1632, False)])
  - ('5ff8eaad', 2046, [(378, False), (1666, False), (2506, False)], [(378, False), (1666, False), (2506, False)])
  - ('de826fc9', 2052, [(904, False), (1640, False), (2496, False)], [(904, False), (1640, False), (2496, False)])
  - ('de826fc9', 2058, [(204, False), (1642, False), (1972, False)], [(204, False), (1642, False), (1972, False)])
  - ('0c8c3f1d', 2064, [(928, False), (1306, False), (1986, False)], [(928, False), (1306, False), (1986, False)])

