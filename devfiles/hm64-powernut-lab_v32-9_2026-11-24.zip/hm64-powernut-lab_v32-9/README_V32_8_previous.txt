HM64 Power Nut Tool v32.8 (2026-11-24): the cubes, and why branches merge
==========================================================================

What you asked for (2026-11-24 12:52 / 12:53)
  "i propose we simply show two wire frame cubes in anticipation of the upcoming data, one for sunny, one for rainy.
  then inside each one we have the 3 axis of horse/nohorse against married/notmarried/ against baby/no no baby."
  "speak a bit more to how the seperate lines can merge ... the branches merge for the same reason 1+2=3 AND 2+1=3 ...
  thats why we describe branches as merging once they reach the same value/dogstate pair, just at different moments
  in time."  "guide page also gets cubes yes."

What changed (v32.8 includes everything of v32.7)
  - README "How it works": the punnet square is now two wire-frame cubes (media/forest_10_cubes.svg): sunny and rainy,
    each horse x married x baby = 8 corners, 16 game files in all. Filled corners show their L1 (Sunny no horse and
    Sunny horse today); the two rainy unmarried, childless corners say "rain lab running"; the rest "later". A small
    H / M / B key on every corner says which file it is.
  - README: new paragraph "Why branches merge" after "Why not search down" (1 + 2 = 3 and 2 + 1 = 3; the pair = the
    random number's value + the dog's state; 4.3 billion values x the dog's states = huge but finite; endless ways to
    write 3, so keep the answer; the same pair reached at different moments = the same branch, entered higher or lower;
    merges up, forks down) and its picture media/forest_2b_merge.svg: real plays of Sunny -> Horse with menus 0, 3 and 5
    frames late all becoming L1, joining its path at +14, +19 and +33 frames (the most common moment for each).
  - guide.html: the same two pictures in How it works.
  - Toolkit: tools/forest_svg.py has "merge" and "cubes" (the punnet stays available: --only punnet);
    tools/forest_facts.py records, for the heaviest line, when each menu timing's plays reach it (k_off range, most
    common, one real play). Rain tables -> add them with --routes rainy-no-horse=... and the corners fill in; a married or
    baby set id is the same name with -married / -baby (e.g. sunny-horse-married-baby).
  - Page data unchanged (byte-equal to v32.7 apart from the version).

Release
  bash ~/Documents/hm64/tools/hm64_release.sh v32-8 <lab sha256> <pages sha256> </dev/null
  (if you have not released v32.7, skip it: v32.8 has all of it)
