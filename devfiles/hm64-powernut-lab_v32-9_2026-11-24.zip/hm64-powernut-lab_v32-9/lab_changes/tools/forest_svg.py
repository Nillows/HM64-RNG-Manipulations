#!/usr/bin/env python3
"""Forest diagrams: simple 2-D vector pictures for "How it works" (README) and the site's guide page.

    python3 tools/forest_svg.py webapp/assets/forest_facts.json --out media/        # every diagram
    python3 tools/forest_svg.py facts.json --out media/ --only punnet tuner          # some of them
    python3 tools/forest_svg.py --list                                               # what there is

The pictures are drawn from the facts file (tools/forest_facts.py), never typed in, so when a new lab run lands
(rainy tables, married, baby) the same command redraws them with the new numbers. One look for all of them:

  Svg            a canvas: title, subtitle, source line, dark rounded panel (reads on light and dark pages)
  tree()         a branching tree grown from the game's own random number generator (so it is the same every time)
  dog_branch()   a dog line drawn as a lightning-bolt branch from its real recorded timeline: every kink is a real
                 change in what the dog does, every segment lasts as long as the dog keeps doing it
  leaf(), sparrow(), sun(), rain(), horseshoe(), arrow(), chip()   the small parts

Colours are the app's: leaves green / gold / purple = Power Nut on bite 1 / bite 2 / bite 3+.
"""
from __future__ import annotations

import argparse
import json
import math
from html import escape
from pathlib import Path

INK, MUTED, FAINT = "#e6edf3", "#8ea3b2", "#5d7080"
BG, PANEL, GRID = "#0f1a24", "#16232f", "#22313f"
BARK, BARK2 = "#9a7652", "#6e5238"
CANOPY = ["#1e3a2a", "#244832", "#2b553a", "#1a3324"]
GREEN, GOLD, PURPLE = "#5fd38d", "#e7c14a", "#b48cff"
CYAN, PINK, SKY, RAIN = "#7fd6ff", "#ff8fb1", "#ffd76a", "#6fa8dc"
CUT = "#4a5866"
FONT = "system-ui,-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif"
LEAF = {"green": GREEN, "gold": GOLD, "purple": PURPLE}


def fmt(n):
    return f"{n:,}".replace("-", "−")


class Lcg:
    """The game's generator (libkmc rand: x = x * 1103515245 + 12345, s32), used to grow the trees."""

    def __init__(self, seed=0):
        self.x = seed & 0xFFFFFFFF

    def next(self):
        self.x = (self.x * 1103515245 + 12345) & 0xFFFFFFFF
        return self.x

    def u(self):                                   # 0..1, from the high bits as the game does
        return ((self.next() + 1) >> 16) % 32768 / 32768.0

    def s32(self):
        x = self.next()
        return x - (1 << 32) if x >= 1 << 31 else x


def lcg_values(n, seed=0):
    g = Lcg(seed)
    return [g.s32() for _ in range(n)]


class Svg:
    def __init__(self, w, h, title="", sub="", source="", label=None):
        self.w, self.h, self.items, self.defs = w, h, [], {}
        self.title, self.sub, self.source = title, sub, source
        self.label = label or title

    def add(self, s):
        self.items.append(s)
        return self

    def text(self, x, y, s, size=14, color=INK, anchor="start", weight="normal", italic=False, opacity=1):
        st = ' font-style="italic"' if italic else ""
        op = f' opacity="{opacity}"' if opacity != 1 else ""
        return self.add(f'<text x="{x:.1f}" y="{y:.1f}" font-size="{size}" fill="{color}" text-anchor="{anchor}" '
                        f'font-weight="{weight}"{st}{op}>{escape(str(s))}</text>')

    def lines(self, x, y, rows, size=13, color=MUTED, gap=None, anchor="start", weight="normal"):
        gap = gap or size * 1.35
        for i, r in enumerate(rows):
            self.text(x, y + i * gap, r, size, color, anchor, weight)
        return y + len(rows) * gap

    def line(self, x1, y1, x2, y2, color=MUTED, w=1.5, dash=None, cap="round", opacity=1, marker=None):
        d = f' stroke-dasharray="{dash}"' if dash else ""
        op = f' opacity="{opacity}"' if opacity != 1 else ""
        m = f' marker-end="url(#{marker})"' if marker else ""
        return self.add(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{color}" '
                        f'stroke-width="{w}" stroke-linecap="{cap}"{d}{op}{m}/>')

    def poly(self, pts, color=INK, w=2, fill="none", opacity=1, dash=None, join="round", close=False):
        if not pts:
            return self
        d = "M" + " L".join(f"{x:.1f},{y:.1f}" for x, y in pts) + (" Z" if close else "")
        ds = f' stroke-dasharray="{dash}"' if dash else ""
        op = f' opacity="{opacity}"' if opacity != 1 else ""
        return self.add(f'<path d="{d}" stroke="{color}" stroke-width="{w}" fill="{fill}" stroke-linejoin="{join}" '
                        f'stroke-linecap="round"{ds}{op}/>')

    def path(self, d, color="none", w=0, fill="none", opacity=1, extra=""):
        op = f' opacity="{opacity}"' if opacity != 1 else ""
        return self.add(f'<path d="{d}" stroke="{color}" stroke-width="{w}" fill="{fill}"{op} {extra}/>')

    def circle(self, x, y, r, fill=INK, stroke="none", w=0, opacity=1):
        op = f' opacity="{opacity}"' if opacity != 1 else ""
        return self.add(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{r:.1f}" fill="{fill}" stroke="{stroke}" '
                        f'stroke-width="{w}"{op}/>')

    def rect(self, x, y, w, h, fill=PANEL, stroke="none", sw=0, r=8, opacity=1, dash=None, extra=""):
        op = f' opacity="{opacity}"' if opacity != 1 else ""
        ds = f' stroke-dasharray="{dash}"' if dash else ""
        return self.add(f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" rx="{r}" fill="{fill}" '
                        f'stroke="{stroke}" stroke-width="{sw}"{op}{ds} {extra}/>')

    def defn(self, key, s):
        self.defs[key] = s

    def render(self):
        top = 0
        head = []
        if self.title:
            head.append(f'<text x="24" y="36" font-size="21" font-weight="700" fill="{INK}">{escape(self.title)}</text>')
        if self.sub:
            head.append(f'<text x="24" y="60" font-size="14" fill="{MUTED}">{escape(self.sub)}</text>')
        foot = []
        if self.source:
            foot.append(f'<text x="24" y="{self.h - 14}" font-size="11.5" fill="{FAINT}">{escape(self.source)}</text>')
        defs = "".join(self.defs.values())
        return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {self.w} {self.h}" width="{self.w}" '
                f'height="{self.h}" role="img" aria-label="{escape(self.label)}" font-family="{FONT}">'
                f'<title>{escape(self.label)}</title>'
                + (f"<defs>{defs}</defs>" if defs else "")
                + f'<rect x="0" y="{top}" width="{self.w}" height="{self.h}" rx="14" fill="{BG}"/>'
                + "".join(head) + "".join(self.items) + "".join(foot) + "</svg>\n")


# ---------------------------------------------------------------- parts

def arrow_def(svg, color=MUTED, key=None):
    key = key or "ar" + color.strip("#")
    svg.defn(key, f'<marker id="{key}" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" '
                  f'orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 Z" fill="{color}"/></marker>')
    return key


def arrow(svg, x1, y1, x2, y2, color=MUTED, w=1.8, dash=None):
    return svg.line(x1, y1, x2, y2, color, w, dash, marker=arrow_def(svg, color))


def leaf(svg, x, y, color=GREEN, r=6, angle=-30, glow=False):
    if glow:
        svg.circle(x, y, r * 2.6, fill=color, opacity=0.18)
    a = math.radians(angle)
    dx, dy = math.cos(a) * r, math.sin(a) * r
    svg.add(f'<ellipse cx="{x:.1f}" cy="{y:.1f}" rx="{r:.1f}" ry="{r * 0.55:.1f}" fill="{color}" '
            f'transform="rotate({angle} {x:.1f} {y:.1f})"/>')
    svg.line(x - dx * 0.8, y - dy * 0.8, x + dx * 0.8, y + dy * 0.8, "#0f1a24", 0.8, opacity=0.6)


def sparrow(svg, x, y, s=1.0, facing=1, color="#c9a27a"):
    f = facing
    svg.add(f'<ellipse cx="{x:.1f}" cy="{y:.1f}" rx="{7 * s:.1f}" ry="{4.6 * s:.1f}" fill="{color}"/>')
    svg.circle(x + f * 6 * s, y - 3.5 * s, 3.4 * s, fill=color)
    svg.circle(x + f * 7 * s, y - 4.2 * s, 0.8 * s, fill="#1a1a1a")
    svg.poly([(x + f * 9.2 * s, y - 3.6 * s), (x + f * 11.5 * s, y - 3 * s), (x + f * 9.2 * s, y - 2.4 * s)],
             "#e7a94a", 1, fill="#e7a94a")
    svg.poly([(x - f * 6 * s, y - 1 * s), (x - f * 12 * s, y - 4 * s), (x - f * 11 * s, y + 1 * s)], color, 1, fill=color)
    svg.line(x - 1 * s, y + 4 * s, x - 1 * s, y + 7 * s, "#7a5a3a", 1)
    svg.line(x + 2 * s, y + 4 * s, x + 2 * s, y + 7 * s, "#7a5a3a", 1)


def sun(svg, x, y, r=13, rays=10, color=SKY):
    for i in range(rays):
        a = 2 * math.pi * i / rays
        svg.line(x + math.cos(a) * r * 1.35, y + math.sin(a) * r * 1.35, x + math.cos(a) * r * 1.85,
                 y + math.sin(a) * r * 1.85, color, 2)
    svg.circle(x, y, r, fill=color)


def rain(svg, x, y, s=1.0):
    svg.circle(x - 9 * s, y, 8 * s, fill="#8a9aa8")
    svg.circle(x + 2 * s, y - 5 * s, 10 * s, fill="#9aaab8")
    svg.circle(x + 12 * s, y + 1 * s, 7 * s, fill="#8a9aa8")
    svg.rect(x - 16 * s, y, 34 * s, 8 * s, fill="#8a9aa8", r=4 * s)
    for i in range(5):
        xx = x - 12 * s + i * 7 * s
        svg.line(xx, y + 12 * s, xx - 3 * s, y + 21 * s, RAIN, 1.6)


def horseshoe(svg, x, y, s=1.0, color="#c8ccd2", crossed=False):
    r = 9 * s
    svg.path(f"M{x - r:.1f},{y + r:.1f} L{x - r:.1f},{y:.1f} A{r:.1f},{r:.1f} 0 0 1 {x + r:.1f},{y:.1f} "
             f"L{x + r:.1f},{y + r:.1f}", color, 4.2 * s, extra='stroke-linecap="round"')
    for dx in (-r, r):
        svg.circle(x + dx, y + 1 * s, 0.9 * s, fill=BG)
    if crossed:
        svg.line(x - r - 4, y + r + 4, x + r + 4, y - r - 4, PINK, 2.4)


def chip(svg, x, y, s, color=INK, fill=PANEL, size=13, stroke=GRID, pad=8, anchor="start", weight="normal"):
    w = len(str(s)) * size * 0.56 + 2 * pad
    x0 = x if anchor == "start" else (x - w / 2 if anchor == "middle" else x - w)
    svg.rect(x0, y - size - 4, w, size + 11, fill=fill, stroke=stroke, sw=1, r=6)
    svg.text(x0 + w / 2, y + 1, s, size, color, "middle", weight)
    return w


def tree(svg, x, y, h, g, depth=5, color=BARK, width=None, lean=0.0, spread=0.55, tips=None, canopy_y=None, opacity=1):
    """A tree grown from the game's generator g (same picture every time). Returns the tip points [(x, y)].
    Segments of one thickness go into one path, so a forest stays a small file."""
    tips = [] if tips is None else tips
    width = width or max(2.0, h / 28)
    a = -math.pi / 2 + lean
    x2, y2 = x + math.cos(a) * h * 0.42, y + math.sin(a) * h * 0.42
    buf = {}
    buf.setdefault(round(width, 1), []).append((x, y, x2, y2))
    _grow(x2, y2, a, h * 0.36, depth, g, width * 0.72, spread, tips, canopy_y, buf)
    for w, segs in sorted(buf.items(), reverse=True):
        d = "".join(f"M{x1:.0f},{y1:.0f}L{x2:.0f},{y2:.0f}" for x1, y1, x2, y2 in segs)
        svg.path(d, color, w, opacity=opacity, extra='stroke-linecap="round"')
    return tips


def _grow(x, y, a, ln, depth, g, w, spread, tips, canopy_y, buf):
    if depth == 0 or ln < 3:
        tips.append((x, y))
        return
    n = 2 + (1 if g.u() < 0.35 else 0)
    for i in range(n):
        da = (i - (n - 1) / 2) * spread + (g.u() - 0.5) * 0.5
        aa = a + da
        l2 = ln * (0.72 + g.u() * 0.22)
        x2, y2 = x + math.cos(aa) * l2, y + math.sin(aa) * l2
        if canopy_y is not None and y2 < canopy_y:
            y2 = canopy_y + g.u() * 6
        buf.setdefault(round(max(0.8, w), 1), []).append((x, y, x2, y2))
        _grow(x2, y2, aa, l2, depth - 1, g, w * 0.7, spread * 0.95, tips, canopy_y, buf)


# ---------------------------------------------------------------- dog lines as branches

def _lean(dir_, base):
    """A fixed lean (-1..1) for each thing the dog can be doing (facing x animation)."""
    h = (dir_ * 2654435761 + base * 40503) & 0xFFFF
    v = (h / 0xFFFF) * 2 - 1
    return math.copysign(0.35 + 0.65 * abs(v), v if v else 1)


def branch_points(vis, t_end, amp=1.0, t0=None):
    """(time, sideways) points of a dog line: one segment per run of the same behaviour, sideways lean by behaviour.
    Kept inside +-amp by turning back at the edge (a lightning bolt, not a drift)."""
    pts, lat = [], 0.0
    t0 = vis[0][0] if t0 is None else t0
    pts.append((t0, 0.0))
    for k0, k1, d, _anim, base in vis:
        if k0 >= t_end:
            break
        k1 = min(k1, t_end)
        if k1 <= t0:
            continue
        s = _lean(d, base)
        step = s * min(1.0, (k1 - max(k0, t0)) / 60.0) * amp * 0.9
        if abs(lat + step) > amp:
            step = -step
        lat += step
        pts.append((k1, lat))
    return pts


def dog_branch(svg, vis, map_fn, t_end, amp, color=CYAN, w=2.4, glow=True, t0=None, opacity=1):
    pts = branch_points(vis, t_end, amp, t0)
    xy = [map_fn(t, s) for t, s in pts]
    if glow:
        svg.poly(xy, color, w * 3.2, opacity=0.13 * opacity)
    svg.poly(xy, color, w, opacity=opacity)
    return pts, xy


def at_time(pts, t):
    """Sideways position of a branch at time t (linear between its kinks)."""
    for (ta, sa), (tb, sb) in zip(pts, pts[1:]):
        if ta <= t <= tb:
            return sa + (sb - sa) * ((t - ta) / (tb - ta) if tb > ta else 0)
    return pts[-1][1]


# ---------------------------------------------------------------- diagrams

def d_canopy(F):
    vals = lcg_values(5)
    s = Svg(960, 470, "A leaf in a forest",
            "Every random thing in the game comes from one number that changes every time anything asks for one.",
            "Generator: libkmc rand() in the game's code, a signed 32-bit number; starts at 0 when the N64 is switched on.")
    floor, top = 400, 124
    g = Lcg(2603)
    # canopy tangle
    for i in range(46):
        cx, cy = 50 + g.u() * 820, top + 10 + g.u() * 70
        s.circle(cx, cy, 26 + g.u() * 30, fill=CANOPY[i % 4], opacity=0.9)
    trees = [(80, 0.06), (185, -0.05), (290, 0.08), (395, -0.04), (500, 0.05), (605, -0.08), (710, 0.06), (815, -0.05)]
    for i, (x, ln) in enumerate(trees):
        tree(s, x, floor, 158, Lcg(i * 977 + 5), depth=6, lean=ln, spread=0.52, width=8,
             color=BARK if i != 3 else "#b58a5e", opacity=0.95)
    for i in range(70):                                   # branches crossing between crowns: one conjoined canopy
        x1, y1 = 60 + g.u() * 760, top + 6 + g.u() * 70
        s.line(x1, y1, x1 + (g.u() - 0.5) * 170, y1 + (g.u() - 0.5) * 40, BARK2, 1.1, opacity=0.85)
    # the leaf: on a low branch of tree 4
    lx, ly = 352, 300
    s.poly([(393, 345), (374, 322), (lx + 4, ly + 4)], "#b58a5e", 2.6)
    leaf(s, lx, ly, GREEN, 9, -40, glow=True)
    s.rect(120, 262, 196, 50, fill=PANEL, stroke=GREEN, sw=1.2, r=8)
    s.lines(132, 282, ["the leaf you want: one cast", "frame that lands the Power Nut"], 13, INK)
    s.line(316, 290, lx - 14, ly - 6, GREEN, 1.2, dash="3 3")
    # floor and range
    s.line(24, floor, 936, floor, "#3a2c20", 6)
    s.text(30, floor + 26, fmt(-2 ** 31), 12.5, MUTED)
    s.text(480, floor + 26, "0", 12.5, MUTED, "middle")
    s.text(930, floor + 26, "+" + fmt(2 ** 31 - 1), 12.5, MUTED, "end")
    s.text(480, floor + 44, "how wide the forest is: every value the random number can take", 12.5, FAINT, "middle")
    arrow(s, 922, floor - 10, 922, top - 18, MUTED, 1.6)
    s.rect(848, 196, 64, 80, fill=BG, r=6, opacity=0.85)
    s.lines(904, 214, ["time", "the game", "has been", "running"], 12, MUTED, gap=16, anchor="end")
    s.rect(500, 252, 330, 92, fill=PANEL, stroke=GRID, sw=1, r=8, opacity=0.96)
    s.lines(514, 274, ["The real generator after power-on:", "0 → " + fmt(vals[0]) + " → " + fmt(vals[1]) + " →",
                       fmt(vals[2]) + " → " + fmt(vals[3]) + " → …",
                       f"{fmt(F['sunlight'][0]['points'][1]['draw'])} steps by the time the house loads."], 12.5, MUTED,
            gap=17)
    s.rect(220, 76, 520, 26, fill=BG, r=6, opacity=0.85)
    s.text(480, 94, "the canopy: branches grow into each other — follow one down and it forks again and again", 13,
           INK, "middle")
    return s


def d_backwards(F):
    bt = F["raw"]["backtrace_top_line"]
    cr = bt["from_crowns"]
    s = Svg(960, 540, "Why not search down from the leaf?",
            "Follow a leaf down and every fork offers more than one way it could have come. You end with odds, not an answer.",
            f"Real trace: the most common dog line of {F['raw']['label']} (L1), back through every play the lab made "
            f"({fmt(bt['plays'])} of {fmt(F['raw']['combos_total'])}).")
    lx, ly = 480, 96
    leaf(s, lx, ly, GREEN, 9, -30, glow=True)
    s.text(lx + 18, ly + 5, "L1 at READY", 13.5, INK)
    layers = [(150, "beach"), (205, "ranch / crossroads"), (260, "farm"), (315, "house (menus)")]
    xs = [120 + i * 120 for i in range(7)]
    g = Lcg(11)
    prev = [(lx, ly + 8)]
    for li, (y, name) in enumerate(layers):
        n = [3, 5, 6, 7][li]
        cur = [(lx + (i - (n - 1) / 2) * (700 / max(n, 1)) * (0.45 + 0.18 * li), y) for i in range(n)]
        if li == 3:
            cur = [(x, y) for x in xs]
        for (x2, y2) in cur:
            for (x1, y1) in prev:
                if abs(x1 - x2) < 260 or len(prev) == 1:
                    s.line(x1, y1, x2, y2, BARK, 1.3, opacity=0.55 + 0.3 * g.u())
        for (x2, y2) in cur:
            s.circle(x2, y2, 3.2, fill=BARK)
        s.text(24, y + 4, name, 12.5, MUTED)
        prev = cur
    mx = max(c["share"] for c in cr)
    base = 470
    for x, c in zip(xs, cr):
        hgt = 100 * c["share"] / mx
        s.line(x, 318, x, base - hgt - 22, BARK, 1, dash="2 3", opacity=0.7)
        s.rect(x - 18, base - hgt, 36, hgt, fill=GREEN, r=3, opacity=0.85)
        s.text(x, base - hgt - 7, f"{c['share'] * 100:.0f}%", 14, INK, "middle", "bold")
        fl = (c['house_vi'] - F['raw']['band']['house_ref']) // 2
        s.text(x, base + 18, f"{fl} frame{'' if fl == 1 else 's'} late", 11.5, MUTED, "middle")
    s.line(70, base, 890, base, GRID, 1.2)
    s.text(860, 150, "Bars: how likely each of the 7", 12.5, MUTED, "end")
    s.text(860, 166, "menu timings is, for a player", 12.5, MUTED, "end")
    s.text(860, 182, "who reached L1", 12.5, MUTED, "end")
    return s


def d_crown(F):
    R = F["raw"]
    cr = R["crowns"]
    sl = F["sunlight"][0]["points"]
    house = sl[1]
    s = Svg(960, 500, "Grow it from the bottom: one seed, a crown of 7",
            "Every N64 starts the generator at 0. Fast menus can only reach the house on 7 different frames: 7 branches.",
            f"Lab: {R['menu_inputs']} menu rhythms (Start→A / Start+A, 4–12 presses a second, every phase). Sparrows: the "
            "farm's start-of-day roll, fixed by the menu timing.")
    base_y, crown_y = 440, 230
    s.line(30, base_y + 6, 930, base_y + 6, "#3a2c20", 6)
    s.circle(480, base_y, 9, fill=SKY)
    s.circle(480, base_y, 18, fill=SKY, opacity=0.2)
    s.text(500, base_y - 6, "seed 0: power on (the same on every N64)", 13, INK)
    s.poly([(480, base_y - 8), (476, 380), (484, 320), (479, crown_y + 34)], BARK, 13)
    s.text(500, 352, f"title screen and menus: {fmt(house['draw'])} draws by the time", 13, MUTED)
    s.text(500, 369, f"the house loads on the fastest menus (VI {fmt(house['vi'])})", 13, MUTED)
    # cut branches (slower menus)
    cut = R["house_cut_vis"]
    for i, v in enumerate(cut):
        x = 560 + i * 42
        s.poly([(482, crown_y + 34), (560 + i * 30, crown_y + 8), (x + 8, crown_y - 40)], CUT, 3, opacity=0.6)
        s.line(x + 2, crown_y - 34, x + 14, crown_y - 46, PINK, 2)
    s.text(905, crown_y - 66, f"{len(cut)} slower branches: cut", 12.5, PINK, "end")
    s.text(905, crown_y - 50, "(menus 7+ frames late — not in the tables)", 11.5, MUTED, "end")
    xs = [110 + i * 52 for i in range(7)]
    for i, (x, c) in enumerate(zip(xs, cr)):
        tipy = 128
        mid = (480 - (480 - x) * 0.45, crown_y - 20)
        s.poly([(478, crown_y + 34), mid, (x, tipy + 14)], BARK, 5)
        s.circle(x, tipy + 10, 5, fill=BARK)
        s.text(x, tipy - 2, f"{c['frames_late']}", 16, INK, "middle", "bold")
        s.text(x, tipy - 22, f"{c['house_vi']}", 11, MUTED, "middle")
        if c["sparrows"] == "door":
            for fr, fc in ((0.25, 1), (0.5, -1)):
                bx_, by_ = x + (mid[0] - x) * fr, tipy + 14 + (mid[1] - tipy - 14) * fr
                sparrow(s, bx_, by_ - 8, 0.95, fc)
    s.text(xs[0] - 22, tipy - 2, "frames late", 12.5, MUTED, "end")
    s.text(xs[0] - 22, tipy - 22, "house VI", 11, MUTED, "end")
    s.rect(24, 300, 300, 92, fill=PANEL, stroke=GRID, sw=1, r=8)
    s.lines(38, 322, ["Each frame later = one more draw:",
                      f"house at draw {cr[0]['draw']} … {cr[-1]['draw']} (0 … 6 frames late).",
                      "The two sparrows by the farm door mark", "5 and 6 frames late: their own table."], 12.5, MUTED,
            gap=17)
    return s


def d_sunlight(F):
    S = F["sunlight"]
    s = Svg(960, 560, "Sunlight: how fast each screen grows the branch",
            "Same route, same time on the clock; what is on screen decides how many random numbers each layer draws.",
            "Lab: the reference route recorded twice from power-on on each game file (equal both times). "
            "Draws = generator steps between two map loads.")
    layers = ["house", "farm", "crossroads", "ranch", "beach"]
    names = {"house": "house", "farm": "farm", "crossroads": "crossroads", "ranch": "ranch", "beach": "beach → READY"}
    y0, y1 = 470, 150
    p0 = S[0]["points"]
    vi_house, vi_ready = p0[1]["vi"], p0[-1]["vi"]
    ymap = lambda vi: y0 - (vi - vi_house) / (vi_ready - vi_house) * (y0 - y1)
    bounds = [next(p for p in p0 if p["at"] == a)["vi"] for a in layers] + [vi_ready]
    for a, v in zip(layers, bounds):
        y = ymap(v)
        s.line(150, y, 930, y, GRID, 1, dash="4 4")
    for i, a in enumerate(layers):
        ym = (ymap(bounds[i]) + ymap(bounds[i + 1])) / 2
        s.text(24, ym + 4, names[a], 13, MUTED)
    s.text(24, y1 - 8, "READY", 13, INK, weight="bold")
    s.text(24, y0 + 22, f"house load (VI {fmt(vi_house)})", 12, FAINT)
    cols = [(260 + i * 190) for i in range(len(S))]
    for x, sc in zip(cols, S):
        pts = {p["at"]: p for p in sc["points"]}
        rainy = "Rain" in sc["label"]
        horse = "no horse" not in sc["label"]
        (rain if rainy else sun)(s, x - 18, 118 if rainy else 116, *(() if rainy else (11,)))
        horseshoe(s, x + 20, 112, 0.9, crossed=not horse)
        s.text(x, 94, sc["label"], 13.5, INK, "middle", "bold")
        xy = []
        g = Lcg(len(sc["label"]))
        for i, a in enumerate(layers):
            va, vb = bounds[i], bounds[i + 1]
            da = pts[a]["draw"]
            db = pts[layers[i + 1]]["draw"] if i + 1 < len(layers) else pts["READY"]["draw"]
            draws = db - da
            per_frame = draws / ((vb - va) / 2)
            ya, yb = ymap(va), ymap(vb)
            kinks = int(min(max(2, draws / 7), (ya - yb) / 1.6))
            amp = min(30, 3 + 6.5 * per_frame)
            for k in range(kinks + 1):
                yy = ya - (ya - yb) * k / kinks
                side = (1 if k % 2 else -1) * amp * (0.55 + 0.45 * g.u())
                xy.append((x + (side if 0 < k < kinks else 0), yy))
            s.text(x + 44, (ya + yb) / 2 + 4, fmt(draws), 12.5, GOLD if rainy and a != "house" else INK)
        s.poly(xy, BARK, 1.8)
        s.text(x, y0 + 22, f"READY at draw {fmt(pts['READY']['draw'])}", 12, MUTED, "middle")
    by = {x["label"]: {p["at"]: p["draw"] for p in x["points"]} for x in S}
    a, b = by.get("Sunny, no horse"), by.get("Sunny, horse")
    if a and b:
        d = [b[k2] - b[k1] - (a[k2] - a[k1]) for k1, k2 in (("farm", "crossroads"), ("crossroads", "ranch"), ("ranch", "beach"))]
        s.text(24, y0 + 48, f"Owning the horse adds {d[0]} draws on the farm, {d[1]} at the crossroads and {d[2]} on the ranch even "
                            "when you never see it. Indoors (the house) it never rains.", 12.5, MUTED)
    return s


def d_three(F):
    R = F["raw"]
    cr = R["crowns"]
    sl = R["slack_vi"]
    tot = sl["house"] + sl["crossroads"] + sl["beach_wait"] + sl["first_cut"] + sl["pier_cut"]
    s = Svg(960, 520, "Each of the 7 branches splits three more times",
            "A few frames of slack in the house, at the crossroads and on the beach. Every branch still ends at READY.",
            f"{R['label']}: states counted per menu timing; slack = the timings the tables cover "
            f"({tot} VIs = {tot // 2} game frames ≈ {tot * F['vi_ms'] / 1000:.2f} s after the menus).")
    xs = [80 + i * 110 for i in range(7)]
    yB, yH, yC, yb, yR = 450, 380, 300, 215, 120
    s.line(30, yR, 800, yR, GOLD, 1.2, dash="5 4")
    s.text(812, yR + 4, "READY", 13, GOLD, weight="bold")
    rows = [(yH, "house turns", [f"0–{sl['house']} VIs ({sl['house'] // 2} frames)", "→ farm states"], "farm"),
            (yC, "crossroads turn", [f"0–{sl['crossroads']} VIs ({sl['crossroads'] // 2} frames)", "→ ranch states"], "ranch"),
            (yb, "beach", [f"first step 0–{sl['beach_wait']} VIs, first", f"cut 0–{sl['first_cut']}, pier cut {sl['pier_cut']} VIs",
                           f"({(sl['beach_wait'] + sl['first_cut'] + sl['pier_cut']) // 2} frames) → beach states"], "beach")]
    for y, name, slack, _k in rows:
        s.line(30, y, 800, y, GRID, 1, dash="3 4")
        s.text(812, y - 4, name, 12.5, INK)
        s.lines(812, y + 12, slack, 10.5, FAINT, gap=13)
    g = Lcg(7)
    for x, c in zip(xs, cr):
        s.poly([(x, yB), (x, yH)], BARK, 5)
        s.text(x, yB + 22, f"{c['frames_late']} late", 12.5, INK, "middle")
        if c["sparrows"] == "door":
            sparrow(s, x + 16, yB - 14, 0.8, -1)
        levels = [(yH, yC, c["farm_states"]), (yC, yb, c["ranch_states"]), (yb, yR, c["beach_states"])]
        starts = [(x, yH)]
        for (ya, yz, n) in levels:
            ends = []
            m = min(n, 9)
            spread = 40 if ya != yb else 44
            for j in range(m):
                xe = x + (j - (m - 1) / 2) * (2 * spread / max(m - 1, 1))
                sx, sy = starts[j % len(starts)]
                midy = (ya + yz) / 2 + (g.u() - 0.5) * 10
                s.poly([(sx, sy), (sx + (xe - sx) * 0.4, midy), (xe, yz)], BARK, 1.4, opacity=0.85)
                ends.append((xe, yz))
            starts = ends
        s.text(x, yR - 12, f"{c['lines']} lines", 12, CYAN, "middle")
        for (y, _n, _s, k) in rows:
            s.text(x - 4, y - 6, str(c[k + "_states"]), 11.5, INK, "end")
    m = R["merged"]
    s.text(40, 92, f"Counted across all 7 branches: {m['farm_states']} farm, {m['ranch_states']} ranch and "
                   f"{m['beach_states']} beach states, not {sum(c['farm_states'] for c in cr)} / "
                   f"{sum(c['ranch_states'] for c in cr)} / {sum(c['beach_states'] for c in cr)}: branches from "
                   "different crowns grow into each other.", 12.5, MUTED)
    return s


def d_pier(F):
    R, sets = F["raw"], F["sets"]
    m = R["merged"]
    h, hs = sets.get("sunny-horse"), sets.get("sunny-horse-sparrows")
    steps = [(R["combos_total"], "ways to play the route", "menu rhythm × house turn × crossroads turn × beach timing"),
             (m["ready_plays"], "different plays at the beach", "identical game states merge on the way"),
             (m["variants"], "arrivals at READY", "a dog line, reached at one timing"),
             (m["lines"], "dog lines", "the same branch a few frames later is one line"),
             (h["families"] if h else None, "shapes to tell apart",
              f"sister lines that become the same dog (sparrow mornings: {hs['families'] if hs else '?'})")]
    s = Svg(960, 490, "The pier moment: group the branches by shape",
            "Most branches are copies of another branch, started a few frames later. Keep one of each shape.",
            f"{R['label']}: every count is from the lab's run (zz_lines.json, dw families).")
    x0, y = 40, 108
    mx = math.log10(steps[0][0])
    for i, (n, what, why) in enumerate(steps):
        if n is None:
            continue
        wbar = 40 + 520 * math.log10(max(n, 1)) / mx
        col = [BARK, BARK, CYAN, CYAN, GREEN][i]
        s.rect(x0, y, wbar, 40, fill=col, r=6, opacity=0.25 + 0.15 * i)
        s.text(x0 + 12, y + 26, fmt(n), 19, INK, weight="bold")
        s.text(x0 + wbar + 14, y + 17, what, 14, INK, weight="bold")
        s.text(x0 + wbar + 14, y + 34, why, 12, MUTED)
        if i:
            pn = steps[i - 1][0]
            s.text(x0, y - 7, f"−{100 * (1 - n / pn):.1f}%" if n / pn > 0.01 else
                   f"1 in {fmt(round(pn / n))} kept", 11.5, PINK)
        y += 64
    s.text(x0, y + 10, "Bars are on a log scale.", 11.5, FAINT)
    # copies illustration
    vis = F["sets"]["sunny-no-horse"]["L1"]["vis"]
    bx, by = 760, 418
    for j, off in enumerate([0, 18, 36, 54]):
        mp = lambda t, sd, o=off: (bx + j * 34 + sd * 14, by - (t - 4) * 0.13 - o * 0.9)
        dog_branch(s, vis, mp, 1700, 1.0, CYAN, 1.6, glow=False, opacity=0.95 if j == 0 else 0.45)
    s.text(bx + 50, by + 22, "one line, started 0 / 9 / 18 / 27", 12, MUTED, "middle")
    s.text(bx + 50, by + 38, "frames later: keep one", 12, MUTED, "middle")
    return s


def _seconds_axis(s, x0, x1, y, t_end, vi_ms, step=5, label="seconds after Jack stops (READY)"):
    s.line(x0, y, x1, y, GRID, 1.2)
    sec_end = t_end * vi_ms / 1000
    k = 0
    while k <= sec_end + 1e-9:
        x = x0 + (x1 - x0) * k / sec_end
        s.line(x, y, x, y + 5, GRID, 1.2)
        s.text(x, y + 19, f"{k:g}", 11.5, MUTED, "middle")
        k += step
    s.text((x0 + x1) / 2, y + 36, label, 12, FAINT, "middle")


def d_leaves(F):
    st = F["sets"]["sunny-no-horse"]
    L1 = st["L1"]
    vi_ms = F["vi_ms"]
    t_end = 2400
    s = Svg(960, 450, "The leaves: when to cast",
            f"L1 of Sunny → No horse ({L1['share'] * 100:.0f}% of plays). Each leaf is a cast frame that lands "
            "the Power Nut.",
            f"Lab: every cast frame from READY on this line ({fmt(L1['casts_tested'] or 0)} casts), each fished to every bite; "
            "leaf colours as in the app.")
    x0, x1, ym = 60, 920, 270
    mp = lambda t, sd: (x0 + (x1 - x0) * t / t_end, ym + sd * 46)
    pts, _ = dog_branch(s, L1["vis"], mp, t_end, 1.0, BARK, 3.2, glow=False)
    counts = {}
    for col in ("gold", "green", "purple"):
        ts = [t for t in L1["leaves"][col] if t <= t_end]
        counts[col] = len(ts)
        for i, t in enumerate(ts):
            x, y = mp(t, at_time(pts, t))
            up = -1 if (i % 2) else 1
            s.line(x, y, x + 5, y - up * 13, BARK, 1)
            leaf(s, x + 5, y - up * 16, LEAF[col], 5.2, -35 if up > 0 else 35)
    _seconds_axis(s, x0, x1, 360, t_end, vi_ms)
    lx = 60
    for col, nm in (("green", "Nut on bite 1"), ("gold", "Nut on bite 2 (hold bite 1)"), ("purple", "bite 3 or later")):
        leaf(s, lx + 6, 96, LEAF[col], 6, -30)
        s.text(lx + 18, 101, f"{nm}: {counts[col]}", 13, INK)
        lx += 280
    g1 = L1["leaves"]["green"][0]
    x, y = mp(g1, at_time(pts, g1))
    s.rect(60, 126, 380, 52, fill=PANEL, stroke=GRID, sw=1, r=8)
    s.lines(72, 146, [f"Cast {g1 * vi_ms / 1000:.2f} s after READY, let go at bite 1: the Nut.",
                      "One game frame earlier or later: no Nut on bite 1."], 12.5, MUTED, gap=17)
    arrow(s, 200, 178, x + 3, y - 22, GREEN, 1.4)
    s.rect(520, 126, 400, 52, fill=PANEL, stroke=GRID, sw=1, r=8)
    s.lines(532, 146, ["Casting changes the sunlight: the line in the water draws", "numbers of its own. You cast to intercept a leaf."],
            12.5, MUTED, gap=17)
    return s


def d_describe(F):
    st = F["sets"]["sunny-no-horse"]
    nar = st["narrowing"]
    L1 = st["L1"]
    vi_ms = F["vi_ms"]
    s = Svg(960, 470, "Describing your dog = describing the shape of your branch",
            "What the dog does in its first seconds is the shape of its line. A few moves rule out almost everything.",
            f"Sunny → No horse, {st['lines']} dog lines. A shape = the order of what the dog does (facing and animation), "
            "timing ignored. Share = route weight.")
    x0, y0, w, hh = 50, 92, 196, 300
    for i, n in enumerate([1, 2, 3, 4]):
        r = nar[n - 1]
        one = r["lines_with_L1_shape"] == 1
        x = x0 + i * (w + 22)
        s.rect(x, y0, w, hh, fill=PANEL, stroke=GREEN if one else GRID, sw=1.2, r=10)
        s.text(x + w / 2, y0 + 26, f"after {n} move{'s' if n > 1 else ''}", 14, INK, "middle", "bold")
        s.text(x + w / 2, y0 + 66, fmt(r["lines_with_L1_shape"]), 34, GREEN if one else CYAN, "middle", "bold")
        s.text(x + w / 2, y0 + 88, "line fits: L1" if one else "lines still fit", 13, MUTED, "middle")
        s.text(x + w / 2, y0 + 110, f"{r['L1_shape_share'] * 100:.0f}% of plays look like this", 12.5, MUTED, "middle")
        vis = L1["vis"][:n]
        tn = vis[-1][1]
        mp = lambda t, sd, xx=x, tn=tn: (xx + w / 2 + sd * 34, y0 + hh - 24 - (t - 4) * (150 / max(1, tn)))
        dog_branch(s, vis, mp, tn, 1.0, GREEN if one else CYAN, 2.6)
        s.text(x + w / 2, y0 + hh - 8, f"first {tn * vi_ms / 1000:.1f} s", 11, FAINT, "middle")
        if i < 3:
            arrow(s, x + w + 3, y0 + 150, x + w + 19, y0 + 150, MUTED, 1.4)
    s.text(50, 420, "The tool weighs each line by how well it fits your keys and keeps the rest in play, so one wrong key "
                    "does not lose your dog.", 12.5, MUTED)
    return s


def d_tuner(F):
    st = F["sets"]["sunny-no-horse"]
    L1 = st["L1"]
    vi_ms = F["vi_ms"]
    k, big = 8, 6                                                   # VIs = 4 game frames; gap drawn 6x larger
    t_end = 700
    s = Svg(960, 530, "The tuner: same branch, different height",
            "Knowing the branch is not enough: your N64 may be a few frames ahead of or behind the tables.",
            f"Branch: L1 of Sunny → No horse, first {t_end * vi_ms / 1000:.0f} s. Example offset {k // 2} game frames "
            f"({k * vi_ms:.0f} ms), drawn {big}× larger. The tables hold each line at about 10 such timings.")
    ytop, ybot = 168, 470
    sc = (ybot - ytop) / t_end
    shift = k * sc * big
    s.text(24, 92, "[ and ] move the app's branch one game frame. When your dog turns at the same moment as the card, "
                   "the leaves line up with your N64 too.", 12.5, MUTED)
    cols = [(180, "the tables (app)", CYAN, 0), (420, "your N64", GOLD, shift), (740, "after tuning: ] × 4", GREEN, shift)]
    got = {}
    for x, name, col, off in cols:
        mp = lambda t, sd, xx=x, o=off: (xx + sd * 70, ybot - (t - 4) * sc - o)
        if x == 740:
            dog_branch(s, L1["vis"], mp, t_end, 1.0, GOLD, 6, glow=False, opacity=0.35)
        pts, xy = dog_branch(s, L1["vis"], mp, t_end, 1.0, col, 2.4)
        got[x] = xy
        s.text(x, 126, name, 14, INK, "middle", "bold")
        for t in L1["leaves"]["green"] + L1["leaves"]["gold"]:
            if t > t_end:
                continue
            xx, yy = mp(t, at_time(pts, t))
            leaf(s, xx + 7, yy - 3, GREEN if t in L1["leaves"]["green"] else GOLD, 4.4, -30)
    for (xa, ya), (xb, yb) in list(zip(got[180], got[420]))[1:10]:
        s.line(xa + 6, ya, xb - 6, yb, FAINT, 0.9, dash="3 4")
    s.line(300, ybot + 2, 300, ybot + 2 - shift, PINK, 2.4)
    s.text(308, ybot - shift / 2 + 6, f"{k // 2} frames", 12.5, PINK)
    arrow(s, 545, 310, 625, 310, MUTED, 1.6)
    s.text(585, 298, "tune", 13, MUTED, "middle")
    return s


def d_punnet(F):
    sets, pend = F["sets"], F.get("pending", {})
    tw = {(t["a"], t["b"]): t for t in F.get("twins", [])}
    vi_ms = F["vi_ms"]
    s = Svg(960, 600, "L1 across game files",
            "The most common dog line (L1) of each game file, 0–40 s after READY. Sunny is drawn; rainy waits for its tables.",
            "Married and baby rows come later. Twin check: the same order of dog moves and the same leaves, at a fixed offset.")
    s.defn("hatch", f'<pattern id="hatch" width="10" height="10" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">'
                    f'<line x1="0" y1="0" x2="0" y2="10" stroke="{GRID}" stroke-width="3"/></pattern>')
    gx, gy, cw, ch = 140, 116, 396, 200
    cols = [("no horse", False), ("horse", True)]
    rows = [("sunny", "Sunny"), ("rainy", "Rainy")]
    for j, (cn, horse) in enumerate(cols):
        x = gx + j * (cw + 14) + cw / 2
        horseshoe(s, x - 44, 92, 0.9, crossed=not horse)
        s.text(x - 26, 102, cn.capitalize(), 15, INK, weight="bold")
    for i, (rid, rn) in enumerate(rows):
        y = gy + i * (ch + 14)
        (sun if rid == "sunny" else rain)(s, 70, y + ch / 2 - 14, *((11,) if rid == "sunny" else ()))
        s.text(70, y + ch / 2 + 26, rn, 15, INK, "middle", "bold")
        for j, (cn, horse) in enumerate(cols):
            x = gx + j * (cw + 14)
            sid = f"{rid}-{'horse' if horse else 'no-horse'}"
            st = sets.get(sid)
            if not st:
                s.rect(x, y, cw, ch, fill="url(#hatch)", stroke=GRID, sw=1.2, r=10, dash="6 5")
                s.rect(x + cw / 2 - 150, y + ch / 2 - 30, 300, 56, fill=BG, r=8, opacity=0.92)
                s.text(x + cw / 2, y + ch / 2 - 6, pend.get(sid, sid), 15, MUTED, "middle", "bold")
                s.text(x + cw / 2, y + ch / 2 + 16, "rain lab running — L1 goes here", 12.5, FAINT, "middle")
                continue
            s.rect(x, y, cw, ch, fill=PANEL, stroke=GRID, sw=1.2, r=10)
            L1 = st["L1"]
            t_end = 2400
            mp = lambda t, sd, xx=x, yy0=y: (xx + 16 + (cw - 32) * t / t_end, yy0 + 130 + sd * 24)
            pts, _ = dog_branch(s, L1["vis"], mp, t_end, 1.0, BARK, 2.0, glow=False)
            for col in ("gold", "green", "purple"):
                for t in L1["leaves"][col]:
                    if t <= t_end:
                        xx, yy = mp(t, at_time(pts, t))
                        leaf(s, xx + 2, yy - 8, LEAF[col], 3.8, -40)
            s.text(x + 14, y + 26, f"L1: {L1['share'] * 100:.1f}% of plays", 14, INK, weight="bold")
            s.text(x + 14, y + 46, f"{st['lines']} dog lines · {st['families']} shapes · "
                                   f"{len(L1['leaves']['green'])} green / {len(L1['leaves']['gold'])} gold / "
                                   f"{len(L1['leaves']['purple'])} purple", 12, MUTED)
            t = tw.get(("sunny-no-horse", sid)) if horse else None
            if t and t["leaves_agree"]:
                s.text(x + 14, y + 68, f"the same branch as no horse, every leaf {abs(t['vi']) // 2} game frames "
                                       f"{'earlier' if t['vi'] < 0 else 'later'}", 12.5, CYAN)
    S = {x["label"]: x for x in F["sunlight"]}
    sn, rn_ = S.get("Sunny, no horse"), S.get("Rainy, no horse")
    if sn and rn_:
        s.text(gx, gy + 2 * ch + 46, f"Rain on the way: READY at draw {fmt(rn_['points'][-1]['draw'])} instead of "
                                     f"{fmt(sn['points'][-1]['draw'])}, so rainy L1s will be other, more jagged branches.",
               12.5, MUTED)
    return s


def d_merge(F):
    R = F["raw"]
    bt = R["backtrace_top_line"]
    vi_ms = F["vi_ms"]
    s = Svg(960, 470, "Why branches merge",
            "1 + 2 = 3 and 2 + 1 = 3: different ways in, one answer. From then on, one branch.",
            f"Real merges ({R['label']}): plays from three menu timings reaching L1, each at its most common moment on L1's path.")
    # left: sums
    g = Lcg(3)
    exprs = ["1 + 2", "2 + 1", "(4 − 1) × 1", "6 ÷ 2", "… any of endless ways"]
    tx, ty = 330, 250
    for i, e in enumerate(exprs):
        y = 112 + i * 62
        x = 40
        chip(s, x, y, e, MUTED if i == 4 else INK, size=14)
        s.poly([(x + len(e) * 8 + 20, y - 5), (x + len(e) * 8 + 90 + g.u() * 20, (y + ty) / 2), (tx - 22, ty - 5)],
               BARK, 2, opacity=0.9)
    s.circle(tx, ty - 6, 22, fill=PANEL, stroke=GREEN, w=2)
    s.text(tx, ty + 2, "3", 22, GREEN, "middle", "bold")
    s.lines(40, 430, ["Different routes, one game state: no need to keep them apart."], 12.5, MUTED)
    # right: L1 reached from different menu timings at different moments
    pick = [c for c in bt["from_crowns"] if c.get("k_off_mode") is not None]
    seen, ex = set(), []
    for c in sorted(pick, key=lambda c: c["k_off_mode"]):
        if c["k_off_mode"] not in seen:
            seen.add(c["k_off_mode"])
            ex.append(c)
    ex = ex[:3]
    x_tr, y_bot, y_top = 860, 420, 100
    kmax = max(c["k_off_mode"] for c in ex) or 1
    ymap = lambda k: y_bot - 70 - (y_bot - 70 - y_top - 40) * k / kmax
    s.poly([(x_tr, y_bot - 40), (x_tr, y_top)], CYAN, 4)
    s.text(x_tr, y_top - 12, "L1", 15, CYAN, "middle", "bold")
    s.text(x_tr + 12, y_bot - 30, "L1's path", 12, MUTED)
    s.text(x_tr + 12, y_bot - 16, "(time ↑)", 11.5, FAINT)
    for i, c in enumerate(ex):
        late = (c["house_vi"] - R["band"]["house_ref"]) // 2
        yj = ymap(c["k_off_mode"])
        x0 = 470 + i * 120
        y0 = y_bot - 8
        pts = [(x0, y0)]
        n = 7
        for j in range(1, n):
            f = j / n
            pts.append((x0 + (x_tr - x0) * f, y0 + (yj - y0) * f + (8 if j % 2 else -8)))
        pts.append((x_tr, yj))
        col = [GOLD, PINK, GREEN][i]
        s.poly(pts, col, 2.4)
        s.circle(x_tr, yj, 5, fill=col)
        s.text(x0, y0 + 20, f"menus {late} frame{'' if late == 1 else 's'} late", 12.5, col, "middle")
        s.text(x_tr - 12, yj - 8, f"joins at +{c['k_off_mode'] // 2} frames", 12, INK, "end")
    s.rect(440, 96, 300, 66, fill=PANEL, stroke=GRID, sw=1, r=8)
    s.lines(452, 116, ["Same random number + same dog =", "the same branch, entered at different", "moments. One line, many timings."],
            12.5, MUTED, gap=17)
    return s


def d_steady(F):
    R = F["raw"]
    of = R["one_future"]
    A, B = of["a"], of["b"]
    sl = {p["at"]: p["vi"] for p in F["sunlight"][0]["points"]}
    s = Svg(960, 560, "One future: when the sunlight stops changing",
            "From the moment the dog wakes until you cast, nothing you do touches the numbers. Then (x, y) decides everything.",
            f"{R['label']}, L1: two real plays (A: first step {A['W']} VIs late, early pier cut; B: on time, later cut); their gap drawn "
            "6× larger. Clock: 1 draw per game frame (lab probe).")
    # the sunlight strip: set by you until the dog wakes, steady until the cast
    x0, x1, y0, hh = 40, 920, 92, 30
    cast = sl["READY"] + 600
    span = cast + 300 - sl["house"]
    X = lambda vi: x0 + (x1 - x0) * (vi - sl["house"]) / span
    s.defn("hatchsun", f'<pattern id="hatchsun" width="8" height="8" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">'
                       f'<line x1="0" y1="0" x2="0" y2="8" stroke="{SKY}" stroke-width="3" opacity="0.55"/></pattern>')
    g = Lcg(9)
    marks = [("house", "house"), ("farm", "farm"), ("crossroads", "crossroads"), ("ranch", "ranch"), ("beach", "beach")]
    for i, (k, nm) in enumerate(marks):
        xa, xb = X(sl[k]), X(sl[marks[i + 1][0]] if i + 1 < len(marks) else sl["dog wakes"])
        s.rect(xa, y0, xb - xa - 2, hh, fill="url(#hatchsun)", r=3, opacity=0.5 + 0.5 * g.u())
        s.text((xa + xb) / 2, y0 + hh + 16, nm, 11.5, MUTED, "middle")
    xw, xr, xc = X(sl["dog wakes"]), X(sl["READY"]), X(cast)
    s.rect(xw, y0, xc - xw, hh, fill=SKY, r=3, opacity=0.55)
    s.rect(xc + 2, y0, x1 - xc - 2, hh, fill="url(#hatchsun)", r=3, opacity=0.9)
    s.text((X(sl["house"]) + xw) / 2, y0 - 8, "sunlight set by you: when each screen loads, when the dog wakes", 12, INK, "middle")
    s.text((xw + xc) / 2, y0 - 8, "steady: 1 draw a frame + the dog's own", 12, INK, "middle")
    s.text((xc + x1) / 2, y0 - 8, "fishing", 12, INK, "middle")
    for xx, lab, anc in ((xw, "the dog wakes", "end"), (xr, "READY", "start"), (xc, "you cast", "middle")):
        s.line(xx, y0 - 2, xx, y0 + hh + 24, GOLD if lab == "READY" else INK, 1.6)
        s.text(xx + (-4 if anc == "end" else 4 if anc == "start" else 0), y0 + hh + 36, lab, 11.5,
               GOLD if lab == "READY" else INK, anc, "bold")
    # the branch with A's and B's stops
    t_end = 700
    bx, ybot, ytop = 130, 500, 196
    sc = (ybot - ytop) / t_end
    mp = lambda t, sd: (bx + sd * 60, ybot - (t - 4) * sc)
    pts, _ = dog_branch(s, F["sets"]["sunny-horse"]["L1"]["vis"] if "sunny-horse" in F["sets"] else
                        F["sets"]["sunny-no-horse"]["L1"]["vis"], mp, t_end, 1.0, CYAN, 2.6)
    ta, tb = 30, 30 + B["k_off"] * 6                                  # drawn 6x apart so the gap shows
    for t, who, col in ((ta, "A stops", GREEN), (tb, "B stops", GOLD)):
        xx, yy = mp(t, at_time(pts, t))
        s.circle(xx, yy, 6, fill=col)
        s.text(xx + 12, yy + 4, who, 13, col, weight="bold")
    xa_, ya_ = mp(ta, at_time(pts, ta))
    xb_, yb_ = mp(tb, at_time(pts, tb))
    s.text(bx - 92, ytop + 10, "L1", 15, CYAN, "middle", "bold")
    s.text(xb_ + 12, yb_ + 20, f"{B['k_off'] // 2} frames later, same branch", 11.5, MUTED)
    s.text(xa_ + 12, ya_ + 20, f"draw {fmt(A['ready_draw'])}", 11.5, MUTED)
    s.text(xb_ + 12, yb_ - 12, f"draw {fmt(B['ready_draw'])}", 11.5, MUTED)
    # (x, y) and its one future
    bx2 = 330
    s.rect(bx2, 196, 600, 152, fill=PANEL, stroke=GREEN, sw=1.2, r=10)
    s.text(bx2 + 16, 222, f"Where A stops:  x = {fmt(A['x_ready'])}", 15, INK, weight="bold")
    s.text(bx2 + 16, 241, f"(draw {fmt(A['ready_draw'])} since power-on)", 12, MUTED)
    dogs = of.get("dog_first") or []
    seq = " → ".join(str(d[3]) for d in dogs[:6])
    s.text(bx2 + 16, 268, "y = the dog: its action, its facing, and a timer that counts down", 13, INK)
    s.text(bx2 + 16, 286, f"(L1 starts: action {dogs[0][1]}, facing {dogs[0][2]}, timer {seq} …)" if dogs else "", 12, MUTED)
    s.text(bx2 + 16, 314, "Next frame: x × 1103515245 + 12345 for the game's clock, and again for each draw the dog's", 12.5, MUTED)
    s.text(bx2 + 16, 332, "state calls for; the dog's next state follows from its state and x. Nothing else goes in.", 12.5, MUTED)
    s.rect(bx2, 362, 600, 62, fill=PANEL, stroke=GRID, sw=1, r=10)
    s.lines(bx2 + 16, 386, [f"So (x, y) has one future. B walked through A's exact (x, y) {B['k_off'] // 2} frames before it stopped:",
                            "from there on they are one branch. Every copy of a shape is the same causal future."], 13, INK, gap=18)
    s.rect(bx2, 436, 600, 48, fill=BG, stroke=CYAN, sw=1.2, r=10)
    arrow(s, bx2 + 18, 460, bx2 + 50, 460, CYAN, 1.8)
    s.text(bx2 + 60, 465, "Your N64 is on that branch too — maybe a few frames higher or lower. That is the tuner's job.", 13, INK)
    return s


def _mini_branch(s, L1, x, y, w, h, t_end=2400):
    mp = lambda t, sd: (x + w * t / t_end, y + sd * h)
    pts, _ = dog_branch(s, L1["vis"], mp, t_end, 1.0, BARK, 1.3, glow=False)
    for col in ("gold", "green", "purple"):
        for t in L1["leaves"][col]:
            if t <= t_end:
                xx, yy = mp(t, at_time(pts, t))
                s.circle(xx, yy - 3, 1.6, fill=LEAF[col])


def d_cubes(F):
    sets, pend = F["sets"], F.get("pending", {})
    tw = {(t["a"], t["b"]): t for t in F.get("twins", [])}
    s = Svg(960, 600, "L1 across game files: two cubes",
            "One cube per weather. Its three axes: the horse, a marriage, a baby — 8 game files per cube, 16 in all.",
            "Each corner = one game file's tables; a filled corner shows its L1 (the most common dog line), 0–40 s after READY.")
    side, dx, dy, cw, ch = 190, 108, -78, 106, 54
    H = {"h": "horse", "m": "married", "b": "a baby"}

    def corner_id(weather, h, m, b):
        return f"{weather}-{'horse' if h else 'no-horse'}" + ("-married" if m else "") + ("-baby" if b else "")

    for ci, (weather, wname) in enumerate((("sunny", "Sunny"), ("rainy", "Rainy"))):
        ox, oy = 92 + ci * 460, 470
        P = lambda h, m, b: (ox + h * side + b * dx, oy - m * side + b * dy)
        (sun if weather == "sunny" else rain)(s, ox + 18, 108, *((11,) if weather == "sunny" else ()))
        s.text(ox + 48, 114, wname, 17, INK, weight="bold")
        # edges (the back-bottom-left corner is hidden: its three edges dashed)
        for (h, m, b) in [(h, m, b) for h in (0, 1) for m in (0, 1) for b in (0, 1)]:
            for (h2, m2, b2) in ((h + 1, m, b), (h, m + 1, b), (h, m, b + 1)):
                if h2 > 1 or m2 > 1 or b2 > 1:
                    continue
                hidden = (h, m, b) == (0, 0, 1) or (h2, m2, b2) == (0, 0, 1)
                x1, y1 = P(h, m, b)
                x2, y2 = P(h2, m2, b2)
                s.line(x1, y1, x2, y2, FAINT if hidden else MUTED, 1.4, dash="4 5" if hidden else None)
        # axis names
        xa, ya = P(0, 0, 0)
        xb, yb = P(1, 0, 0)
        s.text((xa + xb) / 2, ya + 48, "no horse  →  horse", 12.5, MUTED, "middle")
        s.add(f'<text x="{xa - 62:.1f}" y="{ya - side / 2:.1f}" font-size="12.5" fill="{MUTED}" text-anchor="middle" '
              f'transform="rotate(-90 {xa - 62:.1f} {ya - side / 2:.1f})">single  →  married</text>')
        xc, yc = P(1, 0, 1)
        lx_, ly_ = (xb + xc) / 2 + 74, (yb + yc) / 2 + 34
        s.add(f'<text x="{lx_:.1f}" y="{ly_:.1f}" font-size="12.5" fill="{MUTED}" text-anchor="middle" '
              f'transform="rotate({math.degrees(math.atan2(dy, dx)):.1f} {lx_:.1f} {ly_:.1f})">no baby → baby</text>')
        # corners: back ones first so the front cards sit on top
        order = sorted([(h, m, b) for h in (0, 1) for m in (0, 1) for b in (0, 1)], key=lambda v: (-v[2], v[1], v[0]))
        for (h, m, b) in order:
            x, y = P(h, m, b)
            sid = corner_id(weather, h, m, b)
            st = sets.get(sid)
            x0, y0 = x - cw / 2, y - ch / 2
            if st:
                s.rect(x0, y0, cw, ch, fill=PANEL, stroke=GREEN, sw=1.3, r=7)
                _mini_branch(s, st["L1"], x0 + 8, y0 + 38, cw - 16, 6)
                s.text(x0 + cw - 7, y0 + 14, f"L1 {st['L1']['share'] * 100:.0f}%", 11.5, INK, "end", "bold")
            elif sid in pend:
                s.rect(x0, y0, cw, ch, fill=BG, stroke="#c9873a", sw=1.2, r=7, dash="4 3")
                s.text(x + 0, y0 + 36, "rain lab running", 10.5, "#f0b35a", "middle")
            else:
                s.rect(x0, y0, cw, ch, fill=BG, stroke=GRID, sw=1.1, r=7, dash="3 4")
                s.text(x + 0, y0 + 36, "later", 10.5, FAINT, "middle")
            for i, (key, on) in enumerate((("H", h), ("M", m), ("B", b))):
                cx = x0 + 8 + i * 15
                s.rect(cx, y0 + 5, 12, 12, fill=(CYAN if on else BG), stroke=(CYAN if on else GRID), sw=1, r=3,
                       opacity=1 if on else 0.9)
                s.text(cx + 6, y0 + 14.5, key, 9, BG if on else FAINT, "middle", "bold")
    t = tw.get(("sunny-no-horse", "sunny-horse"))
    note = (f"Sunny: the two filled corners share one L1, {abs(t['vi']) // 2} game frames apart. " if t and t["leaves_agree"] else "")
    s.text(24, 552, "H = horse · M = married · B = a baby (lit = yes).  Green = tables ready · orange = rain lab running · "
                    "grey = later.", 12, MUTED)
    s.text(24, 570, note + "Each corner is a game file of its own: its own tables, its own dog lines.", 12, MUTED)
    return s


DIAGRAMS = {
    "canopy": ("forest_1_canopy.svg", d_canopy),
    "backwards": ("forest_2_backwards.svg", d_backwards),
    "merge": ("forest_2b_merge.svg", d_merge),
    "crown": ("forest_3_crown7.svg", d_crown),
    "sunlight": ("forest_4_sunlight.svg", d_sunlight),
    "three": ("forest_5_three_crowns.svg", d_three),
    "pier": ("forest_6_pier.svg", d_pier),
    "steady": ("forest_6b_one_future.svg", d_steady),
    "leaves": ("forest_7_leaves.svg", d_leaves),
    "describe": ("forest_8_describe.svg", d_describe),
    "tuner": ("forest_9_tuner.svg", d_tuner),
    "cubes": ("forest_10_cubes.svg", d_cubes),
}
EXTRA = {                                                    # drawn only with --only (not in the README today)
    "punnet": ("forest_10_punnet.svg", d_punnet),
}


def build(facts, out: Path, only=None):
    out.mkdir(parents=True, exist_ok=True)
    done = []
    for key, (fn, f) in {**DIAGRAMS, **EXTRA}.items():
        if (only and key not in only) or (not only and key in EXTRA):
            continue
        (out / fn).write_text(f(facts).render())
        done.append(fn)
    return done


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("facts", nargs="?", type=Path)
    ap.add_argument("--out", type=Path, default=Path("media"))
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--list", action="store_true")
    a = ap.parse_args()
    if a.list or not a.facts:
        for k, (fn, f) in {**DIAGRAMS, **EXTRA}.items():
            print(f"{k:10s} {fn}" + ("   (only with --only)" if k in EXTRA else ""))
        return
    facts = json.loads(a.facts.read_text())
    for fn in build(facts, a.out, a.only):
        print("wrote", a.out / fn)


if __name__ == "__main__":
    main()
