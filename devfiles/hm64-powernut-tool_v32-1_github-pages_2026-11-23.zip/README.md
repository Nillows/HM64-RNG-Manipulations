# HM64 Power Nut Tool v32.1

A timing aid for catching the **Power Nut** from the ocean pier in **Harvest Moon 64 (USA, NTSC)** on a real N64.
The site's front page (`index.html`) is a **hub**: pick the morning you play (sunny / rainy) and your game file (horse or
not), and it links to that file's pages, the **Lucky Timer** and the **Casting tables**. Each page is one file that holds
only that game file's tables, runs entirely in your browser, needs no install and sends nothing anywhere (no network
requests). Save a page (right-click its link in the hub → *Save link as…*) and it works offline.

<img src="media/hub.png" width="620" alt="The hub: sunny and rainy mornings, each game file with its pages">

<sub><b>The hub.</b> Ready today: <b>Sunny → No horse</b> and <b>Sunny → Horse</b>. Rainy mornings (horse / no horse) are
being collected; a marriage and a baby come later, each with its own tables. Every page is beach-lineup2: the dog left
in the far south-west corner of the beach; you pick your tables by your game file.</sub>

Every random event in the game comes from one random number generator. The dog's behaviour on the beach is a
readout of where that generator is, and an emulator lab has recorded, for every dog path ("line") and every cast frame
up to 120 s after Jack reaches the end of the pier, every bite and what it catches. The page shows you the dog the lab
expects, lets you line it up with the dog on your TV, and tells you when to press B and when to let go.

---

## Contents
**Only want a stopwatch? Start with [Optimal Blind Casting](#optimal-blind-casting).**

1. [Quick start](#1-quick-start)
2. [Setting up the game file](#2-setting-up-the-game-file)
3. [The route](#3-the-route)
4. [What the app starts with](#4-what-the-app-starts-with)
5. [Layer 1 — the histogram and its cast suggestion](#5-layer-1--the-histogram-and-its-cast-suggestion)
6. [Layer 2 — find your dog and tune it to your N64](#6-layer-2--find-your-dog-and-tune-it-to-your-n64)
7. [Layer 3 — Freestyle: choose your own cast](#7-layer-3--freestyle-choose-your-own-cast)
8. [Ending an attempt, results and reports](#8-ending-an-attempt-results-and-reports)
9. [Practice drills](#9-practice-drills)
10. [Every setting, explained](#10-every-setting-explained)
11. [Keys and feedback](#11-keys-and-feedback)

---

## 1. Quick start
1. Open the hub in a **desktop browser with a keyboard** (Chrome recommended for now) and pick your morning and file,
   e.g. **Sunny → No horse → Lucky Timer**. A page is 24–28 MB and takes a few seconds to load.
2. Make the game file described in section 2 (or get a copy of one).
3. Nothing to set up: the page opens ready (section 4).
4. Play: walk the route (section 3) and **tap Space once the moment Jack stops at the end of the pier**. Click the dog
   card that matches your TV, tune it with **[ ]**, and cast on one of its bars (sections 6–7). Cast and reel on the
   controller; the keyboard is only for the tool.

No tool at all? [Optimal Blind Casting](#optimal-blind-casting) below tells you, from what the dog does in the first 10 s, when to cast.

---

## Optimal Blind Casting
No live tool needed, only a stopwatch and your eyes. Start the stopwatch the moment Jack stops at the end of the pier
(where you would tap Space, section 3.5) and watch the dog for 10 seconds. If it starts one of these, press **B at the
time shown — anywhere within half a second of it** — and let go of B as the line says.

- If you see **wiggle-bum** facing **↙ down-left** at **0.5–2 s**, cast at **62.4 s** for **28%** (1 in 3.6) — let go at the 1st bite · push ↘ at 33 s.
- If you see **flapper** facing **↙ down-left** at **4–6 s**, cast at **62.4 s** for **27%** (1 in 3.7) — let go at the 1st bite · push ↘ at 33 s.
- If you see **flapper** facing **↙ down-left** at **2–4 s**, cast at **22.2 s** for **12%** (1 in 8.3) — let go at the 1st bite.
- If you see **sit** facing **↗ up-right** at **8–10 s**, cast at **22.2 s** for **13%** (1 in 7.9) — let go at the 1st bite.
- If you see **rollover** facing **↙ down-left** at **8–10 s**, cast at **30.2 s** for **12%** (1 in 8.5) — hold the 1st bite, let go at the 2nd.
- If you see **smell** facing **→ right** at **2–4 s**, cast at **61.5 s** for **30%** (1 in 3.3) — let go at the 1st bite · push ↘ at 33 s.
- If you see **shoulder-sitting** facing **→ right** at **6–8 s**, cast at **61.5 s** for **30%** (1 in 3.3) — let go at the 1st bite · push ↘ at 33 s.
- If you see **run** facing **↘ down-right** at **2–4 s**, cast at **12.8 s** for **13%** (1 in 7.6) — hold the 1st bite, let go at the 2nd.
- If you see **walk** facing **↘ down-right** at **4–6 s**, cast at **12.8 s** for **13%** (1 in 7.6) — hold the 1st bite, let go at the 2nd.
- If you see **none of these** by 10 s, cast at **63.0 s** for **8.7%** (1 in 12) — let go at the 1st bite · push ↘ at 33 s.
- Not watching the dog at all: cast at **63.0 s** for **10%** (1 in 9.8) — let go at the 1st bite · push ↘ at 33 s.

**Push ↘ at 33 s:** a cast after 40 s needs one push of the stick **down-right** at about 33 s, or Jack lies down at
40 s (section 3.6). Never push after you have cast. **Hold the 1st bite, let go at the 2nd** = keep B held through the
first bite and let go when the second one comes.

The odds are the share of the lab's arrivals on this route (the file in section 2, no sparrows at the door) that show
the sign and land the Power Nut with B pressed anywhere in that second; 1 in 51 (2%) is the game's base chance per
catch. Emulator data. With **sparrows at the door** (section 3.2) the dog lines are different: use the app's list with the
Sparrows box ticked.

<img src="media/app_blind.png" width="700" alt="The Optimal Blind Casting tab of the Dog reference">

<sub><b>The same list in the app</b>: the first tab of the <b>Casting tables</b> page (hub → Sunny → No horse). Space starts its stopwatch when
Jack stops; click a row and it counts down to that cast. The Harbingers tab has the same signs with a cast aimed to a
fraction of a second.</sub>

---

## 2. Setting up the game file
This is the file for **Sunny → No horse** in the hub. **Sunny → Horse** is the same file with the horse (see below);
other game files get their own tables and their own list there.

The tables work on any morning that starts the game in the same position as the lab's file. If yours doesn't, the
tool's dog lines will not match your game.

**What your file needs:**
- **A sunny morning with no cutscene when you wake up.** Any such day works.
- **No horse yet.** Anything that moves on the route and is not in the lab's file (a horse, farm animals) can draw random
  numbers before the beach and send you down a different path.
- **The fishing rod in Jack's hand** (equipped), not in the rucksack. Without it, B does nothing at the pier.
- **The dog left on the beach, in the far south-west corner** (bottom-left on screen), not carried anywhere on the
  day you play. From the end of the pier it sits at the lower-left edge of the screen.

**How to make it:**
1. The day before: take the dog to the beach, put it down in the farthest south-west (bottom-left) corner, and leave
   it there.
2. Make sure the rod is in Jack's hand and you have no horse.
3. Go home, go to bed and save in the diary, in the **first diary slot** (the lab's file is there; another slot needs
   extra menu presses, which makes you later than the tables).
4. The next morning must be sunny, with no cutscene when you wake up. If it rains, reload the day before and try again.

**With a horse (Sunny → Horse).** The same file and the same route, with two differences. Owning the horse changes the
random numbers at the ranch on the way whether or not you see it, so a file with a horse needs the horse tables, not
the no-horse ones. And the horse must stay out of sight: leave it on the farm far from the house door, where it never
comes on screen while Jack walks from the door to the farm exit (a horse on screen draws more random numbers and can
get in the way). The lab's file has the pony, not yet grown; a grown horse has not been tested.

**Is my file right?** The dog's exact spot matters: the lab found that what counts is which 32-unit tile of the beach
the dog stands on, and a different tile shifts every dog line. You can't see tiles, so use the tool's own
check. After a few attempts in which you tapped Space at a bite (sections 5 and 8), open Setup & review → L5 →
**"Is the app working?"**. If your bite taps keep fitting "no dog line" (shown as **off the tables**), your file, your
menu speed or your route does not match the lab's, and the tool's advice will not apply.

---

## 3. The route
Everything from power-on to the bottom of the beach's back wall decides which dog line you get, and the cut onto
the pier decides when you reach READY, so the route is played **as fast as possible** with the same turns every
time. Small hesitations are expected: the tables cover a range of human timings.

### 3.1 Power-on and menus
Turn the console on and **mash Start, then A**, through the title screen and the diary, to load your file as fast as
you can. The tables cover loading up to **4 game frames (about 0.13 s) later than the fastest possible**.

![Power-on to the house: mash Start, then A](media/menus.gif)

<sub>Power-on to the house at full speed. The badge shows the button being pressed: mash **Start** through the logos and the title, then **A** through the diary.</sub>

### 3.2 Sparrows at the door
As Jack walks out of the house, look at the door: **two sparrows by the door** mean your menus were 5–6 frames late.
That morning has its own table. Tick **Sparrows at the door** on the page (or press **S**) before the pier. No sparrows
by the door: leave it unticked. (Sparrows also appear on some slower mornings that no table covers.)

![The farm door on two mornings: no sparrows (left), two sparrows (right)](media/sparrows.png)

<sub>The same moment on the farm, as Jack steps out of the house, on two mornings. **Left:** menus 0–4 frames late, nothing by the door: leave the box off. **Right:** menus 5–6 frames late, two sparrows by the door (circled): tick **Sparrows at the door** or press **S**.</sub>

![The app with Sparrows at the door off and on](media/app_sparrows.png)

<sub><b>What the box changes in the app.</b> The sparrow mornings have their own table (menus 5–6 frames late, so the whole route runs a little later and the dog lines differ). Same page, same file: with the box off the best cast is <b>20.07 s</b> after READY at <b>11.0 %</b>; ticked (or <b>S</b>), the histogram is redrawn from the sparrow table and the best cast moves to <b>22.06 s</b> at <b>11.5 %</b>. A wrong box means the wrong table, so check the door every attempt.</sub>

### 3.3 General path (one held direction per screen)
- **House:** hold **up-left** through the fade-in, cut **down-left** around the table, then **down** out of the door.
- **Farm:** hold **left** to the exit.
- **Crossroads:** **left**, then cut **down-left**.
- **Ranch:** hold **down-right** to the beach. Keep holding it through the black screen into the beach.

<table>
<tr>
<td valign="top" width="50%"><img src="media/house.gif" width="400" alt=""><br><sub><b>House</b>: hold ↖ up-left while it fades in (Jack can't move for the first few seconds), ↙ down-left around the table, then ↓ down out of the door. You have about <b>4 game frames (0.13 s)</b> of slack here.</sub></td>
<td valign="top" width="50%"><img src="media/farm.gif" width="400" alt=""><br><sub><b>Farm</b>: one held ← left to the exit. Look at the door while it fades in (section 3.2).</sub></td>
</tr>
<tr>
<td valign="top" width="50%"><img src="media/crossroads.gif" width="400" alt=""><br><sub><b>Crossroads</b>: ← left, then ↙ down-left to the ranch. The farm and the crossroads together allow about <b>3 game frames (0.10 s)</b>.</sub></td>
<td valign="top" width="50%"><img src="media/ranch.gif" width="400" alt=""><br><sub><b>Ranch</b>: hold ↘ down-right and keep holding it through the black screen into the beach.</sub></td>
</tr>
</table>

<sub>The badge under each clip shows the stick direction held; it turns orange at each turn. Recorded in an emulator from power-on with the timings the tables were built on.</sub>

### 3.4 The beach: the zigzag
The beach is three legs and two turns. Never stop and never walk straight down.
1. **Down-right** (held from the ranch, through the fade-in). Jack starts moving about a second after the beach
   appears.
2. **First cut, down-left:** the moment Jack clears the **small wall**, on that game frame or the next. This is the
   "tight first turn". Then **hug the back wall** going down-left.
   - Turned a little late (Jack drifts off the wall)? Correct by pressing up a moment and carry on. It costs up to half
     a second, and the tables cover it: those are the **Small fix** and **Big fix** presets (section 5).
3. **Second cut, down-right, onto the pier:** anywhere across the pier's width. Where you cut decides where Jack stops
   at the end: **Early** = near edge, **Middle**, **Late** = far edge. All of them are in the tables.
   - Cut outside the pier's window (too early or too late) and Jack does not make it onto the pier. That attempt is not
     in the tables: restart.
4. **Hold down-right** until Jack stops at the water at the end of the pier. He is now facing the sea, ready to cast.
   This moment is **READY**.

![The beach zigzag to READY](media/beach.gif)

<sub>The beach: keep ↘ through the fade-in, ↙ the moment Jack clears the small wall, slide down the back wall, ↘ onto the pier at the bottom of the wall, and hold it until Jack stops at the water: <b>READY</b>. The tables allow your first step up to <b>half a second</b> late; the cut onto the pier has a window of about <b>a third of a second</b> (11 game frames).</sub>

![The moment the dog wakes](media/dog_wake.png)

<sub><b>The moment the dog wakes.</b> The dog is asleep until the camera, following Jack, comes near it. On this route that happens when Jack reaches the bottom of the back wall, a frame or two before the cut onto the pier (the dog itself is still just off screen, by the pier's legs). Everything up to this moment decides your dog line: your first step, the first cut, and any fix along the wall, so if Jack drifts off the wall, fix it straight away: a fix only counts until here. After it, nothing Jack does changes the dog or the random numbers (checked frame by frame in the emulator); the cut onto the pier only changes when you reach READY, and the tables cover that. (A cut at the very start of the pier window wakes the dog a frame or two sooner; those runs are in the tables too.)</sub>

![Where Jack stops: Early, Middle, Late](media/pier_cuts.png)

<sub>Where the cut onto the pier leaves Jack at the dock end: <b>Early</b> = near (upper) edge, <b>Middle</b>, <b>Late</b> = far (lower) edge, by the dog. All are in the tables; pick yours under <b>2nd cut</b> in the Lucky plan if you know it (section 5), or leave Any.</sub>

### 3.5 Space at the end of the pier (the control)
**Tap Space once, the moment Jack stops at the water.** That one tap starts the tool's stopwatch. Everything after it,
including the dog cards, the cast cue and the bite calls, counts from that tap. The tool allows for your reaction time
and learns your personal delay from your bite taps over time.

![READY at the end of the pier, the dog at the lower left](media/ready.png)

<sub><b>READY</b>: Jack has stopped at the water, facing the sea: tap Space now. The dog (circled) sits at the lower-left edge of the screen, half under the black border. If yours is somewhere else, your file is not set up like the lab's (section 2).</sub>

From here the hands are split: the **controller** casts (B) and reels; the **keyboard** is for the tool (Space taps,
the dog keys).

### 3.6 Stay awake
Jack lies down after **40 s** with no input. A red **WAKE JACK** line crosses the histogram 33.4 s after READY (and
every 33.4 s after that) while you are still waiting to cast. When it reaches the white line, push the stick
**down-right once**. That resets the nap timer and does not change the dog or the bites (measured in the lab). Never
push the stick after you have cast; fishing keeps him awake.

---

## 4. What the app starts with

![The Lucky Timer front page with numbered areas](media/app_front.png)

<sub><b>A fresh browser, nothing changed.</b> ① the histogram (section 5) · ② the lamp with its countdown, the stopwatch, Start and ▶ Preview · ③ the result keys H / M / E · ④ the Sparrows and Freestyle boxes, Freestyle's target menu · ⑤ the picture of Jack, the practice drills, your timing compass and the key list · ⑥ the Lucky plan (presets and the cast time) · ⑦ the dog-watch (section 6) · ⑧ the footer: How it works and ⚙ Settings (from v32 the footer's left end links to the ⌂ Hub and the Casting tables; the picture shows v31's two tabs there). Panels ⑤ ⑥ ⑦ can be dragged into any order by their •••• grip.</sub>

A fresh browser opens the Lucky Timer ready:
- Route **Beach-lineup2 · dog on the beach** (the file in section 2), **Sparrows at the door** off.
- Start: **one Space tap when Jack stops at the end of the pier**. With this start the app offers no taps on the way in
  and hides **Pier only**; both come back only if you choose the fade-in start in Setup & review → L2.
- **Dog-watch on**, **5 dog cards**, the most likely dog **on the right**.
- **Freestyle on**: you choose the cast from your dog's bars (section 7). Switch it off (**Ctrl** or the box) for the
  app's own cast suggestion (section 5).
- Dog-watch animation keys: numpad **0** idle · **1** sit · **2** stand · **4** walk · **5** run · **6** sleep · **7** sniff ·
  **8** bark · **9** shoulder, plus **R** rollover · **F** flapper · **G** good-boy · **O** mess · **B** wiggle-bum.
- Front panels: picture of Jack · Lucky plan · dog-watch (drag the •••• grips to reorder).

Everything can be changed, and the browser remembers your changes. If you opened an earlier build on the same site, its
stored settings win over these defaults; change them by hand, or clear the site's data in the browser to start fresh.

Your settings, practice data and attempt history are stored **in your own browser**, for this site. Nothing is sent
anywhere or shared with other players. Clearing the browser's site data resets the tool.

The page also works offline: save it with your browser (File → Save Page As…) and open the saved file. A saved copy
keeps its own settings, separate from the website's.

The **Lucky Timer** page is the tool. The **Casting tables** page (a link in its footer and in the hub) is the Dog
reference, a printable manual method; its first tab is [Optimal Blind Casting](#optimal-blind-casting) (more in section 10).

---

## 5. Layer 1 — the histogram and its cast suggestion
This is the app's own cast suggestion: the best cast for "any dog this route can produce". It shows while
**Freestyle is off** (it is on by default: press **Ctrl** or untick the box).

**The front page, top to bottom:** the histogram; a slim lamp strip (stopwatch, Start / Stop, result keys, the
Sparrows / Pier only / Freestyle boxes); three panels you can drag into any order by their •••• grip: dog-watch,
Lucky plan, and the picture of Jack with the key list.

**The histogram** scrolls from right to left like a rhythm game:
- The **white line** is *now*.
- The **bold blue CAST line** is when to press B. Press as it crosses the white line. The lamp, the countdown and the
  glow around the screen edge all hit zero at that same moment. If the tool has learned that you press late, the bold
  line sits that much early, and a dashed "ghost" line marks the unaltered moment.
- **Bars** show the chance of a Power Nut for a cast at each moment, coloured by the bite the Nut comes on: **green** =
  let go at the **1st** bite, **gold** = hold through the 1st bite and let go at the **2nd**, **purple** = a later
  bite.


![A preview of a lucky attempt with Freestyle off](media/app_preview.gif)

<sub><b>Freestyle off, ▶ Preview a lucky attempt (P).</b> The app plays the cues of one winning attempt so you can see the rhythm: the bold CAST line meets the white line (press B there and keep holding), the release windows follow on the histogram, bite 1 comes (keep holding B, tap Space as it bites) and bite 2 is the Nut (let go). The ▶▶ parts are sped up. A real attempt starts from your Space tap at READY instead.</sub>

**The Lucky plan panel** shows the route name and **Cast at X after READY**, with − / + / best to move it, and
**Auto ✓ / Back to best** (lit when you moved something by hand: click it to go back to the best plan). It also has two
rows of buttons describing your run, each with its own best cast and odds:
- **Your first step on the beach:** Any / **Clean** (tight first turn, no correction) / **Small fix** (a small correction,
  0.17–0.30 s late) / **Big fix** (a bigger one, 0.33–0.50 s late).
- **2nd cut:** Any / **Early** / **Middle** / **Late** (where Jack stopped across the end of the pier).

Pick what you actually did if you know it, or leave Any. ★ marks the best 2nd cut for that first step. With the
pier-end start the plain suggestion is roughly **20 s after your tap at about 11 %** (shown live in the app; it
depends on the presets).

![Clicking through the presets of the Lucky plan](media/app_presets.gif)

<sub><b>Each pick has its own best cast.</b> Any: <b>20.07 s · 11.0 %</b> → Clean: <b>36.96 s · 12.1 %</b> → Small fix: <b>20.14 s · 11.3 %</b> → Big fix: <b>36.77 s · 11.5 %</b>; with Clean, the 2nd cut: Early <b>37.01 s · 12.9 %</b>, Middle ★ <b>36.91 s · 13.1 %</b>, Late <b>36.79 s · 12.7 %</b>. The histogram is redrawn for every pick. If you are not sure how your run went, leave Any: it covers every timing in the tables.</sub>

**After the cast** the lamp reads the bites for you:
- **RELEASE** (e.g. **BITE 1 = NUT: RELEASE**, **RELEASE ON A BITE**) = let go of B at this bite.
- **KEEP HOLDING** / **HOLD · TAP THE BITE** / **HOLD → BITE 2** = hold B through this bite and tap Space as it bites.
  From the tap, the tool works out which frames and dog lines fit and forecasts the next bite.
- **DUD — RESET** = no Nut is left on this cast: reset and save the time.
- A **pink release line** shows the best moment to let go without looking (with its chance, "blind x %").

---

## 6. Layer 2 — find your dog and tune it to your N64
Once you have tapped Space at the end of the pier, the **dog-watch** panel opens with **cards**. Each card plays what
one dog line's dog is doing *right now*, with its share of the likelihood (e.g. "17 % L5 +3").
- "**+3**" means three "sister" lines have become the very same dog by now; they are shown on one card.

![Finding your dog: the TV and the app side by side](media/app_dogwatch.gif)

<sub><b>A real attempt, the TV and the app side by side</b> (the TV is the emulator running the same file and route; the close-up is the dog in the TV's lower-left corner). Space at READY; the cards play five dog lines; one arrow key as the dog turns (optional) and the matching card, L3, rises to the top on the right; click it; five presses of <b>[</b> line it up with the TV (−5 frames); the histogram now shows L3's own Power Nut cast frames.</sub>

**1. Choose your dog.** When a card does what the dog on your TV is doing, **click it**. The other cards disappear and
the panel becomes the **calibration view**: your dog drawn large, with three frames of it underneath (one game frame
earlier, the tuned one, one later). The dog sits on the right by default (left / middle / right in Dog-watch options), so you can put it
nearest your TV.
- Wrong dog? **Backspace** (or click it again) gives you the row back.
- A card that clearly isn't your dog can be thrown out with its **×** (or **Delete** for the top card); Backspace or
  "Undo ×" brings it back.
- Optional, if you can't tell yet: key the dog's facing with the **arrow keys** (two keys = a diagonal) whenever it
  turns, and long animations on their keys (numpad 0 idle, 1 sit, 2 stand, 4 walk, 5 run, 6 sleep, 7 sniff, 8 bark,
  9 shoulder; R rollover, F flapper, G good-boy, O mess, B wiggle-bum). Each key re-weights the lines, so the right card
  rises to the top.

**2. Tune it.** A card plays at the tool's best guess of your timing, so it can run a little early or late. Press
**[** (earlier) and **]** (later) to move it one game frame (33 ms), or **Shift + [ / ]** for 10 frames, until the
large dog turns **exactly** with the dog on your TV. The three small frames show what one frame either way looks like.

<img src="media/app_calibration.png" width="420" alt="The calibration view with numbered parts">

<sub><b>The calibration view.</b> ① your dog, large (it sits on the side the Dog-watch options set: right by default) · ② the same dog one game frame earlier, tuned, and one frame later · ③ how far you moved it (here −5 frames = −167 ms) · ④ [ earlier / later ], zero, Clear my pick (the same as the keys).</sub>

**3. The histogram changes.** With a dog chosen, the histogram stops showing odds for "any dog". It shows **that dog's
own Power Nut cast frames** as bars, at your tuned timing, and the cast suggestion re-aims to the best cast still
ahead, on any bite. In the lab's simulated runs, attempts with the right dog chosen got about 30 % instead of
about 12–13 % with no dog chosen.

**After the cast, the cards stay lit:** the card plays its dog *after* a cast on one particular frame. A card that
stays in step with your dog for more than about 3 s is the frame you landed on. Click it to **lock** that frame
(**[ ]** step it). The lamp then calls the bites exactly from the lab record: **HOLD · NUT IS BITE 2**,
**LET GO AT BITE 1 · NUT**, or **NO NUT ON THIS CAST**. Neighbouring frames show the same dog for 1–3 s after the cast
and then part, so a card parting early just means "not this exact frame".

---

## 7. Layer 3 — Freestyle: choose your own cast
Freestyle is a separate mode for when your dog is chosen and tuned: **you** choose when to cast, from your dog's own
Power Nut frames. No reflex correction is needed, because the dog on screen and the dog on your TV are in step.

**Switch it on and off** with the **Freestyle** box or the **Ctrl** key (changeable). It works before or during an
attempt. Beside the box, pick the target: **Power Nut** (default), or large / medium / small fish.

**What you see** (with a dog chosen; without one the histogram asks you to click your dog):
- **Bars** = your dog's cast frames that catch the target, coloured by bite: **green** = the 1st bite after the cast is
  the catch, **gold** = hold through the 1st bite, the 2nd is the catch.
- **Doubles / triples** (marked **×2** with a band behind them) = two or three neighbouring frames that catch the target
  on the same bite at the same moment. They give you a wider window (67–100 ms instead of 33 ms), so they are the best
  targets.
- The lamp counts down: **NEXT DOUBLE · GREEN · 4.2 s**. For your dog's last double it says **LAST DOUBLE** and pulses
  red from 8 s before (with the glow setting on).
- **Threads:** under the bars is a thin **release lane**. Every bar has a thread from the bar down to the moment its
  catch can be reeled in. Once you pass a bar, its thread's top stays on the white line and the thread swings upright.
  **When it stands straight up, let go of B** (only if you cast on that bar). The lamp says it too: **GREEN THREAD · LET
  GO IN 1.2 s → LET GO NOW**.
- **WAKE JACK** lines keep coming every 33.4 s until you cast (section 3.6).

![Freestyle with the Power Nut target, the large-fish target, and Freestyle off](media/app_targets.png)

<sub><b>The same dog (L3), three views.</b> Top: Freestyle, target <b>Power Nut</b>: only the frames that catch the Nut, doubles marked ×2. Middle: target <b>Large fish</b>: the frames that catch a large fish. Bottom: <b>Freestyle off</b> (Ctrl) with the dog still chosen: KNOWN LINE, the app's own cast moves to the best frame still ahead (here 25.77 s, 31.1 %).</sub>

**How to play it:**
- Watch the countdown, **press B on a bar**, ideally a double.
- **Simplest way, no keyboard needed:** cast in a **green** bar's window and let go at the **first nibble**. For a
  **gold** bar, hold through the first nibble and let go at the second.
- **Optional:** tap **Space as you cast**. The tool takes the nearest double (or group of bars) as the one you went for,
  leaves only that one's thread on screen, shows a pink release line inside its window, and grades the cast in the
  report: **INSIDE**, or **n ms EARLY / LATE**. **Backspace** = "that wasn't my cast". You don't need this; it only helps
  you focus on the release that's left.
- A freestyle attempt with no cast stops by itself at the end of the data (120 s after READY), without logging
  anything.

![A Freestyle cast on a double and the catch, TV and app side by side](media/app_freestyle.gif)

<sub><b>The same attempt, continued.</b> NEXT DOUBLE · GREEN counts down; press B on the ×2 bar (here with a Space tap as you cast, which marks it); hold B while the cast's thread swings up; when it stands upright the lamp says let go: the first nibble is the <b>Power Nut</b>, on the TV too. Then H. In the emulator, casts on the two frames of this double both give the Nut; the frames either side give a small fish.</sub>

For a sense of scale (lab calculation): the best group of bars on a dog line is worth about **29 %** with a press
spread of ±150 ms and about **47 %** at ±60 ms. In other words, steadier hands are worth more than anything else.

---

## 8. Ending an attempt, results and reports
- **H** = caught the Power Nut · **M** = caught a fish / missed · **E** = empty line · **Esc** = stop without logging.
- **Bite taps** (Space at a bite while holding B) are what the tool learns from: your reaction, your clock, which dog
  lines you really land on. They are stored even when you press Esc.
- Setup & review → **L4 · Attempts**: every attempt has a **Report** (the cast moment close up: target, where your press
  landed, the dog line, the locked frame) and **Copy report** for sharing. **Remove** takes a bad attempt out of
  everything the tool learned (**Undo** puts it back). **Export** / **Clear** for the whole log.

<img src="media/app_report.png" width="640" alt="The attempt list and the report of the freestyle attempt">

<sub><b>L4 after the attempt above.</b> One Power Nut in one try; the report shows the target (a double, 67 ms wide), where your Space tap landed (INSIDE, on bar 2 of 2) and what to let go at. <b>Remove</b> takes an attempt out of everything the tool learned.</sub>

---

## 9. Practice drills
Under the picture of Jack:
- **Cast + bite practice:** the whole motion as on the N64. The histogram counts down to CAST, you press Space (or a
  controller button on a USB pad) on the cue and **keep holding**, Jack casts, a bite comes 1.4–5.2 s later, and you
  **let go** the instant the rod dips. The lamp gives both results, e.g. **CAST +42 MS · CAUGHT 231 MS**. These feed your
  press habit and your release reaction.
- **Bite practice:** only the bite. Hold, let go when the rod dips. A bite can be caught for 20 video frames (334 ms):
  CAUGHT / LATE / TOO EARLY.
- **Esc** stops a drill.

![Cast + bite practice](media/app_drill.gif)

<sub><b>Cast + bite practice.</b> Hold Space from the CAST cue, let go when the rod dips. The lamp gives both results: here the press was 43 ms late and the catch took 204 ms.</sub>

---

## 10. Every setting, explained

### Front page
| Control | What it does |
|---|---|
| **Start / Stop**, **▶ Preview a lucky attempt** | Start / stop by mouse (Space starts, Esc stops); Preview plays an attempt's cues with no console. |
| **Power Nut (H) · Fish / missed (M) · Empty line (E)** | Log the result (the same as the keys). |
| **Sparrows at the door** (S) | Use the table for mornings with two sparrows at the house door (section 3.2). |
| **Pier only** (X) | Only shown with the fade-in start: a one-attempt override that makes the next (or last) Space the end-of-pier tap. Hidden (and X does nothing) with the default one-tap start, which already is that tap. |
| **Freestyle** box, **key** button, target menu | Freestyle mode on / off, change its key (default Ctrl), target Power Nut / large / medium / small fish. |
| **Dog-watch** panel: [ earlier · later ] · zero · Clear my pick · Undo × | Tune the dog cards by a frame, back to zero, drop your chosen dog, undo removed cards. |
| **Dog-watch options** → Dogs on screen 3 / 5 / 7 | How many cards (default 5). |
| → most likely dog on the left / in the middle / on the right | Where the top card (and the chosen, large dog) sits (default right). |
| → **Mouseover forecast** (off) | Hover a card to list that dog's next moves with countdowns. |
| → **No missed turns once I start** + late arrows allowed up to … ms | Strict arrow logging: once you start keying, every turn must be keyed (late entries allowed up to the limit). Lines that don't show your sequence drop out. |
| **Lucky plan** panel | See section 5 (presets, Cast at … − + best, Auto ✓ / Back to best, the last attempt in a few lines). |
| **Cast + bite practice**, **Bite practice** | Section 9. |

<table>
<tr>
<td valign="top" width="50%"><img src="media/app_dwopts.png" width="400" alt=""><br><sub><b>Dog-watch options</b>: how many cards (3 / 5 / 7), and where the most likely dog sits. In a 1280-pixel-wide window the 7th card runs past the panel's edge.</sub></td>
<td valign="top" width="50%"><img src="media/app_peek.png" width="400" alt=""><br><sub><b>Mouseover forecast</b> (off by default): hover a card for that dog's next moves, with countdowns at the card's own timing.</sub></td>
</tr>
</table>

### Setup & review (the fold at the bottom)
**L1 · Plan details**
| Setting | What it does |
|---|---|
| **After the cast:** Auto / Smart zones / 1st bite / 2nd bite / 2nd bite + tap | The release rule the plan uses. Auto picks the best. Smart zones: let go of the 1st bite only inside a release window, otherwise hold and tap it. 1st bite / 2nd bite: fixed rules. 2nd bite + tap: always hold through bite 1 and tap it, so the tool can forecast bite 2 or call DUD. |
| **Aim for:** best odds per attempt / fastest Nut | Best chance per attempt, or the best chance per minute (an earlier cast with slightly lower odds). "An attempt costs … s besides the wait" = your reset time, used for the per-minute maths. Ignored while dog-watch is on (the cast stays on best odds). |
| **Personalized cast suggestion (experimental)** | Aims with your own measured timing (B presses, clock taps, how well your offset is known) instead of a plain bell curve. A loose or lopsided timing then prefers wide plateaus over narrow peaks. |
| **P(Nut) overview** | The chance for a cast at each moment with your timing spread. Click it to choose another cast time. |
| **How to do this attempt** | The route and the start in words. |

![The After the cast and Aim for settings and what they do to the plan](media/app_policy.gif)

<sub><b>L1, cause and effect.</b> Auto (= Smart zones here): <b>20.07 s · 11.0 %</b>. 1st bite: the plan changes completely (cast at <b>0.48 s</b>, <b>6.5 %</b>, only green bars). 2nd bite (and 2nd bite + tap): <b>36.92 s · 8.4 %</b>. Aim for fastest Nut: nothing moves while dog-watch is on, as the panel says (the cast stays on best odds).</sub>

**L2 · Start & taps**
| Setting | What it does |
|---|---|
| **Start the stopwatch** | **"when Jack stops at the dock end (READY)"** (default): one Space tap, nothing on the way in. The other option, "when the beach starts to fade in", is a multi-tap start for experienced runners with slightly higher odds (11.6 % vs 11.0 %); choosing it brings back the tap strategies and **Pier only**. |
| **Start key** | Space by default. |

![The two start options in L2](media/app_start.png)

<sub><b>L2, the two starts.</b> Left, the default: one tap at READY, nothing on the way in. Right, the fade-in start: the <b>Pier only</b> box comes back in the lamp row, and L2 gains the tap strategy, the beach cue and the clock-tap settings.</sub>

**L4 · Attempts**: section 8.

**L5 · Your timing**
| Fold | What it does |
|---|---|
| Timing picture | Each dot is something measured about you: left = early, right = late, top = steady, bottom = loose. |
| **Set by hand** | Start-tap delay, cast-cue correction (your B-press habit) and timing spread. Each is learned automatically while its box is ticked; untick one to set it yourself. |
| **Is the app working?** | Your bite taps vs the tables (do they fit a dog line, or are they "off the tables"?), Nuts expected vs caught, where your casts land. |
| **What the app learns, and its limits** | What is learned, from what, and how far it may move. |
| **Your data: clear stats** | Clear any one store (attempt log, bite taps, dog-watch records, clock taps, cast practice, bite practice) or **Clear all stats**. Settings and keys are kept. |
| **Your dog lines** | Which lines your attempts were on, vs how common the lab found them. "Also count what the dog-watch saw" is experimental. |
| **Bite practice**, **Cast practice** | Statistics and options of the drills ("tap instead of hold-and-let-go", "use it as my bite-tap delay", "moving cast line", "full wait", "hold on to the bite and let go", "Copy to my hand-set values", "Forget …"). |

<img src="media/app_L5.png" width="640" alt="L5 Your timing after one attempt">

<sub><b>L5 after one attempt.</b> The timing picture (each dot is something measured about you), the table of what has been learned so far, and the open folds below it.</sub>

### ⚙ Settings → Lucky Timer tab
| Setting | What it does |
|---|---|
| **Route (save / dog spot)** | Which lab table to use: **Beach-lineup2** for the file in section 2. The others are older saves and routes. |
| **Watch the dog at the dock end** | Turns the dog-watch panel (cards) on. |
| **Facing keys** arrow keys / W A S D | Keys for the dog's facing. |
| **Hands on B (stop logging) before the cast (s)** | Dog-watch logging closes this long before the cast (default 2 s). |
| **Dog-watch keys** | Reassign the animation keys (defaults in section 4) and the earlier / later card keys. Keys the tool itself uses are refused. **Reset these keys** returns to the defaults. |
| **Release line** | Show the pink release line (normal mode: best blind release; Freestyle: the middle of your marked cast's window). |
| **Cast tap** + precision | Optional: also tap Space when you press B, so the tool knows your real cast time. |
| **Glow around the screen edge** | The lamp's colour around the whole screen edge, for the corner of your eye. In Freestyle it also covers the LAST DOUBLE pulse. |
| **Facing when casting** SE / E | Only changes the picture of Jack. |
| **Sound too** / … release-window sounds | Beeps with the visual cues (off by default). |
| **Load your own angler frames** / Stick figure | Change the picture of Jack. |

<img src="media/app_settings_lucky.png" width="520" alt="Settings, Lucky Timer tab">

<sub><b>⚙ Settings → Lucky Timer.</b> The route, dog-watch, the key table (every animation with its share of the wait and its key), the release line, cast tap, glow, sound and the picture of Jack.</sub>

### ⚙ Settings → Console & shared timing / Calibration & data tabs
Mostly settings of the older "Dog Oracle" page, which this build no longer shows. Two matter:
- **Console game update (ms; NTSC N64 = 33.430)**: **leave it at 33.430.** If it is changed, the front page shows a red
  warning with a one-click fix.
- **Your tap delay, mean (ms)**: the tool's first guess for your bite-tap delay, until it has learned yours.

<img src="media/app_settings_console.png" width="420" alt="Settings, Console and shared timing tab">

<sub><b>⚙ Settings → Console & shared timing.</b> The game update stays at 33.430 ms.</sub>

![The warning when the console update is changed](media/app_warn.png)

<sub>If it is changed (here to 33.333 ms), the lamp row says so in red; one click puts it back.</sub>

### Casting tables page (the Dog reference)
A manual method for when the live tool is not wanted: what the dog is doing as Jack stops at the end of the pier →
which line you are likely on → how long to wait before casting (best-odds and quick casts per behaviour), the
"harbinger" behaviours that give a line away, and a simple Space stopwatch (Space when Jack stops, Esc to stop; click
a cast time in the tables to count down to it). Tabs: **Optimal Blind Casting** (the list above, first) · **First 10
seconds, by line** · **As you stop** · **Harbingers**. Casts reach 75 s after Jack stops (the Power Nut ends there); a
cast after 40 s says so and needs the push ↘ at about 33 s (a cast after 73 s a second one at about 67 s); the
stopwatch shows PUSH THE STICK ↘ NOW at those moments.
Its own settings: **Table** (Beach-lineup2 for the file in section 2), **Sparrows at the door** (S), **How exact is your
cast?** (±100 / 150 / 200 / 300 ms), **Aim for** best odds or a quick cast of **at least** n %, and **Your reaction when
Jack stops** (ms, taken off your Space tap). **Print the tables** gives a paper copy.

<img src="media/app_dogref.png" width="700" alt="The Casting tables page">

<sub><b>The Casting tables page</b> (the Dog reference, the manual method) on its first tab, Optimal Blind Casting. The picture is from v31, where it was a tab of the one page.</sub>

---

## 11. Keys and feedback

### Keys
| Key | When | Does |
|---|---|---|
| **Space** | at the end of the pier | starts the attempt (the stopwatch) |
| **Space** | after the cast, holding B | marks a bite (the tool forecasts the next one) |
| **Space** | Freestyle, as you cast (optional) | marks your cast |
| **B** (controller) | — | cast, hold, let go. The tool never sees it |
| **Ctrl** | any time | Freestyle on / off (changeable) |
| **S** / **X** | before the pier | sparrows at the door / pier-only override (X: fade-in start only) |
| **Arrows** (or WASD), **Numpad 0–9**, **R F G O B** | dog-watch | dog facing / long animations (section 4) |
| **[ ]**, **Shift + [ ]** | dog chosen | move the dog 1 / 10 game frames |
| **Enter** | after the cast | lock the frame of the card you are tuning |
| **Backspace** | — | undo: the chosen dog, a removed card, the last arrow, a Freestyle cast mark |
| **Delete** | dog-watch | remove the top card |
| **H / M / E / Esc** | — | Nut / fish / empty / stop without logging |

### Feedback that helps
Your browser and system; what you did; what you expected; what happened. **Copy report** from the attempt list
(Setup & review → L4) gives a text block worth pasting, and "Is the app working?" (L5) tells whether your runs fit the
tables at all.
