/* HM64 Dog reference (v31.0, Thomas 2026-11-20) - replaces the Dog Oracle page.
   A manual method that needs no live tool: a reference of what the dog is most likely doing when Jack stops at the pier
   end (and which way it faces), which dog line that means, and how long after stopping to cast - plus a plain stopwatch
   (Space when Jack stops). Nothing here touches the Lucky Timer: it reads the same lab tables through LuckyCore
   (planSet / curve / zoneAt / best, no selection change) and the dog traces of the route (R.dw).

   The model (all from the lab tables in the page):
     - "you stop" = the stopwatch's t = 1 of the route's pier start (READY: Jack stops at the water).
     - a candidate = (dog line, its timing against your stop, weight) = DogWatch.candidates(route, pier plan); what its
       dog shows s seconds after you stop = the line's lab trace at trace VI  s / VI + (ko - mt) + 1.
     - a row's cast = the stopwatch time with the best Nut odds over the candidates of that row, for a B press that is
       off by a bell curve of the chosen spread, under one of three rules:
         1st bite : let go of B at the first bite
         2nd bite : hold through the first bite, let go at the second
         by clock : let go at the first bite only if it comes inside the listed stopwatch windows, else hold and let
                    go at the second (the Lucky Timer's "smart zones", read off the stopwatch by the player)
   Odds are shares of the route-weighted lab arrivals, as everywhere in the app. Not measured on hardware. */
(function (root) {
  'use strict';
  const C = root.HM64Lucky, DW = root.HM64DogWatch, DATA = (typeof HM64_DATA !== 'undefined' && HM64_DATA) || null;
  const $ = id => document.getElementById(id);
  if (!C || !DW || !DATA || !$('refArena')) return;
  const VI = () => (root.HM64LuckyApp && root.HM64LuckyApp.viMs ? root.HM64LuckyApp.viMs()          // v32.0: on its own page (no Lucky Timer)
    : root.HM64Core && root.HM64Core.viMs ? root.HM64Core.viMs() : 16.715);                          // the console frame period setting
  const KEY = 'hm64v31_dogref';
  const DIRN = ['S', 'SW', 'W', 'NW', 'N', 'NE', 'E', 'SE'], ARROW = ['↓', '↙', '←', '↖', '↑', '↗', '→', '↘'];
  const LOOK_VI = 30, MIN_CAST_AFTER_LOOK = 60, HARB_UNTIL = 600, HARB_BIN = 120, SOON = 0.8;
  let S = { route: null, sig: 150, delay: 150, tab: 'blind', quick: 10, aim: 'odds', qv: 0, sparrow: false };
  const RESET_S = 55;                                               // reset + menus, as the Lucky Timer's minutes-per-Nut
  const TABS = [['blind', 'Optimal Blind Casting'], ['lines', 'First 10 seconds, by line'], ['arrive', 'As you stop'], ['harb', 'Harbingers']];   // v31.1: tabs; v31.30: Optimal Blind Casting first
  try { Object.assign(S, JSON.parse(localStorage.getItem(KEY) || '{}')); } catch (e) { /* defaults */ }
  if (S.qv !== 2) { S.quick = 10; S.qv = 2; }                       // v31.10: the floor Thomas asked for ("fastest nut above 10%") is the default
  if (S.bv !== 1) { S.tab = 'blind'; S.bv = 1; }                   // v31.30: everyone lands once on the new Optimal Blind Casting tab
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { /* private mode */ } };
  const nameOf = b => (DATA.names && DATA.names[b]) || (b === 32 ? 'stand' : 'anim ' + b);
  const secs = t => ((t - 1) * VI() / 1000);
  const fx = (v, n) => v.toFixed(n == null ? 1 : n);
  const pct = p => (p == null || !(p >= 0) ? '—' : (100 * p).toFixed(p < 0.0995 ? 1 : 0) + '%');
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  /* ---------------------------------------------------------------- routes with dog traces and a pier start */
  function routes() {
    return C.routes().filter(r => { const R = C.routeOf(r.id); return R && R.dw && (r.anchors || R.anchors || []).some(a => a.id === 'pier'); });
  }
  /* v31.11 (Thomas 2026-11-20 23:05): the sparrow rule of the Lucky Timer here too. The Table list holds the main
     tables only; "Sparrows at the door" (box or key S) switches to that table's sparrow variant (menus 5-6 frames
     late: other dog lines, other casts) and back. */
  const bases = () => routes().filter(r => !r.variant_of);
  const sparOf = id => routes().find(r => r.variant_of === id && r.variant === 'sparrows') || null;
  const curRoute = () => (S.sparrow && sparOf(S.route) ? sparOf(S.route).id : S.route);
  function setSparrow(on) {
    S.sparrow = !!on && !!sparOf(S.route); save();
    const b = $('rfSpar'); if (b) b.checked = S.sparrow;
    refresh();
  }
  function ctx(routeId) {
    const R = C.routeOf(routeId), plan = (C.planSet('all', 'pier', routeId) || [])[0];
    if (!R || !R.dw || !plan) return null;
    const cands = DW.candidates(R, plan, 'all', 'pier');
    /* v31.8: how long an attempt is before Jack stops at the pier end = the fade-in stopwatch's READY time, route mean */
    let lead = 20;
    try { const pf = (C.planSet('all', 'fadein', routeId) || [])[0], v = pf ? pf.variants : [];        // minT: READY, VIs from 1 at the first light
      const wf = v.reduce((a, x) => a + x.w, 0); if (wf > 0) lead = (v.reduce((a, x) => a + x.w * x.minT, 0) / wf - 1) * VI() / 1000; } catch (e) { /* keep 20 s */ }
    return { R, plan, cands, W: cands.reduce((a, c) => a + c.w, 0) || 1, lead };
  }
  function showAt(R, dwi, k) {
    const v = R.dw.lines[dwi].vis;
    let lo = 0, hi = v.length - 1;
    while (lo <= hi) { const m = (lo + hi) >> 1; if (v[m][1] <= k) lo = m + 1; else if (v[m][0] > k) hi = m - 1; else return v[m]; }
    return null;
  }
  const lineName = (R, dwi) => { const li = R.dw.lines[dwi].li; return li >= 0 ? 'L' + (li + 1) : 'no table'; };

  /* ---------------------------------------------------------------- v31.30: casts past 40 s, Optimal Blind Casting
     (Thomas 2026-11-23). The cast tables behind the odds of this page (LuckyCore) end 40 s after Jack stops; the cast
     pack D.dogcast (the Lucky Timer's dog-after-the-cast data) holds every cast frame of every dog line to 120 s with
     its bites, so every aimed cast (0-75 s) and the blind windows are read from there. A plan variant = a dog line + its READY
     offset o: a cast t stopwatch VIs after the stop (t = 1 at the stop) lands on pack label t - 1 + o (as dcBites in
     the Lucky Timer). Odds = shares of the route-weighted arrivals, as everywhere on this page. Checked against an
     independent script on 2026-11-23 (claude/HM64_BLIND_CAST_2026-11-23.md). */
  const DC = DATA.dogcast || null;
  const END_S = 76, WAKE_S = 33.4, NAP_S = 39.4, BLIND_S = 1;
  // END_S: the Nut ends 75 s after the stop; WAKE_S / NAP_S: Jack
  // lies down 40 s after the stop unless the stick is pushed (the Lucky Timer's wake line at 33.4 s; the lab pushes on
  // casts later than 39.4 s); BLIND_S: the width of a blind window (B anywhere in it)
  const flagCache = new Map();
  function flagsOf(key) {                                       // per pack label / 2: Nut on bite 1 / on bite 2 (bite 1 held)
    if (flagCache.has(key)) return flagCache.get(key);
    const ln = DC && DC.lines[key];
    let f = null;
    if (ln) {
      const n = ln.k0 / 2 + ln.idx.length, b1 = new Uint8Array(n), b2 = new Uint8Array(n);
      ln.idx.forEach((cid, j) => {
        if (cid < 0 || DC.F[cid] < 0) return;
        const st = DC.S[cid], i = ln.k0 / 2 + j;
        if (st < 0) return;
        if (DC.O[st] === 'N') b1[i] = 1;
        if (DC.N[st] >= 0 && DC.X[st] >= 0 && DC.O[DC.X[st]] === 'N') b2[i] = 1;
      });
      f = { b1, b2 };
    }
    flagCache.set(key, f);
    return f;
  }
  /* per game frame i after the stop (elapsed VI 2i): the weighted share of the arrivals whose cast there gives the
     Nut on bite 1 (s1) / on bite 2 (s2); vars = [{ key, o, w }] */
  function shares(vars) {
    const nF = Math.floor(END_S * 1000 / VI() / 2) + 1, s1 = new Float64Array(nF), s2 = new Float64Array(nF);
    let W = 0, Wd = 0;
    for (const v of vars) {
      W += v.w;
      const f = flagsOf(v.key); if (!f) continue;
      Wd += v.w;
      for (let i = 0; i < nF; i++) {
        let lab = 2 * i + v.o; lab -= ((lab % 2) + 2) % 2;
        const j = lab / 2;
        if (j < 0 || j >= f.b1.length) continue;
        if (f.b1[j]) s1[i] += v.w;
        if (f.b2[j]) s2[i] += v.w;
      }
    }
    if (Wd > 0) for (let i = 0; i < nF; i++) { s1[i] /= Wd; s2[i] /= Wd; }
    return { s1, s2, cover: W > 0 ? Wd / W : 0 };
  }
  const POL2 = [['bite1', 's1'], ['hold', 's2']];
  /* the best window of BLIND_S seconds starting at elapsed VI >= fromVI: B pressed anywhere in it, one rule */
  function bestWindow(sh, fromVI) {
    const n = Math.max(1, Math.round(BLIND_S * 1000 / VI() / 2)), i0 = Math.max(0, Math.ceil(fromVI / 2));
    let b = null;
    for (const [pol, k] of POL2) {
      const a = sh[k]; let sum = 0;
      for (let i = 0; i < a.length; i++) {
        sum += a[i]; if (i >= n) sum -= a[i - n];
        const st = i - n + 1;
        if (st < i0) continue;
        if (!b || sum / n > b.p + 1e-12) b = { pol, p: sum / n, st, n };
      }
    }
    return b && b.p > 0 ? { pol: b.pol, p: b.p, t: 2 * b.st + b.n + 1, lo: 2 * b.st + 1, hi: 2 * (b.st + b.n) + 1 } : null;
  }
  /* per game frame: P(Nut) of a cast aimed there, the B press off by a bell curve of sd sigVI (as LuckyCore's smoothing) */
  function aimedCurves(sh, sigVI) {
    const sd = Math.max(0.25, sigVI / 2), r = Math.ceil(3 * sd), g = new Float64Array(2 * r + 1);
    let z = 0;
    for (let d = -r; d <= r; d++) { g[d + r] = Math.exp(-0.5 * (d / sd) ** 2); z += g[d + r]; }
    const out = {};
    for (const [pol, k] of POL2) {
      const a = sh[k], P = new Float64Array(a.length);
      for (let i = 0; i < a.length; i++) {
        let q = 0;
        for (let d = -r; d <= r; d++) { const j = i + d; if (j >= 0 && j < a.length) q += g[d + r] * a[j]; }
        P[i] = q / z;
      }
      out[pol] = P;
    }
    return out;
  }
  /* v31.30: a row's casts from the cast pack - the best cast per rule over 0-75 s, the quick cast, and the by-the-clock
     rule (LuckyCore's zone policy, inside its 40-s tables). The 40-s tables leave out, at each moment, the arrivals
     whose line has no table there (e.g. 6% of the L4 flapper-SW arrivals at 5.8 s: 17.4% shown, 16.4% over all of
     them); the pack has every line at every frame. Times are stopwatch VIs (t = 2i + 1 for game frame i after the stop). */
  function evalPack(Q, sigVI, tMin, floor) {
    const sh = shares(packVars(Q)); if (!(sh.cover > 0)) return null;
    const cv = aimedCurves(sh, sigVI), i0 = Math.max(0, Math.ceil((tMin - 1) / 2)), o = {};
    for (const [pol] of POL2) {
      const P = cv[pol]; let b = -1;
      for (let i = i0; i < P.length; i++) if (b < 0 || P[i] > P[b] + 1e-12) b = i;
      if (b >= 0 && P[b] > 0) o[pol] = { t: 2 * b + 1, p: P[b] };
    }
    const simple = !o.hold || (o.bite1 && o.bite1.p >= o.hold.p) ? 'bite1' : 'hold';
    o.simple = o[simple] ? simple : (o.hold ? 'hold' : null);
    if (!o.simple) return null;
    o.late = isLate(o[o.simple].t);
    try {                                                         // by the clock: inside the 40-s tables only
      const g = C.goal; let b;
      try { C.setGoal(null); b = C.best(Q, sigVI, tMin); } finally { C.setGoal(g || null); }
      if (b && b.zone && b.zone.p > 0) {
        const z = C.zoneAt(Q, b.zone.t, sigVI, sigVI, true);
        o.zone = { t: b.zone.t, p: b.zone.p, zones: z && z.zones ? z.zones.filter(w => w[1] > b.zone.t).slice(0, 4) : [] };
      }
    } catch (e) { /* no clock rule */ }
    /* the QUICK cast (v31.8 rule): the first moment one of the two rules reaches `floor`, at the top of that rise
       (at most 1.5 s on), kept when it comes at least 1 s before the best cast */
    if (floor > 0) {
      const end = (o[o.simple].t - 61) / 2;
      let q = null;
      for (const [pol] of POL2) {
        if (!o[pol]) continue;
        const P = cv[pol];
        for (let i = i0; i < end; i++) {
          if (!(P[i] >= floor)) continue;
          let u = i; while (u + 1 < end && u - i < 45 && P[u + 1] >= P[u]) u++;
          if (!q || i < q.i0 || (i === q.i0 && P[u] > q.p)) q = { t: 2 * u + 1, p: P[u], pol, i0: i };
          break;
        }
      }
      o.quick = q;
    }
    return o;
  }
  function packVars(Q) {                                         // a plan's variants as pack lines (series -> dog line key)
    const R = Q.refR; if (!R || !R.dw) return [];
    let m = R._sKey;
    if (!m) { m = R._sKey = new Map(); (R.sidxs || []).forEach((sx, li) => { const dwi = R.dw.of_line[li]; if (dwi != null && dwi >= 0) m.set(sx, R.dw.lines[dwi].key); }); }
    return Q.variants.filter(x => x.w > 0 && m.has(x.s)).map(x => ({ key: m.get(x.s), o: x.o, w: x.w }));
  }
  const candVars = (R, cs) => cs.map(c => ({ key: R.dw.lines[c.dwi].key, o: c.ko - c.mt + 1, w: c.w }));

  /* ---------------------------------------------------------------- v32.2 (Thomas 2026-11-23 18:26): what the window
     looks like. "a tiny image of the moment in time on the histogram that makes it the most favourable ... small
     rectangular thumbnails that, when clicked, expand to show the green candles / gold candles and their density ...
     so people know what the window they're casting into looks like, and it doesn't feel so blind."
     Per Optimal Blind Casting row: the cast histogram of that row's arrivals from 2 s before its 1-s window to 2 s
     after, one column per game frame - the share of the row's arrivals whose cast in that frame catches the Nut on
     bite 1 (green) / on bite 2 holding bite 1 (gold) - and per dog line of the row, its Nut frames. The same numbers
     as the row's odds (shares() of the same arrivals), drawn in the browser, so every page and setting has its own. */
  const CTX_S = 2;
  function chartOf(R, cs, sh, win) {
    if (!win) return null;
    const st = (win.lo - 1) / 2, n = (win.hi - win.lo) / 2, cf = Math.round(CTX_S * 1000 / VI() / 2);
    const a = Math.max(0, st - cf), b = Math.min(sh.s1.length, st + n + cf), m = b - a;
    if (!(m > 0)) return null;
    const L = new Map();
    for (const c of cs) {
      const f = flagsOf(R.dw.lines[c.dwi].key); if (!f) continue;
      let g = L.get(c.dwi); if (!g) L.set(c.dwi, g = { dwi: c.dwi, key: R.dw.lines[c.dwi].key, name: lineName(R, c.dwi), w: 0, f1: new Float32Array(m), f2: new Float32Array(m), tm: new Map() });
      g.w += c.w;
      const o = c.ko - c.mt + 1;
      g.tm.set(o, (g.tm.get(o) || 0) + c.w);
      for (let i = a; i < b; i++) {
        let lab = 2 * i + o; lab -= ((lab % 2) + 2) % 2;
        const j = lab / 2;
        if (j < 0 || j >= f.b1.length) continue;
        if (f.b1[j]) g.f1[i - a] += c.w;
        if (f.b2[j]) g.f2[i - a] += c.w;
      }
    }
    const lines = [...L.values()].sort((x, y) => y.w - x.w), Wd = lines.reduce((q, g) => q + g.w, 0) || 1;
    for (const g of lines) {
      for (let i = 0; i < m; i++) { g.f1[i] /= g.w; g.f2[i] /= g.w; }
      g.share = g.w / Wd;
      g.timings = [...g.tm.entries()].map(([o, w]) => ({ o, w: w / g.w })).sort((x, y) => y.w - x.w); delete g.tm;   // v32.3
    }
    return { a, st, n, s1: Array.from(sh.s1.subarray(a, b)), s2: Array.from(sh.s2.subarray(a, b)), lines, pol: win.pol, p: win.p, lo: win.lo, hi: win.hi };
  }
  const isLate = t => secs(t) > NAP_S;
  const WAKE2_S = 2 * WAKE_S, NAP2_S = WAKE_S + NAP_S;          // a cast after ~72.8 s needs a 2nd push (the wake line at 66.9 s)
  const pushWhen = t => (secs(t) > NAP2_S ? `at about ${WAKE_S.toFixed(0)} s and again at about ${WAKE2_S.toFixed(0)} s` : `once at about ${WAKE_S.toFixed(0)} s`);
  const PUSH_TXT = `Cast after 40 s: push the stick ↘ once at about ${WAKE_S.toFixed(0)} s (and again at about ${WAKE2_S.toFixed(0)} s for a cast after ${NAP2_S.toFixed(0)} s), or Jack lies down (never push after casting).`;

  /* ---------------------------------------------------------------- the best cast for a set of candidates */
  let uid = 0;
  function subPlan(X, pvs) {
    const vars = [];
    X.plan.variants.forEach((x, pv) => { if (pvs.has(pv) && x.w > 0) vars.push(x); });
    return vars.length ? Object.assign({}, X.plan, { variants: vars, k: 'ref' + (++uid), maxBite: 0, refR: X.R }) : null;
  }
  function evalPlan(Q, sigVI, tMin, floor) {
    if (!Q) return null;
    tMin = Math.max(1, Math.round(tMin));
    if (DC && Q.refR) return evalPack(Q, sigVI, tMin, floor);     // v31.30: the cast pack, 0-75 s
    const g = C.goal;
    let b;
    try { C.setGoal(null); b = C.best(Q, sigVI, tMin); } finally { C.setGoal(g || null); }
    const o = {};
    for (const pol of ['bite1', 'hold']) {
      if (!b[pol] || !(b[pol].p > 0)) continue;
      o[pol] = { t: b[pol].t, p: b[pol].p };
      const P = C.curve(Q, sigVI, pol).P;                       // an earlier cast worth nearly as much
      for (let t = Math.max(tMin, Q.firstT || 1); t < b[pol].t - 120; t++) {
        if (P[t] >= SOON * b[pol].p) { let u = t; while (u + 1 < b[pol].t && P[u + 1] >= P[u]) u++; o[pol].soon = { t: u, p: P[u] }; break; }
      }
    }
    if (b.zone && b.zone.p > 0) {
      const z = C.zoneAt(Q, b.zone.t, sigVI, sigVI, true);
      o.zone = { t: b.zone.t, p: b.zone.p, zones: z && z.zones ? z.zones.filter(w => w[1] > b.zone.t).slice(0, 4) : [] };
    }
    const simple = !o.hold || (o.bite1 && o.bite1.p >= o.hold.p) ? 'bite1' : 'hold';
    o.simple = o[simple] ? simple : (o.hold ? 'hold' : null);
    /* v31.8 (Thomas 2026-11-20 22:19: "show times that are most likely ... but then also fastest ... a quick cast, if
       the odds aren't terrible, it's a numbers game"): the QUICK cast = the first moment after the look at which one of
       the two simple rules reaches `floor`, taken at the top of that rise (at most 1.5 s on). Kept only when it comes
       at least 1 s before the best cast. */
    if (o.simple && floor > 0) {
      let q = null;
      for (const pol of ['bite1', 'hold']) {
        if (!o[pol]) continue;
        const P = C.curve(Q, sigVI, pol).P;
        for (let t = Math.max(tMin, Q.firstT || 1); t < o[o.simple].t - 60; t++) {
          if (!(P[t] >= floor)) continue;
          let u = t; while (u + 1 < o[o.simple].t - 60 && u - t < 90 && P[u + 1] >= P[u]) u++;
          if (!q || t < q.t0 || (t === q.t0 && P[u] > q.p)) q = { t: u, p: P[u], pol, t0: t };
          break;
        }
      }
      o.quick = q;
    }
    return o.simple ? o : null;
  }

  /* ---------------------------------------------------------------- the analysis (in slices, so the page stays live) */
  let job = 0;
  const cache = new Map();
  function analyse(routeId, sigMs, onPart, onDone, quickPct) {
    const my = ++job, X = ctx(routeId);
    if (!X) { onDone(null); return; }
    const qp = quickPct == null ? S.quick : quickPct, floor = qp / 100;
    const key = routeId + '|' + sigMs + '|' + qp + '|' + DATA.generated;
    if (cache.has(key)) { onDone(cache.get(key)); return; }
    const { R, cands, W } = X, sigVI = sigMs / VI();
    const out = { routeId, sigMs, quick: qp, lead: X.lead, arrive: [], harb: [], lines: [], all: null, nLines: R.dw.lines.length };
    const tasks = [];
    const pvsOf = cs => new Set(cs.filter(c => c.pv >= 0).map(c => c.pv));
    const byLine = cs => { const m = new Map(); for (const c of cs) m.set(c.dwi, (m.get(c.dwi) || 0) + c.w); return [...m.entries()].sort((a, b) => b[1] - a[1]); };
    // everything together: the cast when you cannot tell the dog at all
    tasks.push(() => { out.all = evalPlan(subPlan(X, pvsOf(cands)), sigVI, MIN_CAST_AFTER_LOOK, floor); });
    // 1. what the dog shows as you stop (half a second after)
    const G = new Map();
    for (const c of cands) {
      const r = showAt(R, c.dwi, LOOK_VI + c.ko - c.mt + 1);
      const k2 = r ? r[4] + '_' + r[2] : '?';
      let g = G.get(k2); if (!g) G.set(k2, g = { key: k2, base: r ? r[4] : null, dir: r ? r[2] : null, w: 0, cs: [] });
      g.w += c.w; g.cs.push(c);
    }
    const groups = [...G.values()].sort((a, b) => b.w - a.w);
    for (const g of groups) {
      const row = { key: g.key, base: g.base, dir: g.dir, share: g.w / W, lines: byLine(g.cs).map(([d, w]) => ({ dwi: d, name: lineName(R, d), p: w / g.w })), cast: null, split: [] };
      out.arrive.push(row);
      tasks.push(() => { row.cast = evalPlan(subPlan(X, pvsOf(g.cs)), sigVI, LOOK_VI + MIN_CAST_AFTER_LOOK, floor); });
      // a mixed group: what each of its main lines does next, so the player can tell them apart
      if (row.lines.length > 1 && row.lines[0].p < 0.9) {
        const main = row.lines.filter(l => l.p >= 0.08).slice(0, 4).map(ln => {
          const cs = g.cs.filter(c => c.dwi === ln.dwi);
          const a = cs.reduce((q, c) => q + c.w * (c.ko - c.mt), 0) / cs.reduce((q, c) => q + c.w, 0) + 1;
          const seq = [];
          for (const r of R.dw.lines[ln.dwi].vis) { const t = r[0] - a; if (t > HARB_UNTIL) break; if (t <= LOOK_VI || r[1] - r[0] < 18) continue; seq.push({ base: r[4], dir: r[2], t }); }
          return { ln, cs, seq };
        });
        for (const m of main) {
          const others = main.filter(x => x !== m);
          const tell = m.seq.find(e => !others.some(x => x.seq.some(f => f.base === e.base && f.dir === e.dir && Math.abs(f.t - e.t) <= 60)));
          const nxt = tell || m.seq[0] || null;
          const sp = { name: m.ln.name, dwi: m.ln.dwi, p: m.ln.p, next: nxt, only: !!tell, cast: null };
          row.split.push(sp);
          tasks.push(() => { sp.cast = evalPlan(subPlan(X, pvsOf(m.cs)), sigVI, Math.max(LOOK_VI, nxt ? nxt.t : 0) + MIN_CAST_AFTER_LOOK, floor); });
        }
      }
    }
    // 2. harbingers: something the dog starts doing in the first 10 s that (nearly) only one line does then
    const H = new Map();
    for (const c of cands) {
      const a = c.ko - c.mt + 1, v = R.dw.lines[c.dwi].vis, seen = new Set();
      for (const r of v) {
        const t = r[0] - a;
        if (t > HARB_UNTIL) break;
        if (t <= LOOK_VI || r[1] - r[0] < 18) continue;        // under 0.3 s on screen: nobody reads it
        const k2 = r[4] + '_' + r[2] + '_' + Math.floor(t / HARB_BIN);
        if (seen.has(k2)) continue;
        seen.add(k2);
        let h = H.get(k2); if (!h) H.set(k2, h = { base: r[4], dir: r[2], bin: Math.floor(t / HARB_BIN), w: 0, cs: [], ts: 0 });
        h.w += c.w; h.cs.push(c); h.ts += c.w * t;
      }
    }
    const harb = [];
    for (const h of H.values()) {
      const ls = byLine(h.cs), pure = ls[0][1] / h.w;
      if (pure < 0.85 || h.w / W < 0.004) continue;
      harb.push({ base: h.base, dir: h.dir, bin: h.bin, t: h.ts / h.w, share: h.w / W, pure, line: lineName(R, ls[0][0]), dwi: ls[0][0], cs: h.cs, all: h.cs, cast: null });   // v31.30: cs = every arrival showing it (was: its line's only)
    }
    harb.sort((a, b) => b.share * b.pure - a.share * a.pure);
    const pinned = new Set(out.arrive.filter(r => r.lines[0].p >= 0.9).map(r => r.lines[0].dwi));
    const perLine = new Map(), keep = [];
    for (const h of harb) { if (pinned.has(h.dwi)) continue; const n = perLine.get(h.dwi) || 0; if (n >= 2) continue; perLine.set(h.dwi, n + 1); keep.push(h); if (keep.length >= 14) break; }
    keep.sort((a, b) => a.dwi - b.dwi || a.t - b.t);
    /* v31.30: Optimal Blind Casting - per harbinger the best 1-s window to cast in (B anywhere in it), over every
       arrival that shows it; one behaviour of one line in neighbouring 2-s bins is one row; then "none of these by
       10 s" (the arrivals showing none of them) and "not watching the dog" (all arrivals). */
    const brows = [];
    for (const h of keep) {
      const m = brows.find(b => b.base === h.base && b.dir === h.dir && b.dwi === h.dwi && b.bins.some(x => Math.abs(x - h.bin) === 1));
      if (m) {
        const have = new Set(m.cs);
        for (const c of h.all) if (!have.has(c)) m.cs.push(c);
        m.bins.push(h.bin); m.tMax = Math.max(m.tMax, h.t); m.tw += h.t * h.share; m.sw += h.share;
      } else brows.push({ base: h.base, dir: h.dir, dwi: h.dwi, line: h.line, bins: [h.bin], cs: h.all.slice(), tMax: h.t, tw: h.t * h.share, sw: h.share });
    }
    const seenAny = new Set();
    for (const b of brows) { b.t = b.tw / b.sw; b.share = b.cs.reduce((q, c) => q + c.w, 0) / W; b.win = null; for (const c of b.cs) seenAny.add(c); }
    const gW = new Map(); for (const r of brows) gW.set(r.dwi, Math.max(gW.get(r.dwi) || 0, r.share));   // rows: the line whose sign is seen most first, then by when it shows
    brows.sort((a, b) => gW.get(b.dwi) - gW.get(a.dwi) || a.dwi - b.dwi || a.t - b.t);
    out.blind = { rows: brows, none: { cs: cands.filter(c => !seenAny.has(c)), win: null }, all: { win: null } };
    out.blind.none.share = out.blind.none.cs.reduce((q, c) => q + c.w, 0) / W;
    for (const b of brows) tasks.push(() => { const sh = shares(candVars(R, b.cs)); b.win = bestWindow(sh, Math.floor(b.tMax) + MIN_CAST_AFTER_LOOK + 30); b.chart = chartOf(R, b.cs, sh, b.win); b.nLines = new Set(b.cs.map(c => c.dwi)).size; delete b.cs; });
    tasks.push(() => { const B = out.blind.none, sh = shares(candVars(R, B.cs)); B.win = bestWindow(sh, HARB_UNTIL + MIN_CAST_AFTER_LOOK + 30); B.chart = chartOf(R, B.cs, sh, B.win); delete B.cs; });
    tasks.push(() => { const B = out.blind.all, sh = shares(candVars(R, cands)); B.win = bestWindow(sh, 0); B.chart = chartOf(R, cands, sh, B.win); });
    for (const h of keep) {
      out.harb.push(h);
      tasks.push(() => { h.cast = evalPlan(subPlan(X, pvsOf(h.cs)), sigVI, Math.round(h.t) + MIN_CAST_AFTER_LOOK + 30, floor); delete h.cs; delete h.all; });
    }
    // 3. every dog line with a cast table: its share, what its dog does in the first 10 s, its best cast when known
    for (const [dwi, w] of byLine(cands)) {
      const cs = cands.filter(c => c.dwi === dwi);
      if (w / W < 0.004 || !cs.some(c => c.pv >= 0)) continue;
      const a = cs.reduce((q, c) => q + c.w * (c.ko - c.mt), 0) / w + 1;
      const seq = [];
      for (const r of R.dw.lines[dwi].vis) { const t = r[0] - a; if (t > HARB_UNTIL) break; if (r[1] - a <= 0 || r[1] - r[0] < 12) continue; seq.push({ base: r[4], dir: r[2], t: Math.max(0, t) }); if (seq.length >= 6) break; }
      const row = { name: lineName(R, dwi), dwi, share: w / W, seq, cast: null };
      out.lines.push(row);
      tasks.push(() => { row.cast = evalPlan(subPlan(X, pvsOf(cs)), sigVI, LOOK_VI + MIN_CAST_AFTER_LOOK, floor); });
    }
    const total = tasks.length;
    (function step() {
      if (my !== job) return;
      const t0 = performance.now();
      while (tasks.length && performance.now() - t0 < 40) tasks.shift()();
      onPart(out, 1 - tasks.length / total);
      if (tasks.length) setTimeout(step, 0); else { cache.set(key, out); onDone(out); }
    })();
  }

  /* ---------------------------------------------------------------- v32.2: the window thumbnails and their close-up */
  const COL1 = '#5fd38d', COL2 = '#e7c14a', COLW = '#6fb7ff', BASE = 1 / 51;
  const CH = new Map();                                         // thumbnail id -> { ch, title, sub }
  let hatchC = null;
  function hatch(g) {                                           // gold, hatched: Nut on bite 2 (as the Lucky Timer)
    if (!hatchC) {
      hatchC = document.createElement('canvas'); hatchC.width = hatchC.height = 6;
      const h = hatchC.getContext('2d'); h.fillStyle = 'rgba(231,193,74,.35)'; h.fillRect(0, 0, 6, 6);
      h.strokeStyle = COL2; h.lineWidth = 2; h.beginPath(); h.moveTo(-1, 7); h.lineTo(7, -1); h.moveTo(-1, 1); h.lineTo(1, -1); h.moveTo(5, 7); h.lineTo(7, 5); h.stroke();
    }
    return g.createPattern(hatchC, 'repeat');
  }
  const fsec = i => 2 * i * VI() / 1000;                        // game frame after the stop -> seconds after the stop
  function setup(cv, w, h) {
    const r = root.devicePixelRatio || 1;
    cv.width = Math.round(w * r); cv.height = Math.round(h * r); cv.style.width = w + 'px'; cv.style.height = h + 'px';
    const g = cv.getContext('2d'); g.setTransform(r, 0, 0, r, 0, 0); return g;
  }
  /* the histogram: bars per game frame in [x0, x0 + m * pf) x [y0, y0 + h); the row's own rule in front, the other
     one behind it at half strength; the window shaded blue, its odds as a white line, 1/51 dashed */
  function bars(g, ch, x0, y0, pf, h, yMax, big) {
    const m = ch.s1.length, y = v => y0 + h - Math.min(h, h * v / yMax);
    g.fillStyle = 'rgba(111,183,255,.13)'; g.fillRect(x0 + (ch.st - ch.a) * pf, y0, ch.n * pf, h);
    const order = ch.pol === 'hold' ? [['s1', COL1], ['s2', null]] : [['s2', null], ['s1', COL1]];
    const gap = big && pf >= 4 ? 1 : 0;
    order.forEach(([k, col], z) => {
      g.globalAlpha = z === 0 ? 0.5 : 1;
      g.fillStyle = col || (big ? hatch(g) : COL2);
      for (let i = 0; i < m; i++) { const v = ch[k][i]; if (v > 0) { const t = y(v); g.fillRect(x0 + i * pf, t, Math.max(1, pf - gap), y0 + h - t); } }
    });
    g.globalAlpha = 1;
    const yb = Math.round(y(BASE)) + 0.5;
    g.setLineDash([3, 3]); g.strokeStyle = 'rgba(220,230,236,.45)'; g.lineWidth = 1;
    g.beginPath(); g.moveTo(x0, yb); g.lineTo(x0 + m * pf, yb); g.stroke();
    g.setLineDash([]); g.strokeStyle = COLW; g.lineWidth = big ? 1.5 : 1;
    const wx0 = x0 + (ch.st - ch.a) * pf, wx1 = wx0 + ch.n * pf, yp = Math.round(y(ch.p)) + 0.5;
    g.beginPath(); g.moveTo(wx0 + 0.5, y0); g.lineTo(wx0 + 0.5, y0 + h); g.moveTo(wx1 - 0.5, y0); g.lineTo(wx1 - 0.5, y0 + h); g.stroke();
    if (!big) { g.fillStyle = 'rgba(11,20,28,.45)'; g.fillRect(x0, y0, wx0 - x0, h); g.fillRect(wx1, y0, x0 + m * pf - wx1, h); }
    g.strokeStyle = '#dce6ec'; g.lineWidth = big ? 2 : 1; g.beginPath(); g.moveTo(wx0, yp); g.lineTo(wx1, yp); g.stroke();
  }
  function paintThumb(cv, ch) {
    const m = ch.s1.length, pf = Math.max(1, Math.round(150 / m)), W = m * pf, H = 30;
    const g = setup(cv, W, H);
    g.fillStyle = '#0b141c'; g.fillRect(0, 0, W, H);
    const yMax = Math.max(0.08, ...ch.s1, ...ch.s2) * 1.08;
    bars(g, ch, 0, 1, pf, H - 2, yMax, false);
  }
  const NL = 12;                                                // dog lines drawn one by one; the rest share one strip
  const ruleOf = (ch, l) => (ch.pol === 'hold' ? l.f2 : l.f1);
  const hasNut = (l, i) => l.f1[i] > 0 || l.f2[i] > 0;
  /* v32.3: st = { hover, sel, focus }: sel = a clicked candle (game frame index in the chart) - the dog lines with a Nut
     there stay lit, the others dim; focus = a clicked dog line (index in ch.lines) - only it stays lit, and its part of
     every candle (its share x its Nut fraction) is drawn white inside the bars. */
  function paintBig(cv, ch, st) {
    st = st || {};
    const sel = st.sel != null && st.sel >= 0 && st.sel < ch.s1.length ? st.sel : null, foc = st.focus != null ? st.focus : null;
    /* v32.4 (Thomas 19:17: "instead of the dog line name dimming i was expecting the candles to disappear like they do
       in freestyle when we know the dog line"): by default a clicked candle / line / timing FILTERS the histogram to
       what you would see if you knew you were on it - the candles of the other lines disappear and the bars are the
       share of THOSE arrivals (the clicked candle's lines together, one line, or one timing's exact frames: 0 or 100%).
       "Keep every candle" (S.keepAll) = the v32.3 view: all candles stay, the other lines dim. */
    const filt = !st.keepAll && (sel != null || foc != null);
    const group = foc != null ? [ch.lines[foc]] : sel != null ? ch.lines.filter(l => hasNut(l, sel)) : ch.lines;
    let vw = ch, gsh = null, gw = 0;
    if (filt) {
      const m0 = ch.s1.length, v1 = new Float64Array(m0), v2 = new Float64Array(m0);
      if (foc != null && st.marks) { for (let i = 0; i < m0; i++) { v1[i] = st.marks.b1[i]; v2[i] = st.marks.b2[i]; } gw = ch.lines[foc].share; }
      else if (foc != null) { const l = ch.lines[foc]; for (let i = 0; i < m0; i++) { v1[i] = l.f1[i]; v2[i] = l.f2[i]; } gw = l.share; }
      else {
        /* a clicked candle = the arrivals (dog line x timing) with a Nut in that frame; the chart shows where else
           THOSE arrivals have their Nut frames: the clicked candle becomes certain, its neighbours show the doubles /
           triples it sits in, everything the group cannot reach disappears */
        const MK = marksAll(ch); gsh = new Map();
        ch.lines.forEach((l, li) => l.timings.forEach((t, ti) => {
          const mk = MK[li][ti]; if (!mk.b1[sel] && !mk.b2[sel]) return;
          const w = l.share * t.w; gw += w;
          let q = gsh.get(li); if (!q) gsh.set(li, q = { w: 0, f1: new Float32Array(m0), f2: new Float32Array(m0) });
          q.w += w;
          for (let i = 0; i < m0; i++) { if (mk.b1[i]) { v1[i] += w; q.f1[i] += w; } if (mk.b2[i]) { v2[i] += w; q.f2[i] += w; } }
        }));
        for (let i = 0; i < m0; i++) { v1[i] /= gw || 1; v2[i] /= gw || 1; }
        for (const q of gsh.values()) for (let i = 0; i < m0; i++) { q.f1[i] /= q.w; q.f2[i] /= q.w; }
      }
      const vk = ch.pol === 'hold' ? v2 : v1; let sum = 0;
      for (let i = ch.st - ch.a; i < ch.st - ch.a + ch.n; i++) sum += vk[i];
      vw = Object.assign({}, ch, { s1: Array.from(v1), s2: Array.from(v2), p: sum / ch.n, gw });
    }
    const m = ch.s1.length, pf = Math.max(3, Math.min(8, Math.floor(860 / m))), L0 = 96, W = L0 + m * pf + 36;
    const top = ch.lines.slice(0, NL), rest = ch.lines.slice(NL), restShare = rest.reduce((q, l) => q + l.share, 0);
    const rh = top.map(l => Math.max(14, Math.min(96, Math.round(220 * l.share)))), RH = rest.length ? 24 : 0;
    const HH = 170, Y1 = 8, Y2 = Y1 + HH + 12, H = Y2 + rh.reduce((q, v) => q + v, 0) + RH + 30;
    const lit = k => (foc != null ? k === foc : sel != null ? hasNut(ch.lines[k], sel) : true);
    const g = setup(cv, W, H);
    g.fillStyle = '#0d1720'; g.fillRect(0, 0, W, H);
    g.fillStyle = '#13222f'; g.fillRect(L0, Y1, m * pf, HH); g.fillRect(L0, Y2, m * pf, H - 30 - Y2);
    const yMax = Math.max(0.08, ...vw.s1, ...vw.s2) * 1.08, X = i => L0 + i * pf, Y = v => Y1 + HH - Math.min(HH, HH * v / yMax);
    g.font = '11px system-ui,sans-serif'; g.textBaseline = 'middle';
    const step = yMax > 0.5 ? 0.2 : yMax > 0.25 ? 0.1 : 0.05;
    for (let v = 0; v <= yMax + 1e-9; v += step) {               // grid + y labels: share of the row's arrivals
      const yy = Math.round(Y(v)) + 0.5;
      g.strokeStyle = 'rgba(43,63,79,.7)'; g.lineWidth = 1; g.beginPath(); g.moveTo(L0, yy); g.lineTo(L0 + m * pf, yy); g.stroke();
      g.fillStyle = '#8ea3b2'; g.textAlign = 'right'; g.fillText(Math.round(100 * v) + '%', L0 - 6, yy);
    }
    bars(g, vw, L0, Y1, pf, HH, yMax, true);
    if (foc != null && !filt) {                                 // the focused line's part of every candle
      const l = ch.lines[foc], fr = ruleOf(ch, l);
      g.fillStyle = 'rgba(255,255,255,.9)';
      for (let i = 0; i < m; i++) { const v = l.share * fr[i]; if (v > 0) { const t = Y(v); g.fillRect(X(i) + (pf >= 5 ? 1 : 0), t, Math.max(1, pf - (pf >= 5 ? 3 : 1)), Y1 + HH - t); } }
    }
    if (sel != null) {                                          // the clicked candle
      const v = Math.max(vw.s1[sel], vw.s2[sel]), t = Math.min(Y(v), Y1 + HH - 3);
      g.strokeStyle = '#ffffff'; g.lineWidth = 1.5; g.strokeRect(X(sel) - 1, t - 2, pf + 1, Y1 + HH - t + 2);
    }
    const wx1 = X(ch.st - ch.a + ch.n), yp = Y(vw.p);
    g.textAlign = 'left'; g.fillStyle = '#dce6ec'; g.font = '600 11px system-ui,sans-serif';
    g.fillText(pct(vw.p), Math.min(wx1 + 4, L0 + m * pf - 30), Math.max(Y1 + 8, yp - 8));
    if (filt) { g.font = '11px system-ui,sans-serif'; g.fillStyle = '#dce6ec'; g.fillText(foc != null ? (st.marks ? `only ${ch.lines[foc].name} at this timing` : 'only ' + ch.lines[foc].name) : `only the arrivals of the clicked candle (${group.length} line${group.length === 1 ? '' : 's'}, ${pct(vw.gw)} of the row)`, L0 + 6, Y1 + 9); }
    g.font = '11px system-ui,sans-serif'; g.fillStyle = '#8ea3b2';
    g.fillText('1/51', L0 + m * pf + 4, Y(BASE));
    let yy = Y2;                                                // the dog lines of the row, heaviest at the top
    const rows = [];
    const strip = (lab, f1, f2, h, k, on) => {
      if (k % 2) { g.fillStyle = '#101d28'; g.fillRect(L0, yy, m * pf, h); }
      const dim = on ? 1 : filt ? 0 : 0.15;
      for (let i = 0; i < m; i++) {                             // a small histogram per line: bar height = the share
        const lay = ch.pol === 'hold' ? [[f1[i], COL1, 0.5], [f2[i], null, 1]] : [[f2[i], null, 0.5], [f1[i], COL1, 1]];   // of its timings with a Nut there
        for (const [a, col, al] of lay) if (a > 0) { const bh = Math.max(2, Math.round((h - 3) * Math.min(1, a))); g.globalAlpha = al * dim; g.fillStyle = col || hatch(g); g.fillRect(X(i), yy + h - 1 - bh, Math.max(1, pf - 1), bh); }
      }
      g.globalAlpha = 1; g.textAlign = 'right'; g.textBaseline = 'middle';
      g.fillStyle = on && (sel != null || foc != null) ? '#ffffff' : on ? '#8ea3b2' : '#4a5d6b';
      g.font = on && (sel != null || foc != null) ? '600 11px system-ui,sans-serif' : '11px system-ui,sans-serif';
      g.fillText(lab, L0 - 6, yy + h / 2);
      rows.push({ y0: yy, y1: yy + h, k }); yy += h;
    };
    const fOf = k => (gsh && gsh.has(k) ? gsh.get(k) : ch.lines[k]);
    top.forEach((l, k) => strip(`${l.name}  ${pct(l.share)}`, fOf(k).f1, fOf(k).f2, rh[k], k, lit(k)));
    if (rest.length) {
      const f1 = new Float32Array(m), f2 = new Float32Array(m), rs = (filt ? rest.filter(l => group.includes(l)) : rest).map(l => ch.lines.indexOf(l));
      const rwOf = k => (gsh && gsh.has(k) ? gsh.get(k).w : ch.lines[k].share), rw = rs.reduce((q, k) => q + rwOf(k), 0) || 1;
      for (const k of rs) { const f = fOf(k), w = rwOf(k); for (let i = 0; i < m; i++) { f1[i] += w * f.f1[i] / rw; f2[i] += w * f.f2[i] / rw; } }
      strip(`${rest.length} more  ${pct(restShare)}`, f1, f2, RH, 'rest', rest.some((l, j) => lit(NL + j)));
    }
    g.font = '11px system-ui,sans-serif';
    g.strokeStyle = COLW; g.lineWidth = 1;                      // the window across the lines too
    for (const x of [X(ch.st - ch.a) + 0.5, wx1 - 0.5]) { g.beginPath(); g.moveTo(x, Y2); g.lineTo(x, yy); g.stroke(); }
    if (sel != null) { g.strokeStyle = 'rgba(255,255,255,.55)'; g.strokeRect(X(sel) - 0.5, Y2, pf, yy - Y2); }
    g.fillStyle = '#8ea3b2'; g.textAlign = 'center'; g.textBaseline = 'top';
    const s0 = fsec(ch.a), s1 = fsec(ch.a + m - 1);
    for (let s = Math.ceil(s0 * 2 - 1e-9) / 2; s <= s1 + 1e-9; s += 0.5) {   // seconds after Jack stops
      const x = L0 + (s * 1000 / VI() / 2 - ch.a) * pf + pf / 2;
      g.fillRect(Math.round(x), yy, 1, 4); g.fillText(s.toFixed(1), x, yy + 6);
    }
    if (st.marks) {                                             // a picked timing of the focused line: its exact Nut frames
      const fr = rows.find(r => r.k === foc), mk = st.marks;
      for (let i = 0; i < m; i++) {
        const r1 = ch.pol === 'hold' ? mk.b2[i] : mk.b1[i], r2 = ch.pol === 'hold' ? mk.b1[i] : mk.b2[i];
        if (!r1 && !r2) continue;
        g.fillStyle = r1 ? '#ffffff' : 'rgba(255,255,255,.45)';
        g.beginPath(); g.moveTo(X(i) + pf / 2, Y1 + HH - 9); g.lineTo(X(i) - 1, Y1 + HH - 1); g.lineTo(X(i) + pf + 1, Y1 + HH - 1); g.closePath(); g.fill();
        if (fr) { g.strokeStyle = r1 ? '#ffffff' : 'rgba(255,255,255,.45)'; g.lineWidth = 1.5; g.strokeRect(X(i) - 0.5, fr.y0 + 1, pf, fr.y1 - fr.y0 - 2); }
      }
    }
    const hv = st.hover;
    if (hv != null && hv >= 0 && hv < m && hv !== sel) { g.fillStyle = 'rgba(255,255,255,.14)'; g.fillRect(X(hv), Y1, pf, yy - Y1); }
    return { L0, pf, m, W, H, rows, view: vw, filt, group };
  }
  function ensureStyle() {
    if ($('rfChartCss')) return;
    const st = document.createElement('style'); st.id = 'rfChartCss';
    st.textContent = '.rfthumb{display:block;cursor:zoom-in;border:1px solid #2b3f4f;border-radius:3px}.rfthumb:hover{border-color:#6fb7ff}' +
      '#rfChartDlg{max-width:96vw;box-sizing:border-box;background:#0d1720;color:#dce6ec;border:1px solid #2b3f4f;border-radius:8px;padding:12px 14px}#rfChartDlg::backdrop{background:rgba(0,0,0,.6)}' +
      '#rfChartDlg .rfch{display:flex;gap:10px;align-items:baseline}#rfChartDlg .rfch b{font-size:15px}#rfChartDlg .rfch button{margin-left:auto}' +
      '#rfChartDlg .rflg{display:flex;gap:16px;margin:6px 0;font-size:12px;flex-wrap:wrap}#rfChartDlg .rflg i{display:inline-block;width:12px;height:12px;margin-right:5px;vertical-align:-2px;border-radius:2px}' +
      '#rfChartDlg canvas{display:block;max-width:100%;cursor:pointer}#rfcRead{font:12px ui-monospace,monospace;height:32px;overflow:hidden;margin-top:4px}' +
      '#rfcLines{margin-top:6px;height:30vh;overflow-y:auto;border-top:1px solid #2b3f4f;padding-top:6px}#rfcLines .rfcsel{font-size:12px;margin-bottom:4px}' +
      '#rfcLines table{border-collapse:collapse;width:100%;font-size:12px}#rfcLines th{text-align:left;font-weight:600;color:#8ea3b2;font-size:11px;padding:2px 6px;border-bottom:1px solid #2b3f4f;position:sticky;top:0;background:#0d1720}' +
      '#rfcLines td{padding:2px 6px;border-bottom:1px solid #16222c;white-space:nowrap}#rfcLines td.num{font-family:ui-monospace,monospace}#rfcLines tr.ln{cursor:pointer}#rfcLines tr.ln:hover td{background:#13222f}' +
      '#rfcLines tr.dim td{opacity:.35}#rfcLines tr.foc td{background:#1d3346}#rfcLines tr.hit td:first-child{box-shadow:inset 3px 0 0 #fff}' +
      '#rfcLines .grp{display:inline-block;padding:0 5px;margin:0 3px 0 0;border-radius:4px;background:#14261d;color:#9fe3b9;font-family:ui-monospace,monospace;font-size:11px}#rfcLines .grp.g2{background:#2a2412;color:#f1d27a}' +
      '#rfcNote{margin-top:6px}';
    document.head.appendChild(st);
  }
  let dlgCur = null;
  /* the dog lines with a Nut inside the window (the row's rule), most odds first: how much each adds to the window's
     odds, the line's own chance if you are on it, its Nut frames in the window in runs of neighbouring frames (the
     singles / doubles / triples freestyle shows), and, for a clicked candle, its chance in that frame */
  function renderLines() {
    const x = dlgCur, ch = x.ch, a0 = ch.st - ch.a, a1 = a0 + ch.n, sel = x.sel, other = ch.pol === 'hold' ? 'f1' : 'f2';
    const fsx = i => fx(fsec(ch.a + i), 2);
    let rows = ch.lines.map((l, k) => {
      const fr = ruleOf(ch, l); let sum = 0, cnt = 0; const groups = [];
      for (let i = a0; i < a1; i++) {
        sum += fr[i]; if (!(fr[i] > 0)) continue; cnt++;
        const gq = groups[groups.length - 1];
        if (gq && gq.i1 === i - 1) { gq.i1 = i; gq.max = Math.max(gq.max, fr[i]); } else groups.push({ i0: i, i1: i, max: fr[i] });
      }
      return { k, l, mean: sum / ch.n, add: l.share * sum / ch.n, cnt, groups, hit: sel != null && hasNut(l, sel) };
    }).filter(r => r.cnt > 0 || r.hit);
    rows.sort((p, q) => (sel != null ? (q.hit - p.hit) : 0) || q.add - p.add);
    const more = rows.length > 16 ? rows.slice(16) : [];
    if (more.length && x.focus != null) { const f = more.find(r => r.k === x.focus); if (f) more.splice(more.indexOf(f), 1); }
    rows = rows.slice(0, 16).concat(x.focus != null && !rows.slice(0, 16).some(r => r.k === x.focus) ? rows.filter(r => r.k === x.focus) : []);
    const noNut = ch.lines.length - ch.lines.filter(l => { const fr = ruleOf(ch, l); for (let i = a0; i < a1; i++) if (fr[i] > 0) return true; return false; }).length;
    let head;
    if (sel != null) {
      const hits = ch.lines.filter(l => hasNut(l, sel));
      const V = x.L && x.L.filt ? x.L.view : null;
      head = `<div class="rfcsel"><b>Candle at ${fsx(sel)} s</b>${sel >= a0 && sel < a1 ? ' (in your window)' : ' (outside your window)'}: ` +
        `<span style="color:${COL1}">Nut on bite 1 ${pct(ch.s1[sel])}</span> · <span style="color:${COL2}">on bite 2 ${pct(ch.s2[sel])}</span> of all the row's arrivals, from ` +
        `<b>${hits.length}</b> dog line${hits.length === 1 ? '' : 's'}` + (V ? `. <b>The chart shows only those arrivals</b> (${pct(V.gw)} of the row: these lines at the timings that have a Nut in this frame) — where else their Nut frames are, as freestyle shows once it knows your dog: your window is worth <b>${pct(V.p)}</b> on them.`
          : ` (lit; the others dimmed).`) + ` Click it again, or <kbd>Esc</kbd>, to clear; <kbd>←</kbd> <kbd>→</kbd> step one game frame.</div>`;
    } else if (x.focus != null) {
      const l = ch.lines[x.focus];
      head = x.L && x.L.filt ? `<div class="rfcsel"><b>${esc(l.name)}</b> (${pct(l.share)} of these arrivals): <b>the chart shows only this line</b>${x.tm != null ? ', at the timing you picked: its exact Nut frames' : ', all its timings together'} — as freestyle does once it knows your dog. Your window is worth <b>${pct(x.L.view.p)}</b> on it. Click it again to clear.</div>`
        : `<div class="rfcsel"><b>${esc(l.name)}</b> (${pct(l.share)} of these arrivals): its part of every candle is drawn white. Click it again to clear.</div>`;
    } else head = `<div class="rfcsel mut">Click a candle to see which dog lines have a Nut there; click a line (here or its label on the left) to see its part of every candle.</div>`;
    const grp = g => `<span class="grp${ch.pol === 'hold' ? ' g2' : ''}">${g.i0 === g.i1 ? fsx(g.i0) : fsx(g.i0) + '–' + fsx(g.i1)} s${g.i1 > g.i0 ? ' ×' + (g.i1 - g.i0 + 1) : ''}${g.max < 0.995 ? ' · ' + pct(g.max) : ''}</span>`;
    $('rfcLines').innerHTML = head + (rows.length ? `<table><tr><th>line</th><th title="this line's share of the row's arrivals">share</th><th title="how many points of the window's ${pct(ch.p)} come from this line">adds to ${pct(ch.p)}</th><th title="the window's odds if you are on this line (timing unknown)">on it</th><th title="game frames of your window where some of this line's timings have a Nut">Nut frames</th>${sel != null ? `<th title="this line's chance in the clicked frame">at ${fsx(sel)} s</th>` : ''}<th title="runs of neighbouring frames with a Nut for some of this line's timings; % = the most of its timings in one frame">runs</th></tr>` +
      rows.map(r => `<tr class="ln${sel != null && !r.hit ? ' dim' : ''}${r.hit ? ' hit' : ''}${x.focus === r.k ? ' foc' : ''}" data-k="${r.k}"><td><b>${esc(r.l.name)}</b></td><td class="num">${pct(r.l.share)}</td><td class="num">${(100 * r.add).toFixed(1)} pts</td><td class="num">${pct(r.mean)}</td><td class="num">${r.cnt} of ${ch.n}</td>` +
        (sel != null ? `<td class="num">${ruleOf(ch, r.l)[sel] > 0 ? pct(ruleOf(ch, r.l)[sel]) : '—'}${r.l[other][sel] > 0 ? ` <span style="color:${ch.pol === 'hold' ? COL1 : COL2}">(${ch.pol === 'hold' ? 'bite 1' : 'bite 2'} ${pct(r.l[other][sel])})</span>` : ''}</td>` : '') +
        `<td>${r.groups.slice(0, 5).map(grp).join('')}${r.groups.length > 5 ? ` <span class="mut">+${r.groups.length - 5}</span>` : ''}</td></tr>`).join('') + `</table>` +
      (more.length ? `<div class="mut small">${more.length} more line${more.length === 1 ? '' : 's'} add ${(100 * more.reduce((q, r) => q + r.add, 0)).toFixed(1)} pts together.</div>` : '') : '') +
      (noNut ? `<div class="mut small">${noNut} of the row's ${ch.lines.length} dog lines have no Nut ${ch.pol === 'hold' ? 'on bite 2' : 'on bite 1'} in your window.</div>` : '');
    if (x.focus != null) $('rfcLines').innerHTML += timingsHtml();
    for (const tr of $('rfcLines').querySelectorAll('tr.ln')) tr.onclick = () => { const k = +tr.dataset.k; x.focus = x.focus === k ? null : k; x.sel = null; x.tm = null; redraw(); };
    for (const tr of $('rfcLines').querySelectorAll('tr.tm')) tr.onclick = () => { const o = +tr.dataset.o; x.tm = x.tm === o ? null : o; redraw(); };
    const ft = $('rfcLines').querySelector('tr.tm.foc'); if (ft && x.tmScroll) { ft.scrollIntoView({ block: 'nearest' }); x.tmScroll = false; }
  }
  /* v32.3 (Thomas 18:52: "see the granular details that get shown in the freestyle mode that make up the zone"): a
     line's timings = the same dog line reached a little earlier or later along the route, so its dog is a few frames
     ahead or behind at your stop and its Nut frames sit at other stopwatch times. Each timing alone has exact Nut
     frames - single frames, doubles, triples - which is what freestyle shows once the dog is tuned. */
  function marksAll(ch) { if (!ch._mk) ch._mk = ch.lines.map(l => l.timings.map(t => marksOf(ch, l, t.o))); return ch._mk; }
  function marksOf(ch, l, o) {
    const f = flagsOf(l.key), m = ch.s1.length, b1 = new Uint8Array(m), b2 = new Uint8Array(m);
    if (!f) return { b1, b2 };
    for (let i = 0; i < m; i++) {
      let lab = 2 * (ch.a + i) + o; lab -= ((lab % 2) + 2) % 2;
      const j = lab / 2;
      if (j < 0 || j >= f.b1.length) continue;
      b1[i] = f.b1[j]; b2[i] = f.b2[j];
    }
    return { b1, b2 };
  }
  function timingsHtml() {
    const x = dlgCur, ch = x.ch, l = ch.lines[x.focus], a0 = ch.st - ch.a, a1 = a0 + ch.n, o0 = l.timings[0].o;
    const fsx = i => fx(fsec(ch.a + i), 2);
    const rows = l.timings.slice(0, 14).map(t => {
      const mk = marksOf(ch, l, t.o), fr = ch.pol === 'hold' ? mk.b2 : mk.b1, gs = [];
      let cnt = 0;
      for (let i = a0; i < a1; i++) { if (!fr[i]) continue; cnt++; const q = gs[gs.length - 1]; if (q && q.i1 === i - 1) q.i1 = i; else gs.push({ i0: i, i1: i }); }
      const d = (t.o - o0) / 2;
      return `<tr class="tm${x.tm === t.o ? ' foc' : ''}" data-o="${t.o}"><td>${d === 0 ? 'most common' : `dog ${Math.abs(d)} frame${Math.abs(d) === 1 ? '' : 's'} ${d > 0 ? 'ahead' : 'behind'}`}</td><td class="num">${pct(t.w)}</td>` +
        `<td class="num">${pct(cnt / ch.n)}</td><td>${gs.length ? gs.map(q => `<span class="grp${ch.pol === 'hold' ? ' g2' : ''}">${q.i0 === q.i1 ? fsx(q.i0) + ' s' : fsx(q.i0) + '–' + fsx(q.i1) + ' s ' + (q.i1 - q.i0 === 1 ? 'double' : q.i1 - q.i0 === 2 ? 'triple' : '×' + (q.i1 - q.i0 + 1))}</span>`).join('') : '<span class="mut">no Nut frame in your window</span>'}</td></tr>`;
    });
    return `<div class="rfcsel" style="margin-top:8px"><b>${esc(l.name)}'s timings</b> (${l.timings.length}): the same dog line reached a little earlier or later along the route, so at your stop its dog is a few frames ahead or behind and its Nut frames move with it. ` +
      `Each timing on its own has exact Nut frames — singles, doubles, triples, as freestyle shows once the dog is tuned. Click one to mark its frames on the chart (▲).</div>` +
      `<table><tr><th>timing</th><th title="share of ${esc(l.name)}'s arrivals with this timing">share</th><th title="the window's odds on this line with this timing">on it</th><th>its Nut frames in your window (${ch.pol === 'hold' ? 'bite 2' : 'bite 1'})</th></tr>${rows.join('')}</table>` +
      (l.timings.length > 14 ? `<div class="mut small">${l.timings.length - 14} rarer timings (${pct(l.timings.slice(14).reduce((q, t) => q + t.w, 0))} of ${esc(l.name)}) not listed.</div>` : '');
  }
  function redraw() {
    const d = $('rfChartDlg'), cv = $('rfcCanvas');
    dlgCur.marks = dlgCur.focus != null && dlgCur.tm != null ? marksOf(dlgCur.ch, dlgCur.ch.lines[dlgCur.focus], dlgCur.tm) : null;
    dlgCur.L = paintBig(cv, dlgCur.ch, dlgCur);
    /* v32.3 (Thomas 18:52: "a little jittery on the left and right side"): the dialog is as wide as the chart, fixed;
       before, the one-line mouse readout under the chart set its width, and every new readout re-centred it */
    const w = Math.min(Math.floor(root.innerWidth * 0.96), dlgCur.L.W + 30);
    if (d.style.width !== w + 'px') d.style.width = w + 'px';
    renderLines();
  }
  function readout(i) {
    const ch = dlgCur.ch, inW = i >= ch.st - ch.a && i < ch.st - ch.a + ch.n, V = dlgCur.L && dlgCur.L.filt ? dlgCur.L.view : ch;
    $('rfcRead').innerHTML = i != null && i >= 0 && i < ch.s1.length ? `${fsec(ch.a + i).toFixed(2)} s after Jack stops${inW ? ' <b>(in your window)</b>' : ''} · ` +
      `<span style="color:${COL1}">Nut on bite 1: ${pct(V.s1[i])}</span> · <span style="color:${COL2}">on bite 2: ${pct(V.s2[i])}</span> of ${V === ch ? 'these arrivals' : 'the arrivals shown'}, B pressed in this game frame` +
      (V === ch ? ` · ${ch.lines.filter(l => hasNut(l, i)).length} dog line(s)` : '') : '';
  }
  function openChart(x) {
    let d = $('rfChartDlg');
    if (!d) {
      ensureStyle();
      d = document.createElement('dialog'); d.id = 'rfChartDlg';
      d.innerHTML = '<div class="rfch"><b id="rfcTitle"></b><button id="rfcClose" title="Close (Esc)">✕</button></div><div id="rfcSub" class="mut small"></div>' +
        `<div class="rflg"><span><i style="background:${COL1}"></i>Nut on bite 1 — let go at the 1st bite</span><span><i style="background:repeating-linear-gradient(135deg,${COL2} 0 2px,rgba(231,193,74,.35) 2px 5px)"></i>Nut on bite 2 — hold the 1st, let go at the 2nd</span>` +
        `<span><i style="background:rgba(111,183,255,.25);border:1px solid ${COLW}"></i>your 1-s window (white line: its odds)</span><span><i style="border-top:2px dashed #8ea3b2;height:0;width:14px;vertical-align:3px"></i>1 in 51</span>` +
        `<label style="margin-left:auto;cursor:pointer" title="Off: a clicked candle, line or timing shows only its own candles (as freestyle once it knows the dog). On: every candle stays and the other dog lines dim."><input type="checkbox" id="rfcKeep"> keep every candle when I click (dim the other lines)</label></div>` +
        '<canvas id="rfcCanvas"></canvas><div id="rfcRead" class="mut"></div><div id="rfcLines"></div><div id="rfcNote" class="mut small"></div>';
      document.body.appendChild(d);
      $('rfcClose').onclick = () => d.close();
      $('rfcKeep').onchange = e => { S.keepAll = !!e.target.checked; save(); if (dlgCur) { dlgCur.keepAll = S.keepAll; redraw(); readout(dlgCur.sel); } e.target.blur(); };
      d.addEventListener('click', e => { if (e.target === d) d.close(); });
      const cv = $('rfcCanvas');
      const at = e => { const r = cv.getBoundingClientRect(), L = dlgCur.L; return { x: (e.clientX - r.left) * (L.W / r.width), y: (e.clientY - r.top) * (L.H / r.height), L }; };
      cv.addEventListener('mousemove', e => {
        if (!dlgCur) return;
        const p = at(e), i = Math.floor((p.x - p.L.L0) / p.L.pf), h = p.x >= p.L.L0 && i >= 0 && i < p.L.m ? i : null;
        if (h === dlgCur.hover) return;
        dlgCur.hover = h; dlgCur.L = paintBig(cv, dlgCur.ch, dlgCur); readout(h != null ? h : dlgCur.sel);
      });
      cv.addEventListener('mouseleave', () => { if (dlgCur) { dlgCur.hover = null; dlgCur.L = paintBig(cv, dlgCur.ch, dlgCur); readout(dlgCur.sel); } });
      cv.addEventListener('click', e => {
        if (!dlgCur) return;
        const p = at(e);
        if (p.x < p.L.L0) {                                      // a line's label: focus that line
          const row = p.L.rows.find(r => p.y >= r.y0 && p.y < r.y1);
          if (row && row.k !== 'rest') { dlgCur.focus = dlgCur.focus === row.k ? null : row.k; dlgCur.sel = null; dlgCur.tm = null; redraw(); }
          return;
        }
        const i = Math.floor((p.x - p.L.L0) / p.L.pf);
        if (i < 0 || i >= p.L.m) return;
        dlgCur.sel = dlgCur.sel === i ? null : i; dlgCur.focus = null; dlgCur.tm = null; redraw(); readout(dlgCur.sel);
      });
      d.addEventListener('keydown', e => {
        if (!dlgCur) return;
        if ((e.key === 'ArrowLeft' || e.key === 'ArrowRight') && dlgCur.sel != null) {
          e.preventDefault();
          dlgCur.sel = Math.max(0, Math.min(dlgCur.ch.s1.length - 1, dlgCur.sel + (e.key === 'ArrowLeft' ? -1 : 1)));
          redraw(); readout(dlgCur.sel);
        }
      });
      d.addEventListener('cancel', e => {                        // Esc: first clears a clicked candle / line, then closes
        if (dlgCur && (dlgCur.sel != null || dlgCur.focus != null)) { e.preventDefault(); dlgCur.sel = null; dlgCur.focus = null; dlgCur.tm = null; redraw(); readout(null); }
      });
    }
    const ch = x.ch, k = ch.pol === 'hold' ? 's2' : 's1';
    const hits = ch[k].slice(ch.st - ch.a, ch.st - ch.a + ch.n).filter(v => v > 0).length;
    $('rfcTitle').innerHTML = x.title; $('rfcSub').innerHTML = x.sub;
    $('rfcNote').innerHTML = `One column per game frame (1/30 s), ${fx(fsec(ch.a), 1)}–${fx(fsec(ch.a + ch.s1.length - 1), 1)} s after Jack stops. Top: the share of this row's arrivals that catch the Power Nut when B is pressed in that frame. ` +
      `Below: the dog lines of this row, heaviest first (strip height = share); in each strip a bar = the share of that line's own timings that catch the Nut in that frame (full height: all of them). ` +
      `In your window ${hits} of ${ch.n} frames carry a Nut ${ch.pol === 'hold' ? 'on bite 2' : 'on bite 1'}; B pressed anywhere in it, ${pct(ch.p)} of these arrivals catch it. ` +
      `A line's timings: the same dog line reached a little earlier or later on the route, so its Nut frames sit at slightly different stopwatch times; on the Lucky Timer, tuning the dog in freestyle pins one of them. Same lab tables as the row's odds.`;
    dlgCur = { ch, hover: null, sel: null, focus: null, tm: null, keepAll: !!S.keepAll };
    $('rfcKeep').checked = !!S.keepAll;
    readout(null);
    redraw();
    if (!d.open) d.showModal();
  }
  const thumb = id => (CH.has(id) ? `<canvas class="rfthumb" data-ch="${id}" title="What you cast into: click for the close-up"></canvas>` : '');

  /* ---------------------------------------------------------------- drawing */
  const dog = (b, d, px) => (b == null ? '' : `<img class="rfdog" style="width:${px || 40}px;height:${px || 40}px" alt="" src="${(DATA.sprites && DATA.sprites[b + '_' + d]) || ''}">`);
  const what = (b, d) => (b == null ? 'not in the tables' : `<b>${esc(nameOf(b))}</b> <span class="rfdir">${ARROW[d]} ${DIRN[d]}</span>`);
  const POLTXT = { bite1: 'let go at the <b>1st</b> bite', hold: 'hold the 1st bite, let go at the <b>2nd</b>' };
  let leadS = 20;
  const perNut = (t, p) => (p > 0 ? `${fx((RESET_S + leadS + secs(t)) / p / 60, 1)} min/Nut` : '');
  function castCell(c, id) {
    if (!c) return '<span class="mut">…</span>';
    const s = c[c.simple], z = c.zone, q = c.quick;
    /* v31.10 (Thomas 2026-11-20 22:49: the "first cast worth 10%" choice belongs here, where the decision is made in a
       second or two, not in the Lucky Timer): S.aim decides which of the two casts is the row's MAIN one - shown
       first, outlined, and what a click anywhere on the row puts on the stopwatch. */
    const fl = shown ? shown.quick : S.quick, qMain = S.aim === 'quick' && !!q;
    const best = `<div class="rfbest ${qMain ? 'rfalt' : 'rfmain'}"><span class="rftag">best odds</span> <button class="rfcast${qMain ? '' : ' main'}" data-t="${s.t}" data-id="${id}" title="Show this cast on the stopwatch">${fx(secs(s.t), 1)} s</button> ${POLTXT[c.simple]} <b>${pct(s.p)}</b> <span class="mut">${perNut(s.t, s.p)}</span></div>`;
    const quick = q ? `<div class="rfquick ${qMain ? 'rfmain' : 'rfalt'}"><span class="rftag">quick</span> <button class="rfcast${qMain ? ' main' : ''}" data-t="${q.t}" data-id="${id}" title="The first cast worth ${fl}% or more: show it on the stopwatch">${fx(secs(q.t), 1)} s</button> ${POLTXT[q.pol]} <b>${pct(q.p)}</b> <span class="mut">${perNut(q.t, q.p)}</span></div>`
      : `<div class="rfquick none"><span class="rftag">quick</span> <span class="mut">${s.p >= fl / 100 ? 'the best cast is the first one worth it' : 'nothing reaches ' + fl + '%'}</span></div>`;
    let h = qMain ? quick + best : best + quick;
    if (isLate(s.t) && !qMain) h += `<div class="rfclock">Cast after 40 s: push the stick ↘ ${pushWhen(s.t)}, or Jack lies down (never push after casting).</div>`;   // v31.30
    if (z && z.p >= s.p + 0.02 && z.zones.length) {
      h += `<div class="rfclock">by the clock: <button class="rfcast lite" data-t="${z.t}" data-id="${id}" data-z="${z.zones.map(w => w.join('-')).join(',')}">${fx(secs(z.t), 1)} s</button> <b>${pct(z.p)}</b> — let go at the 1st bite only if it comes at ` +
        z.zones.map(w => `${fx(secs(w[0]), 1)}–${fx(secs(w[1]), 1)} s`).join(' or ') + `, else hold for the 2nd</div>`;
    }
    return h;
  }
  const linesCell = ls => (ls[0].p >= 0.9 ? `<b class="rfline">${ls[0].name}</b>` + (ls[0].p < 0.995 ? ` <span class="mut">${pct(ls[0].p)}</span>` : '')
    : ls.slice(0, 3).map(l => `${l.name} <span class="mut">${pct(l.p)}</span>`).join(' · ') + (ls.length > 3 ? ` <span class="mut">+${ls.length - 3}</span>` : ''));
  let shown = null;
  function draw(o, frac) {
    shown = o;
    if (o && o.lead) leadS = o.lead;
    const el = $('rfBody');
    if (!o) { el.innerHTML = '<div class="mut">This route has no dog traces.</div>'; return; }
    const A = o.arrive.filter(r => r.share >= 0.003), rest = o.arrive.filter(r => r.share < 0.003);
    const sure = A.filter(r => r.lines[0].p >= 0.9).reduce((q, r) => q + r.share, 0);
    let h = `<div class="rfnote">${frac < 1 ? `working out the casts… ${Math.round(100 * frac)}%` : `<b>If you cannot tell the dog at all</b> (timing spread ±${o.sigMs} ms): ` + (o.all ? castCell(o.all, 'all') : '—') +
      `<div class="rfzero"><b>Every time on this page is counted from the moment Jack stops at the end of the dock</b> — the moment you press Space and the stopwatch starts at 0.0. ${S.sparrow && sparOf(S.route) ? '<b style="color:#ffd28a">Sparrows at the door: the table for menus 5–6 frames late.</b>' : (sparOf(S.route) ? 'No sparrows at the door: the table for menus 0–4 frames late (press S if the pair sits at the door).' : '')}</div>` +
      `<div class="mut">Every row gives two casts, in seconds after Jack stops: <b>best odds</b> = the most likely Nut for that dog; <b>quick</b> = the first cast worth ${o.quick}% or more (at least 1 s sooner). You aim for <b>${S.aim === 'quick' ? 'the quick one' : 'best odds'}</b>: that cast is outlined, and a click anywhere on a row puts it on the stopwatch. min/Nut = minutes of play per Nut if you always took that cast: an attempt counted as ${RESET_S} s up to the beach fade-in (as in the Lucky Timer) + ${fx(o.lead, 0)} s across the beach to the pier end + the wait.</div>`}</div>`;
    const head = h;
    h = `<h3>What is the dog doing as you stop at the pier end?</h3>
      <div class="mut">Look at the dog half a second after Jack stops. ${pct(sure)} of arrivals show something that names the line by itself (bold line number).</div>
      <table class="rftab"><tr><th></th><th>the dog</th><th>how often</th><th>your line</th><th>cast, counted from the moment Jack stops</th></tr>` +
      A.map((r, i) => `<tr class="${r.lines[0].p >= 0.9 ? 'sure' : ''}"><td>${dog(r.base, r.dir)}</td><td>${what(r.base, r.dir)}</td><td class="num">${pct(r.share)}</td><td>${linesCell(r.lines)}</td><td>${castCell(r.cast, 'a' + i)}</td></tr>` +
        r.split.map((s, j) => `<tr class="sub"><td></td><td colspan="2">↳ if it is <b>${s.name}</b> <span class="mut">(${pct(s.p)})</span>` +
          (s.next ? `, ${s.only ? 'only it then does' : 'next (the others too)'}: ${dog(s.next.base, s.next.dir, 26)} ${what(s.next.base, s.next.dir)} at <b>${fx(Math.max(0, s.next.t) * VI() / 1000, 1)} s</b>` : '') + `</td><td>${s.name}</td><td>${castCell(s.cast, 'a' + i + 's' + j)}</td></tr>`).join('')).join('') +
      `</table>` + (rest.length ? `<div class="mut">Rarer (${pct(rest.reduce((q, r) => q + r.share, 0))} together): ${rest.slice(0, 14).map(r => `${esc(nameOf(r.base))} ${r.dir != null ? DIRN[r.dir] : ''}`).join(', ')}${rest.length > 14 ? ' …' : ''}.</div>` : '');
    const pArrive = h;
    h = `<h3>Harbingers: one thing the dog does that names the line</h3>
      <div class="mut">In the first 10 s after you stop. "Sure" = the share of arrivals showing this, then, that are on that line. Lines already named by what the dog does as you stop (the “As you stop” tab) are left out.</div>` +
      (o.harb.length ? `<table class="rftab"><tr><th></th><th>the dog starts to</th><th>about when</th><th>how often</th><th>line</th><th>sure</th><th>cast, counted from the moment Jack stops</th></tr>` +
        o.harb.map((r, i) => `<tr><td>${dog(r.base, r.dir)}</td><td>${what(r.base, r.dir)}</td><td class="num">${fx(r.t * VI() / 1000, 1)} s</td><td class="num">${pct(r.share)}</td><td><b class="rfline">${r.line}</b></td><td class="num">${pct(r.pure)}</td><td>${castCell(r.cast, 'h' + i)}</td></tr>`).join('') + `</table>`
        : `<div class="mut">None beyond the first table.</div>`);
    const pHarb = h;
    h = `<h3>What each line's dog does in the first 10 seconds after you stop, and its cast</h3>
      <div class="mut">Most common line first. Find the row whose dog does what yours does; the times are seconds on the stopwatch.</div>
      <table class="rftab"><tr><th>line</th><th>how often</th><th>the dog, from the moment you stop (seconds)</th><th>cast when you know the line</th></tr>` +
      o.lines.map((r, i) => `<tr><td><b class="rfline">${r.name}</b></td><td class="num">${pct(r.share)}</td><td class="rfseq">${r.seq.map(q => `<span>${dog(q.base, q.dir, 30)}<i>${fx(q.t * VI() / 1000, 1)}</i> ${esc(nameOf(q.base))} ${ARROW[q.dir]}</span>`).join('')}</td><td>${castCell(r.cast, 'l' + i)}</td></tr>`).join('') + `</table>
      <div class="mut">${o.lines.length} of this table's ${o.nLines} dog lines are listed (0.4% of arrivals or more, with a cast table).</div>`;
    const pLines = h;
    /* v31.30 (Thomas 2026-11-23: "simple and direct. If you see x at y cast at z for odds%") */
    const one = p => (p > 0 ? `1 in ${1 / p < 10 ? (1 / p).toFixed(1) : Math.round(1 / p)}` : '');
    const bwin = (w, id, lab) => (!w ? '<span class="mut">…</span>' : `<button class="rfcast main" data-t="${w.t}" data-id="${id}" title="Show this cast on the stopwatch">${fx(secs(w.t), 1)} s</button> <span class="mut">(${fx(secs(w.lo), 1)}–${fx(secs(w.hi), 1)})</span>`);
    const bodds = w => (!w ? '' : `<b>${pct(w.p)}</b> <span class="mut">${one(w.p)}</span>`);
    const BL = o.blind || { rows: [], none: {}, all: {} };
    const sx = v => String(Math.round(v * 10) / 10);
    const between = r => `${sx(Math.max(LOOK_VI, Math.min(...r.bins) * HARB_BIN) * VI() / 1000)}–${sx(Math.min(HARB_UNTIL, (Math.max(...r.bins) + 1) * HARB_BIN) * VI() / 1000)} s`;
    const pushTag = w => (w && isLate(w.t) ? `<div class="rfclock">+ push the stick ↘ ${pushWhen(w.t)}</div>` : '');
    CH.clear();                                                   // v32.2: the window thumbnails of this table
    const rl = (C.routeOf(curRoute()) || {}).label || '';
    const chTitle = w => `Cast at ${fx(secs(w.t), 1)} s <span class="mut">(${fx(secs(w.lo), 1)}–${fx(secs(w.hi), 1)} s)</span> · ${POLTXT[w.pol]} · Power Nut ${pct(w.p)}`;
    BL.rows.forEach((r, i) => { if (r.chart) CH.set('b' + i, { ch: r.chart, title: chTitle(r.win), sub: `If the dog starts ${what(r.base, r.dir)} between ${between(r)} · ${r.nLines || r.chart.lines.length} dog line${(r.nLines || r.chart.lines.length) === 1 ? '' : 's'} · ${esc(rl)}` }); });
    if (BL.none.chart) CH.set('bn', { ch: BL.none.chart, title: chTitle(BL.none.win), sub: `None of the listed behaviours by 10 s · ${BL.none.chart.lines.length} dog lines · ${esc(rl)}` });
    if (BL.all.chart) CH.set('ba', { ch: BL.all.chart, title: chTitle(BL.all.win), sub: `Not watching the dog at all · every arrival of this table (${BL.all.chart.lines.length} dog lines) · ${esc(rl)}` });
    h = `<h3>Optimal Blind Casting</h3>
      <div class="mut">Press <kbd>Space</kbd> the moment Jack stops at the end of the pier and watch the dog for 10 s. If it starts one of these, cast at the time shown — anywhere in that second — and let go of B as the row says. Click a row to put its cast on the stopwatch.</div>
      <table class="rftab rfblind"><tr><th></th><th>if the dog starts</th><th>between</th><th>cast at</th><th>what you cast into</th><th>let go of B</th><th>Power Nut</th></tr>` +
      BL.rows.map((r, i) => `<tr><td>${dog(r.base, r.dir)}</td><td>${what(r.base, r.dir)}</td><td class="num">${between(r)}</td><td>${bwin(r.win, 'b' + i)}${pushTag(r.win)}</td><td>${thumb('b' + i)}</td><td>${r.win ? POLTXT[r.win.pol] : ''}</td><td class="num">${bodds(r.win)}</td></tr>`).join('') +
      `<tr><td></td><td><b>none of these</b></td><td class="num">by 10 s</td><td>${bwin(BL.none.win, 'bn')}${pushTag(BL.none.win)}</td><td>${thumb('bn')}</td><td>${BL.none.win ? POLTXT[BL.none.win.pol] : ''}</td><td class="num">${bodds(BL.none.win)}</td></tr></table>` +
      (BL.all.win ? `<div class="mut" style="display:flex;gap:10px;align-items:center">${thumb('ba')}<span>Not watching the dog at all: cast at <b>${fx(secs(BL.all.win.t), 1)} s</b> (${fx(secs(BL.all.win.lo), 1)}–${fx(secs(BL.all.win.hi), 1)}), ${POLTXT[BL.all.win.pol]}: <b>${pct(BL.all.win.p)}</b> (${one(BL.all.win.p)}).</span></div>` : '') +
      `<div class="mut">Every time counts from the moment Jack stops. ${PUSH_TXT} The odds are the share of the lab's arrivals on this table that show what the row says and land the Power Nut with B pressed anywhere in that second (1/51 = 2% for comparison). The same harbingers, with a cast aimed to a fraction of a second, are on the Harbingers tab.</div>` +
      `<div class="mut">What you cast into: the cast histogram of the row's arrivals from 2 s before its window to 2 s after, one column per game frame (green = Nut on bite 1, gold = Nut on bite 2 holding the 1st; blue = the window, white = its odds). Click one for the close-up with every dog line of the row.</div>`;
    const pBlind = h;
    h = pLines;
    const P = { blind: pBlind, lines: h, arrive: pArrive, harb: pHarb };
    if (!TABS.some(t => t[0] === S.tab)) S.tab = 'lines';
    el.innerHTML = head + `<div class="rftabs">` + TABS.map(([id, txt]) => `<button data-tab="${id}" class="${id === S.tab ? 'on' : ''}">${txt}</button>`).join('') + `</div>` +
      TABS.map(([id]) => `<div class="rfpane" data-pane="${id}"${id === S.tab ? '' : ' hidden'}>${P[id]}</div>`).join('');
    for (const b of el.querySelectorAll('.rftabs button')) b.onclick = () => {
      S.tab = b.dataset.tab; save();
      for (const x of el.querySelectorAll('.rftabs button')) x.classList.toggle('on', x === b);
      for (const x of el.querySelectorAll('.rfpane')) x.hidden = x.dataset.pane !== S.tab;
      b.blur();
    };
    for (const b of el.querySelectorAll('.rfcast')) b.onclick = ev => { ev.stopPropagation(); setTarget(+b.dataset.t, b.dataset.z || '', b.closest('tr')); };
    if (el.querySelector('canvas.rfthumb')) ensureStyle();
    for (const cv of el.querySelectorAll('canvas.rfthumb')) {     // v32.2
      const x = CH.get(cv.dataset.ch); if (!x) continue;
      try { paintThumb(cv, x.ch); } catch (e) { /* no canvas */ }
      cv.onclick = ev => { ev.stopPropagation(); openChart(x); };
    }
    for (const tr of el.querySelectorAll('.rftab tr')) { const m = tr.querySelector('.rfcast.main'); if (m) tr.onclick = () => m.click(); }   // a click on the row = its main cast
    if (frac >= 1 && T.target === null && o.all) { const m = el.querySelector('.rfnote .rfcast.main'); if (m) setTarget(+m.dataset.t, '', null); }   // until a row is clicked: the cast for "cannot tell the dog"
  }

  /* ---------------------------------------------------------------- the stopwatch */
  const T = { t0: null, target: null, zones: [], label: '' };
  function setTarget(t, z, tr) {
    T.target = t; T.zones = z ? z.split(',').map(w => w.split('-').map(Number)) : [];
    T.label = tr ? (tr.querySelector('.rfline') ? tr.querySelector('.rfline').textContent + ' · ' : '') + (tr.cells[1] ? tr.cells[1].textContent.trim().slice(0, 40) : '') : '';
    for (const x of document.querySelectorAll('#rfBody tr.on')) x.classList.remove('on');
    if (tr) tr.classList.add('on');
    tick();
  }
  function start(at) { T.t0 = at - S.delay; tick(); }
  function reset() { T.t0 = null; tick(); }
  function tick() {
    const el = $('rfClock'); if (!el) return;
    const run = T.t0 !== null, s = run ? (performance.now() - T.t0) / 1000 : 0;
    el.textContent = run ? s.toFixed(1) : '0.0';
    const tg = T.target !== null ? secs(T.target) : null, left = tg !== null ? tg - s : null;
    const box = $('rfTimer');
    box.classList.toggle('run', run);
    box.classList.toggle('soon', run && left !== null && left <= 3 && left > 0);
    box.classList.toggle('go', run && left !== null && left <= 0 && left > -0.6);
    $('rfTarget').innerHTML = tg === null ? 'Click a cast time in the tables to show it here.'
      : `Cast at <b>${fx(tg, 1)} s</b>` + (T.label ? ` <span class="mut">(${esc(T.label)})</span>` : '') +
        (run ? (left > 0 ? ` — in <b>${left.toFixed(1)} s</b>` : left > -0.6 ? ' — <b>CAST</b>' : ` — ${(-left).toFixed(1)} s ago`) : '') +
        (T.zones.length ? `<br>1st bite at ${T.zones.map(w => `${fx(secs(w[0]), 1)}–${fx(secs(w[1]), 1)} s`).join(' or ')}: let go. Any other time: hold for the 2nd.` : '');
    if (tg !== null && tg > NAP_S) {                              // v31.30: the stay-awake push(es) for a cast after 40 s
      const two = tg > NAP2_S, near = x => run && s >= x - 1 && s < x + 2.5 && left > 0;
      $('rfTarget').innerHTML += near(WAKE_S) || (two && near(WAKE2_S)) ? ' — <b style="color:#ff9a6a">PUSH THE STICK ↘ NOW</b>'
        : `<br><span class="mut">Push the stick ↘ ${two ? `at about ${WAKE_S.toFixed(0)} s and again at about ${WAKE2_S.toFixed(0)} s` : `once at about ${WAKE_S.toFixed(0)} s`}, or Jack lies down.</span>`;
    }
    $('rfBar').style.width = tg && run ? Math.max(0, Math.min(100, 100 * s / tg)) + '%' : '0%';
    $('rfHint').textContent = run ? 'Space = start again · Esc = stop' : 'Press Space the moment Jack stops at the end of the pier.';
  }
  function loop() { if (root.HM64Arena !== 'lucky' && T.t0 !== null) tick(); }
  document.addEventListener('keydown', e => {
    if (root.HM64Arena === 'lucky' || document.querySelector('dialog[open]')) return;
    const tg = e.target && e.target.tagName;
    if (tg === 'INPUT' || tg === 'SELECT' || tg === 'TEXTAREA') { if (e.key === 'Escape') e.target.blur(); if (tg !== 'SELECT' || e.code !== 'Space') return; }
    if (e.code === 'Space') { e.preventDefault(); if (!e.repeat) start(typeof e.timeStamp === 'number' && e.timeStamp > 0 ? e.timeStamp : performance.now()); }
    else if (e.key === 'Escape') { e.preventDefault(); reset(); }
    else if ((e.key === 's' || e.key === 'S') && !e.ctrlKey && !e.metaKey && !e.altKey && sparOf(S.route)) { e.preventDefault(); if (!e.repeat) setSparrow(!S.sparrow); }
  });

  /* ---------------------------------------------------------------- the page */
  function build() {
    { const cur = routes().find(r => r.id === S.route); if (cur && cur.variant_of) { S.route = cur.variant_of; S.sparrow = cur.variant === 'sparrows'; } }   // a stored variant table -> its main table + the box
    const rs = bases();
    if (!rs.some(r => r.id === S.route)) S.route = (rs[0] || {}).id || null;
    if ($('rfSpar')) { const b = $('rfSpar'); b.checked = !!(S.sparrow && sparOf(S.route)); b.disabled = !sparOf(S.route); b.onchange = e => { setSparrow(e.target.checked); e.target.blur(); }; }
    $('rfRoute').innerHTML = rs.map(r => `<option value="${r.id}">${esc(r.label || r.id)}</option>`).join('');
    $('rfRoute').value = S.route || '';
    $('rfSig').value = String(S.sig); $('rfDelay').value = S.delay;
    $('rfRoute').onchange = e => { S.route = e.target.value; if (!sparOf(S.route)) S.sparrow = false; if ($('rfSpar')) { $('rfSpar').disabled = !sparOf(S.route); $('rfSpar').checked = !!S.sparrow; } save(); e.target.blur(); refresh(); };
    $('rfSig').onchange = e => { S.sig = +e.target.value || 150; save(); e.target.blur(); refresh(); };
    if ($('rfAim')) { $('rfAim').value = S.aim === 'quick' ? 'quick' : 'odds'; $('rfAim').onchange = e => { S.aim = e.target.value === 'quick' ? 'quick' : 'odds'; save(); e.target.blur(); T.target = null; T.zones = []; T.label = ''; if (shown) draw(shown, 1); tick(); }; }
    if ($('rfQuick')) { if (![5, 8, 10, 12, 15].includes(+S.quick)) S.quick = 10; $('rfQuick').value = String(S.quick); $('rfQuick').onchange = e => { S.quick = +e.target.value || 10; save(); e.target.blur(); refresh(); }; }
    $('rfDelay').onchange = e => { S.delay = Math.max(0, Math.min(600, +e.target.value || 0)); save(); };
    $('rfStart').onclick = e => { start(performance.now()); e.target.blur(); };
    $('rfReset').onclick = e => { reset(); e.target.blur(); };
    $('rfPrint').onclick = () => root.print();
  }
  let built = false, want = null;
  function refresh() {
    if (!S.route) { draw(null, 1); return; }
    T.target = null; T.zones = []; T.label = '';
    const rid = curRoute();
    want = rid + '|' + S.sig + '|' + S.quick;
    const same = o => want === o.routeId + '|' + o.sigMs + '|' + o.quick;
    analyse(rid, S.sig, (o, f) => { if (same(o)) draw(o, f); }, o => { if (!o || same(o)) draw(o, 1); tick(); }, S.quick);
  }
  /* v31.7 (Thomas 2026-11-20 21:06: "prevent dog reference from loading its assets and slowing the page down if it
     isn't selected"). Nothing of this page exists until its tab is opened; when the Lucky Timer is selected again the
     unfinished cast search is dropped, the stopwatch interval is stopped and the tables (several hundred dog sprites)
     are taken out of the page. Finished results stay in `cache`, so coming back redraws at once. */
  let iv = null, active = false;
  function show() {
    if (!built) { built = true; build(); }
    if (!active) { active = true; iv = setInterval(loop, 33); refresh(); }
    tick();
  }
  function hide() {
    if (!active) return;
    active = false; job++; want = null;                           // drops a running analysis (its steps check `job`)
    if (iv !== null) { clearInterval(iv); iv = null; }
    T.t0 = null;
    const el = $('rfBody'); if (el) el.innerHTML = '';
    shown = null;
  }
  root.HM64DogRef = { show, hide, setSparrow, curRoute, get active() { return active; }, analyse, ctx, refresh, state: S, timer: T, start, reset, setTarget, get shown() { return shown; }, openChart: id => (CH.has(id) ? openChart(CH.get(id)) : null), charts: CH, get closeup() { return dlgCur; },
    /* v32.3 test hook: per chart, the largest gap between a line's drawn Nut fractions and its timings' exact frames
       weighted by their shares (must be ~0) */
    checkTimings: () => [...CH.entries()].map(([id, x]) => { let worst = 0; for (const l of x.ch.lines) { const a = new Float64Array(x.ch.s1.length), b = new Float64Array(x.ch.s1.length); for (const t of l.timings) { const mk = marksOf(x.ch, l, t.o); for (let i = 0; i < a.length; i++) { a[i] += t.w * mk.b1[i]; b[i] += t.w * mk.b2[i]; } } for (let i = 0; i < a.length; i++) worst = Math.max(worst, Math.abs(a[i] - l.f1[i]), Math.abs(b[i] - l.f2[i])); } return [id, x.ch.lines.length, +worst.toExponential(2)]; }) };

  /* the old Dog Oracle parts of "How it works" go; this page gets its own paragraph */
  const GONE = ['Dog paths.', 'Your keys and names.', 'Scrub bar (03).', 'Tap search.', 'Flickers.', 'Logging.', 'Potential dogs.', 'Histogram.', 'Line-up methods (03).', 'After the cast', 'Two arenas'];
  const hb = $('helpBtn'), old = hb && hb.onclick;
  if (hb && old) hb.onclick = ev => {
    old.call(hb, ev);                                             // fills helpBody with the page's text and opens it
    const parts = $('helpBody').innerHTML.split(/(?=<p><b>)/).filter(p => !GONE.some(g => p.startsWith('<p><b>' + g)));
    const mine = `<p><b>Dog reference.</b> A manual method: no keys to log, nothing learned, nothing stored but three settings. Four tabs. <i>Optimal Blind Casting</i> (the first page): if the dog does one of the listed things in the first 10 s after Jack stops, cast at the time shown — anywhere in that second — and let go at the bite it says; the odds are those of a cast anywhere in that second. <i>First 10 seconds, by line</i>: every dog line, most common first, with what its dog does in the first 10 s after Jack stops and the cast with the best Power Nut odds for it, counted from the moment Jack stops. <i>As you stop</i>: what the dog is doing half a second after Jack stops, how often, which line that means, and the cast. <i>Harbingers</i>: one thing the dog starts doing in the first 10 s that names a line. Casts reach 75 s after Jack stops (the Power Nut ends there); a cast after 40 s needs one push of the stick ↘ at about 33 s (a cast after 73 s a second one at about 67 s), or Jack lies down. A cast comes with its rule — let go at the 1st bite, or hold it and let go at the 2nd — and, where it is worth 2 points or more, a rule by the clock: let go at the 1st bite only if it comes inside the listed times. <kbd>Space</kbd> when Jack stops starts the stopwatch (your reaction, 150 ms unless you change it, is taken off); click a cast time and the stopwatch counts down to it; <kbd>Esc</kbd> stops. The odds assume your B press is off by the timing spread you choose; they come from the lab tables and are not measured on a console.</p>`;
    $('helpBody').innerHTML = parts[0] + mine + parts.slice(1).join('');
  };
  if (root.HM64Arena !== 'lucky') show();
})(typeof window !== 'undefined' ? window : globalThis);
