HM64 Power Nut Tool v32.3 (2026-11-23) — the close-up: steady, and dig into a window
======================================================================================

What you asked for (18:52)
  1. "the popup window is a little jittery on the left and right side when i scroll my mouse over the green lines"
  2. "another feature that shows what doglines are in the section and if you click a candle it highlights the ones in
     that group and dims the others ... see the granular details that get shown in the freestyle mode that make up
     the zone"

1. The jitter: found and fixed
  - Cause: the close-up dialog sized itself to its widest line, and the widest line was the one-line mouse readout
    under the chart ("62.21 s after Jack stops · Nut on bite 1: 26% ..."). Its length changes with every frame you
    point at (numbers of different widths, "(in your window)" or not), so the dialog grew and shrank by ~43 px and
    the browser re-centred it: both edges jumped about 21 px. Measured in the sandbox (1400 px window, 200 mouse
    moves): v32.2 = 2 different dialog boxes (912 / 955 px wide), v32.3 = 1.
  - Fix: the dialog is exactly as wide as the chart; the readout wraps inside a fixed 2-line box; the line list has
    a fixed height and scrolls. Checked: hovering, clicking candles, focusing lines and picking timings leave the
    dialog box unchanged (1 box over 60 steps on both pages).

2. Dig into a window
  - Click a candle: the dog lines with a Nut in that game frame stay lit (strips and labels), the others dim; the
    candle gets a white outline. The list under the chart: per line its share of the row, the points it adds to the
    window's odds (they add up to the row's odds exactly), its odds if you are on it, its Nut frames in the window,
    its value in the clicked frame and its runs of neighbouring Nut frames. <- / -> step one game frame; Esc clears,
    a second Esc closes.
  - Click a line (list row or its label on the chart): its part of every candle is drawn white inside the bars,
    and its timings are listed. A timing = the same dog line reached a little earlier or later along the route (the
    dog a few frames ahead or behind at your stop). Each timing has exact Nut frames - singles, doubles, triples - the
    groups freestyle shows once the dog is tuned. Click a timing: its frames are marked on the chart (white
    triangles under the histogram, white outlines on the line's strip).
  - Checked: for every chart on both pages, every line's timings weighted by their shares give back the line's
    drawn Nut fractions (largest gap 1e-7, float rounding); a clicked candle lights exactly the lines with a Nut
    there; the casting tables' numbers are unchanged (same checksum as v32.1 / v32.2).

Files (lab_changes/, cumulative)
  webapp/hm64_dogref_v31.js   the close-up (paintBig, the line list, timings, the fixed dialog), per-line timings in chartOf
  webapp/site/site.json       version v32.3
  tests/ui_closeup.js         dialog box steady while hovering; candle -> lit lines = lines with a Nut there; adds-up; keys
  tests/ui_timings.js         timings x shares = the line's drawn fractions, every chart
  (and v32.2's tests/ui_thumbs.js, tests/ui_shown.js)

Not tested
  - Firefox and touch screens (Esc handling uses the dialog's standard cancel event).

Release
  bash ~/Documents/hm64/tools/hm64_release.sh v32-3 <lab sha256> <pages sha256> </dev/null
