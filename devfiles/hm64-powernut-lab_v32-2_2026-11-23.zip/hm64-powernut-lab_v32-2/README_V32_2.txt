HM64 Power Nut Tool v32.2 (2026-11-23) — what you cast into
=============================================================

What you asked for (18:26)
  "a tiny image of the moment in time on the histogram that makes it the most favourable ... small rectangular
  thumbnails that, when clicked, expand to show the green candles / gold candles and their density in the moment in
  time ... so people know what the window they're casting into looks like, and it doesn't feel so blind"

What changed
  - Casting tables, Optimal Blind Casting: a new column "what you cast into". Each row (and "none of these", and the
    "not watching the dog" line) has a 150 x 30 thumbnail: the cast histogram of that row's arrivals from 2 s before
    its 1-s window to 2 s after, one column per game frame. Green = Nut on bite 1, gold = Nut on bite 2 holding the
    1st (the row's own rule in front, the other behind at half strength), the window bright and the rest dimmed, a
    white line at the row's odds, 1 in 51 dashed.
  - Click a thumbnail: a close-up (Esc or x closes) with the histogram large (y = share of the row's arrivals), the
    window, its odds, 1/51, seconds after Jack stops on the axis, a readout under the mouse (time, Nut on bite 1 /
    bite 2 in that frame, in or out of the window), and below it every dog line of the row, heaviest first (strip
    height = share; up to 12 lines, the rest in one strip), each a small histogram of its own Nut frames (bar
    height = the share of that line's timings with a Nut there).
  - Drawn in the browser from the page's own tables, so every game-file page and every setting (spread, sparrows)
    has its own pictures; nothing is stored or added to the data. The rows' casts and odds are unchanged.

Files (lab_changes/, cumulative)
  webapp/hm64_dogref_v31.js     chartOf() (the numbers, kept with each blind row), thumbnails, the close-up dialog
  webapp/site/site.json         version v32.2
  tests/ui_thumbs.js            the thumbnails draw, one per row; the window average = the row's odds; the close-up opens
  tests/ui_shown.js             a checksum of the casting tables' numbers (without the pictures) to compare two pages

Checked (sandbox, headless Chrome)
  - Both casting pages: 11 / 13 thumbnails, one per row + "not watching"; no errors. For every row the average of the
    drawn bars across the window = the row's Power Nut odds, and the per-line strips weighted by line share add up to
    the same number (e.g. 27.503 / 27.503 / 27.503 %).
  - The casting tables' numbers (HM64DogRef.shown without the pictures) are byte-identical to v32.1 on both pages;
    only the Optimal Blind Casting tab's HTML grew (the column and one line of text).
  - Screenshots of the table and the close-up looked at (wiggle-bum, rollover, not watching on the horse page).
  - Lucky Timer pages: rebuilt for the version label only.

Not tested
  - Firefox (canvas + <dialog> are standard there), touch screens.

Release
  bash ~/Documents/hm64/tools/hm64_release.sh v32-2 <lab sha256> <pages sha256> </dev/null
