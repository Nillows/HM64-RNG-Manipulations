/* HM64 site pages (v32.0, Thomas 2026-11-23): the glue a generated page needs around the app's modules.
   The site = a hub (index.html) + one single-file page per game-file circumstance and page kind (Lucky Timer,
   Casting tables); HM64_PAGE (written by tools/site_build.py) says which page this is and where its neighbours are.
   - Lucky Timer page: the "How it works" text loses the paragraphs of pages that are gone (the old Dog Oracle, the
     two-arena footer; the Dog reference did this filtering while it lived on the same page) and gains "Pages".
   - Casting tables page: "How it works" opens with this page's paragraph; the Dog reference adds its own after it.
   Included on the Lucky Timer page AFTER the app (which sets the help button), on the casting page BEFORE the Dog
   reference (which wraps whatever the help button does). */
(function (root) {
  'use strict';
  const P = (typeof HM64_PAGE !== 'undefined' && HM64_PAGE) || null, $ = id => document.getElementById(id);
  if (!P || !$('helpBtn') || !$('helpBody') || !$('helpDlg')) return;
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const link = (href, txt) => (href ? `<a href="${esc(href)}">${esc(txt)}</a>` : '');
  const pages = `<p><b>Pages.</b> This page is the <i>${P.kind === 'lucky' ? 'Lucky Timer' : 'Casting tables'}</i> for
    <i>${esc(P.set_label)}</i>: it holds only that game file's tables. The ${link(P.hub, 'hub')} lists every game-file
    circumstance and its pages${P.kind === 'lucky' && P.casting ? '; the ' + link(P.casting, 'casting tables') + ' of this one hold the Dog reference and Optimal Blind Casting' : ''}${P.kind === 'casting' && P.lucky ? '; the ' + link(P.lucky, 'Lucky Timer') + ' of this one is the live tool' : ''}.
    Each page is one file: save it and it works offline. Your settings stay with the file in your browser.</p>`;
  if (P.kind === 'lucky') {
    /* v32.1 (Thomas 2026-11-23): the Spring 9 dog-carry and dog-beach routes are retired; the hub pages hold beach-lineup2
       and its permutations (weather, horse, ...), so their paragraphs go too and one Route paragraph for this page comes in */
    const GONE = ['Dog paths.', 'Your keys and names.', 'Scrub bar (03).', 'Tap search.', 'Flickers.', 'Logging.', 'Potential dogs.', 'Histogram.', 'Line-up methods (03).', 'After the cast', 'Two arenas',
                  'Lucky Timer: pace and start.', 'Lucky Timer: routes.'];
    const lr = (typeof HM64_DATA !== 'undefined' && HM64_DATA && HM64_DATA.lroutes) || [];
    const base = lr.find(r => !r.variant_of), spar = lr.some(r => r.variant === 'sparrows');
    const route = base ? `<p><b>Route.</b> This page has one route, ${esc(base.label)}: the dog left in the far
      south-west corner of the beach the day before, the zig-zag route, one Space tap when Jack stops at the end of the
      pier. ${spar ? 'Mornings with sparrows at the door (your menus 5–6 frames late) have a second table: tick <i>Sparrows at the door</i> in L1 (or press S) when you see them.' : 'No sparrows come to the farm on this morning, so there is one table for every menu speed.'}
      Attempts, taps, the start and the preset are kept per table. Another game file (weather, horse, ...) has its own page: see the hub.</p>` : '';
    const hb = $('helpBtn'), old = hb.onclick;
    if (old) hb.onclick = ev => {
      old.call(hb, ev);                                             // fills helpBody with the app's text and opens it
      const parts = $('helpBody').innerHTML.split(/(?=<p><b>)/).filter(p => !GONE.some(g => p.startsWith('<p><b>' + g)));
      $('helpBody').innerHTML = parts[0] + pages + route + parts.slice(1).join('');
    };
  } else if (P.kind === 'casting') {
    $('helpBtn').onclick = () => {
      $('helpBody').innerHTML = `<h2>How the casting tables work (${esc((typeof HM64_DATA !== 'undefined' && HM64_DATA && HM64_DATA.version) || '')})</h2>` + pages;
      $('helpDlg').showModal();
    };
  }
})(typeof window !== 'undefined' ? window : globalThis);
