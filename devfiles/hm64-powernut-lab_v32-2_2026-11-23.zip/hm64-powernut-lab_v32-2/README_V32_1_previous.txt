HM64 Power Nut Tool v32.1 (2026-11-23) — Sunny → Horse pages, beach-lineup2 only
==================================================================================

What you asked for
  17:00  "the sunny horse tables were attached in my last message, build those out into the page"
  17:24  "remove all the references to those old carry routes, and the routes for on dog-beach ... we are
          crystalizing beach lineup2 and its permutations"

What changed on the site
  - Sunny → Horse is ready: lucky-timer_sunny-horse.html (28 MB) and casting-tables_sunny-horse.html (27 MB), made
    from your horse run (124 dog lines, sparrow-door table 83 lines; casts to 120 s).
  - Every Lucky Timer page now has ONE route: beach-lineup2 for its game file (+ its sparrows-at-the-door table).
    The Spring 9 dog-carry route, the dog-beach routes and the two no-dog routes are gone from the pages, their plans
    and cast tables are no longer embedded (the no-horse Lucky Timer is 24 MB instead of 29 MB), and "How it works"
    drops the carry / dog-beach paragraphs for one "Route." paragraph about the page's own route.
    (The route tables are still in the lab's webapp/assets/lucky_routes.json; only the pages stopped using them.)
  - Settings are shared by every page of the site (one origin on GitHub Pages), so the route is now kept per page:
    a stored route the page does not have gives way to the page's own, and the page's starting route / pier start
    come from site.json ("defaults"). Your local file keeps its settings as before; a stored "carry" route becomes
    beach-lineup2 with the pier start.
  - Rainy → No horse / Horse show "Tables being collected" on the hub.
  - Fix in the cast pack (both packs): a bite's game state does not decide the NEXT bite's state (the hash holds
    something fishing never reads, while the time and catch of the next bite are always the same: checked on 3,066
    such states). The pack kept the first next state it saw, sometimes one whose data ended early, so 359 of 88,719
    no-horse casts (351 of 91,409 horse casts) showed fewer bites than the lab recorded. It now keeps the next state
    with the longest known chain: every bite schedule equals the raw rows, the dog trace checks stay 0 wrong, and the
    sister-line families are unchanged.

What is in this package
  site/                      index.html + the four pages, site_files.sha256, site_local.txt (your
                             HM64_Dog_Oracle_v30_0.html <- lucky-timer_sunny-no-horse.html, as before)
  tools/hm64_release.sh      release script rev e (unchanged)
  lab_changes/ (cumulative), new or changed in v32.1:
      tools/site_build.py               per-set data files (site.json "data"), Lucky Timer defaults, no carry data
      tools/dogcast_pack.py             the longest-chain fix
      tools/dogcast_verify.py           checks a pack against every raw cast row (bite times and catches)
      tools/save_check.py               what a save is (weather, horse, dog tile, rod, checksum); --find by content
      tools/rain_z0_check.py            the rainy runner's pre-flight
      webapp/site/site.json, partials/lucky_dialogs.html
      webapp/hm64_lucky_v29.js          page defaults, route kept per page, carry hidden where the page says so
      webapp/hm64_site_v32.js           the Route paragraph, carry / dog-beach paragraphs dropped
      webapp/assets/dogcast.json        no-horse pack rebuilt with the fix (same inputs: d90 d110 d140c90 d170c120)
      webapp/assets/lucky_routes_sunny-horse.json, dogcast_sunny-horse.json
      tests/test_dogcast_pack.js, ui_site_defaults.js, pre_site_seed.js

Checked (sandbox, headless Chrome)
  - Horse pack: 91,409 of 91,409 cast rows equal to the pack (bite times + catches); the app's decoder on 7,077
    sampled casts: dog held 283,031 moments, 0 wrong; let go at a bite 205,950 moments, 0 wrong; bite schedules 0
    wrong. No-horse pack rebuilt: 88,719 of 88,719 equal, decoder 0 wrong on all three counts.
  - Horse Lucky Timer: fresh browser and a browser with no-horse settings both open on beach-lineup2 + horse with
    the pier start, dog-watch on, Freestyle on; the full pier-start test (one Space, dog-watch, cards, calibration
    pick, freestyle, doubles, Esc, a normal attempt to CAST) runs with no errors; Pier only (X) test clean.
  - No-horse Lucky Timer: the pier-start test gives exactly the v32.0 result apart from the route list; a stored
    carry route opens on beach-lineup2; switching pages keeps each page's route. Help text has no carry / dog-beach.
  - Casting tables, both files: all tabs draw, no errors; the no-horse page's tables equal v32.0's.

Not tested
  - Firefox, and the GitHub Pages site until it is pushed.

Release
  bash ~/Documents/hm64/tools/hm64_release.sh v32-1 <lab sha256> <pages sha256> </dev/null
