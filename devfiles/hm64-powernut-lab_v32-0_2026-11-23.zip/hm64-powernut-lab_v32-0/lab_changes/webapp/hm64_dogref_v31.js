/* HM64 Dog reference (v31.0, Thomas 2026-11-20) - replaces the Dog Oracle page.
   A manual method that needs no live tool: a reference of what the dog is most likely doing when Jack stops at the pier
   end (and which way it faces), which dog line that means, and how long after stopping to cast - plus a plain stopwatch
   (Space when Jack stops). Nothing here touches the Lucky Timer: it reads the same lab tables through LuckyCore
   (planSet / curve / zoneAt / best, no selection change) and the dog traces of the route (R.dw).

   The model (all from the lab tables in the page):
     - "you stop" = the stopwatch's t = 1 of the route's pier start (READY: Jack stops at the water).
     - a candidate = (dog line, its timing against your stop, weight) = DogWatch.candidates(route, pier plan); what its
       dog shows s seconds after you stop = the line's lab trace at trace VI  s / VI + (ko - mt) + 1.
     - a row's cast = the stopwatch time with the best Nut odds over the candidates of that row, for a B press that is
       off by a bell curve of the chosen spread, under one of three rules:
         1st bite : let go of B at the first bite
         2nd bite : hold through the first bite, let go at the second
         by clock : let go at the first bite only if it comes inside the listed stopwatch windows, else hold and let
                    go at the second (the Lucky Timer's "smart zones", read off the stopwatch by the player)
   Odds are shares of the route-weighted lab arrivals, as everywhere in the app. Not measured on hardware. */
(function (root) {
  'use strict';
  const C = root.HM64Lucky, DW = root.HM64DogWatch, DATA = (typeof HM64_DATA !== 'undefined' && HM64_DATA) || null;
  const $ = id => document.getElementById(id);
  if (!C || !DW || !DATA || !$('refArena')) return;
  const VI = () => (root.HM64LuckyApp && root.HM64LuckyApp.viMs ? root.HM64LuckyApp.viMs()          // v32.0: on its own page (no Lucky Timer)
    : root.HM64Core && root.HM64Core.viMs ? root.HM64Core.viMs() : 16.715);                          // the console frame period setting
  const KEY = 'hm64v31_dogref';
  const DIRN = ['S', 'SW', 'W', 'NW', 'N', 'NE', 'E', 'SE'], ARROW = ['↓', '↙', '←', '↖', '↑', '↗', '→', '↘'];
  const LOOK_VI = 30, MIN_CAST_AFTER_LOOK = 60, HARB_UNTIL = 600, HARB_BIN = 120, SOON = 0.8;
  let S = { route: null, sig: 150, delay: 150, tab: 'blind', quick: 10, aim: 'odds', qv: 0, sparrow: false };
  const RESET_S = 55;                                               // reset + menus, as the Lucky Timer's minutes-per-Nut
  const TABS = [['blind', 'Optimal Blind Casting'], ['lines', 'First 10 seconds, by line'], ['arrive', 'As you stop'], ['harb', 'Harbingers']];   // v31.1: tabs; v31.30: Optimal Blind Casting first
  try { Object.assign(S, JSON.parse(localStorage.getItem(KEY) || '{}')); } catch (e) { /* defaults */ }
  if (S.qv !== 2) { S.quick = 10; S.qv = 2; }                       // v31.10: the floor Thomas asked for ("fastest nut above 10%") is the default
  if (S.bv !== 1) { S.tab = 'blind'; S.bv = 1; }                   // v31.30: everyone lands once on the new Optimal Blind Casting tab
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { /* private mode */ } };
  const nameOf = b => (DATA.names && DATA.names[b]) || (b === 32 ? 'stand' : 'anim ' + b);
  const secs = t => ((t - 1) * VI() / 1000);
  const fx = (v, n) => v.toFixed(n == null ? 1 : n);
  const pct = p => (p == null || !(p >= 0) ? '—' : (100 * p).toFixed(p < 0.0995 ? 1 : 0) + '%');
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  /* ---------------------------------------------------------------- routes with dog traces and a pier start */
  function routes() {
    return C.routes().filter(r => { const R = C.routeOf(r.id); return R && R.dw && (r.anchors || R.anchors || []).some(a => a.id === 'pier'); });
  }
  /* v31.11 (Thomas 2026-11-20 23:05): the sparrow rule of the Lucky Timer here too. The Table list holds the main
     tables only; "Sparrows at the door" (box or key S) switches to that table's sparrow variant (menus 5-6 frames
     late: other dog lines, other casts) and back. */
  const bases = () => routes().filter(r => !r.variant_of);
  const sparOf = id => routes().find(r => r.variant_of === id && r.variant === 'sparrows') || null;
  const curRoute = () => (S.sparrow && sparOf(S.route) ? sparOf(S.route).id : S.route);
  function setSparrow(on) {
    S.sparrow = !!on && !!sparOf(S.route); save();
    const b = $('rfSpar'); if (b) b.checked = S.sparrow;
    refresh();
  }
  function ctx(routeId) {
    const R = C.routeOf(routeId), plan = (C.planSet('all', 'pier', routeId) || [])[0];
    if (!R || !R.dw || !plan) return null;
    const cands = DW.candidates(R, plan, 'all', 'pier');
    /* v31.8: how long an attempt is before Jack stops at the pier end = the fade-in stopwatch's READY time, route mean */
    let lead = 20;
    try { const pf = (C.planSet('all', 'fadein', routeId) || [])[0], v = pf ? pf.variants : [];        // minT: READY, VIs from 1 at the first light
      const wf = v.reduce((a, x) => a + x.w, 0); if (wf > 0) lead = (v.reduce((a, x) => a + x.w * x.minT, 0) / wf - 1) * VI() / 1000; } catch (e) { /* keep 20 s */ }
    return { R, plan, cands, W: cands.reduce((a, c) => a + c.w, 0) || 1, lead };
  }
  function showAt(R, dwi, k) {
    const v = R.dw.lines[dwi].vis;
    let lo = 0, hi = v.length - 1;
    while (lo <= hi) { const m = (lo + hi) >> 1; if (v[m][1] <= k) lo = m + 1; else if (v[m][0] > k) hi = m - 1; else return v[m]; }
    return null;
  }
  const lineName = (R, dwi) => { const li = R.dw.lines[dwi].li; return li >= 0 ? 'L' + (li + 1) : 'no table'; };

  /* ---------------------------------------------------------------- v31.30: casts past 40 s, Optimal Blind Casting
     (Thomas 2026-11-23). The cast tables behind the odds of this page (LuckyCore) end 40 s after Jack stops; the cast
     pack D.dogcast (the Lucky Timer's dog-after-the-cast data) holds every cast frame of every dog line to 120 s with
     its bites, so every aimed cast (0-75 s) and the blind windows are read from there. A plan variant = a dog line + its READY
     offset o: a cast t stopwatch VIs after the stop (t = 1 at the stop) lands on pack label t - 1 + o (as dcBites in
     the Lucky Timer). Odds = shares of the route-weighted arrivals, as everywhere on this page. Checked against an
     independent script on 2026-11-23 (claude/HM64_BLIND_CAST_2026-11-23.md). */
  const DC = DATA.dogcast || null;
  const END_S = 76, WAKE_S = 33.4, NAP_S = 39.4, BLIND_S = 1;
  // END_S: the Nut ends 75 s after the stop; WAKE_S / NAP_S: Jack
  // lies down 40 s after the stop unless the stick is pushed (the Lucky Timer's wake line at 33.4 s; the lab pushes on
  // casts later than 39.4 s); BLIND_S: the width of a blind window (B anywhere in it)
  const flagCache = new Map();
  function flagsOf(key) {                                       // per pack label / 2: Nut on bite 1 / on bite 2 (bite 1 held)
    if (flagCache.has(key)) return flagCache.get(key);
    const ln = DC && DC.lines[key];
    let f = null;
    if (ln) {
      const n = ln.k0 / 2 + ln.idx.length, b1 = new Uint8Array(n), b2 = new Uint8Array(n);
      ln.idx.forEach((cid, j) => {
        if (cid < 0 || DC.F[cid] < 0) return;
        const st = DC.S[cid], i = ln.k0 / 2 + j;
        if (st < 0) return;
        if (DC.O[st] === 'N') b1[i] = 1;
        if (DC.N[st] >= 0 && DC.X[st] >= 0 && DC.O[DC.X[st]] === 'N') b2[i] = 1;
      });
      f = { b1, b2 };
    }
    flagCache.set(key, f);
    return f;
  }
  /* per game frame i after the stop (elapsed VI 2i): the weighted share of the arrivals whose cast there gives the
     Nut on bite 1 (s1) / on bite 2 (s2); vars = [{ key, o, w }] */
  function shares(vars) {
    const nF = Math.floor(END_S * 1000 / VI() / 2) + 1, s1 = new Float64Array(nF), s2 = new Float64Array(nF);
    let W = 0, Wd = 0;
    for (const v of vars) {
      W += v.w;
      const f = flagsOf(v.key); if (!f) continue;
      Wd += v.w;
      for (let i = 0; i < nF; i++) {
        let lab = 2 * i + v.o; lab -= ((lab % 2) + 2) % 2;
        const j = lab / 2;
        if (j < 0 || j >= f.b1.length) continue;
        if (f.b1[j]) s1[i] += v.w;
        if (f.b2[j]) s2[i] += v.w;
      }
    }
    if (Wd > 0) for (let i = 0; i < nF; i++) { s1[i] /= Wd; s2[i] /= Wd; }
    return { s1, s2, cover: W > 0 ? Wd / W : 0 };
  }
  const POL2 = [['bite1', 's1'], ['hold', 's2']];
  /* the best window of BLIND_S seconds starting at elapsed VI >= fromVI: B pressed anywhere in it, one rule */
  function bestWindow(sh, fromVI) {
    const n = Math.max(1, Math.round(BLIND_S * 1000 / VI() / 2)), i0 = Math.max(0, Math.ceil(fromVI / 2));
    let b = null;
    for (const [pol, k] of POL2) {
      const a = sh[k]; let sum = 0;
      for (let i = 0; i < a.length; i++) {
        sum += a[i]; if (i >= n) sum -= a[i - n];
        const st = i - n + 1;
        if (st < i0) continue;
        if (!b || sum / n > b.p + 1e-12) b = { pol, p: sum / n, st, n };
      }
    }
    return b && b.p > 0 ? { pol: b.pol, p: b.p, t: 2 * b.st + b.n + 1, lo: 2 * b.st + 1, hi: 2 * (b.st + b.n) + 1 } : null;
  }
  /* per game frame: P(Nut) of a cast aimed there, the B press off by a bell curve of sd sigVI (as LuckyCore's smoothing) */
  function aimedCurves(sh, sigVI) {
    const sd = Math.max(0.25, sigVI / 2), r = Math.ceil(3 * sd), g = new Float64Array(2 * r + 1);
    let z = 0;
    for (let d = -r; d <= r; d++) { g[d + r] = Math.exp(-0.5 * (d / sd) ** 2); z += g[d + r]; }
    const out = {};
    for (const [pol, k] of POL2) {
      const a = sh[k], P = new Float64Array(a.length);
      for (let i = 0; i < a.length; i++) {
        let q = 0;
        for (let d = -r; d <= r; d++) { const j = i + d; if (j >= 0 && j < a.length) q += g[d + r] * a[j]; }
        P[i] = q / z;
      }
      out[pol] = P;
    }
    return out;
  }
  /* v31.30: a row's casts from the cast pack - the best cast per rule over 0-75 s, the quick cast, and the by-the-clock
     rule (LuckyCore's zone policy, inside its 40-s tables). The 40-s tables leave out, at each moment, the arrivals
     whose line has no table there (e.g. 6% of the L4 flapper-SW arrivals at 5.8 s: 17.4% shown, 16.4% over all of
     them); the pack has every line at every frame. Times are stopwatch VIs (t = 2i + 1 for game frame i after the stop). */
  function evalPack(Q, sigVI, tMin, floor) {
    const sh = shares(packVars(Q)); if (!(sh.cover > 0)) return null;
    const cv = aimedCurves(sh, sigVI), i0 = Math.max(0, Math.ceil((tMin - 1) / 2)), o = {};
    for (const [pol] of POL2) {
      const P = cv[pol]; let b = -1;
      for (let i = i0; i < P.length; i++) if (b < 0 || P[i] > P[b] + 1e-12) b = i;
      if (b >= 0 && P[b] > 0) o[pol] = { t: 2 * b + 1, p: P[b] };
    }
    const simple = !o.hold || (o.bite1 && o.bite1.p >= o.hold.p) ? 'bite1' : 'hold';
    o.simple = o[simple] ? simple : (o.hold ? 'hold' : null);
    if (!o.simple) return null;
    o.late = isLate(o[o.simple].t);
    try {                                                         // by the clock: inside the 40-s tables only
      const g = C.goal; let b;
      try { C.setGoal(null); b = C.best(Q, sigVI, tMin); } finally { C.setGoal(g || null); }
      if (b && b.zone && b.zone.p > 0) {
        const z = C.zoneAt(Q, b.zone.t, sigVI, sigVI, true);
        o.zone = { t: b.zone.t, p: b.zone.p, zones: z && z.zones ? z.zones.filter(w => w[1] > b.zone.t).slice(0, 4) : [] };
      }
    } catch (e) { /* no clock rule */ }
    /* the QUICK cast (v31.8 rule): the first moment one of the two rules reaches `floor`, at the top of that rise
       (at most 1.5 s on), kept when it comes at least 1 s before the best cast */
    if (floor > 0) {
      const end = (o[o.simple].t - 61) / 2;
      let q = null;
      for (const [pol] of POL2) {
        if (!o[pol]) continue;
        const P = cv[pol];
        for (let i = i0; i < end; i++) {
          if (!(P[i] >= floor)) continue;
          let u = i; while (u + 1 < end && u - i < 45 && P[u + 1] >= P[u]) u++;
          if (!q || i < q.i0 || (i === q.i0 && P[u] > q.p)) q = { t: 2 * u + 1, p: P[u], pol, i0: i };
          break;
        }
      }
      o.quick = q;
    }
    return o;
  }
  function packVars(Q) {                                         // a plan's variants as pack lines (series -> dog line key)
    const R = Q.refR; if (!R || !R.dw) return [];
    let m = R._sKey;
    if (!m) { m = R._sKey = new Map(); (R.sidxs || []).forEach((sx, li) => { const dwi = R.dw.of_line[li]; if (dwi != null && dwi >= 0) m.set(sx, R.dw.lines[dwi].key); }); }
    return Q.variants.filter(x => x.w > 0 && m.has(x.s)).map(x => ({ key: m.get(x.s), o: x.o, w: x.w }));
  }
  const candVars = (R, cs) => cs.map(c => ({ key: R.dw.lines[c.dwi].key, o: c.ko - c.mt + 1, w: c.w }));
  const isLate = t => secs(t) > NAP_S;
  const WAKE2_S = 2 * WAKE_S, NAP2_S = WAKE_S + NAP_S;          // a cast after ~72.8 s needs a 2nd push (the wake line at 66.9 s)
  const pushWhen = t => (secs(t) > NAP2_S ? `at about ${WAKE_S.toFixed(0)} s and again at about ${WAKE2_S.toFixed(0)} s` : `once at about ${WAKE_S.toFixed(0)} s`);
  const PUSH_TXT = `Cast after 40 s: push the stick ↘ once at about ${WAKE_S.toFixed(0)} s (and again at about ${WAKE2_S.toFixed(0)} s for a cast after ${NAP2_S.toFixed(0)} s), or Jack lies down (never push after casting).`;

  /* ---------------------------------------------------------------- the best cast for a set of candidates */
  let uid = 0;
  function subPlan(X, pvs) {
    const vars = [];
    X.plan.variants.forEach((x, pv) => { if (pvs.has(pv) && x.w > 0) vars.push(x); });
    return vars.length ? Object.assign({}, X.plan, { variants: vars, k: 'ref' + (++uid), maxBite: 0, refR: X.R }) : null;
  }
  function evalPlan(Q, sigVI, tMin, floor) {
    if (!Q) return null;
    tMin = Math.max(1, Math.round(tMin));
    if (DC && Q.refR) return evalPack(Q, sigVI, tMin, floor);     // v31.30: the cast pack, 0-75 s
    const g = C.goal;
    let b;
    try { C.setGoal(null); b = C.best(Q, sigVI, tMin); } finally { C.setGoal(g || null); }
    const o = {};
    for (const pol of ['bite1', 'hold']) {
      if (!b[pol] || !(b[pol].p > 0)) continue;
      o[pol] = { t: b[pol].t, p: b[pol].p };
      const P = C.curve(Q, sigVI, pol).P;                       // an earlier cast worth nearly as much
      for (let t = Math.max(tMin, Q.firstT || 1); t < b[pol].t - 120; t++) {
        if (P[t] >= SOON * b[pol].p) { let u = t; while (u + 1 < b[pol].t && P[u + 1] >= P[u]) u++; o[pol].soon = { t: u, p: P[u] }; break; }
      }
    }
    if (b.zone && b.zone.p > 0) {
      const z = C.zoneAt(Q, b.zone.t, sigVI, sigVI, true);
      o.zone = { t: b.zone.t, p: b.zone.p, zones: z && z.zones ? z.zones.filter(w => w[1] > b.zone.t).slice(0, 4) : [] };
    }
    const simple = !o.hold || (o.bite1 && o.bite1.p >= o.hold.p) ? 'bite1' : 'hold';
    o.simple = o[simple] ? simple : (o.hold ? 'hold' : null);
    /* v31.8 (Thomas 2026-11-20 22:19: "show times that are most likely ... but then also fastest ... a quick cast, if
       the odds aren't terrible, it's a numbers game"): the QUICK cast = the first moment after the look at which one of
       the two simple rules reaches `floor`, taken at the top of that rise (at most 1.5 s on). Kept only when it comes
       at least 1 s before the best cast. */
    if (o.simple && floor > 0) {
      let q = null;
      for (const pol of ['bite1', 'hold']) {
        if (!o[pol]) continue;
        const P = C.curve(Q, sigVI, pol).P;
        for (let t = Math.max(tMin, Q.firstT || 1); t < o[o.simple].t - 60; t++) {
          if (!(P[t] >= floor)) continue;
          let u = t; while (u + 1 < o[o.simple].t - 60 && u - t < 90 && P[u + 1] >= P[u]) u++;
          if (!q || t < q.t0 || (t === q.t0 && P[u] > q.p)) q = { t: u, p: P[u], pol, t0: t };
          break;
        }
      }
      o.quick = q;
    }
    return o.simple ? o : null;
  }

  /* ---------------------------------------------------------------- the analysis (in slices, so the page stays live) */
  let job = 0;
  const cache = new Map();
  function analyse(routeId, sigMs, onPart, onDone, quickPct) {
    const my = ++job, X = ctx(routeId);
    if (!X) { onDone(null); return; }
    const qp = quickPct == null ? S.quick : quickPct, floor = qp / 100;
    const key = routeId + '|' + sigMs + '|' + qp + '|' + DATA.generated;
    if (cache.has(key)) { onDone(cache.get(key)); return; }
    const { R, cands, W } = X, sigVI = sigMs / VI();
    const out = { routeId, sigMs, quick: qp, lead: X.lead, arrive: [], harb: [], lines: [], all: null, nLines: R.dw.lines.length };
    const tasks = [];
    const pvsOf = cs => new Set(cs.filter(c => c.pv >= 0).map(c => c.pv));
    const byLine = cs => { const m = new Map(); for (const c of cs) m.set(c.dwi, (m.get(c.dwi) || 0) + c.w); return [...m.entries()].sort((a, b) => b[1] - a[1]); };
    // everything together: the cast when you cannot tell the dog at all
    tasks.push(() => { out.all = evalPlan(subPlan(X, pvsOf(cands)), sigVI, MIN_CAST_AFTER_LOOK, floor); });
    // 1. what the dog shows as you stop (half a second after)
    const G = new Map();
    for (const c of cands) {
      const r = showAt(R, c.dwi, LOOK_VI + c.ko - c.mt + 1);
      const k2 = r ? r[4] + '_' + r[2] : '?';
      let g = G.get(k2); if (!g) G.set(k2, g = { key: k2, base: r ? r[4] : null, dir: r ? r[2] : null, w: 0, cs: [] });
      g.w += c.w; g.cs.push(c);
    }
    const groups = [...G.values()].sort((a, b) => b.w - a.w);
    for (const g of groups) {
      const row = { key: g.key, base: g.base, dir: g.dir, share: g.w / W, lines: byLine(g.cs).map(([d, w]) => ({ dwi: d, name: lineName(R, d), p: w / g.w })), cast: null, split: [] };
      out.arrive.push(row);
      tasks.push(() => { row.cast = evalPlan(subPlan(X, pvsOf(g.cs)), sigVI, LOOK_VI + MIN_CAST_AFTER_LOOK, floor); });
      // a mixed group: what each of its main lines does next, so the player can tell them apart
      if (row.lines.length > 1 && row.lines[0].p < 0.9) {
        const main = row.lines.filter(l => l.p >= 0.08).slice(0, 4).map(ln => {
          const cs = g.cs.filter(c => c.dwi === ln.dwi);
          const a = cs.reduce((q, c) => q + c.w * (c.ko - c.mt), 0) / cs.reduce((q, c) => q + c.w, 0) + 1;
          const seq = [];
          for (const r of R.dw.lines[ln.dwi].vis) { const t = r[0] - a; if (t > HARB_UNTIL) break; if (t <= LOOK_VI || r[1] - r[0] < 18) continue; seq.push({ base: r[4], dir: r[2], t }); }
          return { ln, cs, seq };
        });
        for (const m of main) {
          const others = main.filter(x => x !== m);
          const tell = m.seq.find(e => !others.some(x => x.seq.some(f => f.base === e.base && f.dir === e.dir && Math.abs(f.t - e.t) <= 60)));
          const nxt = tell || m.seq[0] || null;
          const sp = { name: m.ln.name, dwi: m.ln.dwi, p: m.ln.p, next: nxt, only: !!tell, cast: null };
          row.split.push(sp);
          tasks.push(() => { sp.cast = evalPlan(subPlan(X, pvsOf(m.cs)), sigVI, Math.max(LOOK_VI, nxt ? nxt.t : 0) + MIN_CAST_AFTER_LOOK, floor); });
        }
      }
    }
    // 2. harbingers: something the dog starts doing in the first 10 s that (nearly) only one line does then
    const H = new Map();
    for (const c of cands) {
      const a = c.ko - c.mt + 1, v = R.dw.lines[c.dwi].vis, seen = new Set();
      for (const r of v) {
        const t = r[0] - a;
        if (t > HARB_UNTIL) break;
        if (t <= LOOK_VI || r[1] - r[0] < 18) continue;        // under 0.3 s on screen: nobody reads it
        const k2 = r[4] + '_' + r[2] + '_' + Math.floor(t / HARB_BIN);
        if (seen.has(k2)) continue;
        seen.add(k2);
        let h = H.get(k2); if (!h) H.set(k2, h = { base: r[4], dir: r[2], bin: Math.floor(t / HARB_BIN), w: 0, cs: [], ts: 0 });
        h.w += c.w; h.cs.push(c); h.ts += c.w * t;
      }
    }
    const harb = [];
    for (const h of H.values()) {
      const ls = byLine(h.cs), pure = ls[0][1] / h.w;
      if (pure < 0.85 || h.w / W < 0.004) continue;
      harb.push({ base: h.base, dir: h.dir, bin: h.bin, t: h.ts / h.w, share: h.w / W, pure, line: lineName(R, ls[0][0]), dwi: ls[0][0], cs: h.cs, all: h.cs, cast: null });   // v31.30: cs = every arrival showing it (was: its line's only)
    }
    harb.sort((a, b) => b.share * b.pure - a.share * a.pure);
    const pinned = new Set(out.arrive.filter(r => r.lines[0].p >= 0.9).map(r => r.lines[0].dwi));
    const perLine = new Map(), keep = [];
    for (const h of harb) { if (pinned.has(h.dwi)) continue; const n = perLine.get(h.dwi) || 0; if (n >= 2) continue; perLine.set(h.dwi, n + 1); keep.push(h); if (keep.length >= 14) break; }
    keep.sort((a, b) => a.dwi - b.dwi || a.t - b.t);
    /* v31.30: Optimal Blind Casting - per harbinger the best 1-s window to cast in (B anywhere in it), over every
       arrival that shows it; one behaviour of one line in neighbouring 2-s bins is one row; then "none of these by
       10 s" (the arrivals showing none of them) and "not watching the dog" (all arrivals). */
    const brows = [];
    for (const h of keep) {
      const m = brows.find(b => b.base === h.base && b.dir === h.dir && b.dwi === h.dwi && b.bins.some(x => Math.abs(x - h.bin) === 1));
      if (m) {
        const have = new Set(m.cs);
        for (const c of h.all) if (!have.has(c)) m.cs.push(c);
        m.bins.push(h.bin); m.tMax = Math.max(m.tMax, h.t); m.tw += h.t * h.share; m.sw += h.share;
      } else brows.push({ base: h.base, dir: h.dir, dwi: h.dwi, line: h.line, bins: [h.bin], cs: h.all.slice(), tMax: h.t, tw: h.t * h.share, sw: h.share });
    }
    const seenAny = new Set();
    for (const b of brows) { b.t = b.tw / b.sw; b.share = b.cs.reduce((q, c) => q + c.w, 0) / W; b.win = null; for (const c of b.cs) seenAny.add(c); }
    const gW = new Map(); for (const r of brows) gW.set(r.dwi, Math.max(gW.get(r.dwi) || 0, r.share));   // rows: the line whose sign is seen most first, then by when it shows
    brows.sort((a, b) => gW.get(b.dwi) - gW.get(a.dwi) || a.dwi - b.dwi || a.t - b.t);
    out.blind = { rows: brows, none: { cs: cands.filter(c => !seenAny.has(c)), win: null }, all: { win: null } };
    out.blind.none.share = out.blind.none.cs.reduce((q, c) => q + c.w, 0) / W;
    for (const b of brows) tasks.push(() => { b.win = bestWindow(shares(candVars(R, b.cs)), Math.floor(b.tMax) + MIN_CAST_AFTER_LOOK + 30); delete b.cs; });
    tasks.push(() => { const B = out.blind.none; B.win = bestWindow(shares(candVars(R, B.cs)), HARB_UNTIL + MIN_CAST_AFTER_LOOK + 30); delete B.cs; });
    tasks.push(() => { out.blind.all.win = bestWindow(shares(candVars(R, cands)), 0); });
    for (const h of keep) {
      out.harb.push(h);
      tasks.push(() => { h.cast = evalPlan(subPlan(X, pvsOf(h.cs)), sigVI, Math.round(h.t) + MIN_CAST_AFTER_LOOK + 30, floor); delete h.cs; delete h.all; });
    }
    // 3. every dog line with a cast table: its share, what its dog does in the first 10 s, its best cast when known
    for (const [dwi, w] of byLine(cands)) {
      const cs = cands.filter(c => c.dwi === dwi);
      if (w / W < 0.004 || !cs.some(c => c.pv >= 0)) continue;
      const a = cs.reduce((q, c) => q + c.w * (c.ko - c.mt), 0) / w + 1;
      const seq = [];
      for (const r of R.dw.lines[dwi].vis) { const t = r[0] - a; if (t > HARB_UNTIL) break; if (r[1] - a <= 0 || r[1] - r[0] < 12) continue; seq.push({ base: r[4], dir: r[2], t: Math.max(0, t) }); if (seq.length >= 6) break; }
      const row = { name: lineName(R, dwi), dwi, share: w / W, seq, cast: null };
      out.lines.push(row);
      tasks.push(() => { row.cast = evalPlan(subPlan(X, pvsOf(cs)), sigVI, LOOK_VI + MIN_CAST_AFTER_LOOK, floor); });
    }
    const total = tasks.length;
    (function step() {
      if (my !== job) return;
      const t0 = performance.now();
      while (tasks.length && performance.now() - t0 < 40) tasks.shift()();
      onPart(out, 1 - tasks.length / total);
      if (tasks.length) setTimeout(step, 0); else { cache.set(key, out); onDone(out); }
    })();
  }

  /* ---------------------------------------------------------------- drawing */
  const dog = (b, d, px) => (b == null ? '' : `<img class="rfdog" style="width:${px || 40}px;height:${px || 40}px" alt="" src="${(DATA.sprites && DATA.sprites[b + '_' + d]) || ''}">`);
  const what = (b, d) => (b == null ? 'not in the tables' : `<b>${esc(nameOf(b))}</b> <span class="rfdir">${ARROW[d]} ${DIRN[d]}</span>`);
  const POLTXT = { bite1: 'let go at the <b>1st</b> bite', hold: 'hold the 1st bite, let go at the <b>2nd</b>' };
  let leadS = 20;
  const perNut = (t, p) => (p > 0 ? `${fx((RESET_S + leadS + secs(t)) / p / 60, 1)} min/Nut` : '');
  function castCell(c, id) {
    if (!c) return '<span class="mut">…</span>';
    const s = c[c.simple], z = c.zone, q = c.quick;
    /* v31.10 (Thomas 2026-11-20 22:49: the "first cast worth 10%" choice belongs here, where the decision is made in a
       second or two, not in the Lucky Timer): S.aim decides which of the two casts is the row's MAIN one - shown
       first, outlined, and what a click anywhere on the row puts on the stopwatch. */
    const fl = shown ? shown.quick : S.quick, qMain = S.aim === 'quick' && !!q;
    const best = `<div class="rfbest ${qMain ? 'rfalt' : 'rfmain'}"><span class="rftag">best odds</span> <button class="rfcast${qMain ? '' : ' main'}" data-t="${s.t}" data-id="${id}" title="Show this cast on the stopwatch">${fx(secs(s.t), 1)} s</button> ${POLTXT[c.simple]} <b>${pct(s.p)}</b> <span class="mut">${perNut(s.t, s.p)}</span></div>`;
    const quick = q ? `<div class="rfquick ${qMain ? 'rfmain' : 'rfalt'}"><span class="rftag">quick</span> <button class="rfcast${qMain ? ' main' : ''}" data-t="${q.t}" data-id="${id}" title="The first cast worth ${fl}% or more: show it on the stopwatch">${fx(secs(q.t), 1)} s</button> ${POLTXT[q.pol]} <b>${pct(q.p)}</b> <span class="mut">${perNut(q.t, q.p)}</span></div>`
      : `<div class="rfquick none"><span class="rftag">quick</span> <span class="mut">${s.p >= fl / 100 ? 'the best cast is the first one worth it' : 'nothing reaches ' + fl + '%'}</span></div>`;
    let h = qMain ? quick + best : best + quick;
    if (isLate(s.t) && !qMain) h += `<div class="rfclock">Cast after 40 s: push the stick ↘ ${pushWhen(s.t)}, or Jack lies down (never push after casting).</div>`;   // v31.30
    if (z && z.p >= s.p + 0.02 && z.zones.length) {
      h += `<div class="rfclock">by the clock: <button class="rfcast lite" data-t="${z.t}" data-id="${id}" data-z="${z.zones.map(w => w.join('-')).join(',')}">${fx(secs(z.t), 1)} s</button> <b>${pct(z.p)}</b> — let go at the 1st bite only if it comes at ` +
        z.zones.map(w => `${fx(secs(w[0]), 1)}–${fx(secs(w[1]), 1)} s`).join(' or ') + `, else hold for the 2nd</div>`;
    }
    return h;
  }
  const linesCell = ls => (ls[0].p >= 0.9 ? `<b class="rfline">${ls[0].name}</b>` + (ls[0].p < 0.995 ? ` <span class="mut">${pct(ls[0].p)}</span>` : '')
    : ls.slice(0, 3).map(l => `${l.name} <span class="mut">${pct(l.p)}</span>`).join(' · ') + (ls.length > 3 ? ` <span class="mut">+${ls.length - 3}</span>` : ''));
  let shown = null;
  function draw(o, frac) {
    shown = o;
    if (o && o.lead) leadS = o.lead;
    const el = $('rfBody');
    if (!o) { el.innerHTML = '<div class="mut">This route has no dog traces.</div>'; return; }
    const A = o.arrive.filter(r => r.share >= 0.003), rest = o.arrive.filter(r => r.share < 0.003);
    const sure = A.filter(r => r.lines[0].p >= 0.9).reduce((q, r) => q + r.share, 0);
    let h = `<div class="rfnote">${frac < 1 ? `working out the casts… ${Math.round(100 * frac)}%` : `<b>If you cannot tell the dog at all</b> (timing spread ±${o.sigMs} ms): ` + (o.all ? castCell(o.all, 'all') : '—') +
      `<div class="rfzero"><b>Every time on this page is counted from the moment Jack stops at the end of the dock</b> — the moment you press Space and the stopwatch starts at 0.0. ${S.sparrow && sparOf(S.route) ? '<b style="color:#ffd28a">Sparrows at the door: the table for menus 5–6 frames late.</b>' : (sparOf(S.route) ? 'No sparrows at the door: the table for menus 0–4 frames late (press S if the pair sits at the door).' : '')}</div>` +
      `<div class="mut">Every row gives two casts, in seconds after Jack stops: <b>best odds</b> = the most likely Nut for that dog; <b>quick</b> = the first cast worth ${o.quick}% or more (at least 1 s sooner). You aim for <b>${S.aim === 'quick' ? 'the quick one' : 'best odds'}</b>: that cast is outlined, and a click anywhere on a row puts it on the stopwatch. min/Nut = minutes of play per Nut if you always took that cast: an attempt counted as ${RESET_S} s up to the beach fade-in (as in the Lucky Timer) + ${fx(o.lead, 0)} s across the beach to the pier end + the wait.</div>`}</div>`;
    const head = h;
    h = `<h3>What is the dog doing as you stop at the pier end?</h3>
      <div class="mut">Look at the dog half a second after Jack stops. ${pct(sure)} of arrivals show something that names the line by itself (bold line number).</div>
      <table class="rftab"><tr><th></th><th>the dog</th><th>how often</th><th>your line</th><th>cast, counted from the moment Jack stops</th></tr>` +
      A.map((r, i) => `<tr class="${r.lines[0].p >= 0.9 ? 'sure' : ''}"><td>${dog(r.base, r.dir)}</td><td>${what(r.base, r.dir)}</td><td class="num">${pct(r.share)}</td><td>${linesCell(r.lines)}</td><td>${castCell(r.cast, 'a' + i)}</td></tr>` +
        r.split.map((s, j) => `<tr class="sub"><td></td><td colspan="2">↳ if it is <b>${s.name}</b> <span class="mut">(${pct(s.p)})</span>` +
          (s.next ? `, ${s.only ? 'only it then does' : 'next (the others too)'}: ${dog(s.next.base, s.next.dir, 26)} ${what(s.next.base, s.next.dir)} at <b>${fx(Math.max(0, s.next.t) * VI() / 1000, 1)} s</b>` : '') + `</td><td>${s.name}</td><td>${castCell(s.cast, 'a' + i + 's' + j)}</td></tr>`).join('')).join('') +
      `</table>` + (rest.length ? `<div class="mut">Rarer (${pct(rest.reduce((q, r) => q + r.share, 0))} together): ${rest.slice(0, 14).map(r => `${esc(nameOf(r.base))} ${r.dir != null ? DIRN[r.dir] : ''}`).join(', ')}${rest.length > 14 ? ' …' : ''}.</div>` : '');
    const pArrive = h;
    h = `<h3>Harbingers: one thing the dog does that names the line</h3>
      <div class="mut">In the first 10 s after you stop. "Sure" = the share of arrivals showing this, then, that are on that line. Lines already named by what the dog does as you stop (the “As you stop” tab) are left out.</div>` +
      (o.harb.length ? `<table class="rftab"><tr><th></th><th>the dog starts to</th><th>about when</th><th>how often</th><th>line</th><th>sure</th><th>cast, counted from the moment Jack stops</th></tr>` +
        o.harb.map((r, i) => `<tr><td>${dog(r.base, r.dir)}</td><td>${what(r.base, r.dir)}</td><td class="num">${fx(r.t * VI() / 1000, 1)} s</td><td class="num">${pct(r.share)}</td><td><b class="rfline">${r.line}</b></td><td class="num">${pct(r.pure)}</td><td>${castCell(r.cast, 'h' + i)}</td></tr>`).join('') + `</table>`
        : `<div class="mut">None beyond the first table.</div>`);
    const pHarb = h;
    h = `<h3>What each line's dog does in the first 10 seconds after you stop, and its cast</h3>
      <div class="mut">Most common line first. Find the row whose dog does what yours does; the times are seconds on the stopwatch.</div>
      <table class="rftab"><tr><th>line</th><th>how often</th><th>the dog, from the moment you stop (seconds)</th><th>cast when you know the line</th></tr>` +
      o.lines.map((r, i) => `<tr><td><b class="rfline">${r.name}</b></td><td class="num">${pct(r.share)}</td><td class="rfseq">${r.seq.map(q => `<span>${dog(q.base, q.dir, 30)}<i>${fx(q.t * VI() / 1000, 1)}</i> ${esc(nameOf(q.base))} ${ARROW[q.dir]}</span>`).join('')}</td><td>${castCell(r.cast, 'l' + i)}</td></tr>`).join('') + `</table>
      <div class="mut">${o.lines.length} of this table's ${o.nLines} dog lines are listed (0.4% of arrivals or more, with a cast table).</div>`;
    const pLines = h;
    /* v31.30 (Thomas 2026-11-23: "simple and direct. If you see x at y cast at z for odds%") */
    const one = p => (p > 0 ? `1 in ${1 / p < 10 ? (1 / p).toFixed(1) : Math.round(1 / p)}` : '');
    const bwin = (w, id, lab) => (!w ? '<span class="mut">…</span>' : `<button class="rfcast main" data-t="${w.t}" data-id="${id}" title="Show this cast on the stopwatch">${fx(secs(w.t), 1)} s</button> <span class="mut">(${fx(secs(w.lo), 1)}–${fx(secs(w.hi), 1)})</span>`);
    const bodds = w => (!w ? '' : `<b>${pct(w.p)}</b> <span class="mut">${one(w.p)}</span>`);
    const BL = o.blind || { rows: [], none: {}, all: {} };
    const sx = v => String(Math.round(v * 10) / 10);
    const between = r => `${sx(Math.max(LOOK_VI, Math.min(...r.bins) * HARB_BIN) * VI() / 1000)}–${sx(Math.min(HARB_UNTIL, (Math.max(...r.bins) + 1) * HARB_BIN) * VI() / 1000)} s`;
    const pushTag = w => (w && isLate(w.t) ? `<div class="rfclock">+ push the stick ↘ ${pushWhen(w.t)}</div>` : '');
    h = `<h3>Optimal Blind Casting</h3>
      <div class="mut">Press <kbd>Space</kbd> the moment Jack stops at the end of the pier and watch the dog for 10 s. If it starts one of these, cast at the time shown — anywhere in that second — and let go of B as the row says. Click a row to put its cast on the stopwatch.</div>
      <table class="rftab rfblind"><tr><th></th><th>if the dog starts</th><th>between</th><th>cast at</th><th>let go of B</th><th>Power Nut</th></tr>` +
      BL.rows.map((r, i) => `<tr><td>${dog(r.base, r.dir)}</td><td>${what(r.base, r.dir)}</td><td class="num">${between(r)}</td><td>${bwin(r.win, 'b' + i)}${pushTag(r.win)}</td><td>${r.win ? POLTXT[r.win.pol] : ''}</td><td class="num">${bodds(r.win)}</td></tr>`).join('') +
      `<tr><td></td><td><b>none of these</b></td><td class="num">by 10 s</td><td>${bwin(BL.none.win, 'bn')}${pushTag(BL.none.win)}</td><td>${BL.none.win ? POLTXT[BL.none.win.pol] : ''}</td><td class="num">${bodds(BL.none.win)}</td></tr></table>` +
      (BL.all.win ? `<div class="mut">Not watching the dog at all: cast at <b>${fx(secs(BL.all.win.t), 1)} s</b> (${fx(secs(BL.all.win.lo), 1)}–${fx(secs(BL.all.win.hi), 1)}), ${POLTXT[BL.all.win.pol]}: <b>${pct(BL.all.win.p)}</b> (${one(BL.all.win.p)}).</div>` : '') +
      `<div class="mut">Every time counts from the moment Jack stops. ${PUSH_TXT} The odds are the share of the lab's arrivals on this table that show what the row says and land the Power Nut with B pressed anywhere in that second (1/51 = 2% for comparison). The same harbingers, with a cast aimed to a fraction of a second, are on the Harbingers tab.</div>`;
    const pBlind = h;
    h = pLines;
    const P = { blind: pBlind, lines: h, arrive: pArrive, harb: pHarb };
    if (!TABS.some(t => t[0] === S.tab)) S.tab = 'lines';
    el.innerHTML = head + `<div class="rftabs">` + TABS.map(([id, txt]) => `<button data-tab="${id}" class="${id === S.tab ? 'on' : ''}">${txt}</button>`).join('') + `</div>` +
      TABS.map(([id]) => `<div class="rfpane" data-pane="${id}"${id === S.tab ? '' : ' hidden'}>${P[id]}</div>`).join('');
    for (const b of el.querySelectorAll('.rftabs button')) b.onclick = () => {
      S.tab = b.dataset.tab; save();
      for (const x of el.querySelectorAll('.rftabs button')) x.classList.toggle('on', x === b);
      for (const x of el.querySelectorAll('.rfpane')) x.hidden = x.dataset.pane !== S.tab;
      b.blur();
    };
    for (const b of el.querySelectorAll('.rfcast')) b.onclick = ev => { ev.stopPropagation(); setTarget(+b.dataset.t, b.dataset.z || '', b.closest('tr')); };
    for (const tr of el.querySelectorAll('.rftab tr')) { const m = tr.querySelector('.rfcast.main'); if (m) tr.onclick = () => m.click(); }   // a click on the row = its main cast
    if (frac >= 1 && T.target === null && o.all) { const m = el.querySelector('.rfnote .rfcast.main'); if (m) setTarget(+m.dataset.t, '', null); }   // until a row is clicked: the cast for "cannot tell the dog"
  }

  /* ---------------------------------------------------------------- the stopwatch */
  const T = { t0: null, target: null, zones: [], label: '' };
  function setTarget(t, z, tr) {
    T.target = t; T.zones = z ? z.split(',').map(w => w.split('-').map(Number)) : [];
    T.label = tr ? (tr.querySelector('.rfline') ? tr.querySelector('.rfline').textContent + ' · ' : '') + (tr.cells[1] ? tr.cells[1].textContent.trim().slice(0, 40) : '') : '';
    for (const x of document.querySelectorAll('#rfBody tr.on')) x.classList.remove('on');
    if (tr) tr.classList.add('on');
    tick();
  }
  function start(at) { T.t0 = at - S.delay; tick(); }
  function reset() { T.t0 = null; tick(); }
  function tick() {
    const el = $('rfClock'); if (!el) return;
    const run = T.t0 !== null, s = run ? (performance.now() - T.t0) / 1000 : 0;
    el.textContent = run ? s.toFixed(1) : '0.0';
    const tg = T.target !== null ? secs(T.target) : null, left = tg !== null ? tg - s : null;
    const box = $('rfTimer');
    box.classList.toggle('run', run);
    box.classList.toggle('soon', run && left !== null && left <= 3 && left > 0);
    box.classList.toggle('go', run && left !== null && left <= 0 && left > -0.6);
    $('rfTarget').innerHTML = tg === null ? 'Click a cast time in the tables to show it here.'
      : `Cast at <b>${fx(tg, 1)} s</b>` + (T.label ? ` <span class="mut">(${esc(T.label)})</span>` : '') +
        (run ? (left > 0 ? ` — in <b>${left.toFixed(1)} s</b>` : left > -0.6 ? ' — <b>CAST</b>' : ` — ${(-left).toFixed(1)} s ago`) : '') +
        (T.zones.length ? `<br>1st bite at ${T.zones.map(w => `${fx(secs(w[0]), 1)}–${fx(secs(w[1]), 1)} s`).join(' or ')}: let go. Any other time: hold for the 2nd.` : '');
    if (tg !== null && tg > NAP_S) {                              // v31.30: the stay-awake push(es) for a cast after 40 s
      const two = tg > NAP2_S, near = x => run && s >= x - 1 && s < x + 2.5 && left > 0;
      $('rfTarget').innerHTML += near(WAKE_S) || (two && near(WAKE2_S)) ? ' — <b style="color:#ff9a6a">PUSH THE STICK ↘ NOW</b>'
        : `<br><span class="mut">Push the stick ↘ ${two ? `at about ${WAKE_S.toFixed(0)} s and again at about ${WAKE2_S.toFixed(0)} s` : `once at about ${WAKE_S.toFixed(0)} s`}, or Jack lies down.</span>`;
    }
    $('rfBar').style.width = tg && run ? Math.max(0, Math.min(100, 100 * s / tg)) + '%' : '0%';
    $('rfHint').textContent = run ? 'Space = start again · Esc = stop' : 'Press Space the moment Jack stops at the end of the pier.';
  }
  function loop() { if (root.HM64Arena !== 'lucky' && T.t0 !== null) tick(); }
  document.addEventListener('keydown', e => {
    if (root.HM64Arena === 'lucky' || document.querySelector('dialog[open]')) return;
    const tg = e.target && e.target.tagName;
    if (tg === 'INPUT' || tg === 'SELECT' || tg === 'TEXTAREA') { if (e.key === 'Escape') e.target.blur(); if (tg !== 'SELECT' || e.code !== 'Space') return; }
    if (e.code === 'Space') { e.preventDefault(); if (!e.repeat) start(typeof e.timeStamp === 'number' && e.timeStamp > 0 ? e.timeStamp : performance.now()); }
    else if (e.key === 'Escape') { e.preventDefault(); reset(); }
    else if ((e.key === 's' || e.key === 'S') && !e.ctrlKey && !e.metaKey && !e.altKey && sparOf(S.route)) { e.preventDefault(); if (!e.repeat) setSparrow(!S.sparrow); }
  });

  /* ---------------------------------------------------------------- the page */
  function build() {
    { const cur = routes().find(r => r.id === S.route); if (cur && cur.variant_of) { S.route = cur.variant_of; S.sparrow = cur.variant === 'sparrows'; } }   // a stored variant table -> its main table + the box
    const rs = bases();
    if (!rs.some(r => r.id === S.route)) S.route = (rs[0] || {}).id || null;
    if ($('rfSpar')) { const b = $('rfSpar'); b.checked = !!(S.sparrow && sparOf(S.route)); b.disabled = !sparOf(S.route); b.onchange = e => { setSparrow(e.target.checked); e.target.blur(); }; }
    $('rfRoute').innerHTML = rs.map(r => `<option value="${r.id}">${esc(r.label || r.id)}</option>`).join('');
    $('rfRoute').value = S.route || '';
    $('rfSig').value = String(S.sig); $('rfDelay').value = S.delay;
    $('rfRoute').onchange = e => { S.route = e.target.value; if (!sparOf(S.route)) S.sparrow = false; if ($('rfSpar')) { $('rfSpar').disabled = !sparOf(S.route); $('rfSpar').checked = !!S.sparrow; } save(); e.target.blur(); refresh(); };
    $('rfSig').onchange = e => { S.sig = +e.target.value || 150; save(); e.target.blur(); refresh(); };
    if ($('rfAim')) { $('rfAim').value = S.aim === 'quick' ? 'quick' : 'odds'; $('rfAim').onchange = e => { S.aim = e.target.value === 'quick' ? 'quick' : 'odds'; save(); e.target.blur(); T.target = null; T.zones = []; T.label = ''; if (shown) draw(shown, 1); tick(); }; }
    if ($('rfQuick')) { if (![5, 8, 10, 12, 15].includes(+S.quick)) S.quick = 10; $('rfQuick').value = String(S.quick); $('rfQuick').onchange = e => { S.quick = +e.target.value || 10; save(); e.target.blur(); refresh(); }; }
    $('rfDelay').onchange = e => { S.delay = Math.max(0, Math.min(600, +e.target.value || 0)); save(); };
    $('rfStart').onclick = e => { start(performance.now()); e.target.blur(); };
    $('rfReset').onclick = e => { reset(); e.target.blur(); };
    $('rfPrint').onclick = () => root.print();
  }
  let built = false, want = null;
  function refresh() {
    if (!S.route) { draw(null, 1); return; }
    T.target = null; T.zones = []; T.label = '';
    const rid = curRoute();
    want = rid + '|' + S.sig + '|' + S.quick;
    const same = o => want === o.routeId + '|' + o.sigMs + '|' + o.quick;
    analyse(rid, S.sig, (o, f) => { if (same(o)) draw(o, f); }, o => { if (!o || same(o)) draw(o, 1); tick(); }, S.quick);
  }
  /* v31.7 (Thomas 2026-11-20 21:06: "prevent dog reference from loading its assets and slowing the page down if it
     isn't selected"). Nothing of this page exists until its tab is opened; when the Lucky Timer is selected again the
     unfinished cast search is dropped, the stopwatch interval is stopped and the tables (several hundred dog sprites)
     are taken out of the page. Finished results stay in `cache`, so coming back redraws at once. */
  let iv = null, active = false;
  function show() {
    if (!built) { built = true; build(); }
    if (!active) { active = true; iv = setInterval(loop, 33); refresh(); }
    tick();
  }
  function hide() {
    if (!active) return;
    active = false; job++; want = null;                           // drops a running analysis (its steps check `job`)
    if (iv !== null) { clearInterval(iv); iv = null; }
    T.t0 = null;
    const el = $('rfBody'); if (el) el.innerHTML = '';
    shown = null;
  }
  root.HM64DogRef = { show, hide, setSparrow, curRoute, get active() { return active; }, analyse, ctx, refresh, state: S, timer: T, start, reset, setTarget, get shown() { return shown; } };

  /* the old Dog Oracle parts of "How it works" go; this page gets its own paragraph */
  const GONE = ['Dog paths.', 'Your keys and names.', 'Scrub bar (03).', 'Tap search.', 'Flickers.', 'Logging.', 'Potential dogs.', 'Histogram.', 'Line-up methods (03).', 'After the cast', 'Two arenas'];
  const hb = $('helpBtn'), old = hb && hb.onclick;
  if (hb && old) hb.onclick = ev => {
    old.call(hb, ev);                                             // fills helpBody with the page's text and opens it
    const parts = $('helpBody').innerHTML.split(/(?=<p><b>)/).filter(p => !GONE.some(g => p.startsWith('<p><b>' + g)));
    const mine = `<p><b>Dog reference.</b> A manual method: no keys to log, nothing learned, nothing stored but three settings. Four tabs. <i>Optimal Blind Casting</i> (the first page): if the dog does one of the listed things in the first 10 s after Jack stops, cast at the time shown — anywhere in that second — and let go at the bite it says; the odds are those of a cast anywhere in that second. <i>First 10 seconds, by line</i>: every dog line, most common first, with what its dog does in the first 10 s after Jack stops and the cast with the best Power Nut odds for it, counted from the moment Jack stops. <i>As you stop</i>: what the dog is doing half a second after Jack stops, how often, which line that means, and the cast. <i>Harbingers</i>: one thing the dog starts doing in the first 10 s that names a line. Casts reach 75 s after Jack stops (the Power Nut ends there); a cast after 40 s needs one push of the stick ↘ at about 33 s (a cast after 73 s a second one at about 67 s), or Jack lies down. A cast comes with its rule — let go at the 1st bite, or hold it and let go at the 2nd — and, where it is worth 2 points or more, a rule by the clock: let go at the 1st bite only if it comes inside the listed times. <kbd>Space</kbd> when Jack stops starts the stopwatch (your reaction, 150 ms unless you change it, is taken off); click a cast time and the stopwatch counts down to it; <kbd>Esc</kbd> stops. The odds assume your B press is off by the timing spread you choose; they come from the lab tables and are not measured on a console.</p>`;
    $('helpBody').innerHTML = parts[0] + mine + parts.slice(1).join('');
  };
  if (root.HM64Arena !== 'lucky') show();
})(typeof window !== 'undefined' ? window : globalThis);
