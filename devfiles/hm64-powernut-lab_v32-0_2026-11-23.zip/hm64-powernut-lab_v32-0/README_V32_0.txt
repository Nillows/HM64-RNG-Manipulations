HM64 Power Nut Tool v32.0 (2026-11-23) — the hub layout
=========================================================

What you asked for (2026-11-23 14:28)
  index.html becomes a bare-bones hub, sorted sunny / rainy first, that links to one page per game-file
  circumstance (horse / no horse, later marriage, baby ...). Every working page stays ONE html file that works
  offline. Pages are generated from templates by a script, so all of them keep the same form. First step: split
  the "Lucky Timer" and "Dog reference" tabs out of the one big page into this layout.

What is in this package
  site/index.html                           the hub (7 KB, no scripts)
  site/lucky-timer_sunny-no-horse.html      the Lucky Timer for Sunny -> No horse (29 MB)
  site/casting-tables_sunny-no-horse.html   the Casting tables for Sunny -> No horse (23 MB): Optimal Blind Casting
                                            first, then the Dog reference's other tabs and its stopwatch
  site/site_files.sha256                    checksums the release script checks
  site/site_local.txt                       "HM64_Dog_Oracle_v30_0.html lucky-timer_sunny-no-horse.html": the page
                                            copied over the file you open on your Mac, so your settings stay
  tools/hm64_release.sh                     release script rev e (installs itself from this package)
  lab_changes/                              the lab sources (cumulative since v31.25), new in v32.0:
      tools/site_build.py                   the generator (python3 -I tools/site_build.py DATA.json --out DIR)
      webapp/site/site.json                 the hub's manifest: weathers, game files, their routes and status
      webapp/site/templates/                hub.html, lucky_timer.html, casting_tables.html
      webapp/site/partials/                 the old page cut into pieces (exact slices of v31.30's template)
      webapp/hm64_site_v32.js               page glue ("How it works" text, the Pages paragraph)
      webapp/hm64_lucky_v29.js              5 lines: no arena buttons on a page without the Dog reference
      webapp/hm64_dogref_v31.js             3 lines: frame period from the settings on its own page, help text
      tests/ui_castdump.js, ui_castquick.js, pre_site_arena_buttons.js

How the generator works
  site.json lists every game file ("set") with its weather, status (ready / collecting / planned), what the file
  needs, and the route tables of each of its pages. A ready set gets its pages; the others show on the hub with
  their status. Templates use a small Handlebars subset ({{x}}, {{{raw}}}, {{> partial}}, {{#each}}, {{#if}});
  a name that does not exist stops the build instead of printing nothing. Adding "Sunny -> Horse" later = its
  route tables in the data + "status": "ready" and its routes in site.json; the generator makes its two pages.

Checked (sandbox, headless Chrome)
  - Lucky Timer page vs v31.30: the data embedded is identical (all 23 keys); the HTML differs only where meant
    (title, footer links, the Dog reference removed, the glue script, 5 lines of the arena switch).
  - All 60 Lucky Timer UI tests run on both pages: same results, apart from (a) title / version text, (b) the
    footer test's measure of the Dog reference arena, which is not on this page, and (c) values that also differ
    between two runs of the SAME page (timing of practice drills and learned cast times): each was run twice
    on both pages to tell the two apart. Four old tests give no output on either page (unchanged).
  - Casting tables page vs v31.30's Dog reference tab: all four tabs' tables identical in 12 of 12 settings
    (both tables, 4 spreads, best odds / quick cast at 5-15%), with the numbers behind them and the stopwatch.
  - Release script rev e in a mock home folder with a stand-in GitHub (see below).

Not tested
  - Firefox (everything above is headless Chrome), and the real GitHub Pages site until it is pushed.
  - On your Mac, the hub's own links open lucky-timer_sunny-no-horse.html, a different file from
    HM64_Dog_Oracle_v30_0.html: Firefox gives it fresh settings. Keep opening HM64_Dog_Oracle_v30_0.html for
    your own data (the release puts the new Lucky Timer there). On the website all pages share one origin, so
    testers keep their settings when they move from the old index.html to the new Lucky Timer page.

Release
  bash ~/Documents/hm64/tools/hm64_release.sh v32-0 <lab sha256> <pages sha256> </dev/null
  The installed script finds rev e inside this package and restarts with it. Rev e: checks every site file
  against site_files.sha256 in both zips, pushes the hub + pages + README + media, installs the site into
  ~/Documents/hm64/webapp/, copies the Lucky Timer over HM64_Dog_Oracle_v30_0.html, copies lab_changes/ into
  the lab, and backs up every file it replaces first (backups/<time>_v32-0/local_before/).
