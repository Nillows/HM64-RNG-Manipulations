HM64 Power Nut Tool v32.24 (2026-11-26) - wording and pictures only

WHAT CHANGED
- README: the opening, the deck paragraph and "How it works: a leaf in a forest" are rewritten shorter and plainer
  (How it works: 15.3k -> 12.5k characters; every lab number kept; one figure dropped, the 4,294,967,296 key count).
  Sunlight is now explained as a screen's own draw rate = the slope of "numbers drawn against the clock", and the pier
  section loops back to it: on the pier the slope is steady, so two plays on the same line differ only in time. That
  is why plays join into dog lines and why the tuner only has to move time.
- Site: how-it-works.html captions rewritten to match; the one-future picture now comes before the group-by-shape one.
- Pictures (tools/forest_svg.py, drawn from webapp/assets/forest_facts.json as before):
    forest_1_canopy.svg       every twig now ends in leaves; the loose crossing sticks are gone
    forest_4_sunlight.svg     redrawn as slopes: draws against time for sunny and rainy, with the per-second rate of
                              each rainy screen, and a "same ground: the pier" panel (two real plays, 14 frames apart)
    forest_6b_one_future.svg  title and strip label say "slope"
- NO table, script or tool-page change: every tool page (Lucky Timer, Casting tables, Dog practice, all four files),
  the hub, guide, not-working, settings, deck and problem pages are byte-identical to v32.23 apart from the version label.

NOT CHANGED / NOT EDITED
- README sections 1-11 (the manual), Optimal Blind Casting, the rainy section, How the odds are worked out, Dog practice.

TESTED
- how-it-works.html in headless Chrome (ui_guide.js: no errors, 12 pictures found). Not tested in Firefox.
- The other pages were not re-tested: they are the v32.23 files with another version label (compared byte by byte).
