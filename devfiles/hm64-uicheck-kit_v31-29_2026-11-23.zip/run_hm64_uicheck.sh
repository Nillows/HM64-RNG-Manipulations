#!/usr/bin/env bash
# HM64 Power Nut lab - UI lab, CONSISTENCY CHECK (2026-11-21; kit of 2026-11-23: app v31.29, both starts, tag check2): do all the features behave consistently
# and logically, in every combination? Thousands of seeded random walks of real user actions (keys, clicks, settings)
# through attempts and practice drills in the real app, with a list of invariants checked after every action
# (freestyle / normal, targets, doubles, threads, release line, wake reminder, calibration view, sister lines,
# reports, practice drills, attempt list). Browser only: no emulator, no save, no ROM.
#
#   bash run_hm64_uicheck.sh [browsers at a time]
# Next to this script: hm64-uicheck-kit.tar.gz. Work folder: runs/uicheck (nothing else is touched).
# Result: runs/uicheck/<tag>/UICHECK.md and runs/hm64-uicheck-<tag>-<time>.zip
# Env: HM64_UICHECK_TAG (default check2; the same tag continues where it stopped), HM64_UICHECK_N (1500 scenarios),
#      HM64_UICHECK_SEED0 (1), HM64_UICHECK_APP=/path/app.html, HM64_UILAB_FRAME_MS (33), HM64_UICHECK_WAIT=0,
#      HM64_RUN_ROOT.
set -euo pipefail
say() { printf '\n==> %s\n' "$*"; }
die() { printf '\nSTOP: %s\n' "$*" >&2; exit 1; }

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROCS=${1:-}
KIT="${HM64_UICHECK_KIT:-$HERE/hm64-uicheck-kit.tar.gz}"
TAG=${HM64_UICHECK_TAG:-check2}
N=${HM64_UICHECK_N:-1500}
SEED0=${HM64_UICHECK_SEED0:-1}
FRAME=${HM64_UILAB_FRAME_MS:-33}
[ -f "$KIT" ] || die "$(basename "$KIT") is not next to this script ($HERE)"
command -v docker >/dev/null || die "docker not found"
docker info >/dev/null 2>&1 || die "Docker is not running (start Docker Desktop)"

RUN_ROOT=${HM64_RUN_ROOT:-$HERE/runs}
WORK="$RUN_ROOT/uicheck"
mkdir -p "$WORK"
LOCK="$WORK/.running"
WAITED=0
while :; do
  busy=""
  for d in zigzag dogspots uilearn uidog uiwhole; do [ -d "$RUN_ROOT/$d/.running" ] && busy="another lab run ($RUN_ROOT/$d/.running)"; done
  if [ -z "$busy" ]; then if mkdir "$LOCK" 2>/dev/null; then break; else busy="another consistency check ($LOCK)"; fi; fi
  [ "${HM64_UICHECK_WAIT:-1}" = 1 ] || die "$busy - start this one after it finishes (if none is running, delete that folder)"
  [ $((WAITED % 15)) -ne 0 ] || echo "  $(date +%H:%M) waiting for $busy to finish (Ctrl-C cancels; if nothing is running, delete that folder)"
  WAITED=$((WAITED + 1)); sleep 60
done
trap 'rmdir "$LOCK" 2>/dev/null || true' EXIT
STAMP=$(date +%Y%m%d-%H%M%S)
LOG="$WORK/run-uicheck-$STAMP.log"
exec > >(tee -a "$LOG") 2>&1
say "consistency check: $N scenarios from seed $SEED0, tag $TAG, work folder $WORK"

say "1/4 the kit"
rm -rf "${WORK:?}/kit"; mkdir -p "$WORK/kit"
tar -xzf "$KIT" -C "$WORK/kit" --strip-components 1
[ -f "$WORK/kit/tools/uicheck.py" ] || die "$(basename "$KIT") does not contain tools/uicheck.py"
APP=$(ls "$WORK/kit/uilab/"HM64_Dog_Oracle_*.html | sort | tail -n 1)
if [ -n "${HM64_UICHECK_APP:-}" ]; then cp "$HM64_UICHECK_APP" "$WORK/kit/uilab/app-under-test.html"; APP="$WORK/kit/uilab/app-under-test.html"; fi
echo "  app under test: $(basename "$APP")"
mkdir -p "$WORK/$TAG"

say "2/4 the browser image hm64-uilab-browser (first time: a few minutes)"
docker build --platform linux/arm64 -t hm64-uilab-browser -f "$WORK/kit/docker/Dockerfile.uilab-browser" "$WORK/kit/docker" > "$WORK/build-$STAMP.log" 2>&1 \
  || { tail -30 "$WORK/build-$STAMP.log"; die "the browser image build failed (log: $WORK/build-$STAMP.log)"; }
ui_run() {
  docker run --rm --platform linux/arm64 --shm-size 6g -v "$WORK:/work" -w /work/kit -e HM64_UILAB_FRAME_MS="$FRAME" hm64-uilab-browser "$@" </dev/null
}
if [ -z "$PROCS" ]; then NCPU=$(ui_run nproc 2>/dev/null || echo 2); PROCS=$(( NCPU > 1 ? NCPU - 1 : 1 )); fi
echo "  browsers at a time: $PROCS"

say "3/4 check: 4 scenarios"
rm -rf "${WORK:?}/$TAG/_check"
ui_run python3 tools/uicheck.py run --app "/work/kit/uilab/$(basename "$APP")" --n 4 --seed0 900001 --procs "$PROCS" --dir "/work/$TAG/_check" || die "the check run failed"
PLAYED=$( { grep -c '"steps"' "$WORK/$TAG/_check/check.jsonl" 2>/dev/null || true; } | tr -d ' ')
NOHOOK=$( { grep -c 'no v31.25 hooks' "$WORK/$TAG/_check/check.jsonl" 2>/dev/null || true; } | tr -d ' ')
[ "${NOHOOK:-0}" -eq 0 ] || die "the app under test is older than v31.25: nothing was run"
[ "${PLAYED:-0}" -ge 3 ] || { head -c 600 "$WORK/$TAG/_check/check.jsonl" 2>/dev/null; die "the app did not play the check scenarios in the headless browser ($PLAYED of 4)"; }
echo "  check: $PLAYED of 4 scenarios played"

say "4/4 the scenarios (Ctrl-C is safe: the same command continues)"
ui_run python3 tools/uicheck.py run --app "/work/kit/uilab/$(basename "$APP")" --n "$N" --seed0 "$SEED0" --procs "$PROCS" --dir "/work/$TAG" || die "the run failed"
ui_run python3 tools/uicheck.py report --dir "/work/$TAG" > "$WORK/$TAG/report.log" 2>&1 || { tail -5 "$WORK/$TAG/report.log"; die "the report failed"; }
sed -n '1,/^## 2/p' "$WORK/$TAG/UICHECK.md"
OUTZIP="$RUN_ROOT/hm64-uicheck-$TAG-$STAMP.zip"
( cd "$WORK" && zip -q -r "$OUTZIP" "$TAG" -x "*/_check/*" ) || die "zip failed"
echo
echo "  report : $WORK/$TAG/UICHECK.md"
echo "  zip    : $OUTZIP   (send this one)"
