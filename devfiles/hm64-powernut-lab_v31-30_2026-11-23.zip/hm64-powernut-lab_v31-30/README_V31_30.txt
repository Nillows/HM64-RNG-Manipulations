HM64 Power Nut tool v31.30 (2026-11-23) - Optimal Blind Casting, and Dog reference casts to 75 s

WHAT YOU ASKED FOR (Thomas 11:03)
"Incorporate this in the app and the README. A section called 'Optimal Blind Casting' that flat out tells the players
the suggested cast times for the harbinger lines. Simple and direct: if you see x at y, cast at z for odds%."

IN THE APP (Dog reference only; the Lucky Timer is byte-for-byte the same code as v31.29)
1. New first tab of the Dog reference: OPTIMAL BLIND CASTING. One row per harbinger: the dog's behaviour and facing,
   when it starts (2-s band after Jack stops), the cast time (and the 1-s window around it), the bite rule, and the
   Power Nut odds of pressing B anywhere in that second. Then "none of these by 10 s" and "not watching the dog at all".
   A cast after 40 s carries "+ push the stick SE once at about 33 s". Click a row = its cast on the stopwatch.
   Everyone lands on this tab once (stored setting bv); after that the tab you last used is remembered.
   On Beach-lineup2 (no sparrows):
     wiggle-bum SW 0.5-2 s  -> 62.4 s, 1st bite, 28% (1 in 3.6), push at 33 s
     flapper SW 4-6 s       -> 62.4 s, 1st bite, 27% (1 in 3.7), push at 33 s
     flapper SW 2-4 s       -> 22.2 s, 1st bite, 12% (1 in 8.3)
     sit NE 8-10 s          -> 22.2 s, 1st bite, 13% (1 in 7.9)
     rollover SW 8-10 s     -> 30.2 s, hold 1st / let go 2nd, 12% (1 in 8.5)
     smell E 2-4 s          -> 61.5 s, 1st bite, 30% (1 in 3.3), push at 33 s
     shoulder-sitting E 6-8 s -> 61.5 s, 1st bite, 30% (1 in 3.3), push at 33 s
     run SE 2-4 s / walk SE 4-6 s -> 12.8 s, hold 1st / let go 2nd, 13% (1 in 7.6)
     none of these by 10 s  -> 63.0 s, 1st bite, 8.7% (1 in 12), push at 33 s
     not watching the dog   -> 63.0 s, 1st bite, 10% (1 in 9.8), push at 33 s
   The table follows the Sparrows box (S): with sparrows at the door it lists that table's own harbingers.
2. Every aimed cast on the Dog reference (best odds and quick, on every tab) is now read from the cast pack (the
   dog-after-the-cast data, every cast frame to 120 s), over 0-75 s instead of the 40-s tables. Many best casts move
   past 40 s, e.g. "cannot tell the dog" 36.9 s hold 8.4% -> 62.7 s 1st bite 11.3%; L1 36.8 s hold 20% -> 62.5 s
   1st bite 29%; L19 4.7 s 27% -> 61.7 s 35%; L6 62.6 s 32%; L7 62.7 s 34%. A cast after 40 s says "push the stick
   SE once at about 33 s" under it, and the stopwatch shows "PUSH THE STICK SE NOW" from 32.4 to 35.9 s when the
   target cast is after 40 s. The by-the-clock rule still comes from the 40-s tables (unchanged).
3. Two accuracy fixes found on the way:
   a. A harbinger's cast is now computed over every arrival that shows the harbinger, not only its line's (sit NE:
      14% of those arrivals are other lines; its old 40-s figure 15.9% was really 14.3%).
   b. The 40-s tables leave out, at each moment, the arrivals whose line has no table there (some lines' tables start
      14 s or more after the stop) and average the rest. Example: flapper SW at 2-4 s, cast 5.8 s: 17.4% shown, 16.4%
      over all of them. The pack has every line at every frame, so these numbers are now complete. One-line rows were
      already exact (the 40-s tables and the pack agree on all 82,738 table frames).
4. How it works (help) text: four tabs, casts to 75 s, the push.

CHECKED
- v31.29 rebuilt from the handoff snapshot + v31.29 lab_changes: byte-identical to the page you shipped (index.html
  of the GitHub Pages zip). v31.30 = that source + hm64_dogref_v31.js (patch script
  experiments/blind_cast/patch_blind.py, exact-anchor replacements) + version label.
- Every number of the new tab and the casts (9 harbinger rows, none of these, not watching, 10 harbinger casts,
  "cannot tell the dog", lines L1-L12) recomputed by an independent Python script from dogcast.json +
  lucky_routes.json (experiments/blind_cast/verify_v3130.py): 34 of 34 equal.
- The Dog reference's harbinger list reproduced in Python (harb_bands.py): 10 of 10 rows equal.
- Headless (Chrome): tests/ui_blind.js (the tab, a row click, the push reminder, the sparrow table), tests/ui_push2.js (two pushes for a
  cast after 73 s), tests/ui_latecasts.js (no cast the page shows lands after 72.8 s on either table), tests/ui_dogref.js
  (no errors, Lucky Timer unchanged after visiting the Dog reference), regression of the Lucky Timer tests on v31.29 vs
  v31.30 (see the chat / project doc claude/HM64_BLIND_CAST_2026-11-23.md for the list).
- Not checked: Firefox (headless Chrome only); a console.

README.md (GitHub Pages zip)
- Title v31.30; a new section "Optimal Blind Casting" right after Quick start (unnumbered, so every other section
  number and cross-reference stays), generated from the app's own output (experiments/blind_cast/readme_v3130.py,
  every line checked against the same row of the page); a pointer in Contents, Quick start and section 4; section 10's
  Dog reference paragraph (four tabs, casts to 75 s, the push).
- media/app_blind.png (new: the tab) and media/app_dogref.png (re-taken: the old one was caught mid-calculation,
  "working out the casts... 11%", on the v31.28 tab layout).

lab_changes/ is cumulative since v31.25 (your lab tree): new in v31.30 = webapp/hm64_dogref_v31.js,
tools/export_webapp.py (VERSION), tests/ui_blind.js, tests/ui_harbdump.js, experiments/blind_cast/ (the analysis and
check scripts of today's blind-cast work; they were written in the sandbox and use its /home/claude/x paths).
