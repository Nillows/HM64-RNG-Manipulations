HM64 Power Nut tool v31.29 (2026-11-23) - fix for the consistency lab's F6 violations

THE BUG (found by check1 on v31.25, 10 of 1,487 scenarios; still in v31.26-v31.28)
With the FADE-IN start (tap strategies) and Freestyle on, Space pressed as the cast within about 2 s of READY was not
taken as the cast. The app still read it as one more tap of the start sequence, for as long as the tap window was open
(until 2 s after the plan's READY). Two outcomes, both reproduced here:
  - "EXTRA TAP IGNORED": the cast is not marked (no focus, no grading); harmless otherwise.
  - worse: the new tap is fitted together with the earlier ones and they are all re-read (lamp "FIRST CONTROL ✓"):
    the dock-end tap becomes the ranch exit, the stopwatch jumps by seconds, and everything timed from it (dog cards,
    threads, release) is off. Seen on v31.25 and v31.28 with a Space 100 VIs after READY.
The default one-tap start at the dock end (v31.27+) has no tap sequence and was never affected (checked: a Space 2 s
after READY marks the cast on v31.28 and v31.29).

THE FIX (hm64_lucky_v29.js, two lines)
1. Freestyle: once the dock-end tap is in, Space is the cast (never another sequence tap). A second Space within
   300 ms of the dock-end tap is ignored as key bounce.
2. Freestyle: the tap window ends 2 s after READY as the picked dog has it (wakeReady), not the plan's READY; with no
   dog picked it is the plan's READY as before.
Normal mode (Freestyle off) is unchanged: there, taps between the dock end and 1.5 s before the cast still go to the
sequence (see "Open" below).

CHECKED
- Both reproduced scenarios (seed 52 "mixed", seed 825 "free") played on v31.25 + this fix: no violation (146 and 249
  actions; the cast was marked 2 and 3 times).
- Probe (real-time browser): fade-in start, freestyle, Space 60 / 100 VIs after READY: v31.28 "EXTRA TAP IGNORED" /
  "FIRST CONTROL ✓" with the taps re-read; v31.29 "CAST" both times, taps untouched. Dock-end start: CAST on both.
- The v31.29 page differs from v31.28 only in these lines, the version label and the build date (checked line by line).

THE CONSISTENCY LAB, UPDATED FOR v31.27+ (lab_changes/uilab/uicheck_driver.js, lab_changes/tools/uicheck.py)
- v31.27 changed the defaults (Freestyle on, one-tap dock-end start). The old driver pressed Ctrl only to switch
  freestyle ON and assumed the fade-in start, so on v31.27+ it would have played the wrong mode and flagged F2. It now
  sets freestyle explicitly and plays BOTH starts (setting "start": pier / fadein, shown in the report).
- tools/uicheck.py: a scenario may run 3000 s (was 1500 s: the 13 "no output" scenarios of check1 hit that limit) and
  the virtual-time budget is 380 s (was 260 s; the cast data now reach 120 s).
- A kit for the Mac is in the separate zip hm64-uicheck-kit_v31-29_2026-11-23.zip: run_hm64_uicheck.sh (default tag
  check2, so check1 stays as it is) + hm64-uicheck-kit.tar.gz.

OPEN (your call)
- Normal mode, fade-in start: a stray Space between the dock-end tap and 1.5 s before the cast is still fitted with the
  sequence and can re-read the taps the same way. A player has no reason to press Space there, so it was left alone; the
  same rule as freestyle (after the dock-end tap, no more sequence taps) would close it, at the cost of no longer
  correcting an accidental early dock-end tap with a later one.

lab_changes/ is cumulative since v31.25 (your lab tree).
