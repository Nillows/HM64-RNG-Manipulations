/* HM64 pier zones (v32.23, Thomas 2026-11-26: "integrate it into the cut logic of the turn and load in the separate
   tables to sit atop the existing stable ones"). Pages whose cast pack has zone tables (rainy since v32.23, sunny since
   v32.27: Thomas 2026-11-26 19:53 "lets do the full sunny tables"); loaded right after the page data, before every other script.

   Why: in the rain the dog walks far, and a dog whose tile is off the camera's visibility grid draws no random numbers
   [DECOMP entity.c / animals.c]. The camera follows Jack, and the end of the pier has three camera zones (north: all
   recordings; middle; south). The cast pack (tools/zone_build.py) holds one table per zone in one file:
   lines[key].idx = the BASE table (a Power Nut only where it holds from all three zones), and pack.zones.d[zone][key] =
   [frame, cast, frame, cast, ...] = the frames that differ in that zone. Here lines[key].idx becomes a getter that
   answers for the zone in use, so every reader of the pack follows it without knowing about zones. The route tables'
   flags per zone (route.zones) are read by the Lucky computation itself (a preset with a 2nd cut = that zone's series).

   Zone in use: on the Lucky Timer the selected preset's 2nd cut (HM64Lucky.select tells this file); on the Casting
   tables and Dog practice pages the picker this file adds. 'all' = not known = the base table. */
(function (root) {
'use strict';
const D = (typeof HM64_DATA !== 'undefined' && HM64_DATA) || null, PG = (typeof HM64_PAGE !== 'undefined' && HM64_PAGE) || {};
const pack = D && (D.dogcast || D.pack) || null, Z = pack && pack.zones;
if (!Z) { root.HM64Zone = null; return; }
const ORDER = ['all', 'north', 'middle', 'south'], KEY = 'hm64v32_pierzone';
const NAME = { all: 'Not sure', north: 'North', middle: 'Middle', south: 'South' };
const BAND = { all: 'anywhere on the pier end', north: '2nd cut frames 1–3', middle: '2nd cut frames 4–8', south: '2nd cut frames 9–11' };
const DESC = {
  all: 'You do not know where Jack stops on the end of the pier. The tables count a Power Nut only where it comes on the same bite at the same moment from the north end, the middle and the south end.',
  north: 'You cut down-right onto the pier in the first 3 game frames it is possible: Jack stops at the north end of the pier end (the edge nearest the beach). The lab recorded every cast from here, so this is the full table.',
  middle: 'You cut down-right in game frames 4–8 of the pier window: Jack stops in the middle of the pier end. This table holds the casts measured from the middle, with the Nuts that exist only there.',
  south: 'You cut down-right in game frames 9–11 of the pier window (the last ones that still reach the end): Jack stops at the south end. This table holds the casts measured from there, with the Nuts that exist only there.' };
let cur = 'all';
const subs = [];
const store = {
  get() { try { const o = JSON.parse(localStorage.getItem(KEY) || '{}'); return ORDER.includes(o[PG.set]) ? o[PG.set] : null; } catch (e) { return null; } },
  set(z) { try { const o = JSON.parse(localStorage.getItem(KEY) || '{}'); o[PG.set] = z; localStorage.setItem(KEY, JSON.stringify(o)); } catch (e) { /* private mode */ } } };
/* each line's table per zone, built the first time it is asked for */
for (const key of Object.keys(pack.lines)) {
  const ln = pack.lines[key], base = ln.idx, tabs = { all: base };
  const of = z => {
    let t = tabs[z];
    if (!t) { t = base.slice(); const d = (Z.d[z] || {})[key]; if (d) for (let q = 0; q < d.length; q += 2) t[d[q]] = d[q + 1]; tabs[z] = t; }
    return t;
  };
  Object.defineProperty(ln, 'idx', { get() { return of(cur); }, enumerable: true, configurable: true });
  Object.defineProperty(ln, 'idxOf', { value: of, enumerable: false });
}
const unp = {}; for (const z of ORDER) unp[z] = new Set((Z.unproven && Z.unproven[z]) || []);
function set(z, opts) {
  if (!ORDER.includes(z)) z = 'all';
  if (z === cur) return false;
  cur = z;
  if (!(opts && opts.quiet)) for (const f of subs.slice()) { try { f(cur); } catch (e) { if (root.console) root.console.error(e); } }
  paint();
  return true;
}
/* the zone of a preset (group) of a route with zone tables: its 2nd-cut tag, or 'all' */
function ofGroup(R, g) {
  const ax = R && R.zones && g && g.ax ? g.ax[R.zones.axis || 'cut2'] : null;
  return ax && ORDER.includes(ax) ? ax : 'all';
}
const groupId = z => (z && z !== 'all' ? 'cut2-' + z : 'all');   // the preset of a zone with any wait
/* arrivals per zone for pages that carry them as plain lists (Dog practice: route.arr) */
for (const r of (D.routes || [])) {
  if (!r.arrz) continue;
  const base = r.arr;
  Object.defineProperty(r, 'arr', { get() { return r.arrz[cur] || base; }, enumerable: true, configurable: true });
}
const pctOf = (a, b) => (b ? Math.round(100 * a / b) + '%' : '—');
function countsTxt(z) {
  const rp = Z.report || {}, n = rp.north && rp.north.frames_nut_1_6, a = rp.all && rp.all.frames_nut_1_6;
  if (z === 'north') return n ? `${n.toLocaleString('en-US')} cast frames with a Power Nut (the whole recording)` : '';
  if (z === 'all') return a && n ? `${a.toLocaleString('en-US')} cast frames with a Power Nut hold from every zone (${pctOf(a, n)} of the north table)` : '';
  const c = rp[z]; if (!c) return '';
  const kept = (c.recorded_nut_kept_measured || 0) + (c.recorded_nut_kept_copied || 0), only = (c.zone_only_nut_new || 0) + (c.zone_only_nut_other_bite || 0);
  return `${(c.frames_nut_1_6 || 0).toLocaleString('en-US')} cast frames with a Power Nut on the dog lines that reach this zone: ${kept.toLocaleString('en-US')} as recorded at the north end + ${only.toLocaleString('en-US')} that exist only here; ` +
    `${(c.recorded_nut_lost || 0).toLocaleString('en-US')} recorded ones are fish here` + (((c.recorded_nut_not_proven || 0) + (c.line_not_measured || 0)) ? `, ${((c.recorded_nut_not_proven || 0) + (c.line_not_measured || 0)).toLocaleString('en-US')} are not proven here yet (shown as fish)` : '');
}
const noteTxt = z => `<b>${z === 'all' ? 'Any 2nd cut' : NAME[z] + ' (' + BAND[z] + ')'}</b>${z === 'middle' ? ' (the default: the biggest zone)' : ''}: ${DESC[z]}${countsTxt(z) ? ' ' + countsTxt(z) + '.' : ''}` +
  (unp[z].size ? ` ${unp[z].size} dog line${unp[z].size > 1 ? 's are' : ' is'} marked “not proven here”: never cast away from the north end, so ${unp[z].size > 1 ? 'their' : 'its'} Power Nut casts count as fish unless a measured line shares the cast.` : '');
/* the picker (Casting tables, Dog practice): four buttons + a note */
let box = null;
function paint() {
  if (!box) return;
  for (const b of box.querySelectorAll('button[data-z]')) b.classList.toggle('on', b.dataset.z === cur);
  const n = box.querySelector('.pznote'); if (n) n.innerHTML = noteTxt(cur);
}
function mount(after, onPick) {
  if (!after || box) return box;
  if (!document.getElementById('pzCss')) {
    const st = document.createElement('style'); st.id = 'pzCss';
    st.textContent = '.pzbox{flex:1 1 100%;margin:6px 0 2px;padding:6px 8px;border:1px solid var(--line,#2c4a3c);border-radius:8px}.pzbox .pzrow{display:flex;gap:6px;flex-wrap:wrap;align-items:center}' +
      '.pzbox button{padding:3px 10px;border-radius:14px}.pzbox button.on{background:var(--ok,#5fd38d);color:#06140d;font-weight:700}.pzbox .pznote{margin-top:4px;color:var(--mut,#9fb5a8);font-size:12px;line-height:1.35}' +
      '.pzbadge{color:#ffb86b;font-weight:600;white-space:nowrap}';
    document.head.appendChild(st);
  }
  box = document.createElement('div'); box.className = 'pzbox small'; box.id = 'pzBox';
  box.innerHTML = (PG.rainy
    ? '<div class="pzrow"><b title="Rain: where Jack stops on the end of the pier moves the camera, and a dog that walks off the camera’s grid stops drawing random numbers. Each part of the pier end has its own table.">Rain · where Jack stops on the pier end (your 2nd cut):</b>'
    : '<div class="pzrow"><b title="Where Jack stops on the end of the pier moves the camera, and a dog that walks off the camera’s grid stops drawing random numbers. Each part of the pier end has its own table. On a sunny morning that changes few casts, mostly late ones.">Where Jack stops on the pier end (your 2nd cut):</b>') +
    ORDER.map(z => `<button data-z="${z}" title="${DESC[z].replace(/"/g, '&quot;')}">${z === 'all' ? 'Not sure' : NAME[z] + ' · ' + BAND[z].replace('2nd cut ', '')}</button>`).join('') + '</div><div class="pznote"></div>';
  after.parentNode.insertBefore(box, after.nextSibling);
  for (const b of box.querySelectorAll('button[data-z]')) b.onclick = () => { const z = b.dataset.z; b.blur(); if (set(z)) { store.set(z); if (onPick) onPick(z); } };
  paint();
  return box;
}
/* default: the middle zone (Thomas 2026-11-26 10:22: the biggest zone, 45% of the plays); the Lucky Timer's own preset decides there */
if (PG.kind !== 'lucky') cur = store.get() || 'middle';
/* "How it works": one paragraph about the zones, put in front of whatever the page writes */
const HELP = !PG.rainy ? '<p><b>The pier zones (v32.27).</b> A dog off the camera’s grid stops drawing random numbers. The camera follows Jack, so where he stops on the end of the pier can change what a cast catches. ' +
  'On a sunny morning the dog seldom walks that far in the first minute, so nearly every Power Nut cast holds from all three zones; what changes is mostly later bites of later casts. ' +
  'The end has three camera zones, set by your 2nd cut (down-right onto the pier): <b>North</b> = the first 3 game frames the cut is possible (where the lab recorded everything), <b>Middle</b> = frames 4–8, <b>South</b> = frames 9–11. ' +
  'Each zone has its own table: every recorded cast whose dog comes near a tile the zones see differently was cast again from the middle and from the south end, and the table shows what was measured there. <b>Not sure</b> uses the base table: a Nut only where it comes on the same bite at the same moment from all three. ' +
  'A recorded Nut that does not come in your zone, or was not proven there, is shown as a fish and left out of the odds.</p>' : '<p><b>Rain: the pier zones (v32.23).</b> In the rain the dog walks far, and a dog off the camera’s grid stops drawing random numbers. The camera follows Jack, so where he stops on the end of the pier decides which casts hold. ' +
  'The end has three camera zones, set by your 2nd cut (down-right onto the pier): <b>North</b> = the first 3 game frames the cut is possible (where the lab recorded everything), <b>Middle</b> = frames 4–8, <b>South</b> = frames 9–11. ' +
  'Each zone has its own table: the recorded casts that were measured again from there, plus the Power Nuts that exist only there. <b>Not sure</b> uses the base table: a Nut only where it comes on the same bite at the same moment from all three. ' +
  'A recorded Nut that does not come in your zone is shown as a fish and left out of the odds. Since v32.25 every dog line has been cast from every zone it can stand in.</p>';
root.addEventListener('load', () => {
  const hb = document.getElementById('helpBtn'), old = hb && hb.onclick, body = document.getElementById('helpBody');
  if (hb && old && body) hb.onclick = ev => { old.call(hb, ev); if (body.innerHTML.indexOf(PG.rainy ? 'Rain: the pier zones' : 'The pier zones (v32.27)') < 0) { const i = body.innerHTML.indexOf('<p><b>'); body.innerHTML = i >= 0 ? body.innerHTML.slice(0, i) + HELP + body.innerHTML.slice(i) : body.innerHTML + HELP; } };
});
root.HM64Zone = {
  has: true, order: ORDER, names: NAME, bands: BAND,
  get cur() { return cur; }, set, store, ofGroup, groupId, mount, noteTxt, countsTxt,
  /* the Lucky Timer: its selected preset decides (HM64Lucky.select calls this); other pages keep their own pick */
  follow(R, g) { if (PG.kind === 'lucky' && R && R.zones) { const z = ofGroup(R, g); if (set(z)) store.set(z); } },
  onChange(f) { subs.push(f); },
  label: z => (z === 'all' ? 'anywhere on the pier end' : NAME[z || cur].toLowerCase() + ' of the pier end'),
  unproven: (key, z) => unp[z || cur].has(key),
  /* does the Power Nut of the cast on pack label kc, bite n, of this line hold wherever Jack stops (= is it in the base table)? */
  everywhere(key, kc, n) {
    const ln = pack.lines[key]; if (!ln) return false;
    const j = (kc - ln.k0) / 2, ix = ln.idxOf('all'); if (j < 0 || j >= ix.length || ix[j] < 0) return false;
    let st = pack.S[ix[j]], q = 1;
    while (st >= 0 && q < n) { if (pack.N[st] < 0) return false; st = pack.X[st]; q++; }
    return st >= 0 && pack.O[st] === 'N';
  },
  badge: (key, z) => (unp[z || cur].has(key) ? ' <span class="pzbadge" title="This dog line was never cast away from the north end of the pier end. Its Power Nut casts are shown as fish until the lab has measured it here (a cast it shares with a measured line counts).">not proven here</span>' : ''),
  letters: Z.letters || {}, report: Z.report || {},
};
})(typeof window !== 'undefined' ? window : globalThis);
