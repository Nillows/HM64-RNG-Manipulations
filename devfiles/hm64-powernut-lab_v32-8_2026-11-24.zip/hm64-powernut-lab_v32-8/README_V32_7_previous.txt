HM64 Power Nut Tool v32.7 (2026-11-24): the guide page, "Not working?", How it works as a forest
================================================================================================

What you asked for (2026-11-24 11:43)
  "the actual app itself should have the instructions for the setup and beach traversal on it ... as its own html, and
  accessible from the hub, as well as from the lucky timer and casting tables themselves. something that the player can
  see under a "Not Working?" button on the tool pages themselves that takes them to the specifics."
  The README's "how it works" as the forest analogy, with simple vector pictures next to real data; "make a set of tools
  yourself so that you can create these kinds of simplified vector 2d diagrams yourself"; a punnet square of L1
  (rain / no rain x horse / no horse) with placeholders for rain; sunny data for the single-branch pictures.

What changed
  Site
    - guide.html (new page, the second file of the site): 1 your game file (opens on the file ticked in the hub, or the
      one the tool page links: what it needs, how to make it, its pages), 2 the route (menus, sparrows, house / farm /
      crossroads / ranch, with the README's clips), 3 the beach (zigzag, the dog waking, the pier cuts, Space at READY,
      staying awake), Not working? (10 answers, each with its own link), How it works (the 10 forest pictures).
    - Every tool page's footer: "Guide" and an orange "Not working?". The button opens a short checklist (what this
      page's game file needs, then 10 problems, most common first); each line opens its answer in the guide in a new
      tab, so the attempt on the page is kept. Keys pressed while it is open do not reach the tool. Esc closes it.
    - Hub: "Guide" and "Not working?" under the three buttons, opened on the file you ticked.
    - site.json v32.7; the horse file's first "needs" line corrected (it draws more on the farm, the crossroads and the
      ranch, not only at the ranch: measured, below).
    - The data in every page is byte-identical to v32.6 (apart from the version).
  README (pages zip)
    - New section "How it works: a leaf in a forest" (before "How the odds are worked out"): the forest, why not search
      down, bottom-up from seed 0, the crown of 7 with the sparrows, sunlight, three crowns, the pier moment, the leaves,
      describing the dog, the tuner, L1 across game files; 10 SVG pictures in media/. Quick start: Not working? with two
      screenshots; the hub picture retaken; "about 31,000 plays" now says what they are (30,976 plays on the beach).
  Diagram toolkit (lab)
    - tools/forest_facts.py: reads lab output into webapp/assets/forest_facts.json (stage counts per menu crown from a
      dog-watch run, the reference-route draws of each game file, each table's dog lines, families, L1 and its Nut
      frames, the shape narrowing, twins between files).
    - tools/forest_svg.py: draws every picture from that file (python3 tools/forest_svg.py webapp/assets/forest_facts.json
      --out media/ ; --list ; --only punnet tuner). When the rain tables are in, add them with --routes and the rainy
      cells of the punnet square fill in.
    - data/forest_z0/: the four reference-route records the sunlight picture uses (two recorded in the sandbox today
      from your saves; no save or ROM data in them).
    - The command that made v32.7's facts:
        python3 tools/forest_facts.py --raw <the horse dog-watch run folder> --raw-label "Sunny, horse" \
          --z0 "Sunny, no horse=data/forest_z0/sunny-no-horse_52cfd712.json" --z0 "Sunny, horse=data/forest_z0/sunny-horse_b0f2a284.json" \
          --z0 "Rainy, no horse=data/forest_z0/rainy-no-horse_8e972d75.json" --z0 "Rainy, horse=data/forest_z0/rainy-horse_287c11a6.json" \
          --routes "sunny-no-horse=webapp/assets/lucky_routes.json#lineup-lineup2" \
          --routes "sunny-horse=webapp/assets/lucky_routes_sunny-horse.json#lineup-lineup2-horse" \
          --routes "sunny-no-horse-sparrows=webapp/assets/lucky_routes.json#lineup-lineup2-sparrow-door" \
          --routes "sunny-horse-sparrows=webapp/assets/lucky_routes_sunny-horse.json#lineup-lineup2-horse-sparrow-door" \
          --pending "rainy-no-horse=Rainy, no horse" --pending "rainy-horse=Rainy, horse" --out webapp/assets/forest_facts.json

Found while making the pictures
  - Sunny no horse and Sunny horse share the same L1: the same dog line, every move and every Nut frame, 3 game frames
    (6 VIs) earlier on the horse file.
  - The slack after the menus is 34 game frames (68 VIs, about 1.14 s): house 4, crossroads 3, beach 27 (first step 15,
    first cut 1, pier window 11).
  - Rain: READY at draw 10,593 instead of 1,259 (13-19 draws per game frame outdoors). Rainy horse = rainy no horse on the
    reference route.

Checks (sandbox, headless Chrome)
  - tests/ui_guide.js (+ pre_guide_hub.js), tests/ui_notworking.js on a Lucky Timer, a Casting tables and a Dog practice
    page, tests/ui_hub_guide.js; every Not working? link has its answer in guide.html.
  - Unchanged: page data (byte-equal), hub picker, Try it, Dog practice drills.
  - Release script rev f (unchanged) in the mock Mac with these zips: guide.html and the forest pictures arrive in the
    clone, the lab tools in ~/Documents/hm64.

Files (lab_changes/, cumulative)
  new: tools/forest_facts.py, tools/forest_svg.py, webapp/assets/forest_facts.json, data/forest_z0/*.json,
       webapp/site/templates/guide.html, tests/ui_guide.js, tests/pre_guide_hub.js, tests/ui_notworking.js,
       tests/ui_hub_guide.js
  changed: tools/site_build.py (guide page, page.guide / page.needs), webapp/hm64_site_v32.js (Not working?),
       webapp/site/templates/{hub,lucky_timer,casting_tables,practice}.html, webapp/site/partials/site_css.html,
       webapp/site/site.json

Release
  bash ~/Documents/hm64/tools/hm64_release.sh v32-7 <lab sha256> <pages sha256> </dev/null
