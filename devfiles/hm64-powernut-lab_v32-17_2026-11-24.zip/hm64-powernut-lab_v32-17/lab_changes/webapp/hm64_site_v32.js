/* HM64 site pages (v32.0, Thomas 2026-11-23): the glue a generated page needs around the app's modules.
   The site = a hub (index.html) + one single-file page per game-file circumstance and page kind (Lucky Timer,
   Casting tables, Dog practice); HM64_PAGE (written by tools/site_build.py) says which page this is and where its
   neighbours are.
   - Lucky Timer page: the "How it works" text loses the paragraphs of pages that are gone (the old Dog Oracle, the
     two-arena footer; the Dog reference did this filtering while it lived on the same page) and gains "Pages".
   - Casting tables page: "How it works" opens with this page's paragraph; the Dog reference adds its own after it.
   - v32.5 (Thomas 2026-11-23 19:52: "add explanations in plain english ... in the charts of the app as well"): every
     page's "How it works" has "How the odds are worked out" (HM64Why.text), and the Lucky Timer's histogram an ⓘ fold
     that says what its bars are right now (freestyle with a dog / freestyle without / the app's own odds). The Dog
     practice page gets its own help.
   Included on the Lucky Timer page AFTER the app (which sets the help button), on the casting page BEFORE the Dog
   reference (which wraps whatever the help button does), on the practice page before the drills. */
(function (root) {
  'use strict';
  const P = (typeof HM64_PAGE !== 'undefined' && HM64_PAGE) || null, $ = id => document.getElementById(id);
  const DATA = (typeof HM64_DATA !== 'undefined' && HM64_DATA) || null;
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const GUIDE = 'https://github.com/Nillows/HM64-RNG-Manipulations#how-the-odds-are-worked-out';
  /* how many plays of the route the lab made for this page's main table (route source: member routes) */
  const plays = () => {
    const rs = (DATA && (DATA.lroutes || DATA.routes)) || [], r = rs.find(x => !x.variant_of) || rs[0];
    const n = r ? (r.source && r.source.members) || r.plays : null;
    return n ? Math.round(n / 1000).toLocaleString('en-US') + ',000' : 'tens of thousands of';
  };
  /* v32.5: the plain-English account, the same on every page (the guide's section has the long version) */
  const why = () => `<p><b>How the odds are worked out.</b> The lab replayed this game file's route about ${plays()} ways a good player
    might play it: mashing the menus at 5–15 presses a second, turning in the house and at the crossroads at any moment
    that still reaches the next screen within a few frames of the fastest, starting on the beach up to half a second late, cutting onto the pier anywhere across it. Every choice
    in its window counts as equally likely. Each play ends on one <i>dog line</i> (one path of the game's random numbers,
    which the dog acts out) reached at one <i>timing</i> (a few frames earlier or later); that pair is an <i>arrival</i>,
    and its <i>weight</i> is the share of the plays that reach it. For every dog line and every cast frame (1/30 s) up to
    120 s the lab recorded every bite and what it catches. So a bar or candle is the weighted share of the arrivals still
    in play whose cast on that frame lands the Power Nut (green: on the 1st bite; gold: on the 2nd, holding the 1st).
    Your B press is never exact, so the odds of a cast are those bars blurred by your press: a bell curve with the spread
    you set (±150 ms = about 2 presses in 3 within 150 ms), or every frame of a 1-s window alike for a blind cast.
    Watching the dog narrows the arrivals: a sign keeps only the arrivals that show it, and each dog-watch key multiplies
    a line by how well it fits (a key it does not show ×0.02, a turn you did not key ×0.1). 1 in 51 is the game's base
    chance per catch. Emulator data, not measured on a console. <a href="${GUIDE}" target="_blank" rel="noopener">The long version (guide)</a>${P && P.practice && P.kind !== 'practice' ? ` · try the mechanic on the <a href="${esc(P.practice)}">Dog practice</a> page` : ''}.</p>`;
  root.HM64Why = { text: why, guide: GUIDE };
  /* v32.7 (Thomas 2026-11-24 11:43: "something that the player can see under a "Not Working?" button on the tool pages
     themselves that takes them to the specifics"): the footer's Not working? opens a short list of what to check, most
     common first, each linked to its answer on the guide page (a new tab, so the attempt on this page is kept). Without
     the script the button is a plain link to the guide's Not working? section. v32.15 (Thomas 16:05): Not working? is a
     page of its own (not-working.html), the answers are its anchors; setup, route and beach stay on the guide. */
  const NW = [['nw-file', 'Am I on the right tables?'], ['nw-dog', 'The dog is not at the lower-left edge when Jack stops'],
    ['nw-pier', 'Jack does not reach the end of the pier'], ['nw-sparrows', 'Sparrows: tick the box or not?'],
    ['nw-nocard', 'No dog card matches what my dog does'], ['nw-off', '"Off the tables": my bite taps fit no dog line'],
    ['nw-miss', 'The dog matches, but my casts miss the Nut'], ['nw-awake', 'Jack lay down before I cast'],
    ['nw-rain', 'It is raining'], ['nw-page', 'The page is slow, blank, or ignores my keys']];
  function notWorking() {
    const btn = document.getElementById('nwBtn');
    if (!P || !btn || typeof document.createElement('dialog').showModal !== 'function') return;
    const g = (P.guide || 'guide.html') + '?set=' + encodeURIComponent(P.set || '');
    const nw = (P.notworking || 'not-working.html') + '?set=' + encodeURIComponent(P.set || '');
    const dlg = document.createElement('dialog');
    dlg.id = 'nwDlg';
    dlg.style.cssText = 'max-width:560px;width:calc(100% - 24px);background:#0f1c27;color:#dce6ec;border:1px solid #6a5530;border-radius:10px;padding:14px 18px;font:14px/1.5 system-ui,sans-serif';
    const needs = (P.needs || []).map(x => `<li>${esc(x)}</li>`).join('');
    dlg.innerHTML = `<div style="display:flex;justify-content:space-between;align-items:baseline;gap:10px"><b style="font-size:16px;color:#f0b35a">Not working?</b><button type="button" id="nwClose" title="Close (Esc)">✕</button></div>
      <div style="color:#8ea3b2;font-size:13px;margin:2px 0 8px">Check these, most common first. Each opens its answer on the Not working? page (a new tab: this page keeps your attempt).</div>
      <details style="margin:0 0 8px"><summary style="cursor:pointer">This page is for <b>${esc(P.set_label || '')}</b>: what that game file needs</summary><ul style="margin:6px 0;padding-left:20px;font-size:13px">${needs}</ul>
      <a href="${esc(g)}#setup-${esc(P.set || '')}" target="_blank" rel="noopener">How to make it (guide)</a></details>
      <ol style="margin:0;padding-left:22px">${NW.map(([id, t]) => `<li style="margin:3px 0"><a href="${esc(nw)}#${id}" target="_blank" rel="noopener">${esc(t)}</a></li>`).join('')}</ol>
      <div style="margin-top:10px;font-size:13px"><a href="${esc(nw)}" target="_blank" rel="noopener">All the answers on one page</a> · <a href="${esc(g)}#route" target="_blank" rel="noopener">the whole route, step by step</a> · <a href="${esc(g)}#beach" target="_blank" rel="noopener">the beach zigzag</a> · <a href="${esc(P.hub || 'index.html')}">⌂ Hub</a></div>`;
    document.body.appendChild(dlg);
    dlg.querySelector('#nwClose').onclick = () => dlg.close();
    dlg.addEventListener('click', e => { if (e.target === dlg) dlg.close(); });
    dlg.addEventListener('keydown', e => e.stopPropagation());     // the tool's keys stay off while the list is open
    btn.addEventListener('click', e => {
      if (e.ctrlKey || e.metaKey || e.shiftKey || e.button) return;   // a new tab / window: the plain link
      e.preventDefault();
      dlg.showModal();
      btn.blur();
    });
    root.HM64NotWorking = { open: () => dlg.showModal(), items: NW };
  }
  /* v32.16 (Thomas 2026-11-24 16:45): your keys, timing and practice are on the Settings page, which shares this page's
     storage on the website. A page opened from a folder keeps its own (Firefox), so the footer's "⇅ Settings file" moves
     everything through a file: export it from the website's Settings page and import it here, or the other way round. */
  function settingsFile() {
    const TM = root.HM64Timing, link = document.querySelector('footer a[href="settings.html"]');
    if (!TM || !link || typeof document.createElement('dialog').showModal !== 'function') return;
    const btn = document.createElement('a');
    btn.className = 'btnlink'; btn.href = '#'; btn.id = 'sfBtn'; btn.textContent = '⇅ Settings file';
    btn.title = 'Export everything this page keeps (keys, timing, practice, attempts) to a file, or import such a file: for a page opened from a folder on your computer';
    link.insertAdjacentElement('afterend', btn);
    const dlg = document.createElement('dialog');
    dlg.id = 'sfDlg';
    dlg.style.cssText = 'max-width:520px;width:calc(100% - 24px);background:#0f1c27;color:#dce6ec;border:1px solid #36546a;border-radius:10px;padding:14px 18px;font:14px/1.5 system-ui,sans-serif';
    dlg.innerHTML = `<div style="display:flex;justify-content:space-between;align-items:baseline;gap:10px"><b style="font-size:16px">Your settings file</b><button type="button" id="sfClose" title="Close (Esc)">✕</button></div>
      <div style="color:#8ea3b2;font-size:13px;margin:4px 0 8px">Your keys, timing, practice and attempts live in your browser, per website: every page of the
      website shares them (set them on the <a href="settings.html" target="_blank" rel="noopener" style="color:#6fb7ff">Settings</a> page). A page opened from a folder on your
      computer keeps its own. Move them with a file: export where they are, import where you want them. ${location.protocol === 'file:' ? '<b style="color:#f0b35a">This page is opened from a file.</b>' : ''}</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap"><button type="button" id="sfExport">Export to a file</button><button type="button" id="sfImport">Import from a file</button><input type="file" id="sfFile" accept=".json,application/json" hidden></div>
      <div id="sfTxt" style="color:#8ea3b2;font-size:13px;margin-top:6px"></div>`;
    document.body.appendChild(dlg);
    const $d = id => dlg.querySelector('#' + id);
    $d('sfClose').onclick = () => dlg.close();
    dlg.addEventListener('click', e => { if (e.target === dlg) dlg.close(); });
    dlg.addEventListener('keydown', e => e.stopPropagation());     // the tool's keys stay off while it is open
    $d('sfExport').onclick = () => {
      const o = TM.exportAll(), n = Object.keys(o.keys).length, a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([JSON.stringify(o, null, 1)], { type: 'application/json' }));
      a.download = `hm64-settings_${new Date().toISOString().slice(0, 10)}.json`; document.body.appendChild(a); a.click(); a.remove();
      $d('sfTxt').textContent = `Saved ${n} stored item${n === 1 ? '' : 's'} to ${a.download}.`;
    };
    $d('sfImport').onclick = () => $d('sfFile').click();
    $d('sfFile').onchange = e => {
      const f = e.target.files && e.target.files[0]; if (!f) return;
      f.text().then(t => {
        const o = JSON.parse(t), n = Object.keys(o.keys || {}).length;
        if (!confirm(`Replace ${n} stored item${n === 1 ? '' : 's'} of this page with the ones in ${f.name} (saved ${o.at || '?'})? The page reloads with them.`)) return;
        TM.importAll(o); location.reload();
      }).catch(err => { $d('sfTxt').textContent = 'Not an HM64 settings file: ' + (err && err.message || err); });
      e.target.value = '';
    };
    btn.addEventListener('click', e => { e.preventDefault(); dlg.showModal(); btn.blur(); });
    root.HM64SettingsFile = { open: () => dlg.showModal() };
  }
  if (typeof document !== 'undefined') {
    const both = () => { notWorking(); settingsFile(); };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', both); else both();
  }
  if (!P || !$('helpBtn') || !$('helpBody') || !$('helpDlg')) return;
  const link = (href, txt) => (href ? `<a href="${esc(href)}">${esc(txt)}</a>` : '');
  const KIND = { lucky: 'Lucky Timer', casting: 'Casting tables', practice: 'Dog practice' };
  const others = [P.kind !== 'lucky' && P.lucky ? 'the ' + link(P.lucky, 'Lucky Timer') + ' is the live tool' : '',
    P.kind !== 'casting' && P.casting ? 'the ' + link(P.casting, 'casting tables') + ' hold the Dog reference and Optimal Blind Casting' : '',
    P.kind !== 'practice' && P.practice ? link(P.practice, 'Dog practice') + ' has drills on its real dog lines' : ''].filter(Boolean);
  const pages = `<p><b>Pages.</b> This page is the <i>${KIND[P.kind] || P.kind}</i> for
    <i>${esc(P.set_label)}</i>: it holds only that game file's tables. The ${link(P.hub, 'hub')} lists every game-file
    circumstance and its pages${others.length ? '; for this one, ' + others.join('; ') : ''}.
    Each page is one file: save it and it works offline. Your settings stay with the file in your browser.</p>
    <p><b>Settings (v32.16).</b> Your keys (start key, dog facing, animations, card timing), your timing (start-tap delay,
    B-press correction, timing spread), the cast tap, sound, the console frame period, cast practice, bite practice and the
    one attempt count of every page are on the <a href="settings.html" target="_blank" rel="noopener">Settings</a> page:
    one place for every page of the tool. This page's own <i>⚙ Settings</i> button is now <i>⚙ Options</i> (route, dog-watch,
    release line, display). Where an older paragraph below says <i>L5 · Your timing</i>, <i>Settings → Lucky Timer</i> for
    keys, the cast tap or sound, or the practice buttons, read: the Settings page; for anything else in <i>Settings →</i>, read
    <i>⚙ Options</i>. A page opened from a folder keeps its own
    copy: the footer's <i>⇅ Settings file</i> moves them through a file.</p>`;
  if (P.kind === 'lucky') {
    /* v32.1 (Thomas 2026-11-23): the Spring 9 dog-carry and dog-beach routes are retired; the hub pages hold beach-lineup2
       and its permutations (weather, horse, ...), so their paragraphs go too and one Route paragraph for this page comes in */
    const GONE = ['Dog paths.', 'Your keys and names.', 'Scrub bar (03).', 'Tap search.', 'Flickers.', 'Logging.', 'Potential dogs.', 'Histogram.', 'Line-up methods (03).', 'After the cast', 'Two arenas',
                  'Lucky Timer: pace and start.', 'Lucky Timer: routes.'];
    const lr = (DATA && DATA.lroutes) || [];
    const base = lr.find(r => !r.variant_of), spar = lr.some(r => r.variant === 'sparrows');
    const route = base ? `<p><b>Route.</b> This page has one route, ${esc(base.label)}: the dog left in the far
      south-west corner of the beach the day before, the zig-zag route, one Space tap when Jack stops at the end of the
      pier. ${spar ? 'Mornings with sparrows at the door (your menus 5–6 frames late) have a second table: tick <i>Sparrows at the door</i> in L1 (or press S) when you see them.' : 'No sparrows come to the farm on this morning, so there is one table for every menu speed.'}
      Attempts, taps, the start and the preset are kept per table. Another game file (weather, horse, ...) has its own page: see the hub.</p>` : '';
    const hb = $('helpBtn'), old = hb.onclick;
    if (old) hb.onclick = ev => {
      old.call(hb, ev);                                             // fills helpBody with the app's text and opens it
      const parts = $('helpBody').innerHTML.split(/(?=<p><b>)/).filter(p => !GONE.some(g => p.startsWith('<p><b>' + g)));
      $('helpBody').innerHTML = parts[0] + pages + route + why() + parts.slice(1).join('');
    };
    /* v32.5: the histogram's own explanation, for the mode it is in right now */
    const tl = $('lkTimeline'), A = root.HM64LuckyApp;
    if (tl && A) {
      const d = document.createElement('details'); d.id = 'lkWhy'; d.className = 'small';
      d.style.cssText = 'margin:2px 0 4px;color:var(--mut)';
      d.innerHTML = '<style>#lkWhy a,#helpBody a{color:#6fb7ff}</style><summary style="cursor:pointer">ⓘ What the bars mean, and where the odds come from</summary><div id="lkWhyTxt" style="margin:4px 0 2px;line-height:1.45;max-width:1100px"></div>';
      tl.insertAdjacentElement('afterend', d);
      const txt = () => {
        let fs = false, pick = null, sig = 150;
        try { fs = !!A.fsOn(); pick = A.run && A.run.dw ? A.run.dw.pick : null; sig = Math.round(A.sigmaMs()); } catch (e) { /* app not ready */ }
        const head = fs && pick ? `<b>Freestyle, your dog chosen.</b> Each bar is one cast frame (1/30 s) on which <b>that dog</b>, at the timing you tuned, lands the Power Nut —
            green: let go at the 1st bite; gold: hold the 1st, let go at the 2nd. Nothing is averaged any more: a bar is the lab's yes for that exact frame, if your dog and its timing are right.
            What is left is your press: a double (two neighbouring frames, 67 ms) is worth about 29% with a press spread of ±150 ms and about 47% at ±60 ms.`
          : fs ? `<b>Freestyle, no dog chosen yet.</b> Freestyle draws a dog's own Nut frames once you choose it: click the card that does what your TV dog does, or press <kbd>Enter</kbd> when the top card is yours, then tune it with <kbd>[</kbd> <kbd>]</kbd>.`
          : `<b>The app's own odds.</b> A bar's height is the chance that a cast at that moment lands the Power Nut, counted over every arrival still in play
            (a dog line reached at a timing; how often the route reaches each is its weight), with your B press spread of ±${sig} ms blurred in as a bell curve.
            Your taps and dog-watch keys re-weight the arrivals; with a dog chosen only its arrivals count. The bold CAST line sits on the best moment still ahead.`;
        return head + ` <b>Dog cards:</b> a card's % is its line's share right now — the line's weight × how well it fits the keys you pressed (a key it does not show ×0.02, a turn you did not key ×0.1), scaled so the cards add up to 100%.` +
          ` <a href="${GUIDE}" target="_blank" rel="noopener">More in the guide</a>${P.practice ? ` · try it without a console: <a href="${esc(P.practice)}">Dog practice</a>` : ''}.`;
      };
      let last = '';
      const upd = () => { if (!d.open) return; const h = txt(); if (h !== last) { last = h; $('lkWhyTxt').innerHTML = h; } };
      d.addEventListener('toggle', upd); setInterval(upd, 1000);
      d.querySelector('summary').addEventListener('click', e => { setTimeout(() => e.target.blur(), 0); });
    }
  } else if (P.kind === 'casting') {
    $('helpBtn').onclick = () => {
      $('helpBody').innerHTML = `<h2>How the casting tables work (${esc((DATA && DATA.version) || '')})</h2>` + pages + why();
      $('helpDlg').showModal();
    };
  } else if (P.kind === 'practice') {
    $('helpBtn').onclick = () => {
      $('helpBody').innerHTML = `<h2>How the Dog practice works</h2>` + pages +
        `<p><b>What it is.</b> A test bench with no console: the "TV" plays a real dog line of this game file, drawn by how often the route reaches it (or the one you choose under <i>Dog</i>), at a real timing. Nothing here is learned or sent anywhere; your results stay in this browser.</p>
        <p><b>1 · Tune the dog.</b> The dog card plays the same line at the tool's guess of your timing — your Space tap off by up to 150 ms, the line reached a few frames earlier or later than usual — just as on the Lucky Timer after you pick a dog. Step it with your tuning keys until it turns at the very moment the TV dog does and press <kbd>Enter</kbd>. The result says how many game frames off you were and what that does to the line's next Nut casts: one frame off misses every single frame, a double forgives one frame on one side. <i>TV speed</i> slows the TV down (the dog's own animation keeps its speed; its turns come slower).</p>
        <p><b>2 · Read the dog.</b> Key what you see with your dog-watch keys: the facing whenever it turns (two keys at once = a diagonal), long animations on their keys. The cards re-weight with the Lucky Timer's own matcher. <kbd>Enter</kbd> picks the top card, a click any card. Right means your line, or a sister line that has already become the same dog.</p>
        <p><b>3 · Whole attempt.</b> Tap your start key when Jack stops, pick and tune the dog, then hold the start key to cast — it stands in for B, as the Lucky Timer reads a held Space — and let go when the float bites. The catch is the lab's record for the exact frame you cast on, with the true dog and timing, whatever you picked. Jack stays awake by himself here.</p>
        <p><b>Your keys.</b> The keys of your Lucky Timer settings (on the website every page shares them). A page saved to your computer keeps its own settings, so the keys can be changed here too (<i>change</i> next to the key list); their labels follow your keyboard layout where the browser tells it, or once you have typed the key.</p>` + why();
      $('helpDlg').showModal();
    };
  }
})(typeof window !== 'undefined' ? window : globalThis);
