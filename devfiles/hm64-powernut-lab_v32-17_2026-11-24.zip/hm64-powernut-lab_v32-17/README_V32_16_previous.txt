HM64 Power Nut Tool v32.16 (2026-11-24): Settings - your keys, timing, practice and one attempt count, for every page
=====================================================================================================================

What you asked for (2026-11-24 16:45)
  "take the tap and timing part of the application and move it to a harmonized "settings" option on the hub. the
  seperate sections can all collect and use data from each other if they ise the same format for the next page. and
  they can all add to the same integer in your local storage to keep track of number of attempts consistently. theres no
  need to have that part on every single page table individually, so bring it all under one section under the settings."
  Your picks: its own page (settings.html); timing, keys and practice move there (the attempt log stays on each page and
  feeds it); one attempt count for Lucky Timer attempts + Dog practice whole attempts; website + export / import.

What changed (v32.16 includes v32.7 - v32.15)
  - settings.html (new; hub button "Settings" with the attempt count, a footer link on every tool page, the help pages'
    top bar). Sections:
      Your attempts   ONE integer (hm64v32_attempts) + by page (hm64v32_attempts_by). Starts from what is on record (the
                      logged Lucky Timer attempts + Dog practice whole attempts).
      Your timing     the timing compass and the four rows (start taps, B press on CAST, bite taps, how much you vary);
                      the practice parts worked out live, the parts that need dog tables (clock shift, bite taps, dock-end
                      tap, where casts landed) as the Lucky Timer last worked them out (hm64v32_timing_fit). Set by hand:
                      start-tap delay (+ learn from bite taps), cast-cue correction, timing spread. Dog practice's READY
                      taps (hm64v32_starttaps) can set the start-tap delay after 5.
      Practice        the Lucky Timer's cast + bite practice (quick mode, pulses -1.5/-1/-0.5 s, press window +-0.6 s,
                      moving cast line, hold to the bite) and bite practice (hold and let go / tap): same timings, same
                      records (hm64v29_lucky_castprac, hm64v30_lucky_biteprac); start key, controller, or mouse on the picture.
      Your keys       start key, facing (arrows / WASD), the animation key table (with each animation's share of the wait,
                      worked out at build time from the first ready set's route), card-timing keys; the Lucky Timer's refusals.
      Cues            sound; the cast tap + precision.   Console: frame period (+ NTSC check / fix), stock bite-tap delay.
      Your data       export everything (all hm64* keys) to a file / import a file.
  - webapp/hm64_timing_v32.js (new, on every tool page and Settings): the shared stores (the Lucky Timer's own keys and
    formats) and its formulas copied line for line (castStats, press profile, cue correction, timing spread, bite reactions).
    Test: the same seeded store gives the same numbers on Settings and in the Lucky Timer (corr -33, spread 90, 16 presses,
    median +33, sd 17.642, bite median 220).
  - Lucky Timer: start key (L2), the compass, Set by hand, cast practice, bite practice (L5) and the front panel's practice
    buttons, the dog-watch keys / facing keys / cast tap / sound (its dialog) and the frame period / tap delay (Console
    tab) are hidden (kept in the page for the code); L5 is "What your attempts teach" with one line of the timing in use
    and a link to Settings. It saves what it learned (hm64v32_timing_fit, never during an attempt or a drill), adds 1 to
    the attempt count when an attempt starts, and takes in changes from other tabs (storage event: shared fields of
    hm64v29_lucky, practice logs, console settings; a new frame period reloads the page when idle). Its own dialog button
    is now "⚙ Options" (route, dog-watch, release line, display).
  - Casting tables: the timing spread and the stopwatch's start delay are yours from Settings (spread auto / by hand;
    start-tap delay + the clock shift the Lucky Timer learned); the page's own two controls are hidden; a line above the
    tables says which values are in use; a change in another tab redoes the tables. Fresh browser = the old defaults
    (+-150 ms, 150 ms): table checksums unchanged (2311396371 / 1548110645).
  - Dog practice: keys from Settings only (an old page key override moves into the shared store once); a whole attempt
    adds 1 to the count; the tap when Jack stops is kept as a start-tap measure; the release at a bite as a bite reaction
    (m rel, c 1, src Dog practice; up to 1 s after the last bite that showed).
  - Every tool page's footer: "Settings" (new tab) and "⇅ Settings file" (export / import for a page opened from a folder).
  - README: section "Settings: your keys, timing and practice in one place", sections 9-10 updated, new media/settings.png
    and media/settings_drill.png, hub.png / guide.png / notworking_page.png / app_notworking.png retaken.
  - Tests: ui_settings, ui_settings_lucky, ui_settings_sync, ui_settings_casting, ui_settings_practice, ui_settingsfile
    (+ pre_settings_seed / _hand / _practice); 28 Lucky Timer UI tests vs v32.15: same or noise except the expected (texts,
    version, the compass no longer drawn on the Lucky Timer); practice drills' invariants; casting checksums equal.

Release
  bash ~/Documents/hm64/tools/hm64_release.sh v32-16 <lab sha256> <pages sha256> </dev/null
