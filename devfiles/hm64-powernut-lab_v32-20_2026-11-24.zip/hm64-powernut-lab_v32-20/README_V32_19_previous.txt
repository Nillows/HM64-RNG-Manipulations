HM64 Power Nut Tool v32.19 (2026-11-24): the rainy tables enhanced
=====================================================================

What you asked for
  22:16  "ok can you use your findings to enhance the rain data, please also add the necessary casting tables, and the
         dog data for the common lines, and any harbingers you see worthy of mentioning."
  22:48  "would it be helpful to introduce multiple shades of purple if they arent part of the same bite group?"

What changed (v32.19 includes v32.7 - v32.18)
  - Rainy Casting tables, later bites: the release rules go to the 6th bite ("hold the first 4 bites, let go at the
    5th"), casts reach 120 s after Jack stops (a cast after 106 s needs a third push of the stick at about 100 s), and
    every cast says when its bite comes. min/Nut and the quick cast count the wait to that bite.
    On rain about a third of the plays have their best known-line cast on bite 3 or later.
  - New tab on the rainy Casting tables: Wide windows. For each line, every run of 3+ frames in a row where at least
    half of that line's arrivals catch the Nut on the same bite, with the cast, the bite and the odds. Examples:
    L18 108.31-108.68 s x12, 3rd bite, 75%; L9 48.41-48.61 s x7, 1st bite, 65%; L6 70.70-70.80 s, 5th bite, 39%.
  - Harbingers on the rainy pages can name a family of sister lines (the same dog after a few seconds). Optimal Blind
    Casting lists 26 signs on rain (14 on sunny). Strongest: mess facing up-right at 0.5-2 s -> 65.6 s, 5th bite, 33%;
    sniff-standing facing down-right at 2-4 s -> 24.5 s, 1st bite, 33%; flapper facing down-right at 6-8 s -> 31.1 s,
    1st bite, 30%.
  - Copy lines folded (tools/fold_copies.py). No horse L67 and horse L67 were L25 with Jack stopping one game frame
    earlier on the same path. Their plays now count under L25, and nothing moves in the odds.
    Rainy lines are now 98 / 67 (were 99 / 68). Every line name after L66 moves down one (e.g. L76 -> L75, L84 -> L83).
    L73 (no horse) has the same numbers as L25 but its dog shows another sprite for 0.47 s, so it stays its own line.
  - Lucky Timer: shades of purple. Bite 3 is lightest, then 4, 5, and 6 or later is darkest. Freestyle also writes the
    bite number over every purple group of bars. On rain 1 purple run in 10 mixed bites (e.g. 6-6-6-5 looked like four
    of a kind). Sunny has none.
  - Guide section 3.3 (rainy mornings only), a rainy line in Not working?, README: the rainy blind list, a table of
    the common rainy lines (what the dog does, cast, bite, odds), Wide windows with a screenshot.
  - Sunny pages: the same data and the same casting tables (checked). Only the purple shade for bite-3 bars changes.
  - New lab tools: tools/fold_copies.py, tools/rule_bites.py, tools/wide_windows.py, tools/purple_runs.py, plus the
    21:57 analysis tools (line_merges.py, nut_runs.py, known_line_windows.py, blind_any_bite.py, pack_extrap_test.py).
    New tests: tests/ui_rainbites.js, tests/pre_site_fadein_buttons.js.

On the Mac
  The routes in this package were built from the folded results. Before rebuilding the rainy routes from your
  result folders, run tools/fold_copies.py <dogwatch result folder> <its d170c120 FD1_lines.jsonl> --write.
  Details: claude/HM64_RAIN_2026-11-23.md, section v32.19.

Release
  bash ~/Documents/hm64/tools/hm64_release.sh v32-19 <lab sha256> <pages sha256> </dev/null
