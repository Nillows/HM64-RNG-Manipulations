"""Out-of-sample test of the cast pack's continuation past a cast row's own horizon.
Casts that BOTH the d140c90 window (data to 140 s) and the d170c120 window (data to 170 s) recorded: build a pack with
those casts' d170c120 rows left out (the other d170c120 rows stay), so for them the pack only knows the bites to 140 s
and continues through shared bite states, as it does for every cast before 80 s; compare that continuation with the
held-out rows. python3 -I extrap_test.py LAB D90 D140 D170 OUTDIR"""
import json, os, sys, glob, subprocess, collections
lab, d90, d140, d170, out = sys.argv[1:6]
os.makedirs(out, exist_ok=True)
k140 = set()
for fp in glob.glob(os.path.join(d140, "FD_casts_b*.jsonl")):
    for l in open(fp):
        r = json.loads(l)
        for c in r["casts"]:
            k140.add((r["key"], c["k"]))
fd = os.path.join(out, os.path.basename(d170.rstrip("/")) + "_heldout")
os.makedirs(fd, exist_ok=True)
held = {}
for f in os.listdir(d170):
    src = os.path.join(d170, f)
    if f.startswith("FD_casts_b"):
        with open(os.path.join(fd, f), "w") as o:
            for l in open(src):
                r = json.loads(l)
                keep = [c for c in r["casts"] if (r["key"], c["k"]) not in k140]
                for c in r["casts"]:
                    if (r["key"], c["k"]) in k140:
                        held[(r["key"], c["k"])] = [(b[0], b[1][:1]) for b in c["b"]]
                if keep:
                    r["casts"] = keep
                    r["_job"]["casts"] = [x for x in r["_job"]["casts"] if (r["key"], int(x[0])) not in k140]
                    o.write(json.dumps(r) + "\n")
    elif f == "FD1_lines.jsonl":
        os.symlink(src, os.path.join(fd, f))
pack = os.path.join(out, "pack.json")
subprocess.run([sys.executable, "-I", os.path.join(lab, "tools/dogcast_pack.py"), d90, d140, fd, "--cast-until", "7200", "--out", pack],
               check=True, stdout=subprocess.DEVNULL)
P = json.load(open(pack))
H140 = 8398
cnt = collections.Counter(); nut = collections.Counter()
for (key, k), want in held.items():
    ln = P["lines"].get(key); c = ln["idx"][(k - ln["k0"]) // 2]
    st, lab_, got = P["S"][c], k + P["F"][c], []
    if P["F"][c] >= 0:
        while st >= 0 and len(got) < 40:
            got.append((lab_, P["O"][st]))
            if P["N"][st] < 0: break
            lab_ += P["N"][st]; st = P["X"][st]
    wl = [b for b in want if b[0] > H140]; gl = [b for b in got if b[0] > H140]
    if not wl and not gl: cnt["no bite past 140 s in either"] += 1; continue
    if not gl: cnt["pack stops at 140 s (no continuation)"] += 1; continue
    n = min(len(wl), len(gl)); lim = min(wl[-1][0] if wl else 0, gl[-1][0])
    same = [x for x in wl if x[0] <= lim] == [x for x in gl if x[0] <= lim]
    cnt["continuation right" if same else "continuation WRONG"] += 1
    wn = next((b[0] for b in wl if b[1] == "N"), None); gn = next((b[0] for b in gl if b[1] == "N"), None)
    if wn or gn: nut["Nut past 140 s: " + ("same" if wn == gn else "pack %s, real %s" % (gn, wn))] += 1
print(f"{len(held)} held-out casts (recorded by both windows):", dict(cnt))
for k, v in sorted(nut.items(), key=lambda x: -x[1])[:12]: print("  ", k, v)
