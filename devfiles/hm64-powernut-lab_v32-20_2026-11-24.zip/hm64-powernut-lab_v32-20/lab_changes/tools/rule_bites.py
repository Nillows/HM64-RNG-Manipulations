"""Release rules past the 2nd bite (v32.19). For every dog line of a route: the best cast (press sd 150 ms, aimed) per rule 'let go at bite n' (n = 1..10, hold the bites before it), over the line's timings; the weight of lines whose best rule is bite n; and the best 1-s blind window per rule over all arrivals.n  python3 -I tools/rule_bites.py ROUTES.json PACK.json"""
import json, sys, numpy as np
VI=16.715
rp, pp = sys.argv[1], sys.argv[2]; NB=10
R=json.load(open(rp))['routes'][0]; P=json.load(open(pp))
F,S,N,X,O=P['F'],P['S'],P['N'],P['X'],P['O']
def flags(key):
    ln=P['lines'].get(key)
    if not ln: return None
    n=ln['k0']//2+len(ln['idx']); b=np.zeros((NB+1,n),np.uint8)
    for j,cid in enumerate(ln['idx']):
        if cid<0 or F[cid]<0: continue
        st=S[cid]; i=ln['k0']//2+j; nb=1
        while st>=0 and nb<=NB:
            if O[st]=='N': b[nb,i]=1
            if N[st]<0 or X[st]<0: break
            st=X[st]; nb+=1
    return b
dl=R['dw']['lines']; W=sum(l['w'] for l in dl)
# variants pier group all
key_of={}
for li,dwi in enumerate(R['dw']['of_line']):
    if dwi>=0: key_of[li]=dl[dwi]['key']
vars_={}
for li,w,o,mt in R['groups'][0]['v']['pier']:
    vars_.setdefault(key_of[li],[]).append((o,w))
nF=int(121000/VI/2)+1
sd=150/VI/2; r=int(np.ceil(3*sd)); g=np.exp(-0.5*(np.arange(-r,r+1)/sd)**2); g/=g.sum()
tot=np.zeros((NB+1,nF)); Wd=0
rows=[]
for li,key in sorted(key_of.items()):
    f=flags(key)
    if f is None or key not in vars_: continue
    s=np.zeros((NB+1,nF)); wl=0
    for o,w in vars_[key]:
        i=np.arange(nF); lab=2*i+o; lab-=lab%2; j=lab//2; ok=(j>=0)&(j<f.shape[1])
        for n in range(1,NB+1): s[n,ok]+=w*f[n,j[ok]]
        wl+=w
    tot+=s; Wd+=wl
    s/=wl
    best=[]
    for n in range(1,NB+1):
        a=np.convolve(s[n],g,'same'); b=a.argmax(); best.append((a[b],n,b))
    bb=max(best)
    rows.append((wl/W, li+1, bb, sorted(best,reverse=True)[:3]))
rows.sort(reverse=True)
cnt={}
for wsh,name,bb,top in rows:
    cnt[bb[1]]=cnt.get(bb[1],0)+wsh
print('weight of lines whose best known-line rule is bite n:', {k:round(100*v,1) for k,v in sorted(cnt.items())})
for wsh,name,bb,top in rows[:40]:
    print(f"L{name:<3d} {100*wsh:5.2f}%  best bite {bb[1]} at {2*bb[2]*VI/1000+VI/1000:6.2f}s {100*bb[0]:5.1f}%   " + "  ".join(f"b{n} {100*p:4.1f}%@{2*i*VI/1000:5.1f}" for p,n,i in top))
tot/=Wd
print('blind (all arrivals) best 1-s window per rule:')
nwin=int(round(1000/VI/2))
for n in range(1,NB+1):
    c=np.convolve(tot[n],np.ones(nwin)/nwin,'valid'); b=c.argmax()
    print(f"  bite {n}: {100*c[b]:.2f}% window from {2*b*VI/1000:.1f} s")
