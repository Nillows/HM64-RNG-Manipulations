"""
Lengthen the dog traces of the Lucky routes (dw.lines[].vis, from the dog-watch run: 40 s after READY) with the no-cast
paths of a full-day run (FD1_lines.jsonl, e.g. results/fullday/d110: 110 s), so the dog cards and the dog-watch can
run past 40 s (v31.14, cast frames to 60 s). The overlap is compared first: nothing is written if any line differs.

  python3 tools/dw_extend_traces.py webapp/assets/lucky_routes.json results/fullday/d110/FD1_lines.jsonl [--until 3660]

vis rows are [k0, k1, screen facing, visual class, sprite base]; the app reads k0, k1, facing and base. Added rows carry
the class of a row with the same (base, facing) when the old traces have one, else -1.
"""
import argparse, json, sys


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("routes"); ap.add_argument("lines"); ap.add_argument("--until", type=int, default=3660)
    a = ap.parse_args()
    FD = {}
    for l in open(a.lines):
        r = json.loads(l)
        if r.get("ok"):
            d, k, runs = r["d"], 0, []
            for i in range(0, len(d), 2):
                k = d[i] if i == 0 else k + d[i]
                runs.append([k, d[i + 1] >> 3, d[i + 1] & 7])              # label, base, facing
            FD[r["key"]] = (runs, r["end"][0])
    doc = json.load(open(a.routes))
    cls = {}
    for R in doc["routes"]:
        for L in (R.get("dw") or {}).get("lines", []):
            for v in L["vis"]:
                cls.setdefault((v[4], v[2]), v[3])
    same = diff = ext = 0
    bad = []
    for R in doc["routes"]:
        dw = R.get("dw")
        if not dw:
            continue
        for L in dw["lines"]:
            fd = FD.get(L["key"])
            if not fd:
                bad.append((R["id"], L["key"], "no full-day line")); continue
            runs, end = fd
            vis, old_end = L["vis"], L["vis"][-1][1]
            # compare on the overlap: what each shows at every label
            def at_fd(k):
                cur = None
                for kk, b, f in runs:
                    if kk > k: break
                    cur = (b, f)
                return cur
            ok = True
            for v in vis:
                for k in (v[0], (v[0] + v[1]) // 2, v[1] - 1):
                    if k < runs[0][0] or k >= old_end: continue
                    if at_fd(k) == (v[4], v[2]): same += 1
                    else: diff += 1; ok = False
            if not ok:
                bad.append((R["id"], L["key"], "differs on the overlap")); continue
            out = [v for v in vis if v[1] < old_end] + []
            lastv = vis[-1]
            cur = [lastv[0], lastv[1], lastv[2], lastv[3], lastv[4]]
            lim = min(a.until, end)
            for i, (kk, b, f) in enumerate(runs):
                nxt = runs[i + 1][0] if i + 1 < len(runs) else end
                if nxt <= old_end or kk >= lim: continue
                k0, k1 = max(kk, old_end), min(nxt, lim)
                if (b, f) == (cur[4], cur[2]) and k0 <= cur[1]:
                    cur[1] = k1
                else:
                    out.append(cur); cur = [k0, k1, f, cls.get((b, f), -1), b]
            out.append(cur)
            L["vis"] = out; ext += 1
        if not bad:
            dw["until"] = max(L["vis"][-1][1] for L in dw["lines"])
    print(f"overlap: {same} samples equal, {diff} different; lines lengthened: {ext}; problems: {len(bad)} {bad[:4]}")
    if bad:
        sys.exit("STOP: nothing written")
    json.dump(doc, open(a.routes, "w"), separators=(",", ":"))
    print("written", a.routes)


if __name__ == "__main__":
    main()
