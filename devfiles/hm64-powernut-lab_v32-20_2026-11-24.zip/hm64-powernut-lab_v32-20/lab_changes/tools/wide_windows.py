"""Wide windows (v32.19, the Casting tables' rainy tab, worked out independently): per dog line with >= 0.4% of the plays, runs of 3+ game frames in which at least TH (0.5) of the line's arrivals catch the Nut on the same bite; the aimed odds (sd 150 ms) at the run's best frame and when that bite comes.n  python3 -I tools/wide_windows.py ROUTES.json PACK.json [TH]"""
import json, sys, numpy as np
VI=16.715; NB=6
rp, pp = sys.argv[1], sys.argv[2]; TH=float(sys.argv[3]) if len(sys.argv)>3 else 0.5
R=json.load(open(rp))['routes'][0]; P=json.load(open(pp))
F,S,N,X,O=P['F'],P['S'],P['N'],P['X'],P['O']
def flags(key):
    ln=P['lines'].get(key); n=ln['k0']//2+len(ln['idx']); b=np.zeros((NB+1,n),np.uint8); t=np.full((NB+1,n),-1)
    for j,cid in enumerate(ln['idx']):
        if cid<0 or F[cid]<0: continue
        st=S[cid]; i=ln['k0']//2+j; dt=F[cid]
        for q in range(1,NB+1):
            if st<0: break
            t[q,i]=dt
            if O[st]=='N': b[q,i]=1
            if N[st]<0 or X[st]<0: break
            dt+=N[st]; st=X[st]
    return b,t
dl=R['dw']['lines']; W=sum(l['w'] for l in dl)
key_of={li:dl[dwi]['key'] for li,dwi in enumerate(R['dw']['of_line']) if dwi>=0}
vars_={}
for li,w,o,mt in R['groups'][0]['v']['pier']: vars_.setdefault(li,[]).append((o,w))
nF=int(121000/VI/2)+1
sd=150/VI/2; r=int(np.ceil(3*sd)); g=np.exp(-0.5*(np.arange(-r,r+1)/sd)**2); g/=g.sum()
rows=[]
for li in sorted(vars_):
    wl=sum(w for o,w in vars_[li])
    if wl/W<0.004: continue
    b,t=flags(key_of[li]); s=np.zeros((NB+1,nF)); tw=np.zeros((NB+1,nF))
    for o,w in vars_[li]:
        i=np.arange(nF); lab=2*i+o; lab-=lab%2; j=lab//2; ok=(j>=0)&(j<b.shape[1])
        for q in range(1,NB+1):
            s[q,ok]+=w*b[q,j[ok]]; tw[q,ok]+=w*b[q,j[ok]]*t[q,j[ok]]
    s/=wl; tw/=wl
    for q in range(1,NB+1):
        a=np.convolve(s[q],g,'same'); i=0
        while i<nF:
            if s[q,i]>=TH:
                k=i
                while k+1<nF and s[q,k+1]>=TH: k+=1
                if k-i+1>=3:
                    mid=(i+k)//2; best=i+int(np.argmax(a[i:k+1]))
                    bt=(s[q,i:k+1]*(2*np.arange(i,k+1)+1)+tw[q,i:k+1]).sum()/s[q,i:k+1].sum()
                    rows.append((wl/W, li+1, q, i, k, k-i+1, a[best], best, bt))
                i=k+1
            else: i+=1
rows.sort(key=lambda x:(-x[0], -x[6]))
print(len(rows),'runs; lines with one:', len(set(x[1] for x in rows)))
for x in rows[:60]:
    sh,name,q,i,k,n,p,best,bt=x
    print(f"L{name:<3d} {100*sh:5.2f}%  bite {q}  {2*i*VI/1000:6.2f}-{2*k*VI/1000:6.2f}s x{n:<2d} aim {2*best*VI/1000+VI/1000:6.2f}s {100*p:5.1f}%  bite at {bt*VI/1000:6.1f}s")
