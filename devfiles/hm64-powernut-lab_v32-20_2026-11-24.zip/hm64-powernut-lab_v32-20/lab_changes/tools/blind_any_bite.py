"""Blind casting with any bite (2026-11-24): for every cast moment t (stopwatch VIs after the dock-end tap) the share of
the route's plays (arrivals: dog line x timing, weights of the 'all' preset at the pier start) that land the Power Nut
when they (a) let go at bite n, or (b) hold through every bite until the stopwatch reads r and let go at the next bite
(r chosen best for t). Cast spread: Gaussian sd SIG ms (the player's press), release: the visible bite (no spread).
python3 -I blind_any_bite.py ROUTES PACK [SIG_MS]"""
import json, sys, math
import numpy as np
VI_MS = 16.715
R = [r for r in json.load(open(sys.argv[1]))["routes"] if r.get("dw")][0]; P = json.load(open(sys.argv[2]))
SIG = float(sys.argv[3]) if len(sys.argv) > 3 else 150.0
keys = [x["key"] for x in R["line_info"]]
g = next(x for x in R["groups"] if x["id"] == "all")
arr = [(keys[i], w, o) for i, w, o, mt in g["v"]["pier"]]
W = sum(w for _, w, _ in arr)
name = {}
for i, l in enumerate(R["dw"]["lines"]):
    name[l["key"]] = ("L%d" % (l["li"] + 1)) if l["li"] >= 0 else "x%d" % i
T = np.arange(0, 7200, 2)
NB = 10
pn = np.zeros((NB + 1, len(T)))
RMAX = 10400
cov = np.zeros((len(T), RMAX // 2), dtype=np.float32)
memo = {}
def chain(key, c):
    m = memo.get((key, c))
    if m is not None: return m
    ln = P["lines"].get(key); j = (c - ln["k0"]) // 2
    out = []
    if 0 <= j < len(ln["idx"]) and ln["idx"][j] >= 0 and P["F"][ln["idx"][j]] >= 0:
        cid = ln["idx"][j]; st, lab = P["S"][cid], c + P["F"][cid]
        while st >= 0 and len(out) < 16:
            out.append((lab, P["O"][st]))
            if P["N"][st] < 0: break
            lab += P["N"][st]; st = P["X"][st]
    memo[(key, c)] = out
    return out
for ti, t in enumerate(T):
    d = np.zeros(RMAX // 2 + 1, dtype=np.float32)
    for key, w, o in arr:
        c = (t + o) - ((t + o) % 2)
        ch = chain(key, c)
        j = next((i for i, b in enumerate(ch) if b[1] == "N"), None)
        if j is None: continue
        pn[min(j + 1, NB), ti] += w
        sN = ch[j][0] - o; sp = (ch[j - 1][0] - o) if j > 0 else t
        lo, hi = (sp + 10) // 2 + 1, (sN + 10) // 2
        if hi >= lo and lo < RMAX // 2:
            d[max(lo, 0)] += w; d[min(hi + 1, RMAX // 2)] -= w
    cov[ti] = np.cumsum(d)[:-1]
pn /= W; cov /= W
sd = SIG / VI_MS / 2                                   # in cast frames
ker = np.exp(-0.5 * (np.arange(-30, 31) / sd) ** 2); ker /= ker.sum()
sm = lambda a: np.convolve(a, ker, mode="same")
print(f"{sys.argv[1].split('/')[-1]}: {len(arr)} arrivals, cast spread sd {SIG:.0f} ms")
for n in range(1, NB + 1):
    s = sm(pn[n]); i = int(np.argmax(s))
    print(f"  let go at bite {n}{'+' if n == NB else ''}: best cast {T[i] * VI_MS / 1000:6.2f} s -> {100 * s[i]:5.2f}%  (exact frame, no spread: {100 * pn[n].max():5.2f}%)")
covs = np.apply_along_axis(sm, 0, cov)
i, r = np.unravel_index(np.argmax(covs), covs.shape)
print(f"  hold until the clock reads r, let go at the next bite: best cast {T[i] * VI_MS / 1000:.2f} s, r = {2 * r * VI_MS / 1000:.2f} s -> {100 * covs[i, r]:.2f}%")
best = covs.max(axis=1)
top = np.argsort(-best)
seen = []
for i in top:
    if all(abs(i - j) > 30 for j in seen):
        seen.append(i)
        r = int(np.argmax(covs[i]))
        print(f"    cast {T[i] * VI_MS / 1000:6.2f} s, let go at the first bite after {2 * r * VI_MS / 1000:6.2f} s: {100 * covs[i, r]:5.2f}%")
    if len(seen) >= 8: break
