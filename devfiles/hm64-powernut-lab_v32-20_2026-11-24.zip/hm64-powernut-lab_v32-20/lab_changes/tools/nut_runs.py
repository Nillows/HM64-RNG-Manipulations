"""(1) runs of >= 3 neighbouring cast frames with the same Nut colour (bite 1 green, 2 gold, 3+ purple) per dog line,
checked against the raw full-day rows; (2) are the lines distinct trajectories? (FD1 no-cast hash sequences).
python3 -I rain_runs.py ROUTES PACK FD_DIR [FD_DIR ...]"""
import json, sys, glob, os, collections
VI = 59.826
routes, packp, fds = sys.argv[1], sys.argv[2], sys.argv[3:]
R = json.load(open(routes))["routes"][0]; P = json.load(open(packp))
dw = R["dw"]["lines"]; Wt = sum(l["w"] for l in dw)
name = {l["key"]: ("L%d" % (l["li"] + 1) if l["li"] >= 0 else "x%d" % i) for i, l in enumerate(dw)}
w = {l["key"]: l["w"] / Wt for l in dw}

def nut(key, k):
    ln = P["lines"].get(key); j = (k - ln["k0"]) // 2
    if j < 0 or j >= len(ln["idx"]) or ln["idx"][j] < 0: return None
    c = ln["idx"][j]; st, lab, n = P["S"][c], k + P["F"][c], 1
    if P["F"][c] < 0: return (0, None, c)
    while st >= 0 and n <= 16:
        if P["O"][st] == "N": return (n, lab, c)
        if P["N"][st] < 0: break
        lab += P["N"][st]; st = P["X"][st]; n += 1
    return (0, None, c)

# raw rows: (key, k) -> (nut bite n, its label) from the line's own cast
raw = {}
for d in fds:
    for fp in sorted(glob.glob(os.path.join(d, "FD_casts_b*.jsonl"))):
        for l in open(fp):
            r = json.loads(l)
            for c in r["casts"]:
                n = next((i + 1 for i, b in enumerate(c["b"]) if b[1][:1] == "N"), 0)
                raw[(r["key"], c["k"])] = (n, c["b"][n - 1][0] if n else None)
runs = []
for l in dw:
    key = l["key"]
    if key not in P["lines"]: continue
    ln = P["lines"][key]; last = ln["k0"] + 2 * (len(ln["idx"]) - 1)
    cur = None
    for k in range(ln["k0"], last + 1, 2):
        v = nut(key, k); col = None if not v or v[0] == 0 else min(v[0], 3)
        if cur and col == cur["col"]:
            cur["ks"].append(k); cur["n"].append(v[0]); cur["t"].append(v[1])
        else:
            if cur and len(cur["ks"]) >= 3: runs.append(cur)
            cur = {"key": key, "col": col, "ks": [k], "n": [v[0]] if v else [0], "t": [v[1]] if v else [None]} if col else None
    if cur and len(cur["ks"]) >= 3: runs.append(cur)
COL = {1: "green", 2: "gold", 3: "purple"}
print(f"{routes.split('/')[-1]}: {len(dw)} dog lines; runs of >= 3 neighbouring frames with the same colour: {len(runs)}")
for x in sorted(runs, key=lambda x: (-len(x["ks"]), -w[x["key"]])):
    own = [raw.get((x["key"], k)) for k in x["ks"]]
    ok = sum(1 for k, o, n, t in zip(x["ks"], own, x["n"], x["t"]) if o and o == (n, t))
    ts = sorted(set(x["t"]))
    print(f"  {name[x['key']]:>4} ({x['key'][:8]}, {100 * w[x['key']]:.2f}% of plays) {COL[x['col']]:6s} x{len(x['ks'])}: casts "
          f"{x['ks'][0] / VI:.2f}-{x['ks'][-1] / VI:.2f} s, Nut on bite {sorted(set(x['n']))} at {', '.join(f'{t / VI:.2f}' for t in ts)} s; "
          f"own raw rows {sum(1 for o in own if o)}/{len(own)}, equal {ok}")
