"""Known dog line, tuned clock: for each line the cast moment with the best chance of the Nut when the press lands with
a Gaussian spread (sd SIG ms) around it and B is let go at the Nut bite of the aimed frame (the same bite moment;
neighbouring frames whose Nut comes at that same moment count, any bite number). Also: runs of >= 3 neighbouring Nut
frames with the same colour, counted. python3 -I known_line.py ROUTES PACK [SIG] [MAXCAST_VI]"""
import json, sys, math, collections
VI_MS = 16.715
R = [r for r in json.load(open(sys.argv[1]))["routes"] if r.get("dw")]; P = json.load(open(sys.argv[2]))
SIG = float(sys.argv[3]) if len(sys.argv) > 3 else 150.0
KMAX = int(sys.argv[4]) if len(sys.argv) > 4 else 7198
info = {}
for r in R:
    for i, l in enumerate((r.get("dw") or {}).get("lines", [])):
        x = info.setdefault(l["key"], {"w": 0.0, "name": None})
        x["w"] += l["w"]
        if x["name"] is None and r is R[0]: x["name"] = ("L%d" % (l["li"] + 1)) if l["li"] >= 0 else "x%d" % i
Wt = sum(x["w"] for x in info.values())
fam = {}
r0 = R[0]
for i, (l, f) in enumerate(zip(r0["dw"]["lines"], r0["dw"].get("fam", []))):
    fam[l["key"]] = r0["dw"]["lines"][f[0]]["key"]
g = [math.exp(-0.5 * (d * 2 * VI_MS / SIG) ** 2) for d in range(-30, 31)]; gs = sum(g); g = [x / gs for x in g]
res = []; runs = collections.Counter(); runlen = collections.Counter()
for key, x in info.items():
    ln = P["lines"].get(key)
    if not ln: continue
    nut = {}
    for j, c in enumerate(ln["idx"]):
        k = ln["k0"] + 2 * j
        if c < 0 or k > KMAX or P["F"][c] < 0: continue
        st, lab, n = P["S"][c], k + P["F"][c], 1
        while st >= 0 and n <= 16:
            if P["O"][st] == "N": nut[k] = (lab, n); break
            if P["N"][st] < 0: break
            lab += P["N"][st]; st = P["X"][st]; n += 1
    best = (0, None, None)
    for k, (m, n) in nut.items():
        p = sum(g[d + 30] for d in range(-30, 31) if nut.get(k + 2 * d, (None,))[0] == m)
        if p > best[0]: best = (p, k, (m, n))
    # runs of the same colour
    ks = sorted(nut); cur = []
    for k in ks + [None]:
        col = None if k is None else min(nut[k][1], 3)
        if cur and k is not None and k == cur[-1][0] + 2 and col == cur[-1][1]: cur.append((k, col)); continue
        if len(cur) >= 3: runs[cur[0][1]] += 1; runlen[min(len(cur), 8)] += 1
        cur = [(k, col)] if k is not None else []
    res.append((x["w"] / Wt, x["name"], key, best))
print(f"{sys.argv[1].split('/')[-1]}: casts to {KMAX * VI_MS / 1000:.0f} s, press spread sd {SIG:.0f} ms")
print(f"  runs of >= 3 neighbouring frames with the same colour: {sum(runs.values())} (green {runs[1]}, gold {runs[2]}, purple {runs[3]}); "
      f"by length: " + ", ".join(f"{k}{'+' if k == 8 else ''}: {v}" for k, v in sorted(runlen.items())))
ps = sorted([r[3][0] for r in res], reverse=True)
wavg = sum(w * b[0] for w, _, _, b in res) / sum(w for w, _, _, b in res)
print(f"  best known-line cast per line: median {100 * ps[len(ps) // 2]:.0f}%, weighted mean {100 * wavg:.0f}%, top {100 * ps[0]:.0f}%")
for w, nm, key, (p, k, mn) in sorted(res, key=lambda r: -r[0])[:12]:
    print(f"    {nm:>4} ({100 * w:4.1f}% of plays, family {info[fam.get(key, key)]['name'] if fam.get(key, key) in info else '?'}): cast at {k * VI_MS / 1000:6.2f} s "
          f"(line clock) -> {100 * p:3.0f}%, the Nut on bite {mn[1]} at {mn[0] * VI_MS / 1000:.2f} s")
