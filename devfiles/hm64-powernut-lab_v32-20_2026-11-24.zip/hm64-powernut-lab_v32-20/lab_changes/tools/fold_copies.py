#!/usr/bin/env python3
"""Fold dog lines that are copies of another line (v32.19, 2026-11-24; Thomas: "make sure they are truly unique and that
they cannot be represented as different moments in same trajectory").

A copy is a line B whose whole future from its READY is line A's, s VIs later or earlier (s even = whole game frames):
  - the random number's position (absolute draw count) and the dog (actionState, direction, stateTimer) agree every game
    frame of the dog-watch run (Z6_lines.jsonl obs, READY to 40 s): B(k) == A(k + s) for every k >= 0;
  - the dog as seen (visible runs: screen facing + sprite base) agrees every VI where both are known, to the end of the
    full-day run (Z6 obs vis to 40 s, FD1_lines.jsonl runs to 170 s);
  - past 40 s the full-day run's per-frame cast hashes agree apart from short gaps (Jack's idle / stay-awake frames
    are in that hash and fixed to each line's own READY), as in tools/line_merges.py.
The lab's own merge (zigzag_campaign.merge_same_paths) needs the copy's READY state, Jack included, on the other line's
path at a shift >= 0, so these stay separate there. A copy's members join the heavier line with k_off moved by s (a cast
tau VIs after the member's READY is the line's cast k = tau + k_off, which may be < 0 for the first frame or two: no
data there, as before READY). Each member keeps its weight and READY, so no odds change; the line list loses the copy.

  python3 -I tools/fold_copies.py RESULTS_DIR FD1_lines.jsonl [--write]

--write: zz_lines.json is replaced (the first time, the original is kept as zz_lines.prefold.json; later runs start
from that file, so the fold is repeatable). Without it: report only."""
import collections
import json
import shutil
import sys
from pathlib import Path

VI = 59.826
MAXS = 120                     # shifts tried, VIs


def z6(res):
    st, vis = {}, {}
    for l in open(res / "Z6_lines.jsonl"):
        r = json.loads(l)
        if not (r.get("ok") and r.get("obs")):
            continue
        dr = dict((k, v) for k, v in r["obs"]["draw"])
        dg = {x[0]: tuple(x[1:]) for x in r["obs"]["dog"]}
        cur, s = None, {}
        for k in sorted(dr):
            if k in dg:
                cur = dg[k]
            s[k] = (dr[k], cur)
        st[r["key"]] = s
        v = {}
        for k0, k1, f, c, b in r["obs"]["vis"]:
            for k in range(k0, k1):
                v[k] = b * 8 + f
        vis[r["key"]] = v
    return st, vis


def fd1(path):
    hs, vis = {}, {}
    for l in open(path):
        r = json.loads(l)
        if not r.get("ok"):
            continue
        hs[r["key"]] = {r["h0"] + r["step"] * i: h for i, h in enumerate(r["hs"])}
        d, k, runs = r["d"], 0, []
        for i in range(0, len(d), 2):
            k = d[i] if i == 0 else k + d[i]
            runs.append((k, d[i + 1]))
        v = {}
        for (k0, c), nxt in zip(runs, runs[1:] + [(r["end"][0], None)]):
            for kk in range(k0, nxt[0]):
                v[kk] = c
        vis[r["key"]] = v
    return hs, vis


def check(a, b, s, ST, VZ, HS, VF):
    """B(k) == A(k + s) from B's READY on. -> (ok, notes)"""
    A, B = ST[a], ST[b]
    ks = [k for k in sorted(B) if k >= 0 and k + s in A]
    if not ks or any(B[k] != A[k + s] for k in ks):
        return False, "dog-watch states differ"
    for name, X in (("visible dog to 40 s", VZ), ("visible dog to 170 s", VF)):
        va, vb = X.get(a), X.get(b)
        if va is None or vb is None:
            return False, name + ": missing"
        bad = [k for k in vb if k >= 0 and k + s in va and va[k + s] != vb[k]]
        if bad:
            return False, f"{name}: {len(bad)} VIs differ (first at {min(bad)})"
    ha, hb = HS.get(a), HS.get(b)
    if ha is None or hb is None:
        return False, "full-day hashes missing"
    run = worst = 0
    ks = [k for k in sorted(hb) if k > 2398 and k + s in ha]
    for k in ks:
        run = run + 1 if hb[k] != ha[k + s] else 0
        worst = max(worst, run)
    if worst > 10 or run:
        return False, f"full-day hashes part (run of {worst})"
    return True, f"one to {ks[-1] / VI:.0f} s" if ks else "no full-day overlap"


def main():
    res, fdp = Path(sys.argv[1]), sys.argv[2]
    pre = res / "zz_lines.prefold.json"
    Z = json.loads((pre if pre.exists() else res / "zz_lines.json").read_text())
    ST, VZ = z6(res)
    HS, VF = fd1(fdp)
    keys = sorted((k for k in Z if k in ST), key=lambda k: -Z[k]["w"])
    at = collections.defaultdict(list)                     # state -> (line, k) for the first MAXS VIs of each line
    for k in keys:
        k0 = min(kk for kk in ST[k] if kk >= 0)
        for kk, s in ST[k].items():
            if k0 <= kk <= k0 + MAXS:
                at[s].append((k, kk))
    folds, near = [], []
    done = set()
    for b in reversed(keys):                               # lightest first: a copy joins a heavier line
        if b in done:
            continue
        kb0 = min(kk for kk in ST[b] if kk >= 0)
        cands = sorted({(ka - kb, a) for kb in range(kb0, kb0 + MAXS + 1) if kb in ST[b]
                        for a, ka in at.get(ST[b][kb], []) if a != b and a not in done and Z[a]["w"] >= Z[b]["w"]},
                       key=lambda x: (abs(x[0]), -Z[x[1]]["w"]))
        for s, a in cands:
            ok, why = check(a, b, s, ST, VZ, HS, VF)
            if ok:
                folds.append((b, a, s, why))
                done.add(b)
                break
            near.append((b, a, s, why))
    name = {k: f"#{i + 1}" for i, k in enumerate(keys)}
    print(f"{res.name}: {len(keys)} lines; copies: {len(folds)}")
    for b, a, s, why in folds:
        print(f"  {b} ({100 * Z[b]['w']:.3f}%) = {a} ({100 * Z[a]['w']:.3f}%) shifted {s:+d} VIs: joins it with k_off "
              f"{s:+d}; {why}")
    for b, a, s, why in near:
        if b not in done and why != "dog-watch states differ":     # same logic state, but seen or later differs
            print(f"  not a copy: {b} ({100 * Z[b]['w']:.3f}%) vs {a} at {s:+d} VIs: {why}")
    if "--write" not in sys.argv:
        return
    for b, a, s, why in folds:
        T, L = Z[a], Z.pop(b)
        for m in L["members"]:
            if "k_off" in m:
                m["k_off"] += s
                m["line_k"] = m.get("line_k", 0) + s
        T["members"].extend(L["members"])
        T["w"] += L["w"]
        T.setdefault("merged", []).append([b, s])
        T["merged"] += [[k, sh + s] for k, sh in L.get("merged", [])]
        T.setdefault("folded", []).append([b, s, why])
    if not pre.exists():
        shutil.copyfile(res / "zz_lines.json", pre)
    (res / "zz_lines.json").write_text(json.dumps(Z))
    print(f"written {res / 'zz_lines.json'} ({len(Z)} lines; original kept as {pre.name})")


if __name__ == "__main__":
    main()
