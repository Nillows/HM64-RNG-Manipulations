"""Purple runs that mix bite numbers (v32.19, Thomas 2026-11-24 22:48). Per dog line, the first Nut bite of every cast frame (the Lucky Timer's dcNutAt, up to 16); maximal runs of neighbouring frames with bite 3+; how many mix bite numbers.n  python3 -I tools/purple_runs.py ROUTES.json PACK.json   (ROUTES: one route, e.g. webapp/assets/lucky_routes_rainy-no-horse.json)"""
import json, sys, collections
rp, pp = sys.argv[1], sys.argv[2]
R=json.load(open(rp))['routes'][0]; P=json.load(open(pp))
F,S,N,X,O=P['F'],P['S'],P['N'],P['X'],P['O']
def first_nut(cid, maxb=16):
    if cid<0 or F[cid]<0: return 0
    st=S[cid]; n=1
    while st>=0 and n<=maxb:
        if O[st]=='N': return n
        if N[st]<0 or X[st]<0: return 0
        st=X[st]; n+=1
    return 0
dl=R['dw']['lines']; W=sum(l['w'] for l in dl)
pairs=collections.Counter(); runs=collections.Counter(); mixedruns=0; allruns=0; wmixed=0; wall=0
for l in dl:
    ln=P['lines'].get(l['key'])
    if not ln: continue
    nb=[first_nut(c) for c in ln['idx']]
    # maximal runs of consecutive purple frames (first Nut bite >= 3)
    i=0
    while i<len(nb):
        if nb[i]>=3:
            j=i
            while j+1<len(nb) and nb[j+1]>=3: j+=1
            if j>i:
                seg=nb[i:j+1]; allruns+=1; wall+=l['w']
                if len(set(seg))>1: mixedruns+=1; wmixed+=l['w']; runs[tuple(seg)]+=1
            i=j+1
        else: i+=1
    for a,b in zip(nb,nb[1:]):
        if a>=3 and b>=3: pairs['same' if a==b else 'diff']+=1
print('neighbouring purple frames (same line): same bite', pairs['same'], 'different bite', pairs['diff'])
print('purple runs of 2+ frames:', allruns, 'of which mix bites:', mixedruns)
print('examples:', [ (k,v) for k,v in runs.most_common(8)])
