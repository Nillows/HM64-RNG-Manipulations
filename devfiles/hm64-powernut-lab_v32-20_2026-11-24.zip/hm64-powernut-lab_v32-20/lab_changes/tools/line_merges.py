"""Distinct dog lines? (2026-11-24, Thomas: "make sure they are truly unique and that they cannot be represented as
different moments in same trajectory").
State of a line at game frame k (dog-watch run, Z6_lines.jsonl obs, READY to 40 s): the random number's position
(absolute draw count since power-on = the LCG value) + the dog (actionState, direction, stateTimer). Lines A and B are
ONE trajectory shifted by d VIs from frame J on when state_A(k) == state_B(k + d) for every k >= J. Past 40 s the
full-day run's per-frame cast hashes (FD1_lines.jsonl, to 170 s) must keep agreeing (Jack's own idle / stay-awake
frames are in that hash and fixed to each line's READY, so a shifted copy differs there for a few frames; tolerated).
Prints the pairs, and how many distinct trajectories the lines are at moments after READY.
python3 -I line_unique4.py DOGWATCH_DIR FD1_lines.jsonl ROUTES PACK [--json out]"""
import json, sys, collections
VI = 59.826
D, fd1, routes, packp = sys.argv[1:5]
R = json.load(open(routes))["routes"]; P = json.load(open(packp))
info = {}
for r in R:
    for i, l in enumerate((r.get("dw") or {}).get("lines", [])):
        x = info.setdefault(l["key"], {"w": 0.0, "name": None})
        x["w"] += l["w"]
        if x["name"] is None and r is R[0]: x["name"] = ("L%d" % (l["li"] + 1)) if l["li"] >= 0 else "x%d" % i
Wt = sum(x["w"] for x in info.values())
nm = lambda k: (info.get(k, {}).get("name") or k[:8]); wt = lambda k: 100 * info.get(k, {}).get("w", 0) / Wt
Z = json.load(open(D + "/zz_lines.json"))
S = {}
for l in open(D + "/Z6_lines.jsonl"):
    r = json.loads(l)
    if r["key"] in Z and r.get("obs"):
        dr = dict((k, v) for k, v in r["obs"]["draw"]); dg = {}
        cur = None
        for x in r["obs"]["dog"]: dg[x[0]] = tuple(x[1:])
        st = {}
        for k in sorted(dr):
            if k in dg: cur = dg[k]
            st[k] = (dr[k], cur)
        S[r["key"]] = st
H = {}
for l in open(fd1):
    r = json.loads(l)
    if r.get("ok"): H[r["key"]] = dict((r["h0"] + r["step"] * i, h) for i, h in enumerate(r["hs"]))
pos = collections.defaultdict(list)
for key, st in S.items():
    for k, s in st.items(): pos[s].append((key, k))
cand = collections.defaultdict(collections.Counter)
for s, ps in pos.items():
    if 1 < len(ps) < 60:
        for x in ps:
            for y in ps:
                if x[0] < y[0]: cand[(x[0], y[0])][y[1] - x[1]] += 1

def late_ok(a, b, d):
    """past 40 s: the cast hashes agree apart from gaps of <= 10 frames"""
    A, B = H.get(a), H.get(b)
    if not A or not B: return None, 0
    ks = [k for k in sorted(A) if k > 2398 and k + d in B]
    run = worst = bad = 0
    for k in ks:
        if A[k] != B[k + d]: run += 1; bad += 1; worst = max(worst, run)
        else: run = 0
    return worst <= 10 and run == 0, (ks[-1] if ks else 0)

def casts_equal(a, b, d, J):
    ok = tot = 0
    la, lb = P["lines"].get(a), P["lines"].get(b)
    if not la or not lb: return 0, 0
    for j, c in enumerate(la["idx"]):
        k = la["k0"] + 2 * j
        if k < J: continue
        jb = (k + d - lb["k0"]) // 2
        if c < 0 or not 0 <= jb < len(lb["idx"]) or lb["idx"][jb] < 0: continue
        def ch(cid, kk):
            if P["F"][cid] < 0: return ()
            st, lab, out = P["S"][cid], kk + P["F"][cid], []
            while st >= 0 and len(out) < 2:
                out.append((lab - kk, P["O"][st]))
                if P["N"][st] < 0: break
                lab += P["N"][st]; st = P["X"][st]
            return tuple(out)
        tot += 1; ok += ch(c, k) == ch(lb["idx"][jb], k + d)
    return ok, tot

same, merge, touch = [], [], []
for (a, b), ds in cand.items():
    best = None
    for d, n in ds.most_common(4):
        A, B = S[a], S[b]
        ks = [k for k in sorted(A) if k + d in B]
        eq = [A[k] == B[k + d] for k in ks]
        if not any(eq): continue
        j = eq.index(True); stay = all(eq[j:])
        x = (stay, -ks[j], d, ks[j], ks[0])
        if best is None or x[:2] > best[:2]: best = x
    if not best: continue
    stay, _, d, J, k0 = best
    if not stay: touch.append((a, b, d, J)); continue
    lo, last = late_ok(a, b, d)
    ok, tot = casts_equal(a, b, d, J)
    rec = (a, b, d, J, lo, last, ok, tot)
    if lo is False:                                  # one to 40 s, but the full-day run shows them parting later
        touch.append((a, b, d, J)); continue
    (same if J <= k0 else merge).append(rec)
print(f"{len(S)} lines; pairs that ever reach the same random number with the same dog: {len(same) + len(merge) + len(touch)} of {len(S) * (len(S) - 1) // 2}")
print(f"  ONE trajectory from READY on (a copy shifted in time): {len(same)} pairs")
for a, b, d, J, lo, last, ok, tot in sorted(same, key=lambda x: -max(wt(x[0]), wt(x[1]))):
    print(f"    {nm(a):>4} {wt(a):5.2f}% = {nm(b):>4} {wt(b):5.2f}%  {nm(b)} is {nm(a)} {d:+d} VIs ({d // 2:+d} frames); still one to "
          f"{last / VI:.0f} s: {lo}; casts with the same bites 1-2 {ok}/{tot}")
print(f"  different at READY, ONE trajectory from a later moment (and staying so): {len(merge)} pairs")
for a, b, d, J, lo, last, ok, tot in sorted(merge, key=lambda x: x[3]):
    print(f"    {nm(a):>4} {wt(a):5.2f}% ~ {nm(b):>4} {wt(b):5.2f}%  shift {d:+4d} VIs: one from {J / VI:5.2f} s; still one to "
          f"{last / VI:.0f} s: {lo}; casts from then on equal {ok}/{tot}")
print(f"  meet for a moment and part again: {len(touch)} pairs (the same random-number position and the same dog action / facing / timer for a moment; the rest of the state - the dog's spot and animation, on rain the raindrops - differs)")
# distinct trajectories over time (union of pairs merged by T)
def comps(T):
    par = {k: k for k in S}
    def f(x):
        while par[x] != x: par[x] = par[par[x]]; x = par[x]
        return x
    for a, b, d, J, *_ in same + merge:
        if J <= T + 6: par[f(a)] = f(b)
    return len({f(k) for k in S})
print("  distinct trajectories among the lines: " + ", ".join(f"{t} s {comps(t * VI)}" for t in (0, 0.5, 1, 2, 5, 10, 20, 30, 40)))
if "--json" in sys.argv: json.dump({"same": same, "merge": merge, "touch": touch}, open(sys.argv[sys.argv.index("--json") + 1], "w"))
