#!/usr/bin/env python3
"""Sister dog lines (2026-11-21). Two dog lines of a route are sisters when one's dog trace equals the other's moved by
d VIs (an even number: whole game frames) from some moment on AND, from that moment on, every cast frame has the same
bites (times shifted by d, same catches) in the dog-after-the-cast pack. Writes per route
    dw.fam = [[rep, d, join], ...]   one entry per dw line (same order as dw.lines)
rep = index of the family's main line (itself: [i, 0, 0]); trace_rep[k] == trace_line[k + d] for k >= join (rep VIs).
The app shows one card per family for the members that have joined (always accurate: never before `join`).
  python3 -I tools/dw_families.py webapp/assets/lucky_routes.json webapp/assets/dogcast.json [--check]"""
import json, sys
import numpy as np

DMAX, TAIL0, MAXJOIN = 200, 1900, 1700          # shifts tried (VIs), where the tails are compared, latest join accepted


def trace(line, n):
    a = np.full(n, -1, dtype=np.int32)
    for k0, k1, f, c, b in line["vis"]:
        a[max(0, k0):min(n - 1, k1) + 1] = b * 8 + f
    return a


def chains(P, key):
    ln = P["lines"].get(key)
    if not ln:
        return None
    out = {}
    for j, c in enumerate(ln["idx"]):
        if c < 0:
            continue
        k = ln["k0"] + 2 * j
        st, lab, ch = P["S"][c], k + P["F"][c], []
        while st >= 0 and len(ch) < 16:
            ch.append((lab, P["O"][st]))
            if P["N"][st] < 0:
                break
            lab += P["N"][st]
            st = P["X"][st]
        out[k] = ch
    return out


def same_chain(a, b, d, lim):
    """a (rep cast k) vs b (member cast k + d): same bites, shifted by d; a tail cut by the data limit may be missing"""
    n = min(len(a), len(b))
    for i in range(n):
        if a[i][0] + d != b[i][0] or a[i][1] != b[i][1]:
            return False
    longer = a if len(a) > len(b) else b
    return all(x[0] > lim for x in longer[n:])


def main():
    rp, pp = sys.argv[1], sys.argv[2]
    R = json.load(open(rp)); P = json.load(open(pp))
    lim = int(P.get("until", 5398)) - 420
    for r in R["routes"]:
        dw = r.get("dw")
        if not dw or not dw.get("lines"):
            continue
        L = dw["lines"]; n = int(dw.get("until", 2460)) + 2
        T = [trace(l, n) for l in L]; C = [chains(P, l["key"]) for l in L]
        order = sorted(range(len(L)), key=lambda i: (L[i]["li"] < 0, -L[i]["w"]))
        fam = [None] * len(L)
        for i in order:
            if fam[i] is not None or C[i] is None:
                continue
            fam[i] = [i, 0, 0]
            for m in order:
                if fam[m] is not None or C[m] is None:
                    continue
                for d in sorted(range(-DMAX, DMAX + 1, 2), key=abs):
                    lo, hi = max(TAIL0, TAIL0 - d), min(n, n - d) - 2
                    if not np.array_equal(T[i][lo:hi], T[m][lo + d:hi + d]) or (T[i][lo:hi] < 0).all():
                        continue
                    k0 = max(0, -d)
                    diff = np.nonzero(T[i][k0:hi] != T[m][k0 + d:hi + d])[0]
                    join = int(diff[-1]) + k0 + 1 if len(diff) else k0
                    bad = [k for k, ch in C[i].items() if k >= join and (k + d) in C[m] and not same_chain(ch, C[m][k + d], d, lim)]
                    if bad:
                        join = max(bad) + 2
                    if join <= MAXJOIN:
                        fam[m] = [i, d, join]
                    break
        for i in range(len(L)):
            if fam[i] is None:
                fam[i] = [i, 0, 0]
        dw["fam"] = fam
        reps = sorted({f[0] for f in fam})
        groups = [[m for m in range(len(L)) if fam[m][0] == rp_] for rp_ in reps]
        name = lambda i: ("L%d" % (L[i]["li"] + 1)) if L[i]["li"] >= 0 else "x%d" % i
        print(f"{r['id']}: {len(L)} lines -> {len(groups)} families; " + " | ".join(
            name(g[0]) + f"({len(g)}; joins to {max(fam[m][2] for m in g) / 59.826:.1f} s)" for g in groups if len(g) > 1))
    if "--check" not in sys.argv:
        json.dump(R, open(rp, "w"), separators=(",", ":"))
        print("written", rp)


if __name__ == "__main__":
    main()
