/* headless (v32.19): the casting tables of a page with release rules past the 2nd bite (rainy pages). Prints what the
   tables say: the cast for "cannot tell the dog", the Optimal Blind Casting rows, every line's cast, the harbingers, and
   exercises the close-up of a later-bite row (candles, a clicked candle, a focused line, a picked timing, the try panel
   with every rule). Errors are collected. */
(function () { const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => { const $ = id => document.getElementById(id), out = { errors: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    try {
      if ($('arOracle')) { $('arOracle').click(); await sleep(80); }
      const R = window.HM64DogRef;
      const done = () => R.shown && R.shown.all && !/working out/.test($('rfBody').textContent);
      for (let i = 0; i < 2400 && !done(); i++) await sleep(50);
      const o = R.shown, VI = 16.715, s = t => +(t * VI / 1000).toFixed(2);
      const cast = c => (!c ? null : { rule: c.simple, t: s(c[c.simple].t), p: +c[c.simple].p.toFixed(4), bite: c[c.simple].bt ? s(c[c.simple].bt) : null,
        quick: c.quick ? { rule: c.quick.pol, t: s(c.quick.t), p: +c.quick.p.toFixed(4), bite: c.quick.bt ? s(c.quick.bt) : null } : null,
        rules: Object.fromEntries(Object.keys(c).filter(k => /^(bite\d|hold)$/.test(k)).map(k => [k, [s(c[k].t), +c[k].p.toFixed(4)]])) });
      out.page = { bites: R.checkTimings && R.bites, end: R.endS };
      out.all = cast(o.all);
      const win = w => (!w ? null : { rule: w.pol, t: s(w.t), lo: s(w.lo), hi: s(w.hi), p: +w.p.toFixed(4), bite: w.bt ? s(w.bt) : null });
      out.blind = o.blind.rows.map(r => ({ dog: r.base + '_' + r.dir, line: r.line, share: +r.share.toFixed(4), win: win(r.win) }));
      out.blindNone = win(o.blind.none.win); out.blindAll = win(o.blind.all.win);
      out.lines = o.lines.map(r => ({ name: r.name, share: +r.share.toFixed(4), cast: cast(r.cast) }));
      out.harb = o.harb.map(r => ({ line: r.line, t: s(r.t), share: +r.share.toFixed(4), pure: +r.pure.toFixed(3), cast: cast(r.cast) }));
      out.arrive = o.arrive.filter(r => r.share >= 0.003).map(r => ({ dog: r.key, share: +r.share.toFixed(4), lines: r.lines.slice(0, 3).map(l => l.name + ' ' + (100 * l.p).toFixed(0) + '%').join(', '), cast: cast(r.cast) }));
      out.wide = (o.wide || []).map(r => ({ name: r.name, share: +r.share.toFixed(4), more: r.more, runs: r.runs.map(w => ({ rule: w.pol, from: s(2 * w.i0), to: s(2 * w.i1), n: w.n, t: s(w.t), p: +w.p.toFixed(4), bite: w.bt ? s(w.bt) : null })) }));
      out.tabs = [...document.querySelectorAll('.rftabs button')].map(b => b.dataset.tab + ':' + b.textContent);
      out.widePane = { rows: document.querySelectorAll('[data-pane="wide"] tr').length, len: ((document.querySelector('[data-pane="wide"]') || {}).innerHTML || '').length };
      const paneRows = id => [...document.querySelectorAll(`[data-pane="${id}"] tr`)].slice(1).map(tr => tr.textContent.replace(/\s+/g, ' ').trim());
      out.txt = { blind: paneRows('blind'), lines: paneRows('lines'), harb: paneRows('harb'), arrive: paneRows('arrive'), wide: paneRows('wide') };
      out.timings = R.checkTimings();
      out.text = { push: (document.querySelector('[data-pane="blind"]') || {}).textContent.match(/Cast after 40 s[^.]*\./) };
      /* the close-up of the first later-bite blind row (or the first row) */
      const ids = [...R.charts.keys()];
      const late = ids.find(id => /^bite[3-8]$/.test(R.charts.get(id).ch.pol)) || ids[0];
      out.closeup = { id: late, pol: late ? R.charts.get(late).ch.pol : null };
      if (late) {
        R.openChart(late); await sleep(60);
        const x = R.closeup, cv = $('rfcCanvas'), r = cv.getBoundingClientRect();
        out.closeup.title = $('rfcTitle').textContent; out.closeup.legend = [...document.querySelectorAll('#rfChartDlg .rflg span')].map(e => e.textContent);
        out.closeup.radios = [...document.querySelectorAll('input[name=rfcPol]')].map(e => e.value);
        const L = x.L, clickAt = (px, py) => cv.dispatchEvent(new MouseEvent('click', { clientX: r.left + px * r.width / L.W, clientY: r.top + py * r.height / L.H, bubbles: true }));
        const i0 = x.ch.st - x.ch.a; clickAt(L.L0 + (i0 + 1) * L.pf + 1, 40); await sleep(30);
        out.closeup.sel = x.sel; out.closeup.head = ($('rfcLines').querySelector('.rfcsel') || {}).textContent;
        clickAt(L.L0 + (i0 + 1) * L.pf + 1, 40); await sleep(30);
        const tr = $('rfcLines').querySelector('tr.ln'); if (tr) { tr.click(); await sleep(30); }
        out.closeup.focus = x.focus; const tm = $('rfcLines').querySelector('tr.tm'); if (tm) { tm.click(); await sleep(30); }
        out.closeup.tm = R.closeup.tm; out.closeup.timHead = ($('rfcLines').querySelectorAll('th')[3] || {}).textContent;
        $('rfcTryBtn').click(); await sleep(30);
        out.closeup.try = [];
        for (const v of out.closeup.radios) { const e = [...document.querySelectorAll('input[name=rfcPol]')].find(z => z.value === v); e.checked = true; e.onchange({ target: e }); await sleep(20); out.closeup.try.push([v, $('rfcTryOut').textContent.match(/Your inputs: ([0-9.]+%)/) ? RegExp.$1 : null]); }
        $('rfChartDlg').close();
      }
      /* the stopwatch with a late cast */
      const late2 = [...document.querySelectorAll('#rfBody .rfcast')].map(b => +b.dataset.t).filter(t => t * VI / 1000 > 107)[0];
      if (late2) { R.setTarget(late2, '', null); R.start(performance.now() - 99.5 * 1000); await sleep(30); out.watch = $('rfTarget').textContent; R.reset(); }
      out.help = null;
    } catch (e) { out.errors.push('test: ' + e.message + ' ' + (e.stack || '').split('\n')[1]); }
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out, null, 1); document.body.appendChild(pre);
  }, 400);
})();
