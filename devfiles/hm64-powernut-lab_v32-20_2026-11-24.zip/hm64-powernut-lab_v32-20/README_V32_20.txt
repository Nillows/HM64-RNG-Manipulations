HM64 Power Nut Tool v32.20 (2026-11-24): the cast report shows the frames around the target
============================================================================================

What you asked for (23:37)
  "can you show the surrounding lines around the group? ... i got this cast report, but pulled up a medium fish instead
  of a powernut, so id like to see the adjacent bars in the cast report around whatever group the player tried to hit
  ... if the bar doesnt have anything at the shared bite cluster then just leave the bar empty because you would cruise
  through the cluster if you cast on that frame."

What changed (v32.20 includes v32.7 - v32.19)
  - Lucky Timer, freestyle cast report (L4 -> Report): every cast frame around the target now shows what a cast on
    it would have caught at the target's bite, the moment you let go.
      - Full bar: the Power Nut, coloured by bite, with the bite number.
      - Shorter grey bar: a fish, marked S / M / L with the bite number.
      - No bar: that frame has no bite at that moment.
  - The report text lists the 6 frames on each side (e.g. "before M2 M2 · · | target | after · L4"). It says which side
    each fish size sits on: before = early, after = late.
  - The report also lists the target cast's own bites in order. A fish that matches none of the neighbours but one of
    those means you let go at an earlier bite.
  - Reports stored before v32.20 get the same view when you open them, if their target can be found again without doubt.
  - Your 11:31 pm report (L41, triple x4, bite 4, Nut at 152.99 s): none of the 10 frames either side of the target
    bites at that moment, except one more 4th-bite Nut 3 frames after.
    The target cast's own bites: 1st small fish 89.4 s, 2nd MEDIUM fish 99.8 s, 3rd small fish 121.7 s, 4th NUT 153.0 s.
    So the medium fish points to letting go at the 2nd bite (or another dog), not to a cast a frame early or late.
  - README section 8: "Around the target" with a picture.

Release
  bash ~/Documents/hm64/tools/hm64_release.sh v32-20 <lab sha256> <pages sha256> </dev/null
