HM64 Power Nut Tool v32.6 (2026-11-24): the release opens the website, a release-window switch, a compact hub
=============================================================================================================

What you asked for (2026-11-24 09:09)
  "can you change the behaviour of the script to not open the file locally but instead on my github 'pages' for it
  https://nillows.github.io/HM64-RNG-Manipulations/ as long as it clones from origin its fine."
  "add a checkbox in the histogram settings to "show release window" and that either enables or disables the bottom
  histogram bar representing the release windows so it looks like what it did before we added it."
  "harmonize and compactify the main index page ... a series of check boxes the player checks off or doesnt and then
  they click the same button to go to either the cast tables for that, the lucky timer, or the dog practice as its own
  3 consistent buttons on the main page"

What changed
  Release script rev f (tools/hm64_release.sh, SCRIPT_REV 2026-11-24f; the installed rev e installs it from the lab zip
  and starts again with it)
    - After the push and the local install, it waits until GitHub Pages serves this release (the site's
      site_files.sha256 equal to the one just pushed; checked every 10 s, at most 5 min: HM64_PAGES_WAIT_S /
      HM64_PAGES_STEP_S), then opens https://nillows.github.io/HM64-RNG-Manipulations/?v=<version> in Firefox
      (the ?v= makes Firefox fetch the new hub). If Pages is slow it opens it anyway and says to reload.
    - The local copy (~/Documents/hm64/webapp, your HM64_Dog_Oracle_v30_0.html) is still updated and backed up, but
      not opened. Note: the website keeps its own settings, taps and attempts in Firefox (per site), separate from the
      local file's.
  Lucky Timer: Settings -> Lucky Timer -> "Release line and window" -> "Show the release window under the histogram"
    - On (default) = as before. Off: in Freestyle the "let go here" lane and the threads from each bar go and the bars
      take the whole histogram, as before v31.18 (the pink release line of a marked cast, if that setting is on, is
      drawn over the bars); in the app's own odds the lane of bites after the cast (first bites, release band, blind
      release curve, plop) goes and the P(Nut) lane takes the whole height. The lane is still worked out without
      being drawn, so the lamp's let-go countdown keeps working. Stored as L.relWin.
  Hub (index.html)
    - "Your game file - tick what is true of it": Rainy morning, I own the horse, Married (later), A baby (later).
      Below: the file's name and status, then three buttons that are always the same, in the same order: Casting
      tables, Lucky Timer, Dog practice. A file without tables yet (rainy) greys them out. Under them: the weather's
      note and "Your game file needs, and how to make it" for that file. Ticks are remembered (hm64v32_hub);
      #<set id> in the address picks a file (e.g. .../#sunny-horse). Without scripts: a plain list of every page.
    - site.json: "traits" (rainy, horse; married and baby marked later) and each set's traits; shorter button blurbs.
      site_build.py hands the hub its picker data (hub_json) and stops if two sets share the same traits.
    - Page links carry ?v=<version> so a browser fetches the new page after a release.

Checks (sandbox, headless Chrome)
  - Hub (tests/ui_hub.js): ticks -> Sunny/No horse, Sunny/Horse (ready, three links each), Rainy/Horse and Rainy/No horse
    (collecting, three greyed buttons), remembered, #sunny-horse picks it; married / baby disabled.
  - Release window (tests/ui_relwin.js + screenshots): box on by default; off hides the lane in Freestyle (run.fsLive
    still 7 windows, the lamp unchanged) and the bites lane in the odds view; on gives the v32.5 picture.
  - Unchanged: casting numbers (checksums), Dog practice drills, Try it, Enter = top dog, pier start, site defaults.
  - Release rev f in the mock Mac (stand-in GitHub Pages): installs itself over rev e, pushes, waits for Pages
    (immediately; and with Pages two checks behind), prints the website it opens; local install as before.

Files (lab_changes/, cumulative)
  tools/hm64_release.sh (rev f), webapp/hm64_lucky_v29.js (relWin), webapp/site/partials/lucky_dialogs.html (the box),
  webapp/site/templates/hub.html, webapp/site/site.json (v32.6, traits), tools/site_build.py (hub_json),
  tests/ui_hub.js, tests/ui_relwin.js

Release
  bash ~/Documents/hm64/tools/hm64_release.sh v32-6 <lab sha256> <pages sha256> </dev/null
