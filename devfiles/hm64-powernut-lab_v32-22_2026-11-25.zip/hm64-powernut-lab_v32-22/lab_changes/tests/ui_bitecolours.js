/* headless (v32.21): one colour per bite (Thomas 2026-11-24 23:50). On a rainy Lucky Timer page: the palette, the
   latest bite per dog line, a freestyle attempt on the card whose line reaches the latest bite (its bars in their bite's
   colour, read back from the canvas pixels, and the legend), then the same pick with the known-line view off: the
   "P(Nut) if you cast here" lane split by bite must add up to the any-bite curve, and the zone plan's later-bite
   histogram split by bite must add up to its total. Screens are returned as data URLs. Route id: sed-replaced. */
(function () {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => {
    const A = window.HM64LuckyApp, C = window.HM64Lucky, DW = window.HM64DogWatch, $ = id => document.getElementById(id), out = { errors: [] }, shots = {};
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    try {
      const RID = 'lineup-lineup2';
      localStorage.clear(); $('arLucky').click(); A.L.audio = false;
      $('lkRoute').value = RID; $('lkRoute').onchange({ target: $('lkRoute') });
      $('lkDwOn').checked = true; $('lkDwOn').onchange({ target: $('lkDwOn') });
      const R = C.routeOf(RID), vi = 33.430 / 2;
      out.palette = [1, 2, 3, 4, 5, 6, 7].map(n => [n, A.bcol(n), A.bname(n)]);
      const tops = {}; R.dw.lines.forEach((l, i) => { if (l.li < 0) return; const t = A.fsTopBite(R, i); tops[t] = (tops[t] || 0) + 1; });
      out.linesByTopBite = tops;
      A.L.free = true; A.fsSync();
      out.free = A.L.free;
      const tNow = () => (performance.now() - A.run.wall0) / vi + 1, tick = () => { A.dwTick(tNow()); A.drawTimeline(tNow()); };
      const plan = A.plans[0], cands = DW.candidates(R, plan, 'all', 'fadein'), c = cands.filter(x => x.pv >= 0).sort((a, b) => b.w - a.w)[0];
      const F0 = performance.now() - (c.mt - 1) * vi - 600;
      A.start(F0 - 70 * vi + 230); A.seqPress(F0 + 66 * vi + 230); A.seqPress(F0 + (c.mt - 1) * vi + 230);
      await sleep(300); tick();
      { const z = A.run.zone;                                     // the plan before a dog is picked: the later-bite histogram by bite
        if (z && z.d3) { let maxd = 0; for (const [bn, v] of z.d3) { let s = 0; for (const n of [3, 4, 5, 6]) s += (z.d3b[n] && z.d3b[n].get(bn)) || 0; maxd = Math.max(maxd, Math.abs(s - v)); }
          out.d3 = { bins: z.d3.size, maxAbsDiff: maxd, bites: Object.fromEntries(Object.entries(z.d3b).map(([n, m]) => [n, m.size])) }; }
        const fc = z && C.forecast ? C.forecast(z, 1) : null;     // after one bite held: the hold spans carry the later Nut's bite
        out.holds = fc ? { n: fc.holds.length, withBite: fc.holds.filter(h => h[2] >= 2).length, first: fc.holds.slice(0, 6).map(h => [+((h[0] - 1) * vi / 1000).toFixed(2), +((h[1] - 1) * vi / 1000).toFixed(2), h[2]]) } : null; }
      const cards = [...$('lkCompCards').querySelectorAll('.lkdog')].map(e => +e.dataset.dwi);
      const best = cards.slice().sort((p, q) => A.fsTopBite(R, q) - A.fsTopBite(R, p))[0];
      out.cards = cards.map(d => ['L' + (R.dw.lines[d].li + 1), A.fsTopBite(R, d)]);
      $('lkCompCards').querySelector(`.lkdog[data-dwi="${best}"]`).click(); await sleep(60); tick();
      const w = A.run.dw, dwi = w.pick.dwi, K = A.knownView(tNow()), a = K.a;
      out.pick = { line: K.name, top: A.fsTopBite(R, dwi), fs: !!K.fs };
      /* the bars ahead, each with its bite; a 16-s view that holds the most different bites from 3 up */
      const bars = []; for (let v = Math.ceil(tNow()) + 30; v < 7100; v++) { const kc = Math.round(v + a); if (kc % 2) continue; const nb = A.dcNutAt(R, dwi, kc); if (nb > 0) bars.push([v, nb, kc]); }
      let pickT = null, pickSet = 0;
      for (const [v] of bars) { const t0 = v - 3 * 1000 / vi, s = new Set(bars.filter(b => b[0] >= v && b[0] < v + 12 * 1000 / vi).map(b => b[1])); const k = [...s].filter(n => n >= 3).length; if (k > pickSet) { pickSet = k; pickT = t0; } }
      out.bars = { n: bars.length, byBite: bars.reduce((o, b) => (o[b[1]] = (o[b[1]] || 0) + 1, o), {}), viewAt: pickT && +((pickT - 1) * vi / 1000).toFixed(2), bitesInView: pickSet };
      if (pickT != null) {
        await sleep(Math.max(0, (pickT - tNow()) * vi)); tick();
        const cv = $('lkTimeline'), g = cv.getContext('2d'), dpr = devicePixelRatio, W = cv.width, H = cv.height, t = tNow();
        const sec = 1000 / A.viMs(), v0 = t - 2.5 * sec, span = 16 * sec, X = v => (v - v0) / span * W;
        const hex = (r, gg, b) => '#' + [r, gg, b].map(x => x.toString(16).padStart(2, '0')).join('');
        const chk = { ok: 0, bad: [], exact: 0 }, dbl = A.fsDoubles(R, dwi), inDbl = kc => dbl.some(d => kc >= d.k0 && kc <= d.k1);
        const bot = H - ((K.fs && A.L.relWin !== false) ? 96 : 22) * dpr, y = Math.round(bot - 5 * dpr), wd = Math.max(2 * dpr, X(2) - X(0) - 1);
        const rgb = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16)), BG = rgb('#0d1a14'), d2 = (p, q) => (p[0] - q[0]) ** 2 + (p[1] - q[1]) ** 2 + (p[2] - q[2]) ** 2;
        const bySide = new Map(bars.map(b => [b[2], b[1]]));
        for (const [v, nb, kc] of bars) { if (v < v0 + 4 || v > v0 + span - 4 || inDbl(kc)) continue;
          if ((bySide.get(kc - 2) || nb) !== nb || (bySide.get(kc + 2) || nb) !== nb) continue;   // a neighbour of another bite overlaps the edge pixels
          let px = null; for (let x = Math.floor(X(v)) - 1; x <= Math.ceil(X(v) + wd) + 1; x++) { const p = g.getImageData(x, y, 1, 1).data, q = [p[0], p[1], p[2]]; if (!px || d2(q, BG) > d2(px, BG)) px = q; }
          const near = [1, 2, 3, 4, 5, 6].sort((m, n) => d2(px, rgb(A.bcol(m))) - d2(px, rgb(A.bcol(n))))[0];
          if (hex(...px) === A.bcol(nb)) chk.exact++;
          if (near === nb) chk.ok++; else chk.bad.push([+((v - 1) * vi / 1000).toFixed(2), nb, A.bcol(nb), hex(...px), near]); }
        out.pixels = { ok: chk.ok, exact: chk.exact, bad: chk.bad.slice(0, 8), nBad: chk.bad.length };
        shots.freestyle = cv.toDataURL('image/png');
        out.lamp = (A.fsCue(tNow()) || {}).big;
        out.fsLiveBites = [...new Set((A.run.fsLive || []).map(x => x.nb))].sort();
      }
      /* the known-line view off: the plan lane with the any-bite curve split by bite */
      if (A.fsOn()) A.fsToggle(); A.L.knownView = false; await sleep(30); tick(); out.laneMode = { fs: A.fsOn(), known: A.run.known };
      const cvA = A.run.dw && A.run.dw.anyCv;
      if (cvA) {
        let maxd = 0, n = 0, top = 0; const mass = [0, 0, 0, 0, 0, 0, 0];
        for (let v = cvA.lo; v <= cvA.hi; v += 3) { const o = cvA.by(v), s = o.reduce((p, q) => p + q, 0), at = cvA.at(v); maxd = Math.max(maxd, Math.abs(s - at)); n++; for (let k = 1; k <= 6; k++) { mass[k] += o[k]; if (o[k] > 0 && k > top) top = k; } }
        const tot = mass.reduce((p, q) => p + q, 0);
        out.anyCv = { checked: n, maxAbsDiff: maxd, top, massByBite: mass.slice(1).map(m => +(m / (tot || 1)).toFixed(4)), cachedTop: cvA.top };
        shots.lane = $('lkTimeline').toDataURL('image/png');
      } else out.anyCv = null;
    } catch (e) { out.errors.push('test: ' + e.message + ' ' + (e.stack || '').split('\n')[1]); }
    out.shots = shots;
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, 400);
})();
