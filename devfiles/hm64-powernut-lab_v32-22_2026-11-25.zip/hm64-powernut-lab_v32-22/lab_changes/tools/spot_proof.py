"""Spot-proof the rainy tables (v32.22, 2026-11-25).

A rainy cast was recorded with Jack in the north camera zone of the dock end. The pier-spot run repeated every recorded
Power Nut cast from the middle zone (z 164.4 and 176.4) and the south zone (z 194.4). This tool keeps a Nut bite in the
app's data only if the measured casts gave that Nut on the same bite at the same moment, with the same bites before it,
in every zone it was measured in. Every other Nut bite (lost in a zone, never measured, or beyond the measured bites)
becomes the catch letter 'f' = "a fish; Power Nut only from the north end": the pages count only 'N'.

  python3 -I tools/spot_proof.py --pack IN.json --routes IN_routes.json --plan spot_plan_<label>.json.gz \
      --spots results/spots/<label>/SP2_casts.jsonl --pack-out OUT.json --routes-out OUT_routes.json [--report R.json]

A line whose members all stand in the north zone (its second cuts reach no other spot: --zz, the dog-watch run's
zz_lines.json) is north by nature: its frames keep the recorded casts as they are.

How: the cast pack shares casts and bite states between lines, so a cast that loses a Nut gets a copy (a new cast id
with its own copy of the bite chain up to its last such bite; new entries appended, nothing else moves) and the frames
of the lines that reach other zones point at the copy. In the route table the bite-1 / bite-2 Nut flags
(n1 / n2) of those casts are cleared and the counts corrected. Run it on the ORIGINAL (north) files: it refuses a
pack that already holds an 'f'.
"""
import argparse
import gzip
import json
import sys

ap = argparse.ArgumentParser()
for a in ("pack", "routes", "plan", "spots", "zz", "pack-out", "routes-out"):
    ap.add_argument("--" + a, required=True)
ap.add_argument("--report")
A = ap.parse_args()

pack = json.load(open(A.pack))
if "f" in pack["O"]:
    sys.exit("STOP: this pack already holds 'f' catches - run the tool on the original (north) pack")
routes = json.load(open(A.routes))
plan = json.load(gzip.open(A.plan, "rt"))
zz = json.load(open(A.zz))
NORTH_ONLY = {k for k, L in zz.items() if all(m.get("spot", [0, 0])[1] < 161 for m in L["members"]) and L["rep"]["spot"][1] < 161}
F, S, N, X = pack["F"], pack["S"], pack["N"], pack["X"]
O = list(pack["O"])
STATE_ARRAYS = [k for k in ("R", "N", "X", "L", "T") if k in pack]
CAST_ARRAYS = [k for k in ("P", "F", "S", "E") if k in pack]
assert all(len(pack[k]) == len(S) for k in CAST_ARRAYS) and all(len(pack[k]) == len(O) for k in STATE_ARRAYS)
lines = pack["lines"]


def chain(c, limit=40):
    """[(VIs after the cast, catch, state)]"""
    out, t, st = [], F[c], S[c]
    while st is not None and st >= 0 and len(out) < limit:
        out.append((t, O[st], st))
        if N[st] is None or N[st] < 0:
            break
        t += N[st]
        st = X[st]
    return out


def cid_of(key, k):
    L = lines.get(key)
    if not L:
        return None
    j, rem = divmod(k - L["k0"], 2)
    if rem or j < 0 or j >= len(L["idx"]):
        return None
    c = L["idx"][j]
    return c if c is not None and c >= 0 else None


# measurements per cast id: zone tag -> list of bite lists (relative times)
meas = {}
for ln in open(A.spots):
    r = json.loads(ln)
    tag = r.get("_job", {}).get("spot")
    if tag not in ("z164.4", "z176.4", "z194.4"):
        continue
    for c in r.get("casts", []):
        cid = cid_of(r["key"], c["k"])
        if cid is None:
            continue
        meas.setdefault(cid, {}).setdefault(tag, []).append([(b[0] - c["k"], b[1]) for b in c["b"]])

rep = {"nut_bites": 0, "kept": 0, "north_only_lost_in_a_zone": 0, "north_only_not_measured": 0, "casts_changed": 0, "states_added": 0}
flag = {}          # cast id -> set of bite indexes (0-based) to turn into 'f'
ncast = len(S)
for c in range(ncast):
    if S[c] is None or S[c] < 0:
        continue
    ch = chain(c)
    nuts = [i for i, (_, o, _) in enumerate(ch) if o == "N"]
    if not nuts:
        continue
    m = meas.get(c)
    for i in nuts:
        rep["nut_bites"] += 1
        want = [(t, o) for t, o, _ in ch[:i + 1]]
        if not m:
            rep["north_only_not_measured"] += 1
            flag.setdefault(c, set()).add(i)
            continue
        ok = True
        short = False
        for tag, runs in m.items():
            for got in runs:
                if len(got) <= i:
                    short = True
                elif got[:i + 1] != want:
                    ok = False
        if not ok:
            rep["north_only_lost_in_a_zone"] += 1
            flag.setdefault(c, set()).add(i)
        elif short:
            rep["north_only_not_measured"] += 1
            flag.setdefault(c, set()).add(i)
        else:
            rep["kept"] += 1

copy_of = {}
FLAG_OF_COPY = {}
for c, idxs in flag.items():
    ch = chain(c)
    last = max(idxs)
    new_ids = []
    for i in range(last + 1):
        st = ch[i][2]
        nid = len(O)
        for a in STATE_ARRAYS:
            pack[a].append(pack[a][st])
        O.append("f" if i in idxs else O[st])
        new_ids.append(nid)
    for i in range(last):
        X[new_ids[i]] = new_ids[i + 1]
    nc = len(S)
    for a in CAST_ARRAYS:
        pack[a].append(pack[a][c])
    S[nc] = new_ids[0]
    copy_of[c] = nc
    FLAG_OF_COPY[nc] = idxs
    rep["casts_changed"] += 1
    rep["states_added"] += len(new_ids)
rep["frames_repointed"] = rep["frames_north_only_lines_kept"] = 0
for key, L in lines.items():
    north = key in NORTH_ONLY
    for j, c in enumerate(L["idx"]):
        if c is not None and c in copy_of:
            if north:
                rep["frames_north_only_lines_kept"] += 1
            else:
                L["idx"][j] = copy_of[c]
                rep["frames_repointed"] += 1
rep["north_only_lines"] = len([k for k in lines if k in NORTH_ONLY])
pack["O"] = "".join(O)
pack["spot_proof"] = {"v": 1, "by": "tools/spot_proof.py", "f": "Power Nut only from the north camera zone of the dock end", **rep}

# the route tables: bite-1 / bite-2 Nut flags per cast frame
R = routes["routes"]
rr = {"routes": 0, "n1_cleared": 0, "n2_cleared": 0}
for route in R:
    info = route.get("line_info") or []
    tot1 = tot2 = 0
    for li, ln in enumerate(route.get("lines") or []):
        key = info[li]["key"]
        if "n1" not in ln:
            continue
        n1 = ln["n1"].split(".")
        n2 = ln["n2"].split(".") if "n2" in ln else None
        before = (rr["n1_cleared"], rr["n2_cleared"])
        for i in range(len(n1)):
            if key not in lines or key in NORTH_ONLY:
                continue
            j = i
            c = lines[key]["idx"][j] if j < len(lines[key]["idx"]) else None
            if c is None or c < 0 or c < ncast:
                continue
            f = flag.get(next(o for o, n in copy_of.items() if n == c), ()) if False else FLAG_OF_COPY.get(c, ())
            if n1[i] != "0" and 0 in f:
                n1[i] = "0"
                rr["n1_cleared"] += 1
            if n2 is not None and n2[i] != "0" and 1 in f:
                n2[i] = "0"
                rr["n2_cleared"] += 1
        ln["n1"] = ".".join(n1)
        if n2 is not None:
            ln["n2"] = ".".join(n2)
        d1, d2 = rr["n1_cleared"] - before[0], rr["n2_cleared"] - before[1]
        if "wins1" in ln:
            ln["wins1"] -= d1
        if "wins2" in ln:
            ln["wins2"] -= d2
        if "nut1" in info[li]:
            info[li]["nut1"] -= d1
        if "nut2" in info[li]:
            info[li]["nut2"] -= d2
        tot1 += d1
        tot2 += d2
    src = route.get("source")
    if isinstance(src, dict) and "nut1" in src:
        src["nut1"] -= tot1
        src["nut2"] -= tot2
        src["spot_proof"] = "Nut flags only where the Nut held in every measured camera zone of the dock end (tools/spot_proof.py)"
    rr["routes"] += 1
json.dump(pack, open(getattr(A, "pack_out"), "w"), separators=(",", ":"))
json.dump(routes, open(getattr(A, "routes_out"), "w"), separators=(",", ":"))
rep.update(rr)
if A.report:
    json.dump(rep, open(A.report, "w"), indent=1)
print(json.dumps(rep))
