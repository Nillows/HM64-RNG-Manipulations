set -euo pipefail
SCRIPT_REV="2026-11-25g"
if [ "${1:-}" = labdata ]; then
  shift
  [ -f "$HOME/Documents/hm64/tools/hm64_labdata.sh" ] || { echo "STOP: $HOME/Documents/hm64/tools/hm64_labdata.sh is missing (it comes with the release tools setup file)"; exit 1; }
  exec bash "$HOME/Documents/hm64/tools/hm64_labdata.sh" "$@"
fi
VER="${1:?usage: hm64_release.sh VERSION LAB_SHA256 PAGES_SHA256   |   hm64_release.sh labdata [wait]}"
LAB_SHA="${2:-}"
PAGES_SHA="${3:-}"
VER_US=$(printf '%s' "$VER" | tr '-' '_')
VER_DOT=$(printf '%s' "$VER" | tr '-' '.')
DL="$HOME/Downloads"
HM="$HOME/Documents/hm64"
TOOLS="$HM/tools"
TS=$(date +%Y%m%d-%H%M%S)
BK="$HM/backups/${TS}_${VER}"
STAGE="$BK/stage"
mkdir -p "$BK" "$TOOLS" "$STAGE"
exec > >(tee -a "$BK/release.log") 2>&1
PUSHED=no
SITE=no
SITEFILES=""
LOCAL=""
MAIN=""
export GIT_TERMINAL_PROMPT=0
GH_ED25519='github.com ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIOMqqnkVzrm0SdG6UOoqKLsabgH5C9okWi0dh2l9GKJl'
SSHKEY="$HOME/.ssh/hm64_github_ed25519"
DIED=no
say() { printf '\n==> %s\n' "$*"; }
die() {
  DIED=yes
  printf '\nSTOP: %s\n' "$*"
  if [ "$PUSHED" = no ]; then printf 'Nothing was pushed to GitHub.\n'; fi
  printf 'Log and backups: %s\n' "$BK"
  exit 1
}
on_err() { rc=$?; [ "$DIED" = no ] || return 0; die "unexpected error (exit $rc) at line $1 of the release script: $2"; }
on_exit() {
  rc=$?
  if [ "$rc" -ne 0 ] && [ "$DIED" = no ]; then
    printf '\nSTOP: the release script stopped unexpectedly (exit %s); the last lines above say where.\n' "$rc"
    if [ "$PUSHED" = no ]; then printf 'Nothing was pushed to GitHub.\n'; else printf 'The push to GitHub had already gone through.\n'; fi
    printf 'Log and backups: %s\n' "$BK"
  fi
}
trap 'on_err $LINENO "$BASH_COMMAND"' ERR
trap on_exit EXIT
sha_of() { shasum -a 256 "$1" | awk '{print $1}'; }
pick() {
  pat="$1"; want="$2"; found=""
  while IFS= read -r f; do
    [ -n "$f" ] || continue
    if [ -z "$want" ] || [ "$(sha_of "$f")" = "$want" ]; then found="$f"; break; fi
  done <<LIST
$(ls -t "$DL"/$pat 2>/dev/null || true)
LIST
  printf '%s' "$found"
}
canon() { basename "$1" | sed -E -e 's/ ?\([0-9]+\)\.zip$/.zip/' -e 's/ [0-9]+\.zip$/.zip/'; }
explain_missing() {
  kind="$1"; pre="$2"; want="$3"; pat="${pre}_*.zip"
  printf '\nThe %s zip (%s) with checksum %s… is not in %s. What is there:\n' "$kind" "$pat" "$(printf '%s' "$want" | cut -c1-12)" "$DL"
  any=no
  while IFS= read -r f; do
    [ -n "$f" ] || continue
    any=yes
    case "$f" in
      *.part|*.crdownload|*.download|*.partial) printf '  STILL DOWNLOADING: %s (wait until the browser has finished)\n' "$(basename "$f")" ;;
      *.zip) s=$(sha_of "$f"); if [ "$s" = "$want" ]; then m="checksum matches"; else m="DIFFERENT checksum $(printf '%s' "$s" | cut -c1-12)… (not this release's file: download it again)"; fi
             printf '  %s  %s MB  %s\n' "$(basename "$f")" "$(( $(wc -c < "$f") / 1048576 ))" "$m" ;;
      *) printf '  %s\n' "$(basename "$f")" ;;
    esac
  done <<LIST
$(find "$DL" -maxdepth 1 -iname "${pre}*" 2>/dev/null || true)
LIST
  [ "$any" = yes ] || printf '  nothing named like it: download it from the chat into Downloads\n'
  elsewhere=$(find "$HOME/Desktop" "$HOME/Documents" -maxdepth 2 -name "$pat" -not -path "$HM/backups/*" 2>/dev/null | head -n 3 || true)
  if [ -n "$elsewhere" ]; then printf '  found outside Downloads (move it into Downloads):\n%s\n' "$(printf '%s\n' "$elsewhere" | sed 's/^/    /')"; fi
}
gh_try() {
  if [ -n "${1:-}" ]; then GH_OUT=$(ssh -i "$1" -o IdentitiesOnly=yes -o BatchMode=yes -o ConnectTimeout=20 -T git@github.com 2>&1 </dev/null || true)
  else GH_OUT=$(ssh -o BatchMode=yes -o ConnectTimeout=20 -T git@github.com 2>&1 </dev/null || true); fi
  printf '%s\n' "$GH_OUT" >> "$BK/ssh_tests.txt"
  GH_USER=""
  case "$GH_OUT" in *"successfully authenticated"*) GH_USER=$(printf '%s\n' "$GH_OUT" | sed -n 's/^Hi \([^!]*\)!.*/\1/p' | head -n 1) ;; esac
  [ -n "$GH_USER" ] || return 1
  u=$(printf '%s' "$GH_USER" | tr '[:upper:]' '[:lower:]'); o=$(printf '%s' "$OWNER" | tr '[:upper:]' '[:lower:]')
  case "$u" in "$o"|"$o"/*) return 0 ;; esac
  echo "note: that SSH key belongs to GitHub user $GH_USER, not $OWNER"
  return 1
}
gh_try_n() {
  t=0
  while :; do
    if gh_try "$1"; then return 0; fi
    t=$((t + 1))
    case "$GH_OUT" in *"Permission denied"*) [ "$t" -lt 3 ] || return 1; sleep 3 ;; *) return 1 ;; esac
  done
}
gh_unreachable() {
  case "$GH_OUT" in
    *"Could not resolve"*|*"timed out"*|*"Connection refused"*|*"Network is unreachable"*|*"No route to host"*|*"Connection closed"*|*"Connection reset"*)
      die "this Mac cannot reach GitHub over SSH right now: $(printf '%s' "$GH_OUT" | head -n 1). Check the internet connection, then run the same command again." ;;
    *"IDENTIFICATION HAS CHANGED"*|*"Host key verification failed"*)
      die "SSH does not trust github.com's host key on this Mac ($(printf '%s' "$GH_OUT" | grep -m1 -E 'IDENTIFICATION|verification')). GitHub's real key is SHA256:+DiY3wvvV6TuJJhbpZisF/zLDA0zPMSvHdkr4UvCOqU. Remove the old entry with: ssh-keygen -R github.com   then run the same command again." ;;
  esac
}
ensure_push() {
  RAW=$(git config --get remote.origin.url || true)
  case "$RAW" in *github.com*) ;; *) echo "origin is not on github.com ($RAW): left as it is"; return 0 ;; esac
  OR=$(printf '%s' "$RAW" | sed -E -e 's#\.git$##' -e 's#^.*github\.com[:/]+##')
  OWNER="${OR%%/*}"
  SSH_URL="git@github.com:${OR}.git"
  command -v ssh >/dev/null 2>&1 && command -v ssh-keygen >/dev/null 2>&1 || die "ssh or ssh-keygen is missing on this Mac"
  mkdir -p "$HOME/.ssh"; chmod 700 "$HOME/.ssh"
  KH="$HOME/.ssh/known_hosts"
  if ! ssh-keygen -F github.com -f "$KH" 2>/dev/null | grep -q 'AAAAC3NzaC1lZDI1NTE5AAAAIOMqqnkVzrm0SdG6UOoqKLsabgH5C9okWi0dh2l9GKJl'; then
    if [ -f "$KH" ]; then cp "$KH" "$BK/known_hosts.before"; fi
    if [ -s "$KH" ] && [ -n "$(tail -c 1 "$KH")" ]; then echo >> "$KH"; fi
    printf '%s\n' "$GH_ED25519" >> "$KH"
    echo "added GitHub's published host key (ed25519, SHA256:+DiY3wvvV6TuJJhbpZisF/zLDA0zPMSvHdkr4UvCOqU) to $KH"
  fi
  MODE=""
  if [ -f "$SSHKEY" ] && gh_try_n "$SSHKEY"; then MODE=key
  elif gh_try ""; then MODE=default
  fi
  if [ -z "$MODE" ]; then
    gh_unreachable
    if [ ! -f "$SSHKEY" ]; then
      ssh-keygen -q -t ed25519 -N "" -C "hm64-release@$(hostname -s 2>/dev/null || echo mac)" -f "$SSHKEY"
      echo "made an SSH key for the releases (no passphrase): $SSHKEY"
    fi
    [ -f "$SSHKEY.pub" ] || ssh-keygen -y -f "$SSHKEY" > "$SSHKEY.pub"
  fi
  if [ -z "$MODE" ] && ! gh_try "$SSHKEY"; then
    PUB=$(cat "$SSHKEY.pub")
    if [ "$(uname)" = Darwin ]; then
      printf '%s' "$PUB" | pbcopy 2>/dev/null || true
      open -a Firefox "https://github.com/settings/ssh/new" 2>/dev/null || open "https://github.com/settings/ssh/new" 2>/dev/null || true
    fi
    cat <<MSG

GitHub does not know this key yet. One time only, in Firefox (GitHub's "new SSH key" page just opened: https://github.com/settings/ssh/new):
  Title: anything, e.g. Mac mini hm64
  Key type: Authentication Key
  Key: press Cmd+V (the key is on your clipboard; it is also the line below)
  then click "Add SSH key" (GitHub may ask for your password or a 2FA code)
$PUB

Waiting for GitHub to accept it (checks every ${HM64_SSH_WAIT_S:-5} s, up to $(( ${HM64_SSH_TRIES:-180} * ${HM64_SSH_WAIT_S:-5} / 60 )) min). Nothing has been changed yet.
MSG
    n=0
    until gh_try "$SSHKEY"; do
      gh_unreachable
      n=$((n + 1))
      [ "$n" -lt "${HM64_SSH_TRIES:-180}" ] || die "GitHub has not accepted the key ($SSHKEY.pub) yet. Add it at https://github.com/settings/ssh/new, then run the same command again."
      sleep "${HM64_SSH_WAIT_S:-5}"
    done
    echo "GitHub accepted the key."
  fi
  [ -n "$MODE" ] || MODE=key
  if [ "$MODE" = key ]; then
    git config core.sshCommand "ssh -i '$SSHKEY' -o IdentitiesOnly=yes"
    echo "push access: SSH key $SSHKEY (GitHub user $GH_USER), used by this clone only"
  else
    case "$(git config --get core.sshCommand || true)" in *hm64_github_ed25519*) git config --unset core.sshCommand ;; esac
    echo "push access: this Mac's usual SSH key (GitHub user $GH_USER)"
  fi
  PUSHURL=$(git config --get remote.origin.pushurl || true)
  if [ -n "$PUSHURL" ]; then printf 'pushurl %s\n' "$PUSHURL" >> "$BK/origin_before.txt"; git config --unset remote.origin.pushurl; fi
  if [ "$RAW" != "$SSH_URL" ]; then
    printf 'url %s\n' "$RAW" >> "$BK/origin_before.txt"
    git remote set-url origin "$SSH_URL"
    echo "origin switched to SSH: $RAW -> $SSH_URL (to go back: git -C \"$REPO\" remote set-url origin $RAW)"
  fi
}
is_repo() {
  [ -d "$1/.git" ] || return 1
  git -C "$1" remote get-url origin 2>/dev/null | tr '[:upper:]' '[:lower:]' | grep -q 'nillows/hm64-rng-manipulations'
}

say "1/8  Packages for $VER_DOT in $DL (release script $SCRIPT_REV)"
ls "$DL" >/dev/null 2>&1 || die "Terminal is not allowed to read your Downloads folder (macOS privacy). Turn it on: System Settings > Privacy & Security > Files and Folders > Terminal > Downloads Folder, then run the same command again."
LOCKS=$(find "$HM/runs" -maxdepth 3 -name .running 2>/dev/null | sed "s#^$HM/##" | tr '\n' ' ' || true)
CONT=0
if command -v docker >/dev/null 2>&1; then CONT=$(docker ps --format '{{.Image}}' 2>/dev/null | grep -c 'hm64-lab' || true); fi
if [ -n "$LOCKS" ] || [ "${CONT:-0}" -gt 0 ]; then
  echo "note: a lab run is going (${LOCKS:-no lock file}; ${CONT:-0} hm64-lab container(s)). The release does not touch it: it reads Downloads and writes only webapp/, hm64-powernut-lab_${VER}/, backups/, tools/ and your repo clone."
  LABNOTE=" A lab run is going and may be filling the disk (${LOCKS:-hm64-lab containers})."
else LABNOTE=""; fi
FREE_MB=$(( $(df -Pk "$HM" | awk 'NR==2{print $4}') / 1024 ))
NEED_MB=${HM64_MIN_FREE_MB:-1024}
[ "$FREE_MB" -ge "$NEED_MB" ] || die "only $FREE_MB MB free on the disk, the release needs about $NEED_MB MB (zips unpacked, backups, the repo copy).$LABNOTE Free some space, then run the same command again."
echo "free disk: $FREE_MB MB"
LAB=$(pick "hm64-powernut-lab_${VER}_*.zip" "$LAB_SHA")
PAGES=$(pick "hm64-powernut-tool_${VER}_github-pages_*.zip" "$PAGES_SHA")
if [ -z "$LAB" ]; then explain_missing lab "hm64-powernut-lab_${VER}" "$LAB_SHA"; die "the lab zip of $VER_DOT is missing (see above)"; fi
NEWSCRIPT=$(unzip -Z1 "$LAB" 2>/dev/null | grep '/tools/hm64_release\.sh$' | head -n 1 || true)
if [ -n "$NEWSCRIPT" ] && [ "${HM64_RELEASE_UPDATED:-}" != 1 ]; then
  unzip -p "$LAB" "$NEWSCRIPT" > "$BK/hm64_release.sh.new"
  NEWREV=$(grep -m1 '^SCRIPT_REV=' "$BK/hm64_release.sh.new" | cut -d'"' -f2 || true)
  if [[ "$NEWREV" > "$SCRIPT_REV" ]] && ! cmp -s "$BK/hm64_release.sh.new" "$TOOLS/hm64_release.sh"; then
    if [ -f "$TOOLS/hm64_release.sh" ]; then cp "$TOOLS/hm64_release.sh" "$BK/hm64_release.sh.old"; fi
    cp "$BK/hm64_release.sh.new" "$TOOLS/hm64_release.sh"
    echo "the package brings a newer release script ($NEWREV): installed it (old copy: $BK/hm64_release.sh.old), starting again with it"
    HM64_RELEASE_UPDATED=1 exec bash "$TOOLS/hm64_release.sh" "$VER" "$LAB_SHA" "$PAGES_SHA"
  fi
fi
NEWLD=$(unzip -Z1 "$LAB" 2>/dev/null | grep '/tools/hm64_labdata\.sh$' | grep -v lab_changes | head -n 1 || true)
if [ -n "$NEWLD" ]; then
  unzip -p "$LAB" "$NEWLD" > "$BK/hm64_labdata.sh.new"
  LDNEW=$(grep -m1 '^LABDATA_REV=' "$BK/hm64_labdata.sh.new" | cut -d'"' -f2 || true)
  LDOLD=""
  if [ -f "$TOOLS/hm64_labdata.sh" ]; then LDOLD=$(grep -m1 '^LABDATA_REV=' "$TOOLS/hm64_labdata.sh" | cut -d'"' -f2 || true); fi
  if [[ "$LDNEW" > "$LDOLD" ]]; then
    if [ -f "$TOOLS/hm64_labdata.sh" ]; then cp "$TOOLS/hm64_labdata.sh" "$BK/hm64_labdata.sh.old"; fi
    cp "$BK/hm64_labdata.sh.new" "$TOOLS/hm64_labdata.sh"
    echo "the package brings a newer lab-data script ($LDNEW): installed it"
  fi
fi
if [ -z "$PAGES" ]; then explain_missing "GitHub Pages" "hm64-powernut-tool_${VER}_github-pages" "$PAGES_SHA"; die "the GitHub Pages zip of $VER_DOT is missing (see above)"; fi
echo "lab:   $LAB"
echo "pages: $PAGES"
[ -z "$LAB_SHA" ] || echo "checksums: both match"

say "2/8  Unpacking into a staging folder and checking the contents"
unzip -q "$PAGES" -d "$STAGE/pages"
unzip -q "$LAB" -d "$STAGE/lab"
PKG="$STAGE/lab/hm64-powernut-lab_${VER}"
[ -d "$PKG" ] || die "the lab zip lacks the folder hm64-powernut-lab_${VER}/"
[ -f "$STAGE/pages/README.md" ] && [ -d "$STAGE/pages/media" ] || die "the pages zip lacks README.md or media/"
grep -q "HM64 Power Nut Tool $VER_DOT" "$STAGE/pages/README.md" || die "README.md is not the $VER_DOT README"
if [ -f "$STAGE/pages/site_files.sha256" ]; then
  SITE=yes
  LABSITE="$PKG/site"
  [ -f "$LABSITE/site_files.sha256" ] || die "the pages zip is a site (site_files.sha256) but the lab zip has no site/ folder"
  cmp -s "$LABSITE/site_files.sha256" "$STAGE/pages/site_files.sha256" || die "the two zips list different site files"
  BADP=$(cd "$STAGE/pages" && shasum -a 256 -c site_files.sha256 2>&1 | grep -v ': OK$' || true)
  [ -z "$BADP" ] || die "site files in the pages zip do not match their checksums: $(printf '%s' "$BADP" | head -n 3 | tr '\n' ' ')"
  BADL=$(cd "$LABSITE" && shasum -a 256 -c site_files.sha256 2>&1 | grep -v ': OK$' || true)
  [ -z "$BADL" ] || die "site files in the lab zip do not match their checksums: $(printf '%s' "$BADL" | head -n 3 | tr '\n' ' ')"
  SITEFILES=$(awk 'NF{print $2}' "$STAGE/pages/site_files.sha256")
  printf '%s\n' $SITEFILES | grep -qx 'index.html' || die "the site has no index.html"
  for f in $SITEFILES; do grep -qF "$VER_DOT" "$STAGE/pages/$f" || die "$f does not carry the version label $VER_DOT"; done
  if [ -f "$LABSITE/site_local.txt" ]; then LOCAL=$(cat "$LABSITE/site_local.txt"); fi
  for src in $(printf '%s\n' "$LOCAL" | awk 'NF{print $2}'); do printf '%s\n' $SITEFILES | grep -qx "$src" || die "site_local.txt names $src, which is not a site file"; done
  echo "site: $(printf '%s\n' $SITEFILES | wc -l | tr -d ' ') files, the same in both zips, every checksum right; README title $VER_DOT; $(ls "$STAGE/pages/media" | wc -l | tr -d ' ') media files"
  printf '%s\n' $SITEFILES | sed 's/^/  /'
else
  APP_NEW="$PKG/HM64_Dog_Oracle_${VER_US}.html"
  [ -f "$STAGE/pages/index.html" ] || die "the pages zip lacks index.html"
  [ -f "$APP_NEW" ] || die "the lab zip lacks HM64_Dog_Oracle_${VER_US}.html"
  cmp -s "$APP_NEW" "$STAGE/pages/index.html" || die "the app in the lab zip and index.html differ"
  grep -qF "$VER_DOT" "$STAGE/pages/index.html" || die "index.html does not carry the version label $VER_DOT"
  LOCAL="HM64_Dog_Oracle_v30_0.html HM64_Dog_Oracle_${VER_US}.html"
  echo "index.html = the lab zip's app, README title $VER_DOT, $(ls "$STAGE/pages/media" | wc -l | tr -d ' ') media files"
fi

say "3/8  Your clone of Nillows/HM64-RNG-Manipulations, and push access"
REPO=""
if [ -f "$TOOLS/repo_path.txt" ]; then p=$(cat "$TOOLS/repo_path.txt"); if is_repo "$p"; then REPO="$p"; fi; fi
if [ -z "$REPO" ]; then
  while IFS= read -r g; do
    d=$(dirname "$g")
    if is_repo "$d"; then REPO="$d"; break; fi
  done <<LIST
$(find "$HOME" -maxdepth 5 \( -path "$HOME/Library" -o -path "$HOME/Pictures" -o -path "$HOME/Music" -o -path "$HOME/Movies" -o -path "$HOME/.Trash" -o -path "$HM/backups" \) -prune -o -type d -name .git -print 2>/dev/null || true)
LIST
fi
if [ -z "$REPO" ]; then
  REPO="$HM/HM64-RNG-Manipulations"
  [ ! -e "$REPO" ] || die "$REPO exists but is not a clone of Nillows/HM64-RNG-Manipulations"
  echo "no clone found: cloning into $REPO"
  git clone https://github.com/Nillows/HM64-RNG-Manipulations.git "$REPO" || die "git clone failed (network?)"
fi
printf '%s\n' "$REPO" > "$TOOLS/repo_path.txt"
cd "$REPO"
BR=$(git symbolic-ref --short HEAD 2>/dev/null) || die "the clone is not on a branch (detached HEAD)"
echo "clone: $REPO (branch $BR)"
ensure_push

say "4/8  Safety checks: no unsaved edits, up to date with GitHub"
DIRTY=$(git status --porcelain | grep -v '\.DS_Store$' || true)
if [ -n "$DIRTY" ]; then
  printf '%s\n' "$DIRTY" > "$BK/uncommitted_files.txt"
  printf '%s\n' "$DIRTY" | sed 's/^...//' | while IFS= read -r f; do
    [ -e "$f" ] && mkdir -p "$BK/uncommitted/$(dirname "$f")" && cp -R "$f" "$BK/uncommitted/$f" || true
  done
  die "the clone has changes that are not committed (listed in $BK/uncommitted_files.txt, copies in $BK/uncommitted). Commit or discard them, then run the same command again."
fi
git fetch -q origin || die "git fetch failed (network or SSH key; details above)"
set -- $(git rev-list --left-right --count "HEAD...origin/$BR")
AHEAD="$1"; BEHIND="$2"
if [ "$AHEAD" -gt 0 ] && [ "$BEHIND" -gt 0 ]; then die "your clone and GitHub have both moved on ($AHEAD local, $BEHIND remote commits): sort that out by hand first"; fi
if [ "$BEHIND" -gt 0 ]; then git merge -q --ff-only "origin/$BR" && echo "pulled $BEHIND commit(s) from GitHub"; else echo "up to date with GitHub"; fi
[ "$AHEAD" -eq 0 ] || echo "note: $AHEAD local commit(s) not yet on GitHub will be pushed too: $(git log --format=%s -n "$AHEAD" | tr '\n' ';')"
SITE_BEFORE=$(git rev-parse "origin/$BR")

say "5/8  Backups (before anything changes) in $BK"
BEFORE=$(git rev-parse HEAD)
TAG="backup/pre-${VER}-${TS}"
git tag "$TAG" "$BEFORE"
echo "git tag $TAG = $BEFORE (your clone before this release)"
mkdir -p "$BK/repo_before"
for f in index.html README.md media $SITEFILES site_files.sha256; do [ -e "$f" ] && cp -R "$f" "$BK/repo_before/" || true; done
echo "copied the site files, README.md, media/ to $BK/repo_before"
mkdir -p "$BK/local_before/webapp" "$BK/local_before/lab"
for f in $SITEFILES site_files.sha256 "HM64_Dog_Oracle_${VER_US}.html" $(printf '%s\n' "$LOCAL" | awk 'NF{print $1}'); do
  if [ -f "$HM/webapp/$f" ]; then cp "$HM/webapp/$f" "$BK/local_before/webapp/"; echo "copied: webapp/$f"; fi
done
if [ -d "$PKG/lab_changes" ]; then
  (cd "$PKG/lab_changes" && find . -type f) | while IFS= read -r f; do
    f=${f#./}
    if [ -f "$HM/$f" ]; then mkdir -p "$BK/local_before/lab/$(dirname "$f")"; cp "$HM/$f" "$BK/local_before/lab/$f"; fi
  done
  echo "copied the lab files that lab_changes/ replaces to $BK/local_before/lab"
fi
if [ -e "$HM/hm64-powernut-lab_${VER}" ]; then cp -R "$HM/hm64-powernut-lab_${VER}" "$BK/local_before/"; echo "copied: hm64-powernut-lab_${VER}/"; fi

if [ "$SITE" = yes ]; then say "6/8  Updating the clone: the site (hub + pages), README.md, media/, devfiles/"; else say "6/8  Updating the clone: index.html, README.md, media/, devfiles/"; fi
if [ "$SITE" = yes ]; then
  for f in $SITEFILES site_files.sha256; do cp "$STAGE/pages/$f" .; done
  ADD="$SITEFILES site_files.sha256"
  WHAT="site ($(printf '%s\n' $SITEFILES | wc -l | tr -d ' ') files)"
else
  cp "$STAGE/pages/index.html" .
  ADD="index.html"
  WHAT="app"
fi
cp "$STAGE/pages/README.md" .
rm -rf media && cp -R "$STAGE/pages/media" media
mkdir -p devfiles
cp "$LAB" "devfiles/$(canon "$LAB")"
cp "$PAGES" "devfiles/$(canon "$PAGES")"
git add $ADD README.md media devfiles
if git diff --cached --quiet; then
  echo "nothing changed: your clone already has $VER_DOT"
else
  git diff --cached --stat | tail -n 15
  git commit -q -m "$VER_DOT: $WHAT + README + media; devfiles: $(canon "$LAB"), $(canon "$PAGES")"
  echo "committed $(git rev-parse --short HEAD)"
fi

say "7/8  Pushing to GitHub"
if [ "$(git rev-list --count "origin/$BR..HEAD")" -gt 0 ]; then
  git push origin "$BR" || die "git push failed. Your clone has the new commit; push again with: cd \"$REPO\" && git push. To drop the commit instead: cd \"$REPO\" && git reset --hard $TAG"
  PUSHED=yes
fi
REMOTE=""
i=0
while [ "$i" -lt "${HM64_VERIFY_TRIES:-6}" ]; do
  REMOTE=$(git ls-remote origin "refs/heads/$BR" 2>"$BK/ls-remote.err" | awk '{print $1}' || true)
  [ -z "$REMOTE" ] || break
  i=$((i + 1))
  echo "reading GitHub's $BR back failed ($(grep -v '^$' "$BK/ls-remote.err" | head -n 1)); try $i of ${HM64_VERIFY_TRIES:-6}, again in ${HM64_VERIFY_WAIT_S:-5} s"
  sleep "${HM64_VERIFY_WAIT_S:-5}"
done
if [ -z "$REMOTE" ]; then
  if [ "$PUSHED" = yes ]; then echo "warning: git reported the push as accepted, but GitHub could not be read back to double-check it. Carrying on; look at the website in a few minutes."
  else echo "warning: GitHub could not be read back now, but the fetch in step 4 showed it equal to your clone. Carrying on."; fi
else
  [ "$REMOTE" = "$(git rev-parse HEAD)" ] || die "GitHub's $BR ($REMOTE) is not your HEAD ($(git rev-parse HEAD))"
  echo "GitHub $BR = $(git rev-parse --short HEAD)"
fi

say "8/8  Installing on this Mac (old copies are in $BK/local_before)"
mkdir -p "$HM/webapp"
if [ "$SITE" = yes ]; then
  for f in $SITEFILES site_files.sha256; do cp "$LABSITE/$f" "$HM/webapp/"; done
  echo "site: $HM/webapp/index.html (the hub) and its pages"
  SRCDIR="$LABSITE"
else
  cp "$APP_NEW" "$HM/webapp/"
  SRCDIR="$PKG"
fi
while read -r dst src; do
  [ -n "$dst" ] || continue
  cp "$SRCDIR/$src" "$HM/webapp/$dst"
  echo "$src -> webapp/$dst (the file you open: your settings, taps and attempts stay with it)"
  [ -n "$MAIN" ] || MAIN="$dst"
done <<LOCALS
$LOCAL
LOCALS
if [ -d "$PKG/lab_changes" ]; then cp -R "$PKG/lab_changes/." "$HM/"; echo "lab: lab_changes/ copied into $HM"; fi
rm -rf "$HM/hm64-powernut-lab_${VER}"
cp -R "$PKG" "$HM/"
echo "package: $HM/hm64-powernut-lab_${VER}"
rm -rf "$STAGE"
OWNER_REPO=$(git remote get-url origin | sed -e 's#\.git$##' -e 's#.*[:/]\([^/:]*\)/\([^/]*\)$#\1/\2#')
PAGES_URL="https://$(printf '%s' "${OWNER_REPO%%/*}" | tr '[:upper:]' '[:lower:]').github.io/${OWNER_REPO#*/}/"
OPEN_URL="${PAGES_URL}?v=${VER}"
LIVE=""
if [ "$SITE" = yes ] && command -v curl >/dev/null 2>&1; then
  WANT=$(shasum -a 256 < "$REPO/site_files.sha256" | awk '{print $1}')
  WAIT=${HM64_PAGES_WAIT_S:-300}; STEP=${HM64_PAGES_STEP_S:-10}; waited=0
  while :; do
    GOT=$( (curl -fsSL --max-time 20 "${PAGES_URL}site_files.sha256?nocache=$(date +%s)" 2>/dev/null || true) | shasum -a 256 | awk '{print $1}')
    if [ "$GOT" = "$WANT" ]; then LIVE=yes; break; fi
    if [ "$waited" -ge "$WAIT" ]; then LIVE=no; break; fi
    [ "$waited" -gt 0 ] || echo "waiting for GitHub Pages to publish $VER_DOT (usually 1-2 minutes, at most $((WAIT / 60)) min)..."
    sleep "$STEP"; waited=$((waited + STEP))
  done
  if [ "$LIVE" = yes ]; then echo "website: GitHub Pages serves $VER_DOT"; else echo "website: GitHub Pages did not show $VER_DOT within $((WAIT / 60)) min; opening it anyway - reload it in a minute"; fi
fi
if [ "$(uname)" = Darwin ]; then open -a Firefox "$OPEN_URL" 2>/dev/null || open "$OPEN_URL" 2>/dev/null || true; fi

cat <<DONE

DONE: $VER_DOT is on GitHub and on this Mac.
  Website, opened in Firefox: $OPEN_URL$( [ "$LIVE" != no ] || printf ' (still publishing: reload it in a minute)' )
  The local copy (updated, not opened): $HM/webapp/${MAIN:-?} - your settings there stay with that file
  Backups and log: $BK
DONE
if [ "$SITE" = yes ]; then printf '  The hub on this Mac: %s/webapp/index.html\n' "$HM"; fi
if [ "$SITE_BEFORE" != "$(git rev-parse HEAD)" ]; then
  printf '  To undo the website (a new commit that brings the old files back; nothing is deleted):\n    cd "%s" && git revert --no-edit %s..HEAD && git push\n' "$REPO" "$SITE_BEFORE"
fi
printf '  Earlier local files (if there were any): %s/local_before\n' "$BK"
if [ "${HM64_RELEASE_NO_LABDATA:-}" = 1 ]; then
  echo "  Lab data: skipped (HM64_RELEASE_NO_LABDATA=1)"
elif [ -f "$TOOLS/hm64_labdata.sh" ]; then
  if ! bash "$TOOLS/hm64_labdata.sh" </dev/null; then
    printf '\nwarning: the lab data was NOT brought up to date on GitHub (see above). The release itself is done. Try again with: bash %s/hm64_release.sh labdata </dev/null\n' "$TOOLS"
  fi
else
  echo "  Lab data: $TOOLS/hm64_labdata.sh is not installed, so the lab-data branch was not updated"
fi
