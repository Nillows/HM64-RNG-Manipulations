HM64 Power Nut Tool v32.21 (2026-11-25): one colour per bite
=============================================================

What you asked for (2026-11-24 23:50)
  "lets revamp the shaded purple colours to just be their own colours, its confusing and a 1 colour group per # of
  held bites to catch has been working fine. after purple do red/orange/blue etc. one colour per cast held through count"

What changed (v32.21 includes v32.7 - v32.20)
  - Every bite has its own colour, everywhere the app colours a Power Nut by its bite:
      bite 1 green  #5fd38d   let go at the 1st bite
      bite 2 gold   #e7c14a   hold the 1st, let go at the 2nd
      bite 3 purple #b48cff   hold 2, let go at the 3rd
      bite 4 red    #d72440   hold 3, let go at the 4th
      bite 5 orange #fc740e   hold 4, let go at the 5th
      bite 6 blue   #3a68e2   hold 5, let go at the 6th (blue also stands for a 7th or later bite)
    The v32.19 shades of purple are gone. Freestyle still writes the bite number on every group of bite 3 and later,
    so a 7 or 8 on a blue group tells the exact bite.
  - Checked with the palette validator on the timeline's dark background: the three new colours stay well apart from
    every other bite colour (at least 17 dE; at least 10.6 dE with red-green colour blindness simulated), and from
    the pink RELEASE line, the blue CAST line and the report's fish bars (at least 15). The closest pair is still
    green / gold, which the bars' heights tell apart.
  - Lucky Timer:
      - Freestyle bars, doubles, threads, release windows and the cast report: the bite's own colour.
      - The legend lists one swatch per bite, up to the latest bite on the line you are on.
      - The lamp names the colour ("NEXT DOUBLE · ORANGE"). "Let go in ..." now says "held through bites 1-4" for a
        5th-bite bar.
      - Freestyle off, dog picked, known-line view off: the "P(Nut) if you cast here" bars are now split by the bite
        their Nut comes on, stacked, with the same total. Before, everything above the green/gold part was purple,
        though some of it was a 1st- or 2nd-bite Nut.
      - The later-bite histogram under the plan and the "hold on" bands after a held bite use the bite's colour too;
        a hold band says which bite the Nut is on.
      - The lamp's purple for KEEP HOLDING / MASH C-RIGHT / WAKE JACK is a cue colour, not a bite: unchanged.
  - Casting tables: the close-up, the thumbnails, the Try-it radios, the run chips (Wide windows, lines) and the
    texts use the rule's own colour; the close-up legend names the rule ("Nut on bite 5 - hold the first 4, let go at
    the 5th").
  - Forest figures: a bite 3+ leaf gets its own bite's colour (rainy L1 shows red and orange leaves now).
    tools/forest_facts.py records the bite of each later leaf; nothing else in forest_facts.json changed.
  - Guide 3.3, Not working, README (section 8 picture, Wide windows picture) say the new colours.

Checks
  - Rainy, no horse (new test tests/ui_bitecolours.js):
      - The split "P(Nut)" bars add up to the old any-bite curve (largest difference 2e-16 over 803 points).
      - The later-bite histogram by bite adds up to its total.
      - Hold bands carry the Nut's bite (3, 3, 5, 4).
      - Bar pixels read back in their bite's colour.
  - Old v32.20 pages against v32.21:
      - Sunny casting tables: identical (dump of 3 sets; close-up, try panel, timings, thumbs, filter, quick cast).
      - Sunny Lucky Timer tests: identical.
      - Rainy Lucky Timer tests: same apart from run-to-run timing noise (checked with a second run of the old page).
      - Rainy casting tables: same numbers; only the close-up legend text changed.
  - Practice release on a stand-in for your Mac: OK.

Release
  bash ~/Documents/hm64/tools/hm64_release.sh v32-21 <lab sha256> <pages sha256> </dev/null
