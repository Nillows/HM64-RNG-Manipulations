HM64 Power Nut Tool v32.22 (2026-11-25): rainy tables that hold from every part of the pier's end
===================================================================================================

What you asked for (2026-11-25 18:43)
  "these were the big late ones i was trying ... the bites never came. i agree with this hypothesis. yes please build
  the corrected rainy pages"

Why the rainy casts missed
  All rainy casts were recorded with Jack at the north end of the pier's end (z 154.8 - 158.4). One step further south
  the camera sits lower; the dog then leaves the screen at other moments, and a dog off the screen draws no random
  numbers. The end of the pier has three camera zones: north (z 154.8 - 158.4), middle (z 164 - 188.4) and south
  (z 194 - 196.1). Inside a zone every spot plays the same.
  The pier-spot run on your Mac (170 min, all gates passed) cast every recorded Nut cast again from z 164.4, 176.4 and
  194.4: the Nut came on the same bite at the same moment in 84.3% (no horse) / 85.5% (horse). Without the horse:
  99 / 97 / 99 / 95% of the casts in the first four 20 s blocks, 59% at 80 - 100 s, 53% after 100 s.

What changed
  - Rainy cast data (webapp/assets/dogcast_rainy-*.json, lucky_routes_rainy-*.json), made by the new
    tools/spot_proof.py from the recorded files and the pier-spot results: a Power Nut bite stays a Nut only if the
    measured casts gave it on the same bite, at the same moment, with the same bites before it, in every zone.
    Every other Nut bite becomes the catch letter f = "fish (a Nut only from the north end of the dock)".
    The 8 / 7 dog lines that only ever stand at the north end keep their casts as recorded.
      no horse: Nut bites 9,605 -> 5,927 kept; 970 lost in a zone; 2,708 not measured
                frames with a Nut on bites 1-6: 16,823 -> 11,444 (68%)
      horse:    Nut bites 7,057 -> 4,823 kept; 726 lost in a zone; 1,508 not measured
                frames with a Nut on bites 1-6: 11,036 ->  8,653 (78%)
  - All rainy pages (Casting tables, Lucky Timer, Dog practice) use the corrected data: odds, wide windows, doubles,
    freestyle bars and dog cards. The sunny pages are the v32.21 pages with the new version label.
  - Guide 3.3, Not working? ("It is raining") and the rainy files' hub notes explain the pier zones.
  - README: the rainy section's lists are the corrected ones.

Known gap, told straight
  - 11 dog lines without the horse (6.9% of the plays) and 8 with it (3.0%) were measured only at their recorded
    spot: the spot lab moves Jack by changing the second cut on the line's recorded beach state, and on those states
    another second cut gives another dog line. Their Nut casts are set aside unless another line shares the cast
    (L9 without the horse has no Nut cast in v32.22; L7 keeps few). The zone run does not cover them either; they
    need their own small run.
  - "Not measured" also holds Nut bites the spot run did not reach. They are set aside, not known to be lost.

Checked
  - spot_proof: the original bite chains are untouched; changed casts are copies; 0 Nuts kept that a zone lost.
  - Casts shared between dog lines at the north end are shared in the other zones too: 2,756 (no horse) and 2,102
    (horse) shared Nut casts compared through the spot run's line hashes at z 164.4 / 176.4 / 194.4, none differs.
  - Sunny pages: identical to v32.21 apart from the version label and the one new catch name.
  - UI tests in headless Chrome on both rainy files (freestyle, cast report, dog cards after the cast, families,
    rain bites, quick casts): they run as on v32.21, with fewer Nut frames. NOT tested: Firefox, a console.

Install: the one release line (the release script unpacks site/, tools/ and lab_changes/ into ~/Documents/hm64).
