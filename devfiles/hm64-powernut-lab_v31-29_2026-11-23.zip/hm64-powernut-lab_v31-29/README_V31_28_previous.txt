HM64 Power Nut tool v31.28 (2026-11-22) - wording fixes and two display fixes

WHAT CHANGED (from v31.27; the cast data, odds, defaults and every calculation are unchanged)
1. Beach-lineup2 tables (both: normal and sparrows at the door), 2nd cut buttons and preset tooltips. The old texts
   came from the dog-beach save, where the sleeping dog blocks part of the pier and the pier window is 7 game frames.
   With the dog on the open beach the window is 11 game frames (22 VIs), checked in the emulator on your
   beach-lineup2 save (D 84 and D 86, also on a sparrow morning):
   - Early:  "down-right in the first 6 frames of the pier window ... near edge of the dock end (z 155-176)"
             (was: the first 2 frames, z 170-176)
   - Middle: "frames 7-8 of the pier window" (was 3-4), z 182-188
   - Late:   "frames 9-11 of the pier window" (was 5-7), z 194-196
   Which runs count as Early / Middle / Late did not change: the tables have always sorted them by where Jack
   stops (z), so the odds are the same. The dog-beach tables keep their own (correct) wording.
2. Preset tooltips no longer say "First step first step ..." (a doubled word in all four lineup tables).
3. L5 "Is the app working?": the sentence "Not verified on hardware: ..." is gone (the method works on console).
   It still says the 1,496 simulated attempts were measured in the lab.

4. Dog-watch summary line ("Not sure yet: L5 +3 17% ..."): a card family's "+3" badge used to show as raw HTML
   (<b style="color:#7fd6ff" title="One dog path: ...">+3</b>) in the text under the cards, in the "LOCKED: ..." /
   "leaning: ..." state and in the DOG LINE LOCKED flash. Now plain text "L5 +3". Found while making the README
   screenshots.
5. L4 attempt report: the report's text lines did not wrap (the attempts table keeps its cells on one line), so long
   lines ran off the panel and needed sideways scrolling. The report row now wraps.

The generator (tools/zigzag_routes.py) carries the same wording, so a rebuild of the tables cannot bring the old
texts back.

TESTED (headless Chrome)
- Items 1-3: the page was compared with v31.27 character by character (only these texts and the version label).
- ui_cal (old defaults stored), ui_fresh27 (fresh browser): no errors; ui_attempts: identical to v31.27 except
  timestamps. A full scripted attempt (dog-watch, pick, tune, freestyle cast, H, report) ran without page errors.

lab_changes/ holds the changed lab sources (now also webapp/HM64_Dog_Oracle_v28_template.html), cumulative since v31.25 (your lab tree): it also carries v31.26's cast
data (dogcast.json to 120 s) and the v31.27 changes.
