HM64 Power Nut Tool v32.15 (2026-11-24): Guide, Not working? and How it works are three pages
==============================================================================================

What you asked for (2026-11-24 16:05)
  "can you seperate the "not working?" and how it works pages so theyre not just one page at different starting point
  down the page"

What changed (v32.15 includes v32.7 - v32.14)
  - guide.html now holds only the setup (your game file), the route and the beach.
  - not-working.html (new, templates/not_working.html): the 10 answers (anchors nw-file ... nw-page, unchanged text), a
    line naming your game file with a link to its setup on the guide.
  - how-it-works.html (new, templates/how_it_works.html): the forest pictures with their captions (unchanged).
  - The three share partials/guide_css.html (the old guide style + the current page marked in the top bar) and
    partials/guide_js.html: the game file comes from ?set=<id> (tool pages), else the hub's ticks, else the first file,
    and every link between the three pages carries it (the guide's picker moves the links along when you switch).
  - Old links still land: guide.html#not-working / #nw-... go on to not-working.html (same ?set= and answer),
    guide.html#how-it-works to how-it-works.html (for pages saved before v32.15 and old READMEs).
  - Links re-pointed: the tool pages' footer "Not working?" and every item of their Not working? list
    (not-working.html?set=<id>#nw-..., plus "All the answers on one page"); the hub's Not working? button (follows the
    ticks) and "How it works, in pictures"; the deck and problem pages' "How it works".
  - site_files order: index, guide, not-working, how-it-works, deck, problem, then the tool pages.
  - Tool pages: only the footer link, the page's link list (HM64_PAGE.notworking) and the site script changed; their
    tables (HM64_DATA) byte-equal to v32.14. Hub, deck, problem: only those links.
  - README: the three help pages; new media/notworking_page.png; guide.png and app_notworking.png retaken.
  - Tests: tests/ui_guide.js now runs on all three pages; ui_notworking (3 page kinds), ui_hub_guide, ui_hub, ui_deck
    pass; the old-link redirects and ?set= checked by loading the pages with those URLs.

Release
  bash ~/Documents/hm64/tools/hm64_release.sh v32-15 <lab sha256> <pages sha256> </dev/null
