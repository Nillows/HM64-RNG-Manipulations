HM64 Power Nut Tool v32.9 (2026-11-24): the pier moment - one future once the sunlight is steady
=================================================================================================

What you asked for (2026-11-24 13:12)
  "flesh out the "sorting branches by shape" section to be possible only when we know the "sunlight level" will stop
  fluctuating. once that happens the shapes solidify into their full causal trajectory ... analyze one branch, which
  has an rng value of x, and dogstate of y, and a sunlight (rng draw of 1) we can understand how the shape couldnt be
  any other way, so they are the same ... then segue that into the tuning example"

What changed (v32.9 includes v32.7 and v32.8)
  - README "The pier moment": sorting by shape needs steady sunlight. Until the dog wakes your inputs set it; from the dog
    waking until the cast nothing Jack does touches the numbers, and standing at the pier each game frame draws exactly
    one number for the game's clock plus the dog's own. Then a branch is (x, y) = the random number's value + the dog's
    state, and (x, y) has one future, so copies are the same branch. Real example (Sunny -> Horse, L1): play A stops at
    x = 569,421,077 (draw 1,253); play B, another route, stops 14 frames later at draw 1,271 - 14 frames before it
    stopped, still walking the pier, it passed through A's exact (x, y). Then the existing counts (280 M plays -> 156
    lines -> 21 shapes), and a segue: your N64 is on one of these branches, maybe a few frames higher or lower. The tuner
    paragraph now refers back to it: the height is the only thing that can still differ.
  - New picture media/forest_6b_one_future.svg (also in the guide): the sunlight strip (set by you -> steady from the dog
    waking -> fishing after the cast), L1 with A's and B's stops, (x, y) and how the next frame follows, the arrow to
    the tuner.
  - Toolkit: forest_facts.py "one_future" (two plays of the heaviest line, their draw counts and x, the line's first dog
    records); forest_svg.py "steady".
  - Page data unchanged (byte-equal to v32.8 apart from the version).

Release
  bash ~/Documents/hm64/tools/hm64_release.sh v32-9 <lab sha256> <pages sha256> </dev/null
  (v32.7 / v32.8 not released yet? skip them: v32.9 has everything)
