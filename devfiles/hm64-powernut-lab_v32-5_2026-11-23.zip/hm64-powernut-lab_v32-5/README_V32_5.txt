HM64 Power Nut Tool v32.5 (2026-11-23): plain-English odds, Try it, Dog practice, Enter picks the top dog
==========================================================================================================

What you asked for
  19:52 "add explanations in plain english peppered throughout the Readme about how the odds were calculated ... how
        weights were determined could be its own whole section the rest of the readme refers too ... also add such
        explanations in the charts of the app as well. and maybe an embedded test window for them to play with? ...
        a little test area in the readme that is interactive and lets the player try the mechanic in a controlled
        environment using lines they could get based on our data."
        (Your answers: all three drills - tune, read, whole attempt; the chart test window = change the inputs.)
  19:58 "make sure the practice activities take preferences from the players specific keyboard layout ... adding
        enter as a key to autoselect the most likely dog without clicking it ... and then of course that gets to
        tuning after."
  20:00 "why is the candle autofill to 100% when you click it?"

What changed
  README (GitHub)
    - New section "How the odds are worked out": one generator acted out by the dog; the lab's ~31,000 plays of the
      route and the weights (every choice in its window alike; an arrival = a dog line at a timing; weight = its share
      of the plays; the pachinko picture; 84 lines, top 14%, 6 hold half, 19 hold 90%); every cast frame a known yes/no
      (~89,000 casts); a bar = a weighted share; your press as a bell curve or a flat window; watching the dog = ruling
      arrivals out (Bayes: x0.02 a wrong key, x0.1 an unkeyed turn); a known dog leaves only your hands (29% / 47%).
    - New section "Dog practice: try it without a console" (a README cannot run scripts, so the test area is a page
      of the site, linked from the README and the hub, with two screenshots).
    - One-line notes through the rest (intro, Optimal Blind Casting, sparrows, the histogram bars, presets, dog cards,
      freestyle 29% / 47%, the casting tables' spread setting), the clicked-candle explanation, Try it (+ screenshot),
      Enter in sections 6 and 11. New media: app_try.png, practice_whole.png, practice_read.png; app_blind_candle.png
      redone (it shows the new label).
  Dog practice (new page per game file: dog-practice_<file>.html, 5.5 / 6.4 MB; linked from the hub and every page)
    - 1 Tune the dog: the TV plays a real arrival (drawn by weight, or the line you pick) at its true timing; its card
      plays at the tool's guess (your tap off by up to +-150 ms, the line's usual timing); [ ] until in step, Enter.
      Scored in game frames, with the line's next 6 Nut casts pressed dead on the middle at your tuning (hit / miss).
      TV speed 1x / 1/2x / 1/4x.
    - 2 Read the dog: your dog-watch keys; the cards re-weight with HM64DogWatch.likelihood (the Lucky Timer's matcher),
      sister lines folded as on the Lucky Timer; Enter = the top card, a click = any card. Right = your line or a sister
      line already joined.
    - 3 Whole attempt: start key when Jack stops (your stored start delay taken off), read, Enter, tune, Enter; the
      picked dog's Nut frames scroll under the TV (green / gold, NEXT DOUBLE countdown); hold the start key to cast (it
      stands in for B, as the Lucky Timer's hold mode reads it) and let go at the bite (20-VI window). The catch = the
      lab's record of the exact cast frame of the TRUE arrival (pack F / S / N / X / O).
    - Keys = the Lucky Timer's stored settings (hm64v29_lucky: dwKeys, dwAnimKeys, dwAdjKeys, startKey, dwCards, dwFill,
      start delay); changeable on the page for a saved local copy (hm64v32_practice.keys, "use my Lucky Timer keys"
      resets). Matched by KeyboardEvent.code like the Lucky Timer; labels follow the layout (navigator.keyboard where the
      browser has it, else what each key typed on this site: hm64v32_keylabels).
    - Data: dog traces + arrivals ('all' preset, pier start) + the cast pack without the dog after the cast + sprites,
      Jack's frames, the READY screenshot. Results: last 300 per drill in hm64v32_practice_stats.
  Lucky Timer
    - Enter with no dog chosen (dog-watch, before the cast) = the top card is chosen, as a click; Enter again = timing
      set (as before); Backspace undoes the choice. Lamp: TOP DOG L1 . [ ] TUNE . ENTER WHEN IN STEP. Key hints, the
      card tooltip, Settings' reserved-key list and How it works say so.
    - Under the histogram: "i What the bars mean, and where the odds come from" (folded): the explanation for the mode
      it is in right now (the app's odds / freestyle without a dog / freestyle with your dog) + what a dog card's % is.
    - How it works: "How the odds are worked out" (also on the other two pages).
  Casting tables
    - Close-up: "Try it: change the inputs" - your press (anywhere in a window of 1-60 frames, or aimed with a spread
      0-300 ms), where you press, which bite you let go at, which dog lines count (all / none / only those with a Nut
      where I press). Candles, strips, the line list and the odds follow live; a line says how the number is made.
      With the row's own inputs it gives the row's odds exactly.
    - A clicked candle (filtered view) is labelled "your pick reads 100% by definition: it held x% of the row, and only
      those arrivals are kept"; the text under the chart says it too.
    - Optimal Blind Casting: a fold "i How these odds are worked out"; header tooltips; the other three tabs a one-line
      note on what "how often" and a cast's % are (with the page's spread).

Checks (sandbox, headless Chrome, both sunny pages)
  - Casting numbers unchanged (HM64DogRef.shown checksum 2311396371 / 1548110645, as since v32.1); thumbnails, timings
    (gap <= 1.3e-7), close-up (steady box: one width through every action), filter (clicked candle certain) as before.
  - Try it (tests/ui_trypanel.js): row inputs = row odds on all 11 / 13 charts (gap <= 1.8e-8); one line = its own
    fractions exactly; aimed = an independent bell-curve sum (gap <= 1.8e-8); the dialog keeps one width.
  - Dog practice (tests/ui_practice_drills.js): tune put in step -> 0 frames (12 of 12), 3 frames off -> 3 and every
    single missed; [ ] / Shift move 2 / 20 VIs; read with keys simulated from the true dog -> scored right exactly
    when the true line is on top; whole attempt (tap, pick, tune, cast on a Nut frame, let go at the Nut bite) -> the
    Power Nut 8 of 8, on bite 1 or 2. tests/ui_practice_keys.js (seed tests/pre_practice_keys.js): W A S D, , . , J,
    start key q, 3 cards, 180 ms are used; AZERTY labels Z Q S D; a facing key refused as a tuning key; a page key
    saved and given back; help.
  - Lucky Timer (tests/ui_enterpick.js): Enter -> the top card chosen, calibration view; ] ] -> +4 VIs; Enter -> timing
    set; Backspace -> undone; Enter -> top again; Enter outside an attempt untouched. ui_pierstart, ui_pierx, ui_fresh27,
    ui_site_defaults (both sets) no errors. ui_pickfirst / ui_dogmanual / ui_carousel (made for the fade-in start; run
    with it): the same results as v32.4 except, as intended, Enter after un-picking now picks the top dog.
    ui_pickfirst, ui_pickquiet, ui_dogmanual, ui_carousel fail on v32.4 too with the pier start (they assume the old
    fade-in default): not new.

Files (lab_changes/, cumulative)
  webapp/hm64_practice_v32.js (new), webapp/site/templates/practice.html (new), webapp/hm64_dogref_v31.js (Try it, the
  candle label, the notes), webapp/hm64_lucky_v29.js (Enter), webapp/hm64_app_v28.js (help: Enter), webapp/hm64_site_v32.js
  (the explanations, practice help), webapp/site/site.json (v32.5, practice per set), webapp/site/templates/{hub,
  lucky_timer,casting_tables}.html (links), webapp/site/partials/site_css.html (link colour), tools/site_build.py (page
  kind "practice", practice_data()), tests/ui_trypanel.js, ui_practice_drills.js, ui_practice_keys.js,
  pre_practice_keys.js, ui_enterpick.js

Release
  bash ~/Documents/hm64/tools/hm64_release.sh v32-5 <lab sha256> <pages sha256> </dev/null
  (It includes v32.2 - v32.4; the site now has three pages per game file; the release script copies every file its
  site_files.sha256 lists, nothing else to do. It does not touch the rain run.)
