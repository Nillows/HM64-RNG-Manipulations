HM64 Power Nut Tool v32.4 (2026-11-23) — clicking a candle filters, like freestyle
====================================================================================

What you asked for (19:17)
  "can you make the reverse behaviour the default of clicking into a candle, like instead of the dog line name dimming
  i was expecting the candles to dissapear like they do in freestyle when we know the dog line. the way youve done it
  is great too, but can you put a checkbox to showcase the way youve laid it out too? i like both"

What changed (Casting tables, the window close-up)
  - Click a candle (default): the chart keeps only the arrivals that make up that candle - each dog line at each of
    its timings that has a Nut in that frame - and shows where else THEIR Nut frames are, as the share of those
    arrivals. The clicked candle goes to 100%, its neighbours show the double / triple it sits in, and every candle
    those arrivals cannot reach disappears (30-60 of the 150 frames on the rows tried). The odds line shows the window
    on those arrivals; the line strips show each lit line's matching timings only; the other lines go blank.
    (Grouping by arrival, not by whole dog line: a line with many timings has a Nut in nearly every frame of the
    window, so a by-line filter would remove almost nothing. An arrival = a line at one timing = what freestyle knows
    once the dog is tuned.)
  - Click a line: the chart shows only that line (all its timings); click one of its timings: only its exact Nut
    frames, each 0 or 100%.
  - New checkbox in the close-up, "keep every candle when I click (dim the other lines)": the v32.3 view (every
    candle stays, the lines without a Nut there dim; a clicked line's part drawn white). Off by default; remembered
    with the page's other settings (hm64v31_dogref.keepAll).

Checks (sandbox, headless Chrome, both sunny pages)
  - Filtered candle: the clicked candle is certain (bite 1 + bite 2 share >= 100% of the group), candles outside the
    group's reach are empty (wiggle-bum: 60 of 150 gone, group 38% of the row, window 29.5% on it; not watching: 30
    gone, group 15%, window 19.3%; run: 40 gone).
  - Filtered line = the line's own drawn fractions exactly; a timing = 0 / 100% frames only.
  - Box ticked: the chart equals the row's histogram (v32.3 behaviour), stored in the settings.
  - Unchanged: the casting tables' numbers (same checksum as v32.1-v32.3), thumbnails (window mean = odds), timings
    (sum = drawn fractions, gap <= 1.3e-7), the dialog box stays put through hovering and clicking.

Files (lab_changes/, cumulative)
  webapp/hm64_dogref_v31.js   paintBig's filtered view, marksAll(), the checkbox; webapp/site/site.json v32.4
  tests/ui_filter.js          the checks above

Release
  bash ~/Documents/hm64/tools/hm64_release.sh v32-4 <lab sha256> <pages sha256> </dev/null
