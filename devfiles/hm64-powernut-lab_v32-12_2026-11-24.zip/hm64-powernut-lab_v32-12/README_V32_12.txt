HM64 Power Nut Tool v32.12 (2026-11-24): "The problem it solves" is its own page
================================================================================

What you asked for (2026-11-24 15:27)
  "i was expecting the problem it solves section to be its own html, and then just have links to it from the hub to
  keep it focused on the tool. this is just a small offset feature for a link on the hub, and an enhancement to an
  explainer on the readme."

What changed (v32.12 includes v32.7 - v32.11)
  - problem.html (new site page): the explainer (top-decking one card), the picture media/problem_deck.svg, buttons to
    the deck page and the hub, a link to How it works.
  - Hub: the big "The problem it solves" box is gone; one small line under the intro: "What problem does this solve?"
    (problem.html) · "Try it with a deck of cards" (deck.html). The hub is back to the tool.
  - deck.html and guide.html link "The problem" in their top links.
  - README: the section stays (the explainer), now also pointing to problem.html; hub picture and caption updated.
  - Page data unchanged (byte-equal to v32.11 apart from the version).

Release
  bash ~/Documents/hm64/tools/hm64_release.sh v32-12 <lab sha256> <pages sha256> </dev/null
