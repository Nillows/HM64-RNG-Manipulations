/* headless (v32.23): the pier zones of a rainy page. Runs on the Lucky Timer, the Casting tables and the Dog practice
   page of a set whose cast pack has zone tables.
   Lucky Timer: every 2nd-cut preset plans on its own zone's series, and that series says what the zone's pack table
   says for every cast frame of the route table (bite 1, bite 2, later bites: 0 mismatches wanted); the cards of the
   L1 presets switch the zone; the pack answers for the zone in use; the number of Nut frames per zone equals the
   build report; a line not measured in a zone gets its "not proven here" mark and shows no Nut there.
   Casting tables: the picker switches the tables (other arrivals, other odds), back to "Not sure" = the first tables.
   Dog practice: the picker switches arrivals and flags. */
(function () {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => {
    const $ = id => document.getElementById(id), out = { errors: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    try {
      const PG = HM64_PAGE, D = HM64_DATA, Z = window.HM64Zone, P = D.dogcast || D.pack;
      out.page = { kind: PG.kind, set: PG.set, zones: !!PG.zones, has: !!(Z && Z.has), cur0: Z && Z.cur };
      const chain = cid => { const o = []; let t = P.F[cid], s = P.S[cid]; while (s >= 0 && o.length < 40) { o.push([t, P.O[s]]); if (P.N[s] < 0) break; t += P.N[s]; s = P.X[s]; } return o; };
      const nutFrames = z => { let n = 0; for (const k in P.lines) { const ix = P.lines[k].idxOf(z); for (const c of ix) if (c >= 0 && P.S[c] >= 0 && chain(c).slice(0, 6).some(b => b[1] === 'N')) n++; } return n; };
      if (PG.kind === 'lucky') {
        const A = window.HM64LuckyApp, C = window.HM64Lucky;
        localStorage.clear(); if ($('arLucky')) $('arLucky').click(); A.L.audio = false;
        const rid = C.selection.route, R = C.routeOf(rid);
        out.route = { id: rid, axes: R.axes.map(a => a.id + ':' + a.opts.map(o => o.id).join('/')), groups: R.groups.length, pace0: C.selection.pace, zone0: Z.cur };
        out.series = {}; out.nut = {};
        for (const z of ['all', 'north', 'middle', 'south']) {
          const gid = z === 'all' ? 'all' : 'cut2-' + z, plan = C.planSet(gid, 'pier', rid)[0];
          let frames = 0, bad = 0, n1 = 0, n2 = 0, nx = 0;
          R.lines.forEach((c, li) => {
            const s = plan.series[R.sidxs[li]], ln = P.lines[R.line_info[li].key], ix = ln.idxOf(z);
            for (let i = 0; i < s.len; i++) {
              if (s.n1[i] < 0) continue;
              const j = (s.v0 + i - 1 - ln.k0) / 2, ch = chain(ix[j]); frames++;
              let ok = ch.length > 0 && s.b1[i] === ch[0][0] && s.n1[i] === (ch[0][1] === 'N' ? 1 : 0);
              if (ch.length > 1) ok = ok && s.b2[i] === ch[1][0] && s.n2[i] === (ch[1][1] === 'N' ? 1 : 0); else ok = ok && s.n2[i] < 0;
              const bx = s.bx && s.bx[i];
              if (bx) for (let q = 0; q < bx.length; q++) { const e = ch[q + 2]; if (!e || Math.abs(bx[q]) !== e[0] || (bx[q] < 0) !== (e[1] === 'N')) ok = false; if (bx[q] < 0) nx++; }
              if (!ok) bad++;
              n1 += s.n1[i] === 1; n2 += s.n2[i] === 1;
            }
          });
          const b = C.best(plan, 9, 30);
          out.series[z] = { zone: plan.zone, frames, mismatches: bad, nut1: n1, nut2: n2, nutLater: nx, variants: plan.variants.length, best: ['zone', 'bite1', 'hold'].map(q => q + ' ' + (100 * b[q].p).toFixed(2) + '% @' + ((b[q].t - 1) * 16.715 / 1000).toFixed(1) + 's').join(' | ') };
          out.nut[z] = nutFrames(z);
        }
        const rp = Z.report, never = (rp.middle && rp.middle.frames_nut_1_6_lines_never_here) || 0;
        out.nutReport = { all: rp.all.frames_nut_1_6, north: rp.north.frames_nut_1_6, middle: rp.middle.frames_nut_1_6 + never, south: rp.south.frames_nut_1_6 + never };
        out.nutEqualsReport = ['all', 'north', 'middle', 'south'].every(z => out.nut[z] === out.nutReport[z]);
        // v32.23: which Nut frames hold wherever Jack stops (solid bars) and which only in the zone in use (striped)
        out.bars = {};
        for (const z of ['all', 'north', 'middle', 'south']) {
          let solid = 0, striped = 0;
          for (const k in P.lines) { const ln = P.lines[k], ix = ln.idxOf(z); ix.forEach((c, j) => { if (c < 0 || P.S[c] < 0) return; const n = chain(c).findIndex(b => b[1] === 'N') + 1; if (n > 0 && n <= 6) { if (Z.everywhere(k, ln.k0 + 2 * j, n)) solid++; else striped++; } }); }
          out.bars[z] = { solid, striped };
        }
        // the L1 cards
        const cardsTxt = () => [...$('lkPace').querySelectorAll('.lkcard')].map(e => e.textContent.replace(/\s+/g, ' ').trim().slice(0, 40));
        const click = async label => { const el = [...$('lkPace').querySelectorAll('.lkcard')].find(e => e.textContent.trim().startsWith(label)); if (!el) throw new Error('no card ' + label); el.click(); await sleep(120); };
        A.refresh(); await sleep(200);
        out.ui = { cards0: cardsTxt(), steps: [] };
        const snap = what => out.ui.steps.push({ what, pace: C.selection.pace, zone: Z.cur, cast: $('lkT').textContent, p: $('lkP').textContent, table: (($('lkPaceTxt').textContent.match(/Table in use — [^:]*/) || [''])[0]) });
        snap('start');
        await click('Middle'); snap('Middle');
        out.ui.cardsMiddle = cardsTxt();
        await click('Clean'); snap('Middle + Clean');
        await click('South'); snap('South (wait kept)');
        await click('North'); snap('North');
        out.ui.stored = JSON.parse(localStorage.getItem('hm64v29_lucky') || '{}').routePace;
        // the pack follows: a frame that differs between the zones
        const key0 = Object.keys(Z.report && D.dogcast.zones.d.middle)[0], d0 = D.dogcast.zones.d.middle[key0];
        out.pack = { key: key0.slice(0, 8), frame: d0[0], north: P.lines[key0].idx[d0[0]] };
        await click('Middle'); out.pack.middle = P.lines[key0].idx[d0[0]]; out.pack.middleWant = d0[1];
        // a line not measured here
        const unp = D.dogcast.zones.unproven.middle || [];
        out.unproven = { middle: unp.length, north: (D.dogcast.zones.unproven.north || []).length, all: (D.dogcast.zones.unproven.all || []).length };
        if (unp.length) {
          const k = unp[0], dwi = R.dw.lines.findIndex(l => l.key === k);
          out.unproven.badgeMiddle = /not proven here/.test(Z.badge(k)); out.unproven.nutsMiddle = P.lines[k].idx.filter(c => c >= 0 && P.S[c] >= 0 && chain(c).some(b => b[1] === 'N')).length;
          out.unproven.clusters = A.fsClusters(R, dwi).length;
          await click('North');
          out.unproven.badgeNorth = /not proven here/.test(Z.badge(k)); out.unproven.nutsNorth = P.lines[k].idx.filter(c => c >= 0 && P.S[c] >= 0 && chain(c).some(b => b[1] === 'N')).length;
          out.unproven.clustersNorth = A.fsClusters(R, dwi).length;
        }
        // an attempt on the middle table: Space at the pier end, the cards come, no errors
        await click('Middle');
        if ($('lkDwOn') && !$('lkDwOn').checked) { $('lkDwOn').checked = true; $('lkDwOn').onchange({ target: $('lkDwOn') }); }
        const ev = (type, o) => document.dispatchEvent(new KeyboardEvent(type, Object.assign({ code: 'Space', key: ' ', bubbles: true, cancelable: true }, o || {})));
        ev('keydown'); ev('keyup'); await sleep(500); if (A.run.wall0 !== null) A.frameOnce(); await sleep(1500); if (A.run.wall0 !== null) A.frameOnce();
        out.attempt = { running: A.run.wall0 !== null, planZone: A.run.plan && A.run.plan.zone, cards: $('lkCompCards').querySelectorAll('.lkdog').length, castS: A.run.T ? +((A.run.T - 1) * 16.715 / 1000).toFixed(2) : null };
        ev('keydown', { code: 'Escape', key: 'Escape' });
      }
      if (PG.kind === 'casting') {
        const Rf = window.HM64DogRef;
        const done = () => Rf && Rf.shown && Rf.shown.all && Rf.shown.zone === Z.cur && !/working out/.test($('rfBody').textContent);
        const wait = async () => { for (let i = 0; i < 3000 && !done(); i++) await sleep(50); };
        const snap = () => { const o = Rf.shown; return { zone: o.zone, done: done(), rows: document.querySelectorAll('#rfBody tr').length, lines: o.lines.length, all: o.all && o.all.best ? null : null,
          first: (document.querySelector('#rfBody tbody tr') || { textContent: '' }).textContent.replace(/\s+/g, ' ').trim().slice(0, 110), note: ($('rfBody').querySelector('.rfnote') || { textContent: '' }).textContent.replace(/\s+/g, ' ').slice(0, 150),
          notProven: (document.querySelector('#rfBody').textContent.match(/not proven here/g) || []).length }; };
        await wait(); out.picker = !!$('pzBox'); out.buttons = [...document.querySelectorAll('#pzBox button')].map(b => b.textContent);
        out.t = {}; out.t.start = snap();
        for (const z of ['south', 'north', 'all', 'middle']) {
          document.querySelector(`#pzBox button[data-z="${z}"]`).click(); await sleep(100); await wait();
          out.t[z] = snap();
        }
        out.backEqual = JSON.stringify(out.t.start) === JSON.stringify(out.t.middle);
        out.note = $('pzBox').querySelector('.pznote').textContent.slice(0, 160);
        out.stored = localStorage.getItem('hm64v32_pierzone');
        out.nut = { all: nutFrames('all'), north: nutFrames('north'), middle: nutFrames('middle'), south: nutFrames('south') };
      }
      if (PG.kind === 'practice') {
        await sleep(300);
        const Pr = window.HM64Practice;
        const snap = () => { const R = Pr.route(), p = Pr.prep(R); let nut = 0; for (const l of p.lines.slice(0, 20)) { const f = Pr.flags(R.dw.lines[l.dwi].key); if (f) for (let i = 0; i < f.b1.length; i++) nut += f.b1[i] + f.b2[i]; }
          return { zone: Z.cur, arrivals: p.cands.length, lines: p.lines.length, top: p.lines.slice(0, 3).map(l => Pr.lineName(R, l.dwi) + ' ' + (100 * l.p).toFixed(1) + '%'), nut12top20: nut, options: $('prLine').options.length }; };
        out.picker = !!$('pzBox'); out.t = {}; out.t.start = snap();
        for (const z of ['south', 'north', 'all', 'middle']) { document.querySelector(`#pzBox button[data-z="${z}"]`).click(); await sleep(150); out.t[z] = snap(); }
        out.backEqual = JSON.stringify(out.t.start) === JSON.stringify(out.t.middle);
        Pr.newDrill('tune'); await sleep(300); out.drill = { started: !!Pr.S, kind: Pr.S && Pr.S.kind };
      }
    } catch (e) { out.errors.push('test: ' + e.message + ' ' + (e.stack || '').split('\n').slice(1, 3).join(' | ')); }
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out, null, 1); document.body.appendChild(pre);
  }, 600);
})();
