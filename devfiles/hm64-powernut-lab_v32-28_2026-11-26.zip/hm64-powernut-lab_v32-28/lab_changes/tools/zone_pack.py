"""Rainy cast pack + route table for ONE camera zone of the dock end, or for "everywhere" (2026-11-26).

  python3 -I tools/zone_pack.py --pack ORIG_PACK --routes ORIG_ROUTES --zz zz_lines.json --spots SP2_casts.jsonl
          --zones SP3_zones.jsonl --zone middle|south|all --pack-out P --routes-out R [--report J]

Input = the RECORDED (north) pack and routes. A recorded Power Nut bite of a cast frame stays 'N' in a zone when
  - the zone's measurement of that cast (spot run or zone run) gives the same bites up to and including it, or
  - the cast was not measured there, its line was, it is not near a tile the zone treats differently (those were
    all measured; the check samples of the zone run came out as recorded on 3,352 of 3,352) AND the Nut bite lies
    within the cast's recorded row (the prediction and the check cover the recorded row, not bites known by chaining).
It becomes 'f' ("fish here; a Nut only elsewhere / not proven here") when the measurement differs, when the measured
part ends before that bite, when the line was not measured in the zone, or when the cast frame comes before Jack can
stand there. Lines that never stand in the zone are left as recorded (they cannot occur there).
--zone all = a Nut only where it stays in the middle AND the south zone (a cast frame impossible in a zone does not
count against it). NOT added: Nuts that exist only in a zone (new, or on another bite): they need bite chains built
from the measurements (tools/dogcast_pack.py on the zone rows) - still to do."""
import argparse, json, collections
ap = argparse.ArgumentParser()
for a in ("pack", "routes", "zz", "spots", "zones", "zone", "pack-out", "routes-out"): ap.add_argument("--" + a, required=True)
ap.add_argument("--report"); ap.add_argument("--rows", nargs="+", required=True, help="the recorded FD_casts_b*.jsonl files")
A = ap.parse_args()
pack = json.load(open(A.pack)); routes = json.load(open(A.routes)); zz = json.load(open(A.zz))
assert "f" not in pack["O"] and "n" not in pack["O"], "the input must be the recorded pack"
F, S, N, X = pack["F"], pack["S"], pack["N"], pack["X"]; O = list(pack["O"]); lines = pack["lines"]
STATE = [a for a in ("R", "N", "X", "L", "T") if a in pack]; CAST = [a for a in ("P", "F", "S", "E") if a in pack]
def chain(c, limit=40):
    out, t, st = [], F[c], S[c]
    while st is not None and st >= 0 and len(out) < limit:
        out.append((t, O[st], st))
        if N[st] is None or N[st] < 0: break
        t += N[st]; st = X[st]
    return out
ZN = {"z164.4": "middle", "z176.4": "middle", "z194.4": "south", "middle": "middle", "south": "south"}
meas = {"middle": {}, "south": {}}; imposs = {"middle": set(), "south": set()}; seen = {"middle": set(), "south": set()}
for p in (A.spots, A.zones):
    for ln in open(p):
        r = json.loads(ln); z = ZN.get(r.get("_job", {}).get("zone") or r.get("_job", {}).get("spot"))
        if not z or r.get("ok", True) is False or r.get("key") not in lines: continue
        L = lines[r["key"]]; seen[z].add(r["key"])
        for c in r.get("casts", []):
            j, rem = divmod(c["k"] - L["k0"], 2)
            if rem or j < 0 or j >= len(L["idx"]) or L["idx"][j] is None or L["idx"][j] < 0: continue
            meas[z].setdefault(L["idx"][j], []).append([(b[0] - c["k"], b[1]) for b in c["b"]])
        for k in r.get("skipped", []):
            j, rem = divmod(k - L["k0"], 2)
            if not rem and 0 <= j < len(L["idx"]): imposs[z].add((r["key"], j))
rowlen = {}                                # cast id -> bites in its longest recorded row (the part the zone run's check covers)
for p in A.rows:
    for ln in open(p):
        try: r = json.loads(ln)
        except ValueError: continue
        if r.get("key") not in lines: continue
        L = lines[r["key"]]
        for c in r.get("casts", []):
            j, rem = divmod(c["k"] - L["k0"], 2)
            if rem or j < 0 or j >= len(L["idx"]) or L["idx"][j] is None or L["idx"][j] < 0: continue
            rowlen[L["idx"][j]] = max(rowlen.get(L["idx"][j], 0), len(c.get("b") or []))
def zs(key): return {m["spot"][1] for m in zz[key]["members"] if "spot" in m} | {zz[key]["rep"]["spot"][1]}
RANGE = {"middle": (161, 191), "south": (191, 999)}
stands = {z: {k for k in lines if k in zz and any(lo <= s < hi for s in zs(k))} for z, (lo, hi) in RANGE.items()}
rep = collections.Counter()
def flags_in(z, key, j, cid, ch, nuts, strict):
    """bite indexes of this frame's recorded Nuts that are NOT a Nut in zone z"""
    if key not in stands[z]: return set()
    if (key, j) in imposs[z]: return set(nuts) if strict else set()
    m = meas[z].get(cid)
    if m is None: return {i for i in nuts if i >= rowlen.get(cid, 0)} if key in seen[z] else set(nuts)
    out = set()
    for i in nuts:
        want = [(t, o) for t, o, _ in ch[:i + 1]]
        if any(len(g) <= i or g[:i + 1] != want for g in m): out.add(i)
    return out
clone = {}
def clone_of(cid, fl, ch):
    k = (cid, fl)
    if k in clone: return clone[k]
    last = max(fl); ids = []
    for i in range(last + 1):
        st = ch[i][2]; nid = len(O)
        for a in STATE: pack[a].append(pack[a][st])
        O.append("f" if i in fl else O[st]); ids.append(nid)
    for i in range(last): X[ids[i]] = ids[i + 1]
    nc = len(S)
    for a in CAST: pack[a].append(pack[a][cid])
    S[nc] = ids[0]; clone[k] = nc; rep["casts_added"] += 1; rep["states_added"] += len(ids)
    return nc
FL = {}                                   # (key, j) -> flagged bite indexes
for key, L in lines.items():
    for j, cid in enumerate(L["idx"]):
        if cid is None or cid < 0 or S[cid] is None or S[cid] < 0: continue
        ch = chain(cid); nuts = [i for i, (_, o, _) in enumerate(ch) if o == "N"]
        if not nuts: continue
        rep["frames_with_a_recorded_nut"] += 1; rep["nut_bites"] += len(nuts)
        if A.zone == "all": fl = flags_in("middle", key, j, cid, ch, nuts, False) | flags_in("south", key, j, cid, ch, nuts, False)
        else: fl = flags_in(A.zone, key, j, cid, ch, nuts, True)
        rep["nut_bites_kept"] += len(nuts) - len(fl)
        if any(i < 6 for i in nuts): rep["frames_nut_on_bites_1_6"] += 1; rep["frames_nut_on_bites_1_6_kept"] += any(i < 6 and i not in fl for i in nuts)
        if fl:
            FL[(key, j)] = fl; L["idx"][j] = clone_of(cid, frozenset(fl), ch); rep["frames_repointed"] += 1
pack["O"] = "".join(O)
pack["zone_pack"] = {"v": 1, "by": "tools/zone_pack.py", "zone": A.zone, "f": "fish here; a Power Nut only elsewhere or not proven here", **rep}
for route in routes["routes"]:
    info = route.get("line_info") or []; t1 = t2 = 0
    for li, ln in enumerate(route.get("lines") or []):
        key = info[li]["key"]
        if "n1" not in ln: continue
        n1 = ln["n1"].split("."); n2 = ln["n2"].split(".") if "n2" in ln else None; d1 = d2 = 0
        for i in range(len(n1)):
            f = FL.get((key, i), ())
            if n1[i] != "0" and 0 in f: n1[i] = "0"; d1 += 1
            if n2 is not None and i < len(n2) and n2[i] != "0" and 1 in f: n2[i] = "0"; d2 += 1
        ln["n1"] = ".".join(n1)
        if n2 is not None: ln["n2"] = ".".join(n2)
        if "wins1" in ln: ln["wins1"] -= d1
        if "wins2" in ln: ln["wins2"] -= d2
        if "nut1" in info[li]: info[li]["nut1"] -= d1
        if "nut2" in info[li]: info[li]["nut2"] -= d2
        t1 += d1; t2 += d2
    src = route.get("source")
    if isinstance(src, dict) and "nut1" in src:
        src["nut1"] -= t1; src["nut2"] -= t2; src["zone_pack"] = "Nut flags for the camera zone '%s' of the dock end (tools/zone_pack.py)" % A.zone
    rep["n1_cleared"] += t1; rep["n2_cleared"] += t2
json.dump(pack, open(getattr(A, "pack_out"), "w"), separators=(",", ":")); json.dump(routes, open(getattr(A, "routes_out"), "w"), separators=(",", ":"))
if A.report: json.dump(rep, open(A.report, "w"), indent=1)
print(A.zone, json.dumps(rep))
