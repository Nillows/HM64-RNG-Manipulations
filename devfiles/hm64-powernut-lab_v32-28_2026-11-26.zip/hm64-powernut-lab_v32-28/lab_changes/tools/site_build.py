"""HM64 site generator (v32.0, Thomas 2026-11-23): the hub index.html + one single-file page per game-file
circumstance and page kind, all from the templates in webapp/site/.

  python3 -I tools/site_build.py DATA.json --out DIR [--site webapp/site/site.json]

DATA.json = an app data export (as webapp_rebuild.py takes it); the Lucky Timer route tables (webapp/assets/
lucky_routes.json) and the cast pack (webapp/assets/dogcast.json) are loaded on top, exactly as webapp_rebuild.py does.

Layout (Thomas): index.html is a bare hub sorted by weather (sunny / rainy) and then by circumstance (horse / no
horse, later marriage, baby ...). Every working page is ONE self-contained HTML file (download it and it works
offline) holding only its own circumstance's tables. Page kinds today:
  lucky    the Lucky Timer                      lucky-timer_<set>.html
  casting  the casting tables (Dog reference)   casting-tables_<set>.html
  practice Dog practice (v32.5): drills on real dog lines (tune / read / a whole attempt)   dog-practice_<set>.html

Templates use a small Handlebars subset (no dependencies, output stays plain HTML):
  {{x.y}}  HTML-escaped value      {{{x}}}  raw value (scripts, data)       {{> name}}  partials/name.html
  {{#each list}} ... {{else}} ... {{/each}}   (inside: {{this}}, {{@index}}, {{@first}}, {{@last}}, outer names)
  {{#if x}} ... {{else}} ... {{/if}}    {{#unless x}} ... {{/unless}}    {{!-- comment --}}
A name that does not resolve is an error (a typo never ships as an empty string); {{#if}} on a missing name is false.
"""
import argparse
import datetime as dt
import hashlib
import html
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT / "webapp"
SITE = WEB / "site"


# ------------------------------------------------------------------------------------------------ template engine
class TemplateError(Exception):
    pass


TOKEN = re.compile(r"\{\{!--.*?--\}\}|\{\{\{\s*([^}]*?)\s*\}\}\}|\{\{(.*?)\}\}", re.S)


def parse(text, name):
    """-> list of nodes: str | ('var', path, raw) | ('partial', name) | ('block', kind, arg, body, else_body)"""
    root = []
    stack = [("root", None, root, None)]          # (kind, arg, current list, else list or None)
    pos = 0
    for m in TOKEN.finditer(text):
        if m.start() > pos:
            stack[-1][2].append(text[pos:m.start()])
        pos = m.end()
        tok = m.group(0)
        if tok.startswith("{{!--"):
            continue
        if m.group(1) is not None:                                   # {{{raw}}}
            stack[-1][2].append(("var", m.group(1).strip(), True))
            continue
        t = m.group(2).strip()
        if not t or t.startswith("!"):
            continue
        if t.startswith(">"):
            stack[-1][2].append(("partial", t[1:].strip()))
        elif t.startswith("#"):
            kind, _, arg = t[1:].partition(" ")
            if kind not in ("each", "if", "unless"):
                raise TemplateError(f"{name}: unknown block #{kind}")
            node = ["block", kind, arg.strip(), [], None]
            stack[-1][2].append(node)
            stack.append((kind, arg, node[3], node))
        elif t == "else":
            kind, arg, _, node = stack[-1]
            if node is None or node[4] is not None:
                raise TemplateError(f"{name}: stray {{{{else}}}}")
            node[4] = []
            stack[-1] = (kind, arg, node[4], node)
        elif t.startswith("/"):
            kind = t[1:].strip()
            if stack[-1][0] != kind:
                raise TemplateError(f"{name}: {{{{/{kind}}}}} closes {{{{#{stack[-1][0]}}}}}")
            stack.pop()
        else:
            stack[-1][2].append(("var", t, False))
    if len(stack) != 1:
        raise TemplateError(f"{name}: {{{{#{stack[-1][0]}}}}} is never closed")
    if pos < len(text):
        root.append(text[pos:])
    return root


_MISSING = object()


class Renderer:
    def __init__(self, partial_dir):
        self.partial_dir = Path(partial_dir)
        self.cache = {}

    def partial(self, name):
        if name not in self.cache:
            p = self.partial_dir / f"{name}.html"
            if not p.exists():
                raise TemplateError(f"partial {name} not found ({p})")
            self.cache[name] = parse(p.read_text(), f"partials/{name}.html")
        return self.cache[name]

    @staticmethod
    def lookup(stack, path):
        if path == "this":
            return stack[-1][0]
        if path.startswith("@"):
            return stack[-1][1].get(path[1:], _MISSING)
        frames = list(stack)
        while path.startswith("../"):
            path = path[3:]
            frames = frames[:-1] or frames[:1]
        parts = path.split(".")
        for value, _ in reversed(frames):
            if isinstance(value, dict) and parts[0] in value:
                cur = value
                for p in parts:
                    if isinstance(cur, dict) and p in cur:
                        cur = cur[p]
                    else:
                        return _MISSING
                return cur
        return _MISSING

    def render(self, nodes, stack, name, depth=0):
        if depth > 30:
            raise TemplateError(f"{name}: partials nested too deep")
        out = []
        for n in nodes:
            if isinstance(n, str):
                out.append(n)
            elif n[0] == "var":
                v = self.lookup(stack, n[1])
                if v is _MISSING:
                    raise TemplateError(f"{name}: {{{{{n[1]}}}}} does not resolve")
                v = "" if v is None else (("true" if v else "false") if isinstance(v, bool) else str(v))
                out.append(v if n[2] else html.escape(v, quote=True))
            elif n[0] == "partial":
                out.append(self.render(self.partial(n[1]), stack, f"partials/{n[1]}.html", depth + 1))
            else:
                _, kind, arg, body, other = n
                v = self.lookup(stack, arg)
                if kind == "each":
                    if v is _MISSING or v is None:
                        raise TemplateError(f"{name}: {{{{#each {arg}}}}} does not resolve")
                    items = list(v)
                    if not items:
                        out.append(self.render(other or [], stack, name, depth))
                    for i, item in enumerate(items):
                        meta = {"index": i, "first": i == 0, "last": i == len(items) - 1}
                        out.append(self.render(body, stack + [(item, meta)], name, depth))
                else:
                    truth = v is not _MISSING and bool(v)
                    if kind == "unless":
                        truth = not truth
                    out.append(self.render(body if truth else (other or []), stack, name, depth))
        return "".join(out)


def render_template(template_path, ctx, partial_dir):
    r = Renderer(partial_dir)
    nodes = parse(Path(template_path).read_text(), Path(template_path).name)
    return r.render(nodes, [(ctx, {})], Path(template_path).name)


# ------------------------------------------------------------------------------------------------ data and scripts
def load_data(data_path, routes_path, dogcast_path):
    data = json.loads(Path(data_path).read_text())
    data["lroutes"] = json.loads(Path(routes_path).read_text())["routes"]
    if Path(dogcast_path).exists():
        data["dogcast"] = json.loads(Path(dogcast_path).read_text())
    return data


UI_MARK = "/* ================================================================== UI */"
UI_CLOSE = "})(typeof window !== 'undefined' ? window : globalThis);\n"


def lucky_core_only(src):
    """hm64_lucky_v29.js holds the computation (HM64Lucky) and then the Lucky Timer's UI in one closure; a page
    without the Lucky Timer takes the computation only: everything before the UI mark, closed like the file."""
    assert src.count(UI_MARK) == 1 and src.endswith(UI_CLOSE), "hm64_lucky_v29.js: UI mark / closing line changed"
    head = src[:src.index(UI_MARK)]
    assert "root.HM64Lucky = LuckyCore;" in head and head.rstrip().endswith("if (typeof document === 'undefined') return;")
    return head + UI_CLOSE


def scripts():
    rd = lambda n: (WEB / n).read_text()
    lucky = rd("hm64_lucky_v29.js")
    return {"core": rd("hm64_core_v28.js"), "app": rd("hm64_app_v28.js"), "dogwatch": rd("hm64_dogwatch_v30.js"),
            "lucky": lucky, "lucky_core": lucky_core_only(lucky), "dogref": rd("hm64_dogref_v31.js"),
            "site": rd("hm64_site_v32.js"), "practice": rd("hm64_practice_v32.js"), "timing": rd("hm64_timing_v32.js"),
            "settings": rd("hm64_settings_v32.js")}


def zone_scripts(js):
    """v32.23: the scripts of a page whose cast pack has pier-zone tables (rainy sets). The sources stay untouched -
    pages without zones are built from them byte for byte - and tools/zone_patches.py applies its exact-string patches
    to the copies used here; hm64_zone_v32.js is added (the template loads it right after the data)."""
    import importlib.util
    spec = importlib.util.spec_from_file_location("zone_patches", Path(__file__).resolve().parent / "zone_patches.py")
    zp = importlib.util.module_from_spec(spec); spec.loader.exec_module(zp)
    out = dict(js)
    lucky = zp.apply("hm64_lucky_v29.js", js["lucky"])
    out.update({"lucky": lucky, "lucky_core": lucky_core_only(lucky), "dogref": zp.apply("hm64_dogref_v31.js", js["dogref"]),
                "practice": zp.apply("hm64_practice_v32.js", js["practice"]), "zone": (WEB / "hm64_zone_v32.js").read_text()})
    return out


def page_data(data, kind, routes, version, generated, carry=True):
    """The data a page embeds. lucky: everything (the Lucky Timer, its settings and its legacy carry plans use it
    all), routes narrowed to the set's. casting: what the casting tables read (HM64Lucky.prepare, DogWatch, the
    Dog reference), routes narrowed to the set's."""
    known = {r["id"] for r in data["lroutes"]}
    missing = [r for r in routes if r not in known]
    if missing:
        raise SystemExit(f"site.json names routes that the data does not have: {missing}")
    lr = [r for r in data["lroutes"] if r["id"] in routes]
    if kind == "practice":
        d = practice_data(data, lr)
    elif kind == "lucky":
        d = dict(data)
        d["lroutes"] = lr
        if not carry:
            # v32.1 (Thomas 2026-11-23): the Spring 9 dog-carry route is retired; its plans and cast tables stay out
            d["lucky"] = None
            d["casts"] = []
    else:
        keep = ("pace", "arrivals", "names", "keys", "dirs", "class_of", "pose_groups", "sprites", "dogcast")
        d = {k: data[k] for k in keep if k in data}
        d["lucky"] = None
        d["casts"] = []
        d["lroutes"] = lr
    d["version"] = version
    d["generated"] = generated
    # same key order as the single-page build (version and generated first): the Lucky Timer page's data equals it
    order = [k for k in data if k in d] + [k for k in d if k not in data]
    return {k: d[k] for k in order}


def practice_data(data, lr):
    """v32.5 Dog practice: only what the drills read - the dog traces of the set's routes, every arrival (dog line x
    READY offset) with its route weight (the 'all' preset, Space when Jack stops), the cast pack without the dog after
    the cast (P / R / T: the drills do not show it), the dog sprites and Jack's frames on the READY screenshot."""
    routes = []
    for r in lr:
        g = next(x for x in r["groups"] if x["id"] == "all")
        of = r["dw"]["of_line"]
        agg = {}
        for li, w, o, mt in g["v"]["pier"]:
            assert mt == 1, "a pier-start arrival with a later first cast"
            agg[(of[li], o)] = agg.get((of[li], o), 0.0) + w
        for dwi, w, o, mt in (g.get("vu") or {}).get("pier", []):
            assert mt == 1
            agg[(dwi, o)] = agg.get((dwi, o), 0.0) + w
        routes.append({"id": r["id"], "label": r.get("label", r["id"]), "variant_of": r.get("variant_of"), "variant": r.get("variant"),
                       "plays": (r.get("source") or {}).get("members"),
                       "dw": {"lines": [{"key": L["key"], "w": L["w"], "li": L["li"], "vis": L["vis"]} for L in r["dw"]["lines"]],
                              "fam": r["dw"].get("fam"), "until": r["dw"].get("until")},
                       "arr": [[dwi, round(w, 9), o] for (dwi, o), w in sorted(agg.items())]})
        if r.get("zones"):                               # v32.23: the arrivals of each pier zone (the preset "2nd cut <zone>")
            arrz = {}
            for z in r["zones"]["order"]:
                gz = next((x for x in r["groups"] if x["id"] == "cut2-" + z), None)
                if gz is None:
                    continue
                az = {}
                for li, w, o, mt in gz["v"]["pier"]:
                    assert mt == 1
                    az[(of[li], o)] = az.get((of[li], o), 0.0) + w
                for dwi, w, o, mt in (gz.get("vu") or {}).get("pier", []):
                    assert mt == 1
                    az[(dwi, o)] = az.get((dwi, o), 0.0) + w
                arrz[z] = [[dwi, round(w, 9), o] for (dwi, o), w in sorted(az.items())]
            routes[-1]["arrz"] = arrz
    keys = {L["key"] for r in routes for L in r["dw"]["lines"]}
    dc = data.get("dogcast") or {}
    pack = {k: dc[k] for k in ("v", "until", "cast_until", "F", "S", "N", "X", "O") if k in dc}
    pack["lines"] = {k: v for k, v in (dc.get("lines") or {}).items() if k in keys}
    if dc.get("zones"):                                  # v32.23: the pier-zone tables of the lines kept
        zs = dc["zones"]
        pack["zones"] = dict(zs, d={z: {k: v for k, v in d.items() if k in keys} for z, d in zs["d"].items()})
    d = {k: data[k] for k in ("names", "sprites", "jack", "beach") if k in data}
    d["routes"] = routes
    d["pack"] = pack
    return d


def data_json(d):
    return json.dumps(d, separators=(",", ":")).replace("</", "<\\/")


# ------------------------------------------------------------------------------------------------ the site
VI_MS_DECK = 16.715                      # one VI on NTSC hardware (the app's value since v30.1)
DECK_PULL_VI = 20                        # the window to let go of B at a bite (Dog practice's G_PULL)
DECK_CAST_UNTIL = 2398                   # the tables' cast window: up to 40 s after READY (Jack lies down at 40 s)
KIND = {
    "lucky": {"template": "lucky_timer.html", "file": "lucky-timer_{set}.html", "name": "Lucky Timer"},
    "casting": {"template": "casting_tables.html", "file": "casting-tables_{set}.html", "name": "Casting tables"},
    "practice": {"template": "practice.html", "file": "dog-practice_{set}.html", "name": "Dog practice"},
}


def build(data_path, out, site_path=SITE / "site.json", generated=None):
    site = json.loads(Path(site_path).read_text())
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    generated = generated or dt.date.today().isoformat()
    # v32.1: each set may name its own route tables and cast pack (site.json "data", files in webapp/assets); the
    # default is the original pair (Sunny, no horse). Loaded once per pair.
    cache = {}

    def data_of(s):
        x = s.get("data") or {}
        pair = (x.get("routes", "lucky_routes.json"), x.get("dogcast", "dogcast.json"))
        if pair not in cache:
            for f in pair:
                if not (WEB / "assets" / f).exists():
                    raise SystemExit(f'site.json set {s["id"]}: webapp/assets/{f} not found')
            cache[pair] = load_data(data_path, WEB / "assets" / pair[0], WEB / "assets" / pair[1])
        return cache[pair]
    js = scripts()
    jsz = None
    weathers = {w["id"]: w for w in site["weathers"]}
    files = []
    for s in site["sets"]:
        s["weather_label"] = weathers[s["weather"]]["label"]
        s["pages"] = []
        for kind in ("lucky", "casting", "practice"):
            if s.get(kind):
                s["pages"].append({"kind": kind, "name": KIND[kind]["name"], "file": KIND[kind]["file"].format(set=s["id"]),
                                   "blurb": s[kind].get("blurb", "")})
        s["links"] = {p["kind"]: p["file"] for p in s["pages"]}
    for w in site["weathers"]:
        w["sets"] = [s for s in site["sets"] if s["weather"] == w["id"]]
    base = {"site": site, "generated": generated, "hub": "index.html", "guide": "guide.html", "deck": "deck.html",
            "problem": "problem.html", "notworking": "not-working.html", "howitworks": "how-it-works.html",
            "settings": "settings.html"}
    for s in site["sets"]:
        for p in s["pages"]:
            d = page_data(data_of(s), p["kind"], s[p["kind"]]["routes"], site["version"], generated,
                          carry=s[p["kind"]].get("carry") is not False)
            page = {"kind": p["kind"], "set": s["id"], "set_label": f'{s["weather_label"]} · {s["label"]}', "file": p["file"],
                    "title": f'HM64 {p["name"]} · {s["weather_label"]}, {s["label"].lower()} · {site["version"]}',
                    "hub": "index.html", "lucky": s["links"].get("lucky"), "casting": s["links"].get("casting"),
                    "practice": s["links"].get("practice"), "guide": "guide.html", "notworking": "not-working.html", "settings": "settings.html",
                    "needs": s.get("needs", [])}
            if s.get("traits", {}).get("rainy"):
                page["rainy"] = True                      # v32.18: no sparrows in the rain (Not working? leaves that item out)
            zoned = bool((data_of(s).get("dogcast") or {}).get("zones"))
            if zoned:
                page["zones"] = True                      # v32.23: pier-zone tables (tools/zone_build.py)
                jsz = jsz or zone_scripts(js)
            if p["kind"] == "casting" and s["casting"].get("bites"):
                # v32.19: release rules up to bite N and casts to end_s s after READY (the set's cast data; rainy sets)
                page["castBites"] = int(s["casting"]["bites"])
                page["castEnd"] = float(s["casting"].get("end_s", 76))
            if p["kind"] == "lucky":
                # v32.1: the Lucky Timer's starting settings for this game file (a route of this page, its start) and
                # whether the old Spring 9 dog-carry route (no horse) is offered; stored settings still win where
                # they fit the page
                lk = s["lucky"]
                for r in [lk.get("defaults", {}).get("route")] + list(lk.get("defaults", {}).get("routeAnchor", {})):
                    if r is not None and r not in lk["routes"]:
                        raise SystemExit(f'site.json set {s["id"]}: Lucky Timer default names route {r}, not on the page')
                if lk.get("defaults"):
                    page["luckyDefaults"] = lk["defaults"]
                if lk.get("carry") is False:
                    page["carry"] = False
            ctx = dict(base, set=s, page=page, js=jsz if zoned else js, data_json=data_json(d),
                       page_json=json.dumps(page, separators=(",", ":")).replace("</", "<\\/"))
            text = render_template(SITE / "templates" / KIND[p["kind"]]["template"], ctx, SITE / "partials")
            (out / p["file"]).write_text(text)
            files.append(p["file"])
    # v32.6: the hub's picker - every set with its traits (rainy, horse, ...), status, texts and page links
    hub_data = {"version": site["version"], "traits": site.get("traits", []),
                "weathers": {w["id"]: {"label": w["label"], "note": w.get("note", "")} for w in site["weathers"]},
                "kinds": [{"kind": k, "name": KIND[k]["name"], "blurb": next((s[k].get("blurb", "") for s in site["sets"] if s.get(k)), "")}
                          for k in ("casting", "lucky", "practice")],
                "sets": [{"id": s["id"], "traits": s.get("traits", {}), "status": s["status"], "status_label": s.get("status_label", s["status"]),
                          "summary": s.get("summary", ""), "needs": s.get("needs", []), "make": s.get("make", []), "links": s["links"]}
                         for s in site["sets"]]}
    for s in site["sets"]:
        for t in hub_data["traits"]:
            if not t.get("later") and t["id"] not in s.get("traits", {}):
                raise SystemExit(f'site.json set {s["id"]}: no value for trait {t["id"]}')
    combos = [tuple(bool(s["traits"].get(t["id"])) for t in hub_data["traits"] if not t.get("later")) for s in site["sets"]]
    if len(set(combos)) != len(combos):
        raise SystemExit("site.json: two sets have the same traits")
    hub = render_template(SITE / "templates" / "hub.html",
                          dict(base, hub_json=json.dumps(hub_data, separators=(",", ":"), ensure_ascii=False).replace("</", "<\\/")),
                          SITE / "partials")
    (out / "index.html").write_text(hub)
    files.insert(0, "index.html")
    # v32.7 (Thomas 2026-11-24 11:43): the guide - setup per game file, the route, "Not working?", how it works
    # v32.15 (Thomas 2026-11-24 16:05): the guide, Not working? and How it works are three pages; they share the game
    # file picked by ?set=<id> or the hub's ticks (partials/guide_js.html)
    sets_json = json.dumps([{"id": s["id"], "label": f'{s["weather_label"]} · {s["label"]}',
                             "traits": {t["id"]: bool(s.get("traits", {}).get(t["id"]))
                                        for t in hub_data["traits"] if not t.get("later")}}
                            for s in site["sets"]], separators=(",", ":"), ensure_ascii=False).replace("</", "<\\/")
    for k, (tpl, name) in enumerate([("guide.html", "guide.html"), ("not_working.html", "not-working.html"),
                                     ("how_it_works.html", "how-it-works.html")]):
        (out / name).write_text(render_template(SITE / "templates" / tpl, dict(base, sets_json=sets_json), SITE / "partials"))
        files.insert(1 + k, name)
    # v32.11 (Thomas 2026-11-24 15:08): the deck - the problem as top-decking a card. v32.14 (15:44): casting = press and
    # hold; each bite of a real cast lights a face-down card for the release window (20 VIs = 0.33 s), let go on it to
    # catch it. Real casts from the cast pack of the first ready set, over the tables' cast window (0-40 s after READY,
    # before Jack would lie down), on the dog lines that make up 90% of the route's weight - which line is not the point.
    s0 = next(s for s in site["sets"] if s.get("status") == "ready" and s.get("lucky"))
    d0 = data_of(s0)
    rid = (s0["lucky"].get("defaults") or {}).get("route") or s0["lucky"]["routes"][0]
    r = next(x for x in d0["lroutes"] if x["id"] == rid)
    pk = d0.get("dogcast") or {}
    W = sum(L["w"] for L in r["dw"]["lines"]) or 1
    keep, acc = [], 0.0
    for L in sorted(r["dw"]["lines"], key=lambda L: -L["w"]):
        if L["key"] in pk.get("lines", {}):
            keep.append(L)
            acc += L["w"] / W
            if acc >= 0.90:
                break
    smap, sN, sX, sO = {}, [], [], []

    def sid(st, depth=0):                       # the pack's bite states, re-numbered per (state, bite number): up to 6 bites a cast
        if st < 0 or depth >= 6:
            return -1
        if (st, depth) in smap:
            return smap[(st, depth)]
        i = smap[(st, depth)] = len(sN)
        sN.append(pk["N"][st]); sX.append(-1); sO.append(pk["O"][st])
        sX[i] = sid(pk["X"][st], depth + 1) if pk["N"][st] >= 0 else -1
        if sX[i] < 0:
            sN[i] = -1
        return i
    lines = []
    for L in keep:
        ln = pk["lines"][L["key"]]
        cs = []
        for j, cid in enumerate(ln["idx"]):
            lab = ln["k0"] + 2 * j
            if lab > DECK_CAST_UNTIL:
                break
            cs.append([pk["F"][cid], sid(pk["S"][cid])] if cid >= 0 and pk["F"][cid] >= 0 else 0)
        lines.append({"w": round(L["w"] / W, 6), "k0": ln["k0"], "c": cs})
    deck = {"set": f'{s0["weather_label"]} · {s0["label"]}', "vi_ms": VI_MS_DECK, "pull": DECK_PULL_VI, "until": DECK_CAST_UNTIL,
            "share": round(acc, 4), "lines": lines, "N": sN, "X": sX, "O": "".join(sO)}
    dk = render_template(SITE / "templates" / "deck.html",
                         dict(base, deck_set=deck["set"], deck_share=f'{100 * acc:.0f}%',
                              deck_json=json.dumps(deck, separators=(",", ":")).replace("</", "<\\/"),
                              jack_json=json.dumps(d0.get("jack"), separators=(",", ":")).replace("</", "<\\/")), SITE / "partials")
    (out / "deck.html").write_text(dk)
    files.insert(4, "deck.html")
    # v32.16 (Thomas 2026-11-24 16:45): Settings - keys, timing, practice and the attempt count for every page. Data: Jack's
    # frames and the READY screenshot (the drills), the animation names, and each animation's share of the dog's wait on
    # the first ready set's route (the key table; the Lucky Timer's dwAnimStats over the same lines)
    READABLE = {0, 4, 5, 6, 7}                                  # hm64_dogwatch_v30.js READABLE (screen facings S, N, east)
    st = {}
    tot = 0.0
    for Ln in r["dw"]["lines"]:
        for v in Ln["vis"]:
            dd = (v[1] - v[0]) * (Ln.get("w") or 1)
            o = st.setdefault(v[4], {"b": v[4], "t": 0.0, "rd": 0.0, "long": 0, "n": 0})
            o["t"] += dd
            tot += dd
            o["n"] += 1
            if v[2] in READABLE:
                o["rd"] += dd
            if v[1] - v[0] >= 30:
                o["long"] += 1
    anim = sorted(({"b": o["b"], "share": round(o["t"] / tot, 6), "readable": round(o["rd"] / o["t"], 4) if o["t"] else 0,
                    "long": round(o["long"] / o["n"], 4)} for o in st.values()), key=lambda o: -o["share"])
    sx = {k: d0[k] for k in ("jack", "beach", "names") if k in d0}
    sx.update({"anim": anim, "anim_from": f'{s0["weather_label"]} · {s0["label"]}', "version": site["version"]})
    (out / "settings.html").write_text(render_template(SITE / "templates" / "settings.html",
                                                       dict(base, js=js, sets_json=sets_json, settings_json=json.dumps(sx, separators=(",", ":"), ensure_ascii=False).replace("</", "<\\/")),
                                                       SITE / "partials"))
    files.insert(4, "settings.html")
    # v32.12 (Thomas 2026-11-24 15:27): the problem it solves, its own page (the hub only links it)
    (out / "problem.html").write_text(render_template(SITE / "templates" / "problem.html", base, SITE / "partials"))
    files.insert(6, "problem.html")
    listing = {"version": site["version"], "generated": generated,
               "files": [{"file": f, "bytes": (out / f).stat().st_size,
                          "sha256": hashlib.sha256((out / f).read_bytes()).hexdigest()} for f in files]}
    (out / "site_files.json").write_text(json.dumps(listing, indent=1) + "\n")
    # for the release script (shasum -a 256 -c): every file of the site with its checksum
    (out / "site_files.sha256").write_text("".join(f'{f["sha256"]}  {f["file"]}\n' for f in listing["files"]))
    # pages to copy over files people already open locally (Firefox keeps a local file's settings per file name)
    local = site.get("local_install", [])
    for x in local:
        if x["page"] not in files:
            raise SystemExit(f'site.json local_install names {x["page"]}, which the build did not make')
    (out / "site_local.txt").write_text("".join(f'{x["as"]} {x["page"]}\n' for x in local))
    return listing


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("data")
    ap.add_argument("--out", required=True)
    ap.add_argument("--site", default=str(SITE / "site.json"))
    ap.add_argument("--generated", help="date stamp for the pages (default: today)")
    a = ap.parse_args()
    listing = build(a.data, a.out, a.site, a.generated)
    for f in listing["files"]:
        print(f'{f["file"]:44s} {f["bytes"] / 1e6:7.2f} MB  {f["sha256"][:12]}')


if __name__ == "__main__":
    sys.exit(main())
