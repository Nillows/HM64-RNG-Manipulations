#!/usr/bin/env python3
"""Facts for the "leaf in a forest" diagrams (README "How it works", site guide page).

Everything the diagrams draw comes from lab output, so they can be redrawn as new data comes in:

  python3 tools/forest_facts.py \
      --raw RUN_DIR                       a dog-watch run folder (Z1..Z5 jsonl + zz_lines.json), e.g. the horse raw run
      --raw-label "Sunny, horse"          what that run is
      --z0 "Sunny, no horse=Z0.json"      a Z0 reference-route record (repeatable): RNG draws at every map load
      --routes "sunny-no-horse=webapp/assets/lucky_routes.json#lineup-lineup2"   (repeatable) a table set's dog lines
      --pending "rainy-no-horse=Rainy, no horse"                                 (repeatable) a set still being collected
      --collected "sunny-no-horse-married=ROUTES.json#route-id"                  (repeatable, v32.28) a game file whose lab
                                          data is in but whose pages are not built yet: the cubes picture shows its L1
      --update FACTS.json                 start from an existing facts file and only add what is given here
      --out webapp/assets/forest_facts.json

Nothing here is estimated: counts are counted, VIs are read from the records. tools/forest_svg.py draws them.
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tools"))

VI_MS = 16.715                       # one VI on hardware (NTSC); a game frame is 2 VIs
# The farm sparrows are a start-of-day roll fixed by the menu timing alone (zigzag_campaign "dogwatch" preset notes,
# measured on the lineup saves): door pair at house VI 1046 / 1048 (menus 5-6 game frames late), far pair off screen at
# 1036 / 1042, none at 1038 / 1040 / 1044.
SPARROWS = {1046: "door", 1048: "door", 1036: "far", 1042: "far"}


def jl(p):
    out = []
    with open(p) as f:
        for line in f:
            line = line.strip()
            if line:
                r = json.loads(line)
                if "_error" not in r and "error" not in r:
                    out.append(r)
    return out


def raw_facts(run: Path, preset: str = "dogwatch") -> dict:
    """Stage-by-stage fan-out of one dog-watch run, per menu crown (house state in the band)."""
    import zigzag_campaign as zc
    cfg = dict(zc.PRESETS[preset])
    # menus -> house states (one row = one menu input: press style x rhythm x phase)
    ok = {(s_, T, zc.hold_of(h, T)) for s_ in cfg["styles"] for T in cfg["periods"] for h in cfg["holds"]}
    menu_runs, hvi, hdraw, per_h = 0, {}, {}, Counter()
    for r in jl(run / "Z1_menus.jsonl"):
        if (r["style"], r["T"], r["h"]) not in ok:
            continue
        for x in r["rows"]:
            menu_runs += 1
            if x.get("house"):
                per_h[x["house"]] += 1
                hvi[x["house"]] = x["house_vi"]
                hdraw[x["house"]] = x.get("draw")
    h0 = cfg.get("house_ref") or min(hvi.values())
    band = {h for h in per_h if cfg.get("house_lo", 0) <= hvi[h] - h0 <= cfg["house_slack"]}
    cut = sorted({hvi[h] for h in per_h if h not in band})

    def mine(rows, **grids):
        return [r for r in rows if all(tuple(r.get("_job", {}).get(k, ())) == tuple(cfg[v]) for k, v in grids.items())]
    z2 = {r["h"]: r for r in mine(jl(run / "Z2_house.jsonl"), Us="Us", Vs="Vs")}
    z3 = {r["f"]: r for r in mine(jl(run / "Z3_cross.jsonl"), Cs="Cs")}
    z4 = {r["r"]: r for r in jl(run / "Z4_ranch.jsonl")}
    fmin = min(row[2] for h in band for row in z2[h]["rows"] if row[2] is not None)
    rmin = min(row[1] for f in z3.values() for row in f["rows"] if row[1] is not None)
    lines = json.load(open(run / "zz_lines.json"))
    mem = defaultdict(list)                                   # beach state (no @w) -> [(line, k_off)]
    for lid, L in lines.items():
        for m in L["members"]:
            mem[m["b"].split("@")[0]].append((lid, m["k_off"]))
    per_beach_ready = {b: len(v) for b, v in mem.items()}     # READY plays per beach state (W x D x B)

    crowns, all_f, all_r, all_b, all_var, all_lines = [], set(), set(), set(), set(), set()
    combos_total, line_combos = 0, defaultdict(Counter)      # line -> {house_vi: plays reaching it}
    mem_lines = {b: Counter(v[0] for v in vs) for b, vs in mem.items()}
    crown_beaches = {}
    for h in sorted(band, key=lambda h: hvi[h]):
        farms = Counter(row[3] for row in z2[h]["rows"] if row[2] is not None and row[2] - fmin <= cfg["farm_slack"])
        ranches, beaches = Counter(), Counter()
        for f, nf in farms.items():
            e = z3.get(f, {})
            if e.get("farm_fail"):
                continue
            for row in e.get("rows", []):
                if row[1] is not None and row[1] - rmin <= cfg["ranch_slack"]:
                    ranches[row[2]] += nf
        for r_, nr in ranches.items():
            b = z4.get(r_, {}).get("b")
            if b:
                beaches[b] += nr
        var = {v for b in beaches for v in mem.get(b, [])}
        ready_paths = sum(per_beach_ready.get(b, 0) for b in beaches)
        combos = per_h[h] * sum(n * per_beach_ready.get(b, 0) for b, n in beaches.items())
        combos_total += combos
        crown_beaches[hvi[h]] = (per_h[h], beaches)
        for b, n in beaches.items():
            for lid, c in mem_lines.get(b, {}).items():
                line_combos[lid][hvi[h]] += per_h[h] * n * c
        crowns.append({"house": h, "house_vi": hvi[h], "frames_late": (hvi[h] - h0) // 2, "draw": hdraw.get(h),
                       "sparrows": SPARROWS.get(hvi[h], "none"), "menu_inputs": per_h[h],
                       "farm_states": len(farms), "ranch_states": len(ranches), "beach_states": len(beaches),
                       "ready_paths": ready_paths, "variants": len(var), "lines": len({v[0] for v in var}),
                       "combos": combos})
        all_f |= set(farms); all_r |= set(ranches); all_b |= set(beaches); all_var |= var
        all_lines |= {v[0] for v in var}
    top = max(line_combos, key=lambda k: sum(line_combos[k].values()))
    tot = sum(line_combos[top].values())
    # when each crown's plays reach that line: its READY offset k_off (VIs after the line's earliest arrival), and one
    # real play per crown (its beach timings) at the most common offset - the same branch entered at different moments
    mem_top = defaultdict(list)
    for m in lines[top]["members"]:
        mem_top[m["b"].split("@")[0]].append(m)
    when = {}
    for v, (nm, beaches) in crown_beaches.items():
        ko, ex = Counter(), {}
        for b, n in beaches.items():
            for m in mem_top.get(b, []):
                ko[m["k_off"]] += nm * n
                ex.setdefault(m["k_off"], {"W": m["W"], "D": m["D"], "B": m["B"]})
        if ko:
            mode = ko.most_common(1)[0][0]
            when[v] = {"k_off_min": min(ko), "k_off_max": max(ko), "k_off_mode": mode, "example": ex[mode]}
    backtrace = {"line": top, "plays": tot, "share_of_all": round(tot / combos_total, 4),
                 "from_crowns": [{"house_vi": v, "plays": n, "share": round(n / tot, 4), **when.get(v, {})}
                                 for v, n in sorted(line_combos[top].items())]}
    return {
        "run": run.name, "preset": preset,
        "menu_inputs": menu_runs, "menu_inputs_in_band": sum(per_h[h] for h in band),
        "house_cut_vis": cut, "house_states_cut": len([h for h in per_h if h not in band]),
        "band": {"house_ref": h0, "lo": cfg.get("house_lo", 0), "hi": cfg["house_slack"]},
        "slack_vi": {"menus": cfg["house_slack"] - cfg.get("house_lo", 0), "house": cfg["farm_slack"],
                     "crossroads": cfg["ranch_slack"], "beach_wait": max(cfg["Ws"]) - min(cfg["Ws"]),
                     "first_cut": max(cfg["Ds"]) - min(cfg["Ds"]),
                     "pier_cut": _pier_window(lines)},
        "crowns": crowns,
        "merged": {"farm_states": len(all_f), "ranch_states": len(all_r), "beach_states": len(all_b),
                   "beach_starts": len(all_b) * len(cfg["Ws"]), "ready_plays": sum(per_beach_ready[b] for b in all_b),
                   "variants": len(all_var), "lines": len(all_lines)},
        "combos_total": combos_total,
        "backtrace_top_line": backtrace,
        "one_future": one_future(run, lines, top),
        "pairs": key_value_pairs(run, lines),
        "line_weights_top": [round(w, 4) for w in sorted((L["w"] for L in lines.values()), reverse=True)[:12]],
    }


def s32_after(n, seed=0):
    """The generator's value after n draws from power-on (the draw index is the position on the LCG stream)."""
    x = seed & 0xFFFFFFFF
    for _ in range(n):
        x = (x * 1103515245 + 12345) & 0xFFFFFFFF
    return x - (1 << 32) if x >= 1 << 31 else x


def one_future(run: Path, lines, top):
    """Two plays of the heaviest line that stop at the pier at different moments: the earliest (k_off 0) and one at the
    most common later offset - the later one passes through the earlier one's (x, y) k_off VIs before it stops. Plus the
    line's first dog records (dogInfo action / direction / state timer) from the run's dog-watch traces."""
    mem = lines[top]["members"]
    ko = Counter(m["k_off"] for m in mem if m["k_off"] > 0)
    later = ko.most_common(1)[0][0]
    a = next(m for m in mem if m["k_off"] == 0)
    b = next(m for m in mem if m["k_off"] == later)
    pick = lambda m: {"k_off": m["k_off"], "W": m["W"], "D": m["D"], "B": m["B"], "ready_draw": m["ready_draw"],
                      "wake_draw": m["wake_draw"], "x_ready": s32_after(m["ready_draw"])}
    out = {"line": top, "a": pick(a), "b": pick(b)}
    tr = run / "dogwatch_traces.json"
    if tr.exists():
        t = json.load(open(tr))["lines"].get(top) or {}
        out["dog_first"] = (t.get("dog") or [])[:6]
    return out


# dogInfo.actionState -> the animation the game sets for it (decomp src/game/animals.c, updateDog's switch)
DOG_ACTIONS = {0: "standing", 1: "walking", 2: "sitting", 3: "standing", 4: "running", 5: "barking", 6: "eating",
               7: "sniffing", 8: "peeing", 10: "digging", 11: "sitting", 12: "on its belly", 13: "flapping its ears",
               14: "sitting, sniffing", 16: "sitting", 17: "sitting, happy", 18: "sleeping", 19: "scratching",
               20: "sitting, looking", 21: "jumping", 22: "jumping"}


def key_value_pairs(run: Path, lines, n_lines=3, frames=4):
    """Real (random number : dog state) pairs from the run's natural line paths (Z6_lines.jsonl, observe records):
    the heaviest line as Jack stops and on its next frames, and the next lines as Jack stops. The draw count on a frame
    = the last absolute count the trace recorded + one per game frame since (the main loop's clock)."""
    want = [k for k, _ in sorted(((k, L["w"]) for k, L in lines.items()), key=lambda t: -t[1])[:n_lines]]
    recs = {}
    with open(run / "Z6_lines.jsonl") as f:
        for line in f:
            head = line[:120]
            for k in want:
                if k in head and k not in recs:
                    r = json.loads(line)
                    if r.get("key") == k and r.get("obs"):
                        recs[k] = r
            if len(recs) == len(want):
                break

    def at(seq, k):
        cur = None
        for row in seq:
            if row[0] <= k:
                cur = row
            else:
                break
        return cur

    out = []
    for li, k in enumerate(want):
        r = recs.get(k)
        if not r:
            continue
        o = r["obs"]
        k0 = o["draw"][0][0]
        for f in range(frames if li == 0 else 1):
            kk = k0 + 2 * f
            d = at(o["draw"], kk)
            idx = d[1] + (kk - d[0]) // 2
            dg = at(o["dog"], kk)
            pos = at(o.get("pos", []), kk)
            out.append({"line": k, "rank": li + 1, "frame": f, "draw": idx, "x": s32_after(idx),
                        "action": dg[1], "action_name": DOG_ACTIONS.get(dg[1], f"action {dg[1]}"), "facing": dg[2],
                        "timer": dg[3], "spot": pos[1:] if pos else None})
    return out


def _pier_window(lines):
    """Width of the second-cut window (VIs of B that reach READY for one beach start and first cut)."""
    per = defaultdict(set)
    for L in lines.values():
        for m in L["members"]:
            per[(m["b"], m["D"])].add(m["B"])
    return max(max(v) - min(v) + 1 for v in per.values())


def z0_facts(label, path):
    d = json.load(open(path))
    rec = d.get("record", d)
    st = rec["info"]["stages"]
    names = {"1": "house", "2": "farm", "3": "crossroads", "4": "ranch", "5": "beach"}
    pts = [{"at": "power on", "vi": 0, "draw": 0}]
    for k in sorted(st, key=int):
        pts.append({"at": names.get(k, k), "vi": st[k]["vi"], "draw": st[k]["draw"]})
    g = rec["got"]
    b = st["5"]["vi"]
    pts.append({"at": "dog wakes", "vi": b + g["wake"][0], "draw": g["wake"][1]})
    pts.append({"at": "READY", "vi": b + g["ready"][0], "draw": g["ready"][3]})
    return {"label": label, "save": d.get("save"), "save_sha256": (d.get("save_sha256") or "")[:16] or None,
            "weather": (rec["info"].get("save") or {}).get("weather"), "points": pts}


def route_facts(set_id, spec):
    path, rid = spec.split("#")
    d = json.load(open(path))
    R = next(x for x in d["routes"] if x["id"] == rid)
    dw = R["dw"]
    L = dw["lines"]
    W = sum(x["w"] for x in L) or 1
    fam = dw.get("fam") or [[i, 0, 0] for i in range(len(L))]
    reps = Counter(f[0] for f in fam)
    top = max(range(len(L)), key=lambda i: L[i]["w"])
    t = R["lines"][L[top]["li"]] if L[top].get("li", -1) >= 0 else None
    leaves = {"green": [], "gold": [], "purple": [], "purple_bite": []}
    if t:
        lo = t["lo"]
        leaves["green"] = [lo + i for i, c in enumerate(t["n1"]) if c == "1"]
        leaves["gold"] = [lo + i for i, c in enumerate(t.get("n2") or "") if c == "1"]
        for i, e in enumerate(t.get("bx") or []):
            if isinstance(e, list) and any(b < 0 for b in e):
                leaves["purple"].append(lo + i)
                # v32.21: which later bite (3, 4, ...) - the app gives each its own colour; "purple" keeps every bite 3+ leaf
                leaves["purple_bite"].append(3 + next(q for q, b in enumerate(e) if b < 0))
    # describing the shape: how many different dog shapes (the sequence of what the dog does, timing ignored) are
    # still possible after the dog's first n moves, and how much of the route weight shares L1's shape
    narrow = []
    for n in range(1, 9):
        pre = defaultdict(float)
        for x in L:
            pre[tuple((r[2], r[4]) for r in x["vis"][:n])] += x["w"] / W
        mine_ = tuple((r[2], r[4]) for r in L[top]["vis"][:n])
        narrow.append({"moves": n, "shapes": len(pre), "L1_shape_share": round(pre[mine_], 4),
                       "lines_with_L1_shape": sum(1 for x in L if tuple((r[2], r[4]) for r in x["vis"][:n]) == mine_)})
    ws = sorted((x["w"] / W for x in L), reverse=True)
    acc, n50, n90 = 0.0, None, None
    for i, w in enumerate(ws):
        acc += w
        if n50 is None and acc >= 0.5:
            n50 = i + 1
        if n90 is None and acc >= 0.9:
            n90 = i + 1
    return {"set": set_id, "route": rid, "label": R.get("label"), "lines": len(L), "families": len(reps),
            "lines_with_table": len(R["lines"]), "top_share": round(ws[0], 4), "n50": n50, "n90": n90,
            "narrowing": narrow,
            "L1": {"key": L[top]["key"], "share": round(L[top]["w"] / W, 4),
                   "vis": L[top]["vis"], "leaves": leaves, "casts_tested": t.get("tested") if t else None}}


FISH = {"N": "the Power Nut", "s": "a small fish", "m": "a medium fish", "l": "a large fish"}


def interception(set_facts, pack_path, lo_vi=7, t_min=720, t_max=1440):
    """A real cast that grows a Power Nut leaf on L1, and the cast one game frame later that does not: the cast moment,
    the dog after each cast until its first bite (the cast pack's P runs: [dVI, code = base * 8 + facing]), the bites.
    The cast is picked among L1's Nut-on-bite-1 cast frames between t_min and t_max VIs after READY (so the branch has
    grown a while before the cast) whose next frame is not a Nut."""
    pk = json.load(open(pack_path))
    L1 = set_facts["L1"]
    ln = pk["lines"].get(L1["key"])
    if not ln:
        return None

    def cast(lab):
        j = (lab - ln["k0"]) // 2
        if j < 0 or j >= len(ln["idx"]) or ln["idx"][j] < 0:
            return None
        cid = ln["idx"][j]
        f, st = pk["F"][cid], pk["S"][cid]
        if f < 0 or st < 0:
            return None
        rows, t, flat = [], 0, pk["P"][cid]
        for i in range(0, len(flat), 2):
            t0, t = t, t + flat[i]
            code = flat[i + 1]
            if t > f:
                break
            rows.append([lab + t, None, code & 7, 0, code >> 3])
        for a, b in zip(rows, rows[1:]):
            a[1] = b[0]
        if rows:
            rows[-1][1] = lab + f
        bites, at, s2 = [], lab + f, st                  # v32.14: the bites of this cast (the pack's chain: N to the next, X its state)
        while s2 >= 0 and len(bites) < 4:
            bites.append([at, pk["O"][s2]])
            if pk["N"][s2] < 0:
                break
            at, s2 = at + pk["N"][s2], pk["X"][s2]
        return {"label": lab, "vi": lab + 1, "bite_vi": lab + f, "outcome": pk["O"][st], "what": FISH.get(pk["O"][st], pk["O"][st]),
                "rows": rows, "bites": bites}
    green = set(L1["leaves"]["green"])
    for v in L1["leaves"]["green"]:
        if t_min <= v <= t_max and (v + 2) not in green:
            a, b, c = cast(v - 1), cast(v + 1), cast(v - 3)
            if a and b and a["outcome"] == "N" and b["outcome"] != "N":
                return {"line": L1["key"], "cast": a, "next": b, "prev": c}
    return None


def twin_offset(a, b):
    """If two L1 dog paths are the same branch a fixed number of VIs apart, that number (else None)."""
    va, vb = a["L1"]["vis"], b["L1"]["vis"]
    n = min(len(va), len(vb)) - 1                         # the last run is cut by the recorded window
    if n < 5 or [tuple(x[2:]) for x in va[:n]] != [tuple(x[2:]) for x in vb[:n]]:
        return None
    offs = Counter(y[1] - x[1] for x, y in zip(va[:n], vb[:n]))
    off, cnt = offs.most_common(1)[0]
    la, lb = a["L1"]["leaves"], b["L1"]["leaves"]
    same_leaves = all([x + off for x in la[c]] == lb[c] for c in ("green", "gold", "purple"))
    return {"vi": off, "runs_checked": n, "runs_agree": cnt, "leaves_agree": same_leaves}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--raw", type=Path)
    ap.add_argument("--raw-label", default="")
    ap.add_argument("--preset", default="dogwatch")
    ap.add_argument("--z0", action="append", default=[])
    ap.add_argument("--routes", action="append", default=[])
    ap.add_argument("--pending", action="append", default=[])
    ap.add_argument("--collected", action="append", default=[])
    ap.add_argument("--update", type=Path)
    ap.add_argument("--pack", action="append", default=[], help="id=dogcast.json: the cast pack of a set (interception)")
    ap.add_argument("--out", type=Path, required=True)
    a = ap.parse_args()
    if a.update:                                         # v32.28: add to an existing facts file, change nothing else in it
        out = json.loads(a.update.read_text())
        out["collected"] = dict(out.get("collected") or {})
        for s in a.collected:
            sid, spec = s.split("=", 1)
            out["collected"][sid] = route_facts(sid, spec)
            unm = sid.replace("-married", "")
            if unm in out.get("sets", {}):               # the same file without the marriage: do the two L1 lines share a branch?
                t = twin_offset(out["sets"][unm], out["collected"][sid])
                out["collected"][sid]["twin_of_unmarried"] = t
        a.out.write_text(json.dumps(out, indent=1) + "\n")
        print("updated", a.out, "collected:", ", ".join(out["collected"]))
        return
    out = {"vi_ms": VI_MS, "rng": {"type": "s32", "min": -2 ** 31, "max": 2 ** 31 - 1, "seed_at_power_on": 0,
                                    "step": "x = x * 1103515245 + 12345 (libkmc rand)"}}
    if a.raw:
        out["raw"] = raw_facts(a.raw, a.preset)
        out["raw"]["label"] = a.raw_label
    out["sunlight"] = [z0_facts(*s.split("=", 1)) for s in a.z0]
    out["sets"] = {}
    for s in a.routes:
        sid, spec = s.split("=", 1)
        out["sets"][sid] = route_facts(sid, spec)
    out["pending"] = dict(s.split("=", 1) for s in a.pending)
    out["collected"] = {}
    for s in a.collected:
        sid, spec = s.split("=", 1)
        out["collected"][sid] = route_facts(sid, spec)
    for s in a.pack:
        sid, path = s.split("=", 1)
        if sid in out["sets"]:
            out["sets"][sid]["interception"] = interception(out["sets"][sid], path)
    ids = list(out["sets"])
    out["twins"] = []
    for i in range(len(ids)):
        for j in range(i + 1, len(ids)):
            t = twin_offset(out["sets"][ids[i]], out["sets"][ids[j]])
            if t:
                out["twins"].append({"a": ids[i], "b": ids[j], **t})
    a.out.write_text(json.dumps(out, indent=1) + "\n")
    print("wrote", a.out)


if __name__ == "__main__":
    main()
