HM64 Power Nut Tool v32.27 (2026-11-26) - the sunny pages have the three pier-zone tables

Thomas 19:53: "lets do the full sunny tables, that way we are always working from certainty, and we justify the 2nd
cut option even staying in the sunny versions of the tables".

WHAT CHANGED SINCE v32.26
- Sunny - No horse and Sunny - Horse (Lucky Timer, Casting tables, Dog practice): one table per pier zone, from the
  sunny pier-spot campaign of 2026-11-26 (22,814 + 21,058 casts from the middle and the south end, both M4s).
  The 2nd cut is now North / Middle / South (game frames 1-3 / 4-8 / 9-11 of the pier window) and comes BEFORE the
  first step, as on the rainy pages; the old Early / Middle / Late choice is gone (its Early mixed two camera zones).
  The pages open on Middle. Both routes of a sunny page (the main table and the sparrow-door table) have the zones.
- What the data says (cast frames with a Power Nut on bites 1-6):
      no horse: north 16,941 | hold from all three 16,813 | a fish from the south end 12, from the middle 0
      horse:    north 22,310 | hold from all three 22,118 | a fish from the south end 25, from the middle 1
  No Power Nut exists only in the middle or only in the south. About 1 cast frame in 20 has some bite that differs by
  zone (mostly later bites of casts after the first minute): those frames now show what was measured in the zone.
- NOT PROVEN, shown as fish outside the north end: 116 (no horse) / 167 (horse) cast frames whose Nut is a 5th or 6th
  bite 142-151 s after READY, later than the recorded part of the cast. 12 + 15 casts per zone would settle them.
- tools/zone_build.py: --sunny (only the routes of the pack are rebuilt, the sparrow-door table weighs its members by
  house arrival like tools/zigzag_routes.py: all 26 recorded presets are reproduced first, as proof), and for every
  file: a pack cast is tied to its recorded row and to its twin recordings (same cast hash) - before, a cast that two
  runs recorded was tied through the line frame only. The rainy tables of v32.26 come out byte for byte from the old
  builder and keep every kept / lost Nut with the new one (the new one would add a few measured zone-only Nuts to the
  rainy tables: NOT in this release, the rainy tables are the v32.26 ones).
- tools/zone_verify.py: the same twin rule, routes of other packs in the file must be unchanged, --bx-slack.
- tools/hm64_labdata.sh rev 2026-11-26k: a machine whose git has no name / e-mail (the PC) commits the lab-data folder
  as "hm64-lab (<host>)" instead of stopping.
- Guide, Not working?, README: the sunny zones. Rainy pages: only the version label and the zone script (its sunny
  wording) differ from v32.26; their tables are identical.

TESTED (headless Chrome; NOT Firefox, not a console)
- zone_verify on both sunny files: ok - 0 contradicted; every route frame of all four tables equals the pack.
- tests/ui_zones.js on the 6 sunny pages and on the sparrow-door routes: 0 errors, 0 mismatches, Nut frames = report.
- The regression round of v32.25 on the sunny pages (old = v32.26) and ui_zones / ui_rainy on the rainy pages.
