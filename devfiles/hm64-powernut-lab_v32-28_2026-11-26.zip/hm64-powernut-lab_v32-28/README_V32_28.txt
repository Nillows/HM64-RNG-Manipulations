HM64 Power Nut Tool v32.28 (2026-11-26) - nothing "not proven" on the sunny pages, more measured Nuts on the rainy ones

Thomas 20:36: "lets solve it once and for all". 21:40: "analyze the gap data, build it into the next version" and
"add the marriage images to the read me cubes L1 images".

WHAT CHANGED SINCE v32.27
- SUNNY (both files): the 116 / 167 cast frames whose late Power Nut (a 5th or 6th bite 142-151 s after READY) was
  "not proven" outside the north end are settled. Campaign nuts-sunny (21:26-21:35): the 12 + 15 casts behind them,
  each from the north spot, the middle and the south, held to 170 s = 81 casts. All 81 show exactly the bites the page
  had, the Nut included. Cast frames with a Nut on bites 1-6 now:
      no horse: north 16,941 | middle 15,901 of 15,901 | south 15,889 (12 are fish there) | all three 16,929
      horse:    north 22,310 | middle 21,286 (1 fish)   | south 21,262 (25 fish)          | all three 22,285
  Not proven: 0. The north casts are the first direct recording of these late Nuts (the page knew them through shared
  bite states): confirmed.
- RAINY (both files): rebuilt with the builder of v32.27, which ties a cast that two runs recorded to both recordings.
  Every kept and every lost Nut of v32.26 is unchanged; the tables gain measured Nuts that exist only in a zone and had
  been left out: no horse +66 middle / +100 south, horse +30 / +53, all on casts later than a minute after READY.
      no horse: middle 14,356 -> 14,422, south 13,594 -> 13,694;  horse: middle 9,719 -> 9,749, south 9,205 -> 9,258
  North and "Not sure" are unchanged (16,823 / 11,036 and 13,729 / 9,446). The rainy Lucky Timer route tables (casts in
  the first 40 s) are byte-identical to v32.26's; the change is in the cast pack (casts after a minute).
- README picture "L1 across game files: two cubes": the two married files (no horse, sunny and rainy) are drawn with
  their L1 from the married lab runs of 2026-11-25, as "measured in the lab, pages to come" (orange dashes). Found:
  on both, L1 is the single file's L1 - every move of the dog and every Nut leaf of the first 40 s, at the same moment,
  with the same share of the plays (14% / 5%). tools/forest_facts.py --update / --collected, tools/forest_svg.py.
  The married PAGES are not built: this is the picture only.
- tools/hm64_labdata.sh rev 2026-11-26l (the campaign's zips in the table; git identity fallback of rev k).
- Guide, zone help text, README: the numbers above.

WHO RAN WHAT
- The PC (new container hm64-lab:amd64-nd) ran all 81 casts: it claimed both blocks of both saves first. Your M4 ran
  its gate. Scott's M4 did not join (its results branch was last written at 18:45).
- Gates: your M4 and the PC both: control casts 12 / 12 and 15 / 15 as recorded; no-cast dog to 170 s 11 of 11 lines
  (no horse), 12 of 13 (horse; the 13th differs after 120 s, as this afternoon). The 75 new gate rows of the PC equal
  your M4's row for row (ARM against the new x86 container).
- So the 81 casts exist from ONE machine. Their proof is that machine's gate and that all 81 equal the page's chain.

TESTED (headless Chrome; NOT Firefox, not a console)
- zone_verify on all four files: ok - 0 contradicted.
- tests/ui_zones.js on all 12 tool pages and the two sparrow-door routes; the regression round against v32.27.
