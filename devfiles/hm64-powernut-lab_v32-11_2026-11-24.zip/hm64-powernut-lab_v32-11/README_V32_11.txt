HM64 Power Nut Tool v32.11 (2026-11-24): the problem it solves, and the deck page
==================================================================================

What you asked for (2026-11-24 15:08)
  A section near the top of the website and the README, with pictures, on the problem the app solves: catching the
  Power Nut = top-decking a chosen card from a shuffled deck (a different deck each arrival at the beach) that flickers
  with the unseen RNG; casting shuffles a new card in; leaving the beach = a new deck; the deck shuffles faster while
  your hand reaches (fishing draws) - the tool lets you draw the card when you need it. And a page with an interactive
  attempt: 52 cards in new deck order, remove 1 (51 left), pick a goal; stack from unix time x time on the page (max
  1800 s); blink 0.33 s with a random line from the data as the seed; click the face-down deck to start; 51 face-down
  cards in a grid, Press-Your-Luck style but nothing jumps around.

What changed (v32.11 includes v32.7 - v32.10)
  - deck.html (new site page, built by site_build.py from the ready sets' Lucky routes): 52 cards in new deck order
    (A-K spades, A-K diamonds, K-A clubs, K-A hearts); click one to take it out, then the goal card. "Stack the deck":
    seed = unix ms x ms on the page (capped at 1800 s, no running timer) mod 2^32, into the game's own generator
    (libkmc rand), Fisher-Yates for the stack and for the grid layout, then a dog line drawn by its route weight. Click
    the deck to start (you are at READY); each moment (0.33 s; or the game's 1/30 s, ticked) one card is on top: the goal
    card exactly on that line's Nut-on-the-1st-bite cast frames, otherwise a stack card picked by the frame. Press =
    your hand reaches (the deck shuffles twice as fast), let go = draw: the card is shown and turned over where it lies;
    then the deck reshuffles (new stack, new line). Leave the beach = a new time seed. After 40 s of game time Jack lies
    down. "Use the tool": a countdown lamp + a strip of the next 60 moments (green = your card on top). Tally: draws,
    goal cards, your rate, the blind odds of the decks you drew from. No flashing at the game's own speed (30 Hz).
  - Hub: "The problem it solves" box above the picker (text + media/problem_deck.svg + link to the deck page). Guide:
    "The deck" in its top links.
  - README: "## The problem it solves: top-decking one card" before Contents (the analogy, the picture, the deck page with
    a screenshot media/deck_page.png); Contents line; hub picture retaken.
  - Toolkit: forest_svg.py "deck" -> media/problem_deck.svg (L1 of Sunny -> No horse, its first 2 s: the goal card on the
    Nut frames; 22 of 1,197 frames in 40 s = 1.8% blind; the tool's cue at 0.72 s).
  - Page data unchanged (byte-equal to v32.10 apart from the version).

Note: in the game a moment is one frame (1/30 s = 33 ms), ten times shorter than the page's default 0.33 s; the page
offers both and the text says so.

Release
  bash ~/Documents/hm64/tools/hm64_release.sh v32-11 <lab sha256> <pages sha256> </dev/null
