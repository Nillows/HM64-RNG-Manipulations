/* HM64 Dog practice (v32.5, Thomas 2026-11-23 19:52 / 19:58): "a little test area ... that is interactive and lets
   the player try the mechanic in a controlled environment using lines they could get based on our data"; "make sure
   the practice activities take preferences from the players specific keyboard layout"; "adding enter as a key to
   autoselect the most likely dog ... practice dog identifying with the arrow keys and just hit enter when the top
   dog is right and then of course that gets to tuning after".

   One page per game file (tools/site_build.py, kind "practice"), three drills on the page's own lab data:
     1 Tune the dog    a dog line plays on the "TV" at its true timing; its card plays at the tool's guess of your
                       timing (the line's usual timing, your Space tap off by up to +-150 ms); step the card with
                       your [ ] keys until it turns with the TV, Enter = "in step". Scored in game frames, with what
                       that does to the line's next Nut casts.
     2 Read the dog    key the dog's facing and long animations with your dog-watch keys; the cards re-weight live
                       (HM64DogWatch.likelihood, the Lucky Timer's own matcher); Enter picks the top card, a click
                       any card. Scored right / wrong, with how sure the tool was.
     3 Whole attempt   tap your start key when Jack stops, read the dog, Enter / click, tune, then hold the start key
                       to cast (it stands in for B, as the Lucky Timer's hold mode reads it) and let go at the bite:
                       the catch comes from the lab's record of that exact cast frame.
   Every dog is an arrival drawn by its weight (the share of the lab's plays of the route that reach that dog line at
   that timing), or one line the player chooses. Time: e = VIs since READY on the TV (true); the tool's clock runs
   `lag` VIs behind it. A line's trace k = e + o (o = the arrival's READY offset); a card plays k = eTool + A + adj
   (A = the line's mean offset over its arrivals, adj = the tuning). A cast pressed at true e lands on pack label
   2*floor(e/2) + o, floored to even (as the casting tables' shares()).

   Keys: the Lucky Timer's stored settings (hm64v29_lucky: dwKeys, dwAnimKeys, dwAdjKeys, startKey, dwCards, dwFill,
   start-tap delay); on the website every page shares them. A local copy of a page keeps its own storage (Firefox: per
   file), so the keys can also be set here (hm64v32_practice.keys, used before the Lucky Timer's). Keys are matched by
   their physical position (KeyboardEvent.code) like the Lucky Timer; their labels follow your layout where the browser
   says it (navigator.keyboard) or where you have typed the key on this site (hm64v32_keylabels). */
(function (root) {
  'use strict';
  const D = typeof HM64_DATA !== 'undefined' ? HM64_DATA : null, DW = root.HM64DogWatch, $ = id => document.getElementById(id);
  if (!D || !DW || !$('prRoot')) return;
  const VI_MS = 33.430 / 2, FAM_MARGIN = 60, G_CAST = 36, G_PULL = 20, G_RECAST = 24, BOUNCE_MS = 300;
  const store = {
    get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* storage unavailable */ } },
  };
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const pct = p => (p == null || !(p >= 0) ? '—' : (100 * p).toFixed(p < 0.0995 ? 1 : 0) + '%');
  const fx = (v, n) => v.toFixed(n == null ? 1 : n);
  const sec = e => e * VI_MS / 1000;
  const evenFloor = x => { const f = Math.floor(x); return f - (((f % 2) + 2) % 2); };
  const now = () => performance.now();
  const evT = e => (typeof e.timeStamp === 'number' && e.timeStamp > 0 && Math.abs(e.timeStamp - now()) < 5000 ? e.timeStamp : now());
  const FACING = DW.FACING, ARROW = DW.ARROW;

  /* ------------------------------------------------------------------ the player's keys */
  const ANIM_EXTRA = { 80: 'KeyR', 88: 'KeyF', 104: 'KeyG', 176: 'KeyO', 200: 'KeyB' };   // the Lucky Timer's defaults (v31.27)
  const animDef = () => { const o = {}; for (const [g, bs] of Object.entries(DW.NUMPAD)) for (const b of bs) o[b] = 'Numpad' + g; return Object.assign(o, ANIM_EXTRA); };
  const DIRKEY = { arrows: { ArrowUp: [0, -1], ArrowDown: [0, 1], ArrowLeft: [-1, 0], ArrowRight: [1, 0] },
                   wasd: { KeyW: [0, -1], KeyS: [0, 1], KeyA: [-1, 0], KeyD: [1, 0] } };
  const FAC_OF = { '0,1': 0, '-1,1': 1, '-1,0': 2, '-1,-1': 3, '0,-1': 4, '1,-1': 5, '1,0': 6, '1,1': 7 };
  let K = null;
  function loadKeys() {
    const L = store.get('hm64v29_lucky', {}) || {}, P = (store.get('hm64v32_practice', {}) || {}).keys || null;
    const x = Object.assign({}, L, P || {});
    const delay = x.startTapMs != null && +x.startTapMs >= 0 ? +x.startTapMs : x.anchorDelayMs && +x.anchorDelayMs.pier >= 0 ? +x.anchorDelayMs.pier : 150;
    K = { startKey: typeof x.startKey === 'string' && x.startKey ? x.startKey : ' ', facing: x.dwKeys === 'wasd' ? 'wasd' : 'arrows',
          anim: Object.assign(animDef(), x.dwAnimKeys || {}), adj: Array.isArray(x.dwAdjKeys) && x.dwAdjKeys.length === 2 ? x.dwAdjKeys.slice() : ['BracketLeft', 'BracketRight'],
          cards: [3, 5, 7].includes(+x.dwCards) ? +x.dwCards : 5, fill: ['rtl', 'mid', 'ltr'].includes(x.dwFill) ? x.dwFill : 'rtl', delayMs: Math.max(0, Math.min(600, delay)),
          src: P ? 'page' : (L.dwAnimKeys || L.dwAdjKeys || L.dwKeys || L.startKey ? 'lucky' : 'default') };
    /* the animation groups: one key = one group (several animations may share a key), as the Lucky Timer's dwGroups */
    const by = {}, defSig = {};
    for (const [b, c] of Object.entries(K.anim)) if (c) (by[c] = by[c] || []).push(+b);
    for (const [g, bs] of Object.entries(DW.NUMPAD)) defSig[bs.slice().sort((a, b) => a - b).join(',')] = +g;
    K.groups = Object.entries(by).map(([code, bs]) => { bs.sort((a, b) => a - b); const d = defSig[bs.join(',')];
      return { gid: d != null ? d : 1000 + bs[0], code, bases: bs, label: d != null ? DW.NUMPAD_TXT[d] : bs.map(nameOf).join(' / ') }; });
    DW.setGroups(K.groups.map(g => [g.gid, g.bases]));
  }
  /* key labels on the player's own layout */
  const LAB = store.get('hm64v32_keylabels', {}) || {};
  let LMAP = null;
  const PRINTABLE = /^(Key[A-Z]|Digit\d|Bracket(Left|Right)|Semicolon|Quote|Comma|Period|Slash|Backslash|Backquote|Minus|Equal|IntlBackslash)$/;
  const CODE_TXT = { ArrowUp: '↑', ArrowDown: '↓', ArrowLeft: '←', ArrowRight: '→', Escape: 'Esc', BracketLeft: '[', BracketRight: ']', Minus: '-', Equal: '=', Semicolon: ';', Quote: "'",
    Comma: ',', Period: '.', Slash: '/', Backslash: '\\', Backquote: '`', IntlBackslash: '<', NumpadAdd: 'Num +', NumpadSubtract: 'Num −', NumpadMultiply: 'Num *', NumpadDivide: 'Num /',
    NumpadDecimal: 'Num .', Delete: 'Del', Insert: 'Ins', PageUp: 'PgUp', PageDown: 'PgDn', Enter: 'Enter', NumpadEnter: 'Num Enter', Backspace: 'Backspace', Space: 'Space', Tab: 'Tab' };
  function keyTxt(c) {
    if (!c) return '—';
    if (PRINTABLE.test(c)) { const l = LAB[c] || (LMAP && LMAP.get(c)); if (l && l.length === 1) return l.toUpperCase(); }
    return CODE_TXT[c] || (/^Key[A-Z]$/.test(c) ? c[3] : /^Digit\d$/.test(c) ? c[5] : /^Numpad\d$/.test(c) ? 'Num ' + c[6] : c);
  }
  const startTxt = () => (K.startKey === ' ' ? 'Space' : K.startKey.length === 1 ? K.startKey.toUpperCase() : K.startKey);
  try { if (navigator.keyboard && navigator.keyboard.getLayoutMap) navigator.keyboard.getLayoutMap().then(m => { LMAP = m; renderKeys(); }).catch(() => {}); } catch (e) { /* no layout API */ }
  document.addEventListener('keydown', e => {                      // learn what each key types on this keyboard
    if (!e.code || !PRINTABLE.test(e.code) || !e.key || e.key.length !== 1 || e.shiftKey || e.ctrlKey || e.altKey || e.metaKey) return;
    const k = e.key.toLowerCase(); if (LAB[e.code] === k) return;
    LAB[e.code] = k; store.set('hm64v32_keylabels', LAB);
  }, true);

  /* ------------------------------------------------------------------ data */
  const ROUTES = (D.routes || []).filter(r => r.dw && r.arr && r.arr.length);
  const BASE = ROUTES.find(r => !r.variant_of) || ROUTES[0], SPAR = ROUTES.find(r => r.variant === 'sparrows' && r.variant_of === (BASE && BASE.id)) || null;
  const PK = D.pack || null;
  const nameOf = b => (D.names && D.names[b]) || (b === 32 ? 'stand' : 'anim ' + b);
  const lineName = (R, dwi) => { const li = R.dw.lines[dwi].li; return li >= 0 ? 'L' + (li + 1) : 'dog ' + (dwi + 1); };
  const spr = (b, d) => (D.sprites && D.sprites[b + '_' + d]) || '';
  function prep(R) {
    if (R._p) return R._p;
    const c = R.arr.map(([dwi, w, o]) => ({ dwi, ko: o, mt: 1, w, pv: 0, o }));
    const W = c.reduce((q, x) => q + x.w, 0) || 1, by = new Map();
    for (const x of c) { let g = by.get(x.dwi); if (!g) by.set(x.dwi, g = { dwi: x.dwi, w: 0, so: 0 }); g.w += x.w; g.so += x.w * x.o; }
    const lines = [...by.values()].map(g => ({ dwi: g.dwi, p: g.w / W, A: g.so / g.w })).sort((a, b) => b.p - a.p);
    return (R._p = { cands: c, W, lines, Aof: new Map(lines.map(l => [l.dwi, l.A])) });
  }
  function showAt(R, dwi, k) {
    const v = R.dw.lines[dwi].vis;
    let lo = 0, hi = v.length - 1;
    while (lo <= hi) { const m = (lo + hi) >> 1; if (v[m][1] <= k) lo = m + 1; else if (v[m][0] > k) hi = m - 1; else return v[m]; }
    return null;
  }
  const flagCache = new Map();
  function flags(key) {                                           // per pack label / 2: Nut on bite 1 / on bite 2 (bite 1 held)
    if (flagCache.has(key)) return flagCache.get(key);
    const ln = PK && PK.lines[key];
    let f = null;
    if (ln) {
      const n = ln.k0 / 2 + ln.idx.length, b1 = new Uint8Array(n), b2 = new Uint8Array(n);
      ln.idx.forEach((cid, j) => {
        if (cid < 0 || PK.F[cid] < 0) return;
        const st = PK.S[cid], i = ln.k0 / 2 + j; if (st < 0) return;
        if (PK.O[st] === 'N') b1[i] = 1;
        if (PK.N[st] >= 0 && PK.X[st] >= 0 && PK.O[PK.X[st]] === 'N') b2[i] = 1;
      });
      f = { b1, b2 };
    }
    flagCache.set(key, f);
    return f;
  }
  function castOf(key, lab) {                                     // the lab's record of a cast on pack label lab: its bites
    const ln = PK && PK.lines[key]; if (!ln) return null;
    const j = (lab - ln.k0) / 2; if (j < 0 || j >= ln.idx.length || ln.idx[j] < 0) return null;
    const cid = ln.idx[j], out = [];
    let f = PK.F[cid], st = PK.S[cid], at = lab + f;
    while (f >= 0 && st >= 0 && out.length < 16) { out.push({ lab: at, o: PK.O[st], st }); if (PK.N[st] < 0) break; at += PK.N[st]; st = PK.X[st]; }
    return { cid, bites: out, nut: out.findIndex(b => b.o === 'N') };
  }
  const FISH = { N: 'the POWER NUT', s: 'a small fish', m: 'a medium fish', l: 'a large fish' };
  /* Nut groups of a line at alignment off (trace k = e + off) after e0: neighbouring frames with the Nut on the same bite */
  function nutGroups(key, off, e0, e1) {
    const f = flags(key); if (!f) return [];
    const out = []; let cur = null;
    for (let i = Math.max(0, Math.ceil(e0 / 2)); 2 * i <= e1; i++) {
      const lab = evenFloor(2 * i + off), j = lab / 2;
      const b = j >= 0 && j < f.b1.length ? (f.b1[j] ? 1 : f.b2[j] ? 2 : 0) : 0;
      if (b && cur && cur.b === b && cur.i1 === i - 1) cur.i1 = i;
      else if (b) out.push(cur = { b, i0: i, i1: i }); else cur = null;
    }
    return out;
  }

  /* ------------------------------------------------------------------ settings and stats of this page */
  const PS = Object.assign({ drill: 'tune', speed: 1, line: 'any', sparrow: false }, store.get('hm64v32_practice', {}) || {});
  const savePS = () => store.set('hm64v32_practice', PS);
  const ST = store.get('hm64v32_practice_stats', { tune: [], read: [], whole: [] }) || { tune: [], read: [], whole: [] };
  const saveST = () => { for (const k of ['tune', 'read', 'whole']) ST[k] = (ST[k] || []).slice(-300); store.set('hm64v32_practice_stats', ST); };
  const route = () => (PS.sparrow && SPAR ? SPAR : BASE);

  /* ------------------------------------------------------------------ the drill */
  let S = null;                                                   // the running drill
  function pickArrival(R) {
    const P = prep(R), only = PS.line !== 'any' ? +PS.line : null;
    const cs = only != null ? P.cands.filter(c => c.dwi === only) : P.cands;
    const W = cs.reduce((q, c) => q + c.w, 0);
    let r = Math.random() * W;
    for (const c of cs) { r -= c.w; if (r <= 0) return c; }
    return cs[cs.length - 1];
  }
  function newDrill(kind) {
    const R = route(), a = pickArrival(R);
    if (!a) return;
    S = { kind, R, a, phase: 'count', at0: now(), readyAt: now() + (kind === 'whole' ? 2600 : 1600), speed: kind === 'whole' ? 1 : +PS.speed || 1,
          lag: 0, adj: 0, logs: [], chord: null, pick: null, tuned: false, out: new Set(), hist: [], cast: null, rel: null, result: null, tap: null, msg: '' };
    if (kind === 'tune') { S.pick = { dwi: a.dwi, A: prep(R).Aof.get(a.dwi), fam: [a.dwi] }; S.lag = (Math.random() * 2 - 1) * 150 / VI_MS; }   // your Space tap off by up to +-150 ms
    S.base = 0; S.at = S.readyAt;
    if ($('prReveal')) $('prReveal').innerHTML = '';
    render();
  }
  /* true VIs since READY (the TV); speed changes re-anchor */
  const eTrue = t => S.base + ((t == null ? now() : t) - S.at) * S.speed / VI_MS;
  const eTool = t => eTrue(t) - S.lag;
  function setSpeed(v) {
    PS.speed = v; savePS();
    if (S && S.kind !== 'whole') { const t = now(), e = eTrue(t); if (t > S.at) { S.base = e; S.at = t; } S.speed = v; }
  }
  const started = () => S && now() >= S.readyAt;
  const toolOn = () => S && (S.kind !== 'whole' ? started() : S.tap != null);

  /* the cards: the arrivals re-weighted by the keys (the Lucky Timer's matcher), per line, sister lines folded */
  function comp() {
    const R = S.R, P = prep(R), t = eTool() + 1;
    if (S._c && S._c.n === S.logs.length && S._c.out === S.out.size && now() - S._c.at < 250) return S._c;
    const lk = S.logs.length ? DW.likelihood(R, P.cands, S.logs, { now: t }) : null, by = new Map();
    let Z = 0;
    P.cands.forEach((c, i) => {
      const p = c.w * (lk ? lk[i] : 1); if (!(p > 0) || S.out.has(c.dwi)) return;
      Z += p; let g = by.get(c.dwi); if (!g) by.set(c.dwi, g = { dwi: c.dwi, p: 0, so: 0 }); g.p += p; g.so += p * c.o;
    });
    let lines = [...by.values()].map(g => ({ dwi: g.dwi, p: g.p / Z, A: g.so / g.p, li: R.dw.lines[g.dwi].li })).sort((x, y) => y.p - x.p);
    const F = R.dw.fam;                                             // sister lines that have become the same dog: one card
    if (F) {
      const grp = new Map(), out = [];
      for (const x of lines) { const f = F[x.dwi]; if (!f || !(t + (x.A - 1) - f[1] >= f[2] + FAM_MARGIN)) { out.push(x); continue; } let g = grp.get(f[0]); if (!g) grp.set(f[0], g = []); g.push(x); }
      for (const g of grp.values()) {
        if (g.length < 2) { out.push(g[0]); continue; }
        const keep = g.find(x => S.pick && x.dwi === S.pick.dwi) || g.find(x => x.li >= 0) || g[0];
        out.push(Object.assign({}, keep, { p: g.reduce((q, x) => q + x.p, 0), fam: g.map(x => x.dwi) }));
      }
      lines = out.sort((x, y) => y.p - x.p);
    }
    return (S._c = { at: now(), n: S.logs.length, out: S.out.size, lines });
  }
  const cardK = (dwi, A) => eTool() + A + (S.pick && S.pick.dwi === dwi ? S.adj : 0);
  function pick(dwi, how) {
    if (!S || !toolOn() || S.cast) return;
    if (S.pick && S.pick.dwi === dwi) { S.pick = null; S.tuned = false; S.adj = 0; render(); return; }
    const c = comp(), ln = c.lines.find(x => x.dwi === dwi); if (!ln) return;
    S.pick = { dwi, A: ln.A, at: eTool(), p: ln.p, fam: ln.fam || [dwi], how }; S.tuned = false; S.adj = 0;
    if (S.kind === 'read') return reveal();
    flash(`${lineName(S.R, dwi)} picked · ${keyTxt(K.adj[0])} ${keyTxt(K.adj[1])} tune · Enter when in step`);
    render();
  }

  /* ------------------------------------------------------------------ keys */
  document.addEventListener('keydown', e => {
    if (!S && !(e.key === K.startKey || e.code === 'Enter')) return;
    const tg = e.target, typing = tg && ((tg.tagName === 'INPUT' && !['range', 'checkbox', 'radio', 'button'].includes(tg.type)) || tg.tagName === 'TEXTAREA' || tg.tagName === 'SELECT');
    if (cap || typing || document.querySelector('dialog[open]')) return;
    const t = evT(e);
    if (e.key === K.startKey) { e.preventDefault(); if (!e.repeat) startKey(t); return; }
    if (!S) { if (e.code === 'Enter' && !e.repeat) { e.preventDefault(); newDrill(PS.drill); } return; }
    if (e.key === 'Escape') { e.preventDefault(); stop('stopped'); return; }
    if (e.code === K.adj[0] || e.code === K.adj[1]) {
      e.preventDefault();
      if (S.pick && toolOn() && !S.cast && S.phase !== 'done') { S.adj += (e.code === K.adj[0] ? -2 : 2) * (e.shiftKey ? 10 : 1); S.adj = Math.max(-240, Math.min(240, S.adj)); S.tuned = false; render(); }
      return;
    }
    if (e.code === 'Enter' || e.code === 'NumpadEnter') {
      e.preventDefault(); if (e.repeat) return;
      if (S.phase === 'done') { newDrill(S.kind); return; }
      if (!toolOn() || S.cast) return;
      if (S.kind === 'tune') { reveal(); return; }
      if (!S.pick) { const c = comp(), top = c.lines[0]; if (top) pick(top.dwi, 'enter'); return; }
      if (!S.tuned) { S.tuned = true; S.tunedAdj = S.adj; flash('TIMING SET'); render(); }
      return;
    }
    if (e.code === 'Backspace') {
      e.preventDefault(); if (e.repeat || S.cast) return;
      if (S.pick && S.kind === 'whole') { S.pick = null; S.adj = 0; S.tuned = false; flash('PICK UNDONE'); render(); return; }
      if (S.logs.length) { S.logs.pop(); S.chord = null; render(); }
      return;
    }
    if (S.kind === 'tune' || !toolOn() || S.cast || S.phase === 'done') return;
    const dir = DIRKEY[K.facing][e.code], g = dir ? null : K.groups.find(x => x.code === e.code);
    if (!dir && !g) return;
    e.preventDefault(); if (e.repeat) return;
    const tv = eTool(t) + 1;
    if (g) { S.logs.push({ t: tv, g: g.gid }); S.chord = null; flash(`DOG ${g.label.toUpperCase()}`); render(); return; }
    const c = S.chord;
    if (c && tv - c.t <= 0.25 * 1000 / VI_MS && c.keys.size === 1 && !c.keys.has(e.code)) {
      const d0 = [...c.keys.values()][0];
      if (d0[0] * dir[0] + d0[1] * dir[1] === 0) { c.keys.set(e.code, dir); c.log.f = FAC_OF[[d0[0] + dir[0], d0[1] + dir[1]].join(',')]; flash(`DOG ${ARROW[c.log.f]} ${FACING[c.log.f]}`); render(); return; }
    }
    const log = { t: tv, f: FAC_OF[dir.join(',')] };
    S.logs.push(log); S.chord = { t: tv, log, keys: new Map([[e.code, dir]]) };
    flash(`DOG ${ARROW[log.f]} ${FACING[log.f]}`); render();
  });
  document.addEventListener('keyup', e => {
    if (!S || cap || e.key !== K.startKey) return;
    e.preventDefault();
    if (S.kind === 'whole' && S.cast && S.rel == null) release(evT(e));
  });
  function startKey(t) {
    if (!S || S.phase === 'done') { newDrill(PS.drill); return; }
    if (S.kind !== 'whole') return;
    if (S.tap == null) {                                          // the tap when Jack stops: the tool's clock starts (your delay taken off)
      if (t < S.readyAt - 700) return;
      S.tap = t; S.lag = (t - K.delayMs - S.readyAt) / VI_MS; render(); return;
    }
    if (S.cast || t - S.tap < BOUNCE_MS) return;
    const e = eTrue(t), lab = evenFloor(2 * Math.floor(e / 2) + S.a.o), key = S.R.dw.lines[S.a.dwi].key, rec = castOf(key, lab);
    S.cast = { t, e, lab, rec, bites: rec ? rec.bites.map(b => Object.assign({ e: b.lab - S.a.o }, b)) : [] };
    if (!rec) { S.result = { none: true }; finishWhole(); }
    render();
  }
  function release(t) {
    const e = eTrue(t), c = S.cast;
    let hit = null, n = -1;
    c.bites.forEach((b, i) => { if (e >= b.e && e < b.e + G_PULL) { hit = b; n = i; } });
    S.rel = { t, e, n };
    S.result = hit ? { catch: hit.o, n: n + 1 } : { empty: true, early: !c.bites.length || e < c.bites[0].e };
    S.relAt = now(); finishWhole();
  }
  function stop(why) { if (!S) return; if (S.phase !== 'done') { S.phase = 'done'; S.msg = why; } render(); }

  /* ------------------------------------------------------------------ results */
  function reveal() {
    if (!S || S.phase === 'done') return;
    S.phase = 'done';
    const R = S.R, a = S.a, key = R.dw.lines[a.dwi].key;
    if (S.kind === 'tune') {
      const A = prep(R).Aof.get(a.dwi), need = a.o - A + S.lag, eps = S.adj - need;
      const off = Math.sign(eps) * Math.floor(Math.abs(eps) / 2 + 0.5 - 1e-9);
      const e0 = eTrue(), gs = nutGroups(key, a.o, e0 + 30, e0 + 60 * 1000 / VI_MS).slice(0, 6);
      /* a press dead on the middle of each of the line's next Nut groups as the tool would show them with this tuning:
         the tool draws label L at tool time L - (A + adj), i.e. at true time L - o - eps, so the press lands eps VIs off */
      const f = flags(key), tests = gs.map(g => { const ep = 2 * g.i0 + (g.i1 - g.i0 + 1) - eps, lab = evenFloor(2 * Math.floor(ep / 2) + a.o), j = lab / 2;
        return { g, ok: !!(j >= 0 && j < f.b1.length && (g.b === 1 ? f.b1[j] : f.b2[j])) }; });
      S.res = { eps, off, tests, need };
      ST.tune.push({ at: Date.now(), off, dwi: a.dwi, speed: S.speed }); saveST();
    } else if (S.kind === 'read') {
      const ok = !!S.pick && (S.pick.dwi === a.dwi || (S.pick.fam || []).includes(a.dwi));
      const c = comp(), tl = c.lines.find(x => x.dwi === a.dwi || (x.fam || []).includes(a.dwi));
      S.res = { ok, at: S.pick ? S.pick.at : eTool(), pP: S.pick ? S.pick.p : null, pTrue: tl ? tl.p : 0, how: S.pick ? S.pick.how : null, keys: S.logs.length };
      ST.read.push({ at: Date.now(), ok, s: sec(S.res.at), keys: S.logs.length }); saveST();
    }
    render();
  }
  function finishWhole() {
    S.phase = 'done';
    const R = S.R, a = S.a, key = R.dw.lines[a.dwi].key, c = S.cast;
    const right = !!S.pick && (S.pick.dwi === a.dwi || (S.pick.fam || []).includes(a.dwi));
    let tuneOff = null;
    if (S.pick && right) { const eps = (S.pick.A + S.adj) - (a.o + S.lag); tuneOff = Math.sign(eps) * Math.floor(Math.abs(eps) / 2 + 0.5 - 1e-9); }
    /* where the cast landed against this arrival's own Nut frames */
    let near = null;
    if (c) {
      const gs = nutGroups(key, a.o, Math.max(0, c.e - 90), c.e + 90);
      for (const g of gs) { const d = Math.floor(c.e / 2) < g.i0 ? g.i0 - Math.floor(c.e / 2) : Math.floor(c.e / 2) > g.i1 ? Math.floor(c.e / 2) - g.i1 : 0; if (!near || Math.abs(d) < Math.abs(near.d)) near = { g, d: Math.floor(c.e / 2) < g.i0 ? -d : d }; }
    }
    S.res = { right, tuneOff, near };
    ST.whole.push({ at: Date.now(), nut: !!(S.result && S.result.catch === 'N'), right, tuneOff, castNut: !!(c && c.rec && c.rec.nut >= 0) }); saveST();
    render();
  }

  /* ------------------------------------------------------------------ the TV (Thomas's READY screenshot + Jack's frames) */
  const JACK = D.jack && D.jack.facings ? D.jack : null, BEACH = D.beach && D.beach.img ? D.beach : null;
  const imgs = new Map();
  const img = src => { let m = imgs.get(src); if (!m) { m = new Image(); m.src = src; imgs.set(src, m); } return m; };
  function frameOf(a, e) {
    const tot = a.ticks.reduce((x, y) => x + y, 0) || 1;
    let k = Math.max(0, Math.floor(e || 0));
    if (a.loop) k %= tot; else if (k >= tot) return a.frames.length - 1;
    for (let i = 0; i < a.ticks.length; i++) { if (k < a.ticks[i]) return i; k -= a.ticks[i]; }
    return a.frames.length - 1;
  }
  function jackNow() {
    if (!S) return { anim: 'idle', info: `${startTxt()} or Enter starts a drill` };
    const t = now();
    if (t < S.readyAt) { const left = (S.readyAt - t) / 1000; return { anim: 'idle', walk: Math.min(1, left / 1.4), info: S.kind === 'whole' ? `Jack walks to the end of the pier… tap ${startTxt()} the moment he stops` : `READY in ${fx(left, 1)} s` }; }
    const e = eTrue(t), c = S.cast;
    if (S.kind === 'whole' && S.tap == null && S.phase !== 'done') return { anim: 'idle', info: `Jack has stopped: tap ${startTxt()}` };
    if (!c) return { anim: 'idle', info: S.phase === 'done' ? 'done' : S.kind === 'whole' ? `hold ${startTxt()} to cast (it is your B button here)` : 'READY' };
    if (S.result && S.result.none) return { anim: 'idle', info: 'no lab record for a cast on that frame' };
    const d = e - c.e;
    if (S.rel) {
      const r = (t - S.relAt) * S.speed / VI_MS;
      if (S.result && S.result.catch) return r < 34 ? { anim: 'land', e: r, info: 'reeling in…' } : { anim: 'hold', nut: S.result.catch === 'N', info: S.result.catch === 'N' ? 'POWER NUT!' : FISH[S.result.catch] || 'a fish' };
      return { anim: r < 34 ? 'land' : 'idle', e: r, info: 'nothing on the line' };
    }
    if (d < 4) return { anim: 'idle', info: 'cast!' };
    if (d < G_CAST) return { anim: 'cast', e: d - 4, info: 'cast!' };
    for (let i = 0; i < c.bites.length; i++) {
      const b = c.bites[i];
      if (e >= b.e && e < b.e + G_PULL) return { anim: 'bite', e: e - b.e, float: 'floatBite', ft: e - b.e, info: `BITE ${i + 1}` };
      if (e >= b.e + G_PULL && e < b.e + G_PULL + G_RECAST) return { anim: 'wait', info: 'held through it' };
    }
    const last = c.bites[c.bites.length - 1];
    if (!c.bites.length || e > last.e + G_PULL + 400) { if (S.phase !== 'done') { S.result = { end: true }; finishWhole(); } return { anim: 'wait', info: "the lab's record of this cast ends here" }; }
    return { anim: 'wait', float: 'float', ft: d - G_CAST, info: 'waiting for a bite…' };
  }
  function drawTV() {
    const cv = $('prTv'); if (!cv) return;
    const W = 440, H = 352, r = root.devicePixelRatio || 1;
    if (cv.width !== Math.round(W * r)) { cv.width = Math.round(W * r); cv.height = Math.round(H * r); cv.style.width = W + 'px'; cv.style.height = H + 'px'; }
    const g = cv.getContext('2d'); g.setTransform(r, 0, 0, r, 0, 0);
    const st = jackNow();
    g.fillStyle = '#4c6584'; g.fillRect(0, 0, W, H);
    let s = 2, ax = 160, ay = 140;
    if (BEACH) {
      const k = W / BEACH.w, bim = img(BEACH.img), jp = BEACH.jack.SE;
      if (bim.complete && bim.naturalWidth) g.drawImage(bim, 0, 0, BEACH.w * k, BEACH.h * k);
      s = k * BEACH.pxPerNative; ax = (jp[0] - BEACH.x0) * k; ay = (jp[1] - BEACH.y0) * k;
    }
    if (st.walk) { ax -= 70 * st.walk * 0.85 * s / 2; ay -= 70 * st.walk * 0.53 * s / 2; }
    g.imageSmoothingEnabled = false;
    if (JACK) {
      const F = JACK.facings.SE, sc = JACK.scene.SE;
      const draw = (a, i, x, y) => { const m = img(a.frames[i]); if (m.complete && m.naturalWidth) g.drawImage(m, Math.round(x - a.ax * s), Math.round(y - a.ay * s), a.w * s, a.h * s); };
      g.fillStyle = '#0b162466'; g.beginPath(); g.ellipse(ax, ay + 2 * s, 9 * s, 3.5 * s, 0, 0, 6.283); g.fill();
      const an = F[st.anim] || F.idle; draw(an, frameOf(an, st.e), ax, ay);
      if (st.nut && JACK.extras.nut) draw(JACK.extras.nut, 0, ax + sc.held[0] * s, ay + sc.held[1] * s);
      if (st.float && JACK.extras[st.float]) draw(JACK.extras[st.float], frameOf(JACK.extras[st.float], st.ft), ax + sc.float[0] * s, ay + sc.float[1] * s);
    }
    g.fillStyle = '#000a'; g.fillRect(0, H - 22, W, 22); g.fillStyle = '#dce6ec'; g.font = '12px ui-monospace,monospace'; g.textBaseline = 'middle'; g.fillText(st.info || '', 8, H - 11);
    if (S && now() >= S.readyAt && now() < S.readyAt + 600 && S.kind !== 'whole') { g.fillStyle = '#5fd38d'; g.font = 'bold 26px system-ui'; g.fillText('READY', W - 120, 28); }
    /* the dog: an animated sprite in the inset (it sits at the lower-left edge of the TV, beyond this picture) */
    const di = $('prTvDog'); let src = '';
    if (S && !S.cast) { const v = showAt(S.R, S.a.dwi, eTrue() + S.a.o); if (v) src = spr(v[4], v[2]); }
    if (S && S.cast) src = '';
    if (di.dataset.src !== src) { di.dataset.src = src; di.src = src || 'data:,'; di.style.visibility = src ? 'visible' : 'hidden'; }
    $('prTvDogNote').textContent = S && S.cast ? 'after the cast the dog takes a new path (not shown here)' : S ? '' : 'the dog';
  }

  /* ------------------------------------------------------------------ the tool side */
  let flashTxt = '', flashAt = 0;
  const flash = t => { flashTxt = t; flashAt = now(); };
  /* the cards are built once per layout and then updated in place: a rebuilt <img> would restart its animated GIF */
  let cardMode = '';
  const setImg = (im, src) => { if (!im) return; if (im.dataset.src !== src) { im.dataset.src = src; im.src = src || 'data:,'; im.style.visibility = src ? 'visible' : 'hidden'; } };
  const dogAt = (R, dwi, k) => { const v = showAt(R, dwi, k); return v ? spr(v[4], v[2]) : ''; };
  function renderCards() {
    const box = $('prCardsBox');
    if (!S || !toolOn()) {
      const m = 'msg:' + (S && S.kind === 'whole' && S.tap == null ? `The dog cards start with your ${esc(startTxt())} tap when Jack stops.` : 'The dog cards appear at READY.');
      if (cardMode !== m) { cardMode = m; box.innerHTML = `<div class="mut">${m.slice(4)}</div>`; }
      return;
    }
    const R = S.R, c = comp();
    if (S.pick) {
      const m = 'cal:' + S.pick.dwi;
      if (cardMode !== m) {
        cardMode = m;
        box.innerHTML = `<div class="prcal"><div class="prbig"><img alt="" data-d="0"><div><b>${lineName(R, S.pick.dwi)}</b> <span class="prp"></span> <span class="prset prok"></span></div></div>` +
          `<div class="prthree"><div><img alt="" data-d="-2"><span>1 frame earlier</span></div><div class="mid"><img alt="" data-d="0"><span>tuned</span></div><div><img alt="" data-d="2"><span>1 frame later</span></div></div>` +
          `<div class="prmoved mono"></div>${S.kind === 'whole' ? '<div class="small mut">Click the dog or Backspace: back to the cards.</div>' : ''}</div>`;
        const big = box.querySelector('.prbig'); if (S.kind === 'whole') big.onclick = () => pick(S.pick.dwi, 'click');
      }
      const x = c.lines.find(l => l.dwi === S.pick.dwi || (l.fam || []).includes(S.pick.dwi)), k = cardK(S.pick.dwi, S.pick.A);
      for (const im of box.querySelectorAll('img[data-d]')) setImg(im, dogAt(R, S.pick.dwi, k + +im.dataset.d));
      box.querySelector('.prp').textContent = S.kind !== 'tune' && x ? pct(x.p) : '';
      box.querySelector('.prset').textContent = S.tuned ? 'timing set' : '';
      box.querySelector('.prmoved').textContent = `moved ${S.adj >= 0 ? '+' : '−'}${Math.abs(S.adj / 2)} frame${Math.abs(S.adj) === 2 ? '' : 's'} (${S.adj >= 0 ? '+' : '−'}${Math.round(Math.abs(S.adj) * VI_MS)} ms)`;
      return;
    }
    const n = Math.min(K.cards, c.lines.length), m = 'cards:' + n + ':' + K.fill;
    if (cardMode !== m) {
      cardMode = m;
      box.innerHTML = `<div class="prcards">${Array.from({ length: n }, () => `<div class="prcard"><img alt=""><div class="nm"></div><div class="pp"></div><div class="prtop">Enter</div></div>`).join('')}</div>`;
      for (const el of box.querySelectorAll('.prcard')) el.onclick = () => pick(+el.dataset.dwi, 'click');
    }
    const show = c.lines.slice(0, n), slots = [...box.querySelectorAll('.prcard')];
    const order = K.fill === 'rtl' ? show.slice().reverse() : K.fill === 'mid' ? (() => { const o = []; show.forEach((x, i) => { if (i % 2) o.unshift(x); else o.push(x); }); return o; })() : show;
    order.forEach((x, i) => {
      const el = slots[i]; if (!el) return;
      el.dataset.dwi = x.dwi; el.classList.toggle('top', x === c.lines[0]);
      el.title = 'Click: this is my dog' + (x === c.lines[0] ? ' (or Enter: it is the top card)' : '');
      setImg(el.querySelector('img'), dogAt(R, x.dwi, cardK(x.dwi, x.A)));
      const nm = `<b>${lineName(R, x.dwi)}</b>${x.fam && x.fam.length > 1 ? ` <span class="mut">+${x.fam.length - 1}</span>` : ''}`;
      if (el.querySelector('.nm').innerHTML !== nm) el.querySelector('.nm').innerHTML = nm;
      const pp = el.querySelector('.pp'), pt = pct(x.p) + (x.p >= 0.9 ? ' LOCKED' : '');
      if (pp.textContent !== pt) pp.textContent = pt;
      pp.className = 'pp ' + (x.p >= 0.9 ? 'prok' : 'mut');
    });
  }
  function logHtml() {
    if (!S || S.kind === 'tune' || !S.logs.length) return '';
    return '<div class="prlog mono small">' + S.logs.slice(-8).map(l => `${fx(sec(l.t - 1), 1)} s ${l.f != null ? ARROW[l.f] + ' ' + FACING[l.f] : (K.groups.find(g => g.gid === l.g) || { label: 'animation' }).label}`).join(' · ') + '</div>';
  }
  /* drill 3: the picked dog's own Nut frames at the tuned timing, as freestyle draws them (the tool's view, not the truth) */
  function drawLane() {
    const cv = $('prLane'); if (!cv) return;
    const box = cv.parentElement, W = Math.max(300, box.clientWidth - 2), H = 96, r = root.devicePixelRatio || 1;
    if (cv.width !== Math.round(W * r) || cv.height !== Math.round(H * r)) { cv.width = Math.round(W * r); cv.height = Math.round(H * r); cv.style.width = W + 'px'; cv.style.height = H + 'px'; }
    const g = cv.getContext('2d'); g.setTransform(r, 0, 0, r, 0, 0);
    g.fillStyle = '#0b141c'; g.fillRect(0, 0, W, H);
    const lane = $('prLaneTxt');
    if (!S || S.kind !== 'whole' || !S.pick || !toolOn()) { lane.textContent = S && S.kind === 'whole' && toolOn() ? 'Pick your dog (Enter = the top card, or click one): its own Nut frames appear here.' : ''; return; }
    const R = S.R, key = R.dw.lines[S.pick.dwi].key, f = flags(key), off = S.pick.A + S.adj, e = S.cast ? S.cast.e - S.lag : eTool();
    const pxS = W / 14, x0 = W * 0.18, X = ee => x0 + sec(ee - e) * pxS, base = H - 16;
    g.strokeStyle = '#2b3f4f'; g.beginPath(); g.moveTo(0, base + 0.5); g.lineTo(W, base + 0.5); g.stroke();
    let next = null;
    if (f) for (let i = Math.max(0, Math.floor((e - 3 * 1000 / VI_MS) / 2)); 2 * i < e + 12 * 1000 / VI_MS; i++) {
      const lab = evenFloor(2 * i + off), j = lab / 2; if (j < 0 || j >= f.b1.length) continue;
      const b = f.b1[j] ? 1 : f.b2[j] ? 2 : 0; if (!b) continue;
      const x = X(2 * i);
      g.fillStyle = b === 1 ? '#5fd38d' : '#e7c14a'; g.fillRect(Math.round(x), 14, Math.max(2, Math.round(2 * VI_MS / 1000 * pxS) - 1), base - 14);
      if (2 * i >= e && !next) next = { i, b };
    }
    g.fillStyle = '#ffffff'; g.fillRect(Math.round(x0), 4, 2, base - 2);
    g.fillStyle = '#8ea3b2'; g.font = '11px system-ui'; g.textBaseline = 'top';
    for (let s = Math.ceil(sec(e - 3 * 1000 / VI_MS)); s <= sec(e) + 12; s++) { const x = X(s * 1000 / VI_MS); if (x > 0 && x < W) { g.fillRect(Math.round(x), base, 1, 4); g.fillText(String(s), x - 4, base + 4); } }
    if (S.cast) { lane.textContent = 'Cast. Watch the float on the TV: let go at the bite (green = the 1st bite, gold = hold the 1st, let go at the 2nd).'; return; }
    if (next) {                                                   // the group it starts
      let i1 = next.i; while (true) { const lab = evenFloor(2 * (i1 + 1) + off), j = lab / 2; if (j < f.b1.length && (next.b === 1 ? f.b1[j] : f.b2[j])) i1++; else break; }
      const n = i1 - next.i + 1;
      lane.innerHTML = `<b>NEXT ${n >= 3 ? 'TRIPLE' : n === 2 ? 'DOUBLE' : 'SINGLE'} · ${next.b === 1 ? '<span style="color:#5fd38d">GREEN</span> (let go at the 1st bite)' : '<span style="color:#e7c14a">GOLD</span> (hold the 1st, let go at the 2nd)'}</b> in ${fx(sec(2 * next.i - e), 1)} s · hold ${esc(startTxt())} on it to cast`;
    } else lane.textContent = 'No Nut frame for this dog in the next 12 s.';
  }
  function revealHtml() {
    if (!S || S.phase !== 'done') return '';
    const R = S.R, a = S.a, nm = lineName(R, a.dwi), A = prep(R).Aof.get(a.dwi);
    const tmg = Math.round((a.o - A) / 2), tmTxt = tmg === 0 ? 'its usual timing' : `${Math.abs(tmg)} frame${Math.abs(tmg) === 1 ? '' : 's'} ${tmg > 0 ? 'ahead of' : 'behind'} its usual timing`;
    if (S.msg === 'stopped') return `<div class="mut">Stopped. ${esc(startTxt())} or Enter for another dog.</div>`;
    if (S.kind === 'tune') {
      const r = S.res, n = Math.abs(r.off);
      const head = r.off === 0 ? '<b class="prok">In step ✓</b>' : `<b class="prbad">${n} frame${n === 1 ? '' : 's'} off</b> (${Math.round(n * 2 * VI_MS)} ms): ${n} more press${n === 1 ? '' : 'es'} of <kbd>${keyTxt(r.off > 0 ? K.adj[0] : K.adj[1])}</kbd> would have put it in step`;
      return `${head}. The dog was <b>${nm}</b> at ${tmTxt}; your tap was ${Math.round(Math.abs(S.lag) * VI_MS)} ms ${S.lag > 0 ? 'late' : 'early'}.` +
        (r.tests.length ? `<div style="margin-top:4px">Its next Nut casts, pressed dead on the middle with your tuning: ${r.tests.map(x => `<span class="prchip ${x.ok ? 'ok' : 'bad'}">${fx(sec(2 * x.g.i0), 1)} s ${x.g.i1 - x.g.i0 >= 2 ? 'triple' : x.g.i1 > x.g.i0 ? 'double' : 'single'} ${x.ok ? '✓' : '✗'}</span>`).join(' ')}` +
          ` — ${r.tests.filter(x => x.ok).length} of ${r.tests.length} land on a Nut frame. ${r.off === 0 ? 'In step, every one of them does.' : 'One frame off already misses every single; a double forgives one frame on one side.'}</div>` : '') +
        `<div class="mut" style="margin-top:4px">${esc(startTxt())} or Enter: next dog.</div>`;
    }
    if (S.kind === 'read') {
      const r = S.res;
      if (!S.pick) return `Time's up. The dog was <b>${nm}</b> (${tmTxt}). <span class="mut">${esc(startTxt())} or Enter: next dog.</span>`;
      return `${r.ok ? '<b class="prok">Right ✓</b>' : '<b class="prbad">Not this one</b>'}: you picked <b>${lineName(R, S.pick.dwi)}</b>${r.how === 'enter' ? ' (Enter, the top card)' : ''} at ${fx(sec(r.at), 1)} s, when the tool gave it ${pct(r.pP)}; ` +
        `the dog was <b>${nm}</b>${r.ok ? '' : `, at ${pct(r.pTrue)} then`}. ${r.keys} key${r.keys === 1 ? '' : 's'} pressed.` +
        (!r.ok && r.pP < 0.5 ? ' The pick came while the tool still saw other dogs as likely: one or two more keys usually settle it.' : '') +
        ` <span class="mut">${esc(startTxt())} or Enter: next dog.</span>`;
    }
    const r = S.res, res = S.result || {}, c = S.cast;
    const what = res.none ? 'No lab record for a cast at that moment (too late in the morning).' : res.end ? "You held on past the last bite the lab recorded for that cast." : res.catch ? `You let go at bite ${res.n}: <b>${FISH[res.catch]}</b>.` : res.empty ? `You let go ${res.early ? 'before the first bite' : 'between bites'}: nothing on the line.` : '';
    const cn = c && c.rec ? (c.rec.nut >= 0 ? `This cast frame had the Nut on <b>bite ${c.rec.nut + 1}</b>.` : 'This cast frame had no Nut on any bite.') : '';
    const nr = r.near ? (r.near.d === 0 ? 'Your cast landed on one of this dog\'s Nut frames.' : `The nearest Nut frame was ${Math.abs(r.near.d)} frame${Math.abs(r.near.d) === 1 ? '' : 's'} ${r.near.d < 0 ? 'later' : 'earlier'} than your cast.`) : '';
    return `${what} ${cn} ${nr}<div style="margin-top:4px">The dog was <b>${nm}</b> (${tmTxt}); ${S.pick ? `you picked <b>${lineName(R, S.pick.dwi)}</b> ${r.right ? '✓' : '✗'}` : 'you picked no dog'}` +
      (r.tuneOff != null ? `, tuned ${r.tuneOff === 0 ? 'in step ✓' : Math.abs(r.tuneOff) + ' frame' + (Math.abs(r.tuneOff) === 1 ? '' : 's') + ' off'}` : '') + `; your tap at READY was ${Math.round(Math.abs(S.lag) * VI_MS)} ms ${S.lag > 0 ? 'late' : 'early'} after your ${K.delayMs} ms reaction.</div>` +
      `<div class="mut">${esc(startTxt())} or Enter: another attempt.</div>`;
  }
  function statsHtml() {
    const tn = ST.tune || [], rd = ST.read || [], wh = ST.whole || [];
    const last = (a, n) => a.slice(-n);
    const t = last(tn, 30), r = last(rd, 30), w = last(wh, 30);
    return `<b>Your last 30</b> · Tune: ${t.length ? `${t.filter(x => x.off === 0).length} of ${t.length} in step, ${fx(t.reduce((q, x) => q + Math.abs(x.off), 0) / t.length, 1)} frames off on average` : '—'}` +
      ` · Read: ${r.length ? `${r.filter(x => x.ok).length} of ${r.length} right, picked after ${fx(r.reduce((q, x) => q + x.s, 0) / r.length, 1)} s on average` : '—'}` +
      ` · Whole: ${w.length ? `${w.filter(x => x.nut).length} Nut${w.filter(x => x.nut).length === 1 ? '' : 's'} in ${w.length}, right dog ${w.filter(x => x.right).length}, cast on a Nut frame ${w.filter(x => x.castNut).length}` : '—'}` +
      ` <button id="prClearStats" class="small">clear</button>`;
  }

  /* ------------------------------------------------------------------ keys panel (read from the Lucky Timer, changeable here) */
  let cap = null;                                                 // a key being set: {kind, slot}
  const SRC_TXT = { lucky: 'your Lucky Timer settings', page: 'set on this page', default: "the Lucky Timer's defaults" };
  function renderKeys() {
    if (!K || !$('prKeys')) return;
    const fac = K.facing === 'wasd' ? ['KeyW', 'KeyA', 'KeyS', 'KeyD'].map(keyTxt).join(' ') : '← ↑ → ↓';
    const anims = K.groups.slice().sort((a, b) => a.gid - b.gid).map(g => `<kbd>${esc(keyTxt(g.code))}</kbd> ${esc(g.label)}`).join(' · ');
    $('prKeys').innerHTML = `<div><b>Your keys</b> <span class="mut">(${SRC_TXT[K.src]})</span> · <kbd>${esc(fac)}</kbd> the dog's facing (two at once = a diagonal) · ${anims} · ` +
      `<kbd>${esc(keyTxt(K.adj[0]))}</kbd> <kbd>${esc(keyTxt(K.adj[1]))}</kbd> tune earlier / later (+Shift: 10 frames) · <kbd>Enter</kbd> pick the top dog, again: timing set · <kbd>Backspace</kbd> undo · <kbd>${esc(startTxt())}</kbd> start / tap at READY / B in the whole attempt · <kbd>Esc</kbd> stop ` +
      `<button id="prKeyEdit" class="small">${$('prKeyEd') && !$('prKeyEd').hidden ? 'close' : 'change'}</button></div>`;
    $('prKeyEdit').onclick = () => { const ed = $('prKeyEd'); ed.hidden = !ed.hidden; if (!ed.hidden) renderKeyEd(); renderKeys(); };
  }
  function shownBases() {
    const R = route(), seen = new Map();
    for (const l of R.dw.lines) for (const v of l.vis) if (v[0] < 1200) seen.set(v[4], (seen.get(v[4]) || 0) + (v[1] - v[0]) * l.w);
    return [...seen.entries()].sort((a, b) => b[1] - a[1]).map(x => x[0]);
  }
  function renderKeyEd(why) {
    const ed = $('prKeyEd'); if (!ed || ed.hidden) return;
    const cell = (kind, slot, code) => `<button class="prkey${cap && cap.kind === kind && cap.slot === slot ? ' on' : ''}" data-kind="${kind}" data-slot="${slot}">${cap && cap.kind === kind && cap.slot === slot ? 'press a key…' : esc(keyTxt(code))}</button>`;
    ed.innerHTML = `<div class="row"><b>Facing</b> <select id="prFac"><option value="arrows">arrow keys</option><option value="wasd">${esc(['KeyW', 'KeyA', 'KeyS', 'KeyD'].map(keyTxt).join(' '))} (W A S D positions)</option></select>` +
      ` <b>Tune</b> earlier ${cell('adj', 0, K.adj[0])} later ${cell('adj', 1, K.adj[1])} <b>Start / B</b> <button class="prkey${cap && cap.kind === 'start' ? ' on' : ''}" data-kind="start" data-slot="0">${cap && cap.kind === 'start' ? 'press a key…' : esc(startTxt())}</button></div>` +
      `<div class="prkeygrid">${shownBases().map(b => `<span><img alt="" src="${spr(b, 0)}"> ${esc(nameOf(b))} ${cell('anim', b, K.anim[b])}</span>`).join('')}</div>` +
      `<div class="row small">${why ? `<span class="prbad">${esc(why)}</span>` : '<span class="mut">Click a key, then press the new one (Backspace on an animation = no key; Esc = cancel). Animations that share a key count as one.</span>'}` +
      ` <span style="flex:1"></span><button id="prKeyLucky">use my Lucky Timer keys</button></div>`;
    $('prFac').value = K.facing;
    $('prFac').onchange = ev => { saveKeys({ dwKeys: ev.target.value }); ev.target.blur(); };
    for (const b of ed.querySelectorAll('button.prkey')) b.onclick = () => { cap = { kind: b.dataset.kind, slot: b.dataset.kind === 'anim' ? +b.dataset.slot : +b.dataset.slot }; renderKeyEd(); };
    $('prKeyLucky').onclick = () => { delete PS.keys; savePS(); loadKeys(); renderKeys(); renderKeyEd(); };
  }
  function saveKeys(ch) {
    const cur = { dwKeys: K.facing, dwAnimKeys: Object.assign({}, K.anim), dwAdjKeys: K.adj.slice(), startKey: K.startKey };
    PS.keys = Object.assign(cur, ch); savePS(); loadKeys(); renderKeys(); renderKeyEd();
  }
  document.addEventListener('keydown', e => {
    if (!cap) return;
    e.preventDefault(); e.stopPropagation();
    const c = e.code || '';
    if (c === 'Escape') { cap = null; renderKeyEd(); return; }
    if (cap.kind === 'start') { if (/^(Shift|Control|Alt|Meta|OS)/.test(c)) return; if (['Enter', 'Escape', 'Backspace', 'Tab'].includes(e.key)) { renderKeyEd(`${e.key} is taken`); return; } const x = cap; cap = null; void x; saveKeys({ startKey: e.key }); return; }
    if (cap.kind === 'anim' && (c === 'Backspace' || c === 'Delete')) { const a = Object.assign({}, K.anim, { [cap.slot]: '' }); cap = null; saveKeys({ dwAnimKeys: a }); return; }
    if (!c || /^(Shift|Control|Alt|Meta|OS)/.test(c)) return;
    const fac = Object.keys(DIRKEY[K.facing]);
    let why = null;
    if (['Enter', 'NumpadEnter', 'Escape', 'Backspace', 'Delete', 'Tab'].includes(c) || e.key === K.startKey) why = `${keyTxt(c)} is taken by the tool`;
    else if (fac.includes(c)) why = `${keyTxt(c)} is a facing key`;
    else if (cap.kind === 'anim' && K.adj.includes(c)) why = `${keyTxt(c)} tunes the dog`;
    else if (cap.kind === 'adj' && K.adj[1 - cap.slot] === c) why = `${keyTxt(c)} is the other tuning key`;
    else if (cap.kind === 'adj' && Object.values(K.anim).includes(c)) why = `${keyTxt(c)} is an animation key`;
    if (why) { renderKeyEd(why); return; }
    const x = cap; cap = null;
    if (x.kind === 'anim') saveKeys({ dwAnimKeys: Object.assign({}, K.anim, { [x.slot]: c }) });
    else { const a = K.adj.slice(); a[x.slot] = c; saveKeys({ dwAdjKeys: a }); }
  }, true);

  /* ------------------------------------------------------------------ the page */
  const DRILLS = [['tune', '1 · Tune the dog'], ['read', '2 · Read the dog'], ['whole', '3 · Whole attempt']];
  const HOWTO = {
    tune: () => `A dog plays on the TV at its true timing. Its card (right) plays at the tool's guess of your timing: your tap at READY off by up to 150 ms, and the line reached a few frames earlier or later than usual. Step the card with <kbd>${esc(keyTxt(K.adj[0]))}</kbd> <kbd>${esc(keyTxt(K.adj[1]))}</kbd> until it turns at the very same moment as the TV dog, then press <kbd>Enter</kbd>. The three small frames show one frame either way. Slow the TV down to learn what "in step" looks like.`,
    read: () => `A dog plays on the TV. Key what you see, as on the Lucky Timer: its facing with <kbd>${K.facing === 'wasd' ? esc(['KeyW', 'KeyA', 'KeyS', 'KeyD'].map(keyTxt).join(' ')) : 'the arrow keys'}</kbd> whenever it turns (two at once = a diagonal), long animations on their keys. Every key re-weights the dog lines the way the Lucky Timer does. When the top card is your dog, press <kbd>Enter</kbd> (or click the card that is).`,
    whole: () => `The real thing, start to finish. Tap <kbd>${esc(startTxt())}</kbd> the moment Jack stops at the end of the pier. Read the dog and press <kbd>Enter</kbd> for the top card (or click yours), tune it with <kbd>${esc(keyTxt(K.adj[0]))}</kbd> <kbd>${esc(keyTxt(K.adj[1]))}</kbd>, <kbd>Enter</kbd> when it is in step. Its Nut frames then show under the TV: <b>hold ${esc(startTxt())}</b> on one to cast (here it is your B button) and <b>let go</b> when the float bites — the 1st bite for green, the 2nd for gold. The catch comes from the lab's record of the exact frame you cast on. Jack stays awake by himself in this drill.`,
  };
  function build() {
    loadKeys();
    const R = route(), P = prep(R);
    $('prDrills').innerHTML = DRILLS.map(([id, t]) => `<button data-d="${id}" class="${PS.drill === id ? 'on' : ''}">${t}</button>`).join('');
    for (const b of $('prDrills').querySelectorAll('button')) b.onclick = () => { PS.drill = b.dataset.d; savePS(); S = null; build(); b.blur(); };
    $('prSpeed').value = String(PS.speed); $('prSpeed').onchange = e => { setSpeed(+e.target.value); e.target.blur(); };
    $('prSpeedBox').hidden = PS.drill === 'whole';
    $('prLine').innerHTML = `<option value="any">any dog, by how often the route reaches it</option>` + P.lines.slice(0, 60).map(l => `<option value="${l.dwi}">${lineName(R, l.dwi)} · ${pct(l.p)} of arrivals</option>`).join('');
    if (PS.line !== 'any' && !P.lines.some(l => String(l.dwi) === String(PS.line))) PS.line = 'any';
    $('prLine').value = String(PS.line); $('prLine').onchange = e => { PS.line = e.target.value; savePS(); e.target.blur(); };
    $('prSparBox').hidden = !SPAR; $('prSpar').checked = !!PS.sparrow;
    $('prSpar').onchange = e => { PS.sparrow = e.target.checked; if (PS.line !== 'any') PS.line = 'any'; savePS(); S = null; e.target.blur(); build(); };
    $('prHow').innerHTML = HOWTO[PS.drill]();
    $('prStart').onclick = e => { newDrill(PS.drill); e.target.blur(); };
    $('prLaneBox').hidden = PS.drill !== 'whole';
    renderKeys();
    render();
  }
  function render() {
    if (!K) return;
    renderCards();
    const lg = logHtml(); if ($('prLog').dataset.h !== lg) { $('prLog').dataset.h = lg; $('prLog').innerHTML = lg; }
    const st = !S ? `Press <kbd>${esc(startTxt())}</kbd> or <kbd>Enter</kbd> (or the button) for a dog.` : S.phase === 'done' ? '' : now() < S.readyAt ? 'Get ready…'
      : S.kind === 'tune' ? `Tune the card, <kbd>Enter</kbd> when in step.` : S.kind === 'read' ? `Key what the dog does; <kbd>Enter</kbd> = the top card is mine.` : S.tap == null ? `Tap <kbd>${esc(startTxt())}</kbd> when Jack stops.` : !S.pick ? 'Read the dog, Enter for the top card.' : !S.cast ? (S.tuned ? `Hold <kbd>${esc(startTxt())}</kbd> on a Nut bar to cast.` : 'Tune it, Enter when in step.') : 'Let go at the bite.';
    $('prState').innerHTML = (flashTxt && now() - flashAt < 900 ? `<b class="prflash">${esc(flashTxt)}</b> · ` : '') + st;
    const rv = revealHtml(); if ($('prReveal').dataset.h !== rv) { $('prReveal').dataset.h = rv; $('prReveal').innerHTML = rv; }
    const sh = statsHtml(); if ($('prStats').dataset.h !== sh) { $('prStats').dataset.h = sh; $('prStats').innerHTML = sh; $('prClearStats').onclick = () => { if (confirm('Clear your practice results on this page?')) { ST.tune = []; ST.read = []; ST.whole = []; saveST(); render(); } }; }
  }
  function loop() {
    if (S && S.phase !== 'done' && S.kind === 'read' && started() && sec(eTool()) > 20) { S.msg = ''; reveal(); }
    if (S && S.phase !== 'done' && S.kind === 'tune' && started() && sec(eTrue()) > 90) reveal();
    drawTV(); drawLane(); render();
    root.requestAnimationFrame(loop);
  }
  build();
  root.requestAnimationFrame(loop);
  root.HM64Practice = { get S() { return S; }, get K() { return K; }, newDrill, comp, prep, route, flags, castOf, nutGroups, keyTxt, loadKeys, eTrue, eTool, reveal, pick, ST, PS, showAt, lineName };
})(typeof window !== 'undefined' ? window : globalThis);
