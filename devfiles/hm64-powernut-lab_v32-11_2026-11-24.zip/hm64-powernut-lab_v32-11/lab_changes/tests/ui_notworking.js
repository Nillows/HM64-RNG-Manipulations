/* headless (v32.7): the tool pages' footer has Guide and Not working?; the button opens a checklist (a dialog) whose
   links go to the guide's answers for this page's game file, in a new tab; keys inside it stay inside; Esc closes. */
(function () {
  const t0 = Date.now();
  const go = () => {
    const $ = id => document.getElementById(id), out = { errors: [] };
    if (!$('nwDlg') && Date.now() - t0 < 60000) return setTimeout(go, 300);
    try {
      const btn = $('nwBtn');
      out.footer = [...document.querySelectorAll('footer .arena a')].map(a => [a.textContent, a.getAttribute('href'), a.getAttribute('target')]);
      out.closedBefore = !$('nwDlg').open;
      btn.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, button: 0 }));
      out.opened = $('nwDlg').open;
      out.links = [...$('nwDlg').querySelectorAll('a')].map(a => [a.textContent, a.getAttribute('href'), a.getAttribute('target')]);
      let leaked = 0; const h = () => { leaked++; }; document.addEventListener('keydown', h);
      $('nwDlg').querySelector('a').dispatchEvent(new KeyboardEvent('keydown', { key: ' ', bubbles: true }));
      document.removeEventListener('keydown', h); out.keyLeaked = leaked;
      $('nwDlg').close(); out.closedAfter = !$('nwDlg').open;
      const ev = new MouseEvent('click', { bubbles: true, cancelable: true, button: 0, ctrlKey: true });
      btn.addEventListener('click', e => e.preventDefault(), { once: true });       // keep the headless page here
      btn.dispatchEvent(ev); out.ctrlOpensDialog = $('nwDlg').open;
      out.items = (window.HM64NotWorking || {}).items;
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const p = document.createElement('pre'); p.id = 'testout'; p.textContent = JSON.stringify(out); document.body.appendChild(p);
  };
  setTimeout(go, 500);
})();
