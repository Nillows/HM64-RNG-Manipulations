/* headless (v32.7): the guide page. Every section and every Not working? answer is there, the forest pictures are
   referenced, and the game file opens as the hub's ticks say (pre_guide_hub.js seeds them: horse ticked) with the
   picker switching it. */
(function () {
  setTimeout(() => {
    const out = { errors: [] };
    try {
      const ids = [...document.querySelectorAll('[id]')].map(e => e.id);
      out.ids = ['setup', 'route', 'menus', 'sparrows', 'path', 'beach', 'space', 'awake', 'not-working', 'how-it-works'].filter(i => !ids.includes(i));
      out.nw = ids.filter(i => i.startsWith('nw-'));
      out.sets = [...document.querySelectorAll('details.set')].map(d => [d.id, d.open, d.classList.contains('yours')]);
      out.imgs = [...document.querySelectorAll('figure img')].map(i => i.getAttribute('src'));
      out.navs = [...document.querySelectorAll('nav.top a')].map(a => a.getAttribute('href'));
      const b = [...document.querySelectorAll('#gdPicks button')].find(x => x.dataset.set === 'sunny-no-horse');
      b.click();
      out.after = [...document.querySelectorAll('details.set')].map(d => [d.id, d.open, d.classList.contains('yours')]);
      out.pages = [...document.querySelectorAll('#setup-sunny-horse .pages a')].map(a => a.getAttribute('href'));
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const p = document.createElement('pre'); p.id = 'testout'; p.textContent = JSON.stringify(out); document.body.appendChild(p);
  }, 300);
})();
