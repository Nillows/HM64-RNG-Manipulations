/* headless (v32.11): the deck page. 52 cards in new deck order; take one out, pick the goal; stacking gives 51 cards
   (no removed card, the goal in it) in a seeded order and a random grid; the goal card is on top exactly on the dog
   line's Nut frames; the first deck click starts the moments (0.33 s each), press + let go draws: one draw, its card
   flipped in the grid, a new deck after it. */
(function () {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => {
    const $ = id => document.getElementById(id), out = { errors: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    try {
      const D = window.HM64Deck;
      out.board = [...$('board').children].map(e => e.title);
      D.pick('2♥'); D.pick('A♠');
      out.pickTxt = $('pickTxt').textContent;
      $('stackBtn').click();
      const s = D.state();
      out.n = s.stack.length; out.hasRemoved = s.stack.includes('2♥'); out.hasGoal = s.stack.includes('A♠');
      out.cellsSame = s.cells.slice().sort().join() === s.stack.slice().sort().join();
      out.seedTxt = $('seedTxt').textContent;
      const nut = s.line.nut; let bad = 0;
      for (let f = 0; f < s.line.n; f++) { const g = D.top(f) === 'A♠'; if (g !== nut.includes(f)) bad++; if (D.top(f) === '2♥') bad++; }
      out.topBad = bad; out.lineN = s.line.n; out.nutN = nut.length;
      $('deck').dispatchEvent(new PointerEvent('pointerup'));               // start
      await sleep(2000); D.step();
      out.frameAfter2s = D.state().frame;
      $('tool').click(); await sleep(400); D.step();
      out.lamp = $('lamp').textContent; out.strip = $('strip').children.length;
      $('deck').dispatchEvent(new PointerEvent('pointerdown')); await sleep(340); D.step(); out.reachFrame = D.state().frame;
      out.reachingStatus = $('status').textContent;
      $('deck').dispatchEvent(new PointerEvent('pointerup'));
      const s2 = D.state(); out.draws = s2.draws; out.log = $('log').textContent.split('\n')[0];
      out.flipped = [...$('grid').children].filter(c => !c.classList.contains('back')).length;
      await sleep(1500);
      out.afterDrawRunning = D.state().running; out.newSeedLine = D.state().line !== s.line || D.state().stack.join() !== s.stack.join();
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const p = document.createElement('pre'); p.id = 'testout'; p.textContent = JSON.stringify(out); document.body.appendChild(p);
  }, 300);
})();
