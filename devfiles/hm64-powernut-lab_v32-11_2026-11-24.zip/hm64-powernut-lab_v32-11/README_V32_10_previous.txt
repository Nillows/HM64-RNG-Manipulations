HM64 Power Nut Tool v32.10 (2026-11-24): the forest's sunlight, and key : value pairs
=====================================================================================

What you asked for (2026-11-24 14:14)
  "When explaining the sunlight concept, use more wording that reminds people it is in the context of the forest
  analogy ... it can be confusing because the weather dynamic of sunny vs rainy cast tables. Also, should have a few
  examples of actual rng values as keys and the different dog states as values ... #:a,b format. It will help people
  actually see the limitations that are imposed." + the base-drift / an-hour-of-sunlight-on-a-plant wording.

What changed (v32.10 includes v32.7 - v32.9)
  - README "Sunlight" is now "Sunlight (the forest's sunlight - not the game's weather)": the base drift of the random
    number on each screen with nothing extra drawing on it, shining on the canopy as you travel to READY; it changes
    how a branch grows in the same time, not how tall it gets (an hour of sun on a plant, not its age); what counts is
    each place's drift and how long you stand under it; rain = the game's weather, yet the most forest sunlight.
  - The pier moment speaks of the forest's sunlight / the light on the forest, and has real key : value pairs
    (random number : the dog's action, facing, timer) from Sunny -> Horse: L1 as Jack stops and on its next 3 frames,
    L2 and L3 as Jack stops; L1 two frames on and L2 share the key -117721573 with different dogs = two branches. Then
    the limits: 4,294,967,296 keys x the dog's couple of dozen actions x 8 facings x its timer (x its spot).
    Action names are the decomp's (updateDog's switch: 0 standing, 5 barking, 10 digging, ...).
  - Pictures: "Forest sunlight: how each screen grows the branch" (subtitle: not the game's weather; a line on rain);
    "One future: when the forest's sunlight stops changing" now lists the key : value rows. Guide captions likewise.
  - Toolkit: forest_facts.py "pairs" (from the run's Z6_lines.jsonl observe records: the draw count on a frame = the
    last recorded absolute count + one per game frame since), DOG_ACTIONS; forest_svg.py Svg.mono().
  - Page data unchanged (byte-equal to v32.9 apart from the version).

Release
  bash ~/Documents/hm64/tools/hm64_release.sh v32-10 <lab sha256> <pages sha256> </dev/null
  (v32.7 - v32.9 not released? skip them: v32.10 has everything)
