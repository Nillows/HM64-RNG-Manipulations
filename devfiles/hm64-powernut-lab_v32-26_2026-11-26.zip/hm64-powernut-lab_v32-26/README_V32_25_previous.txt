HM64 Power Nut Tool v32.25 (2026-11-26) - rainy tables with the gap campaign's results

WHAT CHANGED
- Both rainy files: the zone tables (North / Middle / South / Not sure) are rebuilt with the gap campaign "gaps-rainy"
  (both Macs, 12:49-15:43, 3,083 + 2,091 cast jobs = 75,792 casts held to the end of the cast data, all planned jobs
  present, no duplicates). Nothing is marked "not proven here" any more:
    * the 3 + 1 dog lines never cast away from the north end are now cast from the middle and the south (part A);
    * every recorded Nut "not proven" in a zone was cast there (B1): confirmed in the middle for about 3 of 4, in the
      south for about half; the others are fish there;
    * every cast that differs in a zone was held to label 10198 (B2).
- Builder fix (tools/zone_build.py): a measurement that ran PAST the moment of a recorded bite without that bite now
  counts as another future (the zone's own cast); before, such a Nut stayed "not proven". Among measurements of equal
  length the one held longest is used. tools/zone_verify.py (unchanged, independent): ok - 0 contradicted, both files.
- tools/hm64_labdata.sh rev 2026-11-26i: a zip whose contents (names, sizes, CRCs) equal the copy already on lab-data
  is not uploaded again (the two Macs kept replacing each other's 70 MB married dog-watch zips).
- Texts: guide 3.3, Not working?, the zone note and help, README rainy section (zone table, cue list, line table rows
  L6 / L7 / L9, wide windows, page sizes 24-50 MB).

NUMBERS (cast frames with a Nut on bites 1-6; no horse / horse)          v32.23 -> v32.25
  north      16,823 / 11,036   (the recording, unchanged)
  middle     12,630 -> 14,356 / 8,660 -> 9,719     (only there: 834 -> 1,110 / 650 -> 743)
  south      12,202 -> 13,594 / 8,381 -> 9,205     (only there: 899 -> 1,161 / 700 -> 768)
  not sure   12,620 -> 13,729 / 8,703 -> 9,446
  not proven  2,012+554 / 2,124+566 -> 0 ;  horse 1,081+137 / 1,089+146 -> 0
  By cast time (zone / north): first minute 99-101%; 60-120 s middle 84% / 93%, south 76% / 84%.
  Pages: rainy no horse 50.3 / 49.7 / 9.7 MB, rainy horse 36.4 / 35.8 / 7.0 MB.

SUNNY PAGES and the hub, deck, problem, settings, how-it-works pages: byte-identical to v32.24 apart from the version.

TESTED (headless Chrome; not Firefox, not a console)
- tests/ui_zones.js on all 6 rainy pages: 0 errors (every preset's series = the zone pack on every route frame).
- The v32.23 test rounds again (regress.sh, regress2.sh): no errors except ui_freestyle on rainy no horse, which is the
  known fault of the TEST (same on v32.21-v32.24). ui_bitecolours passes with the fade-in pre file (round 2).
- Mock-Mac release v32.24 -> v32.25.
- hm64_labdata.sh: the same-contents check tried on the two married zips from GitHub (same) and on a changed copy
  (different); the script as a whole was not run against GitHub from the sandbox.

NOT DONE
- Part C (per-frame traces of casts that differ between zones, 576 jobs) is collected and merged but not analysed.
- Married data: still not integrated.
