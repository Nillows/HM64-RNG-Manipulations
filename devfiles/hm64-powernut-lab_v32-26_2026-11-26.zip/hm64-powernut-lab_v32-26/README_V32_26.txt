HM64 Power Nut Tool v32.26 (2026-11-26) - the unreliable bars are the marked ones; big zips are stored in parts

Includes everything of v32.25 (rainy tables rebuilt with the gap campaign's results; see README_V32_25_previous.txt).
v32.25 itself was never released: release this one.

WHAT CHANGED SINCE v32.25
- Lucky Timer, rainy pages, a picked dog's bars: the mark is reversed (Thomas 16:40). Only a bar that is a Nut ONLY
  from the zone in use carries an orange mark above it (and stripes); a bar that holds wherever Jack stops has no
  mark. The white marks are gone. Legend: "orange mark + stripes = a Nut only from the <zone> of the pier end -
  no mark = holds wherever Jack stops". README text and picture (media/app_zone_bars.png) redone.
  Only the two rainy Lucky Timer pages differ from v32.25; every other page is byte-identical apart from the version.
- tools/hm64_release.sh rev 2026-11-26h: a package zip over 90 MB is stored in the repository's devfiles/ folder as
  parts (<zip>.part-aa, -ab, ... of up to 90 MB) plus <zip>.parts.txt (how to join them, sha256 of the whole zip and
  of every part); the parts are checked against the zip before the commit. A smaller zip is stored whole as before.
  The release also stops before the commit if any file of the site is over 99 MB (GitHub refuses those).
  HM64_DEVFILE_MAX_MB changes the 90. Your Downloads stay as they are: you still give the release line two zips.
  (tools/hm64_labdata.sh already splits lab-data zips over 95 MB the same way.)

TESTED (headless Chrome; not Firefox)
- tests/ui_zones.js on both rainy Lucky Timer pages: 0 errors. Screenshot looked at: marks only on striped bars.
- Mock-Mac release v32.25 -> v32.26: the new release script installs itself, the pages zip (98.7 MB) goes into
  devfiles/ as 2 parts + parts.txt, the parts join to the zip's sha256.
