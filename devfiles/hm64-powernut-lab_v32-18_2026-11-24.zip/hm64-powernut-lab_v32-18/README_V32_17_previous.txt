HM64 Power Nut Tool v32.17 (2026-11-24): the deck - the big card is the bobber; show RNG speed
==============================================================================================

What you asked for (2026-11-24 20:22 / 20:23)
  "put the same glowing yellow highlight around the large card the player uses to click and start the card game attempt
  ... more similar to the bobber, you could even put a low opacity render of jacks cast animation on the big card"
  "a checkbox that says "show rng speed" that shows the same set of 51 cards, but flipped face up and changing at the rate
  the game does, and then when they cast out it shuffles even faster ... flicker 30 times a second with each frame"
  "the demonstration with the cards face up will look similar to press your luck with 51 cards flickering 30 times a second"
  "get rid of the slow mode ... i just want the real game speed in the deck of cards demo"

What changed (v32.17 includes v32.7 - v32.16)
  - deck.html: at every bite the big card glows like the lit card (gold, 20 VIs = 0.33 s) together with the lit face-down
    card; Jack's fishing frames are drawn on it at 38% opacity (jack_fishing.json, the Lucky Timer's timings): idle, the
    cast (4 VIs, then the 32-VI animation = G_CAST 36), the line out with the float, the rod dipping at a bite
    (bite + floatBite), landing a catch.
  - "show RNG speed" (off by default: the cards flicker): the 51 cards face up, a fresh deal of the same 51 at every step of
    the game's random number (the libkmc LCG). Steps per game frame, from the game's source:
      mainLoop.c        rand() once per frame: 1 step per frame, 30 a second (Jack at the pier, casting, a bite on)
      player.c          handleFishingAction: while the line is in the water waiting for a bite (actionPhase 2),
                        getRandomNumberInRange(0, 400) every frame (a 1-in-401 bite check), and math.c's
                        getRandomNumberInRange calls rand() twice: 3 steps per frame, 90 a second.
    The steps of a frame are shown spread over it (as fast as the screen allows: a 60 Hz screen shows 60 of the 90). The
    dog's own draws are not counted (the deck is the same for every dog line). The lit card glows on its face while the
    faces flicker, so the challenge stays blind; caught cards stay face up.
  - Slow mode: gone since v32.14 (real speed only); the live site shows it until v32.14 or later is released.
  - problem.html and the README's deck paragraph say so; new media/deck_rng.png, media/deck_page.png retaken.
  - Every other page byte-equal to v32.16 apart from the version.
  - tests/ui_deck.js: the big card lit only during a bite, Jack's animation by phase, 3 steps per frame only with the
    line out (1 while casting, during a bite, after), 10 steps in 334 ms at the pier, 29 with the line out, 51 distinct
    face-up cards, faces back down when unticked.

Release
  bash ~/Documents/hm64/tools/hm64_release.sh v32-17 <lab sha256> <pages sha256> </dev/null
