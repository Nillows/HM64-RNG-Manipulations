/* HM64 shared timing (v32.16, Thomas 2026-11-24 16:45): "take the tap and timing part of the application and move it to
   a harmonized "settings" option on the hub. the seperate sections can all collect and use data from each other if they
   use the same format for the next page. and they can all add to the same integer in your local storage to keep track of
   number of attempts consistently."

   One library for every page (Settings, Lucky Timer, Casting tables, Dog practice). It reads and writes the stores the
   Lucky Timer has always used, so nothing is converted and nothing is lost:
     hm64v29_lucky            the Lucky Timer's settings object; the SHARED fields below are the player's timing and keys
     hm64v28_settings         the console frame period (updateMs) and the stock bite-tap delay (tapMuVI)
     hm64v29_lucky_castprac   cast-practice presses   {at, e: ms vs the CAST cue (+ late, null = no press), m: 'line'|'beeps', src, v: 1 = visual cue}
     hm64v30_lucky_biteprac   bite reactions          {at, r: ms after the bite showed (null = early / miss), k: ok|late|early|miss, w, m: 'rel'|'tap', c: 1 = combo, src}
     hm64v29_lucky_tally      the Lucky Timer's logged attempts (their castErrMs = real B presses with the cast tap)
   and adds three:
     hm64v32_attempts         ONE integer: every attempt of every page that counts (Lucky Timer attempt started at the
                              pier, Dog practice whole attempt), Thomas's pick 2026-11-24
     hm64v32_attempts_by      the same count split by page {lucky, practice, before}
     hm64v32_timing_fit       what the Lucky Timer last learned from attempts against its dog tables (clock shift, bite
                              taps, how well the console offset is known, its compass): the parts only it can work out
     hm64v32_starttaps        READY taps measured in Dog practice's whole attempt {at, ms: tap - Jack stopping, src}
   The formulas (castStats, the press profile, the cue correction, the timing spread, the bite reactions) are the Lucky
   Timer's own, copied line for line (hm64_lucky_v29.js, v29.10 - v30.27); tests/ui_settings.js checks they give its
   numbers. Storage is per website (one origin): every page of nillows.github.io shares it; a page opened from a folder
   keeps its own (Firefox), so exportAll / importAll move everything through a file. */
(function (root) {
  'use strict';
  const KEY = {
    lucky: 'hm64v29_lucky', settings: 'hm64v28_settings', cast: 'hm64v29_lucky_castprac', castOld: 'hm64v29_lucky_prac',
    bite: 'hm64v30_lucky_biteprac', tally: 'hm64v29_lucky_tally', fit: 'hm64v32_timing_fit', attempts: 'hm64v32_attempts',
    attemptsBy: 'hm64v32_attempts_by', starts: 'hm64v32_starttaps', practiceStats: 'hm64v32_practice_stats'
  };
  const get = (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } };
  const set = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } };
  /* the player's own timing and keys inside hm64v29_lucky (the Lucky Timer's defaults, LDEF0) */
  const DEF = { startKey: ' ', startTapMs: 150, autoTune: true, biasMs: 0, biasAuto: true, sigmaMs: 150, sigmaAuto: true,
                audio: false, castTap: false, tapPrecMs: 40, dwKeys: 'arrows', dwAnimKeys: null, dwAdjKeys: null,
                bpUse: true, bpMode: 'rel', pracLine: true, pracCombo: true, pracFull: false };
  const SHARED = Object.keys(DEF);
  const NTSC_UPDATE_MS = 33.430;
  const PRAC = { lead: 4000, win: 600, gap: [1100, 2300], keep: 300, startSd: 60 };
  const BP = { gap: [1400, 5200], miss: 1000, show: 1300, keep: 400, min: 8 };
  const WINDOW_VI = 20, START_KEEP = 200, OFFSET_UNKNOWN_MS = 60;

  /* ---------------------------------------------------------------- reading */
  function lucky() {                                              // the shared fields, defaults filled in
    const L = get(KEY.lucky, {}) || {}, o = {};
    for (const k of SHARED) o[k] = L[k] === undefined || L[k] === null ? DEF[k] : L[k];
    if (L.startTapMs == null) {                                   // the Lucky Timer's v29.10 migration, read the same way
      const a = L.anchorDelayMs || {};
      o.startTapMs = a.fadein !== undefined ? a.fadein : a.pier !== undefined ? a.pier : 150;
    }
    if (!L.cueV) o.audio = false;                                 // v29.10: visual cues unless switched back on since
    if (!L.castTapV) o.castTap = false;
    return o;
  }
  function setLucky(patch) {                                      // read, change only these fields, write back
    const L = get(KEY.lucky, {}) || {};
    for (const [k, v] of Object.entries(patch)) { if (!SHARED.includes(k)) throw new Error('not a shared field: ' + k); L[k] = v; }
    if ('audio' in patch) L.cueV = 1;
    if ('castTap' in patch) L.castTapV = 1;
    return set(KEY.lucky, L);
  }
  function console_() {                                            // the app's rule (hm64_app_v28.js v30.1): an old 33.053 default
    const S = Object.assign({ updateMs: NTSC_UPDATE_MS, tapMuVI: 13, tapSdVI: 3 }, get(KEY.settings, {}) || {});   // nobody converted counts as 33.430
    if (!get('hm64v30_tb', null) && Math.abs(+S.updateMs - 33.053) < 0.0005) S.updateMs = NTSC_UPDATE_MS;
    if (!(+S.updateMs > 0)) S.updateMs = NTSC_UPDATE_MS;
    return S;
  }
  function setConsole(patch) { const S = get(KEY.settings, {}) || {}; Object.assign(S, patch); return set(KEY.settings, S); }
  const viMs = () => (+console_().updateMs || NTSC_UPDATE_MS) / 2;
  function castLog() {
    let a = get(KEY.cast, null);
    if (!Array.isArray(a)) a = (get(KEY.castOld, []) || []).filter(Number.isFinite).map(e => ({ at: 0, e: Math.round(e), m: 'beeps', src: 'B key' }));
    return a;
  }
  const biteLog = () => { const a = get(KEY.bite, []); return Array.isArray(a) ? a : []; };
  const tally = () => { const a = get(KEY.tally, []); return Array.isArray(a) ? a : []; };
  const fit = () => get(KEY.fit, null);

  /* ---------------------------------------------------------------- the Lucky Timer's statistics (copied) */
  function castStats(es) {                                       // robust: median, then mean / SD of the presses within 3 MAD
    const v = es.filter(Number.isFinite).slice().sort((a, b) => a - b), n = v.length;
    if (!n) return null;
    const q = (a, f) => a[Math.min(a.length - 1, Math.max(0, Math.round(f * (a.length - 1))))];
    const med = q(v, 0.5), mad = 1.4826 * q(v.map(x => Math.abs(x - med)).sort((a, b) => a - b), 0.5);
    const keep = v.filter(x => Math.abs(x - med) <= Math.max(3 * mad, 40));
    const mean = keep.reduce((a, x) => a + x, 0) / keep.length;
    const sd = keep.length > 1 ? Math.sqrt(keep.reduce((a, x) => a + (x - mean) ** 2, 0) / (keep.length - 1)) : NaN;
    const GF = 2 * viMs(), within = (c, w) => v.filter(x => Math.abs(x - c) <= w).length / n;
    return { n, out: n - keep.length, med, mean, sd, raw1: within(0, GF / 2), cor1: within(med, GF / 2), cor2: within(med, GF * 1.5) };
  }
  const pracMode = L => ((L || lucky()).pracLine ? 'line' : 'beeps');
  const cueKind = r => (r.v ? 'v' : 'a');
  function pracErrs(mode, L) {
    L = L || lucky(); const want = L.audio ? 'a' : 'v';
    return castLog().filter(r => r.m === (mode || pracMode(L)) && Number.isFinite(r.e) && cueKind(r) === want).map(r => r.e);
  }
  function attemptErrs(L) {
    L = L || lucky(); const want = L.audio ? 'a' : 'v';
    return tally().filter(x => Number.isFinite(x.castErrMs) && (x.v ? 'v' : 'a') === want).map(x => x.castErrMs);
  }
  function pressData(L) {                                         // practice presses (current mode, cue type) + real casts
    L = L || lucky();
    const pr = pracErrs(pracMode(L), L).slice(-80), at = attemptErrs(L).slice(-40), es = pr.concat(at);
    return { pr, at, es, s: castStats(es) };
  }
  const pressReady = L => { const d = pressData(L); return d.s && d.s.n >= 5 ? d.s : null; };
  function cueCorr(L) { L = L || lucky(); if (L.biasAuto !== false) { const s = pressReady(L); if (s) return -Math.round(s.med); } return +L.biasMs || 0; }
  /* how well the clock's offset is known: only the Lucky Timer can learn it (cast-tap attempts against its tables) */
  function offsetSdMs() { const f = fit(); return f && Number.isFinite(f.offsetSdMs) ? f.offsetSdMs : OFFSET_UNKNOWN_MS; }
  const sigmaFrom = sd => Math.max(40, Math.min(400, Math.round(Math.sqrt(sd ** 2 + PRAC.startSd ** 2 + offsetSdMs() ** 2) / 10) * 10));
  function sigmaMs(L) {
    L = L || lucky();
    if (L.sigmaAuto !== false) { const s = pressReady(L); if (s && isFinite(s.sd)) return sigmaFrom(s.sd); }
    return +L.sigmaMs || 150;
  }
  const bpWin = () => WINDOW_VI * viMs();
  const bpKind = r => (r.m === 'rel' ? 'rel' : 'tap');
  function bpReact() {                                            // the reactions behind the bite-tap delay (ms)
    const log = biteLog(), of = k => castStats(log.filter(r => bpKind(r) === k && Number.isFinite(r.r) && r.r >= 0).map(r => r.r));
    const tp = of('tap'), rl = of('rel'), useTap = tp && tp.n >= BP.min && isFinite(tp.sd);
    return { s: useTap ? tp : rl && rl.n >= BP.min ? rl : tp || rl, kind: useTap ? 'tap' : rl && rl.n >= BP.min ? 'rel' : tp ? 'tap' : 'rel' };
  }
  function bpStats(rows, mode) {
    rows = (rows || biteLog()).filter(r => bpKind(r) === (mode || (lucky().bpMode === 'tap' ? 'tap' : 'rel')));
    const rs = rows.filter(r => Number.isFinite(r.r) && r.r >= 0).map(r => r.r), s = castStats(rs);
    const early = rows.filter(r => r.k === 'early').length, miss = rows.filter(r => r.k === 'miss').length, w = bpWin();
    const ok = rs.filter(x => x <= w).length, late = rs.length - ok;
    return { n: rs.length, s, early, miss, ok, late, share: rs.length + miss ? ok / (rs.length + miss) : null };
  }

  /* ---------------------------------------------------------------- writing practice records (the Lucky Timer's formats) */
  function addCast(rec) {
    let a = castLog(); a.push(Object.assign({ at: Date.now() }, rec)); a = a.slice(-PRAC.keep); set(KEY.cast, a); return a;
  }
  function addBite(rec) {
    let a = biteLog(); a.push(Object.assign({ at: Date.now(), w: Math.round(bpWin()) }, rec)); a = a.slice(-BP.keep); set(KEY.bite, a); return a;
  }
  function forgetCast(mode, kind) {                               // one mode and cue type, as the Lucky Timer's "Forget presses"
    set(KEY.cast, castLog().filter(r => r.m !== mode || cueKind(r) !== kind));
  }
  function forgetBite() { set(KEY.bite, []); }
  const startTaps = () => { const a = get(KEY.starts, []); return Array.isArray(a) ? a : []; };
  function addStartTap(ms, src) {
    if (!Number.isFinite(ms)) return;
    let a = startTaps(); a.push({ at: Date.now(), ms: Math.round(ms), src: src || '' }); a = a.slice(-START_KEEP); set(KEY.starts, a);
  }

  /* ---------------------------------------------------------------- the one attempt count */
  function attempts() {
    let n = get(KEY.attempts, null);
    if (!Number.isFinite(n)) {                                    // first use: start from what is already on record
      const t = tally().length, ps = get(KEY.practiceStats, {}) || {}, w = Array.isArray(ps.whole) ? ps.whole.length : 0;
      n = t + w; set(KEY.attempts, n); set(KEY.attemptsBy, { before: n, lucky: 0, practice: 0, since: Date.now() });
    }
    return n;
  }
  function addAttempt(src) {
    const n = attempts() + 1; set(KEY.attempts, n);
    const by = Object.assign({ before: 0, lucky: 0, practice: 0 }, get(KEY.attemptsBy, {}) || {});
    by[src] = (by[src] || 0) + 1; set(KEY.attemptsBy, by);
    return n;
  }
  const attemptsBy = () => Object.assign({ before: 0, lucky: 0, practice: 0 }, get(KEY.attemptsBy, {}) || {});
  function resetAttempts() { set(KEY.attempts, 0); set(KEY.attemptsBy, { before: 0, lucky: 0, practice: 0, since: Date.now() }); }

  /* ---------------------------------------------------------------- everything to a file and back */
  const ours = k => /^hm64/.test(k);
  function exportAll() {
    const keys = {};
    try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (ours(k)) keys[k] = localStorage.getItem(k); } } catch (e) { /* storage off */ }
    return { schema: 'hm64-settings-v1', at: new Date().toISOString(), from: String(root.location && root.location.href || ''), keys };
  }
  function importAll(obj) {                                       // replaces the keys in the file, keeps every other key
    if (!obj || obj.schema !== 'hm64-settings-v1' || !obj.keys || typeof obj.keys !== 'object') throw new Error('not an HM64 settings file');
    let n = 0;
    for (const [k, v] of Object.entries(obj.keys)) { if (!ours(k) || typeof v !== 'string') continue; JSON.parse(v); localStorage.setItem(k, v); n++; }
    return n;
  }
  /* another tab of the same site changed something (the 'storage' event fires in the OTHER tabs) */
  function onChange(cb) { root.addEventListener('storage', e => { if (!e.key || ours(e.key)) cb(e.key, e); }); }

  root.HM64Timing = {
    KEY, DEF, SHARED, NTSC_UPDATE_MS, PRAC, BP, WINDOW_VI, OFFSET_UNKNOWN_MS,
    get, set, lucky, setLucky, console: console_, setConsole, viMs, castLog, biteLog, tally, fit,
    castStats, pracMode, cueKind, pracErrs, attemptErrs, pressData, pressReady, cueCorr, offsetSdMs, sigmaFrom, sigmaMs,
    bpWin, bpKind, bpReact, bpStats, addCast, addBite, forgetCast, forgetBite, startTaps, addStartTap,
    attempts, addAttempt, attemptsBy, resetAttempts, exportAll, importAll, onChange
  };
})(typeof window !== 'undefined' ? window : globalThis);
