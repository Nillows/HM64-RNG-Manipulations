/* HM64 Lucky Timer (v29): blind attempts. Start a stopwatch at READY, optionally mash C-right until k whistles,
   cast on the beep, release at the first bite only inside the release zones (else hold for the second bite),
   reset and try again. No observation. Data: the no-whistle cast tables (casts + arrivals) and, when the lucky
   lab run is in, the mash-whistle tables (D.lucky). */
(function (root) {
'use strict';

/* ================================================================== computation (also runs in node) */
const LuckyCore = (function () {
  const TMAX = 2820;                 // 47 s of stopwatch time (VI): the lineup tables end 40 s after READY = up to VI 2755 on the
                                     // fade-in stopwatch (v30.2; 2700 cut their last second off)
  const VMAX = 2900;                 // path VI kept (45 s + arrival offsets + kernel)
  let D = null, viMs = 16.715, plans = [], cache = new Map();   // v30.1: 33.430 ms per game update (hardware), was 16.5265

  function denseSeries(v0, n) {
    return { v0, n1: new Int8Array(n).fill(-1), b1: new Int16Array(n).fill(-1), n2: new Int8Array(n).fill(-1),
             b2: new Int16Array(n).fill(-1), len: n, bx: null };
  }
  /* v30: bites 3+ of a cast (every bite to the run's horizon, 90 s after READY on the dog-watch run): per path VI null
     (unknown: no every-bite data for that cast state) or an Int16Array [b3, b4, ...] (path VIs after this VI, negative =
     a Nut bite; empty = no later bite showed by the horizon); -1 in the data = the entry of VI i - parity */
  function laterBites(c, n) {
    const out = new Array(n).fill(null);
    for (let i = 0; i < n; i++) {
      let e = c.bx[i], sh = 0;
      if (e === -1 && c.parity != null) { e = c.bx[i - c.parity]; sh = c.parity; }
      if (!Array.isArray(e)) continue;
      out[i] = Int16Array.from(e, b => (b < 0 ? -(-b - sh) : b - sh));
    }
    return out;
  }
  function fromCasts(c) {                                          // no-whistle table of one dog path (path VI)
    const n = Math.max(0, Math.min(c.n1.length, VMAX - c.lo));
    const s = denseSeries(c.lo, n);
    for (let i = 0; i < n; i++) {
      const a = c.n1[i];
      if (a === '.') continue;
      s.n1[i] = a === '1' ? 1 : 0; s.b1[i] = c.b1[i];
      if (c.n2 && c.n2[i] !== undefined && c.n2[i] !== '.') { s.n2[i] = c.n2[i] === '1' ? 1 : 0; s.b2[i] = c.b2[i]; }
    }
    if (c.bx) s.bx = laterBites(c, n);
    return s;
  }
  function fromLucky(G, x) {                                       // mash table on the cast grid (rep polls -> path VI)
    const vEnd = Math.min(VMAX, G[Math.min(G.length - 1, x.i0 + x.n1.length - 1)] + 2);
    const v0 = G[x.i0] + 1, s = denseSeries(v0, Math.max(0, vEnd - v0));
    for (let i = 0; i < x.n1.length; i++) {
      const v = G[x.i0 + i] + 1 - v0;
      if (v >= s.len || x.n1[i] === '.') continue;
      s.n1[v] = x.n1[i] === '1' ? 1 : 0; s.b1[v] = x.b1[i];
      if (x.n2[i] !== undefined && x.n2[i] !== '.') { s.n2[v] = x.n2[i] === '1' ? 1 : 0; s.b2[v] = x.b2[i]; }
    }
    return s;
  }
  /* Plans for a pace group (D.pace: route weights split by the runner's slack before the dog lands) and a
     start anchor: 'ready' (t = 1 at READY) or 'dog' (t = 1 when the dog is put down; READY of a route with beach
     wait D is then t = 17 + 2*(D//2), its first possible cast). The whistle plans exist for 'ready' + all routes. */
  /* Routes: 'carry' = the Spring 9 dog-carry route (the lab's arrival pool, pace presets, dog-landing / READY start);
     D.lroutes = extra routes with their own cast table (one dog line each, tools/route_tables.py) and their own start
     anchors ({id, label, r0}: READY sits r0 VI after the start event, so path VI = t - r0). All no-whistle plans share
     one series list (dog paths, then the route tables), so the smoothing cache stays valid across routes. */
  let series0 = null, wplans = [], sel = { route: 'carry', pace: 'all', anchor: 'ready' };
  const setCache = new Map();
  const CARRY = { id: 'carry', label: 'Spring 9 dog carry (lab arrival pool)', anchors: [{ id: 'dog', label: 'when the dog lands' }, { id: 'ready', label: 'at READY' }] };
  function routes() { return [CARRY].concat(D && D.lroutes ? D.lroutes : []); }
  function routeOf(id) { return routes().find(r => r.id === id) || CARRY; }
  function prepare(data, vims, selection) {
    D = data; viMs = vims || viMs; cache = new Map(); setCache.clear();
    series0 = D.casts.map(c => c ? fromCasts(c) : null);
    for (const r of D.lroutes || []) {
      if (r.lines) { r.sidxs = r.lines.map(c => { series0.push(c ? fromCasts(c) : null); return series0.length - 1; }); r.sidx = r.sidxs[0]; }
      else { r.sidx = series0.length; series0.push(fromCasts(r.casts)); }
    }
    wplans = [];
    const L = D.lucky;
    if (L && L.plans) {
      const tot = D.arrivals.reduce((a, x) => a + x[2], 0) || 1;
      for (const p of L.plans) {
        const series = p.series.map(x => fromLucky(L.G, x));
        const variants = p.scen.map(([sid, o, w, period, starts]) => ({ w, o, s: sid, period, starts, minT: 1 }));
        const W = variants.reduce((a, x) => a + x.w, 0);
        // stopwatch time of the last whistle's end (typical) and the earliest cast with data
        const ends = variants.map(x => ({ w: x.w, t: (x.starts.length ? x.starts[x.starts.length - 1] + 41 : 0) - x.o + 1 }))
          .sort((a, b) => a.t - b.t);
        let acc = 0, med = 0;
        for (const e of ends) { acc += e.w; if (acc >= W / 2) { med = e.t; break; } }
        const firstT = Math.min(...variants.map(x => series[x.s].v0 - x.o));
        wplans.push({ k: p.k, label: `${p.k} whistle${p.k > 1 ? 's' : ''}`, series, variants, cover: W / tot,
                      firstT: Math.max(1, firstT), whistleEnd: med, pace: 'all', anchor: 'ready' });
      }
    }
    return select(selection || sel);
  }
  /* v29.9: routes with `members` (tools/zigzag_routes.py) build any combination of their `axes` on demand.
     id = 'all' or axis-option pairs in axis order joined by '+', e.g. 'house-fast+cut1-tight+cut2-early'. */
  function axId(R, ax) {
    const parts = (R.axes || []).filter(A => ax[A.id]).map(A => A.id + '-' + ax[A.id]);
    return parts.length ? parts.join('+') : 'all';
  }
  function parseAx(R, id) {
    if (id === 'all') return {};
    const ax = {};
    for (const part of String(id).split('+')) {
      const i = part.indexOf('-'), A = (R.axes || []).find(a => a.id === part.slice(0, i));
      if (i < 0 || !A || !A.opts.some(o => o.id === part.slice(i + 1))) return null;
      ax[A.id] = part.slice(i + 1);
    }
    for (const A of R.axes) if (A.needs && ax[A.id] && !ax[A.needs]) return null;
    return ax;
  }
  function groupOf(R, id) {
    if (!R.members) return (R.groups || []).find(g => g.id === id) || null;
    R.groupCache = R.groupCache || new Map();
    if (R.groupCache.has(id)) return R.groupCache.get(id);
    const ax = parseAx(R, id);
    if (!ax) return null;
    const cols = R.members_cols, ci = name => cols.indexOf(name), iw = ci('w'), il = ci('line'), io = ci('k_off'), ir = ci('ready_rel');
    const tests = Object.entries(ax).map(([a, o]) => { const A = R.axes.find(x => x.id === a); return [ci(a), A.opts.findIndex(x => x.id === o)]; });
    let W = 0, Wc = 0;
    const v = { pier: new Map(), beach: new Map() }, sel = [];
    for (const m of R.members) if (tests.every(([c, k]) => m[c] === k)) { sel.push(m); W += m[iw]; if (m[il] >= 0) Wc += m[iw]; }
    if (!(W > 0)) { R.groupCache.set(id, null); return null; }
    const add = (map, key, w) => map.set(key, (map.get(key) || 0) + w);
    for (const m of sel) {
      if (m[il] < 0) continue;
      add(v.pier, m[il] + ':' + m[io] + ':1', m[iw] / W);
      add(v.beach, m[il] + ':' + (m[io] - m[ir]) + ':' + (m[ir] + 1), m[iw] / W);
    }
    const lst = map => [...map].map(([k, w]) => { const [li, o, mt] = k.split(':').map(Number); return [li, w, o, mt]; });
    const names = Object.entries(ax).map(([a, o]) => { const A = R.axes.find(x => x.id === a); return (A.short || A.id) + ' ' + A.opts.find(x => x.id === o).label.toLowerCase(); });
    const last = R.axes.filter(A => ax[A.id]).pop();
    const g = { id, ax, label: names.length ? names.join(' · ') : 'All', band: last ? last.opts.find(x => x.id === ax[last.id]).band : 'every route',
                desc: names.length ? names.join('; ') : 'All simulated routes of this preset', share: W, cover: Wc / W,
                v: { pier: lst(v.pier), beach: lst(v.beach) } };
    R.groupCache.set(id, g);
    (R.groups = R.groups || []).filter(x => x.id === id).length || R.groups.push(g);
    return g;
  }
  const groupFor = (R, ax) => groupOf(R, axId(R, ax));
  function groups() {
    const R = routeOf(sel.route);
    if (R.groups) return R.groups;                                 // multi-line route tables: their own presets
    return D && D.pace ? D.pace.groups : [{ id: 'all', label: 'All' }];
  }
  function norm(selection) {
    const x = { route: (selection && selection.route) || 'carry', pace: (selection && selection.pace) || 'all',
                anchor: (selection && selection.anchor) || 'ready' };
    const R = routeOf(x.route);
    x.route = R.id;
    if (R.id !== 'carry') {                                        // one dog line: no pace groups; line mixes: their presets
      if (!(R.members ? groupOf(R, x.pace) : R.groups && R.groups.some(g => g.id === x.pace))) x.pace = 'all';
      if (!R.anchors.some(a => a.id === x.anchor)) x.anchor = R.anchors[0].id;
      return x;
    }
    if (!(D && D.pace)) x.anchor = 'ready';
    if (x.anchor !== 'dog' && x.anchor !== 'ready') x.anchor = D && D.pace ? 'dog' : 'ready';
    if (!(D && D.pace && D.pace.groups.some(g => g.id === x.pace))) x.pace = 'all';   // carry presets (not the current route's)
    return x;
  }
  function select(selection) {
    sel = norm(selection);
    plans = planSet(sel.pace, sel.anchor, sel.route);
    return plans;
  }
  function planSet(pace, anchor, route) {                          // cached plan list for a route + pace group + anchor
    const x = norm({ pace, anchor, route }), key = x.route + '/' + x.pace + '/' + x.anchor;
    if (!setCache.has(key) && x.route !== 'carry' && (routeOf(x.route).groups || routeOf(x.route).members)) {
      const R = routeOf(x.route), A0 = R.anchors.find(a => a.id === x.anchor);
      const g = groupOf(R, x.pace) || groupOf(R, 'all') || R.groups[0];
      const var0 = (g.v[A0.id] || []).filter(([li]) => series0[R.sidxs[li]])
        .map(([li, w, o, mt]) => ({ w, o, s: R.sidxs[li], period: 0, starts: [], minT: mt }));
      const firstT = var0.length ? Math.min(...var0.map(v => v.minT)) : 1;
      setCache.set(key, [{ k: 0, label: 'No whistle', series: series0, variants: var0, cover: g.cover, firstT,
                           whistleEnd: 0, pace: g.id, anchor: x.anchor, route: R.id, r0: A0.r0,
                           hz: R.source && R.source.bite_horizon ? R.source.bite_horizon + 1 : null }]);
    }
    if (!setCache.has(key) && x.route !== 'carry') {
      const R = routeOf(x.route), A0 = R.anchors.find(a => a.id === x.anchor);
      const var0 = [{ w: 1, o: -A0.r0, s: R.sidx, period: 0, starts: [], minT: A0.r0 + 1 }];
      setCache.set(key, [{ k: 0, label: 'No whistle', series: series0, variants: var0, cover: 1, firstT: A0.r0 + 1,
                           whistleEnd: 0, pace: 'all', anchor: x.anchor, route: R.id, r0: A0.r0 }]);
    }
    if (!setCache.has(key)) {
      const g = D.pace ? D.pace.groups.find(y => y.id === x.pace) : null, dog = x.anchor === 'dog';
      const src = g ? g[x.anchor] : D.arrivals;
      const var0 = src.filter(a => series0[a[0]]).map(a => ({ w: a[2], o: a[1], s: a[0], period: 0, starts: [],
                                                              minT: dog ? (D.pace.lag0 || 16) + 1 + (a[3] || 0) : 1 }));
      const p0 = { k: 0, label: 'No whistle', series: series0, variants: var0, cover: 1,
                   firstT: dog ? (D.pace.lag0 || 16) + 1 : 1, whistleEnd: 0, pace: x.pace, anchor: x.anchor, route: 'carry',
                   r0: dog ? (D.pace.lag0 || 16) : 0 };
      setCache.set(key, [p0].concat(x.pace === 'all' && !dog ? wplans : []));
    }
    return setCache.get(key);
  }
  /* the cast-landing spread: a number (Gaussian SD in VIs) or, for personalized suggestions (v29.10), a measured kernel
     {id, k, r, sd}: k[d + r] = P(the cast lands d VIs after the aim), any shape (lopsided for a late or early habit) */
  const sigKey = s => (typeof s === 'object' ? s.id : s.toFixed(3));
  const sdOf = s => (typeof s === 'object' ? s.sd : s);
  function kernel(sig) {
    if (sig && typeof sig === 'object') return { k: sig.k, r: sig.r };
    sig = Math.max(0.5, sig);
    const r = Math.ceil(3 * sig), k = new Float32Array(2 * r + 1);
    let z = 0;
    for (let d = -r; d <= r; d++) { k[d + r] = Math.exp(-0.5 * (d / sig) ** 2); z += k[d + r]; }
    for (let i = 0; i < k.length; i++) k[i] /= z;
    return { k, r };
  }
  /* per series: Gaussian-weighted mean of the known outcomes around every path VI (bite1 and hold) */
  function smoothed(plan, sig) {
    const key = plan.k + ':' + (typeof sig === 'object' ? sig.id : sig.toFixed(2));
    if (cache.has(key)) return cache.get(key);
    const { k, r } = kernel(sig);
    const out = plan.series.map(s => {
      if (!s) return null;
      const n = s.len, a1 = new Float32Array(n), d1 = new Float32Array(n), a2 = new Float32Array(n), d2 = new Float32Array(n);
      for (let i = 0; i < n; i++) {
        const x1 = s.n1[i], x2 = s.n2[i];
        if (x1 < 0 && x2 < 0) continue;
        const lo = Math.max(0, i - r), hi = Math.min(n - 1, i + r);
        for (let j = lo; j <= hi; j++) {
          const kw = k[i - j + r];                               // aim j, landing i: offset i - j
          if (x1 >= 0) { a1[j] += kw * x1; d1[j] += kw; }
          if (x2 >= 0) { a2[j] += kw * x2; d2[j] += kw; }
        }
      }
      return { a1, d1, a2, d2 };
    });
    cache.set(key, out);
    return out;
  }
  /* route-weighted P(Nut) for a cast at stopwatch VI t (t = 1 is READY): pol 'bite1' | 'hold' */
  const memos = new WeakMap();
  function memo(plan, key, fn) {          // per variant list: copies of a plan with other weights get their own cache
    let m = memos.get(plan.variants);
    if (!m) { m = new Map(); memos.set(plan.variants, m); }
    if (!m.has(key)) { if (m.size > 24) m.clear(); m.set(key, fn()); }
    return m.get(key);
  }
  function curve(plan, sig, pol) { return memo(plan, 'c:' + pol + ':' + sigKey(sig), () => curveRaw(plan, sig, pol)); }
  function curveRaw(plan, sig, pol) {
    const sm = smoothed(plan, sig), P = new Float32Array(TMAX + 1).fill(NaN), C = new Float32Array(TMAX + 1);
    const W = plan.variants.reduce((a, x) => a + x.w, 0) || 1;
    const num = new Float64Array(TMAX + 1), den = new Float64Array(TMAX + 1);
    for (const x of plan.variants) {
      const s = plan.series[x.s], m = sm[x.s];
      if (!s) continue;
      const a = pol === 'hold' ? m.a2 : m.a1, d = pol === 'hold' ? m.d2 : m.d1;
      for (let t = Math.max(1, x.minT || 1); t <= TMAX; t++) {
        const i = t + x.o - s.v0;
        if (i < 0 || i >= s.len || d[i] < 0.05) continue;
        num[t] += x.w * a[i] / d[i]; den[t] += x.w;
      }
    }
    for (let t = 1; t <= TMAX; t++) if (den[t] > 0) { P[t] = num[t] / den[t]; C[t] = den[t] / W * plan.cover; }
    return { P, C };
  }
  /* zone policy at cast time T: release at bite 1 only in zones where bite-1 Nuts outweigh bite-2 Nuts
     (bite times seen with spread sigB). Returns value (+ zones, bite densities in bins of binVI after READY,
     and the weighted scenarios when full). Typed arrays only: it runs a few hundred times per plan. */
  const ZB = 6;
  let zbuf = null;
  function zoneAt(plan, T, sig, sigB, full) {
    const binVI = ZB; sigB = sdOf(sigB || sig);
    const { k, r } = kernel(sig);
    if (!plan.maxBite) {
      let m = 0;
      for (const s of plan.series) if (s) for (let i = 0; i < s.len; i++) { if (s.b1[i] > m) m = s.b1[i]; if (s.b2[i] > m) m = s.b2[i]; }
      plan.maxBite = m;
    }
    const nb = Math.ceil((TMAX + 3 * r + plan.maxBite + 400) / binVI) + 4;
    if (!zbuf || zbuf.nb < nb) zbuf = { nb, d1n: new Float64Array(nb), d1f: new Float64Array(nb), d2n: new Float64Array(nb), s1: new Float64Array(nb), s2: new Float64Array(nb), pin: new Float64Array(nb) };
    const { d1n, d1f, d2n, s1, s2, pin } = zbuf;
    d1n.fill(0, 0, nb); d1f.fill(0, 0, nb); d2n.fill(0, 0, nb); s1.fill(0, 0, nb); s2.fill(0, 0, nb);
    let W = 0, hiBin = 0, hi2 = 0;
    const each = fn => {
      for (const x of plan.variants) {
        const s = plan.series[x.s];
        if (!s) continue;
        const c0 = T + x.o - s.v0, dmin = Math.max(-r, (x.minT || 1) - T);
        let z = 0;
        for (let d = dmin; d <= r; d++) { const i = c0 + d; if (i >= 0 && i < s.len && s.n1[i] >= 0 && s.n2[i] >= 0) z += k[d + r]; }
        if (!z) continue;
        for (let d = dmin; d <= r; d++) {
          const i = c0 + d;
          if (i < 0 || i >= s.len || s.n1[i] < 0 || s.n2[i] < 0) continue;
          const base = s.v0 + i - x.o;
          fn(x.w * k[d + r] / z, base + s.b1[i], s.n1[i], base + s.b2[i], s.n2[i], base, s.bx ? s.bx[i] : null);
        }
      }
    };
    each((w, t1, n1, t2, n2) => {
      const b = Math.max(0, Math.floor(t1 / binVI));
      if (n1) d1n[b] += w; else d1f[b] += w;
      d2n[b] += n2 * w; W += w; if (b > hiBin) hiBin = b;
      const b2 = Math.floor(t2 / binVI); if (b2 > hi2) hi2 = b2;
    });
    if (!W) return null;
    const kb = kernel(Math.max(sigB / binVI, 0.3)), top = Math.min(nb, hiBin + kb.r + 2);
    for (let i = 0; i < top; i++) {
      if (!d1n[i] && !d2n[i]) continue;
      for (let d = -kb.r; d <= kb.r; d++) { const j = i + d; if (j >= 0 && j < top) { s1[j] += d1n[i] * kb.k[d + kb.r]; s2[j] += d2n[i] * kb.k[d + kb.r]; } }
    }
    const kp = kernel(Math.max(sigB / binVI, 0.3));            // chance a bite in bin i is judged inside a zone
    for (let i = 0; i < top; i++) {
      let a = 0, zz = 0;
      for (let d = -kp.r; d <= kp.r; d++) { const j = i + d; if (j < 0 || j >= top) continue; zz += kp.k[d + kp.r]; if (s1[j] > s2[j] + 1e-12) a += kp.k[d + kp.r]; }
      pin[i] = zz ? a / zz : 0;
    }
    let val = 0, v1 = 0, v2 = 0;
    for (let i = 0; i < top; i++) { val += pin[i] * d1n[i] + (1 - pin[i]) * d2n[i]; v1 += d1n[i]; v2 += d2n[i]; }
    const out = { value: val / W, bite1: v1 / W, hold: v2 / W, binVI };
    if (!full) return out;
    const zones = [];
    let cur = null;
    for (let i = 0; i < top; i++) {
      const zin = s1[i] > s2[i] + 1e-12;
      if (zin && !cur) cur = [i * binVI, (i + 1) * binVI];
      else if (zin) cur[1] = (i + 1) * binVI;
      else if (cur) { zones.push(cur); cur = null; }
    }
    if (cur) zones.push(cur);
    /* v30.2: the drawn densities reach the last second bite (they stopped just after the last FIRST bite, so late
       second-bite Nuts were not drawn); d3 = Nut bites 3+ of casts whose bites 1-2 are no Nut, by their time (sparse:
       bin -> share); byBite = where the Nut comes from under the zone policy (bite 1 released in a zone, bite 2
       otherwise) + later3 = share of casts held to bite 2 whose Nut is on bite 3+ (by bite number) */
    const topD = Math.max(top, hi2 + 2);
    const D1n = new Float64Array(topD), D1f = new Float64Array(topD), D2n = new Float64Array(topD), D2all = new Float64Array(topD), sc = [];
    const d3 = new Map(), later3 = {};
    let q1 = 0, q2 = 0, known3 = 0;
    each((w, t1, n1, t2, n2, cast, bx) => {
      const b = Math.max(0, Math.floor(t1 / binVI)), p = pin[Math.min(b, top - 1)];
      if (n1) D1n[b] += w / W; else D1f[b] += w / W;
      const b2 = Math.floor(t2 / binVI);
      if (b2 >= 0 && b2 < topD) { D2n[b2] += (1 - p) * n2 * w / W; D2all[b2] += n2 * w / W; }
      q1 += p * n1 * w / W; q2 += (1 - p) * n2 * w / W;
      if (bx) {
        known3 += w / W;
        if (!n2) for (let q = 0; q < bx.length; q++) if (bx[q] < 0) {
          const bn = Math.floor((cast - bx[q]) / binVI);
          d3.set(bn, (d3.get(bn) || 0) + (1 - p) * w / W);
          later3[q + 3] = (later3[q + 3] || 0) + (1 - p) * w / W;
          break;
        }
      }
      sc.push({ w, t1, n1, t2, n2, cast, base: cast, bx });
    });
    return Object.assign(out, { zones, d1n: D1n, d1f: D1f, d2n: D2n, d2all: D2all, sc, W, d3, byBite: { 1: q1, 2: q2, later: later3, known3 } });
  }
  /* value of a fixed choice (cast at T, policy, release zones) on a plan's arrivals: used to show what one pace
     group's plan gives the other groups. Bite judgement into zones with spread sig, as in zoneAt. */
  function valueWith(plan, T, sig, pol, zones) {
    const z = zoneAt(plan, T, sig, sig, true);
    if (!z) return NaN;
    const Phi = v => { const t = 1 / (1 + 0.3275911 * Math.abs(v / Math.SQRT2)), y = 1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-v * v / 2); return 0.5 * (1 + (v >= 0 ? y : -y)); };
    let v = 0;
    for (const e of z.sc) {
      let pin = pol === 'bite1' ? 1 : 0;
      if (pol === 'zone') for (const [a, b] of zones || []) pin += Phi((b - e.t1) / sdOf(sig)) - Phi((a - e.t1) / sdOf(sig));
      v += e.w * (pin * e.n1 + (1 - pin) * e.n2);
    }
    return v / z.W;
  }
  function zoneCurve(plan, sig, step) {
    step = step || 6;
    return memo(plan, 'z:' + step + ':' + sigKey(sig), () => zoneCurveRaw(plan, sig, step));
  }
  function zoneCurveRaw(plan, sig, step) {
    const P = new Float32Array(TMAX + 1).fill(NaN);
    for (let t = 1; t <= TMAX; t += step) {                       // grid at 1 + k*step (the fill below assumes it)
      if (t < plan.firstT) continue;
      const z = zoneAt(plan, t, sig, sig, false);
      if (z) P[t] = z.value;
    }
    for (let t = 1; t <= TMAX; t++) {                             // fill between the steps for drawing
      if (!isNaN(P[t])) continue;
      const a = t - ((t - 1) % step), b = a + step;
      if (!isNaN(P[a]) && b <= TMAX && !isNaN(P[b])) P[t] = P[a] + (P[b] - P[a]) * (t - a) / step;
      else if (!isNaN(P[a])) P[t] = P[a];
    }
    return P;
  }
  /* v30.6 goal: null = the cast with the best odds per attempt; { over: VIs } = the cast with the best odds per
     unit of time, p / (over + t): `over` = what an attempt costs besides the stopwatch time to the cast (reset -> start,
     the bites after the cast). The UI lab (2026-11-17, 1,496 attempts on the Mac) showed the release logic loses no Nut
     once the cast is made and the shown odds are right, so the time per Nut is the thing left to choose. */
  let goal = null;
  const setGoal = g => { goal = g && g.over > 0 ? { over: g.over } : null; };
  const score = (t, p) => (goal ? p / (goal.over + t) : p);
  function argmax(P, lo, mask) {
    let bt = -1, bp = -1, bs = -1;
    for (let t = Math.max(1, lo); t < P.length; t++) if (!isNaN(P[t]) && (!mask || mask[t]) && score(t, P[t]) > bs) { bs = score(t, P[t]); bp = P[t]; bt = t; }
    return { t: bt, p: bp };
  }
  /* v29.9: aims only where >= 80% of the plan's routes have a cast table (near a table's end only the members that
     reach READY earliest are left, and their share alone gave fake highs) */
  const COVER_MIN = 0.8;
  function okMask(plan, sig) {
    return memo(plan, 'm:' + sigKey(sig), () => {
      const C = curve(plan, sig, 'bite1').C, cv = plan.cover || 1, m = new Uint8Array(TMAX + 1);
      for (let t = 1; t <= TMAX; t++) m[t] = C[t] / cv >= COVER_MIN ? 1 : 0;
      return m;
    });
  }
  /* best cast time per policy (t >= tMin), the zone policy refined around the coarse optimum */
  function best(plan, sig, tMin) {
    tMin = Math.max(tMin || 30, plan.firstT);
    const out = {}, mask = okMask(plan, sig);
    for (const pol of ['bite1', 'hold']) out[pol] = argmax(curve(plan, sig, pol).P, tMin, mask);
    // zone policy: local maxima of a 6-VI grid (peaks are only ~2 sigma wide), the best few refined per VI
    const zc = zoneCurve(plan, sig, 6), cands = [];
    for (let t = 1; t <= TMAX; t += 6) {
      if (t < tMin || isNaN(zc[t]) || !mask[t]) continue;
      if (!(zc[t - 6] > zc[t]) && !(zc[t + 6] > zc[t])) cands.push([t, zc[t]]);
    }
    cands.sort((a, b) => score(b[0], b[1]) - score(a[0], a[1]));
    let z = { t: -1, p: -1 }, zs = -1;
    for (const [t0] of cands.slice(0, goal ? 10 : 6)) {
      for (let t = Math.max(tMin, t0 - 6); t <= Math.min(TMAX, t0 + 6); t++) {
        if (!mask[t]) continue;
        const r = zoneAt(plan, t, sig);
        if (r && score(t, r.value) > zs) { zs = score(t, r.value); z = { t, p: r.value }; }
      }
    }
    out.zone = z;
    return out;
  }
  /* Bite-1 tap: the runner taps a key when the first bite shows. Posterior over (variant, cast offset d) given the tap
     at stopwatch VI tau: prior weight x kernel(d) x N(tau; t1 + tapMu, tapSd). Without a cast tap the cast lands at
     T + bias + d, d ~ N(0, sig) (aim spread) and the bite at T + bias + d + b1. With a cast tap (key pressed together
     with B at stopwatch VI cast.c) the landed path VI is c + bias + d + o, d ~ N(0, cast.sd) (tap + start-key spread;
     bias = the stopwatch's offset to the console) and the bite shows at c + b1 on the same stopwatch, so the bite delay
     after the cast is the fingerprint. Returns the evidence Z (relative), P(Nut on bite 1) p1, P(Nut on bite 2) pNut
     and the weighted scenarios. */
  const FLAT = 1 / 2400;      // density (per VI) of a tapped bite whose time this cast state does not give (no data / after the horizon)
  function tapPosterior(plan, T, sig, bias, tau, tapMu, tapSd, weightOf, cast, tau2, tauX) {
    const ct = cast && cast.c != null ? cast : null;
    /* T rounded (2026-11-16): stored taps keep the CAST cue's sub-VI time (aim + cast-cue correction / VI); a fractional
       centre made every index fractional -> Z NaN -> the profile (auto-tune, personal weights) learned nothing */
    const center = ct ? Math.round(ct.c) : Math.round(T), { k, r } = kernel(ct ? ct.sd : sig), sc = [];
    const sd = ct ? Math.hypot(tapSd, ct.tapSd || 0) : tapSd;
    let Z = 0, nut = 0, nut1 = 0, prior = 0;
    const b = Math.round(bias || 0);
    for (const x of plan.variants) {
      const s = plan.series[x.s];
      if (!s) continue;
      const wx = weightOf ? weightOf(x) : x.w, c0 = center + x.o - s.v0 + b;
      for (let d = Math.max(-r, (x.minT || 1) - center - b); d <= r; d++) {
        const i = c0 + d;
        if (i < 0 || i >= s.len || s.n1[i] < 0 || s.n2[i] < 0) continue;
        prior += wx * k[d + r];
        const base = ct ? ct.c : s.v0 + i - x.o, t1 = base + s.b1[i], t2 = base + s.b2[i], z = (tau - (t1 + tapMu)) / sd;
        if (Math.abs(z) > 5) continue;
        const z2 = tau2 != null ? (tau2 - (t2 + tapMu)) / sd : 0;     // second bite tapped too (held through bite 1)
        if (Math.abs(z2) > 5) continue;
        let w = wx * k[d + r] * Math.exp(-0.5 * (z * z + z2 * z2)) / (sd * 2.5066);
        const bx = s.bx ? s.bx[i] : null, hz = plan.hz ? base + plan.hz - (s.v0 + i) : null;
        if (tauX && tauX.length) {                                     // v30: bites 3+ tapped too (held through each)
          let ok = true;
          for (let q = 0; q < tauX.length && ok; q++) {
            if (bx && q < bx.length) {
              const zq = (tauX[q] - (base + Math.abs(bx[q]) + tapMu)) / sd;
              if (Math.abs(zq) > 5) ok = false; else w *= Math.exp(-0.5 * zq * zq) / (sd * 2.5066);
            } else if (bx && hz != null && tauX[q] - tapMu < hz - 3 * sd) ok = false;   // this cast has no such bite by the horizon
            else w *= FLAT;
          }
          if (!ok) continue;
        }
        sc.push({ w, pair: x.s + ':' + x.o, path: x.s, pv: i + s.v0, n1: s.n1[i], n2: s.n2[i], t1, t2, d: d + b, mt: x.minT || 1, base, bx });
        Z += w; nut += w * s.n2[i]; nut1 += w * s.n1[i];
      }
    }
    return { Z: prior ? Z / prior : 0, pNut: Z ? nut / Z : NaN, p1: Z ? nut1 / Z : NaN, sc };
  }
  /* v31.2 (Thomas, 2026-11-20): the dog AFTER the cast, from the 90-s lab run (tools/dogcast_pack.py -> D.dogcast).
     pack.lines[key] = {k0, idx: cast id per cast frame k0, k0 + 2, ...}; per cast P (dog changes from the cast to its
     first bite: flat [dk, code, ...], code = animation base * 8 + screen facing), F (VIs to the first bite, -1 none),
     S (that bite's state), E (VIs of data); per bite state R (changes while B stays held, to the next bite), N (VIs to
     the next bite, -1 none), X (next state), L (VIs of data when N is -1), T (changes for pack.tail VIs when B is let
     go at that bite). Lab facts behind it: the dog after a cast depends on the exact cast frame (one game frame apart:
     the two dogs part 1.0 - 2.7 s after the cast, never the same), and the state at a bite fixes everything after it.
     dogAfterCast(pack, key, kc, dt, rel, nat) -> the dog's code dt VIs after a cast at trace label kc on dog line `key`
     (rel = number of the bite B is let go at, 0 = held through; nat = the code showing at the cast frame);
     undefined = no data for that line / frame / moment. */
  function dogAfterCast(pack, key, kc, dt, rel, nat) {
    const ln = pack && pack.lines[key];
    if (!ln || dt < 0) return undefined;
    const j = (kc - ln.k0) / 2;
    if (j < 0 || j >= ln.idx.length || j !== Math.floor(j)) return undefined;
    const cid = ln.idx[j];
    if (cid < 0) return undefined;
    let cur = nat;
    const walk = (flat, from) => { let t = from; for (let i = 0; i < flat.length; i += 2) { t += flat[i]; if (t > dt) return; cur = flat[i + 1]; } };
    const f = pack.F[cid];
    if (f < 0 || dt < f) { if (dt > pack.E[cid]) return undefined; walk(pack.P[cid], 0); return cur; }
    cur = pack.P[cid].length ? pack.P[cid][pack.P[cid].length - 1] : nat;
    let bt = f, st = pack.S[cid], n = 1;
    for (;;) {
      if (st < 0) return undefined;
      if (rel === n) { if (dt - bt > pack.tail) return undefined; walk(pack.T[st], bt); return cur; }
      const nx = pack.N[st];
      if (nx >= 0 && dt >= bt + nx) { const r = pack.R[st]; if (r.length) cur = r[r.length - 1]; bt += nx; st = pack.X[st]; n++; continue; }
      if (nx < 0 && dt - bt > pack.L[st]) return undefined;
      walk(pack.R[st], bt);
      return cur;
    }
  }
  /* v30.30 (Thomas, 2026-11-20): bite taps that fit no dog line - what explains them?
     tapWhy: for one plan, the likelihood of the tapped bites (taus: bite 1, bite 2 ...) for every cast offset d in
     -R..R VIs from T:  L(d) = sum over variants (by weight) of prod N(tau_q; bite q of that frame + mu, sd) / sum of weights.
     noFit: the tables given (the plan's own first, then its sibling arrival tables) share one flat prior over
     (table, d); the posterior mass is read three ways - the best +-W window (where the cast landed, if it is sharp),
     the sides (own table early / late) and the tables. Nothing above zero anywhere = no cast within +-R on any table
     gives these bites. Honest by construction: when the bites do not pin it down, no bucket reaches `need`.
     T is the frame the fit is centred on (the caller adds the clock shift). castAt (the tapped cast, VI): the bites are
     then timed from that tap and d is how far the game's frame was from the centre. */
  function tapWhy(plan, T, taus, mu, sd, R, castAt) {
    const c = Math.round(T), L = new Float64Array(2 * R + 1), W = new Float64Array(2 * R + 1), nrm = 1 / (sd * 2.5066283);
    const t1 = taus[0], t2 = taus.length > 1 ? taus[1] : null;
    for (const x of plan.variants) {
      const s = plan.series[x.s];
      if (!s || !(x.w > 0)) continue;
      for (let d = Math.max(-R, (x.minT || 1) - c); d <= R; d++) {
        const i = c + x.o - s.v0 + d;
        if (i < 0 || i >= s.len || s.n1[i] < 0 || s.n2[i] < 0) continue;
        W[d + R] += x.w;
        const base = castAt != null ? castAt : s.v0 + i - x.o, z = (t1 - (base + s.b1[i]) - mu) / sd;
        if (z < -5 || z > 5) continue;
        let l = x.w * Math.exp(-0.5 * z * z) * nrm;
        if (t2 != null) { const z2 = (t2 - (base + s.b2[i]) - mu) / sd; if (z2 < -5 || z2 > 5) continue; l *= Math.exp(-0.5 * z2 * z2) * nrm; }
        L[d + R] += l;
      }
    }
    for (let k = 0; k <= 2 * R; k++) L[k] = W[k] > 0 ? L[k] / W[k] : 0;
    return L;
  }
  function noFit(tables, T, taus, mu, sd, R, W, need, castAt) {
    const Ls = tables.map(p => tapWhy(p, T, taus, mu, sd, R, castAt));
    let S = 0; const tot = Ls.map(L => { let a = 0; for (let k = 0; k < L.length; k++) a += L[k]; S += a; return a; });
    if (!(S > 0)) return { k: 'none', n: taus.length };
    let pe = 0, pl = 0;
    for (let k = 0; k <= 2 * R; k++) { if (k < R) pe += Ls[0][k]; else if (k > R) pl += Ls[0][k]; }
    let best = null;
    Ls.forEach((L, j) => { for (let k = 0; k <= 2 * R; k++) { let a = 0; for (let q = Math.max(0, k - W); q <= Math.min(2 * R, k + W); q++) a += L[q]; if (!best || a > best.a) best = { a, j, d: k - R }; } });
    const o = { n: taus.length, pe: pe / S, pl: pl / S, pt: tot.map(a => a / S), j: best.j, d: best.d, pw: best.a / S };
    const jt = o.pt.indexOf(Math.max.apply(null, o.pt));
    if (o.pw >= need) o.k = best.j ? 'table' : 'cast';                       // sharp: the table and where the cast landed
    else if (jt > 0 && o.pt[jt] >= need) { o.k = 'table'; o.j = jt; o.d = null; }
    else if (o.pe >= need || o.pl >= need) { o.k = 'side'; o.j = 0; o.d = null; o.s = o.pe >= need ? -1 : 1; }
    else o.k = 'open';
    return o;
  }
  /* v30.21: the scenarios of a cast before any bite is tapped: every (variant, landed frame) the plan allows, weight =
     the variant's weight x the landing kernel; same fields as tapPosterior's `sc` (so biteAt works on them) */
  function scen(plan, T, sig, bias, cast) {
    const ct = cast && cast.c != null ? cast : null;
    const center = ct ? Math.round(ct.c) : Math.round(T), { k, r } = kernel(ct ? ct.sd : sig), sc = [], b = Math.round(bias || 0);
    for (const x of plan.variants) {
      const s = plan.series[x.s];
      if (!s || !(x.w > 0)) continue;
      const c0 = center + x.o - s.v0 + b;
      for (let d = Math.max(-r, (x.minT || 1) - center - b); d <= r; d++) {
        const i = c0 + d;
        if (i < 0 || i >= s.len || s.n1[i] < 0 || s.n2[i] < 0) continue;
        const base = ct ? ct.c : s.v0 + i - x.o;
        sc.push({ w: x.w * k[d + r], n1: s.n1[i], n2: s.n2[i], t1: base + s.b1[i], t2: base + s.b2[i], base, bx: s.bx ? s.bx[i] : null });
      }
    }
    return sc;
  }
  /* stopwatch spans holding most of the Nut-bite mass: bins of 6 VI with >= frac of the peak, merged when < gap apart */
  function nutSpans(items, frac, gap) {
    const bins = new Map();
    let m = 0;
    for (const [t, w] of items) { const b = Math.floor(t / 6); const v = (bins.get(b) || 0) + w; bins.set(b, v); if (v > m) m = v; }
    const out = [];
    for (const b of [...bins.keys()].sort((a, c) => a - c)) {
      if (!(bins.get(b) >= (frac || 0.25) * m && m > 0)) continue;
      const a = b * 6, e = (b + 1) * 6;
      if (out.length && a - out[out.length - 1][1] <= (gap || 30)) out[out.length - 1][1] = e; else out.push([a, e]);
    }
    return out;
  }
  /* v30, every bite: bite m (1-based) of a scenario -> [stopwatch VI, Nut 0/1], or null when unknown (no every-bite data
     for that cast state, or no such bite by the run's horizon) */
  function biteAt(e, m) {
    if (m === 1) return [e.t1, e.n1];
    if (m === 2) return [e.t2, e.n2];
    const bx = e.bx, q = m - 3;
    if (!bx || q >= bx.length) return null;
    return [e.base + Math.abs(bx[q]), bx[q] < 0 ? 1 : 0];
  }
  /* after j bites were tapped (held through each): the next bite j + 1. pNext = P(it is the Nut); pAny = P(a Nut on any
     later bite we know of); byBite = the Nut mass by bite; spans = Nut moments of bite j + 1 (6-VI bins of its time where
     releasing wins and that hold >= 25% of the peak: the green lamp); holds = bins where holding on wins (a Nut on a
     later bite outweighs a Nut on this one, >= 10% of the later-Nut peak): there the runner keeps B down and taps the
     bite; anywhere else the next bite is released (v29.9 rule: release bite 2). unknown = scenarios whose next bite is
     not in the data (old cast states without every-bite data, or after 90 s) */
  function forecast(post, j, frac, gap) {
    const A = new Map(), B = new Map(), items = [], byBite = {};
    let Z = 0, pNext = 0, pAny = 0, unk = 0, mA = 0, mB = 0;
    for (const e of post.sc) {
      const w = e.w;
      Z += w;
      const nx = biteAt(e, j + 1);
      if (!nx) { unk += w; continue; }
      let later = 0, first = nx[1] ? j + 1 : 0;
      for (let m = j + 2; m < j + 40; m++) { const bm = biteAt(e, m); if (!bm) break; if (bm[1]) { later = 1; if (!first) first = m; break; } }
      if (first) byBite[first] = (byBite[first] || 0) + w;
      pNext += w * nx[1]; pAny += w * (nx[1] || later ? 1 : 0);
      const bn = Math.floor(nx[0] / 6);
      if (nx[1]) { A.set(bn, (A.get(bn) || 0) + w); items.push([nx[0], w]); }
      if (later) B.set(bn, (B.get(bn) || 0) + w);
    }
    for (const v of A.values()) if (v > mA) mA = v;
    for (const v of B.values()) if (v > mB) mB = v;
    const merge = (keys, keep, g) => {
      const out = [];
      for (const bn of keys) {
        if (!keep(bn)) continue;
        const lo = bn * 6, hi = lo + 6;
        if (out.length && lo - out[out.length - 1][1] <= g) out[out.length - 1][1] = hi; else out.push([lo, hi]);
      }
      return out;
    };
    const spans = merge([...A.keys()].sort((a, c) => a - c), bn => A.get(bn) > (B.get(bn) || 0) && A.get(bn) >= (frac || 0.25) * mA, gap || 30);
    const holds = merge([...B.keys()].sort((a, c) => a - c), bn => B.get(bn) > (A.get(bn) || 0) && B.get(bn) >= 0.1 * mB, 0);
    items.sort((a, c) => a[0] - c[0]);
    let acc = 0, nutT = null;
    const nz = items.reduce((a, x) => a + x[1], 0);
    for (const [t, w] of items) { acc += w; if (acc >= nz / 2) { nutT = t; break; } }
    for (const m in byBite) byBite[m] /= Z || 1;
    return { j, pNext: Z ? pNext / Z : NaN, pAny: Z ? pAny / Z : NaN, unknown: Z ? unk / Z : NaN, spans, holds, nutT, byBite };
  }
  /* P(bite m was the Nut) under a posterior (the verdict on a tapped bite) */
  function biteNut(post, m) {
    let Z = 0, n = 0;
    for (const e of post.sc) { const b = biteAt(e, m); if (!b) continue; Z += e.w; n += e.w * b[1]; }
    return Z ? n / Z : NaN;
  }
  /* summary of a posterior: most likely dog path (+ share), most likely landed path VI on it, expected bite time and
     the tap lag it implies (tau - bite onset) */
  function tapSummary(post, tau) {
    if (!post || !post.sc.length) return null;
    const Z = post.sc.reduce((a, e) => a + e.w, 0), byPath = {}, byFrame = {};
    let t1 = 0, t1sq = 0;
    for (const e of post.sc) {
      byPath[e.path] = (byPath[e.path] || 0) + e.w / Z;
      const fk = e.path + ':' + (e.pv >> 1); byFrame[fk] = (byFrame[fk] || 0) + e.w / Z;
      t1 += e.w * e.t1 / Z; t1sq += e.w * e.t1 * e.t1 / Z;
    }
    const top = Object.entries(byPath).sort((a, b) => b[1] - a[1])[0], frame = Object.entries(byFrame).sort((a, b) => b[1] - a[1])[0];
    const sdT1 = Math.sqrt(Math.max(0, t1sq - t1 * t1));
    return { path: +top[0], pathShare: top[1], frameShare: frame[1], t1, sdT1, lag: tau - t1 };
  }
  /* Personal profile from stored taps [{k, T, tau, c?}]: stopwatch offsets by maximum evidence with a weak N(0, 9 VI)
     prior (bias: casts vs the aim, for taps without a cast tap; bias0: stopwatch vs console, for taps with one), the
     bite-tap lag (EM over the taps, starting at tapMu), then pair (dog path:offset) masses, shrunk to the route weights
     with alpha. */
  /* v30.23 (Thomas, 2026-11-19): `dogs` = what the dog-watch said about the dog line at the cast, one record per attempt
     {aid, k, dl: [[series, relative likelihood of the logs on that line], ...], fl: the same for every line not listed}.
     It multiplies that attempt's line shares before they are counted, and an attempt with dog logs but no bite tap is
     counted from the dog logs alone. The habit weights (`factor`) are then used everywhere the plan is: the aim, the
     dog-watch's candidate lines (so two lines the logs cannot separate are split by how often the runner is on each). */
  function profile(taps, sig, tapMu, tapSd, alpha, castCfg, tie, em, dogs) {
    alpha = alpha || 3;
    const use = taps.slice(-60).filter(t => plans.find(p => p.k === t.k));
    const dogUse = (dogs || []).slice(-60).filter(d => plans.find(p => p.k === d.k) && d.dl && d.dl.length);
    if (!use.length && !dogUse.length) return null;
    const dogBy = new Map(dogUse.map(d => [String(d.aid), d])), dogMap = new Map();
    const dlf = (d, sidx) => { let m = dogMap.get(d); if (!m) { m = new Map(d.dl); dogMap.set(d, m); } const v = m.get(sidx); return v != null ? v : (d.fl != null ? d.fl : 0.02); };
    const planOf = t => plans.find(p => p.k === t.k);
    const cc = castCfg || { sd: 3.4, tapSd: 2.4 }, castOf = t => (t.c != null ? { c: t.c, sd: cc.sd, tapSd: cc.tapSd } : null);
    const fitSd = Math.max(tapSd, 4);
    const post = (t, b, mu, sd) => tapPosterior(planOf(t), t.T, sig, b, t.tau, mu, sd, null, castOf(t), t.tau2);
    const LL = (sub, b, mu) => { let L = 0; for (const t of sub) L += Math.log(post(t, b, mu, fitSd).Z + 1e-12); return L; };
    const pb = b => -0.5 * (b / 9) ** 2, pm = mu => -0.5 * ((mu - 16) / 8) ** 2;   // weak priors (VI)
    const noCast = use.filter(t => t.c == null), withCast = use.filter(t => t.c != null);
    // the stopwatch offset and the bite-tap lag trade off (a late tap can look like a shifted cast), so they are fitted
    // jointly on the larger subset: coarse grid, then a per-VI refinement; the other subset's offset at that lag
    const main = withCast.length >= noCast.length ? withCast : noCast, other = main === withCast ? noCast : withCast;
    let best = { b: 0, mu: tapMu, L: -Infinity };
    const tryAt = (b, mu) => { const L = LL(main, b, mu) + pb(b) + pm(mu); if (L > best.L) best = { b, mu, L }; };
    /* tie (v29.10, taps without the cast tap): ONE reaction for screen events. The start tap comes k VIs later than the
       start-tap delay tie.d assumes, so the stopwatch runs k VIs behind the console (k = the clock's offset); the B press
       lands tie.p VIs after the CAST cue (measured by practice / real casts) -> b = tie.p + k. The bite tap comes the same
       tie.d + k after the bite, but the bite is read on the k-late stopwatch, so its lag in stopwatch terms is tie.d:
       mu = tie.d, whatever k is (first build had mu = d + k: the fit then sat at k = 0). One unknown, the bite taps pin it. */
    let kTied = null;
    if (tie && main === noCast) {
      let bk = { k: 0, L: -Infinity };
      for (let k = -18; k <= 18; k++) {
        /* v30.25: with the runner's bite reaction measured (bite practice: tie.rb), the "one reaction" assumption is not
           needed. The stopwatch runs k behind, so a bite tapped rb after the bite reads rb - k on it: mu = rb - k.
           Without it the old assumption stays (bite reaction = start reaction, mu = d) - and autoB() caps what it may
           do, because a runner whose bite taps are simply slower than his start taps then looks like a late clock
           (closed-loop test: 150 ms slower -> the casts were pushed 190 ms early). */
        const b = Math.round(tie.p + k), mu = Math.max(3, Math.round(tie.rb != null ? tie.rb - k : tie.d));
        const L = LL(main, b, mu) - 0.5 * (k / 9) ** 2;
        if (L > bk.L) bk = { k, L, mu };
      }
      kTied = bk.k;
      best = { b: Math.round(tie.p + kTied), mu: bk.mu != null ? bk.mu : Math.max(3, Math.round(tie.d)), L: bk.L };
    } else {
      for (let b = -18; b <= 18; b += 2) for (let mu = 6; mu <= 36; mu += 3) tryAt(b, mu);
      const c0 = best;
      for (let b = c0.b - 2; b <= c0.b + 2; b++) for (let mu = c0.mu - 2; mu <= c0.mu + 2; mu++) tryAt(b, mu);
    }
    const fit1 = sub => { let bb = 0, bl = -Infinity; for (let b = -18; b <= 18; b++) { const L = LL(sub, b, best.mu) + pb(b); if (L > bl) { bl = L; bb = b; } } return bb; };
    const bMain = best.b, bOther = other.length ? fit1(other) : 0;
    const bias = main === noCast ? bMain : bOther, bias0 = main === withCast ? bMain : bOther;
    const bOf = t => (t.c != null ? bias0 : bias);
    const lags = [];
    for (const t of use) { const r = post(t, bOf(t), best.mu, fitSd); const sm = tapSummary(r, t.tau); if (sm && r.Z > 1e-4 && sm.sdT1 < 8) lags.push(sm.lag); }
    const enough = lags.length >= 3, mu = best.mu;
    const lagSd = enough ? Math.sqrt(lags.reduce((a, x) => a + (x - mu) ** 2, 0) / (lags.length - 1)) : NaN;
    const muUse = enough ? mu : tapMu, sdUse = enough ? Math.max(tapSd, Math.min(8, lagSd)) : tapSd;
    let mass = {};
    let n = 0, nofit = 0, nDog = 0, nBoth = 0;
    const resp = [];                                                // per attempt: [[pair, share under the lab weights], ...]
    const p0 = {}, P = plans[0], W = P.variants.reduce((a, x) => a + x.w, 0);
    for (const x of P.variants) p0[x.s + ':' + x.o] = (p0[x.s + ':' + x.o] || 0) + x.w / W;
    const sOf = {}; for (const pair of Object.keys(p0)) sOf[pair] = +pair.split(':')[0];
    const seen = new Set();
    for (const t of use) {
      const r = post(t, bOf(t), muUse, sdUse);
      if (!r.sc.length || r.Z < 1e-4) { nofit++; continue; }
      const d = t.aid != null ? dogBy.get(String(t.aid)) : null, agg = {};
      let Z = 0;
      for (const e of r.sc) { const w = d ? e.w * dlf(d, sOf[e.pair] != null ? sOf[e.pair] : +e.pair.split(':')[0]) : e.w; Z += w; agg[e.pair] = (agg[e.pair] || 0) + w; }
      if (!(Z > 0)) { nofit++; continue; }
      if (d) { seen.add(d); nBoth++; }
      for (const pair in agg) { agg[pair] /= Z; mass[pair] = (mass[pair] || 0) + agg[pair]; }
      resp.push(Object.entries(agg));
      n++;
    }
    for (const d of dogUse) {                                       // dog logs, no (fitting) bite tap: the lab weights x the logs
      if (seen.has(d)) continue;
      const agg = {}; let Z = 0;
      for (const pair in p0) { const w = p0[pair] * dlf(d, sOf[pair]); agg[pair] = w; Z += w; }
      if (!(Z > 0)) continue;
      for (const pair in agg) { agg[pair] /= Z; mass[pair] = (mass[pair] || 0) + agg[pair]; }
      resp.push(Object.entries(agg));
      n++; nDog++;
    }
    /* v30.7 (learning test on the Mac, 2026-11-17): the single pass above judges every attempt with the LAB weights, so
       an attempt on one of the runner's usual lines is still spread over all the lines that could give that bite, and
       the habit was learned only weakly (weight on the true line 3% -> 7% where the runner was on it 27% of the time).
       `em` iterations re-judge each attempt with the weights learned so far (EM for the mixture of (line, READY offset)
       pairs, the lab weights as a Dirichlet prior of strength alpha). TRIED, NOT USED (em = 0 everywhere): it raises the
       weight on a habit runner's lines (36% -> 65% after 48 attempts) but not his odds (15.4% -> 14.4%, known exactly
       15.8%; tests/test_lucky_lineprior.js with EM=15): the single pass already aims where his lines pay. */
    for (let it = 0; it < (em || 0) && n; it++) {
      const m2 = {};
      for (const a of resp) {
        let Z = 0; const q = a.map(([pair, w]) => { const f = p0[pair] ? (alpha * p0[pair] + (mass[pair] || 0)) / (alpha + n) / p0[pair] : 1; Z += w * f; return w * f; });
        for (let i = 0; i < a.length; i++) m2[a[i][0]] = (m2[a[i][0]] || 0) + q[i] / Z;
      }
      mass = m2;
    }
    /* (v30.1 tried learning the habit per dog line instead of per (line, READY offset) pair: tests/test_lucky_lineprior.js
       gave the same weights and odds either way, so the rule is unchanged.) */
    const factor = pair => p0[pair] ? (alpha * p0[pair] + (mass[pair] || 0)) / (alpha + n) / p0[pair] : 1;
    const byPath = {};
    for (const [pair, m] of Object.entries(mass)) { const pth = +pair.split(':')[0]; byPath[pth] = (byPath[pth] || 0) + m / Math.max(1, n); }
    return { n, nofit, nDog, nBoth, nTap: n - nDog, bias, bias0, nCast: withCast.length, lag: enough ? { mu, sd: lagSd, n: lags.length } : null,
             tapMu: muUse, tapSd: sdUse, factor, byPath, kTied, tieFree: !!(tie && tie.free), tieRb: !!(tie && tie.rb != null), nNoCast: noCast.length };
  }
  function personal(plan, prof) {                                   // same tables, variants re-weighted by the profile
    if (!prof || !prof.n) return plan;
    return Object.assign(Object.create(Object.getPrototypeOf(plan)), plan,
      { variants: plan.variants.map(x => Object.assign({}, x, { w: x.w * prof.factor(x.s + ':' + x.o) })), personal: true });
  }
  return { prepare, select, planSet, groups, groupOf, groupFor, axId, routes, routeOf, curve, zoneAt, zoneCurve, valueWith, best, setGoal, score, get goal() { return goal; }, kernel, scen, tapWhy, noFit, dogAfterCast, tapPosterior, tapSummary, nutSpans, profile, personal,
           biteAt, forecast, biteNut,
           get plans() { return plans; }, get selection() { return Object.assign({}, sel); }, TMAX };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = LuckyCore; return; }
root.HM64Lucky = LuckyCore;
if (typeof document === 'undefined') return;

/* ================================================================== UI */
const Core = root.HM64Core, D = Core.data;
const $ = id => document.getElementById(id);
if (!$('luckyArena')) return;
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* storage unavailable */ } },
};
const viMs = () => Core.viMs();
const LDEF0 = { sigmaMs: 150, startDelayMs: 120, biasMs: 0, policy: 'auto', plan: 'auto', facing: 'SE', startKey: ' ',
               zoneBeeps: true, audio: false, castT: null, figure: 'jack', personal: true, dudPct: 1, dwOn: true, free: true, dwKeys: 'arrows', dwLead: 2,
               dwCards: 5, dwFill: 'rtl', frontOrder: ['lkPrev', 'lkPlanBox', 'lkDw'],   // v31.27: Thomas's layout (5 cards, top dog on the right)
               pace: 'all', anchor: 'dog', dogDelayMs: -130, castTap: false, tapPrecMs: 40,
               route: 'lineup-lineup2', routePace: {}, anchorDelayMs: { beach: 150, pier: 150 },
               /* v31.27 (Thomas, 2026-11-22): a fresh browser opens ready for the tester setup - beach-lineup2, ONE Space tap at
                  the end of the pier, dog-watch on, Freestyle on. Stored settings still override every one of these. */
               routeAnchor: { 'lineup-lineup2': 'pier', 'lineup-lineup2-sparrow-door': 'pier', 'lineup-dogbeach': 'pier', 'lineup-dogbeach-sparrow-door': 'pier' },
               pracLine: true, pracFull: false, pracAuto: false, autoTune: true,
               tapStrategy: 'ebd', beachCue: 'ctrl', tapSdAuto: true, tapSdMs: 60, tapDataOpen: false, sparrows: false, cueGlow: true, personalCast: false, biasAuto: true, sigmaAuto: true, startTapMs: null, tieReaction: true };
/* v32.1: a hub page (tools/site_build.py) is one game file: HM64_PAGE.luckyDefaults = its route and starts, HM64_PAGE.carry
   false = no Spring 9 dog-carry route (it is a no-horse route). All pages of one site share the stored settings, so the
   route is also kept per page (routeBySet) and a stored route the page does not have gives way to the page's own. */
const PG = (typeof HM64_PAGE !== 'undefined' && HM64_PAGE) || null;
const LDEF = (PG && PG.luckyDefaults)
  ? Object.assign({}, LDEF0, PG.luckyDefaults, { routeAnchor: Object.assign({}, LDEF0.routeAnchor, PG.luckyDefaults.routeAnchor || {}) })
  : LDEF0;
const L = Object.assign({}, LDEF, store.get('hm64v29_lucky', {}));
if (PG) {
  L.routeAnchor = Object.assign({}, L.routeAnchor);
  for (const k of Object.keys(LDEF.routeAnchor)) if (!(k in L.routeAnchor)) L.routeAnchor[k] = LDEF.routeAnchor[k];
  const onPage = id => (id === 'carry' ? PG.carry !== false : (D.lroutes || []).some(r => r.id === id));
  const mine = PG.set && L.routeBySet && L.routeBySet[PG.set];
  if (mine && onPage(mine)) L.route = mine;
  else if (!onPage(L.route)) L.route = LDEF.route;
}
{ /* settings saved by earlier v29.9 builds (double tap on/off, a list of cues) -> a tap strategy + one beach cue */
  const sv = store.get('hm64v29_lucky', {});
  if (!sv.tapStrategy && (sv.tapCues || sv.fadeDouble === false)) {
    const c = sv.fadeDouble === false && !sv.tapCues ? ['fade'] : sv.tapCues;
    L.tapStrategy = c.includes('exit') ? (c.includes('dock') ? 'ebd' : 'eb') : c.includes('dock') ? 'bd' : 'b';
    L.beachCue = c.includes('ctrl') ? 'ctrl' : 'fade';
  }
  delete L.tapCues; delete L.fadeDouble;
}
const save = () => store.set('hm64v29_lucky', L);
if (!L.cueV) { L.audio = false; L.cueV = 1; save(); }          // v29.10: visual cues; sound only if switched back on
if (!L.castTapV) { L.castTap = false; L.castTapV = 1; save(); } // v29.10: no Space-with-B cast tap by default (one reaction instead)
if (L.startTapMs == null) {                                    // v29.10: one start-tap delay for every start (the dog landing aside)
  const a = L.anchorDelayMs || {};
  L.startTapMs = a.fadein !== undefined ? a.fadein : a.pier !== undefined ? a.pier : 150; save();
}
const BITECOL = { 1: '#5fd38d', 2: '#e7c14a', 3: '#b48cff' };   // v30.10: Nut on bite 1 green, bite 2 gold, bite 3+ purple - everywhere
let tally = store.get('hm64v29_lucky_tally', []);
let taps = store.get('hm64v29_lucky_taps', []);                // bite-1 taps [{k, T (effective aim VI), tau, hit}]
{ /* v30.1 time base: stored tap times are VIs counted with the old ms-per-VI; the same wall-clock moments on the new one */
  const tb = store.get('hm64v30_tb', null);
  if (tb && tb.changed && !tb.taps && tb.from > 0 && tb.to > 0) {
    const f = tb.from / tb.to, cv = v => (typeof v === 'number' ? +(v * f).toFixed(1) : v);
    for (const t of taps) {
      for (const k of ['T', 'tau', 'tau2', 'c', 'cs']) if (t[k] != null) t[k] = cv(t[k]);
      if (Array.isArray(t.tx)) t.tx = t.tx.map(cv);
      t.tb = 1;
    }
    store.set('hm64v29_lucky_taps', taps);
    tb.taps = taps.length || true; store.set('hm64v30_tb', tb);
  }
}
let dogLines = store.get('hm64v30_doglines', []); if (!Array.isArray(dogLines)) dogLines = [];   // v30.23: what the dog-watch said about the line at the cast, per attempt
let dwcal = store.get('hm64v30_dwcal', []);                    // v30.1 dog-watch calibration, one entry per attempt whose bites named the line
let fade2 = store.get('hm64v29_lucky_fade2', []);              // double taps [{d: ms (tap 2 - tap 1 - gap), at, route}]
const OS = store.get('hm64v28_settings', {});
/* v30.19 bite practice (Thomas, 2026-11-19): reactions to Jack's bite animation, one record per bite:
   { at, r: ms from the first drawn bite frame to the tap (null = too early / missed), k: ok|late|early|miss, src }.
   With >= BP.min reactions (and "use it" on) their median / spread replace the generic bite-tap delay (13 VIs) wherever
   the attempts have not measured the runner's own lag yet, and serve as the starting value of that fit. */
const BP = { gap: [1400, 5200], miss: 1000, show: 1300, keep: 400, min: 8 };
let biteLog = store.get('hm64v30_lucky_biteprac', []); if (!Array.isArray(biteLog)) biteLog = [];
let bpCache = null;
/* v30.26 (Thomas, 2026-11-20): the drill is "hold the key, let go at the bite", as B on the N64. Records carry
   m: 'rel' (let go) or 'tap' (pressed; every record from before v30.26). The bite-tap delay the app needs is a PRESS
   reaction (in an attempt Space is pressed at the bite), so it takes the tap records when there are BP.min of them and
   the release records otherwise (a stand-in: letting go and pressing are close, not identical). */
const bpKind = r => (r.m === 'rel' ? 'rel' : 'tap');
const bpMode = () => (L.bpMode === 'tap' ? 'tap' : 'rel');
function bpReact() {                                           // robust stats of the reactions behind the bite-tap delay (ms)
  if (!bpCache || bpCache.n !== biteLog.length) {
    const of = k => castStats(biteLog.filter(r => bpKind(r) === k && Number.isFinite(r.r) && r.r >= 0).map(r => r.r));
    const tp = of('tap'), rl = of('rel'), useTap = tp && tp.n >= BP.min && isFinite(tp.sd);
    bpCache = { n: biteLog.length, s: useTap ? tp : rl && rl.n >= BP.min ? rl : tp || rl, kind: useTap ? 'tap' : rl && rl.n >= BP.min ? 'rel' : tp ? 'tap' : 'rel' };
  }
  return bpCache.s;
}
const bpReactKind = () => { bpReact(); return bpCache.kind; };
const bpLag = () => { if (L.bpUse === false) return null; const s = bpReact(); return s && s.n >= BP.min && isFinite(s.sd) ? s : null; };
const tapMu = () => { const s = bpLag(); return s ? s.med / viMs() : (OS.tapMuVI || 13); };
const tapSd = () => { const s = bpLag(); return Math.max(2.5, s ? s.sd / viMs() : (OS.tapSdVI || 3.5)); };
/* cast tap (key together with B): index spread = tap + start-key precision; the tap error also blurs the bite time */
const castCfg = () => { const v = L.tapPrecMs / viMs(); return { sd: Math.max(1.5, Math.hypot(v, v)), tapSd: v }; };
const lagMu = () => (prof && prof.lag ? prof.tapMu : tapMu());                    // the runner's bite-tap lag (VI)
const lagSd = () => (prof && prof.lag ? prof.tapSd : Math.max(tapSd(), 5));
/* v31.21 WAKE-UP REMINDER (Thomas 2026-11-21 16:03). Jack lies down after 40 s without input (player.c IDLE_NAP: 1200
   idle updates); a push of the stick down-right (south-east) resets that and changes neither the dog nor the random
   numbers (lab). The lab pushed every 2000 VIs (33.3 s) after READY on every cast later than that, so the cast data
   past 33 s is data WITH those pushes. A red line crosses the histogram at READY + 33.3 s, + 66.7 s ... to the end of
   the cast data, with 6.7 s to react before he would lie down; the lamp says PUSH DOWN-RIGHT for the first 5.5 s.
   Only while the cast is not made (fishing keeps him awake), and not within 0.5 s before the app's cast. */
const WAKE_EVERY = 2000, WAKE_SHOW = 330, WAKE_NAP = 400;
function wakeReady() {                                            // READY on this stopwatch: the picked dog's, else the plan's
  const w = run.dw, R = dwRoute();
  if (w && w.pick && R && run.wall0 !== null) return -(w.pick.a0 + w.adj);
  return R0();
}
function wakeEnd() {                                              // the last moment a cast can still be made: the plan's cast, or in freestyle the end of the cast data
  if (fsOn()) { if (run.fs.cast != null) return Math.min(run.fs.cast, run.fs.raw != null ? run.fs.raw : run.fs.cast); const w = run.dw, R = dwRoute(), e = w && w.pick && R ? dcLast(R, w.pick.dwi) : null; return wakeReady() + (e != null ? e : ((DCAST && DCAST.cast_until) || 5400) - 2); }
  return (run.castTap != null ? Math.min(run.castTap, run.T) : run.T) - 250;      // as before v31.21: no reminder when the cast comes within 4.2 s of the line (he lies down 6.7 s after it)
}
function wakeList() { const r0 = wakeReady(), end = wakeEnd(), out = []; for (let n = 1; r0 + n * WAKE_EVERY <= end && n < 20; n++) out.push(r0 + n * WAKE_EVERY); return out; }
function wakeNow(t) { if (run.wall0 === null || run.preview || run.practice || !run.plan) return null; const v = wakeList().find(x => t >= x && t < x + WAKE_SHOW); return v == null ? null : { at: v, left: (v + WAKE_NAP - t) * viMs() / 1000 }; }
function drawWake(g, X, y0, y1, dpr, W) {
  if (run.wall0 === null || run.preview || run.practice) return;
  for (const v of wakeList()) { const x = X(v), x1 = X(v + WAKE_NAP); if (x1 < 0 || x > W) continue;
    g.fillStyle = '#ef444422'; g.fillRect(x, y0, x1 - x, y1 - y0);
    g.strokeStyle = '#ef4444'; g.lineWidth = 3 * dpr; g.beginPath(); g.moveTo(x, y0); g.lineTo(x, y1); g.stroke();
    g.setLineDash([4 * dpr, 4 * dpr]); g.lineWidth = 1.5 * dpr; g.beginPath(); g.moveTo(x1, y0); g.lineTo(x1, y1); g.stroke(); g.setLineDash([]);
    g.font = `700 ${11 * dpr}px system-ui`; g.fillStyle = '#ff8a8a'; g.fillText('WAKE JACK · stick down-right', x + 5 * dpr, y0 + 24 * dpr);
    g.font = `${10 * dpr}px system-ui`; g.fillText('he lies down here', x1 + 4 * dpr, y0 + 36 * dpr); }
}
const WINDOW_VI = 20;                                                            // release window after the bite shows
let prof = null, profVer = 0;
const prof_ = () => prof;
const persCache = new Map();
const anchorOf = t => t.anchor || 'ready';                     // taps before v29.2 were all READY-started
const routeOfTap = t => t.route || 'carry';                     // taps before v29.5 were all on the dog-carry route
function updateProfile() {
  const mineF = t => anchorOf(t) === anchor() && routeOfTap(t) === route() && (anchor() !== 'fadein' || (t.ref || 'fade') === L.beachCue);
  const mine = taps.filter(mineF);                               // one clock reference per profile
  const dogs = L.dogHabit === true ? dogLines.filter(mineF) : [];   // off by default: in simulation it added nothing to the bite taps (tests/test_dogline_habit.js)
  const ps = L.tieReaction !== false ? pressReady() : null, dly = anchor() === 'dog' ? null : startDelay();
  /* v30.7 (learning test on the Mac, 2026-11-17: without cast practice the app learned nothing, 11.3% vs 13.3%): with
     no B presses on record the same one-reaction fit runs with p = 0, so what it finds is the whole landing offset
     (B-press habit + clock offset together). autoB() applies it to the clock as before; once >= 5 practice presses
     exist the press part moves to the cast-cue correction and the fit keeps only the clock part. */
  const br = bpLag();                                             // v30.25: the measured bite reaction, when bite practice has one
  const tie = L.tieReaction !== false && dly != null ? { p: ps ? ps.med / viMs() : 0, d: dly / viMs(), free: !ps, ...(br ? { rb: br.med / viMs() } : {}) } : null;
  prof = mine.length || dogs.length ? LuckyCore.profile(mine, sigStd(), tapMu(), tapSd(), 3, castCfg(), tie, 0, dogs) : null;
  profVer++; persCache.clear(); bestCache = null; ccache.clear();
}
function P(plan) {                                              // the plan as seen by this runner (profile weights)
  if (plan._final || !(L.personal && prof && prof.n)) return plan;   // _final: already re-weighted (dock-end tap)
  const key = selKey() + ':' + plan.k;
  if (!persCache.has(key)) persCache.set(key, LuckyCore.personal(plan, prof));
  return persCache.get(key);
}
let customSprites = store.get('hm64v29_angler', {});
const selAnchor = () => (L.route === 'carry' ? L.anchor : L.routeAnchor[L.route]);
const selPace = () => (L.route === 'carry' ? L.pace : (L.routePace || {})[L.route] || 'all');   // presets kept per route
LuckyCore.prepare(D, viMs(), { route: L.route, pace: selPace(), anchor: selAnchor() });
/* v30.6: the goal is set by syncGoal() at every refresh */
let plans = LuckyCore.plans;
const anchor = () => LuckyCore.selection.anchor;   // carry: 'dog' | 'ready'; route tables: their anchors (beach, pier)
const route = () => LuckyCore.selection.route;
const routeDef = () => LuckyCore.routeOf(route());
/* route variants (v29.10): a table that belongs to another route (variant_of), e.g. dog-beach's sparrow mornings,
   is not listed as a route; the base route shows a checkbox for it */
const baseOf = id => { const R = LuckyCore.routes().find(r => r.id === id); return (R && R.variant_of) || id; };
const variantOf = (base, v) => LuckyCore.routes().find(r => r.variant_of === base && r.variant === v) || null;
const sparrowTable = () => variantOf(baseOf(route()), 'sparrows');
const selKey = () => route() + '/' + LuckyCore.selection.pace + '/' + LuckyCore.selection.anchor;
const R0 = () => (plans[0] && plans[0].r0) || 0;               // READY on this stopwatch (no beach wait), VI
const ANAME = { dog: 'the dog lands', ready: 'READY', beach: 'beach entry', pier: 'READY (pier end)', fadein: 'the beach fade-in starts' };
const startName = () => ANAME[anchor()] || ((routeDef().anchors || []).find(a => a.id === anchor()) || {}).label || 'the start';
const keyName = () => (L.startKey === ' ' ? 'Space' : L.startKey);
const startDelay = () => (anchor() === 'dog' ? L.dogDelayMs : L.startTapMs);   // v29.10: one start-tap delay
function setSelection(pace, anch, rt) {                        // route / pace group / start anchor changed
  if (rt) L.route = rt;
  if (pace) { if (L.route === 'carry') L.pace = pace; else (L.routePace = L.routePace || {})[L.route] = pace; }
  if (anch) { if (L.route === 'carry') L.anchor = anch; else L.routeAnchor[L.route] = anch; }
  plans = LuckyCore.select({ route: L.route, pace: selPace(), anchor: selAnchor() });
  L.route = route();
  if (PG && PG.set) (L.routeBySet = Object.assign({}, L.routeBySet))[PG.set] = L.route;
  if (L.plan !== 'auto' && !plans.some(x => String(x.k) === String(L.plan))) L.plan = 'auto';
  L.castT = null; save();
  bestCache = null; ccache.clear(); persCache.clear();
  updateProfile(); fillLSettings(); refresh();
}
/* ---------------------------------------------------------------- your timing, harmonized (v29.10)
   One place (L5 · Your timing), four numbers about the same person, each learned from ALL of its data (auto) or set by
   hand - and each used once:
   - start taps: how late your start / clock taps come after their cue = the start-tap delay (one value for every start,
     the carry route's dog landing aside) + what auto-tune learns from your bite taps on this start;
   - B press on CAST: how late you press B vs the CAST cue = cast practice + real casts (the cast tap), same cue type
     (visual / sound); the CAST cue moves by minus their median (the cast-cue correction);
   - bite taps: how late you tap after a bite shows (the bite-tap profile);
   - how much you vary: your B presses' SD with the start tap's 60 ms = the timing spread.
   Two kinds of timing, on purpose kept apart: REACTING to something you could not time (start cue, bite: ~150-300 ms
   late) and pressing ON a countdown you saw coming (CAST: near 0, often a little early). They are the same person but
   not the same number.
   Auto-tune (the clock): from attempts with the cast tap, no assumption needed; without it (the default since the
   4th build of 2026-11-16) a bite tap mixes clock, B press and bite-tap lag, so it assumes ONE reaction for screen
   events (your start taps and your bite taps come equally late) and takes the B press from your presses: then the
   bite taps pin the clock (LuckyCore.profile tie). The B press belongs to the cast-cue correction alone. */
let pressCache = { key: null, v: null };
function pressData() {                                          // practice presses (current mode, cue type) + real casts
  const last = a => (a.length ? a[a.length - 1].at || 0 : 0);
  const key = [pracLog.length, last(pracLog), tally.length, last(tally), L.audio, L.pracLine].join(':');
  if (pressCache.key !== key) {
    const pr = pracErrs(pracMode()).slice(-80), at = attemptErrs().slice(-40), es = pr.concat(at);
    pressCache = { key, v: { pr, at, es, s: castStats(es) } };
  }
  return pressCache.v;
}
const pressReady = () => { const d = pressData(); return d.s && d.s.n >= 5 ? d.s : null; };
const cueCorr = () => { if (L.biasAuto !== false) { const s = pressReady(); if (s) return -Math.round(s.med); } return L.biasMs; };
/* how well the clock's offset is known: learned from cast-tap attempts (auto-tune), else +-60 ms assumed */
const offsetSdMs = () => (L.autoTune && prof && (prof.nCast || 0) >= 8 ? Math.hypot(castCfg().sd, castCfg().tapSd) * viMs() / Math.sqrt(prof.nCast) : 60);
/* the one timing spread (standard plan): your B presses' spread, one start tap (+-60 ms; the clock taps replace it on the
   fade-in start) and how well the clock offset is known - the same parts as the personalized kernel, as a bell curve */
const sigmaFrom = sd => Math.max(40, Math.min(400, Math.round(Math.sqrt(sd ** 2 + PRAC.startSd ** 2 + offsetSdMs() ** 2) / 10) * 10));
const sigmaMs = () => {
  if (L.sigmaAuto !== false) { const s = pressReady(); if (s && isFinite(s.sd)) return sigmaFrom(s.sd); }
  return L.sigmaMs;
};
const sigStd = aid => Math.max(1, sigEffMs(aid) / viMs());   // the standard Gaussian spread (VIs)
const sigVI = aid => (L.personalCast ? personalKernel(aid) : null) || sigStd(aid);
const sigTag = aid => (L.personalCast ? (personalKernel(aid) || {}).id : null) || String(sigEffMs(aid));   // cache keys
/* ---------------------------------------------------------------- personalized cast suggestions (v29.10, experimental)
   Off (default): the cast lands Gaussian around the aim with the timing spread (slider + the tap cascade), so the
   suggestion goes for the highest peak that spread can hit. On: the landing kernel is YOUR measured timing - every B
   press you made to the cast cue (cast practice with the same cue type, real casts logged with the cast tap; beyond
   3 MAD left out), after the current cast-cue correction, each smeared by the clock's error (clock-tap spread /
   sqrt(clock taps)) and by how well your console offset is known (auto-tune: one bite tap's spread / sqrt(bite taps);
   not learned yet: +-60 ms). A late, loose or lopsided habit gives a wide, lopsided kernel and the best aim moves off
   narrow peaks onto wide plateaus by itself (best expected odds under your own timing); a tight one keeps the peaks.
   Under 8 presses it falls back to the slider's B-press part, Gaussian, plus the same clock and offset terms. */
const PK_MIN = 8, PK_OFFSET_UNKNOWN_MS = 60, PK_RMAX = 60;
const pkCache = new Map();
function trimmed(es) {                                          // the presses castStats keeps (within 3 MAD of the median)
  const v = es.filter(Number.isFinite).slice().sort((a, b) => a - b), n = v.length;
  if (!n) return [];
  const q = (a, f) => a[Math.min(a.length - 1, Math.max(0, Math.round(f * (a.length - 1))))];
  const md = q(v, 0.5), mad = 1.4826 * q(v.map(x => Math.abs(x - md)).sort((a, b) => a - b), 0.5);
  return v.filter(x => Math.abs(x - md) <= Math.max(3 * mad, 40));
}
function pkParts(aid) {
  aid = aid || anchor();
  const vi = viMs(), pr = pracErrs(pracMode()).slice(-80), at = attemptErrs().slice(-40);
  const es = trimmed(pr.concat(at)).map(e => e + cueCorr());    // landing vs the aim (ms): the cue sits at aim + correction
  const nC = aid === 'fadein' ? Math.max(1, clockCues().length) : 1;
  const sc = aid === 'fadein' && route() !== 'carry' ? clockSd() / Math.sqrt(nC) : START1_MS;
  const sb = offsetSdMs(), sbSrc = L.autoTune && prof && (prof.nCast || 0) >= 8 ? `auto-tune, ${prof.nCast} cast-tap attempts` : 'not learned yet';
  const mean = es.length ? es.reduce((a, x) => a + x, 0) / es.length : 0;
  const sd = es.length > 1 ? Math.sqrt(es.reduce((a, x) => a + (x - mean) ** 2, 0) / (es.length - 1)) : NaN;
  const skew = es.length > 2 && sd > 0 ? es.reduce((a, x) => a + ((x - mean) / sd) ** 3, 0) / es.length : 0;
  return { aid, es, nPr: pr.length, nAt: at.length, sc, sb, sbSrc, mean, sd, skew, enough: es.length >= PK_MIN };
}
let pkFast = { key: null, map: new Map() };
function personalKernel(aid) {                                  // cheap key first: it is asked for on every cache lookup
  aid = aid || anchor();
  let h = 0;                                                    // checksum of the presses it would use (contents, not just counts)
  for (const e of pracErrs(pracMode()).slice(-80).concat(attemptErrs().slice(-40))) h = (h * 31 + Math.round(e * 10)) % 1000000007;
  const fk = [h, cueCorr(), Math.round(clockSd()), profVer, sigmaMs(), L.audio, L.pracLine, L.autoTune, route(), clockCues().length, viMs()].join(':');
  if (pkFast.key !== fk) pkFast = { key: fk, map: new Map() };
  if (!pkFast.map.has(aid)) pkFast.map.set(aid, personalKernelRaw(aid));
  return pkFast.map.get(aid);
}
function personalKernelRaw(aid) {
  const P_ = pkParts(aid), vi = viMs();
  const xs = P_.enough ? P_.es : [0];
  const h = P_.enough ? Math.max(10, 1.06 * (P_.sd || 30) * Math.pow(xs.length, -0.2)) : Math.sqrt(Math.max(sigmaMs() ** 2 - START1_MS ** 2, 30 ** 2));
  const w = Math.sqrt(h * h + P_.sc ** 2 + P_.sb ** 2);
  const key = [P_.aid, xs.map(x => Math.round(x)).join(','), Math.round(w)].join('|');
  if (pkCache.has(key)) return pkCache.get(key);
  const lo = Math.floor((Math.min(...xs) - 4 * w) / vi), hi = Math.ceil((Math.max(...xs) + 4 * w) / vi);
  const r = Math.min(PK_RMAX, Math.max(Math.abs(lo), Math.abs(hi), 1)), k = new Float32Array(2 * r + 1);
  let z = 0;
  for (let d = -r; d <= r; d++) { let a = 0; for (const x of xs) a += Math.exp(-0.5 * ((d * vi - x) / w) ** 2); k[d + r] = a; z += a; }
  let m1 = 0, m2 = 0, sum = 0;
  for (let d = -r; d <= r; d++) { k[d + r] /= z; m1 += d * k[d + r]; m2 += d * d * k[d + r]; }
  let hsh = 7;
  for (let i = 0; i < k.length; i++) hsh = (hsh * 31 + Math.round(k[i] * 1e4)) % 1000000007;
  const out = { id: `pk${r}:${hsh}`, k, r, sd: Math.max(1, Math.sqrt(Math.max(0, m2 - m1 * m1))), mean: m1, wMs: w, parts: P_ };
  if (pkCache.size > 40) pkCache.clear();
  pkCache.set(key, out);
  return out;
}
function personalTxt() {                                       // what the personalized suggestion uses, and what it changes
  if (!L.personalCast) return '';
  const pk = personalKernel(), P_ = pk.parts, vi = viMs(), plan = run.plan, pol = run.pol === 'tap' ? 'hold' : run.pol;
  if (!plan) return '';
  const sg = v => (v >= 0 ? '+' : '−') + Math.abs(Math.round(v));
  let h = '<b>Personalized:</b> ' + (P_.enough
    ? `your ${P_.es.length} B presses (${P_.nPr} practice, ${P_.nAt} real casts) land ${sg(P_.mean)} ms vs the aim with the current correction, spread ±${Math.round(P_.sd)} ms` +
      (Math.abs(P_.skew) >= 0.4 ? `, lopsided ${P_.skew > 0 ? 'late' : 'early'}` : '')
    : `only ${P_.es.length} B presses to the ${L.audio ? 'beep' : 'visual cue'} (8 needed): your ${sigmaMs()} ms timing spread stands in for the B press`) +
    `; clock ±${Math.round(P_.sc)} ms; console offset known ±${Math.round(P_.sb)} ms (${P_.sbSrc}) → landing spread ±${Math.round(pk.sd * vi)} ms` +
    (Math.abs(pk.mean * vi) >= 10 ? `, centred ${sg(pk.mean * vi)} ms` : '') + '. ';
  try {                                                         // the standard aim, played with your timing
    const pp = P(plan), bs = LuckyCore.best(pp, sigStd(), 30 + R0()), Ts = bs[pol] ? bs[pol].t : -1;
    if (Ts > 0) {
      const val = T => (pol === 'zone' ? (LuckyCore.zoneAt(pp, T, pk) || {}).value : LuckyCore.curve(pp, pk, pol).P[T]);
      const vMine = val(run.T), vStd = val(Ts);
      h += Ts === run.T ? `Same aim as the standard suggestion (${fmtS(Ts)}).`
        : `Aim ${fmtS(run.T)}: <b>${pct(vMine)}</b> with your timing; the standard aim ${fmtS(Ts)} (±${sigEffMs()} ms Gaussian) would give ${pct(vStd)} with your timing.`;
    }
  } catch (e) { /* plan not ready */ }
  return h;
}
const now = () => performance.now();
/* v29.9 double tap on the fade-in start. Goalpost 1 = the first frame Jack stands still at the ranch exit, which is also
   the first dimmer frame (main loop EXIT_LEVEL, game.c handleExitLevel: map + entities fade at rate 8/frame);
   goalpost 2 = the first non-black beach frame (LEVEL_LOAD + 2 VIs). Lab (rendered + 30/30 ranch states): 70 VIs apart
   every time. Both taps estimate the fade-in moment (tap 2 directly, tap 1 + gap + your learned difference m), so the
   start uses their average: a steadier start, and a missed or fumbled tap is caught. The pair cannot give the absolute
   reaction (both taps carry one); that offset still comes from the bite taps. */
const GP_GAP_VI = 70;
const gapMs = () => GP_GAP_VI * viMs();
function fadeStats() {
  const ds = fade2.slice(-30).map(x => x.d).sort((a, b) => a - b), n = ds.length;
  if (!n) return { n: 0, m: 0, med: NaN, sd: NaN };
  const med = n % 2 ? ds[(n - 1) / 2] : (ds[n / 2 - 1] + ds[n / 2]) / 2, mean = ds.reduce((a, v) => a + v, 0) / n;
  let sd = n > 1 ? Math.sqrt(ds.reduce((a, v) => a + (v - mean) ** 2, 0) / (n - 1)) : NaN;
  if (n >= 5) {                                                 // robust (MAD) once there are a few: one fumble can't inflate it
    const dev = ds.map(v => Math.abs(v - med)).sort((a, b) => a - b), mad = n % 2 ? dev[(n - 1) / 2] : (dev[n / 2 - 1] + dev[n / 2]) / 2;
    sd = Math.max(1.4826 * mad, 5);
  }
  return { n, m: med * n / (n + 2), med, sd };                  // m shrunk toward 0 (same reaction to both) while pairs are few
}
const run = { wall0: null, T: null, plan: null, pol: null, zone: null, beeped: new Set(), result: null, resultAt: 0,
              preview: null, practice: null };
let bestCache = null;

/* ---------------------------------------------------------------- audio */
let actx = null;
function audio() { if (!L.audio) return null; try { actx = actx || new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { actx = null; } return actx; }
let pending = [];
function cancelBeeps() { pending.forEach(g => { try { g.disconnect(); } catch (e) { /* gone */ } }); pending = []; }
function beepAt(wall, f, dur, vol) {
  const a = audio(); if (!a) return;
  const t = a.currentTime + Math.max(0, (wall - now()) / 1000);
  const o = a.createOscillator(), g = a.createGain();
  o.frequency.value = f; o.connect(g); g.connect(a.destination);
  g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol || 0.25, t + 0.005); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.start(t); o.stop(t + dur + 0.02); pending.push(g);
}

/* ---------------------------------------------------------------- plan choice */
function planObj() {
  if (L.plan !== 'auto') { const p = plans.find(x => String(x.k) === String(L.plan)); if (p) return p; }
  return bestOverall().plan;
}
function bests() {
  const key = sigTag() + ':' + selKey() + ':' + plans.length + ':' + profVer + ':' + L.personal + ':' + (LuckyCore.goal ? LuckyCore.goal.over : 'odds');
  if (bestCache && bestCache.key === key) return bestCache.list;
  const list = plans.map(p => { const b = LuckyCore.best(P(p), sigVI(), 30 + R0()); b.tap = b.hold; return { plan: p, b }; });
  bestCache = { key, list };
  return list;
}
function bestOverall() {
  let top = null;
  for (const x of bests()) for (const pol of ['zone', 'bite1', 'hold']) {
    const b = x.b[pol];
    const score = LuckyCore.score(b.t, b.p) * (x.plan.cover >= 0.8 ? 1 : x.plan.cover);   // partly covered plans only if nearly complete
    if (b.t > 0 && (!top || score > top.score)) top = { plan: x.plan, pol, t: b.t, p: b.p, score };
  }
  return top || { plan: plans[0], pol: 'bite1', t: 150, p: 0 };
}
function polOf(plan) {
  if (L.policy !== 'auto') return L.policy;                    // 'tap' = hold-only + bite-1 tap
  const b = bests().find(x => x.plan === plan).b;
  return ['zone', 'bite1', 'hold'].reduce((a, p) => (LuckyCore.score(b[p].t, b[p].p) > LuckyCore.score(b[a].t, b[a].p) ? p : a), 'zone');
}
function castT(plan, pol) {
  if (L.castT !== null && L.castT >= plan.firstT) return L.castT;
  return bests().find(x => x.plan === plan).b[pol].t;
}
function valueAt(plan, pol, T) {
  if (pol === 'zone') { const z = LuckyCore.zoneAt(P(plan), T, sigVI()); return z ? z.value : NaN; }
  return curveC(plan, pol)[T];
}
const ccache = new Map();
/* v30.25: the aim against the curve the lane draws. ok = the aim's value is within 0.3 points (or 3%) of the best cast
   that could still be chosen (live: 2 s or more ahead). Otherwise `why` says what holds the aim where it is. */
function aimCheck(P, T, tNow) {
  if (!P || !(T > 0)) return null;
  const from = tNow != null ? Math.max(1, Math.ceil(tNow) + 120) : 1;
  let pb = -1, tb = -1;
  for (let v = from; v < P.length; v++) if (P[v] > pb) { pb = P[v]; tb = v; }
  const pAim = P[Math.round(T)] || 0;
  if (pb < 0) return { ok: true, pAim, pBest: pAim, tBest: T, ahead: tNow != null };
  const ok = pAim >= pb - Math.max(0.003, 0.03 * pb);
  const why = ok ? '' : L.castT !== null ? 'the cast time is set by hand (Back to best)' : goalTime() ? 'you aim for the fastest Nut, not the best odds' :
    tNow != null && T - tNow < 240 ? 'too close to the cast to move it' : tNow != null ? 'the cast moves only for a gain of 0.2 points with 4 s to spare' : 'another policy has better odds at its own best cast';
  return { ok, pAim, pBest: pb, tBest: tb, why, ahead: tNow != null };
}
const fcache = new WeakMap(), xcache = new WeakMap();
/* v30.31 (whole-tool lab, Mac 2026-11-20): the smart-zones curve is worked out every 6 VIs and drawn straight between;
   with the dog-watch down to a few lines the peaks are narrower than that, and the curve at the aim read 0.5 - 2.7
   points under the exact odds shown beside it (55 - 66 of 150 attempts). Around the aim (+-6 VIs) the drawn curve now
   holds the exact values, so the curve under the CAST ghost and the odds are one number. */
function curveAim(base, plan, pol) {
  if (pol !== 'zone' || !run.plan || run.plan !== plan || !(run.T > 0)) return base;
  const T = Math.round(run.T);
  let m = xcache.get(base); if (!m) { m = new Map(); xcache.set(base, m); }
  if (!m.has(T)) {
    const c = base.slice(), Q = P(plan), sg = sigVI();
    for (let t = Math.max(1, T - 6); t <= Math.min(c.length - 1, T + 6); t++) { const z = LuckyCore.zoneAt(Q, t, sg, sg, false); if (z) c[t] = z.value; }
    if (m.size > 8) m.clear();
    m.set(T, c);
  }
  return m.get(T);
}
function curveC(plan, pol) { if (pol === 'tap') pol = 'hold'; return curveAim(curveC0(plan, pol), plan, pol); }
function curveC0(plan, pol) {                                   // cached per plan, policy, spread and profile
  if (pol === 'tap') pol = 'hold';
  const calc = () => (pol === 'zone' ? LuckyCore.zoneCurve(P(plan), sigVI(), 6) : LuckyCore.curve(P(plan), sigVI(), pol).P);
  /* v30.25 BUG FIX: a plan re-weighted during the attempt (dock-end tap, dog-watch, a picked dog) keeps its key `k`, so
     it was served the curve of the plan it came from: the P(Nut) lane kept showing the curve from before the re-weighting
     while the cast was aimed on the re-weighted plan - the aim could then stand in a valley of the bars. Such plans
     (`_final`) now get their own curve, kept per plan object. */
  if (plan._final) {
    let m = fcache.get(plan); if (!m) { m = {}; fcache.set(plan, m); }
    const k2 = pol + ':' + sigTag();
    if (!(k2 in m)) m[k2] = calc();
    return m[k2];
  }
  const key = selKey() + ':' + plan.k + ':' + pol + ':' + sigTag() + ':' + profVer + ':' + L.personal;
  if (!ccache.has(key)) ccache.set(key, calc());
  return ccache.get(key);
}
const fmtS = vi => ((vi - 1) * viMs() / 1000).toFixed(2) + ' s';
const pct = p => isNaN(p) ? '—' : (100 * p).toFixed(1) + '%';
const POLNAME = { zone: 'Smart zones', bite1: 'Release at 1st bite', hold: 'Hold → release 2nd bite', tap: '2nd bite + tap bite 1' };

/* ---------------------------------------------------------------- plan panel */
function renderPlans() {
  const cur = planObj(), list = bests();
  $('lkPlans').innerHTML = '';
  for (const { plan, b } of list) {
    const pol = ['zone', 'bite1', 'hold'].reduce((a, p) => (b[p].p > b[a].p ? p : a), 'zone');
    const el = document.createElement('div');
    el.className = 'lkcard' + (plan === cur ? ' sel' : '');
    el.innerHTML = `<div class="small mut">${plan.label}</div><div class="share">${pct(b[pol].p)}</div>` +
      `<div class="small mono">cast ${b[pol].t > 0 ? fmtS(b[pol].t) : '—'}</div><div class="small mut">${POLNAME[pol]}</div>` +
      (plan.cover < 0.999 ? `<div class="small mut">${(100 * plan.cover).toFixed(0)}% of routes</div>` : '');
    el.onclick = () => { L.plan = String(plan.k); L.castT = null; save(); refresh(); };
    $('lkPlans').appendChild(el);
  }
  if (plans.length === 1 && route() === 'carry' && (anchor() === 'ready' ? !D.lucky : D.lucky)) {
    const el = document.createElement('div');
    el.className = 'lkcard dim';
    el.innerHTML = '<div class="small mut">1–3 whistles</div><div class="small">' +
      (anchor() === 'ready' ? (LuckyCore.selection.pace === 'all' ? 'needs the <b>lucky</b> lab run' : 'pace <b>All</b> only') : 'READY start only') + '</div>';
    $('lkPlans').appendChild(el);
  }
  $('lkPlans').hidden = !$('lkPlans').children.length || (plans.length === 1 && (!!D.pace || route() !== 'carry') && $('lkPlans').children.length === 1);
  document.querySelectorAll('#lkPol button').forEach(b => b.classList.toggle('on', b.dataset.pol === L.policy));
  /* v30.16: the button is lit only while something is set by hand (then it does something); else it says so */
  const hand = autoHand(), ab = $('lkAutoPlan');
  ab.classList.toggle('on', hand.length > 0); ab.disabled = !hand.length;
  ab.textContent = hand.length ? 'Back to best' : 'Auto ✓';
  ab.title = hand.length ? `Set by hand: ${hand.join(', ')}. Click: the app picks them again (best odds for your timing).` : 'The app picks the cast time and what to do after the cast (best odds for your timing). Nothing is set by hand.';
}
function autoHand() {                                           // what the player has taken over from the app
  const h = [];
  if (L.castT != null) h.push('the cast time');
  if (L.policy !== 'auto') h.push('after the cast: ' + (POLNAME[L.policy] || L.policy));
  if (L.plan !== 'auto') h.push('the plan');
  return h;
}
/* ---------------------------------------------------------------- pace presets (D.pace) */
const POLSHORT = { zone: 'smart zones', bite1: '1st bite', hold: '2nd bite' };
const paceCache = new Map();
function paceRow(g) {                                          // best plan for one pace group (no profile), cached
  const key = sigTag() + ':' + anchor() + ':' + route() + ':' + g.id;
  if (paceCache.has(key)) return paceCache.get(key);
  const sig = sigVI(), plan = LuckyCore.planSet(g.id, anchor(), route())[0], b = LuckyCore.best(plan, sig, 30 + R0());
  const pol = ['zone', 'bite1', 'hold'].reduce((a, q) => (b[q].p > b[a].p ? q : a), 'zone');
  const z = pol === 'zone' ? LuckyCore.zoneAt(plan, b.zone.t, sig, sig, true) : null;
  const r = { g, plan, b, pol, t: b[pol].t, p: b[pol].p, zones: z ? z.zones : null, cross: {} };
  paceCache.set(key, r);
  return r;
}
const startCache = new Map();
function startRow(g, aid) {                                    // v29.9: best plan for one preset on a given start (no profile)
  const key = sigTag(aid) + ':' + aid + ':' + route() + ':' + g.id;
  if (startCache.has(key)) return startCache.get(key);
  const plan = (LuckyCore.planSet(g.id, aid, route()) || [])[0];
  if (!plan) return null;
  const sig = sigVI(aid), b = LuckyCore.best(plan, sig, 30 + (plan.r0 || 0));
  const pol = ['zone', 'bite1', 'hold'].reduce((a, q) => (b[q].p > b[a].p ? q : a), 'zone');
  const r = { aid, t: b[pol].t, p: b[pol].p, pol, r0: plan.r0 || 0 };
  startCache.set(key, r);
  return r;
}
function startCompare() {                                      // every start of a multi-line route for the selected preset
  const R = routeDef();
  if (!R.groups || !R.anchors || R.anchors.length < 2) return null;
  const g = R.groups.find(x => x.id === LuckyCore.selection.pace) || R.groups[0];
  const rows = R.anchors.map(a => ({ a, r: startRow(g, a.id) })).filter(x => x.r && x.r.p >= 0);
  if (rows.length < 2) return null;
  return { rows, best: rows.reduce((a, x) => (x.r.p > a.r.p ? x : a), rows[0]) };
}
const startShort = a => ANAME[a.id] || a.label;
function startTxt() {                                          // "Start: fade-in 13.3% · dock end 13.4% -> best ..."
  if (anchor() === 'pier' && !pierOnly) return '';               // v31.27: the one-tap dock-end start does not advertise the multi-tap start
  const c = startCompare();
  if (!c) return '';
  const cur = c.rows.find(x => x.a.id === anchor()), tie = cur && pct(cur.r.p) === pct(c.best.r.p);
  return ` <span class="small">Start: ${c.rows.map(x => (x.a.id === anchor() ? '<b>' : '') + startShort(x.a) + ' ' + pct(x.r.p) + ' (cast ' + fmtS(x.r.t) + ' after it)' + (x.a.id === anchor() ? '</b>' : '')).join(' · ')}` +
    (tie ? ' → this start is the best for this preset.' : ` → best for this preset: <b>${startShort(c.best.a)}</b> <a href="#" data-start="${c.best.a.id}">use it</a> (or change it under Start).`) + '</span>';
}
function labelStarts() {                                       // the Start menu shows each start's best odds for this preset
  let c = null;
  const sel = $('lkAnchor');
  try { c = startCompare(); } catch (e) { return; }
  if (!c || !sel) return;
  for (const o of sel.options) {
    const x = c.rows.find(y => y.a.id === o.value);
    if (x) o.textContent = `${x.a.label} — ${pct(x.r.p)}${pct(x.r.p) === pct(c.best.r.p) ? ' (best for this preset)' : ''}`;
  }
}
const crossOf = (r, o) => {                                    // r's cast plan if the runner really is in group o
  if (!(o.g.id in r.cross)) r.cross[o.g.id] = LuckyCore.valueWith(o.plan, r.t, sigVI(), r.pol, r.zones);
  return r.cross[o.g.id];
};
const sameAx = (a, b) => Object.keys(a).length === Object.keys(b).length && Object.keys(a).every(k => a[k] === b[k]);
const axGroup = (R, ax) => R.groups.find(g => sameAx(g.ax || {}, ax));
function axSel() {                                             // axes route: the selected group's tags ({} = all routes)
  const R = routeDef(), g = R.groups.find(y => y.id === LuckyCore.selection.pace);
  return (g && g.ax) || {};
}
function paceRows() {                                          // best plan per visible pace group (no profile)
  const R = routeDef();
  if (!(R.groups || (D.pace && route() === 'carry'))) return [];
  if (R.axes) {                                                // two cuts: all + every 1st cut; 2nd cuts once a 1st cut is picked
    const [A1, A2] = R.axes, gx = guessAx(), ax = gx ? Object.assign({}, axSel(), gx.ax) : axSel(), gs = [axGroup(R, {})].concat(A1.opts.map(o => axGroup(R, { [A1.id]: o.id })));
    if (ax[A1.id]) for (const o of A2.opts) gs.push(axGroup(R, { [A1.id]: ax[A1.id], [A2.id]: o.id }));
    return gs.filter(Boolean).map(paceRow);
  }
  const rows = LuckyCore.groups().map(paceRow);
  for (const r of rows) for (const o of rows) if (o !== r) crossOf(r, o);
  return rows;
}
const bandTxt = g => (g.band ? g.band : g.id === 'all' ? 'everyone' : g.hi >= 999 ? `${g.lo}+ frames` : g.lo === 0 ? `≤ ${g.hi} frames` : `${g.lo}–${g.hi} frames`);
function renderPace() {
  const rows = paceRows(), box = $('lkPace');
  if (!box) return;
  box.innerHTML = '';
  $('lkPaceHead').hidden = !rows.length;
  $('lkPaceHead').textContent = routeDef().axes_head ? routeDef().axes_head : routeDef().axes
    ? 'Presets by how you cut on the beach. Pick your 1st cut (down-left after the small wall), then your 2nd cut (down-right onto the pier): the 2nd-cut odds count only routes with that 1st cut. Each pick has its own best cast; ★ = best 2nd cut for that 1st cut.'
    : routeDef().groups
    ? 'Presets by how you cut on the beach: first cut (down-left after the small wall) and pier cut (down-right onto the pier). Pick the one that fits how you play; each has its own best cast.'
    : 'Your pace = total hesitation before the dog lands (4 menu presses + walking). Pick the one you think fits you; each has its own best cast.';
  if (!rows.length) {
    box.hidden = true;
    const R = routeDef();
    $('lkPaceTxt').innerHTML = R.id === 'carry' ? '' : `<b>${R.label}</b>: one dog line (${R.source ? R.source.casts + ' cast frames, ' + R.source.nut1 + ' Nut on bite 1, ' + R.source.nut2 + ' on bite 2' : ''}). ` +
      `${R.note || ''} Your bite taps check it: a bite that fits no cast frame on this line means you were on another line.`;
    return;
  }
  box.hidden = false;
  if (routeDef().axes) return renderAxes(rows);
  const tot = rows[0].g.routes || 1;
  for (const r of rows) {
    const el = paceCard(r, r.g.id === LuckyCore.selection.pace, r.g.label, bandTxt(r.g));
    el.title = r.g.desc ? `${r.g.desc}: ${Math.round(100 * r.g.share)}% of the simulated routes` + (r.g.cover < 0.999 ? ` (casts cover ${Math.round(100 * r.g.cover)}%)` : '')
      : r.g.id === 'all' ? 'All measured routes, as before' : `Routes whose menus + walking hesitate ${bandTxt(r.g)} (video frames, 16.7 ms each) in total before the dog lands: ${Math.round(100 * r.g.routes / tot)}% of the measured routes`;
    el.onclick = () => setSelection(r.g.id, null);
    box.appendChild(el);
  }
  const cur = rows.find(r => r.g.id === LuckyCore.selection.pace) || rows[0];
  const others = rows.filter(r => r !== cur).map(r => `${r.g.label} ${pct(crossOf(cur, r))}`).join(' · ');
  $('lkPaceTxt').innerHTML = `<b>${cur.g.label}</b>: cast <b>${fmtS(cur.t)}</b> after ${startName()}, ${POLSHORT[cur.pol]}` +
    (cur.zones && cur.zones.length ? ` (release zones ${cur.zones.map(([a, b]) => `${fmtS1(a)}–${fmtS1(b)}`).join(', ')})` : '') +
    ` → <b>${pct(cur.p)}</b>. The same plan if you are really another pace: ${others}.` + startTxt();
}
function paceCard(r, selected, label, band, star) {             // one preset card: label, band, best odds, cast time, policy
  const el = document.createElement('div');
  el.className = 'lkcard' + (selected ? ' sel' : '');
  el.innerHTML = `<div class="small"><b>${label}</b>${star ? ' ★' : ''}</div><div class="band">${band}</div><div class="share">${pct(r.p)}</div>` +
    `<div class="small mono">${r.t > 0 ? fmtS(r.t) : '—'}</div><div class="band">${POLSHORT[r.pol]}</div>`;
  return el;
}
function renderAxes(rows) {                                    // two cuts: pick the 1st, then the 2nd (odds for that 1st cut only)
  const R = routeDef(), [A1, A2] = R.axes, own = axSel(), gx = guessAx(), box = $('lkPace');
  const ax = gx ? Object.assign({}, gx.ax, !gx.ax[A2.id] && own[A2.id] && axGroup(R, { [A1.id]: gx.ax[A1.id], [A2.id]: own[A2.id] }) ? { [A2.id]: own[A2.id] } : {}) : own;
  const ownMark = (el, id, axId) => { if (gx && (own[axId] || null) === id && (ax[axId] || null) !== id) el.classList.add('own'); };
  if (gx) {
    const d = document.createElement('div'); d.className = 'small'; d.style.cssText = 'flex:1 1 100%;color:var(--ok);font-weight:600';
    d.textContent = `Your dock-end tap says: ${gx.l1} ${Math.round(100 * gx.p1)}% (green)` +
      (gx.sure2 ? ` · 2nd cut ${gx.l2.toLowerCase()} ${Math.round(100 * gx.p2)}%` : gx.l2 ? ` · 2nd cut: the tap can't tell (best guess ${gx.l2.toLowerCase()} ${Math.round(100 * gx.p2)}%)` : '') +
      '. Dashed = your own pick, back after this attempt. The cast already uses every timing weighted by the tap.';
    box.appendChild(d);
  }
  const rowOf = g => rows.find(r => r.g === g), tip = (g, d) => `${d}: ${Math.round(100 * g.share)}% of the simulated routes` +
    (g.cover < 0.999 ? ` (casts cover ${Math.round(100 * g.cover)}%)` : '');
  const label = t => { const d = document.createElement('div'); d.className = 'small mut'; d.style.cssText = 'flex:1 1 100%;margin-top:2px'; d.textContent = t; box.appendChild(d); };
  const pick = a => { const g = axGroup(R, a); if (g) setSelection(g.id, null); };
  label(A1.label);
  const c1 = [{ o: { id: null, label: 'Any', band: 'not sure' }, g: axGroup(R, {}) }].concat(A1.opts.map(o => ({ o, g: axGroup(R, { [A1.id]: o.id }) })));
  for (const { o, g } of c1) {
    const r = g && rowOf(g); if (!r) continue;
    const el = paceCard(r, (ax[A1.id] || null) === o.id, o.label, o.band);
    ownMark(el, o.id, A1.id);
    el.title = o.id ? tip(g, (A1.short || A1.id) + ' ' + o.label.toLowerCase() + ' (' + o.desc + '), any ' + (A2.short || A2.id)) : tip(g, 'All simulated routes');
    el.onclick = () => pick(o.id ? (ax[A2.id] && axGroup(R, { [A1.id]: o.id, [A2.id]: ax[A2.id] }) ? { [A1.id]: o.id, [A2.id]: ax[A2.id] } : { [A1.id]: o.id }) : {});
    box.appendChild(el);
  }
  label(A2.label);
  let best = null, flat2 = false, c2best = [];
  if (!ax[A1.id]) {
    for (const o of A2.opts) {
      const el = document.createElement('div'); el.className = 'lkcard dim';
      el.innerHTML = `<div class="small"><b>${o.label}</b></div><div class="band">${o.band}</div><div class="share">—</div><div class="band">pick a ${A1.short || A1.id}</div>`;
      el.title = o.desc; box.appendChild(el);
    }
  } else {
    const o1 = A1.opts.find(o => o.id === ax[A1.id]);
    const c2 = A2.opts.map(o => ({ o, g: axGroup(R, { [A1.id]: ax[A1.id], [A2.id]: o.id }) })).filter(x => x.g && rowOf(x.g));
    best = c2.reduce((a, x) => (!a || rowOf(x.g).p > rowOf(a.g).p ? x : a), null);
    const any = { o: { id: null, label: 'Any', band: 'not sure' }, g: axGroup(R, { [A1.id]: ax[A1.id] }) };
    flat2 = c2.length > 0 && c2.every(x => pct(rowOf(x.g).p) === pct(rowOf(any.g).p));   // 2nd cut changes nothing on this start
    const stars = flat2 || !best ? [] : c2.filter(x => pct(rowOf(x.g).p) === pct(rowOf(best.g).p)).map(x => x.o.id);
    c2best = c2.filter(x => stars.includes(x.o.id)).map(x => x.o.label.toLowerCase());
    for (const { o, g } of [any].concat(c2)) {
      const r = rowOf(g), el = paceCard(r, (ax[A2.id] || null) === o.id, o.label, o.band, o.id && stars.includes(o.id));
      ownMark(el, o.id, A2.id);
      el.title = o.id ? tip(g, `${A1.short || A1.id} ${o1.label.toLowerCase()} + ${A2.short || A2.id} ${o.label.toLowerCase()} (${o.desc})`) : tip(g, `${A1.short || A1.id} ${o1.label.toLowerCase()}, any ${A2.short || A2.id}`);
      el.onclick = () => pick(o.id ? { [A1.id]: ax[A1.id], [A2.id]: o.id } : { [A1.id]: ax[A1.id] });
      box.appendChild(el);
    }
  }
  const cur = rows.find(r => r.g.id === LuckyCore.selection.pace) || rows[0];
  const sibs = ax[A2.id] ? A2.opts.filter(o => o.id !== ax[A2.id]).map(o => [o, axGroup(R, { [A1.id]: ax[A1.id], [A2.id]: o.id })])
    : ax[A1.id] ? A1.opts.filter(o => o.id !== ax[A1.id]).map(o => [o, axGroup(R, { [A1.id]: o.id })]) : [];
  const others = sibs.filter(([, g]) => g && rowOf(g)).map(([o, g]) => `${o.label.toLowerCase()} ${pct(crossOf(cur, rowOf(g)))}`).join(' · ');
  $('lkPaceTxt').innerHTML = `<b>${cur.g.id === 'all' ? 'Any cuts' : cur.g.label}</b>: cast <b>${fmtS(cur.t)}</b> after ${startName()}, ${POLSHORT[cur.pol]}` +
    (cur.zones && cur.zones.length ? ` (release zones ${cur.zones.map(([a, b]) => `${fmtS1(a)}–${fmtS1(b)}`).join(', ')})` : '') +
    ` → <b>${pct(cur.p)}</b>.` +
    (others && !(flat2 && ax[A2.id]) ? ` The same cast if your ${ax[A2.id] ? (A2.short || A2.id) : (A1.short || A1.id)} was really ${others}.` : '') +
    (!ax[A1.id] ? ` Pick your ${A1.short || A1.id} to see the ${A2.short || A2.id} odds for it.`
      : flat2 ? ` With this start the ${A2.short || A2.id} changes nothing: the dog's line is set before it (~3 s into the beach) and the stopwatch does not run from the dock end.`
      : !ax[A2.id] && best ? ` Best ${A2.short || A2.id} after ${A1.short || A1.id} ${A1.opts.find(o => o.id === ax[A1.id]).label.toLowerCase()}: <b>${c2best.join(' or ')}</b> (${pct(rowOf(best.g).p)}).` : '') +
    startTxt();
}
const fmtS1 = vi => ((vi - 1) * viMs() / 1000).toFixed(1);
const spansTxt = sp => sp.map(([a, b]) => (b - a > 12 ? `${fmtS1(a)}–${fmtS1(b)} s` : `~${fmtS1(a)} s`)).join(' or ');
function refresh() {
  syncGoal();
  const plan = planObj(), pol = polOf(plan), T = castT(plan, pol);
  run.plan = plan; run.pol = pol; run.T = T;
  run.zone = LuckyCore.zoneAt(P(plan), T, sigVI(), sigVI(), true);
  const p = pol === 'zone' && run.zone ? run.zone.value : valueAt(plan, pol, T);
  $('lkT').textContent = fmtS(T);
  $('lkP').textContent = pct(p);
  $('lkTAfter').textContent = `after ${startName()} →`;
  const pg = (route() !== 'carry' || D.pace) && LuckyCore.selection.pace !== 'all' ? LuckyCore.groups().find(g => g.id === LuckyCore.selection.pace) : null;
  $('lkPlanTxt').textContent = `${route() !== 'carry' ? routeDef().label + ' · ' : ''}${pg ? pg.label + (route() === 'carry' ? ' pace' : '') + ' · ' : ''}${plan.label} · ${POLNAME[pol]}${P(plan) !== plan ? ' · fitted to your taps' : ''}`;
  $('lkHow').innerHTML = howTo(plan, pol, T);
  renderBiteSplit(); renderRate(plan, T, valueAt(plan, pol === 'tap' ? 'hold' : pol, T));
  if ($('lkPersonalCast')) { $('lkPersonalCast').checked = !!L.personalCast; $('lkPersonalTxt').hidden = !L.personalCast; $('lkPersonalTxt').innerHTML = personalTxt(); }
  renderPace(); labelStarts(); renderPlans(); renderTally(); renderProfile(); renderPractice(); renderBite(); renderOff(); renderHabit(); renderTrust(); renderGuard(); renderData(); renderFade2(); renderTimingSum(); drawOverview();
  syncTimingInputs();
}
/* v30.6 (UI lab on the Mac, 2026-11-17): minutes per Nut and the choice of what the cast is picked for.
   L.goal 'odds' (default) = best odds per attempt; 'time' = best odds per minute, p / (over + t) with over = what an
   attempt costs besides the stopwatch time to the cast (L.goalOverS, default 55 s: about 40 s from the reset to the
   beach fade-in + about 15 s of bites after the cast). */
const goalOverS = () => Math.max(10, Math.min(300, +L.goalOverS || 55));
/* With dog-watch on the cast stays on best odds: watching longer is worth far more than casting sooner (UI lab: 28.5%
   with a cast at ~34 s = about 5 min per Nut; an early cast would throw the dog's information away). */
const goalTime = () => L.goal === 'time' && !(L.dwOn && routeDef().dw);
function syncGoal() {                                          // at every refresh: the core's goal follows the settings
  const want = goalTime() ? goalOverS() * 1000 / viMs() : 0, cur = LuckyCore.goal ? LuckyCore.goal.over : 0;
  if (Math.abs(want - cur) < 1e-6) return;
  LuckyCore.setGoal(want ? { over: want } : null);
  bestCache = null; ccache.clear(); paceCache.clear(); startCache.clear(); rateCache = null;
}
function applyGoal() { L.castT = null; save(); refresh(); }
let rateCache = null;
function otherGoal(plan) {                                      // what the other goal would pick (same plan, same spread)
  const key = [selKey(), plan.k, sigTag(), profVer, goalTime(), goalOverS(), L.policy].join(':');
  if (rateCache && rateCache.key === key) return rateCache.v;
  const cur = LuckyCore.goal;
  LuckyCore.setGoal(cur ? null : { over: goalOverS() * 1000 / viMs() });
  let v = null;
  try { const b = LuckyCore.best(P(plan), sigVI(), 30 + R0()), pol = L.policy !== 'auto' ? (L.policy === 'tap' ? 'hold' : L.policy) : ['zone', 'bite1', 'hold'].reduce((a, q) => (LuckyCore.score(b[q].t, b[q].p) > LuckyCore.score(b[a].t, b[a].p) ? q : a), 'zone');
    v = b[pol] && b[pol].t > 0 ? b[pol] : null; } finally { LuckyCore.setGoal(cur); }
  rateCache = { key, v };
  return v;
}
function renderRate(plan, T, p) {
  const el = $('lkRate'); if (!el) return;
  if ($('lkGoal')) { $('lkGoal').value = L.goal === 'time' ? 'time' : 'odds'; if (document.activeElement !== $('lkGoalOver')) $('lkGoalOver').value = goalOverS(); }
  if (!(p > 0)) { el.innerHTML = ''; return; }
  const mins = (t, q) => (goalOverS() + (t - 1) * viMs() / 1000) / q / 60;
  let h = `≈ <b>${mins(T, p).toFixed(1)} min per Nut</b> at this cast (an attempt ≈ ${Math.round(goalOverS() + (T - 1) * viMs() / 1000)} s, ${pct(p)})`;
  if (L.castT === null) { const o = otherGoal(plan);
    if (o && Math.abs(o.t - T) > 12) h += ` · ${goalTime() ? 'best odds' : 'fastest Nut'} would cast at ${fmtS(o.t)}: ${pct(o.p)}, ${mins(o.t, o.p).toFixed(1)} min per Nut`; }
  if (L.goal === 'time' && !goalTime()) h += '<br><span class="mut">Dog-watch is on: the cast is picked for best odds (watching the dog longer is worth more than casting sooner).</span>';
  if (routeDef().dw && !L.dwOn) h += `<br><span style="color:#ffd28a">Dog-watch is off.</span> <span class="mut">In the UI lab (Mac, 2026-11-17, 500 attempts each) it took beach-lineup2 from 12.0% to 28.5% per attempt: Settings → Lucky Timer → "Watch the dog at the dock end".</span>`;
  el.innerHTML = h;
}
function renderBiteSplit() {
  const el = $('lkBiteSplit'), bs = biteSplit();
  if (!el) return;
  if (!bs || !bs.ks.length) { el.innerHTML = ''; return; }
  const part = m => `<span style="color:${BITECOL[Math.min(3, m)]}">${m === bs.top ? '<b>' : ''}■ ${ORD(m)} bite ${pct(bs.by[m])}${m === bs.top ? '</b>' : ''}${m >= 3 ? '*' : ''}</span>`;
  el.innerHTML = `This cast aims at a <b style="color:${BITECOL[Math.min(3, bs.top)]}">${ORD(bs.top)}-bite Nut</b> — Nut by bite: ${bs.ks.map(part).join(' · ')}` +
    (bs.extra ? ' <span class="mut" title="A 3rd or later bite: only when the lamp says KEEP HOLDING at the bite before; not in the odds">(* extra)</span>' : '');
}
function howTo(plan, pol, T) {
  const k = keyName(), steps = [];
  const RH = routeDef().howto;
  if (RH) steps.push(`<li>${RH}</li>`);
  if (anchor() === 'fadein' && doubleOn()) {
    const HOW = { exit: 'when Jack <b>stops at the ranch exit</b> (he stops dead under your stick, the screen starts to dim)',
                  fade: 'when the black screen <b>starts to brighten</b> (the beach fading in)',
                  ctrl: 'when Jack <b>turns down-right and walks</b> on the beach (hold down-right through the fade; 1.09 s after the first light)',
                  dock: 'when Jack <b>stops at the dock end</b>' };
    steps.push(`<li>Tap <kbd>${k}</kbd> ${tapCues().map(c => HOW[c.id]).join(', ')} (miss any one). The clock comes from the transition taps ` +
      `(start-key delay ${startDelay()} ms, then auto-tuned from your bite taps); the dock-end tap tells it your beach timing and re-aims the cast. ` +
      'Then walk the beach as above (the dog wakes about 3 s after the fade-in starts, plus your wait, while Jack is still on the wall; the 2nd cut does not move this stopwatch).</li>');
  }
  else if (anchor() === 'fadein') steps.push(`<li>Press <kbd>${k}</kbd> the moment the black screen after the ranch <b>starts to brighten</b> (the beach fading in, about a second before Jack can move; start-key delay ${startDelay()} ms, the tool learns your offset from your bite taps). ` +
    'Then walk the beach as above (the dog wakes about 3 s after the fade-in starts, plus your wait, while Jack is still on the wall; the 2nd cut does not move this stopwatch).</li>');
  else if (anchor() === 'beach') steps.push(`<li>Press <kbd>${k}</kbd> the moment the <b>beach appears</b> after the black screen (start-key delay ${startDelay()} ms; the tool learns your offset from your bite taps). ` +
    (RH ? 'Then walk the beach as above without pausing (the dog wakes ~3 s in and its line is fixed by that moment).</li>'
        : 'Then walk the route exactly: no pause in the first ~3 s on the beach (the dog wakes then and its line is fixed by that moment), then DR held to the pier end.</li>'));
  else if (anchor() === 'pier') steps.push(`<li>Hold DR to the ${RH ? 'dock' : 'pier'} end and press <kbd>${k}</kbd> the moment Jack <b>stops at the water</b> (READY, start-key delay ${startDelay()} ms).</li>`);
  else if (anchor() === 'dog') steps.push(`<li>Press <kbd>${k}</kbd> <b>together with A</b> as you put the dog down (it lands ~0.13 s after the A press; start-key delay ${L.dogDelayMs} ms). ` +
    'If you would rather press when you <i>see</i> it land, set the delay to about +150 ms. Turn SE as usual: from here, how long you take on the beach changes nothing.</li>');
  else steps.push(`<li>Press <kbd>${k}</kbd> the moment you have control after putting the dog down (READY, facing SE).</li>`);
  if (plan.k) steps.push(`<li>Mash <b>C-right</b> right away; stop as soon as you hear whistle <b>#${plan.k}</b> start (about ${fmtS(plan.whistleEnd)}).</li>`);
  if ((T - R0()) * viMs() > 34000) steps.push('<li>Push the stick <b>down-right (south-east)</b> when the red line passes (33 s after READY, then every 33 s) — Jack lies down after 40 s without input.</li>');
  steps.push(`<li>Press <b>B</b> on the green <b>CAST</b> flash (the lamp in L3 pulses 3-2-1 and a bar fills to the line): <b>${fmtS(T)}</b> after ${startName()} (the bobber plops 0.6 s later)` +
    (L.castTap ? `, and tap <kbd>${k}</kbd> together with it (the tool logs your real cast)` : '') + '. Face SE or E — the lab sees no difference.</li>');
  const tap = `tap <kbd>${k}</kbd> the moment the first bite shows`;
  if (pol === 'bite1') {
    const nb = nutBites().map(([a, b]) => b - a > 12 ? `${fmtS1(a)}–${fmtS1(b)} s` : `~${fmtS1(a)} s`).join(' or ');
    steps.push(`<li>Keep B held; <b>release at the first bite</b> (and ${tap} to log it). With this cast a Nut bite can only come at <b>${nb || '—'}</b>` +
      ' (the lamp turns amber and blinks twice just before each, green while it lasts): be ready then — B must be up within 0.33 s of the bite showing.</li>');
  }
  else if (pol === 'hold' || pol === 'tap') steps.push(`<li>Keep B held through the first bite and ${tap}. The tool tells you the Nut chance on bite 2: <b>DUD → reset now</b>, otherwise <b>release at the second bite</b>.</li>`);
  else {
    const zs = run.zone ? run.zone.zones.map(([a, b]) => `${fmtS1(a)}–${fmtS1(b)} s`).join(', ') : '';
    steps.push(`<li>Keep B held. If the first bite comes inside a <b style="color:var(--ok)">release window</b> (${zs || 'none'}; the lamp is amber just before, green while it is open), <b>release</b> and ${tap}. ` +
      `If it comes <b>before</b> a window, or a window passes with no bite, <b>hold through it</b> and ${tap}: the tool reads which frame and dog path (or line) you are on and forecasts bite 2 — ` +
      '<b>DUD → reset now</b> (red lamp), otherwise the Nut chance and the moment(s) bite 2 can be the Nut (amber just before, green then). Release bite 2 there and tap it too.</li>');
  }
  steps.push('<li>A bite = the rod-pull animation; you have its 0.33 s to let go of B. Power Nut (he eats it) → <kbd>H</kbd>; a fish → <kbd>M</kbd>; ' +
    'the line came back <b>empty</b> → <kbd>E</kbd> (that means B went up outside the bite window). Reset the console, go again. Logged taps fit the plan to you and tell you after each attempt whether the cast or the release missed (L4 · Attempts).</li>');
  return '<ol>' + steps.join('') + '</ol>';
}

/* ---------------------------------------------------------------- overview histogram (0-45 s, click = cast time) */
function drawOverview() {
  const cv = $('lkOverview'), dpr = devicePixelRatio, W = cv.width = cv.clientWidth * dpr, H = cv.height = 110 * dpr;
  const g = cv.getContext('2d'), plan = run.plan;
  g.clearRect(0, 0, W, H);
  const X = t => (t / LuckyCore.TMAX) * W;
  const curves = { bite1: curveC(plan, 'bite1'), hold: curveC(plan, 'hold'), zone: curveC(plan, 'zone') };
  const col = { bite1: '#5fd38d', hold: '#e7c14a', zone: '#ffffff' };
  let ymax = 0.05;
  for (const a of Object.values(curves)) for (let t = 30; t < a.length; t++) if (!isNaN(a[t])) ymax = Math.max(ymax, a[t]);
  ymax *= 1.1;
  const Y = p => H - 14 * dpr - (p / ymax) * (H - 24 * dpr);
  if (plan.k && plan.whistleEnd > 0) { g.fillStyle = '#b48cff33'; g.fillRect(0, 0, X(plan.whistleEnd), H); }
  const selPol = run.pol === 'tap' ? 'hold' : run.pol, sel = curves[selPol];
  g.fillStyle = col[selPol] + '66';
  for (let t = 1; t < sel.length; t += 2) if (!isNaN(sel[t])) g.fillRect(X(t), Y(sel[t]), Math.max(1, X(2) - X(0)), Y(0) - Y(sel[t]));
  for (const pol of ['bite1', 'hold', 'zone']) {
    if (pol === selPol) continue;
    const a = curves[pol];
    g.strokeStyle = col[pol] + '55'; g.lineWidth = 1 * dpr; g.beginPath();
    let on = false;
    for (let t = 1; t < a.length; t += 4) { if (isNaN(a[t])) { on = false; continue; } if (!on) g.moveTo(X(t), Y(a[t])); else g.lineTo(X(t), Y(a[t])); on = true; }
    g.stroke();
  }
  g.strokeStyle = '#ffffff44'; g.setLineDash([4 * dpr, 4 * dpr]); g.beginPath(); g.moveTo(0, Y(1 / 51)); g.lineTo(W, Y(1 / 51)); g.stroke(); g.setLineDash([]);
  g.fillStyle = '#8ea3b2'; g.font = `${10 * dpr}px ui-monospace,monospace`;
  for (let sec = 0; sec <= 45; sec += 5) g.fillText(sec + 's', X(sec * 1000 / viMs() + 1) + 2, H - 2 * dpr);
  g.fillText(`max ${(100 * ymax / 1.1).toFixed(0)}% · stopwatch from ${startName()}`, 2, 10 * dpr);
  if (run.T) { g.strokeStyle = '#6fb7ff'; g.lineWidth = 2 * dpr; g.beginPath(); g.moveTo(X(run.T), 0); g.lineTo(X(run.T), H); g.stroke(); }
}
function overviewClick(e) {
  const r = e.target.getBoundingClientRect(), t = Math.round(((e.clientX - r.left) / r.width) * LuckyCore.TMAX);
  const plan = run.plan;
  if (t < plan.firstT) return;
  L.castT = t - (t % 2); save(); refresh();
}

/* ---------------------------------------------------------------- attempt data (v30.8) */
/* Thomas (2026-11-17): a bad attempt must never be stuck in the data. An attempt can leave records in five stores:
   the L4 log (tally: result, cast tap error), the bite taps (personal profile, clock shift, bite-tap lag), the tap set
   of its start strategy (clock-tap offsets and spread), the dock-end reflex log and the dog-watch arrow calibration.
   The tap data is kept even when the attempt is never logged (Esc, or the stopwatch running out), so the L4 log alone
   does not show everything. From v30.8 every record carries the attempt's id (`aid`); older records are grouped by
   their time stamps (records written within 3 s belong together). attemptList() = one row per attempt, newest first;
   removeAttempt(id) takes its records out of every store and re-fits everything learned; restoreAttempt() undoes the
   last removal. All three are exported for the UI lab. */
let lastAid = 0;
const newAid = () => (lastAid = Math.max(Date.now(), lastAid + 1));
let lastRemoved = null;
function attemptStores() {                                      // [name, records, write-back]
  const out = [['tally', tally, a => { tally = a; store.set('hm64v29_lucky_tally', tally); }],
               ['taps', taps, a => { taps = a; store.set('hm64v29_lucky_taps', taps); }],
               ['dock', dock, a => { dock = a; store.set('hm64v29_lucky_dock', dock); }],
               ['dwcal', dwcal, a => { dwcal = a; store.set('hm64v30_dwcal', dwcal); }],
               ['doglines', dogLines, a => { dogLines = a; store.set('hm64v30_doglines', dogLines); }]];
  for (const k of tsKeys()) out.push(['set:' + k, tsGet(k), a => tsPut(k, a)]);
  return out;
}
function attemptGroups() {                                      // {stores, groups: [{id, legacy, parts: [[store name, record]]}]}
  const stores = attemptStores(), by = new Map(), legacy = [];
  for (const [name, recs] of stores) for (const r of recs) {
    if (!r || typeof r !== 'object') continue;
    if (r.aid != null) { if (!by.has(r.aid)) by.set(r.aid, { id: r.aid, parts: [] }); by.get(r.aid).parts.push([name, r]); }
    else if (Number.isFinite(r.at)) legacy.push([name, r]);
  }
  legacy.sort((a, b) => a[1].at - b[1].at);
  let cur = null;
  for (const [name, r] of legacy) {                               // records from before v30.8: together when written within 3 s
    if (!cur || r.at - cur.last > 3000 || cur.parts.some(q => q[0] === name)) { cur = { id: 't' + r.at, parts: [], last: r.at, legacy: true }; by.set(cur.id, cur); }
    cur.parts.push([name, r]); cur.last = r.at;
  }
  return { stores, groups: [...by.values()] };
}
function attemptRow(a) {
  const get = n => a.parts.filter(q => q[0] === n).map(q => q[1]), tl = get('tally')[0], tp = get('taps')[0], set = a.parts.find(q => q[0].startsWith('set:'));
  return { id: a.id, at: Math.max(...a.parts.map(q => q[1].at || 0)), legacy: !!a.legacy, logged: !!tl,
           result: tl ? (tl.hit ? 'nut' : tl.outcome === 'empty' ? 'empty' : 'miss') : null, route: (tl || tp || {}).route || null, T: tl ? tl.T : null,
           has: { tally: !!tl, castTap: !!(tl && Number.isFinite(tl.castErrMs)), bite: get('taps').filter(t => t.tau != null || t.hit != null).length,
                  clock: set ? Object.keys(set[1].y || {}).length : 0, dock: get('dock').length, dog: get('dwcal').length + get('doglines').length },
           land: landOf((tl && tl.land) || (tp && tp.land) || null), nofit: (tl && tl.nofit) || (tp && tp.nofit) || null, n: a.parts.length,
           q: (tl && tl.q) || get('taps').map(t => t.q).find(Boolean) || null };
}
/* v30.11: the stored call {e, l, ms} -> {side: 'early' | 'late' | 'on' | null (not clear), early, late, on, ms} */
function landOf(x) {
  if (!x || !Number.isFinite(x.e) || !Number.isFinite(x.l)) return null;
  const on = Math.max(0, 1 - x.e - x.l);
  return { early: x.e, late: x.l, on, ms: x.ms, side: x.e >= LAND_CALL ? 'early' : x.l >= LAND_CALL ? 'late' : on >= LAND_CALL ? 'on' : null };
}
/* the run of equal calls at the top of the list (attempts without a clear call are skipped, not counted) + the last 20 */
function landStreak(rows) {
  const calls = rows.filter(a => a.land && a.land.side).slice(0, 20);
  if (!calls.length) return null;
  let n = 0; while (n < calls.length && calls[n].land.side === calls[0].land.side) n++;
  const cnt = { early: 0, late: 0, on: 0 }; for (const a of calls) cnt[a.land.side]++;
  const run_ = calls.slice(0, n), ms = Math.round(run_.reduce((q, a) => q + a.land.ms, 0) / n);
  return { side: calls[0].land.side, n, ms, cnt, total: calls.length };
}
const attemptList = () => attemptGroups().groups.map(attemptRow).sort((a, b) => b.at - a.at);   // newest first
function relearn() {                                            // after the stored attempt data changed
  bestCache = null; ccache.clear(); paceCache.clear(); startCache.clear();
  updateProfile();
  if (run.wall0 === null) refresh(); else renderTally();
  renderAttempts();
}
function removeAttempt(id) {                                    // -> the number of records removed (0 = nothing done)
  if (run.wall0 !== null && String(id) === String(run.aid)) return 0;   // the attempt being played: stop it first
  const { stores, groups } = attemptGroups(), g = groups.find(a => String(a.id) === String(id));
  if (!g) return 0;
  const mine = new Set(g.parts.map(q => q[1])), gone = [];
  for (const [name, recs, put] of stores) {
    const out = recs.filter(r => mine.has(r));
    if (out.length) { put(recs.filter(r => !mine.has(r))); gone.push([name, out]); }
  }
  const n = gone.reduce((a, x) => a + x[1].length, 0);
  if (n) { lastRemoved = { row: attemptRow(g), gone, at: Date.now() }; relearn(); }
  return n;
}
function restoreAttempt() {                                     // undo the last removal
  if (!lastRemoved) return 0;
  let n = 0;
  for (const [name, out] of lastRemoved.gone) {
    const st = attemptStores().find(x => x[0] === name);
    if (name.startsWith('set:') && !st) { const k = name.slice(4); tsPut(k, out.slice()); n += out.length; continue; }
    if (!st) continue;
    st[2](st[1].concat(out).sort((a, b) => (a.at || 0) - (b.at || 0))); n += out.length;
  }
  lastRemoved = null; relearn();
  return n;
}

/* ---------------------------------------------------------------- v31.13 cast quality report ("stats for nerds")
   Thomas 2026-11-21 10:34: analyse each attempt's cast and keep the analysis with the attempt, so the player can see
   where the app wanted the cast, where it drew the line, where he pressed and where the bites say it landed.
   Two halves:
     castRepBuild()   at the end of an attempt, from the live state -> a small plain object `q` stored in the attempt's
                      record (L4 log; the bite-tap record when the attempt was never logged);
     castRepRead(q)   OFFLINE interpreter: from `q` alone -> the numbers and sentences of the report (no live state, no
                      tables), and drawCastRep(canvas, q) the close-up. Both work on any stored attempt, any time.
   q: v, vi (ms per VI), T (aim, stopwatch VI), corr (ms the CAST line is moved for the B-press habit), sig (± ms the
      cast was planned for), pol, odds, cv (P(Nut) for a cast every 2 VIs from T - 60 to T + 60), want [[line, share]]
      (the lines the plan stood on at the cast), press [VI, 'hold' | 'tap'] (Space pressed with B), taps [VI],
      land {e, on, l, ms, n} + lh [[offset VI from the aim, share]] + hit [[line, share]] (from the bite taps), nofit,
      dog {top, pick, adjMs, cadj, exact {line, nut, bites [[n, s, outcome]]}}, hold {kind}. */
function castRepBuild() {
  try {
    if (!run.plan || run.preview || run.practice) return undefined;
    const vi = viMs(), T = run.T, ti = run.tapInfo, w = run.dw, R = routeDef();
    const nameOf = sx => { const i = R.sidxs ? R.sidxs.indexOf(sx) : -1; return i >= 0 ? 'L' + (i + 1) : 'path ' + (sx + 1); };
    const top = (m, n) => { const Z = [...m.values()].reduce((a, b) => a + b, 0) || 1; return [...m.entries()].sort((a, b) => b[1] - a[1]).slice(0, n).map(([sx, x]) => [nameOf(sx), +(x / Z).toFixed(3)]); };
    const wm = new Map(); for (const x of P(run.plan).variants) wm.set(x.s, (wm.get(x.s) || 0) + x.w);
    const fsq = fsOn() ? Object.assign({ cast: run.fs.cast != null ? +run.fs.cast.toFixed(2) : null }, fsRepBuild()) : null;
    const q = { v: 1, ...(fsq ? { fs: fsq } : {}), vi: +vi.toFixed(4), T: +T.toFixed(2), corr: Math.round(cueCorr()), sig: Math.round(sigmaMs()), pol: run.pol, want: top(wm, 4) };
    const od = parseFloat($('lkP').textContent) / 100; if (isFinite(od)) q.odds = +od.toFixed(4);
    const Pc = curveC(run.plan, run.pol), c0 = Math.round(T) - 60; q.cv = [];
    for (let v = c0; v <= c0 + 120; v += 2) q.cv.push(v >= 1 && v < Pc.length && !isNaN(Pc[v]) ? +Pc[v].toFixed(3) : 0);
    if (run.hold) q.press = [+run.hold.down.toFixed(1), 'hold']; else if (run.castTap !== null && run.castTap !== undefined) q.press = [+run.castTap.toFixed(1), 'tap'];
    if (run.hold) q.hold = { kind: run.hold.kind || null };
    q.taps = ti && ti.taus ? ti.taus.map(x => +x.toFixed(1)) : [];
    if (ti && ti.fit && ti.sc && ti.sc.length) {
      const shift = Math.round(ti.Teff) - T, by = new Map(), hm = new Map(); let Z = 0;
      for (const e of ti.sc) { const o = Math.round(e.d + shift); Z += e.w; by.set(o, (by.get(o) || 0) + e.w); hm.set(e.path, (hm.get(e.path) || 0) + e.w); }
      const ld = landing(ti);
      if (ld) q.land = { e: +ld.early.toFixed(3), on: +ld.on.toFixed(3), l: +ld.late.toFixed(3), ms: ld.ms, n: ld.bites };
      q.lh = [...by.entries()].map(([o, x]) => [o, +(x / Z).toFixed(3)]).filter(x => x[1] >= 0.004).sort((a, b) => a[0] - b[0]).slice(0, 60);
      q.hit = top(hm, 4);
    } else if (ti && !ti.fit) q.nofit = nofitRec(ti.nofit) || { k: 'maybe' };
    const DR = dwRoute();
    if (w && DR) {
      const nm = dwi => (DR.dw.lines[dwi].li >= 0 ? 'L' + (DR.dw.lines[dwi].li + 1) : 'a line without a cast table');
      const d = {}; if (w.sum && w.sum.top) d.top = [nm(w.sum.top.dwi), +w.sum.top.p.toFixed(3)];
      if (w.pick) { d.pick = nm(w.pick.dwi); d.adjMs = Math.round(w.adj * vi); }
      if (w.cadj) d.cadj = w.cadj;
      if (w.exact != null) { const a = dcCardA(w.exact), B = a === null ? null : dcBites(DR, w.exact, a); d.exact = { line: nm(w.exact), frame: dcFrame(DR, w.exact).c, src: dcFrame(DR, w.exact).src, nut: B && B.nut ? B.nut.n : 0, bites: B ? B.bites.slice(0, 6).map(b => [b.n, +((b.t - 1) * vi / 1000).toFixed(2), b.o]) : null }; }
      if (w.logs && w.logs.length) d.logs = w.logs.length;
      if (Object.keys(d).length) q.dog = d;
    }
    return q;
  } catch (e) { return undefined; }
}
/* the offline interpreter: stored q -> { lines: [html], call, callP, tags } */
function castRepRead(q, res) {
  if (!q || !q.v) return null;
  const vi = q.vi || viMs(), S = v => ((v - 1) * vi / 1000).toFixed(2) + ' s', ms = x => `${x >= 0 ? '+' : '−'}${Math.abs(Math.round(x))} ms`, fr = x => `${x >= 0 ? '+' : '−'}${(Math.abs(x) / 2).toFixed(1)} frames`;
  const LN = a => (a && a.length ? a.map(x => `${x[0]} ${Math.round(100 * x[1])}%`).join(' · ') : '—');
  const out = { lines: [], call: 'none', callP: 0 };
  if (q.fs) {                                                     // v31.22: freestyle - graded against the target the player declared
    const f = q.fs, T = f.T, TG = { N: 'Power Nut', l: 'large fish', m: 'medium fish', s: 'small fish' }[f.tg] || 'Power Nut', COL = ['', 'green', 'gold', 'purple'];
    const grade = v => (v < T.f0 ? { k: 'early', ms: (T.f0 - v) * vi } : v >= T.f1 + 2 ? { k: 'late', ms: (v - T.f1 - 2) * vi } : { k: 'on', i: Math.floor((v - T.f0) / 2) + 1 });
    const gtx = (g, what) => (g.k === 'on' ? `<b style="color:#8ff0a4">INSIDE</b> the target (${what} on bar ${Math.min(T.n, g.i)} of ${T.n})` : `<b style="color:${g.k === 'early' ? '#6fb7ff' : '#ff9d7a'}">OUTSIDE — ${Math.round(g.ms)} ms ${g.k === 'early' ? 'EARLY' : 'LATE'}</b> (${(g.ms / (2 * vi)).toFixed(1)} frames ${g.k === 'early' ? 'before its first' : 'after its last'} bar)`);
    out.fs = true;
    out.lines.push(`<b>Freestyle</b> — you chose the cast${f.line ? ` on ${f.line}` : ''}; going for the <b>${TG}</b>. The app's own target and CAST line were not in play, and this attempt teaches the app nothing about your timing.`);
    if (!T) { out.lines.push(f.tap != null ? `<b>Target</b> — none: no bars within 0.5 s of your ${keyName()} tap at <b>${S(f.tap)}</b>. Nothing to grade.` : `<b>Target</b> — not declared: tap ${keyName()} as you cast (or lock your dog after the cast) and the report grades the cast against the bars you went for.`); return out; }
    out.lines.push(`<b>Target</b> ${f.by === 'lock' ? '(the bars nearest the frame you locked — no tap at the cast)' : `(the bars nearest your ${keyName()} tap)`}: a <b>${T.kind === 'single' ? 'single bar' : T.kind === 'group' ? `group of ${T.n} bars` : `${T.kind.toUpperCase()} — ${T.n} frames side by side`}</b>, ${T.bites.map(b => COL[Math.min(3, b)]).join(' / ')} (${TG} on bite ${T.bites.join(' or ')}), cast frames <b>${S(T.f0)} – ${S(T.f1 + 2)}</b>${T.kind === 'group' ? '' : ` = a window of ${Math.round((T.f1 + 2 - T.f0) * vi)} ms`}; let go ${S(T.rel)} – ${S(T.relEnd)}.`);
    let call = null;
    if (f.tap != null) { const g = grade(f.tap); out.lines.push(`<b>Your tap</b> at <b>${S(f.tap)}</b>: ${gtx(g, 'the tap fell')}. The tap is your other hand, not B itself.`); call = g.k; }
    if (f.lock != null) { const g = grade(f.lock), tuned = f.by === 'lock' || !!f.cadj;
      out.lines.push(tuned ? `<b>The dog</b> — the frame you locked after the cast${f.cadj ? ` (moved ${Math.abs(f.cadj)} frame${Math.abs(f.cadj) > 1 ? 's' : ''} ${f.cadj < 0 ? 'earlier' : 'later'} with the frame keys)` : ''}, <b>${S(f.lock)}</b>: ${gtx(g, 'the cast landed')}. This is the stronger reading: the dog shows the frame the game cast on.`
        : `<b>The dog</b> — locked at <b>${S(f.lock)}</b> without moving it: that is the frame the app assumed from your tap, not a second reading.`);
      if (tuned) call = g.k; }
    if (q.taps && q.taps.length) { const b = q.taps[0] - (f.lag || 0), d = (b - T.rel) * vi; out.lines.push(`<b>Bite marked</b> at ${S(q.taps[0])} (the bite about ${S(b)}): the target's bite was due at ${S(T.rel)} → ${ms(d)}: ${Math.abs(d) <= 260 ? 'that fits a cast on the target' : 'that does not fit the target — the cast landed on another frame'}.`); if (Math.abs(d) > 260 && call === 'on' && f.lock == null) call = null; }
    const oc = typeof res === 'string' ? (/not logged/i.test(res) ? null : /nut/i.test(res) ? 'nut' : /empty/i.test(res) ? 'empty' : 'fish') : res && res.outcome ? res.outcome : null;
    if (oc) out.lines.push(`<b>Result</b>: ${oc === 'nut' ? `<b style="color:#8ff0a4">${TG === 'Power Nut' ? 'Power Nut' : 'caught'}</b> — the target was hit.` : oc === 'empty' ? 'empty line — B came up outside a bite.' : f.tg && f.tg !== 'N' ? 'a fish — check its size against the target.' : `a fish, no Nut — ${call === 'on' ? 'the reading says inside, so either the dog was a frame off in its timing or B came up outside the green band' : call ? `the cast was ${call}` : 'the cast was off the target'}.`}`);
    out.call = call || 'unclear'; out.callP = call ? 1 : 0; out.fs = true;
    return out;
  }
  const cue = q.T + q.corr / vi, POL = { zone: 'smart zones', bite1: 'let go at the 1st bite', hold: 'hold the 1st, let go at the 2nd', tap: 'hold and tap' };
  out.lines.push(`<b>Target</b> — where the cast should land: <b>${S(q.T)}</b>${Number.isFinite(q.odds) ? `, worth ${pct(q.odds)}` : ''} (${POL[q.pol] || q.pol}; planned for a press within ±${q.sig} ms). The plan stood on: ${LN(q.want)}.`);
  out.lines.push(q.corr ? `<b>CAST line</b> — where it was drawn: <b>${S(cue)}</b>, ${Math.abs(q.corr)} ms ${q.corr < 0 ? 'before' : 'after'} the target, because your B press usually comes ${Math.abs(q.corr)} ms ${q.corr < 0 ? 'after' : 'before'} a line you watch.`
    : `<b>CAST line</b> — drawn on the target (no B-press habit on record: 5 cast-practice presses give one).`);
  if (q.press) { const dl = (q.press[0] - cue) * vi, dt = (q.press[0] - q.T) * vi;
    out.lines.push(`<b>Your press</b> (${q.press[1] === 'hold' ? 'Space held with B' : 'cast tap'}): <b>${S(q.press[0])}</b> = ${ms(dl)} from the line, <b>${ms(dt)} from the target</b>` +
      (q.corr ? ` — without the line being moved it would have been about ${ms(dt - q.corr)}` : '') + '.'); }
  else out.lines.push(`<b>Your press</b>: not measured (the app never sees B; hold Space together with B and it is).`);
  if (q.land) {
    const L_ = q.land, side = L_.e >= LAND_CALL ? 'early' : L_.l >= LAND_CALL ? 'late' : L_.on >= LAND_CALL ? 'on' : 'unclear';
    out.call = side; out.callP = side === 'early' ? L_.e : side === 'late' ? L_.l : side === 'on' ? L_.on : Math.max(L_.e, L_.l, L_.on);
    out.lines.push(`<b>Where it landed</b> (from ${L_.n > 1 ? L_.n + ' bite marks' : 'the bite mark'}): too early <b>${pct(L_.e)}</b> · on the frame <b>${pct(L_.on)}</b> · too late <b>${pct(L_.l)}</b> → ` +
      (side === 'unclear' ? '<b>inconclusive</b> (no side reaches 60%)' : side === 'on' ? '<b style="color:#8ff0a4">on the frame</b>' : `<b style="color:${side === 'early' ? '#6fb7ff' : '#ff9d7a'}">too ${side}</b>, most likely ${ms(L_.ms)} (${fr(L_.ms / vi)}) from the target`) + '.' +
      (q.press ? ` Press and bite marks ${Math.abs((q.press[0] - q.T) * vi - L_.ms) <= 50 ? 'agree' : 'differ by ' + Math.round(Math.abs((q.press[0] - q.T) * vi - L_.ms)) + ' ms (two hands, or the stopwatch against the console)'}.` : ''));
    out.lines.push(`<b>Dog line</b> — the bites point to: ${LN(q.hit)}` + (q.want && q.hit && q.hit.length ? (q.want.some(x => x[0] === q.hit[0][0]) ? ` (${q.hit[0][0]} was one of the lines the plan stood on).` : ` — <b style="color:#ffd28a">${q.hit[0][0]} was not among the plan's main lines</b>.`) : '.'));
  } else if (q.nofit) { out.call = 'nofit'; out.lines.push(`<b>Where it landed</b>: the bite mark fits <b style="color:#ef6f6f">no dog line</b> at this cast` + (q.nofit.k === 'none' ? ' and no cast within ±0.75 s explains it: the run was off the tables (menus, route or start tap), not a timing miss.' : ' — most often a run off the tables; a far cast is the rarer cause.')); }
  else out.lines.push(`<b>Where it landed</b>: no bite was marked, so nothing can be said (Space at the bite, or let go of Space at it in hold mode).`);
  if (q.dog) { const d = q.dog, bits = [];
    if (d.top) bits.push(`dog-watch's top line at the cast: ${d.top[0]} ${Math.round(100 * d.top[1])}%`);
    if (d.pick) bits.push(`you picked ${d.pick}${d.adjMs ? ` (timing ${ms(d.adjMs)})` : ''}`);
    if (d.exact) bits.push(`locked after the cast: ${d.exact.line}, ${d.cadj ? fr(2 * d.cadj) + ' from the assumed press' : 'at the assumed press'} → ${d.exact.nut ? 'Nut on bite ' + d.exact.nut : 'no Nut on that cast'}` + (d.exact.bites ? ` (bites ${d.exact.bites.map(b => `${b[0]}: ${b[1]} s ${b[2] === 'N' ? 'NUT' : 'fish'}`).join(', ')})` : ''));
    else if (d.cadj) bits.push(`cards scrolled ${fr(2 * d.cadj)} after the cast`);
    if (bits.length) out.lines.push(`<b>Dog</b> — ${bits.join('; ')}.`);
    if (d.exact && d.exact.bites && q.taps && q.taps.length) { const cmp = q.taps.map((tv, i) => { const b = d.exact.bites[i]; return b ? Math.round(((tv - 1) * vi / 1000 - b[1]) * 1000) : null; }).filter(x => x !== null);
      if (cmp.length) out.lines.push(`<b>Locked frame against your bite marks</b>: ${cmp.map((x, i) => `bite ${i + 1} marked ${ms(x)} after that frame's bite`).join(' · ')} ${cmp.every(x => x > 60 && x < 500) ? '(a normal reaction: it fits)' : '<b style="color:#ffd28a">(not a reaction time: the locked frame is not what the bites show)</b>'}.`); }
  }
  if (res) out.lines.push(`<b>Result</b>: ${res}.`);
  return out;
}
function drawCastRepFs(cv, q) {
  const dpr = devicePixelRatio || 1, W = cv.width = Math.max(300, cv.clientWidth) * dpr, H = cv.height = 190 * dpr, g = cv.getContext('2d'), vi = q.vi || viMs(), f = q.fs, T = f.T;
  g.clearRect(0, 0, W, H); g.fillStyle = '#0b141c'; g.fillRect(0, 0, W, H); g.font = `${11 * dpr}px system-ui`;
  if (!T) { g.fillStyle = '#8ea3b2'; g.fillText(f.tap != null ? 'Freestyle: no bars within 0.5 s of your tap' : 'Freestyle: no target declared (no tap at the cast, no locked dog)', 10 * dpr, 30 * dpr); return; }
  const mid = (T.f0 + T.f1 + 2) / 2, pts = [f.tap, f.lock].filter(v => v != null), half = Math.max(30, ...pts.map(v => Math.abs(v - mid) + 8)), lo = mid - half, hi = mid + half, X = v => (v - lo) / (hi - lo) * W, base = H - 34 * dpr, top = 46 * dpr;
  g.fillStyle = '#7fd6ff22'; g.fillRect(X(T.f0), top - 6 * dpr, X(T.f1 + 2) - X(T.f0), base - top + 6 * dpr); g.strokeStyle = '#7fd6ff'; g.lineWidth = 2 * dpr; g.strokeRect(X(T.f0), top - 6 * dpr, X(T.f1 + 2) - X(T.f0), base - top + 6 * dpr);
  for (const [v, nb] of f.bars || []) { if (v < lo || v > hi) continue; const inT = v >= T.f0 && v <= T.f1; g.globalAlpha = inT ? 1 : 0.35; g.fillStyle = BITECOL[nb]; g.fillRect(X(v) + 1, top, Math.max(2, X(2) - X(0) - 2), base - top); }
  g.globalAlpha = 1; g.font = `${10 * dpr}px system-ui`;
  for (let m = -1000; m <= 1000; m += 100) { const x = X(mid + m / vi); if (x < 0 || x > W) continue; g.fillStyle = '#263746'; g.fillRect(x, base, 1, 5 * dpr); if (m % 200 === 0) { g.fillStyle = '#8ea3b2'; g.fillText((m > 0 ? '+' : '') + m, x - 8 * dpr, base + 16 * dpr); } }
  g.fillStyle = '#8ea3b2'; g.fillText('ms from the middle of the target · one bar = one game frame (33 ms)', 8 * dpr, base + 28 * dpr);
  const mark = (v, col, txt, row) => { g.strokeStyle = col; g.lineWidth = 3 * dpr; g.beginPath(); g.moveTo(X(v), 26 * dpr + row * 12 * dpr); g.lineTo(X(v), base); g.stroke(); g.fillStyle = col; g.font = `600 ${11 * dpr}px system-ui`; const tw = g.measureText(txt).width; g.fillText(txt, Math.max(4 * dpr, Math.min(W - tw - 4 * dpr, X(v) + 5 * dpr)), 24 * dpr + row * 12 * dpr); };
  if (f.tap != null) mark(f.tap, '#ff9d3a', 'your tap', 0);
  if (f.lock != null) mark(f.lock + 1, f.by === 'lock' || f.cadj ? '#8ff0a4' : '#7f8f9c', f.by === 'lock' || f.cadj ? 'the dog: cast landed here' : 'locked, not moved (the assumed frame)', 1);
  g.fillStyle = '#7fd6ff'; g.font = `600 ${11 * dpr}px system-ui`; g.fillText(`target: ${T.kind}${T.n > 1 ? ' ×' + T.n : ''}`, 8 * dpr, 12 * dpr);
}
function drawCastRep(cv, q) {
  if (q.fs) return drawCastRepFs(cv, q);
  const dpr = devicePixelRatio || 1, W = cv.width = Math.max(300, cv.clientWidth) * dpr, H = cv.height = 190 * dpr, g = cv.getContext('2d'), vi = q.vi || viMs();
  g.clearRect(0, 0, W, H); g.fillStyle = '#0b141c'; g.fillRect(0, 0, W, H);
  const lo = q.T - 60, hi = q.T + 60, X = v => (v - lo) / (hi - lo) * W, base = H - 34 * dpr, top = 44 * dpr;
  g.font = `${10 * dpr}px system-ui`;
  const ym = Math.max(0.02, ...q.cv);
  g.fillStyle = '#3a5870'; q.cv.forEach((p_, i) => { const v = Math.round(q.T) - 60 + 2 * i, h = p_ / ym * (base - top) * 0.55; g.fillRect(X(v), base - h, Math.max(1, X(2) - X(0) - 1), h); });
  g.fillStyle = '#8ea3b2'; g.fillText(`P(Nut) for a cast here (top ${pct(ym)})`, 4 * dpr, base - (base - top) * 0.55 - 3 * dpr);
  for (let m = -1000; m <= 1000; m += 250) { const x = X(q.T + m / vi); g.fillStyle = '#263746'; g.fillRect(x, base, 1, 5 * dpr); g.fillStyle = '#8ea3b2'; g.fillText((m > 0 ? '+' : '') + m, x - 10 * dpr, base + 15 * dpr); }
  g.fillText('ms from the target', W - 96 * dpr, base + 27 * dpr);
  if (q.lh && q.lh.length) { const m = Math.max(...q.lh.map(x => x[1])); g.fillStyle = '#b48cffcc';
    for (const [o, x] of q.lh) { const h = x / m * (base - top) * 0.9; g.fillRect(X(q.T + o) - Math.max(1, (X(1) - X(0)) / 2), base - h, Math.max(2, X(1) - X(0)), h); } }
  const mark = (v, col, dash, lw) => { if (v < lo || v > hi) return false; g.strokeStyle = col; g.lineWidth = lw * dpr; g.setLineDash(dash ? [5 * dpr, 4 * dpr] : []); g.beginPath(); g.moveTo(X(v), top - 6 * dpr); g.lineTo(X(v), base); g.stroke(); g.setLineDash([]); return true; };
  mark(q.T, '#5fd38d', false, 3); mark(q.T + q.corr / vi, '#6fb7ff', true, 2);
  const pOn = q.press ? mark(q.press[0], '#ff9d3a', false, 2) : false;
  const ex = q.dog && q.dog.exact && Number.isFinite(q.dog.exact.frame) ? mark(q.dog.exact.frame, '#ffffff', true, 1.5) : false;
  const key = [['#5fd38d', 'target: where the cast should land'], ['#6fb7ff', q.corr ? `CAST line as drawn (${q.corr > 0 ? '+' : '−'}${Math.abs(q.corr)} ms)` : 'CAST line as drawn (on the target)']];
  if (q.press) key.push(['#ff9d3a', pOn ? 'your press (Space with B)' : `your press: ${Math.round((q.press[0] - q.T) * vi)} ms from the target (off this picture)`]);
  if (q.lh && q.lh.length) key.push(['#b48cff', 'where the bite marks say it landed']);
  if (ex) key.push(['#ffffff', 'the frame you locked with the dog']);
  let x = 4 * dpr, y = 12 * dpr;
  for (const [c, tx] of key) { const wd = g.measureText(tx).width + 22 * dpr; if (x + wd > W) { x = 4 * dpr; y += 13 * dpr; } g.fillStyle = c; g.fillRect(x, y - 7 * dpr, 10 * dpr, 7 * dpr); g.fillStyle = '#cfd9e0'; g.fillText(tx, x + 14 * dpr, y); x += wd; }
}
const castRepPlain = (q, res, when) => { const r = castRepRead(q, res); return r ? `HM64 Lucky Timer — cast report${when ? ' · ' + when : ''}\n` + r.lines.map(x => x.replace(/<[^>]+>/g, '')).join('\n') + '\n\nraw: ' + JSON.stringify(q) : ''; };
let attShow = 12, attOpen = null;
function renderAttempts() {
  const el = $('lkAttList'); if (!el) return;
  const rows = attemptList(), live = run.wall0 !== null;
  const hhmm = at => { const d = new Date(at); return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) + ' ' + d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit', second: '2-digit' }); };
  const RES = { nut: '<b style="color:#8ff0a4">Power Nut</b>', miss: 'fish / missed', empty: 'empty line' };
  const chip = (t, on) => (on ? `<span class="lkchip">${t}</span>` : '');
  const unlogged = rows.filter(a => !a.logged).length;
  $('lkAttSum').innerHTML = rows.length ? `${rows.length} attempt${rows.length === 1 ? '' : 's'} hold data` + (unlogged ? ` — <b style="color:#ffd28a">${unlogged} never logged with H / M / E</b> (Esc or the stopwatch ran out; their taps were kept)` : '') : 'No attempt data stored.';
  $('lkAttUndo').disabled = !lastRemoved; $('lkAttLast').disabled = !rows.length || live;
  $('lkAttUndo').textContent = lastRemoved ? `Undo: put back the attempt of ${hhmm(lastRemoved.row.at)}` : 'Undo';
  const NOFITTXT = nf => (nf.k === 'none' ? `<b style="color:#ef6f6f">off the tables</b> <span class="mut">no cast within ±0.75 s fits</span>`
    : `<span style="color:#f0b35a">no dog line</span> <span class="mut">${Number.isFinite(nf.ms) ? `a cast ${msTxt(nf.ms)} would fit` : nf.s ? `a far ${nf.s < 0 ? 'early' : 'late'} cast would fit` : nf.tab ? 'the other arrival table would fit' : 'cause open'}</span>`);
  const LANDTXT = ld => (!ld ? '<span class="mut">—</span>' : ld.side === 'early' ? `<b style="color:#6fb7ff">too early</b> ${pct(ld.early)} · ${msTxt(ld.ms)}`
    : ld.side === 'late' ? `<b style="color:#ff9d7a">too late</b> ${pct(ld.late)} · ${msTxt(ld.ms)}` : ld.side === 'on' ? `<b style="color:#8ff0a4">on the frame</b> ${pct(ld.on)}`
    : `<span class="mut">not clear (early ${pct(ld.early)} / late ${pct(ld.late)})</span>`);
  const sk = landStreak(rows), SIDE = { early: 'too early', late: 'too late', on: 'on the frame' };
  if ($('lkAttLand')) $('lkAttLand').innerHTML = !sk ? '' :
    `Cast calls (from your bite taps; last ${sk.total} clear ones): <b style="color:#6fb7ff">too early ${sk.cnt.early}</b> · <b style="color:#8ff0a4">on the frame ${sk.cnt.on}</b> · <b style="color:#ff9d7a">too late ${sk.cnt.late}</b>.` +
    (sk.n >= 3 && sk.side !== 'on' ? ` <b style="color:#ffd28a">The last ${sk.n} in a row say ${SIDE[sk.side]} (about ${Math.abs(sk.ms)} ms): you are ${sk.side === 'early' ? 'pressing B ahead of the cue' : 'pressing B behind the cue'}.</b> ` +
      `Aim ${sk.side === 'early' ? 'later' : 'earlier'} yourself — or leave it to the app: with "learn from your bite taps" ticked (Settings · your timing) it moves the cue to meet this habit${L.autoTune !== false ? ' (it is ticked now; untick it if you would rather fix your own aim)' : ' (it is off now)'}.`
     : sk.n >= 3 ? ` The last ${sk.n} in a row landed on the frame.` : '') +
    ' A single call is right about 3 times in 4; a bad attempt\'s call goes with it when you remove it.';
  { /* v31.13: totals of the reports: how the casts landed, in percent */
    const rq = rows.filter(a => a.q).slice(0, 40).map(a => castRepRead(a.q)).filter(Boolean), nn = rq.length, c = k => rq.filter(r => r.call === k).length;
    if ($('lkAttRep')) $('lkAttRep').innerHTML = nn ? `<b>Cast quality</b>, last ${nn} attempt${nn === 1 ? '' : 's'} with a report: <b style="color:#6fb7ff">too early ${pct(c('early') / nn)}</b> · <b style="color:#8ff0a4">on the frame ${pct(c('on') / nn)}</b> · <b style="color:#ff9d7a">too late ${pct(c('late') / nn)}</b> · inconclusive ${pct(c('unclear') / nn)} · no dog line ${pct(c('nofit') / nn)} · no bite marked ${pct(c('none') / nn)}. Open <b>Report</b> on an attempt for its close-up.` : '';
    { const fr = rq.filter(r => r.fs && r.call !== 'unclear'), k = x => fr.filter(r => r.call === x).length; if ($('lkAttRep') && fr.length) $('lkAttRep').innerHTML += ` <span style="color:#7fd6ff"><b>Freestyle targets</b> (${fr.length} graded): inside ${k('on')} · early ${k('early')} · late ${k('late')}.</span>`; }   // v31.22
  }
  const RESP = { nut: 'Power Nut', miss: 'fish / missed', empty: 'empty line' };
  const repRow = a => { if (!a.q || String(attOpen) !== String(a.id)) return ''; const r = castRepRead(a.q, a.logged ? RESP[a.result] : 'not logged (Esc, or the stopwatch ran out)');
    return r ? `<tr class="lkreprow"><td colspan="6"><div class="lkrep"><canvas class="lkrepcv" data-rep="${a.id}"></canvas><div class="lkreptxt">${r.lines.map(x => `<div>${x}</div>`).join('')}</div><div><button data-rep-copy="${a.id}" title="Copy this report (text + the stored numbers) to paste somewhere">Copy report</button></div></div></td></tr>` : ''; };
  el.innerHTML = rows.length ? '<table id="lkAttTbl"><tr><th>when</th><th>result</th><th>cast</th><th>the cast landed</th><th>what it stored</th><th></th></tr>' + rows.slice(0, attShow).map(a =>
    `<tr><td>${hhmm(a.at)}</td><td>${a.logged ? RES[a.result] : '<span style="color:#ffd28a">not logged</span>'}</td><td>${a.T || '—'}</td><td>${a.nofit && !a.land ? NOFITTXT(a.nofit) : LANDTXT(a.land)}</td>` +
    `<td>${chip('L4 log', a.has.tally)}${chip('cast tap', a.has.castTap)}${chip(a.has.clock + ' clock taps', a.has.clock)}${chip('bite taps', a.has.bite)}${chip('dock reflex', a.has.dock)}${chip('dog arrows', a.has.dog)}</td>` +
    `<td>${a.q ? `<button data-rep-open="${a.id}">${String(attOpen) === String(a.id) ? 'Hide report' : 'Report'}</button> ` : ''}<button data-att-remove="${a.id}"${live && a.id === run.aid ? ' disabled' : ''}>Remove</button></td></tr>` + repRow(a)).join('') + '</table>' +
    (rows.length > attShow ? `<button id="lkAttMore">Show ${Math.min(25, rows.length - attShow)} more</button>` : '') : '';
  for (const b of el.querySelectorAll('[data-att-remove]')) b.onclick = () => removeAttempt(b.getAttribute('data-att-remove'));
  for (const b of el.querySelectorAll('[data-rep-open]')) b.onclick = () => { const id = b.getAttribute('data-rep-open'); attOpen = String(attOpen) === id ? null : id; renderAttempts(); };
  for (const cvs of el.querySelectorAll('canvas[data-rep]')) { const a = rows.find(x => String(x.id) === cvs.getAttribute('data-rep')); if (a && a.q) drawCastRep(cvs, a.q); }
  for (const b of el.querySelectorAll('[data-rep-copy]')) b.onclick = () => { const a = rows.find(x => String(x.id) === b.getAttribute('data-rep-copy')); if (!a) return;
    const txt = castRepPlain(a.q, a.logged ? RESP[a.result] : 'not logged', hhmm(a.at)); const done = ok => { b.textContent = ok ? 'Copied ✓' : 'Copy failed'; setTimeout(() => { b.textContent = 'Copy report'; }, 1500); };
    try { navigator.clipboard.writeText(txt).then(() => done(true), () => done(false)); } catch (e) { try { const ta = document.createElement('textarea'); ta.value = txt; document.body.appendChild(ta); ta.select(); const ok = document.execCommand('copy'); ta.remove(); done(ok); } catch (e2) { done(false); } } };
  if ($('lkAttMore')) $('lkAttMore').onclick = () => { attShow += 25; renderAttempts(); };
}

/* ---------------------------------------------------------------- tally */
function renderTally() {
  const mine = tally.filter(x => (x.route || 'carry') === route());
  const n = mine.length, h = mine.filter(x => x.hit).length;
  const p = run.plan ? valueAt(run.plan, run.pol, run.T) : NaN;
  const recent = mine.slice(-12).map(x => `<span class="${x.hit ? 'hit' : 'miss'}" title="${x.plan} · ${x.T}${x.outcome ? ' · ' + x.outcome : ''}">${x.hit ? '●' : x.outcome === 'empty' ? '◌' : '○'}</span>`).join('');
  const atLeast = isNaN(p) || !n ? '' : ` · with ${pct(p)} per try, ${pct(1 - Math.pow(1 - p, n))} of runners would have one by now`;
  const empties = mine.filter(x => x.outcome === 'empty').length, tapped = mine.filter(x => x.fit !== undefined && x.tap !== undefined);
  const onLine = tapped.filter(x => x.fit).length, others = tally.length - n;
  $('lkTally').innerHTML = (route() !== 'carry' ? `<div class="small mut">Route <b>${routeDef().label}</b>${others ? ` (${others} attempt${others === 1 ? '' : 's'} on other routes not counted here)` : ''}</div>` : '') +
    `<div><b>${h}</b> Power Nut${h === 1 ? '' : 's'} in <b>${n}</b> tr${n === 1 ? 'y' : 'ies'} ` +
    `(${n ? pct(h / n) : '—'})${atLeast}</div><div class="small mut">Plan: ~${isNaN(p) || p <= 0 ? '—' : (1 / p).toFixed(1)} tries per Nut on average. Blind 1/51 would be 51.</div>` +
    (empties ? `<div class="small">${empties} of the misses came back empty (B outside the bite window).</div>` : '') +
    (route() !== 'carry' && tapped.length ? `<div class="small">Line check: ${onLine} of ${tapped.length} tapped bites fit ${routeDef().lines ? "one of this route's " + routeDef().lines.length + ' dog lines' : "this route's dog line"}` +
      `${tapped.length - onLine ? ' — the others were off the simulated routes (this table does not apply to them)' : ''}.</div>` : '') +
    `<div class="lkrecent">${recent}</div>`;
  renderLast();
  renderAttempts();
}
/* v30.23: keep what the dog-watch knew about the dog line when the cast came (lab weights, not the personal ones, so a
   habit cannot feed itself): per line with a cast table, the likelihood of the logs relative to the best line. A pick
   that stood counts as the player's own identification: every other line x 0.2. Nothing is kept when the logs say
   nothing (no log and no pick, or every line fits alike). */
function saveDogLine() {
  const w = run.dw;
  if (!w || w.lineSaved || run.preview || run.wall0 === null || !DWC || !w.cands || !w.lk || !(w.logs.length || w.pick || (w.out && w.out.length))) return false;
  const t = (now() - run.wall0) / viMs() + 1;
  if (t < run.T - 30) return false;                              // stopped before the cast: not an attempt on a line
  w.lineSaved = true;
  const g3 = w.g3, l3 = c => (g3 ? Math.exp(-0.5 * ((g3.tau3 - c.mt - g3.r3) / g3.sd) ** 2) : 1);
  const V = (w.base || run.plan).variants, num = new Map(), den = new Map(), dwiOf = new Map();
  w.cands.forEach((c, i) => { if (c.pv < 0 || !V[c.pv]) return; const sx = V[c.pv].s, q = c.w * l3(c); dwiOf.set(sx, c.dwi); num.set(sx, (num.get(sx) || 0) + q * w.lk[i]); den.set(sx, (den.get(sx) || 0) + q); });
  let rel = [...num.keys()].map(sx => [sx, den.get(sx) > 0 ? num.get(sx) / den.get(sx) : 0]);
  if (w.pick) rel = rel.map(([sx, v]) => [sx, dwiOf.get(sx) === w.pick.dwi ? Math.max(v, 1e-6) : v * 0.2]);
  if (w.out && w.out.length) rel = rel.map(([sx, v]) => [sx, w.out.includes(dwiOf.get(sx)) ? v * 0.05 : v]);   // v30.32: lines the player removed
  const mx = Math.max(...rel.map(x => x[1]), 0);
  if (!(mx > 0)) return false;
  rel = rel.map(([sx, v]) => [sx, v / mx]);
  if (rel.every(x => x[1] > 0.8)) return false;                    // the logs do not tell lines apart
  const keep = rel.filter(x => x[1] >= 0.05).sort((a, b) => b[1] - a[1]).slice(0, 16), rest = rel.filter(x => !keep.includes(x));
  dogLines.push({ aid: run.aid, at: Date.now(), k: (run.plan0 || run.plan).k, anchor: anchor(), route: route(), pace: LuckyCore.selection.pace, ...(anchor() === 'fadein' ? { ref: L.beachCue } : {}),
                  dl: keep.map(([sx, v]) => [sx, +v.toFixed(3)]), fl: +(rest.length ? Math.max(0.005, rest.reduce((a, x) => a + x[1], 0) / rest.length) : 0.02).toFixed(4), n: w.logs.length, ...(w.pick ? { pick: 1 } : {}) });
  dogLines = dogLines.slice(-200); store.set('hm64v30_doglines', dogLines);
  return true;
}
function saveTap(hit) {                                        // fold this attempt's bite-1 tap into the profile
  const ti = run.tapInfo;
  if (!ti || ti.saved) return;
  ti.saved = true;
  if (fsOn()) return;                                              // v31.14 freestyle: the player chose the cast - nothing here says anything about their timing
  const cs = run.cs || 0;                                        // stored on the unshifted stopwatch (auto-tune), so the profile fits one offset
  const ld = landing(ti);                                        // v30.11: the early / late call stays with the attempt's data (also when it is never logged)
  const qTap = run.logging ? undefined : castRepBuild();          // v31.13: an attempt that is never logged keeps its report here
  taps.push({ aid: run.aid, k: run.plan.k, T: ti.Teff - cs, tau: +(ti.tau - cs).toFixed(1), hit, pNut: +ti.pNut.toFixed(4), at: Date.now(), ...(qTap ? { q: qTap } : {}),
              ...(ld ? { land: { e: +ld.early.toFixed(2), l: +ld.late.toFixed(2), ms: ld.ms } } : {}), ...(!ti.fit && ti.nofit ? { nofit: nofitRec(ti.nofit) } : {}),
              anchor: anchor(), pace: LuckyCore.selection.pace, pol: run.pol, route: route(), ...(cs ? { cs: +cs.toFixed(2) } : {}),
              ...(anchor() === 'fadein' ? { ref: L.beachCue } : {}),
              ...(run.castTap !== null ? { c: +(run.castTap - cs).toFixed(1) } : {}), ...(ti.tau2 != null ? { tau2: +(ti.tau2 - cs).toFixed(1) } : {}),
              ...(ti.taus && ti.taus.length > 2 ? { tx: ti.taus.slice(2).map(x => +(x - cs).toFixed(1)) } : {}) });
  taps = taps.slice(-200); store.set('hm64v29_lucky_taps', taps);
  updateProfile();
}
/* v31.6 (Thomas 2026-11-20 20:41 / 20:42): "hold Space with B". A start-key press around the cast moment is watched:
   let go again within HOLD_MIN (a tap) -> everything as before (nothing, or the cast tap when that setting is on);
   still down after HOLD_MIN -> HOLD MODE for this attempt: the key went down with B, so its keydown is the cast (logged
   as the cast tap whatever the setting says) and its keyup is the moment B came up. A keyup that fits a bite of the
   tables is that bite, released (it stands in for the bite tap; the reaction is a release reaction); one that fits no
   bite is taken as an empty release (B let go between bites) and stored as such. Held-through bites cannot be tapped
   in hold mode (the key is down). The attempt keeps hold: {down, up, kind}: the two moments a second cast needs. */
const HOLD_MIN = 30;                                              // VIs (0.5 s)
function holdDown(t) {
  if (fsOn() || run.preview || run.hold || run.spc || run.tapInfo || !(t > run.T - 90 && t < run.T + 45)) return false;
  run.spc = { down: t };
  return true;
}
function holdTick(t) {
  const sp = run.spc;
  if (!sp || run.hold || t - sp.down < HOLD_MIN) return;
  run.hold = { down: sp.down, up: null, kind: null };
  if (run.castTap === null) registerCast(sp.down);
  cueFlash(`${keyName().toUpperCase()} HELD WITH B ✓ · let go of both together`, 'hold', 1500);
}
/* v31.7 (Thomas 21:06): "release space on the bites we get, to get the timing; then press space any time before the
   release recommendation, to not skip a beat". In hold mode EVERY bite is marked by letting go of Space:
     - B let go too (a catch)        -> Space simply stays up: that bite stands as released;
     - B still held (bite held on)   -> Space is pressed again, any time before the next bite: holdRe() turns the bite
                                        just marked into a HELD bite and the lamp goes on to the forecast for the next.
   So each Space-up is taken as "released" until a new Space-down says otherwise. The bite forecast is always worked out
   in hold mode (registerTap: holdish), so nothing has to be recomputed when the key goes down again. */
function holdUp(t) {
  const sp = run.spc; if (!sp) return false;
  run.spc = null;
  const h = run.hold; if (!h || h.up !== null) return false;       // a tap: nothing more
  h.up = t; (h.ups || (h.ups = [])).push(t);
  const cast0 = run.castTap !== null ? run.castTap : run.T;
  if (t < cast0 + G_CAST) { h.kind = 'early'; cueFlash('LET GO BEFORE THE FLOAT LANDED', 'info', 1200); return true; }
  let ti = run.tapInfo;
  if (ti && ti.byHold) {                                           // bite 2, 3, ...: one more marked bite
    if (ti.saved || t < ti.taus[ti.taus.length - 1] + G_RECAST) return true;
    applyTaps(ti, ti.taus.concat([t]), true);                      // posterior over every marked bite + the forecast for the next
    ti.released = ti.taus.length; h.kind = 'bite';
    return true;
  }
  const ok = registerTap(t); ti = run.tapInfo;
  if (ok && ti && ti.fit) { ti.released = 1; ti.byHold = true; h.kind = 'bite'; return true; }
  if (ok && ti) { h.nofit = ti.nofit || null; run.tapInfo = null; }
  h.kind = 'empty';
  cueFlash('LET GO · no bite of the tables there: taken as an empty line', 'info', 1600);
  return true;
}
function holdRe(t) {                                              // Space down again in hold mode = B is still held
  const h = run.hold; if (!h || h.up === null) return false;
  const ti = run.tapInfo, was = h.kind;
  h.up = null; h.kind = null; h.re = (h.re || 0) + 1; run.spc = { down: t, re: true };
  if (ti && ti.byHold && ti.released) {
    const n = ti.released; ti.released = 0;
    cueFlash(ti.fit && !ti.dud ? `BITE ${n} HELD ✓` : `BITE ${n} HELD`, 'hold', 900);
  } else if (was === 'empty') cueFlash('STILL HOLDING ✓', 'hold', 700);
  return true;
}
/* start-key presses after the start: with B (the cast, if on and near the aim), then at the first bite */
function isCastTap(t) { return !fsOn() && L.castTap && run.castTap === null && !run.tapInfo && t > run.T - 90 && t < run.T + 45; }
function registerCast(t) {
  if (run.preview || run.castTap !== null) return false;
  run.castTap = t;
  run.castErrMs = (t - run.T) * viMs() - cueCorr();                // vs the CAST cue
  beepAt(now(), 1500, 0.03, 0.08);
  cueFlash(`CAST LOGGED ${msTxt(run.castErrMs)}`, Math.abs(run.castErrMs) <= viMs() ? 'go' : 'info', 1200);
  return true;
}
function registerTap(t) {                                       // the first bite (any policy)
  const cast0 = run.castTap !== null ? run.castTap : run.T;
  if (fsWait()) return false;                                     // freestyle, cast not made: no bite to mark
  if (run.tapInfo || run.preview || t < cast0 + G_CAST) return false;
  const Teff = fsOn() ? run.fs.cast : run.T + cueCorr() / viMs(), withCast = run.castTap !== null && !fsOn();
  const b0 = fsOn() ? 0 : (prof ? (withCast ? prof.bias0 : prof.bias) : 0) - (run.cs || 0);   // this stopwatch is already shifted by cs
  const post = LuckyCore.tapPosterior(P(run.plan), Math.round(Teff), sigVI(), b0, t,
                                      lagMu(), lagSd(), null, withCast ? Object.assign({ c: run.castTap }, castCfg()) : null);
  if (run.gp && run.gp.t3 != null) {                            // dock-end record (plan before the dock-end re-weighting)
    const post0 = run.plan0 && run.plan0 !== run.plan ? LuckyCore.tapPosterior(P(run.plan0), Math.round(Teff), sigVI(), b0, t,
      lagMu(), lagSd(), null, withCast ? Object.assign({ c: run.castTap }, castCfg()) : null) : post;
    run.reflexRec = reflexFrom(post0);
  }
  const sum = LuckyCore.tapSummary(post, t);
  const fit = post.sc.length > 0 && post.Z > 1e-4;
  // bite 2 still matters when the plan holds bite 1: always for 2nd-bite policies; for smart zones (release windows)
  // when the bite came before a window or after it (the runner held through it and tapped it)
  const holdish = !!run.hold || run.pol === 'hold' || run.pol === 'tap' || (run.pol === 'zone' && !inZone(t - lagMu()));   // v31.7: hold mode always wants the forecast
  /* v30: the forecast for bite 2 weighs a Nut on bite 2 against a Nut on a later bite (routes with every-bite data); on
     the other routes it is the v29.9 bite-2 forecast (Nut moments of bite 2) */
  const fc = holdish && fit ? LuckyCore.forecast(post, 1) : null;
  run.tapInfo = { tau: t, Teff, pNut: fc ? fc.pNext : fit ? post.pNut : 0, pAny: fc ? fc.pAny : 0, p1: fit ? post.p1 : NaN, fit, sc: post.sc, nutT2: fc ? fc.nutT : null,
                  holdish, sum, spans2: fc ? fc.spans : [], holds2: fc ? fc.holds : [], fc, taus: [t], pb: [fit ? post.p1 : NaN], released: 0,
                  dud: holdish && fit && 100 * (fc ? fc.pAny : 0) < L.dudPct, withCast, tau2: null, p2b: NaN };
  const ti = run.tapInfo;
  ti.nofit = fit ? null : whyNoFit(ti, [t]);                     // v30.30
  if (!holdish) { beepAt(now(), 1100, 0.04, 0.1); return true; }
  cancelBeeps();                                                // the bite-1 window chirps no longer apply
  if (!fit) { beepAt(now(), 300, 0.25, 0.2); }
  else if (ti.dud) { beepAt(now(), 330, 0.12, 0.25); beepAt(now() + 170, 260, 0.2, 0.25); }
  else {
    beepAt(now(), 990, 0.08, 0.2);
    for (const [a] of ti.spans2) {                                // get-ready ticks before each bite-2 Nut moment
      const wa = run.wall0 + (a - 1) * viMs();
      if (wa - 600 > now() + 200) { beepAt(wa - 600, 1320, 0.035, 0.12); beepAt(wa - 300, 1320, 0.035, 0.12); }
    }
  }
  return true;
}
/* the start key again at bite 2, 3, ... (after holding the bite before): every tapped bite pins the frame further.
   v30: was this bite released (it came outside a hold-on window: green Nut moment, or the plain "release it") or held
   on (inside a hold-on window: a later bite is the better Nut)? Held -> the forecast for the next bite. */
function registerTap2(t) {
  const ti = run.tapInfo;
  if (!ti || !ti.holdish || ti.released || ti.saved || run.preview || t < ti.taus[ti.taus.length - 1] + G_RECAST) return false;
  const held = ti.fit && !ti.dud && inHold(t - lagMu());
  applyTaps(ti, ti.taus.concat([t]), held);
  beepAt(now(), 1100, 0.04, 0.1);
  if (!ti.released && ti.fit && !ti.dud) { cancelBeeps(); cueFlash(`BITE ${ti.taus.length} HELD ✓`, 'hold', 900); }
  return true;
}
/* (re)compute an attempt's bite taps: posterior over every tapped bite, the verdict on each, the forecast for the next */
function applyTaps(ti, taus, heldLast) {
  ti.taus = taus;
  const j = taus.length, b0 = (prof ? (ti.withCast ? prof.bias0 : prof.bias) : 0) - (run.cs || 0);
  const post = LuckyCore.tapPosterior(P(run.plan), Math.round(ti.Teff), sigVI(), b0, taus[0], lagMu(), lagSd(), null,
                                      ti.withCast ? Object.assign({ c: run.castTap }, castCfg()) : null, j > 1 ? taus[1] : null, taus.slice(2));
  const ok = post.sc.length && post.Z > 0;
  ti.nofit = ok ? null : whyNoFit(ti, taus);                      // v30.30
  ti.pb = taus.map((_, m) => (ok ? LuckyCore.biteNut(post, m + 1) : NaN));
  ti.tau2 = j > 1 ? taus[1] : null; ti.p2b = j > 1 ? ti.pb[1] : NaN;
  ti.released = j > 1 && !heldLast ? j : 0;
  if (j > 1 && !ti.released) {
    const fc = ok ? LuckyCore.forecast(post, j) : null;
    Object.assign(ti, { fc, pNut: fc ? fc.pNext : 0, pAny: fc ? fc.pAny : 0, spans2: fc ? fc.spans : [], holds2: fc ? fc.holds : [],
                        nutT2: fc ? fc.nutT : null, dud: !!fc && 100 * fc.pAny < L.dudPct, fit: !!ok, sc: post.sc });
    if (fc && !ti.dud) for (const [a] of ti.spans2) {             // get-ready ticks before each Nut moment of the next bite
      const wa = run.wall0 + (a - 1) * viMs();
      if (wa - 600 > now() + 200) { beepAt(wa - 600, 1320, 0.035, 0.12); beepAt(wa - 300, 1320, 0.035, 0.12); }
    }
  }
}
/* outcome: 'nut' | 'fish' (caught a fish / missed) | 'empty' (the rod came back with nothing) */
function record(hit, kind) {
  if (!run.plan) return;
  kind = hit ? 'nut' : (kind || 'fish');
  const ti = run.tapInfo, pol = run.pol;
  run.last = diagnose(kind, ti, pol);
  const repQ = castRepBuild();                                    // v31.13: the cast quality report, kept with the attempt
  run.logging = true;
  if (run.reflexRec) { run.reflexRec.aid = run.aid; if (!run.reflexRec.at) run.reflexRec.at = Date.now(); dock.push(run.reflexRec); dock = dock.slice(-80); store.set('hm64v29_lucky_dock', dock); run.reflexRec = null; }
  saveTap(hit);
  if (run.dw && run.dw.logs.length && !run.dw.cal) run.dw.cal = dwCalibrate(ti);   // v30.1: learn the arrow reaction from this attempt
  const oddsShown = parseFloat($('lkP').textContent) / 100;        // v30.25: the odds on screen for this cast, for the calibration check
  tally.push({ at: Date.now(), aid: run.aid, plan: run.plan.label, pol, T: fmtS(run.T), hit, outcome: kind, sigma: sigmaMs(), ...(isFinite(oddsShown) ? { odds: +oddsShown.toFixed(4) } : {}), ...(L.audio ? {} : { v: 1 }),
               pace: LuckyCore.selection.pace, start: anchor(), route: route(), fit: ti ? !!ti.fit : undefined,
               cast: run.castTap !== null ? +((run.castTap - 1) * viMs() / 1000).toFixed(3) : undefined,
               castErrMs: run.castTap !== null && !fsOn() ? Math.round(run.castErrMs) : undefined,
               fs: fsOn() ? { cast: run.fs.cast != null ? +((run.fs.cast - 1) * viMs() / 1000).toFixed(3) : null, tap: run.fs.raw != null ? +((run.fs.raw - 1) * viMs() / 1000).toFixed(3) : null } : undefined,
               hold: run.hold ? { down: +((run.hold.down - 1) * viMs() / 1000).toFixed(3), up: run.hold.up !== null ? +((run.hold.up - 1) * viMs() / 1000).toFixed(3) : null, ups: (run.hold.ups || []).map(u => +((u - 1) * viMs() / 1000).toFixed(3)), kind: run.hold.kind, nofit: run.hold.nofit || undefined } : undefined,
               tap: ti ? +((ti.tau - 1) * viMs() / 1000).toFixed(3) : undefined, tapNut: ti ? +ti.pNut.toFixed(3) : undefined,
               bite1Nut: ti && ti.fit ? +ti.p1.toFixed(3) : undefined,
               land: run.last && run.last.land ? { e: +run.last.land.early.toFixed(2), l: +run.last.land.late.toFixed(2), ms: run.last.land.ms } : undefined, nofit: nofitRec(run.last && run.last.nofit), lagMs: ti && ti.sum ? Math.round(ti.sum.lag * viMs()) : undefined,
               ...(run.dw && (run.dw.logs.length || run.dw.pick || run.dw.exact != null || run.dw.cadj) ? { dw: dwRecord() } : {}), q: repQ });
  store.set('hm64v29_lucky_tally', tally);
  run.result = hit ? 'nut' : 'miss'; run.resultAt = now();
  run.logging = false; attOpen = run.aid;                         // the new attempt's report is open in the list
  stop(false); renderTally();
}
const verdict = p1 => (isNaN(p1) ? (routeDef().lines ? "fits none of this route's dog lines (off the simulated routes)" : route() !== 'carry' ? 'off this line (fits no cast frame on it)' : 'fits no dog path') : p1 >= 0.8 ? `a Power Nut bite (${pct(p1)})` : p1 <= 0.02 ? 'a fish bite' : `maybe the Nut (${pct(p1)})`);
/* what went wrong (or right), from the taps and what came out of the water. Game facts (player.c handleFishingAction):
   B up during the bite (20 polls) -> catch; B up at any other moment -> the line comes back empty; the lab: releases
   1-2 frames after the window still catch, but a fish */
/* v30.9 (Thomas, 2026-11-17): where did the cast land? The app never sees the B press, but every bite tap weighs the
   (dog line, landed frame) pairs of the cast tables: each entry of ti.sc carries d = landed frame - the CAST cue's
   frame (VIs). Offset from the AIMED frame = d + (cue frame - aim). early / on / late = posterior mass with the offset
   under -1 VI / within +-1 VI (the aimed game frame and the VI beside it) / over +1 VI; ms = the posterior median.
   A call is made at >= 60% on one side. It covers B-press timing and the stopwatch's clock error together. */
const LAND_CALL = 0.6;
/* v30.30 (Thomas, 2026-11-20): bite taps that fit no dog line - what explains them? The route's arrival tables (its own
   and its siblings: e.g. menus 0-4 frames late and "sparrows at the door" = 5-6 frames late) are searched for any cast
   within +-0.75 s that gives the tapped bites (LuckyCore.noFit).
   What simulation says (tests/test_nofit.js, lineup-lineup2, 200 attempts per case): a normal attempt on the tables fails
   the fit about 1 time in 100; a cast 0.3 - 0.7 s off, or the other arrival table, about 1 in 10; taps that do not belong
   to the tables about 8 in 10. So a no-fit is, most of the time, a run OFF the tables. And when a far cast or the other
   table would give the bite, an off-table run matches like that by chance about as often (1 bite: 25 - 50% of them; 2
   bites: 5 - 15%) - so that match is shown as a possibility and never counted as a cast error.
   k: 'none' = no cast within +-0.75 s on any arrival table gives these bites; 'maybe' = something would (alt). */
const NOFIT = { R: 45, W: 4, need: 0.9, base: 0.01, off: 0.8 };
function siblingTables() {
  const base = baseOf(route()), out = [];
  for (const r of LuckyCore.routes()) {
    if (r.id === route() || (r.id !== base && r.variant_of !== base)) continue;
    const ps = LuckyCore.planSet(LuckyCore.selection.pace, anchor(), r.id) || [], pl = ps.find(q => run.plan && q.k === run.plan.k) || ps[0];
    if (pl) out.push({ id: r.id, plan: pl });
  }
  return out;
}
function whyNoFit(ti, taus) {
  try {
    const sibs = siblingTables(), withCast = ti.withCast && run.castTap !== null;
    const b0 = (prof ? (withCast ? prof.bias0 : prof.bias) : 0) - (run.cs || 0);
    const sd = withCast ? Math.hypot(lagSd(), castCfg().tapSd) : lagSd();
    const o = LuckyCore.noFit([P(run.plan)].concat(sibs.map(q => q.plan)), Math.round(withCast ? run.castTap : ti.Teff) + Math.round(b0), taus.slice(0, 2), lagMu(), sd,
                              NOFIT.R, NOFIT.W, NOFIT.need, withCast ? run.castTap : null);
    const nf = { k: o.k === 'none' ? 'none' : 'maybe', n: Math.min(2, taus.length), tabs: 1 + sibs.length };
    if (o.k === 'cast') nf.ms = Math.round(o.d * viMs());
    else if (o.k === 'side') nf.s = o.s;
    else if (o.k === 'table') nf.tab = sibs[o.j - 1] ? sibs[o.j - 1].id : null;
    return nf;
  } catch (e) { return null; }
}
const nofitTabs = nf => (nf.tabs > 1 ? `any of this route's ${nf.tabs} arrival tables` : `this route's table`);
function nofitTxt(nf) {
  if (!nf) return '';
  const b = nf.n > 1 ? 'these bites' : 'this bite';
  if (nf.k === 'none') return `no dog line: no cast within ±0.75 s gives ${b} on ${nofitTabs(nf)} — the run was off the tables`;
  const R = nf.tab ? LuckyCore.routes().find(r => r.id === nf.tab) : null;
  const alt = Number.isFinite(nf.ms) ? `a cast about ${Math.abs(nf.ms)} ms ${nf.ms < 0 ? 'early' : 'late'} would give ${b}` : nf.s ? `a cast far too ${nf.s < 0 ? 'early' : 'late'} would give ${b}` :
    nf.tab ? `the other arrival table (${R && R.label ? R.label.split('·').pop().trim() : nf.tab}) would give ${b}` : `more than one far cast or arrival table would give ${b}`;
  return `no dog line at your cast: ${alt} — a possibility, not a call`;
}
const nofitAdvice = nf => (!nf ? '' : nf.k === 'none' ? ' No dog line and no cast within ±0.75 s explains the bite: this is not a cast-timing miss. The run was off the tables — the menus ended later than the tables cover, another route, a start tap far off, or the tap was not the bite.' :
  ` The bite fits no dog line at your cast. Most often that is a run off the tables (menus later than the tables cover); ${nf.n > 1 ? 'a far cast is the rarer cause' : 'one bite cannot tell that from a far cast — hold bite 1 and tap bite 2 too'}.`);
const nofitRec = nf => (nf ? { k: nf.k, n: nf.n, tabs: nf.tabs, ...(Number.isFinite(nf.ms) ? { ms: nf.ms } : {}), ...(nf.s ? { s: nf.s } : {}), ...(nf.tab ? { tab: nf.tab } : {}) } : undefined);
function landing(ti) {
  if (!ti || !ti.fit || !ti.sc || !ti.sc.length) return null;
  const shift = Math.round(ti.Teff) - run.T, by = new Map();
  let Z = 0, early = 0, late = 0;
  for (const e of ti.sc) { const o = e.d + shift; Z += e.w; by.set(o, (by.get(o) || 0) + e.w); if (o < -1) early += e.w; else if (o > 1) late += e.w; }
  if (!(Z > 0)) return null;
  let acc = 0, med = 0;
  for (const o of [...by.keys()].sort((a, b) => a - b)) { acc += by.get(o); if (acc >= Z / 2) { med = o; break; } }
  early /= Z; late /= Z;
  const side = early >= LAND_CALL ? 'early' : late >= LAND_CALL ? 'late' : 1 - early - late >= LAND_CALL ? 'on' : null;
  return { early, late, on: Math.max(0, 1 - early - late), ms: Math.round(med * viMs()), side, bites: ti.taus ? ti.taus.length : 1 };
}
const landTxt = ld => `cast landed (from the bite tap${ld.bites > 1 ? 's' : ''}): too early ${pct(ld.early)} · on the frame ${pct(ld.on)} · too late ${pct(ld.late)}` +
  (ld.side ? `, most likely ${msTxt(ld.ms)} from the aimed frame` : '');
const landAdvice = ld => (!ld ? '' : ld.side === 'early' ? ` You cast too early (${pct(ld.early)}; about ${Math.abs(ld.ms)} ms).` :
  ld.side === 'late' ? ` You cast too late (${pct(ld.late)}; about ${Math.abs(ld.ms)} ms).` :
  ld.side === 'on' ? ` The cast was on the aimed frame (${pct(ld.on)}): the dog line, not your timing.` :
  ` Early or late is not clear from this tap (early ${pct(ld.early)} / late ${pct(ld.late)}).`);
function diagnose(kind, ti, pol) {
  const parts = [];
  if (run.gp) parts.push(gpTxt());
  if (run.castTap !== null && !fsOn()) parts.push(`cast ${run.castErrMs >= 0 ? '+' : ''}${Math.round(run.castErrMs)} ms vs the CAST cue`);
  if (run.dw && run.dw.logs.length) parts.push(dwDiag(ti));
  const releasedAt1 = pol === 'bite1' || (pol === 'zone' && ti && !ti.holdish);
  if (ti) {
    parts.push(`bite ${ti.holdish ? '1 (held) ' : ''}tapped at ${fmtS(ti.tau)}: ${verdict(ti.p1)}` + (route() === 'carry' && ti.sum && ti.sum.pathShare >= 0.5 ? ` (most likely dog path ${ti.sum.path + 1}, ${pct(ti.sum.pathShare)})` : '') +
      (routeDef().lines && ti.sum && ti.sum.pathShare >= 0.3 ? ` (most likely dog line ${routeDef().sidxs.indexOf(ti.sum.path) + 1} of ${routeDef().lines.length}, ${pct(ti.sum.pathShare)})` : ''));
    if (ti.holdish && ti.fit && ti.taus.length === 1) parts.push(ti.dud ? `bite 2 forecast: DUD (${pct(ti.pAny)})` : `bite 2 forecast: Nut ${pct(ti.pNut)}`);
    for (let m = 1; m < ti.taus.length; m++) parts.push(`bite ${m + 1} ${ti.released === m + 1 ? '(released) ' : '(held) '}tapped at ${fmtS(ti.taus[m])}: ${verdict(ti.pb[m])}`);
    if (ti.taus.length > 1 && !ti.released && ti.fit) parts.push(ti.dud ? `bite ${ti.taus.length + 1} forecast: DUD` : `bite ${ti.taus.length + 1} forecast: Nut ${pct(ti.pNut)}`);
  }
  const ld = landing(ti);
  if (ld) parts.push(landTxt(ld));
  const nf = ti && !ti.fit ? ti.nofit : null;                     // v30.30
  if (nf) parts.push(nofitTxt(nf));
  let advice = '';
  if (kind === 'nut') advice = 'Power Nut!';
  else if (ti && ti.holdish && ti.tau2 != null) {
    if (kind === 'empty') advice = 'Empty line = B went up outside bite 2’s 0.33 s window.' + (ti.p2b >= 0.8 ? ' That bite was the Nut: release sooner.' : '');
    else if (ti.p2b >= 0.8) advice = 'A fish from a Nut bite 2: B most likely went up 1–2 frames after the window. Release sooner.';
    else if (ti.p2b <= 0.02) advice = 'Bite 2 was a fish however you released: not a release problem.';
  }
  else if (ti && ti.holdish && ti.dud) advice = 'Bite 2 could not be the Nut (the tool said reset).' + landAdvice(ld);
  else if (kind === 'empty') advice = 'Empty line = B went up outside the bite’s 0.33 s window (too late, or before the bite).' +
    (ti && ti.p1 >= 0.8 ? ' And that bite was the Nut: release sooner.' : '');
  else if (ti && releasedAt1 && ti.p1 >= 0.8) advice = 'A fish from a Nut bite: B most likely went up 1–2 frames after the window (lab: releases at +20/+21 polls give a fish). Release sooner.';
  else if (ti && releasedAt1 && ti.p1 <= 0.02) advice = 'That bite was a fish however you released: the cast landed on a fish frame, not a release problem.' + landAdvice(ld);
  else if (ti && releasedAt1) advice = 'Not sure which frame you landed on.';
  if (kind !== 'nut' && ld && !/You cast too|aimed frame|not clear/.test(advice)) advice += landAdvice(ld);
  if (kind !== 'nut' && nf) advice += nofitAdvice(nf);
  return { text: parts.join(' · '), advice, kind, land: ld, nofit: nf };
}
function renderLast() {
  const el = $('lkLast');
  if (!el) return;
  const d = run.last;
  el.innerHTML = d ? `<b>Last attempt</b> (${d.kind === 'nut' ? 'Power Nut' : d.kind === 'empty' ? 'empty line' : 'fish'}): ${d.text || 'no taps'}.` +
    (d.advice ? ` <span style="color:${d.kind === 'nut' ? 'var(--ok)' : '#ffd28a'}">${d.advice}</span>` : '') : '';
}

function renderProfile() {
  const el = $('lkProfile');
  if (!el) return;
  if (!prof || !prof.n) {
    el.innerHTML = `<span class="mut">Personal profile: no bite taps yet${taps.length ? ' with this start (' + startName() + ')' : ''}. Press the start key again when the first bite shows, every attempt; the plan then fits your own arrivals and timing.</span>`;
    return;
  }
  const top = Object.entries(prof.byPath).sort((a, b) => b[1] - a[1]).slice(0, 4).map(([k, m]) => `path ${+k + 1} ${Math.round(100 * m)}%`).join(', ');
  el.innerHTML = `<b>Bite taps</b>: ${prof.n} on this start${prof.nofit ? ` (${prof.nofit} fit no dog path)` : ''}, mostly ${top}. ` +
    `<label><input type="checkbox" id="lkPersonal" ${L.personal ? 'checked' : ''}> fit the plan to me</label> ` +
    '<button id="lkForget">Forget taps</button>';
  $('lkPersonal').onchange = e => { L.personal = e.target.checked; save(); persCache.clear(); bestCache = null; ccache.clear(); L.castT = null; refresh(); };
  $('lkForget').onclick = () => { if (confirm('Forget all bite taps (personal profile) and the learned arrow reaction?')) { taps = []; store.set('hm64v29_lucky_taps', taps); dwcal = []; store.set('hm64v30_dwcal', dwcal); updateProfile(); refresh(); } };
}

/* ---------------------------------------------------------------- run control */
/* v29.9 tap assignment on the fade-in start. The runner picks the cues to tap; any one can be missed. Times on the
   fade-in clock, VIs after the first light (lab, rendered + 30/30 ranch states): ranch exit -70 (the first frame Jack
   stands still = the first dimmer frame, main loop EXIT_LEVEL), first light 0, first control +66 (down-right held
   through the load: MAIN_GAME at VI 65 after the map change, Jack moves 6 units at 67 - a hair of scroll - and turns to
   face down-right at 69, the visible cue; rendered 2026-11-15), dock end = READY of the route
   (no fixed time: it depends on the beach walk, so it tells the timer which beach timing it was). */
const CTRL_VI = 66;
const CUES = [
  { id: 'exit', vi: -GP_GAP_VI, short: 'ranch exit', label: 'Last control at the green ranch exit (Jack stops dead, the screen starts to dim)' },
  { id: 'fade', vi: 0, short: 'fade-in', label: 'First light of the beach fade-in (the black screen starts to brighten)' },
  { id: 'ctrl', vi: CTRL_VI, short: 'first control', label: 'First control on the beach: Jack turns down-right and walks (hold down-right through the fade)' },
  { id: 'dock', vi: null, short: 'dock end', label: 'Jack stops at the dock end (READY)' }];
/* tap strategies: which cues a runner taps. 'B' = the beach cue (first light OR first control: they are 1.09 s
   apart, too close to tap both and still play). In two-tap sets the 2nd may be missed; in the three-tap set any one. */
const STRATS = [
  { id: 'b', cues: ['B'], label: '1 tap: the beach cue', note: 'the clock from one tap' },
  { id: 'eb', cues: ['exit', 'B'], label: '2 taps: ranch exit + beach cue', note: 'a sharper clock; the 2nd may be missed' },
  { id: 'bd', cues: ['B', 'dock'], label: '2 taps: beach cue + dock end', note: 'clock + your beach timing (re-aims the cast); the 2nd may be missed' },
  { id: 'ebd', cues: ['exit', 'B', 'dock'], label: '3 taps: ranch exit + beach cue + dock end', note: 'sharper clock + beach timing; any one may be missed' },
  { id: 'd', cues: [], label: '1 tap: dock end only', note: 'the dock-end start (READY), no transition taps' }];
const strat = () => (anchor() === 'pier' ? STRATS[4] : STRATS.find(x => x.id === L.tapStrategy) || STRATS[3]);
const tapCues = () => { const ids = strat().cues.map(x => (x === 'B' ? L.beachCue : x)); return CUES.filter(c => ids.includes(c.id)); };
const clockCues = () => tapCues().filter(c => c.vi != null);
const doubleOn = () => anchor() === 'fadein';
/* auto-tune: shift the stopwatch by the console offset the bite-tap profile has learned (n >= 8), so the beeps, zones
   and countdown land on the console's time. Taps are stored on the unshifted stopwatch (saveTap) and the profile fits
   those, so it never chases its own correction. */
const TEST = { autoB: null, prof: null };
/* the one-reaction tie is an assumption: bite taps that come later than your start taps push its clock estimate too far
   (lab sim, 24 attempts: bite taps as late as the start taps -> k 4 for a true 3.3 VI; 100 ms later -> k 7, about half
   the difference). Shrunk toward 0 by start-tap error sd 50 ms (3 VI) vs that half of a +-60 ms bite-vs-start
   difference (1.8 VI): 9 / (9 + 3.2) = 0.7. Equal taps lose ~1 VI; 100 ms slower bite taps land ~20 ms early, not ~55. */
const TIE_SHRINK = 0.7, TIE_CAP = 6;
function autoB() {
  if (TEST.autoB != null) return TEST.autoB;
  const prof = TEST.prof || prof_();
  if (!L.autoTune || !prof || prof.n < 8) return 0;
  /* the clock is tuned from attempts WITH the cast tap only (bias0: the bite's delay after your own cast moment pins the
     frame, so clock, B press and bite-tap lag come apart). Without it a bite tap mixes all three: in the lab sim (start
     tap 50 ms late, B 100 ms late, bite taps 215 ms) the fit put the shift into the bite lag (bias ~0), and neither
     "bias" nor "bias + correction" tunes the clock right. The B press is the cast-cue correction's job. */
  let b, cap = 18;
  if ((prof.nCast || 0) >= 8) b = prof.bias0;                   // cast taps: no assumption needed
  else if (L.tieReaction !== false && prof.kTied != null && (prof.nNoCast || 0) >= 8) {
    b = Math.round(TIE_SHRINK * prof.kTied);                    // one reaction
    if (!prof.tieRb) cap = TIE_CAP;                             // v30.25: resting on an assumption nobody measured: at most +-100 ms
  } else return 0;
  return Math.max(-cap, Math.min(cap, b || 0));
}
/* per attempt, the clock taps' times minus their cue times (ms), centred on the attempt's mean: the per-cue offsets
   (vs your beach-cue tap) and one tap's spread come from these (no bite needed). One tap set per route + tap strategy
   + beach cue, each in its own localStorage key (hm64v29_lucky_tapset/<route>/<strategy>/<cue>): [{at, y: {cue: ms},
   d?: dock tapped, s?: strays, x?: culled by the player, m?: carried over from the old shared list (strategy unknown)}].
   Stats use the last 40 kept (not culled) records of the set. */
const TS_PRE = 'hm64v29_lucky_tapset/', TS_KEEP = 120, TS_USE = 40;
const tsKey = (rt, st, cue) => TS_PRE + rt + '/' + st + '/' + cue;
const curTs = () => tsKey(baseOf(route()), strat().id, L.beachCue);   // tap timing does not depend on the variant
const tsCache = new Map();
function tsGet(k) {
  if (!tsCache.has(k)) { const v = store.get(k, []); tsCache.set(k, Array.isArray(v) ? v : []); }
  return tsCache.get(k);
}
function tsPut(k, a) {
  tsCache.set(k, a);
  if (a.length) store.set(k, a); else { try { localStorage.removeItem(k); } catch (e) { /* storage unavailable */ } }
}
function tsKeys() {                                            // every stored set (localStorage + this session's cache)
  const out = new Set();
  try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k && k.startsWith(TS_PRE)) out.add(k); } } catch (e) { /* none */ }
  for (const [k, a] of tsCache) if (a.length) out.add(k);
  return [...out];
}
function migrateTapRec() {                                     // the old shared list (and older exit/fade-in pairs) -> sets
  if (store.get('hm64v29_lucky_tapset_v', 0)) return;
  const old = store.get('hm64v29_lucky_taprec', null);
  const src = Array.isArray(old) ? old : fade2.map(p => ({ at: p.at, route: p.route, y: { exit: -p.d / 2, fade: p.d / 2 } }));
  const touched = new Set();
  for (const r of src) {
    const cue = r.y && (r.y.ctrl != null ? 'ctrl' : r.y.fade != null ? 'fade' : null);
    if (!cue || r.y.exit == null) continue;
    const k = tsKey(r.route || 'lineup-dogbeach', 'ebd', cue);  // the old list did not record the strategy
    tsGet(k).push({ at: r.at, y: r.y, m: 1 }); touched.add(k);
  }
  for (const k of touched) tsPut(k, tsGet(k).sort((a, b) => a.at - b.at).slice(-TS_KEEP));
  try { localStorage.removeItem('hm64v29_lucky_taprec'); } catch (e) { /* none */ }
  store.set('hm64v29_lucky_tapset_v', 1);
}
migrateTapRec();
{ /* v30.1 time base: stored tap sets keep each tap minus its cue's VI offset x ms-per-VI (then centred): the same taps
     against the new ms-per-VI (exit -70 VIs: +13 ms, first control +66 VIs: -12 ms before centring), once */
  const tb = store.get('hm64v30_tb', null);
  if (tb && tb.changed && !tb.sets && tb.from > 0 && tb.to > 0) {
    const dv = (tb.from - tb.to) / 2;                             // ms per VI: old - new
    let nrec = 0;
    for (const k of tsKeys()) {
      const a = tsGet(k).map(rec => {
        if (!rec || !rec.y) return rec;
        const ks = Object.keys(rec.y), y = {};
        for (const id of ks) { const c = CUES.find(q => q.id === id); y[id] = rec.y[id] + (c && c.vi != null ? c.vi * dv : 0); }
        const mu = ks.reduce((q, id) => q + y[id], 0) / (ks.length || 1);
        for (const id of ks) y[id] = Math.round(y[id] - mu);
        nrec++;
        return Object.assign({}, rec, { y });
      });
      tsPut(k, a);
    }
    tb.sets = nrec || true; store.set('hm64v30_tb', tb);
  }
}
const med = a => { const v = a.slice().sort((x, y) => x - y), n = v.length; return n ? (n % 2 ? v[(n - 1) / 2] : (v[n / 2 - 1] + v[n / 2]) / 2) : NaN; };
function tapStats(keys) {
  keys = keys || [curTs()];
  const rs = [].concat(...keys.map(k => tsGet(k).filter(r => !r.x).slice(-TS_USE))), ref = L.beachCue, off = { [ref]: { n: 0, m: 0 } };
  for (const c of CUES) {
    if (c.vi == null || c.id === ref) continue;
    const v = rs.filter(r => r.y[c.id] != null && r.y[ref] != null).map(r => r.y[c.id] - r.y[ref]);
    off[c.id] = { n: v.length, m: v.length ? med(v) * v.length / (v.length + 2) : 0, raw: med(v) };   // shrunk while few
  }
  let ss = 0, df = 0, nrec = 0;
  for (const r of rs) {
    const ys = Object.entries(r.y).map(([k, v]) => v - (off[k] ? off[k].m : 0));
    if (ys.length < 2) continue;
    const mu = ys.reduce((a, v) => a + v, 0) / ys.length;
    ss += ys.reduce((a, v) => a + (v - mu) ** 2, 0); df += ys.length - 1; nrec++;
  }
  return { off, nrec, sdAuto: nrec >= 5 && df ? Math.max(15, Math.sqrt(ss / df)) : NaN };
}
/* one clock tap's spread: manual, or auto from this set (strategies with 2 clock taps); strategies with ONE clock tap
   cannot show a spread, so they borrow it from the 2-clock-tap sets (ranch exit + beach cue) of this route + beach cue */
const TWO_CLOCK = ['eb', 'ebd'];
function precision() {
  if (!L.tapSdAuto) return { sd: L.tapSdMs, src: 'manual' };
  const own = clockCues().length >= 2;
  const st = tapStats(own ? [curTs()] : TWO_CLOCK.map(x => tsKey(baseOf(route()), x, L.beachCue)));
  return isFinite(st.sdAuto) ? { sd: st.sdAuto, src: own ? 'own' : 'borrowed', n: st.nrec } : { sd: 60, src: 'default', n: st.nrec, own };
}
const clockSd = () => precision().sd;
/* the cascade: the timing-spread slider assumes ONE start tap of +-60 ms (as cast practice sets it: hypot(SD, 60));
   on the fade-in start the clock comes from n clock taps of spread s each, so that part becomes s / sqrt(n) */
const START1_MS = 60;
function sigEffMs(aid) {
  if ((aid || anchor()) !== 'fadein') return sigmaMs();
  const sc = clockSd() / Math.sqrt(Math.max(1, clockCues().length));
  return Math.round(Math.sqrt(Math.max(sigmaMs() ** 2 - START1_MS ** 2, 30 ** 2) + sc ** 2));
}
function start(ts) {
  if (run.wall0 !== null || run.practice || run.bite) return;
  engage();
  cancelBeeps();
  refresh();
  ts = ts == null ? now() : ts;
  run.gp = null; run.plan0 = run.plan; run.cs = autoB(); run.reflexRec = null;
  run.aid = newAid();                                           // v30.8: everything this attempt stores carries its id
  if (root.HM64Timing) root.HM64Timing.addAttempt('lucky');     // v32.16: the one attempt count shared by every page
  setTimeout(renderAttempts, 0);
  if (doubleOn()) {
    run.gp = { taps: [ts], last: ts, asg: null, g3: null, rdy: readySpread(run.plan) };
    assign(run.gp, false);
  } else run.wall0 = ts - startDelay() - run.cs * viMs();       // the start event, from the key press
  run.beeped = new Set(); run.result = null; run.preview = null; run.tapInfo = null; run.castTap = null; run.castErrMs = null; run.spc = null; run.hold = null; run.fs = { on: !!L.free && !!dwRoute() && dcHas(dwRoute()), cast: null }; run.fsLive = null;
  run.dw = dwInit();
  scheduleBeeps();
  if (run.gp && routeDef().axes) {                              // warm the preset rows (one per tick) for the dock-end highlight
    const gs = routeDef().groups.slice(), id = run.wall0;
    const step = () => { if (run.wall0 === null || run.wall0 !== id && !run.gp || !gs.length) return; paceRow(gs.shift()); setTimeout(step, 40); };
    setTimeout(step, 60);
  }
  renderRouteBox();
}
let dock = store.get('hm64v29_lucky_dock', []);                // [{at, route, ms: dock-end tap - READY (bite posterior), sd}]
function dockStat() {
  const v = dock.slice(-40).map(x => x.ms).filter(x => isFinite(x)), n = v.length;
  return n ? { n, med: med(v) } : { n: 0 };
}
const r2abs = () => startDelay() + (run.cs || 0) * viMs();     // your clock taps' delay (start-key delay + auto-tune)
const r3abs = () => r2abs();                                   // the dock-end tap: taken as late as the clock taps
function readySpread(plan) {                                   // READY (dock end) on this plan's routes, VIs after the first light
  const v = plan.variants, W = v.reduce((a, x) => a + x.w, 0) || 1;
  const mean = v.reduce((a, x) => a + x.w * x.minT, 0) / W, sd = Math.sqrt(v.reduce((a, x) => a + x.w * (x.minT - mean) ** 2, 0) / W);
  return { mean: mean - 1, sd };                               // minT counts from 1 at the first light
}
/* which cue each tap was: every assignment of the taps (in time order) to the chosen cues (in time order) or to
   "stray", scored by how well the clock taps agree on one first light (spread s each), the dock tap's fit to READY on
   this plan's routes, a 1-in-10 prior per skipped cue and 1-in-20 per stray. Then the clock = the mean of the clock
   taps (minus each cue's learned offset vs your fade-in tap), aligned by the start-key delay, plus auto-tune. */
function assign(g, beeps) {
  const cues = tapCues(), vi = viMs(), s = clockSd(), off = tapStats().off, ws = g.taps, n = ws.length;
  const yOf = (w, c) => w - c.vi * vi - (off[c.id] ? off[c.id].m : 0);
  let best = null;
  const rec = (i, ci, a) => {
    if (i === n) { score(a.slice()); return; }
    a.push(-1); rec(i + 1, ci, a); a.pop();                    // stray
    for (let k = ci; k < cues.length; k++) { a.push(k); rec(i + 1, k + 1, a); a.pop(); }
  };
  const score = a => {
    const ys = [], dk = [];
    a.forEach((k, i) => { if (k < 0) return; if (cues[k].vi == null) dk.push(ws[i]); else ys.push(yOf(ws[i], cues[k])); });
    if (!ys.length) return;                                    // a clock tap is needed for this start
    const F = ys.reduce((x, v) => x + v, 0) / ys.length;
    let L = 0;
    for (const y of ys) L += -0.5 * ((y - F) / s) ** 2 - Math.log(s);
    L += Math.log(s);                                          // n - 1 free deviations
    const sdF = s / Math.sqrt(ys.length);
    for (const w of dk) {
      const sd = Math.hypot(g.rdy.sd * vi, Math.max(50, s), sdF), z = (w - (F - startDelay() + g.rdy.mean * vi + r3abs())) / sd;
      L += -0.5 * z * z - Math.log(sd);
    }
    const used = a.filter(k => k >= 0), last = used.length ? used[used.length - 1] : -1;
    const skips = cues.slice(0, last + 1).filter((c, k) => !used.includes(k)).length;
    const strays = a.filter(k => k < 0).length;
    L += skips * Math.log(0.1) + strays * (Math.log(0.05) + Math.log(1 / 8000));
    if (!best || L > best.L) best = { L, a, F, sdF, nClock: ys.length };
  };
  rec(0, 0, []);
  if (!best) best = { a: [0], F: yOf(ws[0], cues.find(c => c.vi != null) || CUES[1]), sdF: s, nClock: 1 };
  g.asg = best;
  g.cue = {};
  best.a.forEach((k, i) => { if (k >= 0) g.cue[cues[k].id] = ws[i]; });
  g.F = best.F - startDelay(); g.sdF = best.sdF;
  run.wall0 = g.F - (run.cs || 0) * vi;
  if (beeps !== false) { cancelBeeps(); scheduleBeeps(); }
}
function seqPress(w) {
  const g = run.gp;
  if (w - g.last < 300) return 'bounce';
  g.last = w;
  const had = g.cue && g.cue.dock;
  g.taps.push(w);
  assign(g);
  const idx = g.asg.a[g.taps.length - 1];
  const what = idx < 0 ? 'stray' : tapCues()[idx].id;
  cueFlash(what === 'stray' ? 'EXTRA TAP IGNORED' : CUES.find(c => c.id === what).short.toUpperCase() + ' ✓', what === 'stray' ? 'hold' : 'info', 700);
  if (g.cue.dock && g.cue.dock !== had) setTimeout(goal3, 20);
  renderFade2();
  return what;
}
/* the dock-end tap: re-weight this plan's routes by how well their READY time fits the tap (one tap's spread and the
   clock's), then re-aim the cast (if it still is 3+ s away and gains 0.2+ points) and the release zones on those
   routes. Bite forecasts then use them too. */
function goal3() {
  const g = run.gp;
  if (!g || !g.cue.dock || run.wall0 === null || run.castTap !== null || run.tapInfo) return;
  const tau3 = (g.cue.dock - run.wall0) / viMs() + 1, base = P(run.plan0);
  const r3 = r3abs() / viMs(), sd = Math.hypot(Math.max(50, clockSd()), g.sdF || 60) / viMs();   // >= 50: its delay is assumed, not learned
  const lik = v => Math.exp(-0.5 * ((tau3 - v.minT - r3) / sd) ** 2);
  const W0 = base.variants.reduce((a, v) => a + v.w, 0) || 1;
  const vars = base.variants.map(v => Object.assign({}, v, { w: v.w * lik(v) }));
  const Wt = vars.reduce((a, v) => a + v.w, 0);
  g.g3 = { tau3, fit: Wt / W0, sdMs: Math.round(sd * viMs()) };
  if (!(Wt / W0 > 1e-3)) { g.g3.off = true; renderFade2(); return; }
  const Q = Object.assign({}, base, { variants: vars.filter(v => v.w > Wt * 1e-6), _final: true });
  const R = routeDef(), A1 = R.axes && R.axes[0], A2 = R.axes && R.axes[1];
  if (A1) {                                                     // which beach timing (wait x 2nd cut) the tap points to
    const mass = ax => {
      const gr = axGroup(R, ax), pl = gr ? LuckyCore.planSet(gr.id, anchor(), route())[0] : null;
      if (!pl || !pl.variants.length) return 0;
      const Wg = pl.variants.reduce((a, v) => a + v.w, 0) || 1;
      return (gr.share || 0) * pl.variants.reduce((a, v) => a + v.w * lik(v), 0) / Wg;
    };
    const combos = [];
    for (const o1 of A1.opts) {
      if (A2 && A2.opts.some(o2 => axGroup(R, { [A1.id]: o1.id, [A2.id]: o2.id })))
        for (const o2 of A2.opts) combos.push({ o1, o2, m: mass({ [A1.id]: o1.id, [A2.id]: o2.id }) });
      else combos.push({ o1, o2: null, m: mass({ [A1.id]: o1.id }) });
    }
    const tot = combos.reduce((a, x) => a + x.m, 0) || 1;
    combos.forEach(x => { x.p = x.m / tot; });
    g.g3.bands = A1.opts.map(o => ({ id: o.id, label: o.label, p: combos.filter(x => x.o1 === o).reduce((a, x) => a + x.p, 0) }));
    if (A2) g.g3.bands2 = A2.opts.map(o => ({ id: o.id, label: o.label, p: combos.filter(x => x.o2 === o).reduce((a, x) => a + x.p, 0) }));
    const top = combos.reduce((a, x) => (x.p > a.p ? x : a), combos[0]);
    if (top && top.p > 0) {                                     // the guess: the likeliest wait, then its likeliest 2nd cut
      const b1 = g.g3.bands.reduce((a, x) => (x.p > a.p ? x : a)), o1 = A1.opts.find(o => o.id === b1.id);
      const row = combos.filter(x => x.o1 === o1 && x.o2), b2 = row.length ? row.reduce((a, x) => (x.p > a.p ? x : a)) : null;
      /* lab check (tests/sim: 1,200 dock taps per route): the wait is right 67-70% (chance 37%); the 2nd cut only 45%
         on dog-beach (chance 43%), 62% on lineup2 (55%) - READY moves with the wait far more than with the 2nd cut. So
         the 2nd cut is shown only when the tap is decisive (>= 70%); on the fade-in start it changes nothing anyway. */
      const p2 = b2 ? b2.p / (b1.p || 1) : null, sure2 = p2 != null && p2 >= 0.7;
      g.g3.guess = { ax: Object.assign({ [A1.id]: b1.id }, sure2 ? { [A2.id]: b2.o2.id } : {}), p1: b1.p, l1: o1.label,
                     p2, l2: b2 ? b2.o2.label : null, sure2 };
    }
  }
  const sig = sigVI(), valOn = (pl, pol, T) => (pol === 'zone' ? (LuckyCore.zoneAt(pl, T, sig) || {}).value : LuckyCore.curve(pl, sig, pol === 'tap' ? 'hold' : pol).P[T]);
  const T0 = run.T, v0 = valOn(Q, run.pol, T0);
  let T = T0, pol = run.pol, p = v0;
  if (L.castT === null) {
    const tMin = Math.max(base.firstT + 29, Math.ceil(tau3) + 180), b = LuckyCore.best(Q, sig, tMin);
    const pols = L.policy !== 'auto' ? [L.policy === 'tap' ? 'hold' : L.policy] : ['zone', 'bite1', 'hold'];
    const bp = pols.reduce((a, q) => (b[q] && b[q].p > b[a].p ? q : a), pols[0]);
    if (b[bp] && b[bp].t >= tMin && b[bp].p > (v0 || 0) + 0.002) { T = b[bp].t; pol = L.policy === 'tap' ? 'tap' : bp; p = b[bp].p; }
  }
  Object.assign(g.g3, { T0, T, moved: T !== T0, p0: v0, p, lik: { tau3, r3, sd } });
  run.plan = Q; run.T = T; run.pol = pol;
  if (run.dw) { run.dw.g3 = g.g3.lik; dwOpen(tau3); }
  run.zone = LuckyCore.zoneAt(Q, T, sig, sig, true);
  if (pol === 'zone' && run.zone) g.g3.p = run.zone.value;
  $('lkT').textContent = fmtS(T); $('lkP').textContent = pct(g.g3.p); renderBiteSplit();
  cancelBeeps(); scheduleBeeps(); renderFade2(); renderPace();
  if (L.personalCast && $('lkPersonalTxt')) $('lkPersonalTxt').innerHTML = personalTxt();
  if (g.g3.guess) cueFlash(`${g.g3.guess.l1.toUpperCase()} ${Math.round(100 * g.g3.guess.p1)}%${g.g3.guess.sure2 ? ' · ' + g.g3.guess.l2.toUpperCase() : ''} ✓`, 'go', 1600);
}
/* the dock-end tap's guess, shown on the L1 preset cards during the attempt (green); your own pick is dashed */
const guessAx = () => (run.wall0 !== null && !run.preview && run.gp && run.gp.g3 && run.gp.g3.guess && !run.gp.g3.off ? run.gp.g3.guess : null);
/* after the bite tap: the dock-end tap vs the READY the bite posterior points to (plan before the dock-end
   re-weighting, so the tap does not grade itself); kept for a later check of the same-delay assumption */
function reflexFrom(post) {
  const g = run.gp;
  if (!g || !g.cue.dock || !post || !post.sc.length || !(post.Z > 1e-4)) return null;
  const Z = post.sc.reduce((a, e) => a + e.w, 0), dl = post.sc.reduce((a, e) => a + e.w * e.d, 0) / Z;
  const mt = post.sc.reduce((a, e) => a + e.w * e.mt, 0) / Z, sdm = Math.sqrt(post.sc.reduce((a, e) => a + e.w * (e.mt - mt) ** 2, 0) / Z);
  const tau3 = (g.cue.dock - run.wall0) / viMs() + 1;
  return { at: Date.now(), route: route(), ms: Math.round((tau3 + dl - mt) * viMs()), sd: Math.round(sdm * viMs()) };
}
function keepTapRec() {                                         // at the end of an attempt: its clock taps vs their cues
  const g = run.gp;
  if (!g || !g.cue) return;
  const ys = {};
  for (const c of CUES) if (c.vi != null && g.cue[c.id] != null) ys[c.id] = g.cue[c.id] - c.vi * viMs();
  const ks = Object.keys(ys);
  if (ks.length < 2) return;
  const mu = ks.reduce((a, k) => a + ys[k], 0) / ks.length;
  for (const k of ks) ys[k] = Math.round(ys[k] - mu);
  const rec = { at: Date.now(), y: ys, aid: run.aid }, strays = g.asg ? g.asg.a.filter(k => k < 0).length : 0;
  if (g.cue.dock != null) rec.d = 1;
  if (strays) rec.s = strays;
  const k = curTs();
  tsPut(k, tsGet(k).concat([rec]).slice(-TS_KEEP));
  g.kept = true;
  setTimeout(() => { if (run.wall0 === null) refresh(); else renderFade2(); }, 0);   // the new spread for the next attempt
}
/* v31.22 BUG FIX (v31.15 - v31.21): in freestyle a Space before the app's own cast time (which is not in play there)
   was still taken as a route tap, so a cast marked earlier than that was not marked. In freestyle the route taps end
   2 s after the expected READY (every cue is at or before the dock end); from then on Space is the cast. */
const tapsEnd = () => (fsOn() ? Math.min(run.T - 90, wakeReady() + 120) : run.T - 90);   // v31.29: the picked dog's READY when there is one (consistency lab F6)
const seqOpen = t => run.gp && run.castTap === null && !run.tapInfo && t < tapsEnd();
function gpTxt() {                                              // this attempt's taps, for the last-attempt line
  const g = run.gp;
  if (!g || !g.cue) return '';
  const sg = v => (v >= 0 ? '+' : '') + Math.round(v);
  let s = 'taps: ' + tapCues().map(c => `${c.short} ${g.cue[c.id] != null ? '✓' : '✗'}`).join(' · ');
  const strays = g.asg ? g.asg.a.filter(k => k < 0).length : 0;
  if (strays) s += ` (${strays} extra ignored)`;
  if (g.asg && g.asg.nClock > 1) s += `; clock from ${g.asg.nClock} taps (±${Math.round(g.sdF)} ms)`;
  if (g.g3 && g.g3.off) s += '; the dock-end tap fit none of the route timings (ignored)';
  else if (g.g3 && g.g3.bands) s += `; dock end: ${g.g3.bands.filter(b => b.p >= 0.05).map(b => b.label + ' ' + Math.round(100 * b.p) + '%').join(', ')}` +
    (g.g3.guess && g.g3.guess.sure2 ? ` (2nd cut ${g.g3.guess.l2.toLowerCase()} ${Math.round(100 * g.g3.guess.p2)}%)` : '') +
    (g.g3.moved ? `, cast moved ${sg((g.g3.T - g.g3.T0) * viMs())} ms` : '');
  return s;
}
function renderFade2() {
  const box = $('lkTapBox');
  if (!box) return;
  if ($('lkAutoTune')) $('lkAutoTune').checked = !!L.autoTune;
  const R = routeDef(), has = (R.anchors || []).some(a => a.id === 'fadein') && (R.anchors || []).some(a => a.id === 'pier' || a.id === 'fadein');
  box.hidden = !has;
  if (!has) return;
  const st = tapStats(), pr = precision(), sd = pr.sd, sg = v => (v >= 0 ? '+' : '') + Math.round(v);
  const nC = clockCues().length, sc = sd / Math.sqrt(Math.max(1, nC));
  const ms = c => (c.vi === 0 ? 'the clock\'s 0' : sg(c.vi * viMs()) + ' ms from the first light'), C_ = id => CUES.find(c => c.id === id);
  const cur = strat().id;
  const st0 = STRATS.find(x => x.id === cur);
  const onePier = anchor() === 'pier' && !pierOnly;               // v31.27 (Thomas): the one-tap dock-end start offers no earlier taps
  let h = (onePier ? `<div class="small" style="margin:0 0 3px"><b>One tap:</b> ${keyName()} the moment Jack stops at the water at the end of the pier (READY). No taps on the way in. (The multi-tap strategies come with the fade-in start.)</div>`
    : `<label class="lkset"><span>Tap strategy</span> <select id="lkStrat">${STRATS.map(x => `<option value="${x.id}" ${cur === x.id ? 'selected' : ''}>${x.label}</option>`).join('')}</select></label>` +
    `<div class="small mut" style="margin:-2px 0 3px">${st0.note}. Tap ${keyName()} at each cue; the plan above is computed for this strategy.</div>`) +
    (cur === 'd' ? '' : `<label class="lkset"><span>Beach cue</span> <select id="lkBeach">${['ctrl', 'fade'].map(id => `<option value="${id}" ${L.beachCue === id ? 'selected' : ''}>${id === 'ctrl' ? 'first control: Jack turns down-right (+1.09 s)' : 'first light of the fade-in (0 s)'}</option>`).join('')}</select></label>` +
      `<div class="small mut" style="margin:-2px 0 3px">${L.beachCue === 'ctrl' ? 'Hold down-right through the fade; tap when Jack turns and walks.' : 'Tap when the black screen starts to brighten.'}${tapCues().some(c => c.id === 'exit') ? ' Ranch exit: tap when Jack stops dead at the exit (−1.16 s).' : ''}${tapCues().some(c => c.id === 'dock') ? ' Dock end: tap when Jack stops at the water.' : ''}</div>`) +
    `<label class="lkset small"><span>Clock-tap precision (one tap's spread): <b>${Math.round(sd)} ms</b>${precTxt(pr)}</span> ` +
      `<span><input type="range" id="lkTapSd" min="15" max="150" step="5" value="${Math.round(L.tapSdAuto ? sd : L.tapSdMs)}" ${L.tapSdAuto ? 'disabled' : ''}> <label><input type="checkbox" id="lkTapSdAuto" ${L.tapSdAuto ? 'checked' : ''}> auto</label></span></label>`;
  const dockOn = tapCues().some(c => c.id === 'dock');
  h += cur === 'd' ? '<div class="small mut">Dock-end start: one tap at READY; the plan uses your timing spread as set. '
    : `<div class="small mut">This strategy: ${nC} clock tap${nC === 1 ? '' : 's'} → clock ±${Math.round(sc)} ms → timing spread used <b>${sigEffMs('fadein')} ms</b> (your ${sigmaMs()} ms timing spread assumes one start tap of ±${START1_MS}). ` +
      (dockOn ? `The dock-end tap re-aims live, read with ±${Math.round(Math.hypot(Math.max(50, sd), sc))} ms (lab simulation on this route: about +1.6 points per attempt). ` : 'No dock-end tap: no live re-aim. ');
  const offs = CUES.filter(c => c.vi != null && c.id !== L.beachCue && st.off[c.id] && st.off[c.id].n).map(c => `${c.short} ${sg(st.off[c.id].raw)} ms (${st.off[c.id].n})`);
  h += `<br><b>Your tap profile</b> (saved in this browser, refined every attempt): ${st.nrec} attempt${st.nrec === 1 ? '' : 's'} with 2+ clock taps` +
    (offs.length ? `; vs your ${C_(L.beachCue).short} tap: ${offs.join(', ')}` : '') + '. ';
  const ds = dockStat();
  if (ds.n >= 5) h += `Dock-end tap vs the READY your bites point to: ${sg(ds.med - r2abs())} ms vs your clock taps (median of ${ds.n}, rough). `;
  h += '</div>' + (cur === 'd' ? '' : tapDataHtml(st, pr));
  box.innerHTML = h;
  wireTapData();
  if ($('lkStrat')) $('lkStrat').onchange = e => setStrategy(e.target.value);
  if ($('lkBeach')) $('lkBeach').onchange = e => setBeachCue(e.target.value);
  $('lkTapSdAuto').onchange = e => { L.tapSdAuto = e.target.checked; if (!L.tapSdAuto) L.tapSdMs = Math.round(sd / 5) * 5; save(); refreshSig(); };
  $('lkTapSd').onchange = e => { L.tapSdMs = +e.target.value; save(); refreshSig(); };
}
function precTxt(pr) {
  if (pr.src === 'manual') return ' (set by hand)';
  if (pr.src === 'own') return ` (auto, from your last ${pr.n} attempts of this strategy)`;
  if (pr.src === 'borrowed') return ` (auto, borrowed from ${pr.n} attempts of the ranch exit + beach cue strategies on this route: one clock tap cannot show its own spread)`;
  return pr.own ? ` (auto: 60 until 5 attempts of this strategy with both clock taps; ${pr.n} so far)`
    : ' (auto: 60; one clock tap cannot show its spread: 5 attempts with the ranch exit + beach cue strategies on this route measure it)';
}
/* the tap data behind the auto precision: this set's attempts, newest first; cull / restore one, clear the set */
const esc = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
const TSTRAT_SHORT = { b: '1 tap: beach cue', eb: '2 taps: ranch exit + beach cue', bd: '2 taps: beach cue + dock end', ebd: '3 taps: ranch exit + beach cue + dock end', d: 'dock end only' };
function tapDataHtml(st, pr) {
  const k = curTs(), all = tsGet(k), ref = L.beachCue, C_ = id => CUES.find(c => c.id === id), sg = v => (v > 0 ? '+' : v < 0 ? '−' : '±') + Math.abs(Math.round(v));
  const own = clockCues().length >= 2, kept = all.filter(r => !r.x), used = new Set(kept.slice(-TS_USE));
  const gapMs0 = (C_(ref).vi - C_('exit').vi) * viMs(), usual = st.off.exit && isFinite(st.off.exit.raw) ? st.off.exit.raw : 0;
  const devs = [...used].filter(r => r.y.exit != null && r.y[ref] != null).map(r => Math.abs(r.y.exit - r.y[ref] - usual));
  const lim = Math.max(100, 3 * 1.4826 * (devs.length >= 3 ? med(devs) : 40));   // 3 robust SDs of the gap (median |deviation|)
  const when = at => { const d = new Date(at), t = d.toTimeString().slice(0, 5); return d.toDateString() === new Date().toDateString() ? t : d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) + ' ' + t; };
  const btns = () => `<div style="margin-top:4px">${all.length ? `<button type="button" id="lkTapSetClear">Clear this set (${all.length})</button> ` : ''}` +
    `${tsKeys().length || dock.length || fade2.length ? '<button type="button" id="lkFade2Forget">Forget all tap data</button>' : ''}</div>`;
  const sum = own ? `${kept.length} attempt${kept.length === 1 ? '' : 's'}${all.length > kept.length ? `, ${all.length - kept.length} culled` : ''}` +
    (isFinite(st.sdAuto) ? ` → ±${Math.round(st.sdAuto)} ms` : '') : 'one clock tap: nothing to measure here';
  let h = `<details class="lkfold" id="lkTapData"${L.tapDataOpen ? ' open' : ''}><summary>Tap data for this strategy (${sum})</summary>` +
    `<div class="small mut">Set: <b>${TSTRAT_SHORT[strat().id]}</b> · beach cue <b>${C_(ref).short}</b> · route <b>${esc(routeDef().label || route())}</b>. ` +
    'Saved in this browser per route, tap strategy and beach cue. ';
  if (!own) {
    h += `This strategy has one clock tap per attempt, so its spread cannot be measured on its own; auto precision ` +
      (pr.src === 'borrowed' ? `borrows ±${Math.round(pr.sd)} ms from your ${pr.n} attempts of the ranch exit + beach cue strategies (same route and beach cue).` : 'uses 60 ms until you have 5 attempts with the ranch exit + beach cue strategies on this route.') + '</div>' + btns() + '</details>';
    return h;
  }
  h += `Each row = one attempt with both clock taps: the gap from your ranch exit tap to your ${C_(ref).short} tap ` +
    `(the game's: ${(gapMs0 / 1000).toFixed(3)} s). Your usual difference (${sg(-usual)} ms, median) is calibrated away; one tap's ` +
    `spread = the rms of "vs usual" ÷ √2 over your last ${TS_USE} kept attempts${isFinite(st.sdAuto) ? '' : ' (auto from 5)'}. ` +
    'A tap far off both cues is already dropped as an extra tap (that attempt is not stored); cull a fumble that got ' +
    `through (it stays listed: restore it any time). ⚠ = more than ${Math.round(lim)} ms off your usual.</div>`;
  if (!all.length) return h + '<div class="small mut">No attempts yet: tap the ranch exit and the beach cue in an attempt.</div>' + btns() + '</details>';
  h += '<div style="max-height:220px;overflow:auto;margin-top:4px"><table class="plan small" id="lkTapDataTbl"><tr><th>#</th><th>when</th><th>gap</th><th>vs game</th><th>vs usual</th><th></th><th></th></tr>';
  all.map((r, i) => [r, i]).reverse().forEach(([r, i]) => {
    const e = r.y.exit != null && r.y[ref] != null ? r.y.exit - r.y[ref] : null;
    const dev = e == null ? null : e - usual, far = dev != null && Math.abs(dev) > lim;
    const note = r.x ? 'culled' : !used.has(r) ? 'older: not used' : far ? '⚠ far off' : r.m ? 'carried over' : r.s ? `${r.s} extra tap${r.s > 1 ? 's' : ''} ignored` : '';
    h += `<tr style="${r.x || !used.has(r) ? 'opacity:.5' : ''}"><td>${i + 1}</td><td>${when(r.at)}</td>` +
      (e == null ? '<td colspan="3">—</td>' : `<td>${((gapMs0 - e) / 1000).toFixed(3)} s</td><td>${sg(-e)} ms</td><td>${sg(-dev)} ms</td>`) +
      `<td>${note}</td><td><button type="button" data-tsat="${r.at}" data-tsi="${i}">${r.x ? 'restore' : 'cull'}</button></td></tr>`;
  });
  h += '</table></div>';
  return h + btns() + '</details>';
}
function tapDataChanged() { if (run.wall0 !== null) renderFade2(); else refresh(); }   // plan caches are keyed by the spread
function cullRec(i, on) {                                      // on: true = cull, false = restore, undefined = toggle
  const k = curTs(), a = tsGet(k).slice(), r = a[i];
  if (!r) return;
  a[i] = Object.assign({}, r);
  if (on === undefined ? !r.x : on) a[i].x = 1; else delete a[i].x;
  tsPut(k, a); tapDataChanged();
}
function clearSet() { tsPut(curTs(), []); tapDataChanged(); }
function wireTapData() {
  const d = $('lkTapData');
  if (!d) return;
  d.addEventListener('toggle', () => { if (L.tapDataOpen !== d.open) { L.tapDataOpen = d.open; save(); } });
  d.querySelectorAll('button[data-tsi]').forEach(b => { b.onclick = () => cullRec(+b.dataset.tsi); });
  if ($('lkTapSetClear')) $('lkTapSetClear').onclick = () => {
    if (confirm(`Clear the tap data of this set (${TSTRAT_SHORT[strat().id]}, beach cue ${CUES.find(c => c.id === L.beachCue).short}, ${routeDef().label || route()})? Other sets are kept.`)) clearSet();
  };
  if ($('lkFade2Forget')) $('lkFade2Forget').onclick = () => {
    if (confirm('Forget ALL tap data (every route, strategy and beach cue; exit/fade-in pairs; dock-end records)?')) {
      for (const k of tsKeys()) tsPut(k, []);
      fade2 = []; dock = [];
      store.set('hm64v29_lucky_fade2', fade2); store.set('hm64v29_lucky_dock', dock); tapDataChanged();
    }
  };
}
/* the strategy picks the start: dock end only = the dock-end start, any other = the fade-in start */
function setStrategy(id) {
  if (id === 'd') { setSelection(null, 'pier'); return; }
  L.tapStrategy = id; save();
  if (anchor() !== 'fadein') { setSelection(null, 'fadein'); return; }
  refreshSig();
}
function setBeachCue(id) {
  L.beachCue = id; save(); updateProfile();
  if (anchor() !== 'fadein') { setSelection(null, 'fadein'); return; }
  refreshSig();
}
function refreshSig() { bestCache = null; ccache.clear(); paceCache.clear(); startCache.clear(); L.castT = null; refresh(); }
function scheduleBeeps() {
  if (fsOn()) { if (run.plan.k) beepAt(run.wall0 + 30, 660, 0.05, 0.12); return; }   // v31.14 freestyle: no cast countdown - the cast is the player's
  const castWall = run.wall0 + (run.T - 1) * viMs() + cueCorr();
  [-1500, -1000, -500].forEach(d => beepAt(castWall + d, 440, 0.06));
  beepAt(castWall, 880, 0.14);
  if (run.plan.k) beepAt(run.wall0 + 30, 660, 0.05, 0.12);
  if (L.zoneBeeps && run.pol === 'bite1') for (const [a] of nutBites()) {     // get-ready ticks before each Nut-bite cluster
    const wa = run.wall0 + (a - 1) * viMs();
    if (wa > castWall + 500) { beepAt(wa - 600, 1000, 0.035, 0.1); beepAt(wa - 300, 1000, 0.035, 0.1); }
  }
  if (L.zoneBeeps && run.pol === 'zone' && run.zone) {
    for (const [a, b] of run.zone.zones) {
      const wa = run.wall0 + (a - 1) * viMs(), wb = run.wall0 + (b - 1) * viMs();
      if (wa < castWall) continue;
      beepAt(wa, 1200, 0.05, 0.15); beepAt(wa + 70, 1500, 0.05, 0.15); beepAt(wb, 700, 0.06, 0.1);
    }
  }
}
function stop(clearResult) {
  const hadGuess = !!guessAx(), wasLive = run.wall0 !== null;
  if (run.gp && !run.gp.kept) keepTapRec(); const dogSaved = saveDogLine(); saveTap(null); if (dogSaved && !(run.tapInfo && run.tapInfo.saved)) updateProfile(); run.wall0 = null; cancelBeeps(); if (clearResult) run.result = null;
  renderAttempts();                                             // v30.8: an attempt that was not logged still shows its stored taps
  if (hadGuess) renderPace();                                   // the cards go back to your own pick
  if (wasLive && pierOnly) pierRestore();                       // v30.2: pier only lasts one attempt
}
run.castTap = null; run.castErrMs = null; run.last = null;
function preview() {
  if (run.bite) biteStop();
  stop(true); run.tapInfo = null;
  refresh();
  const z = run.zone;
  if (!z) return;
  // a lucky attempt: draw a winning scenario under the current plan and policy
  const wins = z.sc.filter(x => (run.pol === 'hold' ? x.n2 : run.pol === 'bite1' ? x.n1 : (inZone(x.t1) ? x.n1 : x.n2)));
  if (!wins.length) { run.preview = null; return; }
  let r = Math.random() * wins.reduce((a, x) => a + x.w, 0), pick = wins[0];
  for (const x of wins) { r -= x.w; if (r <= 0) { pick = x; break; } }
  const release = run.pol === 'bite1' || (run.pol === 'zone' && inZone(pick.t1));
  run.preview = { cast: pick.cast, bite1: pick.t1, bite2: pick.t2, release1: release };
  run.wall0 = now() - Math.max(0, (Math.min(run.T, pick.cast) - 90) * viMs());
}
/* v30.2: when an unattended stopwatch stops by itself. It was 55 s (TMAX + 10 s) for every plan, which cut an attempt
   off 12 s after a 43 s cast: later bites (the tables follow every bite to 90 s after READY) never got their forecast.
   Now: to the end of the bite data of this plan (or the latest second bite of the tables) + 10 s. */
function runEnd() {
  const pl = run.plan0 || run.plan, T = run.T || 0;
  if (!pl) return LuckyCore.TMAX + 600;
  if (pl._end == null) {
    let mo = 0; for (const v of pl.variants) if (-v.o > mo) mo = -v.o;
    pl._end = pl.hz ? pl.hz + mo : 0;
  }
  return Math.max(LuckyCore.TMAX, T + G_CAST + (pl.maxBite || 1200), pl._end, fsOn() ? ((DCAST && DCAST.cast_until) || 5400) + 3000 + 600 : 0) + 600;   // freestyle: casts to the end of the cast data (v31.26: 120 s), their bites 50 s more
}
/* v30.2: which bite the Nut is expected on for the cast in use (policy in use): {by: {1: p, 2: p, 3: p...}, top, txt}.
   Bites 1-2 add up to the odds shown; bites 3+ are extra chances that only count when the lamp says KEEP HOLDING at
   the bite before (the every-bite forecast after your bite taps). */
const ORD = n => (n === 1 ? '1st' : n === 2 ? '2nd' : n === 3 ? '3rd' : n + 'th');
function biteSplit() {
  const z = run.zone, pol = run.pol;
  if (!z || !z.sc || !z.byBite) return null;
  if (z._sp && z._sp.pol === pol) return z._sp;
  const by = {};
  if (pol === 'zone') { by[1] = z.byBite[1]; by[2] = z.byBite[2]; for (const m in z.byBite.later) by[m] = z.byBite.later[m]; }
  else for (const e of z.sc) {
    const w = e.w / z.W;
    if (pol === 'bite1') { by[1] = (by[1] || 0) + w * e.n1; continue; }
    by[2] = (by[2] || 0) + w * e.n2;
    if (!e.n2 && e.bx) for (let q = 0; q < e.bx.length; q++) if (e.bx[q] < 0) { by[q + 3] = (by[q + 3] || 0) + w; break; }
  }
  const ks = Object.keys(by).map(Number).filter(m => by[m] >= 0.0005).sort((a, b) => a - b);
  const top = ks.reduce((a, m) => (by[m] > (by[a] || 0) ? m : a), ks[0] || 1);
  const short = ks.slice().sort((a, b) => by[b] - by[a]).map(m => `bite ${m} ${pct(by[m])}`).join(' · ');
  z._sp = { pol, by, ks, top, short, extra: ks.some(m => m >= 3) };
  return z._sp;
}
const inZone = t => run.zone && run.zone.zones.some(([a, b]) => t >= a && t < b);
const held = () => !!(run.tapInfo && run.tapInfo.holdish);
/* where to release now: bite-1 windows, or once bite 1 was held, the bite-2 Nut moments (+ the 20-VI window) */
const inRelease = t => (held() ? !run.tapInfo.dud && !run.tapInfo.released && run.tapInfo.spans2.some(([a, b]) => t >= a && t < b + WINDOW_VI) : inZone(t));
/* v30: inside a hold-on window of the next bite (a later bite is the better Nut): keep B down and tap that bite */
const inHold = t => held() && !run.tapInfo.released && (run.tapInfo.holds2 || []).some(([a, b]) => t >= a && t < b + WINDOW_VI);
const nextBite = () => (run.tapInfo ? run.tapInfo.taus.length + 1 : 1);
/* stopwatch spans where a bite-1 Nut can come after this cast (bins with >= 25% of the peak bite-1 Nut density) */
/* ---------------------------------------------------------------- visual cues (v29.10, they replace the beeps)
   One lamp at the top of L3 (+ a glow around the screen edge, for the corner of your eye while you watch the TV), at the
   moments the beeps had. Countdown: GET READY and a bar filling to the target line from 2 s out, amber pulses 3 / 2 / 1 at
   1.5 / 1.0 / 0.5 s (the old lead beeps: press on the rhythm, not as a reaction), green CAST at the cue. After the
   cast: green = release on a bite now (release window, Nut-bite moment, bite-2 Nut moment; bar = time left), amber =
   one opens within 1.5 s (bar fills to it, two blinks 0.6 / 0.3 s before, like the old ticks), yellow = hold, red =
   DUD. Short flashes confirm taps. Sound is optional (Settings). */
const PULSE_MS = 110, CAST_HOLD_MS = 350, COUNT_MS = 2000, LEAD_MS = 1500, WIN_TAIL = 10;
const CUECOL = { pulse: '#ffd28a', cast: '#5fd38d', nut: '#5fd38d', go: '#5fd38d', ready: '#f0b35a', hold: '#e7c14a', bad: '#ef6f6f', wh: '#b48cff', info: '#6fb7ff', count: '#f0b35a', idle: '#8ea3b2' };
function cueFlash(text, kind, ms) { run.flash = { text, kind: kind || 'info', until: now() + (ms || 800) }; }
const castCueT = () => run.T + (run.practice ? 0 : cueCorr() / viMs());   // v30.22: the one cast indicator (lamp, histogram line, countdown texts)
function castAim() {                                            // the bite this cast most likely catches the Nut on
  if (run.practice || run.bite) return null;
  const bs = biteSplit(); if (!bs || !bs.top) return null;
  const n = bs.top, ord = ORD(n).toUpperCase();
  return { n, big: n === 1 ? '1st BITE' : `HOLD · ${ord} BITE`, sub: n === 1 ? 'going for the 1st bite: release it' : `going for the ${ORD(n)} bite: hold through ${n === 2 ? 'bite 1' : 'the bites before'} and tap`,
           chip: n === 1 ? '1st bite · release' : `${ORD(n)} bite · hold` };
}
function countdown(dt, bar, sub, num) {                         // dt: ms to the CAST cue
  if (dt <= 0) return { kind: 'cast', big: 'CAST', sub, bar: bar ? 1 : null, glow: 1 };
  if (dt > COUNT_MS) return { kind: 'info', big: num ? `CAST IN ${(dt / 1000).toFixed(dt < 10000 ? 1 : 0)} s` : 'GET READY', sub };
  const pulse = [1500, 1000, 500].some(d => dt <= d && dt > d - PULSE_MS);
  return { kind: pulse ? 'pulse' : 'count', big: dt > 1500 ? 'GET READY' : dt > 1000 ? '3' : dt > 500 ? '2' : '1', sub,
           bar: bar ? Math.max(0, 1 - dt / COUNT_MS) : null, glow: pulse ? 0.9 : 0 };
}
function windowsCue(t, spans, tail, inC, out) {                 // release moments: inside = green, within 1.5 s = amber lead
  const vi = viMs(), cur = spans.find(([a, b]) => t >= a && t < b + tail);
  if (cur) {
    const left = Math.max(0, (cur[1] + tail - t) * vi), len = (cur[1] + tail - cur[0]) * vi;
    return { kind: inC.kind, big: inC.big, sub: `${inC.sub} · ${(left / 1000).toFixed(1)} s left`, bar: left / len, glow: (t - cur[0]) * vi < 200 ? 1 : inC.glow };
  }
  const nx = spans.find(([a]) => a > t);
  if (nx && (nx[0] - t) * vi <= LEAD_MS) {
    const dt = (nx[0] - t) * vi, blink = [600, 300].some(d => dt <= d && dt > d - PULSE_MS);
    return { kind: blink ? 'pulse' : 'ready', big: `${inC.short} IN ${(dt / 1000).toFixed(1)} s`, sub: out.sub, bar: 1 - dt / LEAD_MS, glow: blink ? 0.8 : 0 };
  }
  return Object.assign({}, out, nx ? { sub: `${out.sub} · next ${inC.short.toLowerCase()} in ${((nx[0] - t) * vi / 1000).toFixed(1)} s` } : {});
}
function cueAt(t, idleMsg) {
  const live = run.wall0 !== null, vi = viMs(), fl = run.flash && run.flash.until > now() ? run.flash : null;
  if (run.bite) return biteCue();
  const pr = run.practice;
  if (pr) {
    if (pr.state === 'armed') return countdown(pr.cue - now(), L.pracLine, pr.combo ? `press ${keyName()} on CAST and HOLD` : `press ${keyName()} on CAST`, L.pracLine);
    if (pr.state === 'hold') return { kind: 'idle', big: 'HOLDING — LET GO AT THE BITE', sub: (pr.last && pr.last.e !== null ? `cast ${msTxt(pr.last.e)} · ` : '') + 'watch Jack, not this lamp' };
    if (pr.state === 'rdone' && pr.rel) return { kind: pr.rel.k === 'ok' ? 'go' : 'bad', big: comboTxt(pr).toUpperCase(), sub: pr.rel.k === 'ok' ? `${Math.round(bpWin() - pr.rel.r)} ms to spare in the ${Math.round(bpWin())} ms window` : pr.rel.k === 'late' ? 'the bite was gone' : pr.rel.k === 'early' ? 'no bite yet' : `still holding ${(BP.miss / 1000).toFixed(0)} s after the bite` };
    const r = pr.last;
    if (r && pr.state === 'done') return r.e === null ? { kind: 'bad', big: 'MISSED', sub: 'no press within 0.6 s of CAST' }
      : { kind: Math.abs(r.e) <= viMs() ? 'go' : Math.abs(r.e) <= 50 ? 'ready' : 'hold', big: msTxt(r.e), sub: practiceMsg(t)[0] };
    return { kind: 'idle', big: 'PRACTICE', sub: practiceMsg(t)[0] };
  }
  if (!live) {
    if (fl) return { kind: fl.kind, big: fl.text, sub: idleMsg };
    if (run.result === 'nut') return { kind: 'nut', big: 'POWER NUT!', sub: 'logged' };
    return { kind: 'idle', big: run.result === 'miss' ? 'LOGGED' : 'READY', sub: idleMsg };
  }
  if (run.preview) return { kind: 'info', big: 'PREVIEW', sub: idleMsg };
  const dt = (run.T + cueCorr() / vi - t) * vi;                 // ms to the CAST cue (cast-cue correction included)
  if (dt > -CAST_HOLD_MS && dt <= COUNT_MS) return countdown(dt, true, (dt > 0 ? 'press B on CAST' : 'B now') + (L.castTap ? ` · tap ${keyName()} with it` : ''), true);
  if (fl) return { kind: fl.kind, big: fl.text, sub: '' };
  if (dt > 0) {
    if (run.plan.k && t < run.plan.whistleEnd + 6) return { kind: 'wh', big: 'MASH C-RIGHT', sub: `stop at whistle #${run.plan.k}` };
    const tr = t - R0();
    { const wk = wakeNow(t); if (wk) return { kind: 'bad', big: 'WAKE JACK · STICK DOWN-RIGHT', sub: `he lies down in ${wk.left.toFixed(1)} s · one push of the stick (south-east) is enough`, glow: 0.6 }; }
    const sq = seqMsg(t), dm = dwLamp(t);
    const bs = biteSplit();
    return countdown(dt, false, dm || (sq ? sq[0] : `cast ${fmtS(run.T)} after ${startName()}${bs && bs.ks.length ? ' · Nut: ' + bs.short : ''}`), true);
  }
  const ti = run.tapInfo;
  if (ti && ti.holdish) {
    const nb = ti.taus.length + 1, later = Math.max(0, (ti.pAny || 0) - (ti.pNut || 0));
    if (ti.released) { const p = ti.pb[ti.released - 1]; return { kind: p >= 0.8 ? 'go' : 'info', big: `BITE ${ti.released} LOGGED`, sub: `${verdict(p)} · H Nut · M fish · E empty` }; }
    if (!ti.fit) return { kind: 'hold', big: `RELEASE AT BITE ${nb}`, sub: `bite ${nb - 1} fits no dog line` + (ti.nofit && ti.nofit.k === 'none' ? ' · off the tables' : '') };
    if (ti.dud) return { kind: 'bad', big: 'DUD — RESET', sub: `${nb > 2 ? 'no later bite' : 'bite 2'} can be the Nut (${pct(ti.pAny)}) · M` + (ld => (ld && (ld.side === 'early' || ld.side === 'late') ? ` · cast too ${ld.side} (${pct(ld[ld.side])})` : ''))(landing(ti)), glow: Math.floor(now() / 300) % 2 ? 0.6 : 0.2 };
    if (inHold(t)) return { kind: 'wh', big: `BITE ${nb}: KEEP HOLDING`, sub: `tap ${keyName()} at it · the Nut is on a later bite (${pct(later)})`, glow: 0.4 };
    return windowsCue(t, ti.spans2, WINDOW_VI, { kind: 'nut', big: `BITE ${nb} = NUT: RELEASE`, sub: `Nut ${pct(ti.pNut)}`, short: 'NUT MOMENT', glow: 0.6 },
                      { kind: 'hold', big: `HOLD → BITE ${nb}`, sub: `Nut ${pct(ti.pNut)} on bite ${nb}${later >= 0.005 ? ` · ${pct(later)} on a later one` : ''} · tap ${keyName()} at it` });
  }
  if (ti) return { kind: 'info', big: 'BITE LOGGED', sub: `${verdict(ti.p1)} · H Nut · M fish · E empty` };
  if (run.pol === 'zone') { const bs = biteSplit(), p1 = bs && bs.by[1] ? ` · Nut on bite 1 (${pct(bs.by[1])})` : '', p2 = bs && bs.by[2] ? ` · Nut on bite 2 (${pct(bs.by[2])})` : '';
    return windowsCue(t, run.zone ? run.zone.zones : [], 0, { kind: 'go', big: 'RELEASE ON A BITE', sub: 'release window' + p1, short: 'WINDOW', glow: 0.45 },
                                            { kind: 'hold', big: 'HOLD · TAP THE BITE', sub: `a bite now: keep holding B, tap ${keyName()}${p2}` }); }
  if (run.pol === 'bite1') return windowsCue(t, nutBites(), WIN_TAIL, { kind: 'nut', big: 'NUT BITE: RELEASE', sub: 'a Nut bite can come now', short: 'NUT MOMENT', glow: 0.6 },
                                             { kind: 'go', big: 'RELEASE AT THE BITE', sub: `tap ${keyName()} at it` });
  return { kind: 'hold', big: 'HOLD BITE 1', sub: `tap ${keyName()} at the bite · release bite 2` };
}
let cueLast = '';
function renderCue(t, idleMsg) {
  const el = $('lkCue');
  if (!el) return;
  let c = cueAt(t, idleMsg) || { kind: 'idle', big: '—', sub: '' };
  if (!(run.flash && run.flash.until > now())) { const fc = fsCue(t); if (fc) c = fc; const ex = exactCue(t); if (ex) c = ex; }   // v31.3: the frame is known -> the exact call; v31.14: freestyle
  const key = c.kind + '|' + c.big + '|' + (c.sub || '');
  /* v30.17 (Thomas, 2026-11-19): at the cast it must be plain which bite this cast goes for */
  const aim = fsOn() ? null : castAim();
  if (aim && (c.kind === 'cast' || /^CAST IN|^GET READY|^[123]$/.test(c.big))) c = Object.assign({}, c, { big: c.kind === 'cast' ? `CAST → ${aim.big}` : c.big, sub: `${aim.sub}${c.sub ? ' · ' + c.sub : ''}` });
  const key2 = key + '|' + (aim ? aim.n : '');
  if (key2 !== cueLast) { el.className = 'lkcue k-' + c.kind; $('lkCueBig').textContent = c.big; $('lkCueSub').textContent = c.sub || ''; cueLast = key2; }
  const ch = $('lkAim');
  if (ch) { const h = aim && (run.wall0 !== null || run.practice || true) ? aim.chip : ''; if (ch.dataset.h !== h) { ch.dataset.h = h; ch.textContent = h; ch.style.color = aim ? BITECOL[Math.min(3, aim.n)] : ''; ch.style.borderColor = aim ? BITECOL[Math.min(3, aim.n)] : ''; ch.hidden = !h; } }
  const bb = $('lkCueBarBox'), on = c.bar != null;
  if (bb.hidden === on) bb.hidden = !on;
  if (on) $('lkCueBar').style.width = (100 * Math.max(0, Math.min(1, c.bar))).toFixed(1) + '%';
  /* v30.14 (Thomas, 2026-11-19): the lamp lives around the whole screen again - while an attempt (or practice) runs the
     edge carries the lamp's colour all the time (faint), swells through the countdown to the cast and flashes on the cues;
     the lamp box itself is only a slim strip now. */
  let gv = c.glow || 0;
  if ((run.wall0 !== null || run.practice) && c.kind !== 'idle') gv = Math.max(gv, 0.18, c.bar != null && /^CAST IN/.test(c.big) ? 0.18 + 0.55 * Math.max(0, Math.min(1, c.bar)) : 0);
  glowSet(L.cueGlow ? gv : 0, CUECOL[c.kind] || '#ffffff');
  { const op = c.pulse && L.cueGlow ? (0.5 + 0.5 * (c.glow || 0)).toFixed(2) : ''; if (el.style.opacity !== op) el.style.opacity = op; }   // v31.24: the lamp strip pulses with the edge
  run.cueNow = c;
}
let glowLast = '';
function glowSet(g, col) {
  const gl = $('cueGlow');
  if (!gl) return;
  const v = g > 0 ? `inset 0 0 0 ${Math.round(16 * g)}px ${col}, inset 0 0 ${Math.round(150 * g)}px ${col}` : 'none';
  if (v !== glowLast) { gl.style.boxShadow = v; glowLast = v; }
}
function nutBites() {
  const z = run.zone; if (!z) return [];
  let m = 0; for (const v of z.d1n) m = Math.max(m, v);
  const out = [];
  for (let i = 0; i < z.d1n.length; i++) {
    if (!(z.d1n[i] >= 0.25 * m && m > 0)) continue;
    const a = i * z.binVI, b = (i + 1) * z.binVI;
    if (out.length && a - out[out.length - 1][1] <= 30) out[out.length - 1][1] = b; else out.push([a, b]);   // < 0.5 s apart: one
  }
  return out;
}

/* ---------------------------------------------------------------- angler (original stick figure; own frames optional) */
const DIRV = { E: [1, 0], SE: [0.82, 0.57] };
function drawAngler(g, W, H, pose, u, dir, info) {
  const s = W / 180, [dx, dy] = DIRV[dir] || DIRV.SE;
  g.clearRect(0, 0, W, H);
  // water and dock
  g.fillStyle = '#0e3550'; g.fillRect(0, 0, W, H);
  g.strokeStyle = '#2b6f9a'; g.lineWidth = 1.5 * s;
  for (let i = 0; i < 7; i++) { const y = (20 + i * 24) * s, ph = (now() / 600 + i) % 1; g.beginPath(); for (let x = 0; x <= W; x += 6 * s) g.lineTo(x, y + Math.sin(x / (14 * s) + ph * 6.28) * 2 * s); g.stroke(); }
  g.fillStyle = '#7a5532';
  if (dir === 'E') g.fillRect(0, 110 * s, 70 * s, 70 * s); else { g.beginPath(); g.moveTo(0, 60 * s); g.lineTo(70 * s, 95 * s); g.lineTo(55 * s, 180 * s); g.lineTo(0, 180 * s); g.closePath(); g.fill(); }
  g.strokeStyle = '#5c3e22'; g.lineWidth = 1 * s;
  for (let i = 0; i < 6; i++) { g.beginPath(); g.moveTo(0, (115 + i * 12) * s); g.lineTo(65 * s, (115 + i * 12) * s); g.stroke(); }
  const img = customSprites[pose + '_' + dir];
  const fx = 42 * s, fy = 118 * s;                              // feet
  const bob = [fx + dx * 95 * s, fy + dy * 50 * s - 6 * s];      // bobber rest point
  if (img) {
    const im = drawAngler.cache[img] || (drawAngler.cache[img] = Object.assign(new Image(), { src: img }));
    if (im.complete) { g.imageSmoothingEnabled = false; g.drawImage(im, fx - 40 * s, fy - 80 * s, 80 * s, 80 * s); }
  } else {
    g.strokeStyle = '#f2e6d0'; g.fillStyle = '#f2e6d0'; g.lineWidth = 3 * s; g.lineCap = 'round';
    const hip = [fx, fy - 30 * s], neck = [fx + dx * 2 * s, fy - 58 * s], head = [neck[0] + dx * 2 * s, neck[1] - 10 * s];
    const L2 = (a, b) => { g.beginPath(); g.moveTo(a[0], a[1]); g.lineTo(b[0], b[1]); g.stroke(); };
    L2([fx - 7 * s, fy], hip); L2([fx + 7 * s, fy], hip); L2(hip, neck);
    g.beginPath(); g.arc(head[0], head[1], 8 * s, 0, 6.283); g.fill();
    g.fillStyle = '#3d8fd0'; g.beginPath(); g.arc(head[0], head[1] - 4 * s, 8.5 * s, Math.PI, 0); g.fill();   // generic bucket hat
    const sh = [neck[0], neck[1] + 6 * s];
    // rod angle (radians above the facing direction); hands at the shoulder front
    let ang = 0.9, hand = [sh[0] + dx * 12 * s, sh[1] + 10 * s], line = null, note = false, nut = false, bang = false;
    if (pose === 'whistle') { hand = [head[0] + dx * 7 * s, head[1] + 3 * s]; note = true; ang = 1.35; }
    else if (pose === 'cast') { ang = 2.2 - 1.9 * u; if (u > 0.55) line = 'fly'; }
    else if (pose === 'wait') { ang = 0.35; line = 'water'; }
    else if (pose === 'zone') { ang = 0.45; line = 'water'; }
    else if (pose === 'bite') { ang = 0.25 + 0.5 * u; line = 'bite'; bang = true; }
    else if (pose === 'reel') { ang = 0.8 + 0.6 * u; line = u < 0.7 ? 'tight' : null; }
    else if (pose === 'catch') { ang = 1.25; nut = true; }
    else if (pose === 'eat') { ang = 1.25; nut = u < 1; }
    L2(sh, hand);
    const toMouth = pose === 'eat' ? Math.min(1, u * 2) : 0;
    const hand2 = nut ? [sh[0] + dx * (18 - 10 * toMouth) * s, sh[1] - (4 + 10 * toMouth) * s] : [hand[0] - dx * 3 * s, hand[1] + 6 * s];
    L2(sh, hand2);
    const rl = 62 * s, tip = [hand[0] + dx * Math.cos(ang) * rl, hand[1] + dy * Math.cos(ang) * rl * 0.6 - Math.sin(ang) * rl];
    g.strokeStyle = '#c9a36b'; g.lineWidth = 2 * s; L2(hand, tip);
    g.strokeStyle = '#dce6ec99'; g.lineWidth = 1 * s;
    if (line) {
      let b = bob.slice();
      if (line === 'fly') b = [tip[0] + (bob[0] - tip[0]) * (u - 0.55) / 0.45, tip[1] + (bob[1] - tip[1]) * (u - 0.55) / 0.45 - 20 * s * Math.sin(Math.PI * (u - 0.55) / 0.45)];
      if (line === 'water' || line === 'zone') b[1] += Math.sin(now() / 260) * 1.5 * s;
      if (line === 'bite') b[1] += 5 * s;
      g.beginPath(); g.moveTo(tip[0], tip[1]);
      if (line === 'tight') g.lineTo(b[0], b[1]); else g.quadraticCurveTo((tip[0] + b[0]) / 2, Math.max(tip[1], b[1]) + 10 * s, b[0], b[1]);
      g.stroke();
      if (line !== 'bite') { g.fillStyle = '#ef6f6f'; g.beginPath(); g.arc(b[0], b[1], 3.5 * s, 0, 6.283); g.fill(); }
      if (line === 'bite' || line === 'tight') { g.strokeStyle = '#ffffffaa'; g.beginPath(); g.arc(b[0], b[1] + 2 * s, 7 * s, 0, 6.283); g.stroke(); }
    }
    if (pose === 'zone') { g.fillStyle = '#5fd38d'; g.font = `bold ${12 * s}px system-ui`; g.fillText('release on a bite', 60 * s, 18 * s); }
    if (bang) { g.fillStyle = '#ffd28a'; g.font = `bold ${22 * s}px system-ui`; g.fillText('!', head[0] - 3 * s, head[1] - 16 * s); }
    if (note) { g.fillStyle = '#b48cff'; g.font = `${16 * s}px system-ui`; const ph = (now() / 400) % 1; g.fillText('♪', head[0] + dx * 14 * s + 6 * s, head[1] - 8 * s - ph * 14 * s); g.fillText('♫', head[0] + dx * 22 * s + 10 * s, head[1] - 2 * s - ((ph + 0.5) % 1) * 14 * s); }
    if (nut) drawNut(g, hand2[0] + dx * 6 * s, hand2[1] - 6 * s, (pose === 'eat' ? 9 * (1 - 0.6 * u) : 9) * s, pose !== 'eat');
    if (pose === 'eat' && u >= 1) { g.fillStyle = '#ffd28a'; g.font = `bold ${13 * s}px system-ui`; g.fillText('+ stamina', head[0] + 10 * s, head[1] - 14 * s); }
  }
  if (info) { g.fillStyle = '#dce6ec'; g.font = `${11 * s}px ui-monospace,monospace`; g.fillText(info, 6 * s, H - 6 * s); }
}
drawAngler.cache = {};
function drawNut(g, x, y, r, sparkle) {
  const gr = g.createRadialGradient(x - r * 0.3, y - r * 0.3, r * 0.2, x, y, r);
  gr.addColorStop(0, '#ffe39a'); gr.addColorStop(1, '#b0701c');
  g.fillStyle = gr; g.beginPath(); g.ellipse(x, y, r * 0.85, r, 0, 0, 6.283); g.fill();
  g.strokeStyle = '#7a4a10'; g.lineWidth = Math.max(1, r / 6); g.beginPath(); g.moveTo(x, y - r); g.lineTo(x, y + r); g.stroke();
  if (sparkle) { const ph = (now() / 300) % 1; g.fillStyle = `rgba(255,255,255,${0.4 + 0.6 * Math.abs(Math.sin(ph * 3.14))})`; star(g, x + r, y - r, r * 0.6); }
}
function star(g, x, y, r) { g.beginPath(); for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4, rr = i % 2 ? r * 0.35 : r; g.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr); } g.closePath(); g.fill(); }

/* Fishing timeline from the game (player.c handleFishingRodAnimation; measured in the lab, same for SE and E):
   B press -> cast animation -> bobber spawns with the PLOP sound 36 VI later (phase 2, waiting).
   Bite -> rod-pull animation for 20 VI (the release window). Held through -> re-cast, plop again 24 VI after the bite.
   Released -> lose-fish/reel animation from bite+20 to bite+54 -> catch at bite+54: the Power Nut is held up for 60 VI,
   then eaten (startAction(EATING); item gone at bite+138, done at bite+250). A fish is simply held at bite+54. */
const G_CAST = 36, G_PULL = 20, G_RECAST = 24, G_CATCH = 54, G_SHOW = 60, G_EATEN = 138, G_DONE = 250;
/* ---------------------------------------------------------------- Jack (Thomas's catalog frames, D.jack) */
const JACK = (Core.data && Core.data.jack && Core.data.jack.facings) ? Core.data.jack : null;
const jackImgs = new Map();
function jimg(src) { let im = jackImgs.get(src); if (!im) { im = new Image(); im.src = src; jackImgs.set(src, im); } return im; }
function frameOf(a, e) {                                         // frame index after e ticks (1 tick = 1 VI at the dock)
  const tot = a.ticks.reduce((x, y) => x + y, 0) || 1;
  let k = Math.max(0, Math.floor(e || 0));
  if (a.loop) k %= tot; else if (k >= tot) return a.frames.length - 1;
  for (let i = 0; i < a.ticks.length; i++) { if (k < a.ticks[i]) return i; k -= a.ticks[i]; }
  return a.frames.length - 1;
}
/* what the console shows at stopwatch VI t, on the game's fishing timeline (see G_* above) */
function jackState(t) {
  const T = run.T, plan = run.plan;
  if (run.result === 'nut' && now() - run.resultAt < 4800) {
    const e = (now() - run.resultAt) / viMs();
    return e < 62 ? { anim: 'hold', nut: true, info: 'Power Nut!' } : e < 196 ? { anim: 'eat', e: e - 62, info: 'eats the Power Nut' } : { anim: 'idle', info: '+15 max stamina' };
  }
  if (run.wall0 === null) return { anim: 'idle', info: run.result === 'miss' ? 'reset and go again' : 'waiting for the start' };
  if (plan.k && t < plan.whistleEnd + 6) return { anim: 'idle', notes: true, info: 'mash C-right' };
  if (t < T + 4) return { anim: 'idle', info: t < castCueT() ? `cast in ${((castCueT() - t) * viMs() / 1000).toFixed(1)} s` : 'cast!' };
  if (t < T + G_CAST) return { anim: 'cast', e: t - T - 4, info: 'cast!' };
  const pv = run.preview;
  if (pv) {
    const b1 = pv.bite1, rel = pv.release1 ? pv.bite1 : pv.bite2;
    if (!pv.release1) {
      if (t >= b1 && t < b1 + G_PULL) return { anim: 'bite', e: t - b1, float: 'floatBite', ft: t - b1, info: 'bite 1: HOLD B' };
      if (t >= b1 + G_PULL && t < b1 + G_RECAST) return { anim: 'wait', info: 're-cast' };
      if (t >= b1 + G_RECAST && t < rel) return { anim: 'wait', float: 'float', ft: t - b1 - G_RECAST, info: 'waiting for bite 2' };
    }
    if (t >= rel && t < rel + G_PULL) return { anim: 'bite', e: t - rel, float: 'floatBite', ft: t - rel, info: 'bite: RELEASE B' };
    if (t >= rel + G_PULL && t < rel + G_CATCH + 2) return { anim: 'land', e: t - rel - G_PULL, info: 'reeling in…' };
    if (t >= rel + G_CATCH + 2 && t < rel + 118) return { anim: 'hold', nut: true, info: 'Power Nut!' };
    if (t >= rel + 118 && t < rel + 252) return { anim: 'eat', e: t - rel - 118, info: 'eats the Power Nut' };
    if (t >= rel + 252) { if (t > rel + 372) { run.wall0 = null; run.preview = null; } return { anim: 'idle', info: '+15 max stamina' }; }
    return { anim: 'wait', float: 'float', ft: t - T - G_CAST, info: 'waiting…' };
  }
  const zone = (run.pol === 'zone' || held()) && inRelease(t);
  return { anim: 'wait', float: 'float', ft: t - T - G_CAST, zone,
           info: held() ? (run.tapInfo.dud ? 'dud → reset' : zone ? 'bite 2 now → RELEASE' : 'held · waiting for bite 2')
             : zone ? 'bite now → RELEASE' : run.pol === 'bite1' ? 'release at the bite' : run.pol === 'hold' ? 'hold bite 1, release bite 2'
             : run.pol === 'tap' ? (!run.tapInfo ? 'hold B · tap the first bite' : run.tapInfo.dud ? 'dud → reset' : 'hold → release bite 2') : 'bite now → HOLD' };
}
const BEACH = (Core.data && Core.data.beach && Core.data.beach.img) ? Core.data.beach : null;
function drawJackScene(g, W, H, st, dir) {
  const J = JACK, F = J.facings[dir] || J.facings.SE, sc = J.scene[dir] || J.scene.SE;
  let s, ax, ay;
  g.imageSmoothingEnabled = false;
  if (BEACH) {                                   // Thomas's screenshot, cropped; k = canvas px per screenshot px
    const k = W / BEACH.w, bim = jimg(BEACH.img), jp = BEACH.jack[dir] || BEACH.jack.SE;
    g.fillStyle = '#4c6584'; g.fillRect(0, 0, W, H);
    if (bim.complete && bim.naturalWidth) { g.imageSmoothingEnabled = true; g.drawImage(bim, 0, 0, BEACH.w * k, BEACH.h * k); g.imageSmoothingEnabled = false; }
    s = k * BEACH.pxPerNative; ax = (jp[0] - BEACH.x0) * k; ay = (jp[1] - BEACH.y0) * k;
    g.fillStyle = '#0b162466'; g.beginPath(); g.ellipse(ax, ay + 2 * s, 9 * s, 3.5 * s, 0, 0, 6.283); g.fill();    // Jack's shadow
  } else {
    s = W / 160; ax = (dir === 'E' ? 40 : 54) * s; ay = (dir === 'E' ? 62 : 52) * s;
    g.fillStyle = '#28486a'; g.fillRect(0, 0, W, H);                                 // drawn water
    g.strokeStyle = '#3b6690'; g.lineWidth = Math.max(1, s * 0.8);
    for (let i = 0; i < 9; i++) { const y = (8 + i * 19) * s, ph = (now() / 900 + i * 0.37) % 1; g.beginPath(); for (let x = -10; x <= W + 10; x += 5 * s) g.lineTo(x, y + Math.sin(x / (11 * s) + ph * 6.283) * 1.4 * s + x * 0.25); g.stroke(); }
    const ux = 0.85, uy = 0.53, vx = -0.53, vy = 0.85, hw = 22 * s;               // drawn pier ending at Jack
    const e0 = [ax - 260 * s * ux, ay - 260 * s * uy], e1 = [ax + 20 * s * ux, ay + 20 * s * uy];
    const c = (p, k) => [p[0] + vx * hw * k, p[1] + vy * hw * k];
    g.fillStyle = '#7d6a55'; g.beginPath(); [c(e0, -1), c(e1, -1), c(e1, 1), c(e0, 1)].forEach(p => g.lineTo(p[0], p[1])); g.closePath(); g.fill();
    g.strokeStyle = '#5d4c3b'; g.lineWidth = Math.max(1, s);
    for (let k = 0; k < 20; k++) { const d = 20 * s - k * 14 * s, p = [ax + d * ux, ay + d * uy]; const a = c(p, -1), b = c(p, 1); g.beginPath(); g.moveTo(a[0], a[1]); g.lineTo(b[0], b[1]); g.stroke(); }
  }
  const draw = (a, idx, x, y) => { const im = jimg(a.frames[idx]); if (im.complete && im.naturalWidth) g.drawImage(im, Math.round(x - a.ax * s), Math.round(y - a.ay * s), a.w * s, a.h * s); };
  const anim = st.anim === 'eat' ? J.extras.eat : F[st.anim] || F.idle;
  draw(anim, frameOf(anim, st.e), ax, ay);
  if (st.nut && J.extras.nut) draw(J.extras.nut, 0, ax + sc.held[0] * s, ay + sc.held[1] * s);
  if (st.float && J.extras[st.float]) {
    const fx = ax + sc.float[0] * s, fy = ay + sc.float[1] * s;
    g.fillStyle = '#10223388'; g.beginPath(); g.ellipse(fx + 1 * s, fy + 13 * s, 6 * s, 2.5 * s, 0, 0, 6.283); g.fill();
    draw(J.extras[st.float], frameOf(J.extras[st.float], st.ft), fx, fy);
  }
  if (st.notes) { g.fillStyle = '#efe2ff'; g.font = `bold ${10 * s}px system-ui`; const ph = (now() / 400) % 1; g.fillText('♪', ax + 12 * s, ay - (44 + ph * 10) * s); g.fillText('♫', ax + 20 * s, ay - (38 + ((ph + 0.5) % 1) * 10) * s); }
  const u = W / 160;                                              // text size independent of the sprite scale
  if (st.zone) { g.fillStyle = '#000a'; g.fillRect(W - 92 * u, 3 * u, 89 * u, 14 * u); g.fillStyle = '#5fd38d'; g.font = `bold ${9 * u}px system-ui`; g.fillText('release on a bite', W - 88 * u, 13 * u); }
  if (st.info) { g.fillStyle = '#000a'; g.fillRect(0, H - 15 * u, W, 15 * u); g.fillStyle = '#dce6ec'; g.font = `${8.5 * u}px ui-monospace,monospace`; g.fillText(st.info, 5 * u, H - 5 * u); }
}
/* current pose from the stopwatch (live: no knowledge of the actual bite; preview: a drawn winning scenario) */
function poseAt(t) {
  const T = run.T, plan = run.plan, castLen = G_CAST;
  if (run.result === 'nut' && now() - run.resultAt < 4000) return now() - run.resultAt < 1000 ? ['catch', 0, 'Power Nut!'] : ['eat', Math.min(1, (now() - run.resultAt - 1000) / 1300), 'Power Nut!'];
  if (run.wall0 === null) return ['idle', 0, run.result === 'miss' ? 'reset and go again' : 'waiting for the start'];
  if (plan.k && t < plan.whistleEnd + 6) return ['whistle', 0, 'mash C-right'];
  if (t < T) return ['idle', 0, t < castCueT() ? `cast in ${((castCueT() - t) * viMs() / 1000).toFixed(1)} s` : 'cast!'];
  if (t < T + castLen) return ['cast', (t - T) / castLen, 'cast!'];
  const pv = run.preview;
  if (pv) {
    const rel = pv.release1 ? pv.bite1 : pv.bite2;
    if (!pv.release1 && t >= pv.bite1 && t < pv.bite1 + G_PULL) return ['bite', (t - pv.bite1) / G_PULL, 'bite 1: HOLD B'];
    if (!pv.release1 && t >= pv.bite1 + G_PULL && t < pv.bite1 + G_RECAST) return ['cast', 0.9, 're-cast (plop)'];
    if (t >= rel && t < rel + G_PULL) return ['bite', (t - rel) / G_PULL, 'bite: RELEASE B'];
    if (t >= rel + G_PULL && t < rel + G_CATCH) return ['reel', (t - rel - G_PULL) / (G_CATCH - G_PULL), 'reeling in…'];
    if (t >= rel + G_CATCH && t < rel + G_CATCH + G_SHOW) return ['catch', 0, 'Power Nut!'];
    if (t >= rel + G_CATCH + G_SHOW && t < rel + G_DONE) return ['eat', (t - rel - G_CATCH - G_SHOW) / (G_EATEN - G_CATCH - G_SHOW), 'eats the Power Nut'];
    if (t >= rel + G_DONE) { if (t > rel + G_DONE + 120) { run.wall0 = null; run.preview = null; } return ['catch', 0, 'max stamina up!']; }
    return ['wait', 0, 'waiting…'];
  }
  if ((run.pol === 'zone' || held()) && inRelease(t)) return ['zone', 0, 'bite now → RELEASE'];
  return ['wait', 0, run.pol === 'bite1' ? 'release at the bite' : run.pol === 'hold' ? 'hold bite 1, release bite 2' : 'bite now → HOLD'];
}

/* ---------------------------------------------------------------- scrolling timeline */
/* v31.13 (Thomas 2026-11-21 10:34): "the histogram should simplify, so players know they're not working with odds
   anymore ... a known line and trajectory, so hit the line exactly and release here". With the dog line known the
   lane of odds is replaced by that line's own facts, read from the 90-s lab data (D.dogcast):
     before the cast (a dog picked)        every cast frame of the line that carries a Nut, coloured by its bite, the
                                           CAST line and the moving now-line: put the cast on a marked frame;
     after the cast (dog + frame locked)   that frame's bites as marks - HOLD through the fish, a green band 0.33 s wide
                                           on the Nut bite: let go inside it - or NO NUT ON THIS CAST. */

/* ---------------------------------------------------------------- v31.14 FREESTYLE (Thomas 2026-11-21 13:14 / 13:15 / 13:51)
   A second MODE, not an add-on: "forget your cast time ... keep the comb level data coming"; "when a player engages
   freestyle, it means they want to choose when they cast"; Space tells the histogram "what bar cluster the person
   tried to hit (assume the middle of the closest density zone) ... and from there help them see the upcoming bite
   zone so the player can anticipate the release".
   The box beside Sparrows / Pier only, or its key (default Ctrl, reassignable; never the start key), switches the
   mode - also inside an attempt. In the mode the app has no cast time: no countdown, no CAST line, no HANDS ON B; the
   dog cards stay on the waiting dog and the watch stays open; the histogram is the picked dog's own Nut cast frames,
   with the groups that share one Nut bite bracketed. The start key = "I am casting": the cast is taken as the middle
   of the nearest group (fsMark), the cards go on from that frame and the histogram shows that group's one release
   band. Backspace = that was not my cast. dwT() is the dog-watch's cast moment: run.T, or in freestyle the marked
   cast (Infinity until then). Freestyle attempts are kept out of everything the app learns about timing. */
const fsOn = () => !!(run.fs && run.fs.on && !run.practice && !run.bite);   // v31.25: never in a practice drill
const fsWait = () => fsOn() && run.fs.cast == null;
function dwT() { return fsOn() ? (run.fs.cast != null ? Math.min(run.fs.cast, run.fs.raw != null ? run.fs.raw : run.fs.cast) : Infinity) : run.T; }
const fsKeyName = () => (L.fsKey && L.fsKey !== 'Control' ? codeTxt(L.fsKey) : 'Ctrl');
const isFsKey = e => (!L.fsKey || L.fsKey === 'Control' ? e.key === 'Control' : e.code === L.fsKey);
function fsSync() {
  const cb = $('lkFree'), lbl = $('lkFreeLbl'); if (!cb) return;
  const live = run.wall0 !== null && !run.preview && !run.practice, can = !!dwRoute() && dcHas(dwRoute());
  const on = live ? fsOn() : !!L.free, marked = live && fsOn() && run.fs.cast != null;
  cb.checked = on; cb.disabled = !can;
  lbl.className = 'lkspar' + (!can ? ' off' : marked ? ' mk' : on ? ' on' : '');
  lbl.title = can ? `Freestyle: a second mode. No cast time from the app: line your dog up, pick a group of bars, cast on it, and tap ${keyName()} as you cast. Only the box itself or the ${fsKeyName()} key switches the mode.` : 'Freestyle needs the dog-watch on a route with dog data (beach-lineup2).';
  const k = $('lkFreeKbd'); if (k && k.textContent !== fsKeyName()) k.textContent = fsKeyName();
  const tx = $('lkFreeTxt'); if (tx) tx.innerHTML = !can || !on ? '' : marked ? `<b style="color:#7fd6ff">Freestyle:</b> cast marked. Backspace = that was not my cast.` : `<b style="color:#7fd6ff">Freestyle${live ? '' : ' is on'}:</b> you choose the cast. Click your dog, line it up, cast on a group of bars and tap <kbd>${esc(keyName())}</kbd> as you cast. <kbd>${esc(fsKeyName())}</kbd> = back to the app's cast time.`;
}
function fsUncast(reopen) {
  const w = run.dw;
  cancelBeeps(); run.castTap = null; run.castErrMs = null; run.tapInfo = null; run.hold = null; run.spc = null;
  if (run.fs) { run.fs.cast = null; run.fs.raw = null; run.fs.comb = null; if (run.fs.T0 != null) { run.T = run.fs.T0; run.fs.T0 = null; } }
  if (w) { dwLock(null); w.tune = null; w.carOff = false; w.cadj = 0;
    if (reopen && w.frozen) { w.frozen = false; w.frozenAt = null; w.open = true; const box = $('lkDw'); if (box) { box.classList.remove('frozen'); box.classList.add('on'); } }
    w.dirty = true; }
  dwCardKey = '';
}
/* the box / its key: the MODE. Idle: for the next attempts. In an attempt: on = "I choose the cast" (nothing cast yet,
   the watch re-opened), off = back to the app's cast time. */
function fsToggle() {
  const live = run.wall0 !== null && !run.preview && !run.practice;
  if (!dwRoute() || !dcHas(dwRoute())) { fsSync(); return false; }
  if (!live) { L.free = !L.free; save(); fsSync(); return true; }
  if (!run.fs) run.fs = { on: false, cast: null };
  if (!run.fs.on) { run.fs.on = true; L.free = true; save(); fsUncast(true); cueFlash(`FREESTYLE · you choose the cast · tap ${keyName()} as you cast`, 'info', 1300); }
  else { fsUncast(false); run.fs.on = false; L.free = false; save(); if ((now() - run.wall0) / viMs() + 1 < run.T) scheduleBeeps(); cueFlash('FREESTYLE OFF · the app’s cast time', 'info', 1000); }
  fsSync();
  return true;
}
/* the picked dog's Nut cast frames as groups ("combs"): frames that share one Nut bite (their bite labels within 16
   VIs) and sit within 12 game frames of the next -> [{lo, hi (cast labels), ks, mid (the Nut frame nearest the group's
   centre), n, rel0, rel1 (first / last Nut-bite label), bites}] */
const fsClMemo = new Map();
function fsClusters(R, dwi) {
  const tg = fsTarget(), key = tg + R.id + ':' + dwi; if (fsClMemo.has(key)) return fsClMemo.get(key);
  const ln = DCAST.lines[R.dw.lines[dwi].key], fr = [];
  for (let j = 0; j < ln.idx.length; j++) { if (ln.idx[j] < 0) continue; const k = ln.k0 + 2 * j;
    let st = DCAST.S[ln.idx[j]], lab = k + DCAST.F[ln.idx[j]], n = 1;
    while (st >= 0 && n <= 16) { if (DCAST.O[st] === tg) { fr.push({ k, n, nt: lab }); break; } if (DCAST.N[st] < 0) break; lab += DCAST.N[st]; st = DCAST.X[st]; n++; } }
  fr.sort((x, y) => x.nt - y.nt || x.k - y.k);
  const out = [];
  for (let i = 0; i < fr.length;) { let e = i + 1; while (e < fr.length && fr[e].nt - fr[i].nt <= 16) e++;
    const g = fr.slice(i, e).sort((x, y) => x.k - y.k); i = e;
    for (let p = 0; p < g.length;) { let q = p + 1; while (q < g.length && g[q].k - g[q - 1].k <= 24) q++;
      const c = g.slice(p, q), ctr = c.reduce((m, x) => m + x.k, 0) / c.length; p = q;
      out.push({ lo: c[0].k, hi: c[c.length - 1].k, ks: c.map(x => x.k), ns: c.map(x => x.n), nts: c.map(x => x.nt), n: c.length, mid: c.reduce((b, x) => (Math.abs(x.k - ctr) < Math.abs(b - ctr) ? x.k : b), c[0].k),
                 rel0: Math.min(...c.map(x => x.nt)), rel1: Math.max(...c.map(x => x.nt)), bites: [...new Set(c.map(x => x.n))].sort() }); } }
  out.sort((x, y) => x.lo - y.lo); fsClMemo.set(key, out); return out;
}
/* v31.16 the targets: DOUBLES = two (or three) neighbouring game frames that both carry the Nut on the same bite and
   the same release moment ("double bar & same colour", Thomas 14:18): a 67-ms cast window with one thing to do.
   -> [{k0, k1 (cast labels), len, bite, rel0, rel1}] by time */
const fsDbMemo = new Map();
function fsDoubles(R, dwi) {
  const key = fsTarget() + R.id + ':' + dwi; if (fsDbMemo.has(key)) return fsDbMemo.get(key);
  const out = [];
  for (const c of fsClusters(R, dwi)) for (let i = 0; i < c.ks.length;) { let j = i + 1; while (j < c.ks.length && c.ks[j] - c.ks[j - 1] === 2 && c.ns[j] === c.ns[i]) j++;
    if (j - i >= 2) out.push({ k0: c.ks[i], k1: c.ks[j - 1], len: j - i, bite: c.ns[i], rel0: c.rel0, rel1: c.rel1, cl: c }); i = j; }
  out.sort((x, y) => x.k0 - y.k0); fsDbMemo.set(key, out); return out;
}
const FS_COL = ['', 'green', 'gold', 'purple'];
function fsNextDouble(t) {                                        // the next double still ahead (>= 0.5 s) on the picked dog
  const w = run.dw, R = dwRoute(); if (!w || !w.pick || !R || R.dw.lines[w.pick.dwi].li < 0) return null;
  const a = w.pick.a0 + w.adj, all = fsDoubles(R, w.pick.dwi), d = all.find(x => x.k0 - a >= t + 30);
  return d ? { d, at: d.k0 - a, inS: (d.k0 - a - t) * viMs() / 1000, col: FS_COL[Math.min(3, d.bite)], last: all[all.length - 1] === d } : { none: true };
}
const FS_NEAR = 30;                                               // a tap counts for a group up to 0.5 s from its edge
/* Space in freestyle = "I am casting now". With a dog picked the cast is taken as the middle of the nearest group of
   bars (what the player aimed at); the cards and the release moment follow from that frame. */
/* v31.22 the declared target of a cast at stopwatch t on the picked dog (a = its alignment): the nearest DOUBLE /
   TRIPLE within 0.5 s (Thomas 16:27: "i will almost exclusively be going for double bars and triple bars"), else the
   nearest group of bars within 0.5 s, else none. -> { cl, dbl, k0, k1 (cast labels of the target's first / last bar),
   kind, n, bites, cast (the frame taken: stopwatch VI) } */
function fsTargetAt(R, dwi, a, t) {
  const kt = t + a, dist = (lo, hi) => (kt < lo ? lo - kt : kt > hi ? kt - hi : 0);
  const db = fsDoubles(R, dwi).map(x => ({ x, d: dist(x.k0, x.k1) })).sort((p, q) => p.d - q.d)[0];
  if (db && db.d <= FS_NEAR) { const x = db.x; let kk = Math.round(Math.min(x.k1, Math.max(x.k0, kt)) / 2) * 2; kk = Math.min(x.k1, Math.max(x.k0, kk));
    return { cl: x.cl, dbl: x, k0: x.k0, k1: x.k1, kind: x.len >= 3 ? 'triple' : 'double', n: x.len, bites: [x.bite], cast: kk - a }; }
  let cl = null, bd = Infinity;
  for (const c of fsClusters(R, dwi)) { const d = dist(c.lo, c.hi); if (d < bd - 1e-9 || (Math.abs(d - bd) < 1e-9 && cl && Math.abs(kt - c.mid) < Math.abs(kt - cl.mid))) { bd = d; cl = c; } }
  if (cl && bd <= FS_NEAR) return { cl, dbl: null, k0: cl.lo, k1: cl.hi, kind: cl.n > 1 ? 'group' : 'single', n: cl.n, bites: cl.bites, cast: cl.mid - a };
  return null;
}
function fsMark(t) {
  if (!fsWait() || !run.dw || run.preview) return false;
  const w = run.dw, R = dwRoute(); let cast = t, cl = null, dbl = null;
  if (w.pick && R && R.dw.lines[w.pick.dwi].li >= 0) {
    const a = w.pick.a0 + w.adj, tg = fsTargetAt(R, w.pick.dwi, a, t);
    if (tg) { cl = tg.cl; dbl = tg.dbl; cast = tg.cast; }
    run.fs.comb = { dwi: w.pick.dwi, name: 'L' + (R.dw.lines[w.pick.dwi].li + 1), a, kc: cl ? Math.round(cast + a) : null, cl, dbl, tg, n: cl ? cl.n : 0, bites: tg ? tg.bites : [],
                    rel: cl ? cl.rel1 - a : null, relEnd: cl ? Math.max(cl.rel1, cl.rel0 + WINDOW_VI) - a : null, off: cl ? Math.round((t - cast) * viMs()) : null };
  } else run.fs.comb = null;
  run.fs.raw = t; run.fs.cast = cast; run.fs.n = (run.fs.n || 0) + 1; run.castTap = cast; run.castErrMs = null; dwCardKey = '';
  if (run.fs.T0 == null) run.fs.T0 = run.T; run.T = cast;         // v31.25 BUG FIX (consistency lab): after a marked cast everything that follows the cast (bite marks, the lamp) must count from it - the lamp said CAST IN 11 s after a bite mark
  cueFlash(dbl ? `CAST · ${dbl.len >= 3 ? 'TRIPLE' : 'DOUBLE'} · bite ${dbl.bite}` : cl ? `CAST · ${cl.n} bar${cl.n > 1 ? 's' : ''} · bite ${cl.bites.join(' or ')}` : 'CAST MARKED', 'go', 700);
  fsSync();
  return true;
}
/* v31.22 the freestyle part of the cast report: graded against the target the player declared (Space at the cast), or,
   with no Space but a locked dog, against the target nearest the locked frame. Stopwatch VIs throughout. */
function fsRepBuild() {
  const w = run.dw, R = dwRoute(), f = run.fs, c = f.comb, o = { tg: fsTarget(), tap: f.raw != null ? +f.raw.toFixed(1) : null, lag: +lagMu().toFixed(1) };
  if (!w || !R) return o;
  const lockOn = w.exact != null && R.dw.lines[w.exact].li >= 0, dwi = c ? c.dwi : lockOn ? w.exact : w.pick ? w.pick.dwi : null;
  if (dwi == null || R.dw.lines[dwi].li < 0) return o;
  o.line = 'L' + (R.dw.lines[dwi].li + 1);
  let a = c ? c.a : null, lockC = null;
  if (lockOn && w.exact === dwi) { const fr = dcLabel(R, dwi, dcCardA(dwi)); if (fr) { lockC = fr.kc - fr.a; if (a == null) a = fr.a; } }
  if (a == null) a = w.pick ? w.pick.a0 + w.adj : 0;
  const tg = c && c.tg ? c.tg : f.raw == null && lockC != null ? fsTargetAt(R, dwi, a, lockC) : null;
  o.by = c ? 'tap' : tg ? 'lock' : null;
  if (tg) { const cl = tg.cl; o.T = { kind: tg.kind, n: tg.n, bites: tg.bites, f0: +(tg.k0 - a).toFixed(1), f1: +(tg.k1 - a).toFixed(1), rel: +(cl.rel1 - a).toFixed(1), relEnd: +(Math.max(cl.rel1, cl.rel0 + WINDOW_VI) - a).toFixed(1) };
    o.bars = []; const mid = Math.round((tg.k0 + tg.k1) / 4) * 2;
    for (let d = -44; d <= 44; d += 2) { const nb = dcNutAt(R, dwi, mid + d); if (nb > 0) o.bars.push([+(mid + d - a).toFixed(1), Math.min(3, nb)]); } }
  if (lockC != null) { o.lock = +lockC.toFixed(1); o.cadj = w.cadj || 0; }
  return o;
}
function fsUnmark() { if (!fsOn() || run.fs.cast == null || run.tapInfo) return false; fsUncast(true); cueFlash('FREESTYLE · not cast yet', 'info', 800); fsSync(); return true; }
const fsComb = () => (fsOn() && run.fs.cast != null ? run.fs.comb : null);
function fsCue(t) {                                               // the lamp in freestyle
  if (!fsOn() || run.wall0 === null) return null;
  if (run.fs.cast == null) { const wk = wakeNow(t); if (wk) return { kind: 'bad', big: 'WAKE JACK · STICK DOWN-RIGHT', sub: `he lies down in ${wk.left.toFixed(1)} s · one push of the stick (south-east) is enough`, glow: 0.6 }; }
  const w = run.dw;
  /* v31.24 (Thomas 2026-11-21 17:56): the LAST double of this dog, whatever its colour - the lamp pulses from 8 s
     before it (faster in the last 3 s) so the last good two-frame chance is not missed. The pulse is the screen-edge
     glow: Settings -> Lucky Timer -> glow box (off = the text only). It outranks the thread and next-double lines. */
  if (run.fs.cast == null && w && w.pick) { const nd = fsNextDouble(t);
    if (nd && nd.last && nd.inS <= 8) { const fast = nd.inS <= 3, ph = (now() % (fast ? 320 : 700)) / (fast ? 320 : 700), pulse = 0.25 + 0.75 * (0.5 - 0.5 * Math.cos(2 * Math.PI * ph));
      return { kind: 'bad', big: `LAST DOUBLE · ${nd.col.toUpperCase()} · ${nd.inS.toFixed(1)} s`, sub: `the last two-frame chance on this dog (${fmtS(nd.at)}): ${nd.d.bite === 1 ? 'let go on bite 1' : nd.d.bite === 2 ? 'hold bite 1, let go on bite 2' : 'let go on bite ' + nd.d.bite} · after it only single bars are left`, bar: Math.max(0, 1 - nd.inS / 8), glow: pulse, pulse: true }; } }
  if (run.fs.cast == null && w && w.pick && run.fsLive && run.known === 'pre') {       // a passed bar's window is close: that outranks the next double
    const q = run.fsLive.find(x => x.r + WINDOW_VI >= t && x.r - t <= 2.5 * 1000 / viMs());
    if (q) { const dt = (q.r - t) * viMs() / 1000, col = FS_COL[q.nb].toUpperCase();
      return dt > 0 ? { kind: 'ready', big: `${col} THREAD · LET GO IN ${dt.toFixed(1)} s`, sub: `only if you cast on its bar (${fmtS(q.c)})${q.nb > 1 ? ' and held through bite 1' : ''} · otherwise keep waiting`, bar: Math.max(0, 1 - dt / 2.5) }
                    : { kind: 'nut', big: `${col} THREAD · LET GO NOW`, sub: `if you cast on its bar (${fmtS(q.c)})` }; } }
  if (run.fs.cast == null && w && w.pick) { const nd = fsNextDouble(t);
    if (nd && !nd.none) return { kind: nd.inS <= 3 ? 'ready' : 'info', big: `${nd.last ? 'LAST' : 'NEXT'} DOUBLE · ${nd.col.toUpperCase()} · ${nd.inS.toFixed(1)} s`, sub: `two frames side by side, same colour (${fmtS(nd.at)}): ${nd.d.bite === 1 ? 'let go on bite 1' : nd.d.bite === 2 ? 'hold bite 1, let go on bite 2' : 'let go on bite ' + nd.d.bite} · cast on it and tap ${keyName()} · or any group you like`, bar: nd.inS <= 3 ? Math.max(0, 1 - nd.inS / 3) : 0 };
    if (nd && nd.none) return { kind: 'info', big: 'FREESTYLE', sub: `no double left on this dog · single bars and groups still count · tap ${keyName()} as you cast` }; }
  if (run.fs.cast == null) return { kind: 'info', big: 'FREESTYLE', sub: w && w.pick ? `cast on a group of bars and tap ${keyName()} as you cast · green = let go on bite 1 · gold = hold bite 1, let go on bite 2` : `click your dog to see its Nut bars · you choose the cast` };
  if (run.tapInfo) return null;                                    // bite marks: the usual lamp
  const c = fsComb();
  if (!c) return { kind: 'hold', big: 'CAST MARKED', sub: `at ${fmtS(run.fs.cast)} · no dog picked: click your dog, or mark the bites with ${keyName()}` };
  if (!c.cl) return { kind: 'bad', big: 'NO BARS NEAR THAT CAST', sub: `${c.name} has no Nut frame within 0.5 s of ${fmtS(run.fs.raw)} · Backspace = that was not my cast` };
  const dt = (c.rel - t) * viMs() / 1000, bt = c.bites.length === 1 ? `bite ${c.bites[0]}` : `bite ${c.bites.join(' or ')}`;
  if (t > c.relEnd) return { kind: 'info', big: 'THE GROUP’S BITE HAS PASSED', sub: `it was at ${fmtS(c.rel)} · H / M / E` };
  if (t >= c.rel) return { kind: 'nut', big: 'LET GO NOW', sub: `the group's Nut bite (${bt})` };
  return { kind: dt <= 1.5 ? 'ready' : 'hold', big: `${c.bites[0] > 1 ? 'HOLD THROUGH BITE 1 · ' : 'HOLD · '}LET GO IN ${dt.toFixed(1)} s`, sub: `${c.name}: ${c.bites.length > 1 ? 'hold through any bite before that · ' : ''}taken as the middle of the group of ${c.n} (your tap ${c.off >= 0 ? '+' : '−'}${Math.abs(c.off)} ms from it) · its Nut is ${bt} at ${fmtS(c.rel)}`, bar: dt <= 3 ? Math.max(0, 1 - dt / 3) : 0 };
}
const dcNutMemo = new Map();
/* v31.20 what the freestyle bars stand for: the Power Nut, or (data to 90 s, catches of every bite) a fish size */
const FS_TG = { N: 'Nut', l: 'large fish', m: 'medium fish', s: 'small fish' };
const fsTarget = () => (fsOn() && FS_TG[L.fsTarget] ? L.fsTarget : 'N');
function dcNutAt(R, dwi, kc) {                                    // bite number that gives the target (the Nut) for a cast at label kc: 0 none, -1 no data
  const tg = fsTarget(), key = tg + (dwi * 8192 + kc); let v = dcNutMemo.get(key); if (v !== undefined) return v;
  const ln = DCAST && DCAST.lines[R.dw.lines[dwi].key], j = ln ? (kc - ln.k0) / 2 : -1;
  if (!ln || j < 0 || j >= ln.idx.length || ln.idx[j] < 0 || !Number.isInteger(j)) v = -1;
  else { v = 0; let st = DCAST.S[ln.idx[j]], n = 1; while (st >= 0 && n <= 16) { if (DCAST.O[st] === tg) { v = n; break; } if (DCAST.N[st] < 0) break; st = DCAST.X[st]; n++; } }
  if (dcNutMemo.size > 60000) dcNutMemo.clear();
  dcNutMemo.set(key, v); return v;
}
const dcLast = (R, dwi) => { const ln = DCAST && DCAST.lines[R.dw.lines[dwi].key]; return ln ? ln.k0 + 2 * (ln.idx.length - 1) : null; };   // the last cast label in the data
function knownView(t) {                                           // null = the ordinary histogram
  const w = run.dw, R = dwRoute();
  if (!w || !R || run.wall0 === null || run.preview || run.practice || !dcHas(R) || L.knownView === false) return null;
  if (t >= dwT()) { const x = dcExact(t); if (x) return { post: true, x, R }; const c = fsComb(); return c ? { post: false, fs: true, focus: c, dwi: c.dwi, a: c.a, R, name: c.name } : null; }   // v31.19: Space marked the cast - the same view, only that cast's threads
  if (w.pick && R.dw.lines[w.pick.dwi].li >= 0) return { post: false, dwi: w.pick.dwi, a: w.pick.a0 + w.adj, R, name: 'L' + (R.dw.lines[w.pick.dwi].li + 1), fs: fsWait() };
  return null;
}
/* v31.18 (Thomas 2026-11-21 15:18 / 15:19): no key at the cast. Under the bars ("doing nothing": every cast frame that
   carries the Nut) a thin second lane: "if you had cast there, you let go here" - each bar's release window on the
   same clock - and a thread tying every bar to its window. While the bar is still ahead the thread is a fixed slant
   (longer = a later bite). Once the bar has passed the white line its upper end stays ON the white line (that cast
   is now either made or not) and the window keeps coming: the thread swings upright, stands vertical on the white
   line at the moment to let go, and is gone. The player follows the thread of the bar he cast on.
   run.fsLive = the passed casts still waiting for their window [{c, r, nb}] (stopwatch VIs), nearest first. */
function fsThreads(g, W, H, dpr, t, K, X, barBot) {
  const a = K.a, relTop = H - 50 * dpr, relBot = H - 24 * dpr, live = [];
  g.fillStyle = '#0a1410'; g.fillRect(0, relTop, W, relBot - relTop);
  g.strokeStyle = '#24362d'; g.lineWidth = 1; g.strokeRect(0, relTop + 0.5, W, relBot - relTop - 1);
  const dbl = new Set(); for (const d of fsDoubles(K.R, K.dwi)) for (let k = d.k0; k <= d.k1; k += 2) dbl.add(k);
  const wWin = Math.max(3 * dpr, X(WINDOW_VI) - X(0)), seen = new Set(), NEAR = 3 * 1000 / viMs();
  const fc = K.focus;
  if (fc) { g.strokeStyle = '#ffffff99'; g.lineWidth = dpr; g.setLineDash([3 * dpr, 3 * dpr]); g.beginPath(); g.moveTo(X(run.fs.raw), 26 * dpr); g.lineTo(X(run.fs.raw), barBot); g.stroke(); g.setLineDash([]); }
  for (const c of fsClusters(K.R, K.dwi)) for (let i = 0; i < c.ks.length; i++) {
    if (fc && c !== fc.cl) continue;                                 // the cast is marked: only its group's threads
    const cs = c.ks[i] - a, r = c.nts[i] - a, nb = Math.min(3, c.ns[i]);
    if (r + WINDOW_VI < t || X(cs) > W + 4) continue;                 // its window is over / the bar is not on screen yet
    const passed = fc ? true : cs < t, xt = passed ? X(t) : X(cs), xr = X(r), col = BITECOL[nb], d2 = dbl.has(c.ks[i]);
    if (passed) live.push({ c: cs, r, nb });
    const wk = Math.round(r / 4) + ':' + nb;                           // one window per release moment
    const soon = fc ? true : passed && r - t <= NEAR, ahead = !passed && cs - t <= NEAR * 1.5;     // bright: about to stand up / about to be cast on
    if (!seen.has(wk) || soon) { seen.add(wk); g.globalAlpha = soon ? 1 : passed ? 0.38 : 0.2; g.fillStyle = col; g.fillRect(xr, relTop + 3 * dpr, soon ? wWin : Math.max(2 * dpr, wWin * 0.25), relBot - relTop - 6 * dpr); }
    if (!passed && !ahead && !d2) continue;                            // far-off bars: no thread yet (their windows are marked)
    g.globalAlpha = soon ? 1 : passed ? 0.3 : ahead ? 0.8 : 0.45; g.strokeStyle = col; g.lineWidth = (soon ? 2.6 : ahead ? 1.6 : 1) * dpr;
    g.beginPath(); g.moveTo(xt + (passed ? 0 : dpr), barBot + 1 * dpr); g.lineTo(xr + (passed ? 0 : dpr), relTop + 3 * dpr); g.stroke();
  }
  g.globalAlpha = 1;
  live.sort((p, q) => p.r - q.r); run.fsLive = live;
  /* v31.23 the blind release line, as outside freestyle (pink; Settings -> Lucky Timer -> release line): the middle of
     the release window, moved by the same habit correction as every line the player acts on (cueCorr(): the median of
     his practice presses against their line), with a dashed ghost at the unmoved moment. A marked cast gets the full
     line and its time; unmarked, every window in its last 3 s gets a pink tick in the release lane. */
  run.fsRel = null;
  if (L.relLine !== false) {
    const corr = cueCorr() / viMs(), seenR = new Set();
    const ms = fc ? (fc.cl ? [{ m: (fc.cl.rel1 + fc.cl.rel0 + WINDOW_VI) / 2 - a, main: true }] : []) : live.filter(q => q.r - t <= NEAR && q.r + WINDOW_VI >= t).map(q => ({ m: q.r + WINDOW_VI / 2 }));
    for (const q of ms) { const kq = Math.round(q.m / 4); if (seenR.has(kq)) continue; seenR.add(kq);
      const cue = q.m + corr, x = X(cue);
      if (q.main) { run.fsRel = { cue, mid: q.m };
        if (Math.abs(corr) >= 0.5) { g.strokeStyle = '#ff7ad955'; g.lineWidth = 2 * dpr; g.setLineDash([4 * dpr, 4 * dpr]); g.beginPath(); g.moveTo(X(q.m), 40 * dpr); g.lineTo(X(q.m), relBot); g.stroke(); g.setLineDash([]); }
        g.strokeStyle = '#ff7ad9'; g.lineWidth = 2.5 * dpr; g.beginPath(); g.moveTo(x, 40 * dpr); g.lineTo(x, relBot); g.stroke();
        g.fillStyle = '#ff7ad9'; g.font = `bold ${11 * dpr}px system-ui`; const tx = `RELEASE ${fmtS(cue)}${Math.abs(corr) >= 0.5 ? ` · ${Math.abs(Math.round(corr * viMs()))} ms ${corr < 0 ? 'early' : 'late'} for your habit` : ''}`;
        g.fillText(tx, Math.max(4 * dpr, Math.min(W - g.measureText(tx).width - 4 * dpr, x + 5 * dpr)), 52 * dpr); }
      else { g.strokeStyle = '#ff7ad9'; g.lineWidth = 2.5 * dpr; g.beginPath(); g.moveTo(x, relTop - 5 * dpr); g.lineTo(x, relBot + 2 * dpr); g.stroke(); } }
  }
  g.font = `${10 * dpr}px system-ui`; g.fillStyle = '#8ea3b2';
  g.fillText('let go here', 6 * dpr, relTop - 4 * dpr);
  const nx = live.find(q => q.r + WINDOW_VI >= t);
  if (nx) { const dt = (nx.r - t) * viMs() / 1000, x = Math.max(X(t) + 6 * dpr, Math.min(W - 150 * dpr, X(nx.r) + wWin + 5 * dpr));
    g.font = `700 ${12 * dpr}px system-ui`; g.fillStyle = BITECOL[nx.nb];
    g.fillText(dt > 0 ? `${dt.toFixed(1)} s` : 'LET GO', x, relBot - 8 * dpr); }
}
/* v32.6: a canvas context that draws nothing (the hidden release lane is still worked out for the lamp) */
const NOCTX = new Proxy({}, { get: (o, k) => (k in o ? o[k] : k === 'measureText' ? () => ({ width: 0 }) : () => {}), set: (o, k, v) => { o[k] = v; return true; } });
function drawKnown(g, W, H, dpr, t, K) {
  const sec = 1000 / viMs(), v0 = t - 2.5 * sec, span = 16 * sec, X = v => (v - v0) / span * W, top = 26 * dpr, fsLane = !K.post && K.fs && L.relWin !== false, bot = H - (fsLane ? 96 : 22) * dpr;
  g.fillStyle = '#0d1a14'; g.fillRect(0, 0, W, H);
  g.font = `${10 * dpr}px system-ui`; g.fillStyle = '#8ea3b2';
  const s0 = Math.ceil((v0 - 1) / sec), s1 = Math.floor((v0 + span - 1) / sec);
  for (let k = s0; k <= s1; k++) { const x = X(k * sec + 1); g.fillRect(x, H - 14 * dpr, 1, 4 * dpr); g.fillText(k + 's', x + 2, H - 3 * dpr); }
  g.font = `600 ${11 * dpr}px system-ui`;
  if (!K.post) {
    const a = K.a; let n = 0;
    for (let v = Math.floor(v0); v <= v0 + span; v++) {
      const kc = Math.round(v + a); if (kc % 2) continue;
      const nb = dcNutAt(K.R, K.dwi, kc); if (nb <= 0) continue;
      n++; g.fillStyle = BITECOL[Math.min(3, nb)]; const x = X(kc - a), wd = Math.max(2 * dpr, X(2) - X(0) - 1);
      g.globalAlpha = K.focus && !(K.focus.cl && K.focus.cl.ks.includes(kc)) ? 0.25 : 1;
      g.fillRect(x, top + (nb === 1 ? 0 : nb === 2 ? 10 * dpr : 20 * dpr), wd, bot - top - (nb === 1 ? 0 : nb === 2 ? 10 * dpr : 20 * dpr));
    }
    g.globalAlpha = 1;
    if (fsLane) fsThreads(g, W, H, dpr, t, K, X, bot);
    else if (!K.post && K.fs) {                                   // v32.6: lane hidden - still worked out (the lamp reads it), not drawn
      fsThreads(NOCTX, W, H, dpr, t, K, X, bot);
      const r = run.fsRel;
      if (r && L.relLine !== false) { const x = X(r.cue); g.strokeStyle = '#ff7ad9'; g.lineWidth = 2.5 * dpr; g.beginPath(); g.moveTo(x, 40 * dpr); g.lineTo(x, bot); g.stroke();
        g.fillStyle = '#ff7ad9'; g.font = `bold ${11 * dpr}px system-ui`; const tx = `RELEASE ${fmtS(r.cue)}`; g.fillText(tx, Math.max(4 * dpr, Math.min(W - g.measureText(tx).width - 4 * dpr, x + 5 * dpr)), 52 * dpr); g.font = `600 ${11 * dpr}px system-ui`; }
    }
    const cue = castCueT(), T = run.T;
    if (K.fs) { /* freestyle: no cast line - the player chooses */ }
    else if (Math.abs(cue - T) >= 0.5) { g.strokeStyle = '#6fb7ff66'; g.lineWidth = 2 * dpr; g.setLineDash([4 * dpr, 4 * dpr]); g.beginPath(); g.moveTo(X(T), top - 8 * dpr); g.lineTo(X(T), bot + 4 * dpr); g.stroke(); g.setLineDash([]); }
    if (!K.fs) { g.strokeStyle = '#6fb7ff'; g.lineWidth = 3 * dpr; g.beginPath(); g.moveTo(X(cue), top - 10 * dpr); g.lineTo(X(cue), bot + 6 * dpr); g.stroke();
      g.fillStyle = '#6fb7ff'; g.fillText('CAST ' + fmtS(cue), Math.min(W - 90 * dpr, X(cue) + 5 * dpr), bot + 2 * dpr); }
    g.fillStyle = K.fs ? '#7fd6ff' : '#cfe6d6'; g.fillText(K.focus ? (K.focus.cl ? `FREESTYLE · ${K.name} — cast marked on a group of ${K.focus.n}: let go when its thread stands straight up on the white line (${fmtS(K.focus.rel)}) · Backspace = not my cast` : `FREESTYLE · ${K.name} — no Nut bars within 0.5 s of that cast · Backspace = not my cast`) : K.fs ? `FREESTYLE · ${K.name} (your dog) — every bar is a cast frame that carries the ${FS_TG[fsTarget()]}. ${fsLane ? 'Cast on a bar, follow its thread: let go when it stands straight up on the white line' : 'Cast on a bar, let go at the bite its colour says'}` : `KNOWN LINE · ${K.name} (your dog) — no odds here: every bar is a cast frame that carries the Nut`, 6 * dpr, 12 * dpr);
    g.font = `${10 * dpr}px system-ui`;
    let lx = 6 * dpr; for (const [nb, tx] of [[1, (K.fs ? FS_TG[fsTarget()] : 'Nut') + ' on bite 1'], [2, 'bite 2'], [3, 'bite 3+']]) { g.fillStyle = BITECOL[nb]; g.fillRect(lx, 16 * dpr, 9 * dpr, 6 * dpr); g.fillStyle = '#8ea3b2'; g.fillText(tx, lx + 12 * dpr, 23 * dpr); lx += (g.measureText(tx).width + 26 * dpr); }
    g.fillStyle = '#8ea3b2'; g.fillText(K.fs ? (n ? (fsLane ? `No key needed. Gold thread = hold through bite 1. (${keyName()} at the cast still marks it, if you like.)` : `No key needed. Gold = hold through bite 1. (${keyName()} at the cast still marks it, if you like.)`) : 'No Nut frame in the next seconds of this line.') : n ? 'Press B so the white line is on the CAST line.' : 'No Nut frame in the next seconds of this line.', lx + 6 * dpr, 23 * dpr);
    if (K.fs) { g.font = `700 ${11 * dpr}px system-ui`; for (const d of fsDoubles(K.R, K.dwi)) { const xa = X(d.k0 - a), xb = X(d.k1 - a) + Math.max(2 * dpr, X(2) - X(0) - 1); if (xb < 0 || xa > W) continue;
        g.fillStyle = BITECOL[Math.min(3, d.bite)]; g.globalAlpha = 0.28; g.fillRect(xa - 3 * dpr, top - 4 * dpr, xb - xa + 6 * dpr, bot - top + 4 * dpr); g.globalAlpha = 1;
        const ym = bot - 30 * dpr; g.fillStyle = '#0d1a14'; g.fillRect((xa + xb) / 2 - 9 * dpr, ym - 11 * dpr, 34 * dpr, 14 * dpr);
        g.fillStyle = BITECOL[Math.min(3, d.bite)]; g.beginPath(); g.moveTo((xa + xb) / 2 - 6 * dpr, ym - 9 * dpr); g.lineTo((xa + xb) / 2 + 6 * dpr, ym - 9 * dpr); g.lineTo((xa + xb) / 2, ym); g.closePath(); g.fill();
        g.fillText('×' + d.len, (xa + xb) / 2 + 9 * dpr, ym); }
      g.font = `${10 * dpr}px system-ui`; }
    if (K.fs) { g.strokeStyle = '#7fd6ff'; g.lineWidth = 2 * dpr; for (const c of fsClusters(K.R, K.dwi)) { if (c.n < 2) continue; const xa = X(c.lo - a) - 2 * dpr, xb = X(c.hi - a) + 4 * dpr; if (xb < 0 || xa > W) continue; g.beginPath(); g.moveTo(xa, bot - 6 * dpr); g.lineTo(xa, bot); g.lineTo(xb, bot); g.lineTo(xb, bot - 6 * dpr); g.stroke(); } }
    if (dcLast(K.R, K.dwi) != null) { const xe = X(dcLast(K.R, K.dwi) - a); if (xe < W) { g.fillStyle = '#00000088'; g.fillRect(xe, top, W - xe, bot - top); g.fillStyle = '#8ea3b2'; g.fillText(`end of the cast data (${Math.round(dcLast(K.R, K.dwi) / (1000 / viMs()))} s after Jack stops)`, xe + 4 * dpr, top + 12 * dpr); } }
  } else if (K.comb) {
    const c = K.comb, a = c.a, cl = c.cl;
    g.fillStyle = '#7fd6ff'; g.fillText(`FREESTYLE CAST · ${c.name}`, 6 * dpr, 12 * dpr);
    g.font = `${10 * dpr}px system-ui`;
    const k0 = Math.round((cl ? cl.mid : run.fs.raw + a) / 2) * 2;
    for (let d = -40; d <= 40; d++) { const k = k0 + 2 * d, nb = dcNutAt(K.R, c.dwi, k); if (nb > 0) { const mine = cl && cl.ks.includes(k); g.globalAlpha = mine ? 1 : 0.3; g.fillStyle = BITECOL[Math.min(3, nb)]; g.fillRect(X(k - a), top, Math.max(2 * dpr, X(2) - X(0) - 1), (bot - top) * (mine ? 0.55 : 0.4)); } }
    g.globalAlpha = 1;
    if (cl) { g.strokeStyle = '#7fd6ff'; g.lineWidth = 2 * dpr; g.strokeRect(X(cl.lo - a) - 3 * dpr, top - 3 * dpr, X(cl.hi - a) - X(cl.lo - a) + 8 * dpr, (bot - top) * 0.55 + 6 * dpr); }
    g.strokeStyle = '#ffffff99'; g.lineWidth = 1 * dpr; g.setLineDash([3 * dpr, 3 * dpr]); g.beginPath(); g.moveTo(X(run.fs.raw), top - 6 * dpr); g.lineTo(X(run.fs.raw), bot); g.stroke(); g.setLineDash([]);
    g.fillStyle = '#cfd8df'; g.fillText('your tap', X(run.fs.raw) + 3 * dpr, bot - 4 * dpr);
    if (cl) { const x = X(c.rel), x1 = X(c.relEnd); g.fillStyle = '#5fd38d55'; g.fillRect(x, top, x1 - x, bot - top); g.strokeStyle = '#5fd38d'; g.lineWidth = 3 * dpr; g.beginPath(); g.moveTo(x, top); g.lineTo(x, bot); g.stroke();
      g.fillStyle = '#8ff0a4'; g.fillText(`LET GO · bite ${c.bites.join(' or ')} = NUT`, Math.min(W - 150 * dpr, x + 4 * dpr), top + 12 * dpr);
      if (x > W) { g.fillStyle = '#8ff0a4'; g.font = `600 ${12 * dpr}px system-ui`; g.fillText(`let go in ${((c.rel - t) * viMs() / 1000).toFixed(1)} s →`, W - 130 * dpr, (top + bot) / 2); }
      g.fillStyle = '#8ff0a4'; g.font = `600 ${11 * dpr}px system-ui`; g.fillText(`Taken as the group of ${c.n} in the box${c.bites[0] > 1 ? ' — hold through bite 1' : ''}: let go inside the green band (${fmtS(c.rel)})`, 150 * dpr, 12 * dpr); }
    else { g.fillStyle = '#ef6f6f'; g.font = `600 ${11 * dpr}px system-ui`; g.fillText('No Nut bars within 0.5 s of that cast · Backspace = that was not my cast', 150 * dpr, 12 * dpr); }
  } else {
    const B = K.x.B, who = K.x.name;
    g.fillStyle = '#cfe6d6'; g.fillText(`KNOWN CAST · ${who} at this frame — no odds here: these are its bites`, 6 * dpr, 12 * dpr);
    g.font = `${10 * dpr}px system-ui`;
    g.strokeStyle = '#6fb7ff'; g.lineWidth = 2 * dpr; const cx = X(dcFrame(K.R, K.x.dwi).c); if (cx >= 0) { g.beginPath(); g.moveTo(cx, top); g.lineTo(cx, bot); g.stroke(); g.fillStyle = '#6fb7ff'; g.fillText('cast', cx + 3 * dpr, top + 10 * dpr); }
    if (!B || !B.bites.length) { g.fillStyle = '#ffd28a'; g.fillText(B ? 'No bite in the data for this frame.' : 'No data for this frame.', 6 * dpr, 23 * dpr); }
    else {
      const nb = B.nut;
      g.fillStyle = nb ? '#8ff0a4' : '#ef6f6f'; g.font = `600 ${11 * dpr}px system-ui`;
      g.fillText(nb ? `NUT ON BITE ${nb.n} · let go inside the green band (${fmtS1(nb.t)} s)` : 'NO NUT ON THIS CAST', 6 * dpr, 24 * dpr); g.font = `${10 * dpr}px system-ui`;
      for (const b of B.bites) {
        const x = X(b.t), isNut = b.o === 'N', before = nb && b.n < nb.n;
        if (isNut) { g.fillStyle = '#5fd38d55'; g.fillRect(x, top, X(b.t + WINDOW_VI) - x, bot - top); g.strokeStyle = '#5fd38d'; g.lineWidth = 3 * dpr; }
        else { g.strokeStyle = before ? '#e7c14a' : '#6b7c88'; g.lineWidth = 2 * dpr; }
        g.beginPath(); g.moveTo(x, top); g.lineTo(x, bot); g.stroke();
        g.fillStyle = isNut ? '#8ff0a4' : before ? '#e7c14a' : '#8ea3b2';
        g.fillText(isNut ? `bite ${b.n} = NUT · LET GO` : `bite ${b.n} · ${DC_FISH[b.o] || b.o}${before ? ' · HOLD' : ''}`, x + 4 * dpr, top + (12 + 12 * ((b.n - 1) % 3)) * dpr);
      }
      const nx = B.bites.find(b => b.t > v0 + span);
      if (nx) { g.fillStyle = '#8ea3b2'; g.fillText(`bite ${nx.n}${nx.o === 'N' ? ' (NUT)' : ''} in ${((nx.t - t) * viMs() / 1000).toFixed(1)} s →`, W - 150 * dpr, bot - 4 * dpr); }
    }
  }
  if (!K.post) drawWake(g, X, 26 * dpr, H - 22 * dpr, dpr, W);
  g.strokeStyle = '#ffffff'; g.lineWidth = 2 * dpr; g.beginPath(); g.moveTo(X(t), 0); g.lineTo(X(t), H); g.stroke();
}
function drawTimeline(t) {
  const cv = $('lkTimeline'), dpr = devicePixelRatio, W = cv.width = cv.clientWidth * dpr, H = cv.height = 230 * dpr;
  const g = cv.getContext('2d'), plan = run.plan, T = run.T, z = run.zone, sec = 1000 / viMs();
  g.clearRect(0, 0, W, H);
  if (!plan) return;
  const live = run.wall0 !== null;
  { const K = live ? knownView(t) : null; run.known = K ? (K.post ? 'post' : 'pre') : null; if (K) { drawKnown(g, W, H, dpr, t, K); return; } }
  if (live && fsOn() && !run.preview) {                            // v31.14 freestyle without a dog: nothing to aim by yet
    g.fillStyle = '#7fd6ff'; g.font = `600 ${15 * dpr}px system-ui`; g.textAlign = 'center';
    g.fillText(run.fs.cast == null ? 'FREESTYLE · click your dog in the dog-watch to see its Nut bars' : 'FREESTYLE · cast marked, no dog picked', W / 2, H / 2 - 6 * dpr);
    g.fillStyle = '#8ea3b2'; g.font = `${11 * dpr}px system-ui`; g.fillText(`${fsKeyName()} = back to the app's cast time`, W / 2, H / 2 + 14 * dpr); g.textAlign = 'left'; return; }
  const lastZ = z && run.pol === 'zone' && z.zones.length ? z.zones[z.zones.length - 1][1] : T + 8 * sec;
  const v0 = live ? t - 2.5 * sec : Math.max(1, T - 3 * sec);
  const span = live ? 16 * sec : Math.max(14 * sec, Math.min(45 * sec, lastZ + 3 * sec - v0));
  const X = v => (v - v0) / span * W;
  const relWin = L.relWin !== false;                                // v32.6: off = no lane of bites / release band, the odds take the height
  const lane1 = relWin ? [8 * dpr, 64 * dpr] : [8 * dpr, 196 * dpr], lane2 = relWin ? [84 * dpr, 186 * dpr] : [196 * dpr, 196 * dpr];
  g.font = `${10 * dpr}px system-ui`;
  if (plan.k) { g.fillStyle = '#b48cff2a'; g.fillRect(X(1), 0, X(plan.whistleEnd) - X(1), H); g.fillStyle = '#b48cff'; g.fillText(`♪ mash C-right ×${plan.k}`, X(1) + 3 * dpr, H - 30 * dpr); }
  if (T - R0() > 37500 / viMs()) { const a = 33000 / viMs() + 1 + R0(), b = 38000 / viMs() + 1 + R0(); g.fillStyle = '#f0b35a22'; g.fillRect(X(a), 0, X(b) - X(a), lane1[1]); g.fillStyle = '#f0b35a'; g.fillText('push SE', X(a) + 3 * dpr, lane1[1] - 4 * dpr); }
  // lane 1: P(Nut) for a cast at each moment (selected policy)
  let P = curveC(plan, run.pol);
  /* v30.25: with a dog picked the cast is aimed at a Nut on ANY bite of that line: the lane shows that curve (the part
     above the 1st / 2nd-bite bars is purple = a Nut on bite 3+), so the aim stands on the top of what is drawn */
  const anyCv = run.dw && run.dw.anyCv && run.dw.pick && plan._dw ? run.dw.anyCv : null, P12 = P;
  if (anyCv) { if (!anyCv.arr || anyCv.sigTag !== sigTag()) { const a = new Float32Array(P.length); for (let v = Math.max(1, anyCv.lo); v < a.length && v <= anyCv.hi; v++) a[v] = anyCv.at(v) || 0; anyCv.arr = a; anyCv.sigTag = sigTag(); } P = anyCv.arr; }
  let ym = 0.05;
  for (let v = Math.max(1, Math.floor(v0)); v < Math.min(P.length, v0 + span); v++) if (!isNaN(P[v])) ym = Math.max(ym, P[v]);
  /* v30.10: every cast candidate is coloured by the bite its Nut comes on - green = bite 1, gold = bite 2 (the bar is
     split by the two policies' shares; bite 3+ is rare and shown purple on the bite lane) */
  const step = Math.max(1, Math.floor(span / W * 2));
  const P1 = run.pol === 'zone' ? curveC(plan, 'bite1') : null, P2 = run.pol === 'zone' ? curveC(plan, 'hold') : null;
  for (let v = Math.max(1, Math.floor(v0)); v < Math.min(P.length, v0 + span); v += step) {
    if (isNaN(P[v])) continue;
    const hAll = P[v] / ym * (lane1[1] - lane1[0]), x = X(v), bwid = Math.max(1, X(v + step) - X(v));
    const h = anyCv ? Math.min(hAll, (P12[v] || 0) / ym * (lane1[1] - lane1[0])) : hAll;
    if (anyCv && hAll > h) { g.fillStyle = BITECOL[3] + '99'; g.fillRect(x, lane1[1] - hAll, bwid, hAll - h); }
    let f1 = run.pol === 'bite1' ? 1 : 0;
    if (P1) { const a1 = P1[v] || 0, a2 = (P2 && P2[v]) || 0; f1 = a1 + a2 > 0 ? a1 / (a1 + a2) : 1; }
    if (f1 > 0) { g.fillStyle = BITECOL[1] + '99'; g.fillRect(x, lane1[1] - h * f1, bwid, h * f1); }
    if (f1 < 1) { g.fillStyle = BITECOL[2] + '99'; g.fillRect(x, lane1[1] - h, bwid, h * (1 - f1)); }
  }
  g.fillStyle = '#8ea3b2'; g.fillText(`P(Nut) if you cast here (${anyCv ? 'your picked dog, any bite' : POLNAME[run.pol]}) — Nut on:`, 4 * dpr, lane1[0] + 8 * dpr);
  { /* v30.25 self-check, drawn on the lane: is the aim on the top of this curve among the casts still possible? */
    const chk = aimCheck(P, T, live ? t : null);
    run.aimChk = chk;
    if (chk) { const txt = chk.ok ? `✓ aim ${pct(chk.pAim)} = the best cast ${chk.ahead ? 'still ahead' : 'of this curve'}` : `aim ${pct(chk.pAim)} · best ${chk.ahead ? 'still ahead' : ''} ${pct(chk.pBest)} at ${fmtS(chk.tBest)} — ${chk.why}`;
      g.font = `${10 * dpr}px system-ui`; g.textAlign = 'right'; g.fillStyle = chk.ok ? '#5fd38d' : '#f0b35a'; g.fillText(txt, W - 6 * dpr, lane1[0] + 8 * dpr); g.textAlign = 'left'; } }
  { let lx = 4 * dpr + g.measureText(`P(Nut) if you cast here (${POLNAME[run.pol]}) — Nut on:`).width + 6 * dpr;
    for (const [n, lab] of [[1, 'bite 1'], [2, 'bite 2'], [3, 'bite 3+']]) { g.fillStyle = BITECOL[n]; g.fillRect(lx, lane1[0] + 1 * dpr, 8 * dpr, 8 * dpr); g.fillText(lab, lx + 11 * dpr, lane1[0] + 8 * dpr); lx += 11 * dpr + g.measureText(lab).width + 8 * dpr; } }
  { let pe = P.length - 1; while (pe > 1 && isNaN(P[pe])) pe--;                 // v30.2: where the cast tables end
    if (X(pe) < W && X(pe) > 0) { g.strokeStyle = '#8ea3b2'; g.setLineDash([3 * dpr, 3 * dpr]); g.lineWidth = dpr; g.beginPath(); g.moveTo(X(pe), lane1[0]); g.lineTo(X(pe), lane1[1]); g.stroke(); g.setLineDash([]);
      g.fillStyle = '#8ea3b2'; g.fillText('end of the cast tables: no casts tested after ' + fmtS(pe), X(pe) + 4 * dpr, lane1[1] - 16 * dpr); } }
  /* v30.22 (Thomas, 2026-11-19): one cast indicator. The bold CAST line is where the white line must be when you press:
     the aimed moment moved by your B-press habit (the same moment as the lamp's CAST cue). The ghost line in the same
     colour is the aimed moment itself, where the cast should land. In cast practice the line stays on the aim: there
     the habit is what is being measured. */
  const cOff = run.practice ? 0 : cueCorr() / viMs(), Tc = T + cOff, ghost = Math.abs(cOff) >= 0.5;
  if (ghost) { g.strokeStyle = '#6fb7ff55'; g.lineWidth = 2 * dpr; g.setLineDash([4 * dpr, 4 * dpr]); g.beginPath(); g.moveTo(X(T), lane1[0]); g.lineTo(X(T), lane2[1]); g.stroke(); g.setLineDash([]); }
  g.strokeStyle = '#6fb7ff'; g.lineWidth = 2.5 * dpr; g.beginPath(); g.moveTo(X(Tc), lane1[0]); g.lineTo(X(Tc), lane2[1]); g.stroke();
  g.fillStyle = '#6fb7ff'; g.font = `bold ${11 * dpr}px system-ui`;
  { const lab = 'CAST ' + fmtS(Tc), right = cOff <= 0; g.textAlign = ghost && !right ? 'left' : ghost ? 'right' : 'left';
    g.fillText(lab, X(Tc) + (g.textAlign === 'right' ? -4 : 3) * dpr, lane1[0] + 22 * dpr);
    if (ghost) { g.fillStyle = '#6fb7ff99'; g.font = `${10 * dpr}px system-ui`; g.textAlign = right ? 'left' : 'right';
      g.fillText(`aim ${fmtS(T)} · you press ${Math.abs(Math.round(cOff * viMs()))} ms ${cOff < 0 ? 'late' : 'early'}`, X(T) + (right ? 4 : -4) * dpr, lane1[0] + 36 * dpr); }
    g.textAlign = 'left'; g.fillStyle = '#6fb7ff'; g.font = `bold ${11 * dpr}px system-ui`; }
  if (relWin) { g.fillStyle = '#6fb7ffaa'; g.fillRect(X(T + G_CAST) - 1, lane2[0] - 6 * dpr, 2, 10 * dpr);
    g.font = `${9 * dpr}px system-ui`; g.fillText('plop', X(T + G_CAST) + 2 * dpr, lane2[0] - 1 * dpr); }
  // lane 2: bites after this cast. Zones (release), first-bite Nuts (green), first bites overall (grey), second-bite Nuts when holding (yellow)
  if (z && relWin) {
    g.font = `${10 * dpr}px system-ui`;
    const hb = held() && !run.tapInfo.released, nbx = nextBite();
    const bands = hb ? (run.tapInfo.dud ? [] : run.tapInfo.spans2.map(([a, b]) => [a, b + WINDOW_VI])) : run.pol === 'zone' && !held() ? z.zones : [];
    for (const [a, b] of bands) {
      g.fillStyle = hb ? '#e7c14a33' : '#5fd38d33'; g.fillRect(X(a), lane2[0], Math.max(2, X(b) - X(a)), lane2[1] - lane2[0]);
      g.fillStyle = hb ? '#ffd54a' : '#5fd38d'; g.fillText(hb ? `bite ${nbx}: release` : 'release', X(a) + 2 * dpr, lane2[0] + 22 * dpr);
    }
    if (hb && !run.tapInfo.dud) for (const [a, b] of run.tapInfo.holds2 || []) {     // v30: a bite here -> keep holding (a later Nut)
      g.fillStyle = '#b48cff2e'; g.fillRect(X(a), lane2[0], Math.max(2, X(b + WINDOW_VI) - X(a)), lane2[1] - lane2[0]);
      g.fillStyle = '#b48cff'; g.fillText(`bite ${nbx}: hold on`, X(a) + 2 * dpr, lane2[0] + 34 * dpr);
    }
    { const rl = live ? releaseLine(t) : null;                    // v30.21: blind-release curve and the release line
      if (rl) { const c = rl.curve, pk = Math.max(rl.p, 0.02), yb = lane2[1], hh2 = (lane2[1] - lane2[0]) * 0.55;
        g.strokeStyle = '#ff7ad988'; g.lineWidth = 1.5 * dpr; g.beginPath(); let pen = false;
        for (let v = Math.max(c.lo, Math.floor(v0)); v < Math.min(c.N, v0 + span); v++) { const yy = yb - c.Pr[v] / pk * hh2; if (pen) g.lineTo(X(v + rl.cue - rl.r), yy); else { g.moveTo(X(v + rl.cue - rl.r), yy); pen = true; } }
        g.stroke();
        if (Math.abs(rl.cue - rl.r) >= 0.5) { g.strokeStyle = '#ff7ad955'; g.lineWidth = 2 * dpr; g.setLineDash([4 * dpr, 4 * dpr]); g.beginPath(); g.moveTo(X(rl.r), lane2[0] - 4 * dpr); g.lineTo(X(rl.r), lane2[1]); g.stroke(); g.setLineDash([]); }   // ghost: the moment itself
        g.strokeStyle = '#ff7ad9'; g.lineWidth = 2.5 * dpr; g.beginPath(); g.moveTo(X(rl.cue), lane2[0] - 4 * dpr); g.lineTo(X(rl.cue), lane2[1]); g.stroke();
        g.fillStyle = '#ff7ad9'; g.font = `bold ${11 * dpr}px system-ui`; g.fillText(`RELEASE ${fmtS(rl.cue)} · blind ${pct(rl.p)}`, X(rl.cue) + 4 * dpr, lane2[0] + 46 * dpr); g.font = `${10 * dpr}px system-ui`; } }
    let mf = 1e-9, mn = 1e-9, m2 = 1e-9;
    const holdish = run.pol === 'hold' || run.pol === 'tap', d2 = holdish ? z.d2all : z.d2n;
    for (let i = 0; i < z.d1n.length; i++) { mf = Math.max(mf, z.d1f[i] + z.d1n[i]); mn = Math.max(mn, z.d1n[i]); m2 = Math.max(m2, d2[i]); }
    const bw = z.binVI, base = lane2[1], hh = lane2[1] - lane2[0] - 28 * dpr;
    for (let i = 0; i < z.d1n.length; i++) {
      const x = X(i * bw), w = Math.max(1.5 * dpr, X((i + 1) * bw) - x - 1);
      if (x > W || x + w < 0) continue;
      const hf = (z.d1f[i] + z.d1n[i]) / mf * hh * 0.45;
      g.fillStyle = '#5b6f7f88'; g.fillRect(x, base - hf, w, hf);
      if (!holdish && z.d1n[i] > 0) { const hn = z.d1n[i] / mn * hh; g.fillStyle = '#5fd38d'; g.fillRect(x, base - hn, w, hn); }
      if (run.pol !== 'bite1' && d2[i] > 0) { const h2 = d2[i] / m2 * hh * 0.8; g.fillStyle = run.tapInfo ? '#e7c14a55' : '#e7c14a'; g.fillRect(x + w * 0.25, base - h2, Math.max(1, w * 0.5), h2); }
    }
    if (z.d3 && z.d3.size && run.pol !== 'bite1' && !run.tapInfo) {                 // v30.2: Nut on bite 3+ (purple), by its time
      let m3 = 1e-9; for (const v of z.d3.values()) m3 = Math.max(m3, v);
      const sc3 = Math.min(1, m3 / m2) * 0.8;                                      // on the second-bite Nuts' scale
      for (const [bn, v] of z.d3) { const x = X(bn * bw), w = Math.max(1.5 * dpr, X((bn + 1) * bw) - x - 1); if (x > W || x + w < 0) continue;
        const h3 = Math.max(2 * dpr, v / m3 * hh * sc3); g.fillStyle = '#b48cff'; g.fillRect(x + w * 0.25, base - h3, Math.max(1, w * 0.5), h3); }
    }
    g.fillStyle = '#8ea3b2';
    g.fillText((z.d3 && z.d3.size && run.pol !== 'bite1' && !run.tapInfo ? 'purple: Nut on bite 3+ · ' : '') + (run.pol === 'zone' ? 'grey: first bites · green: Nut if you release that first bite · gold: Nut on the second bite when you held · band: release zone'
      : run.pol === 'bite1' ? 'grey: first bites · green: Nut when you release at that first bite'
      : run.pol === 'tap' ? 'grey: first bites (hold through, tap the key) · gold: Nut on the second bite · after your tap: bright gold = where the Nut bite 2 can still come'
      : 'grey: first bites (hold through) · gold: Nut on the second bite'), 4 * dpr, lane2[0] + 8 * dpr);
    const ti = run.tapInfo;
    if (ti && ti.holdish) {
      g.setLineDash([4 * dpr, 3 * dpr]); g.strokeStyle = '#ffffff'; g.lineWidth = 1.5 * dpr;
      for (const [m, tt] of ti.taus.entries()) {
        g.beginPath(); g.moveTo(X(tt), lane2[0]); g.lineTo(X(tt), lane2[1]); g.stroke();
        g.fillStyle = '#ffffff'; g.fillText(`tap ${m + 1}`, X(tt) + 3 * dpr, lane2[0] + 20 * dpr);
      }
      g.setLineDash([]);
      const bins = {}; let mx = 1e-9, nb = ti.taus.length + 1;
      if (!ti.released) for (const e of ti.sc) { const bm = LuckyCore.biteAt(e, nb); if (bm && bm[1]) { const b = Math.floor(bm[0] / 6); bins[b] = (bins[b] || 0) + e.w; mx = Math.max(mx, bins[b]); } }
      for (const [b, v] of Object.entries(bins)) { const x = X(+b * 6), w = Math.max(2 * dpr, X(+b * 6 + 6) - x - 1), h = v / mx * hh; g.fillStyle = '#ffd54a'; g.fillRect(x, base - h, w, h); }
    }
    const nutIm = JACK && L.figure !== 'stick' && JACK.extras.nut ? jimg(JACK.extras.nut.frames[0]) : null;
    for (let i = 0; i < z.d1n.length; i++) if ((!holdish && z.d1n[i] > 0.35 * mn) || (holdish && d2[i] > 0.35 * m2)) {
      const x = X((i + 0.5) * bw + G_CATCH), y = lane2[1] + 12 * dpr;
      if (nutIm && nutIm.complete && nutIm.naturalWidth) { g.imageSmoothingEnabled = false; g.drawImage(nutIm, x - 8 * dpr, y - 8 * dpr, 16 * dpr, 16 * dpr); }
      else drawNut(g, x, y, 5 * dpr, false);
    }
  }
  g.fillStyle = '#8ea3b2'; g.font = `${10 * dpr}px ui-monospace,monospace`;
  const s0 = Math.ceil((v0 - 1) / sec), s1 = (v0 + span - 1) / sec, every = span / sec > 24 ? 2 : 1;
  for (let k = s0; k <= s1; k++) { if (k % every) continue; const x = X(k * sec + 1); g.fillRect(x, H - 14 * dpr, 1, 4 * dpr); g.fillText(k + 's', x + 2, H - 3 * dpr); }
  if (live) { drawWake(g, X, 0, H - 16 * dpr, dpr, W); g.strokeStyle = '#ffffff'; g.lineWidth = 2 * dpr; g.beginPath(); g.moveTo(X(t), 0); g.lineTo(X(t), H); g.stroke(); }
  const pr = run.practice;
  if (pr && pr.last && Number.isFinite(pr.last.e) && pr.state !== 'armed') {   // your last practice press vs the CAST line
    const xp = X(T + pr.last.e / viMs());
    g.strokeStyle = '#ff9a50'; g.lineWidth = 3 * dpr; g.beginPath(); g.moveTo(xp, lane1[0]); g.lineTo(xp, lane2[1]); g.stroke();
    g.fillStyle = '#ff9a50'; g.font = `bold ${12 * dpr}px system-ui`; g.fillText('you ' + msTxt(pr.last.e), xp + 4 * dpr, lane1[0] + 40 * dpr);
  }
  if (pr && !L.pracLine && pr.state === 'armed') {             // beeps only: nothing to watch
    g.fillStyle = '#0b1219'; g.fillRect(0, 0, W, H);
    g.fillStyle = '#8ea3b2'; g.font = `${13 * dpr}px system-ui`; g.fillText(L.audio ? 'beeps only — eyes on the TV, press on the last beep' : 'pulses only — the lamp pulses 3-2-1: press on CAST', 12 * dpr, H / 2);
  }
}

/* ---------------------------------------------------------------- cast practice (v29.8)
   The same cues as an attempt with the current plan: the scrolling timeline with the CAST line, the "Cast in" countdown,
   the angler and the four countdown beeps. Press the start key (or any button of a connected controller) on the last
   beep. Each press is logged vs the cue (event time, ms; + = late). Quick mode starts each cast 4 s before the cue;
   full mode waits for a start-key press and runs the whole plan (start → cast) like an attempt. "Moving cast line" off
   = beeps only, as in a real attempt with your eyes on the TV. The profile (median = bias, MAD-trimmed SD = spread)
   sets the beep correction and the timing spread: spread = hypot(press SD, start-key SD 60 ms). */
const PRAC = { lead: 4000, win: 600, gap: [1100, 2300], keep: 300, startSd: 60 };
let pracLog = store.get('hm64v29_lucky_castprac', null);
if (!Array.isArray(pracLog)) pracLog = (store.get('hm64v29_lucky_prac', []) || []).filter(Number.isFinite)
  .map(e => ({ at: 0, e: Math.round(e), m: 'beeps', src: 'B key' }));   // the old beep drill's presses
const pracMode = () => (L.pracLine ? 'line' : 'beeps');      // 'beeps' = cues without the moving line (pulses / beeps)
const PRAC_MODE_A = { line: 'moving line + beeps', beeps: 'beeps only' }, PRAC_MODE_V = { line: 'moving line + bar + pulses', beeps: 'pulses only' };
const PRAC_MODE = new Proxy({}, { get: (o, k) => (L.audio ? PRAC_MODE_A : PRAC_MODE_V)[k] });
const cueKind = r => (r.v ? 'v' : 'a');                       // v29.10: presses to the visual cue (v) vs to beeps (a): kept apart
const evTime = e => (e && e.timeStamp > 0 && e.timeStamp < 1e11 ? e.timeStamp : now());
function castStats(es) {                                       // robust: median, then mean / SD of the presses within 3 MAD
  const v = es.filter(Number.isFinite).slice().sort((a, b) => a - b), n = v.length;
  if (!n) return null;
  const q = (a, f) => a[Math.min(a.length - 1, Math.max(0, Math.round(f * (a.length - 1))))];
  const med = q(v, 0.5), mad = 1.4826 * q(v.map(x => Math.abs(x - med)).sort((a, b) => a - b), 0.5);
  const keep = v.filter(x => Math.abs(x - med) <= Math.max(3 * mad, 40));
  const mean = keep.reduce((a, x) => a + x, 0) / keep.length;
  const sd = keep.length > 1 ? Math.sqrt(keep.reduce((a, x) => a + (x - mean) ** 2, 0) / (keep.length - 1)) : NaN;
  const GF = 2 * viMs(), within = (c, w) => v.filter(x => Math.abs(x - c) <= w).length / n;
  return { n, out: n - keep.length, med, mean, sd, raw1: within(0, GF / 2), cor1: within(med, GF / 2), cor2: within(med, GF * 1.5) };
}
const pracErrs = mode => pracLog.filter(r => r.m === mode && Number.isFinite(r.e) && cueKind(r) === (L.audio ? 'a' : 'v')).map(r => r.e);
const attemptErrs = () => tally.filter(x => Number.isFinite(x.castErrMs) && (x.v ? 'v' : 'a') === (L.audio ? 'a' : 'v')).map(x => x.castErrMs);
/* v30.27 (Thomas, 2026-11-20): one drill for the whole motion, as on the N64 - press on the CAST cue and HOLD, watch
   Jack cast, let go at the bite. `combo` practice = cast practice whose press is held: after the press the rep goes on
   (state 'hold'): Jack's cast animation (G_CAST VIs), the float out, a bite 1.4 - 5.2 s after the float lands, and the
   key coming up is the release. The press is logged exactly as a cast-practice press (same store: cue correction and
   timing spread), the release exactly as a bite-practice release (same store, m 'rel', c 1). */
function practiceStart(combo) {
  if (run.bite) biteStop();
  stop(true); engage(); run.dw = null; run.fs = null; run.fsLive = null; run.known = null;   // v31.25: nothing of the last attempt's dog-watch / freestyle carries into a drill
  run.practice = { rep: 0, cue: null, state: 'idle', last: null, timer: null, session: [], pads: {}, combo: combo != null ? !!combo : L.pracCombo !== false, hb: null, rel: null, relSession: [] };
  refresh();
  if (!L.pracFull) practiceSchedule(700);
}
function practiceStop() {
  const p = run.practice; if (!p) return;
  clearTimeout(p.timer); run.practice = null; cancelBeeps(); run.wall0 = null;
  refresh();
}
function practiceSchedule(ms) {
  const p = run.practice; if (!p) return;
  clearTimeout(p.timer); p.state = 'gap'; p.timer = setTimeout(() => practiceRep(null), ms);
}
function practiceRep(startAt) {                                 // one cast: quick (4 s lead-in) or full (from a start press)
  const p = run.practice; if (!p) return;
  cancelBeeps(); run.tapInfo = null; run.castTap = null; run.result = null; run.preview = null; run.spc = null; run.hold = null;
  const T = run.T;
  run.wall0 = startAt != null ? startAt : now() - Math.max(0, (T - 1) * viMs() - PRAC.lead);
  p.cue = run.wall0 + (T - 1) * viMs();                         // practice cue = the CAST line (no beep correction)
  [-1500, -1000, -500].forEach(d => { if (p.cue + d > now() + 30) beepAt(p.cue + d, 440, 0.06); });
  beepAt(p.cue, 880, 0.14);
  p.state = 'armed'; p.rep++; p.early = false;
  clearTimeout(p.timer); p.timer = setTimeout(() => practicePress(null), p.cue - now() + PRAC.win);
}
function practiceInput(ts, src) {                               // start key / controller button while practising
  const p = run.practice; if (!p) return false;
  if (p.state === 'idle' || (p.state === 'done' && L.pracFull && run.wall0 === null)) { if (L.pracFull) practiceRep(ts); return true; }
  return practicePress(ts, src);
}
function practicePress(ts, src) {                               // ts: press time (performance.now base); null = no press
  const p = run.practice; if (!p || p.state !== 'armed') return false;
  if (ts !== null && ts < p.cue - PRAC.win) { p.early = true; return true; }   // far too early: ignored, still armed
  clearTimeout(p.timer);
  const rec = { at: Date.now(), e: ts === null ? null : Math.round((ts - p.cue) * 10) / 10, m: pracMode(), src: src || keyName(), ...(L.audio ? {} : { v: 1 }) };
  pracLog.push(rec); pracLog = pracLog.slice(-PRAC.keep); store.set('hm64v29_lucky_castprac', pracLog);
  setTimeout(updateProfile, 0);                                  // the one-reaction fit uses your B presses
  p.session.push(rec); p.last = rec; p.state = 'done'; p.rel = null;
  renderPractice();
  if (p.combo && ts !== null) {                                  // the press is held: on to the bite
    const lands = ts + G_CAST * viMs();
    p.state = 'hold'; p.hb = { press: ts, at: lands + BP.gap[0] + Math.random() * (BP.gap[1] - BP.gap[0]), shown: null };
    return true;
  }
  p.timer = setTimeout(() => {
    if (run.practice !== p) return;
    run.wall0 = null;
    if (!L.pracFull) practiceSchedule(PRAC.gap[0] + Math.random() * (PRAC.gap[1] - PRAC.gap[0]));
  }, Math.max(0, p.cue + 900 - now()));
  return true;
}
function practiceNext(after) {                                  // combo: the rep is over, on to the next one
  const p = run.practice; if (!p) return;
  clearTimeout(p.timer);
  p.timer = setTimeout(() => { if (run.practice !== p) return; run.wall0 = null; p.state = 'done'; if (!L.pracFull) practiceSchedule(PRAC.gap[0] + Math.random() * (PRAC.gap[1] - PRAC.gap[0])); }, after);
}
function practiceRelRec(rec) {                                  // the release half of a combo rep, into the bite-practice store
  const p = run.practice;
  rec.at = Date.now(); rec.w = Math.round(bpWin()); rec.m = 'rel'; rec.c = 1;
  biteLog.push(rec); biteLog = biteLog.slice(-BP.keep); bpCache = null; store.set('hm64v30_lucky_biteprac', biteLog);
  p.rel = rec; p.relSession.push(rec); p.state = 'rdone'; p.doneAt = now();
  renderBite(); renderPractice();
  practiceNext(BP.show + 400);
}
function practiceRelease(ts, src) {                             // the held key came up
  const p = run.practice; if (!p || !p.combo || p.state !== 'hold') return false;
  const h = p.hb;
  if (h.shown == null || ts < h.shown) practiceRelRec({ r: null, k: 'early', src: src || keyName() + ' release' });
  else { const r = Math.round((ts - h.shown) * 10) / 10; practiceRelRec({ r, k: r <= bpWin() ? 'ok' : 'late', src: src || keyName() + ' release' }); }
  return true;
}
function practiceTick() {                                       // from frame(): the bite starts on a drawn frame
  const p = run.practice, n = now(); if (!p || !p.combo || p.state !== 'hold') return;
  const h = p.hb;
  if (h.shown == null && n >= h.at) h.shown = n;
  else if (h.shown != null && n - h.shown > BP.miss) practiceRelRec({ r: null, k: 'miss', src: '' });
}
function comboJack(t) {                                         // the preview during a combo rep
  const p = run.practice, vi = viMs(), n = now(), h = p.hb;
  if (p.state === 'hold') {
    const e = (n - h.press) / vi;
    if (h.shown != null) { const eb = (n - h.shown) / vi; return eb < G_PULL ? { anim: 'bite', e: eb, float: 'floatBite', ft: eb, info: '' } : { anim: 'wait', info: '' }; }
    if (e < G_CAST) return e < 4 ? { anim: 'idle', info: 'cast!' } : { anim: 'cast', e: e - 4, info: 'holding…' };
    return { anim: 'wait', float: 'float', ft: e - G_CAST, info: 'holding… let go at the bite' };
  }
  if (p.state === 'rdone' && p.rel) {
    const r = p.rel, e = (n - p.doneAt) / vi;
    if (r.k === 'ok') return e < G_CATCH - G_PULL ? { anim: 'land', e, info: `caught · ${Math.round(r.r)} ms` } : { anim: 'idle', info: `caught · ${Math.round(r.r)} ms` };
    return { anim: 'idle', info: r.k === 'late' ? `late by ${Math.round(r.r - bpWin())} ms` : r.k === 'early' ? 'let go too early' : 'missed' };
  }
  return null;
}
const comboTxt = p => { const c = p.last, r = p.rel;              // "cast +42 ms · caught 231 ms"
  const ct = !c ? '' : c.e === null ? 'cast missed' : `cast ${msTxt(c.e)}`;
  const rt = !r ? '' : r.k === 'ok' ? `caught ${Math.round(r.r)} ms` : r.k === 'late' ? `late +${Math.round(r.r - bpWin())} ms` : r.k === 'early' ? 'let go too early' : 'missed the bite';
  return [ct, rt].filter(Boolean).join(' · '); };
function applyCastProfile(quiet) {                              // beep correction = -median, spread = hypot(SD, start-key SD)
  const s = castStats(pracErrs(pracMode()));
  if (!s || s.n < 5 || !isFinite(s.sd)) { if (!quiet) $('lkPracTxt').insertAdjacentHTML('beforeend', ' <b>Need 5 presses in this mode first.</b>'); return false; }
  L.biasMs = -Math.round(s.med);                                // the manual values (used when "auto" is off in L5)
  L.sigmaMs = sigmaFrom(s.sd);
  save(); fillLSettings(); bestCache = null; ccache.clear(); persCache.clear();
  if (!(run.practice && run.practice.state === 'armed')) refresh();
  return true;
}
const msTxt = x => `${x >= 0 ? '+' : ''}${Math.round(x)} ms`;
function practiceMsg(t) {
  const p = run.practice, k = keyName();
  if (p.state === 'idle') return [`Cast practice (full wait): press ${k} as if ${startName()} — then press ${k} again on CAST (cast ${fmtS(run.T)}). Esc stops.`, ''];
  if (p.state === 'armed') {
    if (p.early && t < run.T - PRAC.win / viMs()) return ['Too early — wait for the 3-2-1', 'hold'];
    return L.pracLine ? [`Cast in ${Math.max(0, (run.T - t) * viMs() / 1000).toFixed(1)} s — press ${k} on CAST`, run.T - t < 90 ? 'go' : '']
      : [L.audio ? `Listen — press ${k} on the last (high) beep` : `Watch the lamp — press ${k} on CAST (after 3-2-1)`, ''];
  }
  if (p.state === 'hold') return [`${p.last && p.last.e !== null ? 'Cast ' + msTxt(p.last.e) + ' — ' : ''}keep holding ${k}; let go the moment the rod dips`, ''];
  if (p.state === 'rdone') return [`${comboTxt(p)}${p.rel && p.rel.k === 'ok' ? '' : p.rel && p.rel.k === 'early' ? ' — on the N64 that reels in an empty line' : ''}`, p.rel && p.rel.k === 'ok' ? 'go' : 'hold'];
  const r = p.last;
  if (!r) return [p.combo ? `Get ready: press ${k} on CAST and HOLD it, let go at the bite` : 'Get ready…', ''];
  if (r.e === null) return ['Missed — no press within 0.6 s of CAST', 'hold'];
  const gf = r.e / (2 * viMs());
  const verdictTxt = Math.abs(r.e) <= viMs() ? 'on the frame' : `${Math.abs(gf).toFixed(1)} game frames ${r.e > 0 ? 'late' : 'early'}`;
  return [`${msTxt(r.e)} — ${verdictTxt}${L.pracFull && p.state === 'done' && run.wall0 === null ? ` · ${k} for the next one` : ''}`, Math.abs(r.e) <= viMs() ? 'go' : Math.abs(r.e) <= 50 ? '' : 'hold'];
}
const pbCache = new Map();
function bestAt(sigMs) {                                        // best odds of the current plan at a timing spread
  const key = selKey() + ':' + sigMs + ':' + L.personal + ':' + profVer;
  if (!pbCache.has(key)) {
    const b = LuckyCore.best(P(planObj()), Math.max(1, sigMs / viMs()), 30 + R0());
    pbCache.set(key, Math.max(b.zone.p, b.bite1.p, b.hold.p));
  }
  return pbCache.get(key);
}
function renderPractice() {
  const btn = $('lkPractice'); if (!btn) return;
  btn.textContent = run.practice ? 'Stop practice (Esc)' : L.pracCombo !== false ? 'Cast + bite practice' : 'Cast practice';
  if ($('lkPracCombo')) $('lkPracCombo').checked = L.pracCombo !== false;
  if ($('lkCombo')) { $('lkCombo').textContent = run.practice ? 'Stop practice (Esc)' : 'Cast + bite practice'; $('lkCombo').classList.toggle('on', !!run.practice); }
  $('lkPracLine').checked = L.pracLine; $('lkPracFull').checked = L.pracFull;
  if ($('lkPracApply')) $('lkPracApply').hidden = L.biasAuto !== false && L.sigmaAuto !== false;
  const mode = pracMode(), es = pracErrs(mode), s = castStats(es), sa = castStats(attemptErrs());
  const miss = pracLog.filter(r => r.m === mode && r.e === null && cueKind(r) === (L.audio ? 'a' : 'v')).length;
  const ses = run.practice ? castStats(run.practice.session.filter(r => Number.isFinite(r.e)).map(r => r.e)) : null;
  const parts = [];
  if (!s) parts.push(`No presses yet in <b>${PRAC_MODE[mode]}</b> mode${L.audio ? '' : ' (presses made with sound are kept apart)'}. Start practice and press ${keyName()} on CAST.`);
  else {
    parts.push(`<b>${PRAC_MODE[mode]}</b>: ${s.n} press${s.n === 1 ? '' : 'es'}${miss ? ` (+${miss} missed)` : ''} · you press <b>${msTxt(s.med)}</b> vs CAST (median) · spread <b>${isFinite(s.sd) ? Math.round(s.sd) + ' ms' : '—'}</b> (1 SD${s.out ? `, ${s.out} outlier${s.out === 1 ? '' : 's'} left out` : ''})`);
    parts.push(`on the right game frame: ${Math.round(100 * s.raw1)}% as you press now, ${Math.round(100 * s.cor1)}% once the cue is shifted by ${msTxt(-s.med)} (within ±1 frame: ${Math.round(100 * s.cor2)}%)`);
    if (ses && run.practice.session.length >= 3) parts.push(`this session: ${ses.n} · ${msTxt(ses.med)} · spread ${isFinite(ses.sd) ? Math.round(ses.sd) + ' ms' : '—'}`);
    if (s.n >= 5 && isFinite(s.sd)) {
      const sig = sigmaFrom(s.sd);
      parts.push(`with this profile: cast-cue correction ${msTxt(-s.med)}, timing spread ${sig} ms (your ${Math.round(s.sd)} ms + start tap ${PRAC.startSd} + clock offset ±${Math.round(offsetSdMs())} ms) → best cast <b>${pct(bestAt(sig))}</b>` +
                 ` (in use: ${msTxt(cueCorr())}, ${sigmaMs()} ms → ${pct(bestAt(sigmaMs()))})`);
    }
  }
  if (sa) parts.push(`in real attempts (${keyName()} tapped with B): ${sa.n} casts · ${msTxt(sa.med)} vs the CAST cue · spread ${isFinite(sa.sd) ? Math.round(sa.sd) + ' ms' : '—'}`);
  $('lkPracTxt').innerHTML = parts.join('<br>');
  drawPracHist(es, s, attemptErrs());
}
function drawPracHist(es, s, ea) {                              // presses per VI (16.715 ms) vs the beep; range zooms to your spread
  const cv = $('lkPracHist'); if (!cv) return;
  const dpr = devicePixelRatio, W = cv.width = Math.max(10, cv.clientWidth * dpr), H = cv.height = 64 * dpr, g = cv.getContext('2d'), top = 13 * dpr;
  g.clearRect(0, 0, W, H);
  const R = s && isFinite(s.sd) ? Math.max(100, Math.min(300, Math.ceil((Math.abs(s.med) + 4 * s.sd) / 50) * 50)) : 300;
  const bw = viMs(), nb = Math.round(2 * R / bw), lo = -nb / 2 * bw, hi = nb / 2 * bw, X = ms => (ms - lo) / (hi - lo) * W;
  const bins = new Array(nb).fill(0), binA = new Array(nb).fill(0);
  const put = (arr, e) => { arr[Math.floor((Math.max(lo, Math.min(hi - 1e-6, e)) - lo) / bw)]++; };
  es.forEach(e => put(bins, e)); ea.forEach(e => put(binA, e));
  const mx = Math.max(1, ...bins, ...binA), base = H - 12 * dpr;
  g.fillStyle = '#6fb7ff'; bins.forEach((v, i) => { if (v) { const h = v / mx * (base - top); g.fillRect(X(lo + i * bw) + 1, base - h, Math.max(1, X(lo + (i + 1) * bw) - X(lo + i * bw) - 2), h); } });
  g.fillStyle = '#ffd54a'; binA.forEach((v, i) => { if (v) { const h = v / mx * (base - top); g.fillRect(X(lo + (i + 0.5) * bw) - 1.5 * dpr, base - h, 3 * dpr, h); } });
  g.strokeStyle = '#ffffff'; g.lineWidth = 1.5 * dpr; g.beginPath(); g.moveTo(X(0), top); g.lineTo(X(0), base); g.stroke();
  if (s) { g.strokeStyle = '#ff9a50'; g.setLineDash([3 * dpr, 3 * dpr]); g.beginPath(); g.moveTo(X(s.med), top); g.lineTo(X(s.med), base); g.stroke(); g.setLineDash([]); }
  g.fillStyle = '#8ea3b2'; g.font = `${9 * dpr}px ui-monospace,monospace`;
  const step = R > 150 ? 100 : 50;
  for (let ms = -Math.floor(R / step) * step; ms <= R; ms += step) {
    const tx = (ms > 0 ? '+' : '') + ms + (ms + step > R ? ' ms' : ''), w = g.measureText(tx).width;
    g.fillText(tx, Math.max(0, Math.min(W - w, X(ms) - w / 2)), H - 2 * dpr);
  }
  g.fillText('blue practice · yellow real casts · white CAST cue · orange median', 2 * dpr, 9 * dpr);
}

/* ---------------------------------------------------------------- v30.21 release line (Thomas, 2026-11-19)
   "A line to release on, without looking at the game." A Nut is caught when B is let go within WINDOW_VI (20 VIs) after
   the Nut bite shows; let go at any other moment the attempt is over. So for a release at stopwatch VI r the chance is
     P(r) = sum over the scenarios still possible (dog line x landed frame; after bite taps: the tap posterior)
            of weight x P(r + your timing error falls in (v, v + 20]) for a Nut bite of that scenario at v
   over every bite the tables hold that has not been tapped yet (any bite number). Your timing error on a line you can
   see coming = the B-press spread from cast practice (60 ms until 5 presses), and the line is drawn where the CAST cue
   would be drawn: shifted by your B-press habit, so that pressing as you do lands on r. The line = the best r still
   ahead; the label gives P(r) ("blind"). It is as sharp as the scenarios are: wide before any bite tap, much sharper
   after bite 1 was held and tapped. */
let relCache = { plan: null, key: '', v: null };
const relSdVI = () => { const ps = pressReady(); return Math.max(1.5, (ps && isFinite(ps.sd) ? ps.sd : 60) / viMs()); };
const phi = x => { const t = 1 / (1 + 0.2316419 * Math.abs(x)), d = 0.3989423 * Math.exp(-x * x / 2); const p = d * t * (0.3193815 + t * (-0.3565638 + t * (1.781478 + t * (-1.821256 + t * 1.330274)))); return x > 0 ? 1 - p : p; };
function relCurve() {
  if (L.relLine === false || run.wall0 === null || run.preview || run.practice || run.bite || !run.plan) return null;
  const ti = run.tapInfo;
  if (ti && (!ti.holdish || ti.released || !ti.fit || ti.saved)) return null;
  if (!ti && run.result) return null;
  const done = ti ? (ti.taus ? ti.taus.length : 1) : 0, s = relSdVI();
  const key = [done, ti ? (ti.taus || [ti.tau]).join(',') : '', run.T, run.castTap, profVer, s.toFixed(2), cueCorr(), run.dw ? run.dw.ver || 0 : 0].join(':');
  if (relCache.plan === run.plan && relCache.key === key) return relCache.v;
  let sc;
  if (ti) sc = ti.sc;
  else {
    const withCast = run.castTap !== null, Teff = run.T + cueCorr() / viMs(), b0 = (prof ? (withCast ? prof.bias0 : prof.bias) : 0) - (run.cs || 0);
    sc = LuckyCore.scen(P(run.plan), Math.round(Teff), sigVI(), b0, withCast ? Object.assign({ c: run.castTap }, castCfg()) : null);
  }
  let Z = 0, hi = 0; const items = [];
  for (const e of sc || []) {
    Z += e.w;
    for (let m = done + 1; m <= 16; m++) { const ba = LuckyCore.biteAt(e, m); if (!ba || !isFinite(ba[0])) break; if (ba[1] > 0) { const v = Math.round(ba[0]); items.push([v, e.w]); if (v > hi) hi = v; } }
  }
  let v = null;
  if (Z > 0 && items.length) {
    const N = hi + WINDOW_VI + Math.ceil(4 * s) + 2, mass = new Float64Array(N), Pr = new Float32Array(N), R3 = Math.ceil(3.5 * s), K = [];
    for (const [t, w] of items) if (t >= 0) mass[t] += w / Z;
    for (let u = -R3; u <= WINDOW_VI + R3; u++) K.push(phi((WINDOW_VI - u + 0.5) / s) - phi((-u + 0.5) / s));   // release r = v + u
    let lo = N; for (let t = 0; t < N; t++) if (mass[t] > 0) { lo = Math.min(lo, t); for (let u = -R3; u <= WINDOW_VI + R3; u++) { const r = t + u; if (r >= 0 && r < N) Pr[r] += mass[t] * K[u + R3]; } }
    v = { Pr, lo: Math.max(0, lo - R3), N, s, done, nut: items.reduce((a, x) => a + x[1], 0) / Z };
  }
  relCache = { plan: run.plan, key, v };
  return v;
}
/* v30.28 BUG FIX (found by the whole-tool lab): the line was "the best release 20 VIs or more ahead", so 0.33 s before
   the stopwatch reached it, it jumped to the next-best moment: nobody could ever let go ON it, and the lamp's RELEASE
   flash never fired. Now the chosen line is held until the stopwatch has passed it; only then (or when the bite taps
   change the curve) is the next one looked for. */
let relLock = null;                                             // { curve, r }
function releaseLine(t) {                                       // the release line now: {r, cue, p, s, done} or null
  const c = relCurve(); if (!c) { relLock = null; return null; }
  const off = cueCorr() / viMs();
  if (relLock && (relLock.curve !== c || t > Math.max(relLock.r, relLock.r + off) + 8)) relLock = null;   // passed, or new evidence
  if (!relLock) {
    const from = Math.max(c.lo, Math.ceil(t + 20), run.T + G_CAST);
    let r = -1, p = 0;
    for (let i = from; i < c.N; i++) if (c.Pr[i] > p) { p = c.Pr[i]; r = i; }
    if (r < 0 || p < 0.005) return null;
    relLock = { curve: c, r };
  }
  const r = relLock.r;
  return { r, cue: r + off, p: c.Pr[r], s: c.s, done: c.done, nut: c.nut, curve: c };
}
let relFlash = null;
function relTick(t) {                                            // one lamp flash on the line (only when it is worth a blind release)
  const rl = releaseLine(t); if (!rl || rl.p < 0.10) return;
  if (t >= rl.cue - 1 && t < rl.cue + 3 && relFlash !== rl.r) { relFlash = rl.r; cueFlash(`RELEASE · blind ${pct(rl.p)}`, 'go', 500); }
}

/* ---------------------------------------------------------------- v30.21 offsets on one line (preview panel)
   One number line, zero in the middle: the dot is the offset the app holds for you (ms), the thin ticks are the single
   measurements behind it, the tall tick is the last one, the hollow dot is where the offset stood before that last
   measurement. Filters: which offset. */
const OFFS = [['total', 'Total'], ['press', 'Cast'], ['rel', 'Release'], ['dock', 'Dock end'], ['exit', 'Ranch exit'], ['bite', 'Bite tap'], ['clock', 'Clock'], ['land', 'Landed']];
function offData(id) {
  const vi = viMs(), dots = timingDots(), dot = k => dots.find(d => d.id === k) || null, mdn = a => (a.length ? med(a) : null);
  const withPrev = (xs, f, what, unit) => { const cur = f(xs), prev = xs.length > 1 ? f(xs.slice(0, -1)) : null; return { x: cur, prev, last: xs.length ? xs[xs.length - 1] : null, xs, n: xs.length, what, unit }; };
  if (id === 'total') { const b = autoB(), corr = cueCorr(); return { x: corr - b * vi, prev: null, last: null, xs: [], n: null, what: `the CAST cue is moved by this for you = B-press habit ${msTxt(corr)} and clock shift ${msTxt(-b * vi)}` }; }
  if (id === 'press') {
    const a = pracLog.filter(r => r.m === pracMode() && Number.isFinite(r.e) && cueKind(r) === (L.audio ? 'a' : 'v')).slice(-80).map(r => [r.at || 0, r.e])
      .concat(tally.filter(x => Number.isFinite(x.castErrMs) && (x.v ? 'v' : 'a') === (L.audio ? 'a' : 'v')).slice(-40).map(x => [x.at || 0, x.castErrMs])).sort((p, q) => p[0] - q[0]).map(x => x[1]);
    return withPrev(a, xs => { const s = castStats(xs); return s ? s.med : null; }, 'your B press against the CAST cue (cast practice + cast taps); the cue is moved the other way');
  }
  if (id === 'rel') return withPrev(biteLog.filter(r => bpKind(r) === bpMode() && Number.isFinite(r.r) && r.r >= 0).map(r => r.r), xs => { const s = castStats(xs); return s ? s.med : null; }, `how long after the bite you ${bpMode() === 'rel' ? 'let go' : 'tap'} (bite practice); the bite can be caught for ${Math.round(bpWin())} ms`);
  if (id === 'dock') { const d0 = startDelay(); return withPrev(dock.slice(-40).map(x => x.ms).filter(isFinite).map(x => x - d0), mdn, 'your dock-end tap against the clock-tap delay'); }
  if (id === 'land') return withPrev(attemptList().filter(a => a.land && a.land.side).slice(0, 20).reverse().map(a => a.land.ms), mdn, 'where your casts landed against the aimed frame (early / late calls from the bite taps)');
  const d = dot(id === 'exit' ? 'exit' : id);
  return { x: d ? d.x : null, prev: null, last: null, xs: [], n: d ? d.n : 0, what: d ? d.what : '' };
}
/* v30.23 "Your dog lines": how often the runner's attempts were on each dog line, from the bite taps and the dog-watch */
function lineHabit() {
  const R = routeDef(), P0 = LuckyCore.plans[0];
  if (!P0 || !prof || !prof.n) return { n: 0, rows: [] };
  const liOf = new Map((R.sidxs || []).map((sx, li) => [sx, li])), lab = new Map(), mine = new Map();
  let W = 0, Wm = 0;
  for (const x of P0.variants) { const f = prof.factor(x.s + ':' + x.o); lab.set(x.s, (lab.get(x.s) || 0) + x.w); mine.set(x.s, (mine.get(x.s) || 0) + x.w * f); W += x.w; Wm += x.w * f; }
  const rows = [...lab.keys()].map(sx => ({ s: sx, li: liOf.has(sx) ? liOf.get(sx) : -1, lab: lab.get(sx) / W, mine: mine.get(sx) / Wm, visits: (prof.byPath[sx] || 0) * prof.n }))
    .map(r => Object.assign(r, { x: r.lab > 0 ? r.mine / r.lab : 1 })).sort((a, b) => b.visits - a.visits);
  return { n: prof.n, nTap: prof.nTap, nDog: prof.nDog, nBoth: prof.nBoth, rows };
}
let habitCache = { ver: -1, v: null };
function lineHabitCached() { if (habitCache.ver !== profVer) habitCache = { ver: profVer, v: lineHabit() }; return habitCache.v; }
const habitOfLine = li => (L.personal ? lineHabitCached().rows.find(r => r.li === li) || null : null);
function renderHabit() {
  const el = $('lkHabit'); if (!el) return;
  if ($('lkDogHabit')) $('lkDogHabit').checked = L.dogHabit === true;
  const h = lineHabitCached(), nm = r => (r.li >= 0 ? 'L' + (r.li + 1) : 'line ' + r.s);
  if (!h.n) { el.innerHTML = `<span class="mut">No attempt has told the app its dog line yet. An attempt counts when you tapped a bite (hold through bite 1 and tap bite 2 as well: that says most).</span>`; return; }
  const top = h.rows.filter(r => r.visits >= 0.05).slice(0, 10), shown = top.reduce((a, r) => a + r.visits, 0);
  el.innerHTML = `<div><b>${h.n} attempt${h.n === 1 ? '' : 's'}</b> on record: ${h.nTap - h.nBoth} from bite taps${L.dogHabit === true ? `, ${h.nDog} from the dog-watch alone, ${h.nBoth} from both` : ''}. Dog-watch records kept: ${dogLines.length}${L.dogHabit === true ? '' : ' (not counted: box below)'}.` +
    `${L.personal ? '' : ' <span style="color:#ef6f6f">"fit the plan to me" is off: the table is shown but not used.</span>'}</div>` +
    `<table class="lkkeytbl" style="margin-top:3px"><tr><th>dog line</th><th>your attempts on it</th><th>share of all runs (lab)</th><th>weight for you</th><th></th></tr>` +
    top.map(r => `<tr><td>${nm(r)}</td><td class="mono">${r.visits.toFixed(1)} <span class="mut">(${Math.round(100 * r.visits / h.n)}%)</span></td><td class="mono">${(100 * r.lab).toFixed(1)}%</td>` +
      `<td class="mono">${(100 * r.mine).toFixed(1)}%</td><td class="mono" style="color:${r.x >= 1.5 ? '#5fd38d' : r.x <= 0.67 ? '#ef6f6f' : 'inherit'}">× ${r.x.toFixed(2)}</td></tr>`).join('') + `</table>` +
    `<div class="small mut" style="margin-top:3px">"Your attempts on it" adds up each attempt's share on the line (an attempt the evidence splits over three lines counts a third on each)${h.n - shown > 0.5 ? `; ${(h.n - shown).toFixed(1)} more are spread thinly over other lines` : ''}. ` +
    `The weight starts at the lab's share and moves towards yours as attempts come in (the lab counts as 3 attempts). It is used for the cast aim and for the dog-watch's competing lines: two lines the arrows cannot separate are split by this weight.</div>`;
}
/* ---------------------------------------------------------------- v30.25 "Is the app working?", learning limits, clear data
   (Thomas, 2026-11-19: confidence at a 20% success rate; safeguards against self-correction running away; one place to
   clear the statistics.) */
function trustData() {
  const rows = tally.filter(x => x.route === route() || !x.route), withOdds = rows.filter(x => Number.isFinite(x.odds));
  const E = withOdds.reduce((a, x) => a + x.odds, 0), V = withOdds.reduce((a, x) => a + x.odds * (1 - x.odds), 0), H = withOdds.filter(x => x.hit).length, sd = Math.sqrt(V);
  const tapped = rows.filter(x => x.fit !== undefined), fit = tapped.filter(x => x.fit).length;
  const nfRows = tapped.filter(x => !x.fit && x.nofit), nfNone = nfRows.filter(x => x.nofit.k === 'none').length;
  const lands = attemptList().filter(a => a.land && Number.isFinite(a.land.ms)).slice(0, 30).map(a => a.land.ms);
  return { n: rows.length, hits: rows.filter(x => x.hit).length, nOdds: withOdds.length, E, sd, H, lo: Math.max(0, Math.floor(E - 2 * sd)), hi: Math.min(withOdds.length, Math.ceil(E + 2 * sd)),
           tapped: tapped.length, fit, nf: nfRows.length, nfNone, offShare: tapped.length >= 8 ? Math.max(0, Math.min(1, ((tapped.length - fit) / tapped.length - NOFIT.base) / (NOFIT.off - NOFIT.base))) : null, landMed: lands.length ? med(lands) : null, landN: lands.length };
}
function renderTrust() {
  const el = $('lkTrust'); if (!el) return;
  const d = trustData(), parts = [];
  parts.push(`<b>1. Do your bite taps land where the game's tables say a bite can come?</b> ` + (d.tapped ? `<b>${d.fit} of ${d.tapped}</b> tapped attempts matched a bite of a dog line at your cast (${Math.round(100 * d.fit / d.tapped)}%).` +
    ` ${d.tapped < 8 ? 'Too few to judge yet.' : d.fit / d.tapped >= 0.7 ? '<span style="color:#5fd38d">The stopwatch and the game agree: the route, the clock and the tables fit what you see.</span>' : d.fit / d.tapped >= 0.4 ? '<span style="color:#f0b35a">Mixed. Usual causes: a tap sequence that went wrong, a different morning (sparrows), a slow menu.</span>' : '<span style="color:#ef6f6f">Mostly no match: the app is not in step with your game. Check the route, the save, the start cue and the frame period before trusting any aim.</span>'}`
    : 'No tapped bites yet. Hold through bite 1 and tap Space when it bites: this is the check that does not depend on luck.') +
    (d.tapped > d.fit ? ` <b>${d.tapped - d.fit}</b> matched no dog line` + (d.nf ? ` (${d.nfNone} of the ${d.nf} examined since v30.30: no cast within ±0.75 s gives the bite on any arrival table of the route)` : '') + '.' +
      (d.offShare !== null ? ` In simulation a normal attempt on the tables fails this check about 1 time in 100, a cast 0.3–0.7 s off or the other arrival table about 1 in 10, taps that do not belong to the tables about 8 in 10: so about <b>${Math.round(100 * d.offShare)}%</b> of your tapped attempts were off the tables (menus ending later than the tables cover, another route, a start tap far off, or a tap that was not the bite).` : '') : '') +
    ` <span class="mut">This is the strong test: a bite time is fixed by the dog line and the cast frame, whether or not it is a Nut, so every tapped bite tests the sync.</span>`);
  parts.push(`<b>2. Do the Nuts come as often as the odds say?</b> ` + (d.nOdds ? `${d.nOdds} logged attempt${d.nOdds === 1 ? '' : 's'} with their odds on record: the app expected <b>${d.E.toFixed(1)}</b> Nuts, luck alone makes that anywhere from ${d.lo} to ${d.hi}; you got <b>${d.H}</b>` +
    ` — ${d.H < d.lo ? '<span style="color:#ef6f6f">fewer than luck explains: the odds shown are too high for your play</span>' : d.H > d.hi ? '<span style="color:#5fd38d">more than luck explains</span>' : 'inside what luck explains'}.`
    : `No attempt logged with its odds yet (kept from v30.25 on; ${d.n} older attempts, ${d.hits} Nuts).`) +
    ` <span class="mut">At odds near 20%, 30 attempts give 6 Nuts ± 4 by luck alone, so a session cannot tell a working tool from a broken one this way; about 100 attempts can tell 20% from 10%.</span>`);
  if (d.landN >= 5) parts.push(`<b>3. Where your casts land</b> (from the bite taps, last ${d.landN}): median ${msTxt(d.landMed)} from the aimed frame. ${Math.abs(d.landMed) <= 50 ? 'On target.' : 'The clock shift below is what corrects this.'}`);
  const ck = run.aimChk;
  if (ck) parts.push(`<b>${d.landN >= 5 ? 4 : 3}. Is the aim on the top of the curve?</b> ${ck.ok ? `<span style="color:#5fd38d">Yes</span>: the aim (${pct(ck.pAim)}) is the best cast of the curve drawn on the histogram.` : `<span style="color:#f0b35a">No</span>: aim ${pct(ck.pAim)}, best ${pct(ck.pBest)} at ${fmtS(ck.tBest)} — ${ck.why}.`} The same check is printed on the histogram at all times.`);
  parts.push(`<span class="mut">Measured in the lab: 1,496 simulated attempts through this app against the emulator gave the Nut rate the app showed (taps only 12.0%, dog-watch 28.5%).</span>`);
  el.innerHTML = parts.join('<br>');
}
function guardRows() {
  const vi = viMs(), b = autoB(), ps = pressReady(), h = lineHabitCached(), cal = typeof dwWin === 'function' ? dwWin() : null, rows = [];
  const capVI = (!prof || (prof.nCast || 0) < 8) && !bpLag() ? TIE_CAP : 18;
  const src = prof ? ((prof.nCast || 0) >= 8 ? `${prof.nCast} attempts with a cast tap` : `${prof.nNoCast || 0} bite-tapped attempts`) : 'no attempts';
  rows.push(['Clock shift', L.autoTune ? msTxt(-b * vi) : 'off', src,
    'Re-fitted from scratch each time on your last 60 bite-tapped attempts, each stored on the un-shifted stopwatch: the shift already applied is taken out before fitting, so it cannot add itself up. Pulled toward 0 (prior ±150 ms), 70% applied, nothing before 8 attempts. Without cast taps it needs your bite reaction: measured by bite practice (8+), else assumed equal to your start-tap reaction, and then the shift is held to ±100 ms.',
    capVI * 16.715 >= 290 ? '±300 ms' : '±100 ms until bite practice or cast taps back it', Math.abs(b) >= capVI ? (capVI < 18 ? 'at its limit: do bite practice (8+) so your bite reaction is measured, not assumed' : 'AT ITS LIMIT: something else is off (route, save, start cue)') : Math.abs(b) >= 12 ? 'large' : 'ok']);
  rows.push(['B-press habit (cast cue)', L.biasAuto !== false && ps ? msTxt(-ps.med) : msTxt(L.biasMs) + ' (by hand)', ps ? `${ps.n} presses` : 'under 5 presses: not used',
    'Median of your practice presses (and cast taps), each measured against the cue as it was shown: moving the cue does not change the measurement. Presses beyond 3 spreads from the median are left out.',
    'median of the last 80', 'ok']);
  rows.push(['Timing spread', sigmaMs() + ' ms', ps && isFinite(ps.sd) ? `your ±${Math.round(ps.sd)} ms + start tap + clock` : 'default', 'Root sum of squares of your press spread, one start tap (±60 ms) and how well the clock is known.', '40 – 400 ms', 'ok']);
  rows.push(['Bite-tap delay', `${Math.round(lagMu() * vi)} ms`, prof && prof.lag ? `fit of ${prof.lag.n} attempts` : bpLag() ? 'bite practice' : 'stock', 'Fitted together with the clock shift, only when 3 or more taps name their bite sharply; else bite practice (8+), else 13 frames.', '100 – 600 ms', 'ok']);
  rows.push(['Dog-line weights', h.n ? `${h.n} attempts` : 'lab weights', L.personal ? 'on' : 'off', 'Each attempt is shared out over the lines by the LAB weights, never by your own, so a favourite line cannot vote for itself. The lab counts as 3 attempts; only the last 60 count.', 'last 60 attempts', 'ok']);
  if (cal) rows.push(['Arrow reaction window', `${Math.round(cal.lo * vi)}–${Math.round(cal.hi * vi)} ms`, cal.learned ? cal.learned + ' arrows' : 'from the bite-tap delay', 'From 8 arrows on attempts whose bites named the dog line: their 10–90% range ± 50 ms.', 'upper end ≤ 750 ms', 'ok']);
  rows.push(['Early / late call', 'shown only', '', 'Never moves the aim: it is the same evidence the clock shift already uses.', '—', 'ok']);
  return rows;
}
function renderGuard() {
  const el = $('lkGuard'); if (!el) return;
  const rows = guardRows(), vi = viMs(), tot = cueCorr() - autoB() * vi;
  el.innerHTML = `<table class="lkkeytbl"><tr><th>what is learned</th><th>now</th><th>from</th><th>limit</th><th></th></tr>` +
    rows.map(r => `<tr title="${r[3].replace(/"/g, '&quot;')}"><td>${r[0]}</td><td class="mono">${r[1]}</td><td class="mut">${r[2]}</td><td class="mono">${r[4]}</td><td style="color:${r[5] === 'ok' ? '#5fd38d' : '#f0b35a'}">${r[5]}</td></tr>` +
      `<tr><td colspan="5" class="mut" style="border-bottom:1px solid #2a3b48;padding-bottom:4px">${r[3]}</td></tr>`).join('') + `</table>` +
    `<div style="margin-top:4px"><b>Total cast offset now: ${msTxt(tot)}</b> (cue ${msTxt(cueCorr())} + clock ${msTxt(-autoB() * vi)}). ` +
    `Nothing here is a running sum: every value is worked out again from the stored measurements, so one bad attempt cannot push it step by step, and removing an attempt (Attempt data) takes its effect out completely.</div>` +
    `<div class="mut" style="margin-top:3px">Switches: "learn from your bite taps" (clock shift) and the two "auto" boxes above (cue, spread); "fit the plan to me" (dog-line weights) in the plan details.</div>`;
}
/* one place to clear what the app has collected */
const DATA_SETS = [
  ['log', 'Attempt log', () => tally.length, 'the H / M / E list and its counts (L4)'],
  ['bites', 'Bite taps', () => taps.length, 'what the app learned from attempts: clock shift, bite-tap delay, early / late calls, your dog lines'],
  ['dog', 'Dog-watch records', () => dwcal.length + dogLines.length, 'the learned arrow reaction and the line records at the cast'],
  ['clock', 'Clock taps', () => tsKeys().reduce((a, k) => a + tsGet(k).length, 0) + dock.length + fade2.length, 'ranch-exit / beach / dock-end tap sets and the dock-end reflex'],
  ['cast', 'Cast practice', () => pracLog.length, 'your B presses on the CAST line: cue correction and timing spread'],
  ['biteprac', 'Bite practice', () => biteLog.length, 'your reactions to the bite animation']];
function clearStats(which) {
  const all = which === 'all', is = k => all || which === k;
  if (run.wall0 !== null) stop(true);
  if (is('log')) { tally = []; store.set('hm64v29_lucky_tally', tally); }
  if (is('bites')) { taps = []; store.set('hm64v29_lucky_taps', taps); }
  if (is('dog')) { dwcal = []; store.set('hm64v30_dwcal', dwcal); dogLines = []; store.set('hm64v30_doglines', dogLines); }
  if (is('clock')) { for (const k of tsKeys()) tsPut(k, []); fade2 = []; dock = []; store.set('hm64v29_lucky_fade2', fade2); store.set('hm64v29_lucky_dock', dock); }
  if (is('cast')) { pracLog = []; store.set('hm64v29_lucky_castprac', pracLog); }
  if (is('biteprac')) { biteLog = []; bpCache = null; store.set('hm64v30_lucky_biteprac', biteLog); }
  lastRemoved = null;
  relearn(); renderTally(); renderAttempts(); renderData();
}
function renderData() {
  const el = $('lkData'); if (!el) return;
  const tot = DATA_SETS.reduce((a, d) => a + d[2](), 0);
  el.innerHTML = `<table class="lkkeytbl">` + DATA_SETS.map(d => `<tr><td><b>${d[1]}</b></td><td class="mono">${d[2]()}</td><td class="mut">${d[3]}</td><td><button type="button" class="lkkeybtn" data-clear="${d[0]}"${d[2]() ? '' : ' disabled'}>Clear</button></td></tr>`).join('') + `</table>` +
    `<div class="row" style="margin-top:5px"><button type="button" id="lkClearAll"${tot ? '' : ' disabled'} style="border-color:#ef6f6f;color:#ffb3b3">Clear all stats</button><span class="small mut">Settings, key assignments, the route and the panel order are kept. A single attempt is removed under L4 → Attempt data.</span></div>`;
  el.querySelectorAll('[data-clear]').forEach(b => { b.onclick = () => { const d = DATA_SETS.find(x => x[0] === b.dataset.clear); if (confirm(`Clear "${d[1]}" (${d[2]()} records)? ${d[3]}. This cannot be undone.`)) clearStats(d[0]); }; });
  if ($('lkClearAll')) $('lkClearAll').onclick = () => { if (confirm(`Clear ALL stats (${tot} records): attempt log, bite taps, dog-watch records, clock taps, cast practice, bite practice? Settings and keys are kept. This cannot be undone.`)) clearStats('all'); };
}
function renderOff() {
  const cv = $('lkOff'); if (!cv) return;
  const box = $('lkOffSel');
  if (box && !box.dataset.made) { box.dataset.made = 1; box.innerHTML = OFFS.map(([id, lab]) => `<button type="button" data-off="${id}">${lab}</button>`).join('');
    box.querySelectorAll('[data-off]').forEach(b => { b.onclick = () => { L.offSel = b.dataset.off; save(); b.blur(); renderOff(); }; }); }
  const id = OFFS.some(o => o[0] === L.offSel) ? L.offSel : 'total', o = offData(id);
  if (box) box.querySelectorAll('[data-off]').forEach(b => b.classList.toggle('on', b.dataset.off === id));
  const Wc = cv.clientWidth || 0; if (!Wc) return;
  const dpr = window.devicePixelRatio || 1, H = 46; cv.width = Wc * dpr; cv.height = H * dpr; cv.style.height = H + 'px';
  const g = cv.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, Wc, H);
  const vals = o.xs.concat(o.x != null ? [o.x] : []).map(Math.abs).sort((a, b) => a - b), top = vals.length ? vals[Math.min(vals.length - 1, Math.floor(0.9 * vals.length))] : 0;
  const R = [100, 200, 400, 800, 1600].find(r => r >= Math.max(top, Math.abs(o.x || 0)) * 1.1) || 1600, pad = 8, y = 20;
  const X = ms => pad + (Math.max(-R, Math.min(R, ms)) + R) / (2 * R) * (Wc - 2 * pad);
  g.strokeStyle = '#3a4d5c'; g.lineWidth = 1; g.beginPath(); g.moveTo(pad, y); g.lineTo(Wc - pad, y); g.stroke();
  g.fillStyle = '#8ea3b2'; g.font = '9px ui-monospace,monospace'; g.textAlign = 'center';
  for (const ms of [-R, -R / 2, 0, R / 2, R]) { g.strokeStyle = ms ? '#3a4d5c' : '#dce6ec'; g.lineWidth = ms ? 1 : 1.5; g.beginPath(); g.moveTo(X(ms), y - (ms ? 4 : 13)); g.lineTo(X(ms), y + (ms ? 4 : 13)); g.stroke(); g.fillText((ms > 0 ? '+' : '') + ms, Math.max(14, Math.min(Wc - 16, X(ms))), H - 2); }
  g.strokeStyle = '#6fb7ff66'; g.lineWidth = 1; for (const v of o.xs.slice(-40, -1)) { g.beginPath(); g.moveTo(X(v), y - 6); g.lineTo(X(v), y + 6); g.stroke(); }
  if (o.last != null) { g.strokeStyle = '#ff9a50'; g.lineWidth = 2; g.beginPath(); g.moveTo(X(o.last), y - 10); g.lineTo(X(o.last), y + 10); g.stroke(); }
  if (o.prev != null) { g.strokeStyle = '#5fd38d'; g.lineWidth = 1.5; g.beginPath(); g.arc(X(o.prev), y, 5, 0, 6.2832); g.stroke(); }
  if (o.x != null) { g.fillStyle = '#5fd38d'; g.beginPath(); g.arc(X(o.x), y, 5, 0, 6.2832); g.fill();
    g.font = 'bold 11px system-ui'; g.textAlign = X(o.x) > Wc * 0.6 ? 'right' : 'left'; g.fillText(msTxt(o.x), X(o.x) + (X(o.x) > Wc * 0.6 ? -9 : 9), y - 8); }
  const lab = OFFS.find(q => q[0] === id)[1], el = $('lkOffTxt');
  if (el) el.innerHTML = o.x == null ? `<b>${lab}</b>: no data yet${o.n ? ` (${o.n} so far)` : ''} — ${o.what}`
    : `<b>${lab}: ${msTxt(o.x)}</b>${o.n != null ? ` · ${o.n} measurement${o.n === 1 ? '' : 's'}` : ''}` +
      (o.last != null ? ` · last one <span style="color:#ff9a50">${msTxt(o.last)}</span>${o.prev != null ? ` moved it ${msTxt(o.x - o.prev)} (was ${msTxt(o.prev)})` : ''}` : '') + `<br><span class="mut">${o.what}</span>`;
}

/* ---------------------------------------------------------------- v30.19 bite practice
   The preview shows Jack with the float out; after a random wait (BP.gap) the game's bite animation plays (rod pull +
   bite float, G_PULL = 20 VIs = the release window, then the float is gone as on the console when B stays held). The
   start key (or any controller button going down or up) is the answer. The reaction is counted from the first bite
   frame the page really drew (frame() stamps it), so the page's own frame timing is not in the number. Verdict: inside
   the 20-VI window = caught, after it = late, before the bite = too early, nothing within 1 s = missed. The lamp never
   shows the bite: only the animation does. */
const bpWin = () => WINDOW_VI * viMs();
function bpStats(rows, mode) {
  rows = (rows || biteLog).filter(r => bpKind(r) === (mode || bpMode()));
  const rs = rows.filter(r => Number.isFinite(r.r) && r.r >= 0).map(r => r.r), s = castStats(rs);
  const early = rows.filter(r => r.k === 'early').length, miss = rows.filter(r => r.k === 'miss').length, w = bpWin();
  const ok = rs.filter(x => x <= w).length, late = rs.length - ok;
  return { n: rs.length, s, early, miss, ok, late, share: rs.length + miss ? ok / (rs.length + miss) : null };
}
function biteStart() {
  if (run.practice) practiceStop();
  stop(true); engage(); cancelBeeps(); run.preview = null; run.result = null; run.dw = null; run.fs = null; run.fsLive = null; run.known = null;
  const rel = bpMode() === 'rel';
  run.bite = { mode: bpMode(), state: rel ? 'ready' : 'wait', held: false, t0: now(), at: 0, shown: null, doneAt: 0, last: null, session: [], pads: {} };
  if (!rel) biteNext(500);
  renderBite();
}
/* release mode: the key (or a controller button) goes down = the line is out, the wait for a bite begins */
function biteHold(ts) {
  const b = run.bite; if (!b || b.mode !== 'rel') return false;
  if (b.held) return true;
  b.held = true;
  if (b.state === 'ready') biteNext(0);
  return true;
}
/* release mode: the key comes up = the answer */
function biteRelease(ts, src) {
  const b = run.bite; if (!b || b.mode !== 'rel') return false;
  if (!b.held) return true;
  b.held = false;
  if (b.state === 'wait' || b.state === 'bite') biteAnswer(ts, src || keyName() + ' release');
  return true;
}
function biteStop() {
  if (!run.bite) return;
  run.bite = null;
  updateProfile(); refresh(); renderBite();
}
function biteNext(lead) {
  const b = run.bite; if (!b) return;
  b.state = 'wait'; b.t0 = now(); b.shown = null;
  b.at = b.t0 + (lead || 0) + BP.gap[0] + Math.random() * (BP.gap[1] - BP.gap[0]);
}
function biteRecord(rec) {
  const b = run.bite;
  rec.at = Date.now(); rec.w = Math.round(bpWin()); rec.m = b.mode;
  biteLog.push(rec); biteLog = biteLog.slice(-BP.keep); bpCache = null; store.set('hm64v30_lucky_biteprac', biteLog);
  b.session.push(rec); b.last = rec; b.state = 'done'; b.doneAt = now();
  renderBite();
}
function biteInput(ts, src) {                                   // tap mode: a press is the answer; ts on the performance.now base
  const b = run.bite; if (!b) return false;
  if (b.mode === 'rel') return biteHold(ts);
  return biteAnswer(ts, src);
}
function biteAnswer(ts, src) {
  const b = run.bite; if (!b) return false;
  if (b.state === 'done' || b.state === 'ready') return true;   // the verdict is showing / nothing held yet
  if (b.state === 'wait' || ts < b.shown) { biteRecord({ r: null, k: 'early', src: src || keyName() }); return true; }
  const r = Math.round((ts - b.shown) * 10) / 10;
  biteRecord({ r, k: r <= bpWin() ? 'ok' : 'late', src: src || keyName() });
  return true;
}
function biteTick() {                                           // from frame(): the bite starts on a drawn frame
  const b = run.bite, n = now(); if (!b) return;
  if (b.state === 'wait' && n >= b.at) { b.state = 'bite'; b.shown = n; }
  else if (b.state === 'bite' && n - b.shown > BP.miss) biteRecord({ r: null, k: 'miss', src: '' });
  else if (b.state === 'done' && n - b.doneAt > BP.show) { if (b.mode === 'rel' && !b.held) { b.state = 'ready'; b.t0 = n; } else biteNext(0); }   // release mode: the next bite needs the key held again
  if (navigator.getGamepads) for (const gp of navigator.getGamepads()) {   // controller: a button going down or up
    if (!gp) continue;
    const prev = b.pads[gp.index], cur = gp.buttons.map(x => x.pressed);
    if (prev) { const i = cur.findIndex((v, j) => v !== prev[j]);
      if (i >= 0) { const ts = gp.timestamp > 0 && gp.timestamp < 1e11 ? gp.timestamp : n;
        if (b.mode === 'rel') { if (cur[i]) biteHold(ts); else if (!cur.some(Boolean)) biteRelease(ts, 'controller release'); }
        else biteAnswer(ts, cur[i] ? 'controller press' : 'controller release'); } }
    b.pads[gp.index] = cur;
  }
}
function biteVerdict(r) {                                       // [text, class] for one record
  const w = Math.round(bpWin());
  if (!r) return ['', ''];
  if (r.k === 'ok') return [`Caught — ${Math.round(r.r)} ms after the bite (${(r.r / viMs()).toFixed(1)} of the ${WINDOW_VI} frames, ${Math.round(w - r.r)} ms to spare)`, 'go'];
  if (r.k === 'late') return [`Late by ${Math.round(r.r - w)} ms — the bite was gone (${Math.round(r.r)} ms; the window is ${w} ms)`, 'hold'];
  if (r.k === 'early') return [bpKind(r) === 'rel' ? 'Too early — you let go before a bite: on the N64 that reels in an empty line' : 'Too early — there was no bite yet', 'hold'];
  return [`Missed — ${bpKind(r) === 'rel' ? 'still holding' : 'no tap'} ${(BP.miss / 1000).toFixed(0)} s after the bite`, 'hold'];
}
function biteMsg() {
  const b = run.bite;
  if (b.state === 'done') return biteVerdict(b.last);
  if (b.mode === 'rel') return [b.state === 'ready' ? `Bite practice: press and HOLD ${keyName()} (or a controller button) to cast. Esc stops.` : `Holding… let go of ${keyName()} the moment the rod dips. Esc stops.`, b.state === 'ready' ? 'go' : ''];
  return [`Bite practice: tap ${keyName()} the moment the rod dips (controller: any button). Esc stops.`, ''];
}
function biteCue() {
  const b = run.bite, r = b.last;
  if (b.state === 'done' && r) return { kind: r.k === 'ok' ? 'go' : 'bad', big: r.k === 'ok' ? `CAUGHT ${Math.round(r.r)} ms` : r.k === 'late' ? `LATE +${Math.round(r.r - bpWin())} ms` : r.k === 'early' ? 'TOO EARLY' : 'MISSED', sub: biteVerdict(r)[0] };
  if (b.mode === 'rel' && b.state === 'ready') return { kind: 'ready', big: `HOLD ${keyName().toUpperCase()}`, sub: 'press and hold to cast, let go at the bite' };
  return { kind: 'idle', big: b.mode === 'rel' ? 'HOLDING — LET GO AT THE BITE' : 'BITE PRACTICE', sub: 'watch Jack, not this lamp' };
}
function biteJack() {                                           // what the preview shows (Jack sprites)
  const b = run.bite, vi = viMs(), n = now();
  if (b.state === 'ready') return { anim: 'idle', info: `hold ${keyName()} to cast` };
  if (b.state === 'wait') return { anim: 'wait', float: 'float', ft: (n - b.t0) / vi, info: b.mode === 'rel' ? 'holding… let go at the bite' : 'waiting for a bite…' };
  if (b.state === 'bite') { const e = (n - b.shown) / vi; return e < G_PULL ? { anim: 'bite', e, float: 'floatBite', ft: e, info: '' } : { anim: 'wait', info: '' }; }
  const r = b.last, e = (n - b.doneAt) / vi;
  if (r.k === 'ok') return e < G_CATCH - G_PULL ? { anim: 'land', e, info: `caught · ${Math.round(r.r)} ms` } : { anim: 'idle', info: `caught · ${Math.round(r.r)} ms` };
  return { anim: r.k === 'early' ? 'wait' : 'idle', float: r.k === 'early' ? 'float' : null, ft: (n - b.t0) / vi, info: r.k === 'late' ? `late by ${Math.round(r.r - bpWin())} ms` : r.k === 'early' ? 'too early' : 'missed' };
}
function bitePose() {                                           // the same for the stick figure
  const b = run.bite, vi = viMs(), n = now();
  if (b.state === 'ready') return ['idle', 0, `hold ${keyName()} to cast`];
  if (b.state === 'wait') return ['wait', 0, b.mode === 'rel' ? 'holding… let go at the bite' : 'waiting for a bite…'];
  if (b.state === 'bite') { const e = (n - b.shown) / vi; return e < G_PULL ? ['bite', e / G_PULL, ''] : ['wait', 0, '']; }
  const r = b.last;
  return r.k === 'ok' ? ['reel', Math.min(1, (n - b.doneAt) / vi / (G_CATCH - G_PULL)), `caught · ${Math.round(r.r)} ms`] : ['idle', 0, r.k === 'late' ? `late by ${Math.round(r.r - bpWin())} ms` : r.k === 'early' ? 'too early' : 'missed'];
}
function drawBiteHist(st) {                                     // reactions per VI, 0 … 600 ms; green inside the window, red after it
  const cv = $('lkBpHist'); if (!cv || !cv.clientWidth) return;
  const dpr = devicePixelRatio, W = cv.width = Math.max(10, cv.clientWidth * dpr), H = cv.height = 64 * dpr, g = cv.getContext('2d'), top = 13 * dpr, base = H - 12 * dpr;
  g.clearRect(0, 0, W, H);
  const bw = viMs(), nb = 36, hi = nb * bw, X = ms => ms / hi * W, win = bpWin();
  const bins = new Array(nb).fill(0);
  for (const r of biteLog) if (bpKind(r) === bpMode() && Number.isFinite(r.r) && r.r >= 0) bins[Math.min(nb - 1, Math.floor(r.r / bw))]++;
  const mx = Math.max(1, ...bins);
  g.fillStyle = '#5fd38d18'; g.fillRect(0, top, X(win), base - top);
  bins.forEach((v, i) => { if (v) { const h = v / mx * (base - top); g.fillStyle = (i + 0.5) * bw <= win ? '#5fd38d' : '#ef6f6f'; g.fillRect(X(i * bw) + 1, base - h, Math.max(1, X(bw) - 2), h); } });
  g.strokeStyle = '#ffffff'; g.lineWidth = 1.5 * dpr; g.beginPath(); g.moveTo(X(win), top); g.lineTo(X(win), base); g.stroke();
  if (st.s) { g.strokeStyle = '#ff9a50'; g.setLineDash([3 * dpr, 3 * dpr]); g.beginPath(); g.moveTo(X(st.s.med), top); g.lineTo(X(st.s.med), base); g.stroke(); g.setLineDash([]); }
  g.fillStyle = '#8ea3b2'; g.font = `${9 * dpr}px ui-monospace,monospace`;
  for (let ms = 0; ms <= hi; ms += 100) { const tx = ms + (ms + 100 > hi ? ' ms' : ''), w = g.measureText(tx).width; g.fillText(tx, Math.max(0, Math.min(W - w, X(ms) - w / 2)), H - 2 * dpr); }
  g.fillText('green caught · red late · white end of the bite window · orange median', 2 * dpr, 9 * dpr);
}
function biteSummary() {                                        // the lines under the histogram
  const st = bpStats(), vi = viMs(), w = Math.round(bpWin()), parts = [], rel = bpMode() === 'rel';
  const other = biteLog.filter(r => bpKind(r) !== bpMode()).length, otherTxt = other ? ` <span class="mut">(${other} ${rel ? 'tap' : 'release'} record${other === 1 ? '' : 's'} from the other mode are kept and shown when you switch.)</span>` : '';
  if (!st.n && !st.miss && !st.early) return { st, html: (rel ? `No bites yet. Start, press and HOLD ${keyName()} (as you hold B), watch Jack, and let go the moment the rod dips.` : `No bites yet. Start, watch Jack and tap ${keyName()} the moment the rod dips.`) + ` A bite can be caught for ${WINDOW_VI} video frames = ${w} ms.` + otherTxt };
  if (st.s) {
    parts.push(`<b>${st.n + st.miss} bite${st.n + st.miss === 1 ? '' : 's'}: caught ${Math.round(100 * st.share)}%</b> (${st.ok} inside the ${w} ms window, ${st.late} late${st.miss ? `, ${st.miss} missed` : ''}${st.early ? ` · ${st.early} ${rel ? 'let go' : 'tapped'} too early, not counted` : ''})` + otherTxt);
    parts.push(`your ${rel ? 'release' : 'tap'} reaction: <b>${Math.round(st.s.med)} ms</b> (median = ${(st.s.med / vi).toFixed(1)} video frames) · spread <b>${isFinite(st.s.sd) ? '±' + Math.round(st.s.sd) + ' ms' : '—'}</b> · room before the window closes: ${Math.round(w - st.s.med)} ms${isFinite(st.s.sd) && st.s.sd > 0 ? ` = ${((w - st.s.med) / st.s.sd).toFixed(1)} spreads` : ''}`);
    const fit = prof && prof.lag && prof.lag.n >= 3;
    if (fit) { const d = lagMu() * vi - st.s.med;
      parts.push(`in your attempts the bite taps come <b>${Math.round(lagMu() * vi)} ms</b> after the forecast bite (${prof.lag.n} attempts): ${Math.abs(d) < 25 ? 'the same as here — the stopwatch and the TV agree' : `${Math.round(Math.abs(d))} ms ${d > 0 ? 'later' : 'earlier'} than here (${d > 0 ? 'TV delay, attention on holding B, or the stopwatch running ahead of the console' : 'the stopwatch running behind the console, or bites you saw coming'})`}`); }
    else { const u = bpLag(), kind = bpReactKind();              // what the bite-tap delay rests on (a press reaction is wanted)
      parts.push(u ? `in use as your bite-tap delay: ${(u.med / vi).toFixed(1)} ± ${Math.max(2.5, u.sd / vi).toFixed(1)} video frames, from your ${u.n} ${kind === 'tap' ? 'tap' : 'release'} reactions` +
          (kind === 'rel' ? ' (a stand-in: in an attempt you PRESS Space at the bite; 8 reactions in tap mode would measure that itself)' : '') + `; the stock value is ${OS.tapMuVI || 13} ± ${Math.max(2.5, OS.tapSdVI || 3.5)}`
        : L.bpUse === false ? 'not in use (box below is off): the bite-tap delay stays at its stock value' : `${Math.max(1, BP.min - st.n)} more reaction${BP.min - st.n === 1 ? '' : 's'} and it replaces the stock bite-tap delay (${OS.tapMuVI || 13} video frames)`); }
  } else parts.push(`${st.early} too early, ${st.miss} missed — no reaction measured yet`);
  if (run.bite && run.bite.session.length >= 3) { const ss = bpStats(run.bite.session); if (ss.s) parts.push(`this session: ${ss.n + ss.miss} bites · caught ${Math.round(100 * ss.share)}% · ${Math.round(ss.s.med)} ms`); }
  return { st, html: parts.join('<br>') };
}
function renderBite() {
  const on = !!run.bite, sm = biteSummary(), st = sm.st;
  for (const id of ['lkBite', 'lkBite2']) if ($(id)) { $(id).textContent = on ? 'Stop bite practice (Esc)' : 'Bite practice'; $(id).classList.toggle('on', on); }
  if ($('lkBiteSum')) $('lkBiteSum').textContent = st.s ? `caught ${Math.round(100 * st.share)}% · ${Math.round(st.s.med)} ms${isFinite(st.s.sd) ? ' ±' + Math.round(st.s.sd) : ''} · ${st.n + st.miss} bites` : '';
  if ($('lkBpUse')) $('lkBpUse').checked = L.bpUse !== false;
  if ($('lkBpMode')) $('lkBpMode').checked = bpMode() === 'tap';
  if ($('lkBpTxt')) $('lkBpTxt').innerHTML = sm.html;
  drawBiteHist(st);
  renderOff();
}
function biteForget() { biteLog = []; bpCache = null; store.set('hm64v30_lucky_biteprac', biteLog); updateProfile(); refresh(); renderBite(); }

/* ---------------------------------------------------------------- settings */
function fillLSettings() {
  syncTimingInputs();
  const dog = anchor() === 'dog', R = routeDef();
  const rs = $('lkRoute');
  if (rs) {
    const bases = LuckyCore.routes().filter(r => !r.variant_of && !(r.id === 'carry' && PG && PG.carry === false));
    rs.innerHTML = bases.map(r => `<option value="${r.id}">${r.label}</option>`).join('');
    rs.value = baseOf(route()); rs.disabled = bases.length < 2;
  }
  $('lkAnchor').innerHTML = (R.anchors || []).map(a => `<option value="${a.id}">${a.id === 'dog' ? 'when the dog lands (recommended)' : R.groups ? a.label + (a.id === R.anchors[0].id ? ' (recommended)' : '') : a.id === 'beach' ? 'at beach entry (recommended)' : a.label}</option>`).join('');
  $('lkAnchor').value = anchor(); $('lkAnchor').disabled = R.id === 'carry' && !D.pace;
  labelStarts();
  $('lkStartDelayLbl').textContent = dog ? 'Dog-landing key delay (ms)' : 'Start-tap delay, every start (ms)';
  $('lkStartDelay').value = startDelay();
  $('lkStartDelayHint').textContent = dog ? '−130 = key together with your A press (the dog lands 8 frames after A) · about +150 = key when you see it land'
    : 'how late your start / clock taps come after their cue (ranch exit, beach cue, dock end, READY): one value for every start; ticked, your bite taps add what they measure on this start';
  $('lkFacing').value = L.facing; $('lkZoneBeeps').checked = L.zoneBeeps; $('lkAudio').checked = L.audio;
  if ($('lkCueGlow')) $('lkCueGlow').checked = L.cueGlow;
  $('lkCastTap').checked = L.castTap; $('lkTapPrec').value = L.tapPrecMs;
  $('lkStartKey').textContent = L.startKey === ' ' ? 'Space' : L.startKey;
  renderTimingSum(); renderRouteBox(); dwSettings();
}
/* L1: the route (chosen in Settings) + the sparrows checkbox for routes with a sparrow table */
function renderRouteBox() {
  if (!$('lkRouteName')) return;
  const base = baseOf(route()), B = LuckyCore.routeOf(base) || routeDef(), sp = sparrowTable();
  $('lkRouteName').textContent = B.label;
  const cb = $('lkSparrows'), lbl = $('lkSparLbl'), on = !!sp && route() === sp.id;
  cb.checked = on; cb.disabled = !sp;
  lbl.hidden = !sp;                                   // v32.18: rainy pages have no sparrow table (no sparrows in the rain)
  lbl.className = 'lkspar' + (!sp ? ' off' : on ? ' on' : '');
  lbl.title = sp ? 'Tick when the two sparrows sit by the doghouse as Jack walks out of the house (menus 5-6 game frames late). Only the box itself or the S key changes it.' : 'No sparrow table for this route';
  $('lkSparTxt').innerHTML = !sp ? '' : on ? `Using the sparrow table (${esc(sp.label)}). Untick (<kbd>S</kbd>) on a morning without them.`
    : 'Tick (or press <kbd>S</kbd>) when the two sparrows sit by the doghouse as you leave the house.';
  fsSync();
  const pb = $('lkPierOnly'), pl = $('lkPierLbl');
  if (pb) {
    const can = pierCan(), isPier = anchor() === 'pier', on = !!pierOnly;
    pb.checked = on; pb.disabled = !can || (isPier && !on);
    pl.className = 'lkspar' + (pb.disabled ? ' off' : on ? ' on' : '');
    const pierNeedless = isPier && !on;                          // v31.27: the start already IS the one dock-end tap - no override to offer
    if (pl.hidden !== pierNeedless) pl.hidden = pierNeedless;     // only write on a change (no DOM churn on every refresh)
    const kp = $('lkKeyPier'); if (kp && kp.hidden !== pierNeedless) kp.hidden = pierNeedless;
    pl.title = 'Pier only: drop the taps before the dock end and time this attempt from your dock-end tap alone. Only the box itself or the X key changes it.';
    $('lkPierTxt').innerHTML = !can ? '' : on ? `<b style="color:#ffd28a">Pier only is on for this attempt:</b> the earlier taps are thrown out; the clock is your <b>dock-end tap</b>${run.wall0 !== null ? ' (running)' : ` — tap <kbd>${esc(keyName())}</kbd> when Jack stops at the dock end`}. It switches itself off after the attempt.`
      : isPier ? ''
      : 'Bad taps on the way in? Tick <b>Pier only</b> (or press <kbd>X</kbd>): the taps before the dock end are thrown out and this attempt is timed from your dock-end tap alone.';
  }
}
/* v30.2 "Pier only" (Thomas): an override for ONE attempt. The runner knows his transition taps were bad -> throw them
   out (they are not stored in the tap data either) and time the attempt from the dock-end tap alone = the route's
   dock-end start (anchor 'pier'). Ticked before the dock-end tap: the next start-key tap is the dock end. Ticked after
   it (before the cast is due): that tap, the most recent data point, becomes the start. The start chosen in L2 comes
   back when the attempt ends (H / M / E, Esc, or the stopwatch running out). */
let pierOnly = null;                                            // { prev: the start before the override }
const pierCan = () => route() !== 'carry' && (routeDef().anchors || []).some(a => a.id === 'pier');
function pierRestore() {
  if (!pierOnly) return;
  const prev = pierOnly.prev;
  pierOnly = null; delete L.pierPrev;
  if ((routeDef().anchors || []).some(a => a.id === prev)) setSelection(null, prev); else { save(); renderRouteBox(); }
}
/* start the pier-only clock from a dock-end tap at wall time dockW; `old` = the clock it replaces (dog logs carried over) */
function pierClock(dockW, old) {
  start(dockW);
  if (run.dw && old && old.logs.length) {                        // dog logs made since: the same moments on the new clock
    const sh = (run.wall0 - old.wall0) / viMs();
    run.dw.logs = old.logs.map(x => Object.assign({}, x, { t: x.t - sh })).filter(x => x.t >= 1); run.dw.dirty = true;
  }
  const tn = (now() - run.wall0) / viMs() + 1;                    // the pier plan's cast is (nearly) gone: the best one 4+ s ahead
  if (L.castT === null && tn > run.T - 240) {
    const sig = sigVI(), Q = P(run.plan), tMin = Math.ceil(tn) + 240, b = LuckyCore.best(Q, sig, tMin);
    const pols = L.policy !== 'auto' ? [L.policy === 'tap' ? 'hold' : L.policy] : ['zone', 'bite1', 'hold'];
    const bp = pols.reduce((x, q) => (b[q] && b[q].p > b[x].p ? q : x), pols[0]);
    if (b[bp] && b[bp].t >= tMin) {
      run.T = b[bp].t; run.pol = L.policy === 'tap' ? 'tap' : bp; run.zone = LuckyCore.zoneAt(Q, run.T, sig, sig, true);
      if (run.dw) run.dw.T0 = run.T;
      $('lkT').textContent = fmtS(run.T); $('lkP').textContent = pct(run.pol === 'zone' && run.zone ? run.zone.value : b[bp].p); renderBiteSplit();
      cancelBeeps(); scheduleBeeps();
    }
  }
}
/* pier only, clock running, before the cast: another Space is the dock-end tap again (the last one counts) */
function pierRetap(w) {
  if (!pierOnly || run.wall0 === null || run.preview || run.castTap !== null || run.tapInfo) return false;
  const t = (now() - run.wall0) / viMs() + 1;
  if (t >= tapsEnd()) return false;                               // the cast is due: from here Space is the cast / the bites
  const prevTap = run.wall0 + startDelay() + (run.cs || 0) * viMs();
  if (w - prevTap < 300) return true;                             // key bounce
  const old = { wall0: run.wall0, logs: run.dw ? run.dw.logs.slice() : [] };
  run.wall0 = null; cancelBeeps();
  pierClock(w, old);
  cueFlash(`DOCK END ✓ replaces the tap ${((w - prevTap) / 1000).toFixed(1)} s before`, 'go', 1600);
  renderRouteBox();
  return true;
}
function setPierOnly(on) {
  const live = run.wall0 !== null;
  if (!on) {
    if (!pierOnly) { renderRouteBox(); return false; }
    if (live) { cueFlash('pier-only clock is running — Esc stops the attempt', 'warn', 1500); renderRouteBox(); return false; }
    pierRestore(); cueFlash('pier only off', 'info', 800); return true;
  }
  if (pierOnly || !pierCan() || anchor() === 'pier' || run.practice || run.bite) { renderRouteBox(); return false; }
  if (live && (run.preview || run.castTap !== null || run.tapInfo || (now() - run.wall0) / viMs() + 1 >= run.T - 90)) {
    cueFlash('too late to switch: the cast is due', 'warn', 1500); renderRouteBox(); return false;
  }
  /* v30.24 (Thomas, 2026-11-19): "I forgot the tap at the screen transition, tapped at the pier, then pressed X" must
     work. With the clock running, X takes the dock-end tap if the taps so far have one; otherwise it takes the LAST
     Space tap as the dock end (that is the forgotten-start case). If that tap was something else (X pressed on the way,
     meaning "the next tap is the dock end"), the next Space before the cast simply replaces it: see pierRetap(). */
  const g = run.gp, hadDock = live && g && g.cue && g.cue.dock != null;
  const lastTap = live ? (g && g.taps && g.taps.length ? g.taps[g.taps.length - 1] : run.wall0 + startDelay() + (run.cs || 0) * viMs()) : null;
  const dockW = hadDock ? g.cue.dock : lastTap;
  const old = live ? { wall0: run.wall0, logs: run.dw ? run.dw.logs.slice() : [] } : null;
  if (live) { if (g) g.kept = true; run.gp = null; run.wall0 = null; cancelBeeps(); }   // the earlier taps: thrown out, not stored
  pierOnly = { prev: anchor() }; L.pierPrev = { route: route(), anchor: pierOnly.prev };
  setSelection(null, 'pier');
  if (dockW != null) {
    pierClock(dockW, old);
    const ago = Math.max(0, (now() - dockW) / 1000);
    cueFlash(hadDock ? 'PIER ONLY ✓ clock = your dock-end tap' : `PIER ONLY ✓ clock = your tap ${ago.toFixed(1)} s ago · not the dock end? tap again there`, 'go', hadDock ? 1500 : 2600);
  } else cueFlash('PIER ONLY — tap at the dock end', 'ready', 1500);
  renderRouteBox();
  return true;
}
/* the sparrows checkbox: switch to / from the variant table, keeping the preset and the start; during an attempt (before
   the cast) the same clock and taps carry on with the other table */
function setSparrows(on) {
  const base = baseOf(route()), sp = variantOf(base, 'sparrows'), target = on && sp ? sp.id : base;
  if (sp) { L.sparrows = !!on; save(); }
  if (target === route()) { renderRouteBox(); return false; }
  if (run.wall0 !== null && (run.preview || run.castTap !== null || run.tapInfo || (now() - run.wall0) / viMs() + 1 >= run.T - 90)) {
    if (sp) { L.sparrows = !on; save(); }
    cueFlash('too late to switch: the cast is due', 'warn', 1500); renderRouteBox(); return false;
  }
  const pace = LuckyCore.selection.pace, anch = anchor(), R2 = LuckyCore.routeOf(target);
  setSelection((R2.groups || []).some(g => g.id === pace) ? pace : 'all', (R2.anchors || []).some(a => a.id === anch) ? anch : null, target);
  if (run.wall0 !== null) {
    run.plan0 = run.plan;
    if (run.dw) { run.dw.base = P(run.plan0); run.dw.cands = null; run.dw.dirty = true; }   // the watch keeps its logs, new table
    if (run.gp) { run.gp.rdy = readySpread(run.plan); run.gp.g3 = null; if (run.gp.cue && run.gp.cue.dock) goal3(); }
    cancelBeeps(); scheduleBeeps();
  }
  cueFlash(on ? 'sparrow table' : 'no-sparrow table', 'info', 900);
  return true;
}
/* L4's first line: how the clock and the beep are set, all offsets in one sentence (v29.9 settings reorganisation) */
/* v30.17 (Thomas, 2026-11-19): the timing profile as one picture ("compass"). Every dot is one thing the app knows about
   your timing: across = how far it sits from where the app expects it (left early, right late, ms), up = how steady it
   is (top steady, bottom loose, ms of spread). The triangle joins your clock taps (ranch exit, beach cue, dock end).
   Hollow = too little data yet. Under it: what the numbers add up to at the CAST cue. */
function timingDots() {
  const vi = viMs(), ps = pressReady(), pd = pressData(), ts = tapStats(), pr = precision(), ds = dockStat(), out = [];
  const tapSdv = isFinite(ts.sdAuto) ? ts.sdAuto : null, ref = L.beachCue;
  /* each clock tap's own spread: its scatter around the attempt's clock (the mean of that attempt's taps, offsets taken out) */
  const res = {}; for (const r of tsGet(curTs()).filter(r => !r.x).slice(-40)) { const ks = Object.keys(r.y).filter(k => ts.off[k]); if (ks.length < 2) continue;
    const ys = ks.map(k => r.y[k] - ts.off[k].m), mu = ys.reduce((a, v) => a + v, 0) / ys.length, f = Math.sqrt(ks.length / (ks.length - 1)); ks.forEach((k, i) => (res[k] = res[k] || []).push((ys[i] - mu) * f)); }
  const own = k => (res[k] && res[k].length >= 5 ? Math.max(10, Math.sqrt(res[k].reduce((a, v) => a + v * v, 0) / res[k].length)) : tapSdv);
  const dv = dock.slice(-40).map(x => x.ms).filter(x => isFinite(x)), dm = dv.length ? med(dv) : 0, dsd = dv.length >= 5 ? Math.sqrt(dv.reduce((a, v) => a + (v - dm) ** 2, 0) / (dv.length - 1)) : tapSdv;
  for (const c of CUES) {
    if (c.vi == null) continue;
    const o = ts.off[c.id]; if (!o || (c.id !== ref && !o.n)) continue;   // only the cues you tap
    out.push({ id: c.id, tri: true, label: c.id === 'exit' ? 'ranch exit tap' : c.id === ref ? 'beach cue tap' : c.short || c.id + ' tap', x: c.id === ref ? 0 : (o.n ? o.raw : null), y: own(c.id), n: c.id === ref ? ts.nrec : o.n, need: 5,
               what: c.id === ref ? 'the clock is set by this tap (0 by definition)' : 'against the beach cue tap' });
  }
  out.push({ id: 'dock', tri: true, label: 'dock end tap', x: ds.n ? ds.med - startDelay() : null, y: dsd, n: ds.n || 0, need: 5, what: 'vs the clock-tap delay' });
  out.push({ id: 'press', label: 'B press on CAST', x: ps ? ps.med : (pd.s && pd.s.n ? pd.s.med : null), y: ps && isFinite(ps.sd) ? ps.sd : null, n: pd.s ? pd.s.n : 0, need: 5, what: 'cast practice + cast taps' });
  const lag = prof && prof.lag && prof.lag.n >= 3;
  out.push({ id: 'bite', label: 'bite tap (Space)', x: lag ? lagMu() * vi - startDelay() : null, y: lag ? lagSd() * vi : null, n: prof && prof.lag ? prof.lag.n : 0, need: 3, what: 'your bite reaction vs your clock-tap delay' });
  const bs = bpReact();
  out.push({ id: 'bprac', label: 'bite practice', x: bs ? bs.med - startDelay() : null, y: bs && isFinite(bs.sd) ? bs.sd : null, n: bs ? bs.n : 0, need: BP.min, what: 'your reaction to the bite animation vs your clock-tap delay' });
  const b = autoB();
  out.push({ id: 'clock', label: 'clock shift', x: prof && prof.n >= 8 && L.autoTune ? b * vi : null, y: pr.sd, n: prof ? prof.n : 0, need: 8, what: 'stopwatch vs console, from the bite taps' });
  const calls = attemptList().filter(a => a.land && a.land.side).slice(0, 20);
  if (calls.length) { const ms = calls.map(a => a.land.ms), m = med(ms), sd = Math.sqrt(ms.reduce((q, v) => q + (v - m) ** 2, 0) / Math.max(1, ms.length - 1));
    out.push({ id: 'land', label: 'where casts landed', x: m, y: calls.length >= 3 ? sd : null, n: calls.length, need: 3, what: 'the early / late calls of your last attempts' }); }
  else out.push({ id: 'land', label: 'where casts landed', x: null, y: null, n: 0, need: 3, what: 'the early / late calls' });
  return out;
}
/* v30.18 audit (North American N64, NTSC, USA cartridge): the game runs OS_VI_NTSC_LAN1 = progressive NTSC, nominally
   59.8261054535 Hz = 16.71511 ms per VI; the lab finds one game update per 2 VIs on the route = 33.4302 ms. The app uses
   33.430 (6.6 ppm short: 0.3 ms over a 45 s cast, far inside a console crystal's tolerance). The Dog Oracle arena can
   overwrite this number ("Use measured speed", or by hand in Settings); the Lucky Timer shares it, so a value off the
   hardware one is flagged here with a one-click way back. */
const NTSC_UPDATE_MS = 33.430, NTSC_HZ = 59.8261054535;
function tbLine() {
  const u = 2 * viMs(), off = Math.abs(u - NTSC_UPDATE_MS) > 0.0015;
  return off ? `<span style="color:#ef6f6f"><b>Time base check: the console frame period in use is ${u.toFixed(4)} ms, not the NTSC N64's ${NTSC_UPDATE_MS.toFixed(3)} ms</b> (set by hand or by "Use measured speed" in the Dog Oracle): a 45 s cast lands ${Math.abs(Math.round((u - NTSC_UPDATE_MS) / 2 * 2692))} ms ${u > NTSC_UPDATE_MS ? 'late' : 'early'}.</span> <button id="lkTbFix">Use ${NTSC_UPDATE_MS.toFixed(3)} ms</button>`
    : `Time base: NTSC N64, ${u.toFixed(3)} ms per game update = 2 video frames of ${viMs().toFixed(3)} ms (${(1000 / viMs()).toFixed(3)} Hz; console nominal ${NTSC_HZ.toFixed(3)} Hz) ✓`;
}
function renderCompass() {
  const cv = $('lkCompass'); if (!cv) return;
  const dots = timingDots(), vi = viMs();
  const Wc = cv.clientWidth || 0; if (!Wc) return;                // closed fold: drawn when it opens
  const dpr = window.devicePixelRatio || 1, H = 300; cv.width = Wc * dpr; cv.height = H * dpr; cv.style.height = H + 'px';
  const g = cv.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, Wc, H);
  const XM = 300, YM = 160, padL = 34, padR = 10, padT = 16, padB = 22;
  const X = ms => padL + (Math.max(-XM, Math.min(XM, ms)) + XM) / (2 * XM) * (Wc - padL - padR), Y = sd => padT + Math.max(0, Math.min(YM, sd)) / YM * (H - padT - padB);
  g.fillStyle = '#0b141c'; g.fillRect(padL, padT, Wc - padL - padR, H - padT - padB);
  g.fillStyle = '#5fd38d14'; g.fillRect(X(-50), Y(0), X(50) - X(-50), Y(60) - Y(0));          // the good corner: within 50 ms, spread under 60 ms
  g.strokeStyle = '#2b3b47'; g.lineWidth = 1; g.font = '10px system-ui, sans-serif'; g.fillStyle = '#8ea3b2';
  for (const ms of [-300, -200, -100, 0, 100, 200, 300]) { g.beginPath(); g.moveTo(X(ms), padT); g.lineTo(X(ms), H - padB); g.strokeStyle = ms ? '#1f2d38' : '#5b7385'; g.stroke(); g.textAlign = 'center'; g.fillText((ms > 0 ? '+' : '') + ms, X(ms), H - padB + 12); }
  for (const sd of [0, 40, 80, 120, 160]) { g.beginPath(); g.moveTo(padL, Y(sd)); g.lineTo(Wc - padR, Y(sd)); g.strokeStyle = sd === 80 ? '#5b7385' : '#1f2d38'; g.stroke(); g.textAlign = 'right'; g.fillText('±' + sd, padL - 4, Y(sd) + 3); }
  g.textAlign = 'left'; g.fillStyle = '#6fb7ff'; g.fillText('EARLY · steady', padL + 4, padT + 11); g.fillText('EARLY · loose', padL + 4, H - padB - 5);
  g.textAlign = 'right'; g.fillStyle = '#ff9d7a'; g.fillText('LATE · steady', Wc - padR - 4, padT + 11); g.fillText('LATE · loose', Wc - padR - 4, H - padB - 5);
  g.textAlign = 'center'; g.fillStyle = '#8ea3b2'; g.fillText('ms from where the app expects it', (padL + Wc - padR) / 2, H - 1);
  const COL = { exit: '#b9cbd8', dock: '#b9cbd8', press: '#5fd38d', bite: '#e7c14a', bprac: '#f0a04a', clock: '#b48cff', land: '#ff9d7a' };
  const tri = dots.filter(d => d.tri && d.x != null && d.y != null);
  if (tri.length >= 2) { g.beginPath(); tri.forEach((d, i) => (i ? g.lineTo(X(d.x), Y(d.y) + (i % 2 ? 5 : -5) * 0) : g.moveTo(X(d.x), Y(d.y)))); g.closePath(); g.fillStyle = '#b9cbd822'; g.fill(); g.strokeStyle = '#b9cbd8'; g.lineWidth = 1.5; g.stroke(); }
  let row = 0;
  for (const d of dots) {
    if (d.x == null) continue;
    const x = X(d.x), y = Y(d.y == null ? 80 : d.y), col = COL[d.id] || '#b9cbd8', ok = d.n >= d.need && d.y != null;
    g.beginPath(); g.arc(x, y, 5, 0, 6.2832); g.lineWidth = 2; g.strokeStyle = col; g.fillStyle = col; if (ok) g.fill(); else g.stroke();
    g.font = '11px system-ui, sans-serif'; g.textAlign = x > Wc * 0.62 ? 'right' : 'left'; g.fillStyle = col;
    g.fillText(`${d.label} ${d.x >= 0 ? '+' : '−'}${Math.abs(Math.round(d.x))}`, x + (x > Wc * 0.62 ? -9 : 9), y + [-9, 15, -21, 27][row++ % 4]);
  }
  const tb = $('lkCompassTbl');
  if (tb) {
    const b = autoB(), corr = cueCorr(), tot = corr - b * vi, sgn = v => (v >= 0 ? '+' : '−') + Math.abs(Math.round(v));
    const verdict = d => (d.x == null ? '<span class="mut">no data yet</span>' : d.n < d.need ? `<span class="mut">${d.n} of ${d.need} needed</span>` :
      (Math.abs(d.x) <= 50 ? '<span style="color:#8ff0a4">on time</span>' : d.x < 0 ? '<span style="color:#6fb7ff">early</span>' : '<span style="color:#ff9d7a">late</span>') + (d.y == null ? '' : d.y <= 60 ? ' · <span style="color:#8ff0a4">steady</span>' : d.y <= 100 ? ' · fair' : ' · <span style="color:#ffd28a">loose</span>'));
    tb.innerHTML = '<table class="lkcomptbl"><tr><th></th><th>offset</th><th>spread</th><th>from</th><th></th></tr>' + dots.map(d =>
      `<tr><td><span style="color:${COL[d.id] || '#b9cbd8'}">●</span> ${d.label}</td><td class="mono">${d.x == null ? '—' : sgn(d.x) + ' ms'}</td><td class="mono">${d.y == null ? '—' : '±' + Math.round(d.y) + ' ms'}</td><td class="mut">${d.n} · ${d.what}</td><td>${verdict(d)}</td></tr>`).join('') + '</table>' +
      `<div style="margin-top:5px"><b>Total cast offset: the CAST cue is shown ${Math.abs(Math.round(tot))} ms ${tot <= 0 ? 'early' : 'late'} for you</b> = your B-press habit ${sgn(corr)} ms (${L.biasAuto !== false && pressReady() ? 'learned' : 'set by hand / not learned'}) ` +
      `${b ? `and the clock shift ${sgn(-b * vi)} ms (${b} VI${Math.abs(b) === 1 ? '' : 's'}, learned from your bite taps)` : 'and no clock shift (needs 8 attempts with a bite tap' + (L.autoTune ? '' : '; "learn from your bite taps" is off') + ')'}. ` +
      `Every cast is planned for a B spread of ±${Math.round(sigEffMs())} ms. ` + tbLine() + '</div>';
    if ($('lkTbFix')) $('lkTbFix').onclick = () => { Core.settings.updateMs = NTSC_UPDATE_MS; store.set('hm64v28_settings', Core.settings); location.reload(); };
  }
}
/* v32.16 (Thomas 2026-11-24 16:45): the four rows of "your timing" as data - drawn here (hidden: L5's old place) and on the
   Settings page, which reads them from the record this page keeps (hm64v32_timing_fit, see saveFit) */
function timingRows() {
  const vi = viMs(), sg = v => (v >= 0 ? '+' : '−') + Math.abs(Math.round(v)), b = autoB(), dly = startDelay(), dog = anchor() === 'dog';
  const d = pressData(), ps = pressReady(), lag = prof && prof.lag && prof.lag.n >= 3 ? prof.lag : null;
  const startVal = dog ? `${sg(dly)} ms (key with A)` : `${Math.round(dly + b * vi)} ms after the cue`;
  const nC = prof ? prof.nCast || 0 : 0, nN = prof ? prof.nNoCast || 0 : 0;
  const startSrc = dog ? 'set by hand' : !L.autoTune ? 'set by hand' : nC >= 8 ? `${dly} set + ${sg(b * vi)} learned from ${nC} attempts with the cast tap`
    : prof && prof.kTied != null && nN >= 8 ? `${dly} set + ${sg(b * vi)} learned from ${nN} bite taps (one reaction for start and bite taps, 70% applied${prof.tieFree ? '; no cast practice yet, so this carries your B-press habit too' : ''})`
    : !ps ? `${dly} assumed; learns from your bite taps after 8 (${nN}/8); 5 cast-practice presses make it sharper`
    : `${dly} assumed; learns from your bite taps after 8 (${nN}/8)`;
  const pressVal = ps ? `${msTxt(ps.med)} vs CAST` : '—', corr = cueCorr();
  const pressSrc = L.biasAuto === false ? `set by hand: CAST cue ${sg(corr)} ms` : ps ? `${ps.n} presses (${d.pr.length} practice + ${d.at.length} real casts) → CAST cue ${sg(corr)} ms`
    : `no presses yet (${d.es.length}/5): cast practice (Settings)${L.castTap ? ', or the cast tap in attempts' : ''}`;
  const lagVal = lag ? `${Math.round(lag.mu * vi)} ms after the bite` : '—';
  const lagSrc = lag ? `±${Math.round((lag.sd || 0) * vi)}, from ${lag.n} bite taps${lag.mu + (lag.sd || 0) > WINDOW_VI - 2 ? ' · <b style="color:#ffd28a">close to the 333 ms window: anticipate the bite</b>' : ''}` : 'learned after 3 bite taps';
  const eff = sigEffMs(), pk = L.personalCast ? personalKernel() : null;
  const varyVal = `±${pk ? Math.round(pk.sd * vi) : eff} ms`;
  const varySrc = (L.sigmaAuto === false ? `set by hand ±${sigmaMs()}` : ps && isFinite(ps.sd) ? `B presses ±${Math.round(ps.sd)} + start tap ±${START1_MS} + clock offset known ±${Math.round(offsetSdMs())}` : `assumed ±${sigmaMs()} (no presses yet)`) +
    (anchor() === 'fadein' && route() !== 'carry' && eff !== sigmaMs() ? `, clock from ${clockCues().length} tap${clockCues().length > 1 ? 's' : ''}` : '') + (pk ? ', personalized kernel' : '');
  return [['start', 'Start taps', startVal, startSrc], ['press', 'B press on CAST', pressVal, pressSrc], ['bite', 'Bite taps', lagVal, lagSrc], ['vary', 'How much you vary', varyVal, varySrc]];
}
function renderTimingSum() {
  renderCompass();
  saveFitSoon();
  renderSetLine();
  const el = $('lkTimingSum');
  if (!el) return;
  const row = (what, val, src) => `<tr><td>${what}</td><td><b>${val}</b></td><td class="mut">${src}</td></tr>`;
  el.innerHTML = '<table class="plan small lktime">' + timingRows().map(r => row(r[1], r[2], r[3])).join('') + '</table>' +
    `<div class="small mut" style="margin-top:3px">Each number learns by itself from every attempt and practice press (auto); "Set by hand" (Settings) overrides one. ` +
    `Reacting to a cue you can't time (start, bite) and pressing on a countdown you see coming (CAST) are different timings, so they stay separate rows.` +
    (!L.castTap ? ` The cast tap is off (Settings): the start-tap delay learns from your bite taps, assuming they come as late as your start taps (one reaction; 70% of what that implies is applied).` : '') + '</div>';
}
/* v32.16: what this page learned from attempts against its dog tables, kept for the Settings page (only a page with the
   tables can work it out): the clock shift, how well the console offset is known, the bite taps, the compass dots, the
   four rows. Written when it changes (debounced). */
function timingFit() {
  const vi = viMs(), b = autoB();
  return { v: 1, at: Date.now(), page: PG ? PG.file || '' : '', set: PG ? PG.set || '' : '', set_label: PG ? PG.set_label || '' : '',
           route: route(), anchor: anchor(), vi, b, clockShiftMs: b * vi, offsetSdMs: offsetSdMs(), startDelay: startDelay(),
           cueCorr: cueCorr(), sigma: sigmaMs(), sigEff: sigEffMs(), autoTune: !!L.autoTune, profN: prof ? prof.n || 0 : 0,
           lag: prof && prof.lag && prof.lag.n >= 3 ? { mu: prof.lag.mu * vi, sd: (prof.lag.sd || 0) * vi, n: prof.lag.n } : null,
           dots: timingDots(), rows: timingRows() };
}
let fitTimer = null, fitKey = '';
function saveFitSoon() {
  if (fitTimer || run.wall0 !== null || run.practice || run.bite) return;   // never during an attempt or a drill: after it
  fitTimer = setTimeout(() => {
    fitTimer = null;
    if (run.wall0 !== null || run.practice || run.bite) return;
    try {
      const f = timingFit(), k = JSON.stringify([f.set, f.route, f.b, f.offsetSdMs, f.startDelay, f.cueCorr, f.sigma, f.sigEff, f.lag, f.dots, f.rows]);
      if (k !== fitKey) { fitKey = k; store.set('hm64v32_timing_fit', f); }
    } catch (e) { /* the record is a convenience for the Settings page */ }
  }, 400);
}
function renderSetLine() {                                      // L5's first lines: the timing in use, set on the Settings page
  const el = $('lkSetLine'); if (!el) return;
  const vi = viMs(), b = autoB(), sg = v => (v >= 0 ? '+' : '−') + Math.abs(Math.round(v)), lag = prof && prof.lag && prof.lag.n >= 3 ? prof.lag : null;
  el.innerHTML = `<b>Your timing in use:</b> start tap ${Math.round(startDelay() + b * vi)} ms after the cue · CAST cue ${sg(cueCorr())} ms · spread ±${sigEffMs()} ms · ` +
    `bite taps ${lag ? Math.round(lag.mu * vi) + ' ms' : 'not learned yet'} · ${keyName()} = start key. ` +
    `Set, practised and explained on the <a class="v32setlink" href="settings.html">Settings</a> page (shared by every page of the tool). Below: what your attempts teach this page.`;
}
$('lkSigma').oninput = e => { L.sigmaMs = +e.target.value; $('lkSigmaV').textContent = L.sigmaMs + ' ms'; };
$('lkSigma').onchange = () => { save(); bestCache = null; refresh(); };
/* the hand-set inputs show the values in use; a row's input is live only while its auto box is off (or has no data) */
function syncTimingInputs() {
  if (!$('lkSigma')) return;
  const ready = !!pressReady();
  $('lkSigma').value = sigmaMs(); $('lkSigmaV').textContent = sigmaMs() + ' ms'; $('lkSigma').disabled = L.sigmaAuto !== false && ready;
  $('lkBias').value = cueCorr(); $('lkBias').disabled = L.biasAuto !== false && ready;
  if ($('lkSigmaAuto')) $('lkSigmaAuto').checked = L.sigmaAuto !== false;
  if ($('lkBiasAuto')) $('lkBiasAuto').checked = L.biasAuto !== false;
  if ($('lkAutoTune')) $('lkAutoTune').checked = !!L.autoTune;
}
/* switching a row to manual starts from the value it had */
const cueCorr0 = () => { const s = pressReady(); return s ? -Math.round(s.med) : L.biasMs; };
const sigmaMs0 = () => { const s = pressReady(); return s && isFinite(s.sd) ? sigmaFrom(s.sd) : L.sigmaMs; };
$('lkStartDelay').onchange = e => {
  const v = +e.target.value;
  if (anchor() === 'dog') L.dogDelayMs = v; else L.startTapMs = v;
  save(); refresh();
};
$('lkAnchor').onchange = e => setSelection(null, e.target.value);
if ($('lkPracBox')) $('lkPracBox').addEventListener('toggle', () => renderPractice());
if ($('lkHowBox')) { $('lkHowBox').open = L.howOpen !== false; $('lkHowBox').addEventListener('toggle', () => { L.howOpen = $('lkHowBox').open; save(); }); }
if ($('lkAutoTune')) $('lkAutoTune').onchange = e => { L.autoTune = e.target.checked; save(); refresh(); };
$('lkPaceTxt').addEventListener('click', e => {                 // "use it": switch to the best start for this preset
  const t = e.target.closest && e.target.closest('[data-start]');
  if (t) { e.preventDefault(); setSelection(null, t.dataset.start); }
});
if ($('lkRoute')) $('lkRoute').onchange = e => {
  const sp = L.sparrows && variantOf(e.target.value, 'sparrows');
  setSelection(null, null, sp ? sp.id : e.target.value);
};
if ($('lkSparrows')) $('lkSparrows').onchange = e => setSparrows(e.target.checked);
if ($('lkPierOnly')) $('lkPierOnly').onchange = e => setPierOnly(e.target.checked);
if ($('lkFreeTgt')) { $('lkFreeTgt').value = FS_TG[L.fsTarget] ? L.fsTarget : 'N'; $('lkFreeTgt').onchange = e => { L.fsTarget = e.target.value; save(); if (run.fs) run.fs.comb = null; dwCardKey = ''; e.target.blur(); fsSync(); }; }
if ($('lkFree')) { $('lkFree').onchange = () => { fsToggle(); };              // the box: same as the key
  $('lkFreeKey').onclick = e => { e.preventDefault(); fsCap = !fsCap; fsCapTxt(fsCap ? 'Press the key for Freestyle (Ctrl is the default; Esc = keep)' : ''); e.target.blur(); }; }
/* v30.15 (Thomas, 2026-11-19): the three front panels (dog-watch, Lucky plan, preview) can be put in any left-to-right
   order: hold the grip at the top of a panel and drag it sideways; double-click a grip = the standard order. The order is
   a CSS `order` per panel (the DOM stays as it is), kept in L.frontOrder. */
const FRONT = ['lkPrev', 'lkPlanBox', 'lkDw'];                  // v31.27: Thomas's order is the standard (double-click a grip)
function frontOrder() { const o = L.frontOrder; return Array.isArray(o) && o.length === FRONT.length && FRONT.every(x => o.includes(x)) ? o.slice() : FRONT.slice(); }
function frontApply(o) { (o || frontOrder()).forEach((id, i) => { const el = $(id); if (el) el.style.order = String(i); }); }
function frontDragTo(id, x) {                                   // the order with panel `id` dropped at screen x
  const cur = frontOrder().filter(k => k !== id), vis = k => { const el = $(k); return el && !el.hidden && el.getBoundingClientRect().width > 0; };
  let n = 0;
  for (const k of cur) { if (!vis(k)) continue; const r = $(k).getBoundingClientRect(); if (x > r.left + r.width / 2) n++; }
  let at = cur.length, seen = 0;                                // insert before the (n+1)-th visible other panel
  for (let i = 0; i < cur.length; i++) { if (!vis(cur[i])) continue; if (seen === n) { at = i; break; } seen++; }
  cur.splice(at, 0, id);
  return cur;
}
if ($('lkPlanBox')) {
  frontApply();
  let drag = null;
  for (const gEl of document.querySelectorAll('.lkfront [data-grip]')) {
    const box = gEl.parentNode;
    gEl.addEventListener('pointerdown', e => { e.preventDefault(); drag = { id: box.id }; box.classList.add('drag'); });
    gEl.addEventListener('dblclick', () => { L.frontOrder = FRONT.slice(); save(); frontApply(); });
  }
  window.addEventListener('pointermove', e => { if (!drag) return; const o = frontDragTo(drag.id, e.clientX); if (o.join() !== frontOrder().join()) { L.frontOrder = o; frontApply(o); } });
  const end = () => { if (!drag) return; $(drag.id).classList.remove('drag'); drag = null; save(); };
  window.addEventListener('pointerup', end); window.addEventListener('pointercancel', end);
}
if ($('lkDwCards')) {                                            // v30.16: how many dogs, and from which side
  $('lkDwCards').value = String([3, 5, 7].includes(+L.dwCards) ? +L.dwCards : 3); $('lkDwFill').value = ['ltr', 'mid', 'rtl'].includes(L.dwFill) ? L.dwFill : 'ltr';
  if ($('lkDwPeekOn')) { $('lkDwPeekOn').checked = !!L.dwPeekOn; $('lkDwPeekOn').onchange = e => { L.dwPeekOn = !!e.target.checked; save(); if (!L.dwPeekOn) dwPeekHide(); e.target.blur(); }; }
  $('lkDwCards').onchange = e => { L.dwCards = +e.target.value; save(); dwCardKey = ''; e.target.blur(); };
  $('lkDwFill').onchange = e => { L.dwFill = e.target.value; save(); dwCardKey = ''; e.target.blur(); };
}
if ($('lkTbWarn')) {                                            // v30.18: a frame period off the NTSC N64's is said on the front page too
  const off = Math.abs(2 * viMs() - NTSC_UPDATE_MS) > 0.0015;
  $('lkTbWarn').hidden = !off;
  if (off) { $('lkTbWarn').textContent = `⚠ frame period ${(2 * viMs()).toFixed(3)} ms ≠ NTSC ${NTSC_UPDATE_MS.toFixed(3)} · click to fix`;
    $('lkTbWarn').onclick = () => { Core.settings.updateMs = NTSC_UPDATE_MS; store.set('hm64v28_settings', Core.settings); location.reload(); }; }
}
if ($('lkMore')) {                                              // v30.14: setup & review folded away; canvases inside are drawn when it opens
  $('lkMore').open = !!L.moreOpen;
  $('lkMore').addEventListener('toggle', () => { L.moreOpen = $('lkMore').open; save(); if (run.wall0 === null) refresh(); renderCompass(); });
}
if ($('lkDwManual')) {
  for (const b of document.querySelectorAll('[data-dwnudge]')) b.onclick = () => dwNudge(+b.dataset.dwnudge);
  $('lkDwAdj0').onclick = () => { const w = run.dw; if (!w) return; if (run.wall0 !== null && (now() - run.wall0) / viMs() + 1 >= dwT() && dcHas(dwRoute())) { w.cadj = 0; dwCardKey = ''; } else dwNudge(-w.adj); };
  if ($('lkDwOutUndo')) $('lkDwOutUndo').onclick = () => dwRestore();
  $('lkDwPickClear').onclick = () => { const w = run.dw; if (!w || run.wall0 === null) return;
    if ((now() - run.wall0) / viMs() + 1 >= dwT() && dcHas(dwRoute())) { w.tune = null; w.exact = null; w.carOff = true; dwCardKey = ''; return; }   // v31.4: after the cast = back to all dogs
    if (w.pick) dwPick(w.pick.dwi); };
}
if ($('lkAttLast')) {
  $('lkAttLast').onclick = () => { const a = attemptList()[0]; if (a) removeAttempt(a.id); };
  $('lkAttUndo').onclick = () => restoreAttempt();
}
if ($('lkGoal')) {
  $('lkGoal').onchange = e => { L.goal = e.target.value === 'time' ? 'time' : 'odds'; applyGoal(); e.target.blur(); };
  const go = $('lkGoalOver');
  go.onchange = () => { L.goalOverS = Math.max(10, Math.min(300, +go.value || 55)); go.value = L.goalOverS; applyGoal(); go.blur(); };
  go.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === 'Escape') { go.blur(); e.preventDefault(); e.stopPropagation(); } });
}
if ($('lkDwStrict')) {                                           // v30.2 dog-watch: strict sequence + late allowance
  if (L.dwLateMs == null) L.dwLateMs = 1000;
  const mark = () => { if (run.dw) run.dw.dirty = true; dwLast = ''; };
  $('lkDwStrict').onchange = e => { L.dwStrict = e.target.checked; save(); mark(); };
  const li = $('lkDwLate');
  li.onchange = () => { L.dwLateMs = Math.min(3000, Math.max(300, +li.value || 1000)); li.value = L.dwLateMs; save(); mark(); li.blur(); };
  li.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === 'Escape') { li.blur(); e.preventDefault(); e.stopPropagation(); } });
}
/* v30.2: the two attempt boxes change only by a click on the box itself or by their key. They never keep the keyboard
   focus (a focused checkbox takes the next Space tap as "toggle me" and the tap is lost), the text beside them is not
   a label any more, and no other control of the Lucky Timer keeps the focus after a click either. */
for (const id of ['lkSparrows', 'lkPierOnly', 'lkDwStrict', 'lkFree']) { const cb = $(id); if (cb) { cb.addEventListener('mousedown', e => e.preventDefault()); cb.addEventListener('focus', () => cb.blur()); } }
{ const arena = $('luckyArena');
  if (arena) arena.addEventListener('click', e => { const t = e.target.closest && e.target.closest('button, summary, input[type=checkbox], input[type=radio]'); if (t && document.activeElement === t) t.blur(); });
  document.addEventListener('keyup', e => {                      // Firefox toggles a focused box / presses a focused button on keyup
    if (root.HM64Arena !== 'lucky' || document.querySelector('dialog[open]')) return;
    const t = e.target, tag = t && t.tagName, typ = t && t.type;
    if (e.key === L.startKey && (tag === 'BUTTON' || tag === 'SUMMARY' || (tag === 'INPUT' && (typ === 'checkbox' || typ === 'radio')))) e.preventDefault();
  }, true); }
if (L.pierPrev) { const pp = L.pierPrev; delete L.pierPrev; save();   // the page was closed during a pier-only attempt: back to the chosen start
  setTimeout(() => { if (route() === pp.route && anchor() === 'pier' && (routeDef().anchors || []).some(a => a.id === pp.anchor)) setSelection(null, pp.anchor); }, 0); }
if ($('lkRouteChange')) $('lkRouteChange').onclick = e => { e.preventDefault(); $('settingsBtn').click(); };
$('lkBias').onchange = e => { L.biasMs = +e.target.value; save(); refresh(); };
if ($('lkBiasAuto')) $('lkBiasAuto').onchange = e => { L.biasAuto = e.target.checked; if (!L.biasAuto) L.biasMs = cueCorr0(); save(); fillLSettings(); refreshSig(); };
if ($('lkSigmaAuto')) $('lkSigmaAuto').onchange = e => { L.sigmaAuto = e.target.checked; if (!L.sigmaAuto) L.sigmaMs = sigmaMs0(); save(); fillLSettings(); refreshSig(); };
$('lkFacing').onchange = e => { L.facing = e.target.value; save(); };
$('lkZoneBeeps').onchange = e => { L.zoneBeeps = e.target.checked; save(); };
$('lkAudio').onchange = e => { L.audio = e.target.checked; save(); renderPractice(); };
if ($('lkCueGlow')) $('lkCueGlow').onchange = e => { L.cueGlow = e.target.checked; save(); };
if ($('lkPersonalCast')) $('lkPersonalCast').onchange = e => { L.personalCast = e.target.checked; save(); refreshSig(); };
$('lkCastTap').onchange = e => { L.castTap = e.target.checked; save(); refresh(); };
$('lkTapPrec').onchange = e => { L.tapPrecMs = Math.max(10, +e.target.value || 40); save(); updateProfile(); refresh(); };
let capturing = false;
$('lkStartKey').onclick = () => { capturing = true; $('lkStartKey').textContent = 'press a key…'; };
document.querySelectorAll('#lkPol button').forEach(b => { b.onclick = () => { L.policy = b.dataset.pol; L.castT = null; save(); refresh(); }; });
$('lkAutoPlan').onclick = () => { const was = autoHand(); L.plan = 'auto'; L.policy = 'auto'; L.castT = null; save(); refresh();
  if (was.length && run.wall0 === null) cueFlash(`BACK TO BEST · cast ${$('lkT').textContent} · ${$('lkP').textContent}`, 'go', 1400); };
$('lkMinus').onclick = () => { L.castT = Math.max(run.plan.firstT, run.T - 2); save(); refresh(); };
$('lkPlus').onclick = () => { L.castT = Math.min(LuckyCore.TMAX, run.T + 2); save(); refresh(); };
$('lkBest').onclick = () => { L.castT = null; save(); refresh(); };
$('lkOverview').onclick = overviewClick;
$('lkStart').onclick = () => (run.bite ? biteStop() : run.practice ? practiceStop() : run.wall0 === null ? start() : stop(true));
$('lkHit').onclick = () => record(true); $('lkMiss').onclick = () => record(false, 'fish'); $('lkEmpty').onclick = () => record(false, 'empty');
$('lkPreview').onclick = preview;
$('lkPractice').onclick = () => (run.practice ? practiceStop() : practiceStart());
if ($('lkCombo')) $('lkCombo').onclick = e => { e.target.blur(); run.practice ? practiceStop() : practiceStart(true); };
if ($('lkPracCombo')) $('lkPracCombo').onchange = e => { L.pracCombo = e.target.checked; save(); if (run.practice) { practiceStop(); practiceStart(); } else renderPractice(); };
for (const id of ['lkBite', 'lkBite2']) if ($(id)) $(id).onclick = e => { e.target.blur(); run.bite ? biteStop() : biteStart(); };
if ($('lkBpUse')) $('lkBpUse').onchange = e => { L.bpUse = e.target.checked; save(); updateProfile(); refresh(); renderBite(); };
if ($('lkBpMode')) $('lkBpMode').onchange = e => { if (run.bite) biteStop(); L.bpMode = e.target.checked ? 'tap' : 'rel'; save(); renderBite(); };
if ($('lkBpForget')) $('lkBpForget').onclick = () => { if (confirm('Forget your bite-practice reactions?')) biteForget(); };
if ($('lkBpBox')) $('lkBpBox').addEventListener('toggle', () => renderBite());
if ($('lkDogHabit')) $('lkDogHabit').onchange = e => { L.dogHabit = e.target.checked; save(); relearn(); };
$('lkPracLine').onchange = e => { L.pracLine = e.target.checked; save(); renderPractice(); };
$('lkPracFull').onchange = e => { L.pracFull = e.target.checked; save(); if (run.practice) { practiceStop(); practiceStart(); } else renderPractice(); };

$('lkPracApply').onclick = () => { if (applyCastProfile(false)) renderPractice(); };
$('lkPracForget').onclick = () => { if (confirm(`Forget your ${PRAC_MODE[pracMode()]} practice presses?`)) { pracLog = pracLog.filter(r => r.m !== pracMode() || cueKind(r) !== (L.audio ? 'a' : 'v')); store.set('hm64v29_lucky_castprac', pracLog); renderPractice(); } };
$('lkResetTally').onclick = () => { if (confirm('Clear the attempt log?')) { tally = []; store.set('hm64v29_lucky_tally', tally); renderTally(); } };
$('lkExport').onclick = () => {
  const blob = new Blob([JSON.stringify({ schema: 'hm64-v29-lucky', version: D.version, settings: L, tally }, null, 1)], { type: 'application/json' });
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `hm64_lucky_${new Date().toISOString().slice(0, 10)}.json`; a.click();
};
$('lkSprites').onclick = () => $('lkSpriteFile').click();
$('lkSpriteFile').onchange = e => {
  const f = e.target.files[0]; if (!f) return;
  f.text().then(t => { try { customSprites = JSON.parse(t); store.set('hm64v29_angler', customSprites); $('lkSpriteTxt').textContent = Object.keys(customSprites).length + ' frames loaded'; } catch (err) { $('lkSpriteTxt').textContent = 'not a JSON file'; } });
};
$('lkSpriteClear').onclick = () => {
  customSprites = {}; store.set('hm64v29_angler', {});
  L.figure = JACK && L.figure === 'stick' ? 'jack' : 'stick'; save(); figureTxt();
};
function figureTxt() {
  $('lkSpriteClear').textContent = JACK && L.figure !== 'stick' ? 'Use stick figure' : JACK ? 'Use Jack frames' : 'Stick figure';
  $('lkSpriteTxt').textContent = Object.keys(customSprites).length ? Object.keys(customSprites).length + ' own frames loaded'
    : JACK && L.figure !== 'stick' ? "Jack: your catalog's frames, game timing" : 'stick figure';
}
figureTxt();


/* ---------------------------------------------------------------- v30 dog-watch (HM64DogWatch, webapp/hm64_dogwatch_v30.js)
   From the dock-end tap (or READY on this plan's routes when there is none) to HANDS ON B (L.dwLead s before the cast)
   the runner logs the dog: arrows / WASD at every facing change (the first arrow = the facing it has; a second,
   orthogonal key while the first is held, within 0.25 s, turns that log into the diagonal, time kept), numpad 0-9 for a
   long animation while it faces S, N or east; Backspace undoes the last log. Each log re-weights every candidate route
   (lines with and without a cast table, READY offsets, READY times) by its recorded dog trace (soft matching, one clock
   offset for all logs, unlogged facing changes count as misses), after the dock-end tap's own weighting; the plan
   becomes that mixture and the cast re-aims (smart zones / policy as goal3) while it is >= lead + 2 s away and gains
   >= 0.2 points. Frozen at HANDS ON B. Space keeps its meanings (taps, bites); S / H / M / E outside the watch. */
const DWC = root.HM64DogWatch || null;
const dwRoute = () => (DWC && L.dwOn && routeDef().dw ? routeDef() : null);
function dwInit() {
  const R = dwRoute();
  if (!R || run.preview) return null;
  return { logs: [], undone: [], open: false, frozen: false, openAt: null, g3: null, lk: null, sum: null, moved: 0, T0: run.T,
           held: new Map(), chord: null, dirty: false, lastUp: 0, cands: null, base: P(run.plan0 || run.plan),
           pick: null, adj: 0, comp: null, locked: null, quiet: [] };   // quiet: [[from, to]] spans with a dog picked (v30.25)   // v30.10: manual pick {dwi, a0}, nudge (VIs), competing lines
}
/* v30.2: "no missed turns once I start" - the late-entry allowance (ms, its own number) is never tighter than the reaction window */
const dwLateVI = ww => Math.max((ww || dwWin()).hi + 6, Math.min(3000, Math.max(300, +L.dwLateMs || 1000)) / viMs());
const dwLeadVI = () => Math.max(1, +L.dwLead || 2) * 1000 / viMs();
/* v30.1: the arrow reaction is its own number (choosing one of eight arrows is slower than tapping a bite). After every
   attempt whose bite taps name the dog line (>= 80%), the logs are measured against that line's trace (DWC.calibrate):
   lag of each arrow / numpad key behind the change it names, turns nobody logged, logs that match nothing. From 8 lags
   on, the look-back window is their 10-90% range +- 3 VIs; the stray and missed shares replace the fixed 0.02 / 0.10
   (shrunk to those with 25 / 20 pseudo-counts). Until then: the bite-tap reaction +- 7.5 VIs, as v30.0. */
function dwCal() {
  const use = dwcal.slice(-40), lags = [];
  let n = 0, stray = 0, turns = 0, missed = 0;
  for (const c of use) { lags.push(...(c.lagF || []), ...(c.lagG || [])); n += (c.nF || 0) + (c.nG || 0); stray += c.stray || 0; turns += c.turns || 0; missed += c.missed || 0; }
  lags.sort((a, b) => a - b);
  return { lags, n, stray, turns, missed, attempts: use.length };
}
function dwWin() {                                             // reaction window (VIs)
  const k = dwCal();
  if (k.lags.length >= 8) {
    const q = p => k.lags[Math.min(k.lags.length - 1, Math.floor(p * k.lags.length))];
    const lo = Math.max(3, q(0.1) - 3);
    return { lo, hi: Math.min(45, Math.max(lo + 10, q(0.9) + 3)), learned: k.lags.length };   // v30.10: capped (an arrow may be keyed late in a facing; that is not reaction)
  }
  const mu = prof && prof.lag ? lagMu() : 17.5;
  return { lo: Math.max(4, mu - 7.5), hi: mu + 7.5, learned: 0 };
}
function dwPen() {
  const k = dwCal();
  return { eps: Math.min(0.25, Math.max(0.005, (k.stray + 0.02 * 25) / (k.n + 25))), miss: Math.min(0.6, Math.max(0.03, (k.missed + 0.10 * 20) / (k.turns + 20))) };
}
function dwCalibrate(ti) {                                     // called when the attempt is recorded
  const w = run.dw, R = dwRoute();
  if (!w || !R || !DWC.calibrate || !w.logs.length || !ti || !ti.sum || !(ti.sum.pathShare >= 0.8) || !ti.sc) return null;
  const li = R.sidxs.indexOf(ti.sum.path), dwi = li >= 0 ? R.dw.of_line[li] : -1;
  if (dwi == null || dwi < 0) return null;
  const byO = new Map();                                         // the READY offset on that line: the pair holding most of its mass
  let tot = 0;
  for (const e of ti.sc) if (e.path === ti.sum.path) { const o = +String(e.pair).split(':')[1]; byO.set(o, (byO.get(o) || 0) + e.w); tot += e.w; }
  const top = [...byO.entries()].sort((a, b) => b[1] - a[1])[0];
  if (!top || !(top[1] >= 0.5 * tot)) return null;
  const c = DWC.calibrate(R, dwi, top[0] - 1, w.logs, w.frozenAt != null ? w.frozenAt : Math.min(dwT(), 1e9) - dwLeadVI());
  const rec = { at: Date.now(), aid: run.aid, route: route(), lagF: c.lagF, lagG: c.lagG, nF: c.nF, nG: c.nG, stray: c.strayF + c.strayG, turns: c.turns, missed: c.missed };
  dwcal.push(rec); dwcal = dwcal.slice(-60); store.set('hm64v30_dwcal', dwcal);
  return rec;
}
function dwOpen(tOpen) {
  const w = run.dw;
  if (!w || w.open || w.frozen) return;
  w.open = true; w.openAt = tOpen;
  $('lkDw').classList.add('on');
}
function dwTick(t) {
  const w = run.dw, box = $('lkDw');
  if (!box) return;
  box.hidden = !(dwRoute());
  if (!w || run.wall0 === null || run.practice || run.bite) { if (!box.hidden) { dwRender(t); dwCards(t); } return; }   // v31.25 BUG FIX: a practice drill is not an attempt - the last attempt's dog stayed selected in it
  if (!w.open && !w.frozen) {                                    // no dock-end tap in this strategy (or missed): READY + 0.5 s
    const rs = readySpread(run.plan0 || run.plan), tr = anchor() === 'pier' ? 1 : rs.mean + 1;
    if (t >= tr + 30 && !(run.gp && run.gp.cue && run.gp.cue.dock == null && clockCues().length && tapCues().some(c => c.id === 'dock') && t < tr + 3 * rs.sd + 60)) dwOpen(t);
  }
  if (w.open && !w.frozen && t >= dwT() - dwLeadVI()) {           // HANDS ON B: final weighting, no re-aim
    w.frozen = true; w.open = false; w.frozenAt = t;
    if (w.logs.length || (w.out && w.out.length)) dwUpdate(t, true);
    box.classList.remove('on'); box.classList.add('frozen');
    if (!fsOn()) cueFlash('HANDS ON B', 'ready', 900);            // v31.25 (found by the consistency lab): in freestyle the watch closes at the marked cast - B is already down
  }
  if (w.open && (w.logs.length || w.pick || (w.out && w.out.length)) && (w.dirty || now() - w.lastUp > 1500)) dwUpdate(t, false);
  else if (w.frozen && w.dirty && t < dwT()) dwUpdate(t, true);   // a pick / nudge after HANDS ON B: weights only, no re-aim
  dwRender(t); dwCards(t);
}
/* re-weight the plan by the logs (on top of the dock-end tap) and maybe re-aim */
function dwUpdate(t, final) {
  const w = run.dw, R = dwRoute();
  if (!w || !R) return;
  w.dirty = false; w.lastUp = now();
  const base = w.base, sig = sigVI();
  if (!w.cands) w.cands = DWC.candidates(R, base, LuckyCore.selection.pace, anchor());
  const g3 = w.g3, oF = dwOutF(w), l3 = c => oF(c) * (g3 ? Math.exp(-0.5 * ((g3.tau3 - c.mt - g3.r3) / g3.sd) ** 2) : 1);
  const ww = dwWin(), pn = dwPen(), cs = Math.max(1.5, Math.hypot(run.gp && run.gp.sdF ? run.gp.sdF : clockSd(), 30) / viMs());   // the clock's own spread
  /* v30.1: the clock offset the logs imply (stopwatch ahead of the console, VIs) is kept with the attempt but NOT applied
     to the cue: in the lab's simulation it barely beats the taps' own clock (RMS 3.05 -> 2.95 VIs after 10 s, 6.3 -> 5.2
     after 20 s with a poor clock) and a wrong reaction window makes it worse (5.6 -> 6.6); the dog turns too rarely. */
  w.clock = {};
  w.lk = DWC.likelihood(R, w.cands, w.logs.map(l => (l.f != null ? { t: l.t, f: l.f } : { t: l.t, g: l.g })),
                        { now: t, lo: ww.lo, hi: ww.hi, eps: pn.eps, miss: pn.miss, clockSd: cs, prior: w.cands.map(c => c.w * l3(c)), clock: w.clock,
                          strict: !!L.dwStrict, late: dwLateVI(ww), quiet: w.quiet });   // v30.2: strict sequence + its own late allowance; v30.25: no keying expected while a dog is picked
  w.strict = !!L.dwStrict;
  const post = w.cands.map((c, i) => c.w * l3(c) * w.lk[i]);
  w.sum = DWC.summary(R, w.cands, post);
  const f = new Map();
  w.cands.forEach((c, i) => { if (c.pv >= 0) f.set(c.pv, l3(c) * w.lk[i]); });
  w.post = post;
  let vars = base.variants.map((x, pv) => Object.assign({}, x, { w: x.w * (f.get(pv) || 0) }));
  w.pickNote = '';
  if (w.pick) {                                                  // v30.10 manual adjustment: "this card is my dog", lined up by eye
    const li = R.dw.lines[w.pick.dwi].li;
    if (li < 0) w.pickNote = 'no cast table for the dog you picked: the cast stays as planned';
    else {
      const sx = R.sidxs[li], a = w.pick.a0 + w.adj, tm = base.variants.find(x => x.s === sx) || { period: 0, starts: [], minT: 1 };
      let mt = tm.minT || 1, bw = -1;
      w.cands.forEach((c, i) => { if (c.dwi === w.pick.dwi && post[i] > bw) { bw = post[i]; mt = c.mt; } });
      /* v30.11 (Thomas, 2026-11-18): the arrows stay in charge. The picked dog at the lined-up timing (+- 2 x DW_EYE) is
         scored against the logs together with every candidate of the app's own weighing: when the logs fit it less
         than DW_DROP of the best-fitting candidate (one arrow that the picked dog never shows is enough: x 0.02), the
         pick is dropped and the app's own weighing carries on. While it stands, the timing inside the eye window is
         weighted by the logs too. */
      const syn = [];
      for (let d = -2 * DW_EYE; d <= 2 * DW_EYE; d++) syn.push({ dwi: w.pick.dwi, ko: Math.round(a) + d + mt, mt, w: 1, pv: -1, d });
      let ls = syn.map(() => 1), fit = 1;
      if (w.logs.length) {
        const all = DWC.likelihood(R, w.cands.concat(syn), w.logs.map(l => (l.f != null ? { t: l.t, f: l.f } : { t: l.t, g: l.g })),
                                   { now: t, lo: ww.lo, hi: ww.hi, eps: pn.eps, miss: pn.miss, clockSd: cs, strict: false, late: dwLateVI(ww), quiet: w.quiet });   // v30.12: always the normal rule here - under the strict
        /* rule one late or skipped arrow (x 0.001) dropped RIGHT picks (Mac stress test: 23 of 130; 0 of 131 under the normal rule) and dropped wrong ones no more often (92 vs 88 of 150) */
        let mN = 0, mS = 0;
        for (let i = 0; i < all.length; i++) { if (i < w.cands.length) mN = Math.max(mN, all[i]); else mS = Math.max(mS, all[i]); }
        ls = Array.from(all.slice(w.cands.length)); fit = mN > 0 ? mS / mN : 1;
      }
      w.pickFit = fit;
      if (fit < DW_DROP) {
        w.dropped = { dwi: w.pick.dwi, t, fit, logs: w.logs.length }; w.drops = (w.drops || 0) + 1; w.pick = null; dwQuiet(w, t, true); dwCardKey = '';
        if (t < dwT()) cueFlash('YOUR PICK DROPPED · the arrows say another dog', 'hold', 1500);
      } else {
        w.dropped = null;
        vars = syn.map((c, j) => Object.assign({}, tm, { s: sx, o: c.ko - mt + 1, minT: mt, w: Math.exp(-0.5 * (c.d / DW_EYE) ** 2) * ls[j] }));
      }
    }
  }
  const Wt = vars.reduce((a, x) => a + x.w, 0);
  if (!(Wt > 0)) return;
  const Q = Object.assign({}, base, { variants: vars.filter(x => x.w > Wt * 1e-6), _final: true, _dw: true });
  const valOn = (pl, pol, T) => (pol === 'zone' ? (LuckyCore.zoneAt(pl, T, sig) || {}).value : LuckyCore.curve(pl, sig, pol === 'tap' ? 'hold' : pol).P[T]);
  const T0 = run.T, v0 = valOn(Q, run.pol, T0);
  let T = T0, pol = run.pol, p = v0;
  const tMin = Math.max(base.firstT + 29, Math.ceil(t) + dwLeadVI() + 120);
  if (!final && L.castT === null && T0 >= tMin) {
    const b = LuckyCore.best(Q, sig, tMin);
    const pols = L.policy !== 'auto' ? [L.policy === 'tap' ? 'hold' : L.policy] : ['zone', 'bite1', 'hold'];
    const bp = pols.reduce((a, q) => (b[q] && b[q].p > b[a].p ? q : a), pols[0]);
    if (b[bp] && b[bp].t >= tMin && b[bp].p > (v0 || 0) + 0.002) { T = b[bp].t; pol = L.policy === 'tap' ? 'tap' : bp; p = b[bp].p; }
  }
  /* v30.16 (Thomas, 2026-11-19): a picked dog line is read for what is still possible. The cast is the moment still ahead
     with the best chance of a Nut on ANY bite of that line (1st, 2nd or later: smart zones release the 1st bite where that
     is the Nut, hold and tap where a later one is), whatever policy or cast time was set by hand, also after HANDS ON B and
     also when the best moment of the line has already gone by - as long as the cast is still DW_PICK_MIN away and the new
     one at least DW_PICK_LEAD ahead. */
  w.anyP = null; w.anyCv = null;
  if (w.pick && Q._dw && vars.length && vars[0].s === R.sidxs[R.dw.lines[w.pick.dwi].li]) {
    const cv = anyBiteCurve(Q, sig, Math.ceil(t) + DW_PICK_LEAD), a0 = cv.at(T0);
    pol = 'zone'; w.anyCv = cv;
    if (T0 - t >= DW_PICK_MIN && cv.best && cv.best.p > (a0 || 0) + 0.002) T = cv.best.t;
    w.anyP = cv.at(T); w.pickLate = !!(cv.best && cv.peak && cv.peak.t < Math.ceil(t) + DW_PICK_LEAD && cv.peak.p > cv.best.p + 0.02 ? cv.peak : null) && { t: cv.peak.t, p: cv.peak.p };
  }
  if (T !== T0) w.moved += T - T0;
  if (fsOn()) T = T0;                                             // v31.14 freestyle: the app's cast time is not in play, nothing to re-aim
  run.plan = Q; run.T = T; run.pol = pol;
  run.zone = LuckyCore.zoneAt(Q, T, sig, sig, true);
  w.p = w.anyP != null ? Math.max(w.anyP, run.zone ? run.zone.value : 0) : pol === 'zone' && run.zone ? run.zone.value : p;
  if (w.anyP != null) renderBiteSplit();
  $('lkT').textContent = fmtS(T); $('lkP').textContent = pct(w.p);
  if (T !== T0) { cancelBeeps(); scheduleBeeps(); cueFlash(`CAST MOVED ${T >= T0 ? '+' : '−'}${(Math.abs(T - T0) * viMs() / 1000).toFixed(2)} s · ${pct(w.p)}`, 'go', 1200); }
}
/* ---- v30.20 (Thomas, 2026-11-19): the animation keys and the card-timing keys can be reassigned.
   L.dwAnimKeys = { sprite base: key code | '' } (animations on the same key are one group: any of them fits the key);
   L.dwAdjKeys = [dog cards earlier, later]. Keys are matched by their physical position (KeyboardEvent.code), so the
   numpad works with NumLock off. Keys the tool itself uses can never be assigned (DW_RESERVED). */
const DW_RESERVED = { Space: 'every tap (start, clock cues, dock end, bites)', KeyS: 'sparrows at the door', KeyX: 'pier only', KeyH: 'result: Nut', KeyM: 'result: fish',
  KeyE: 'result: empty line', KeyP: 'preview', Escape: 'stop', Backspace: 'undo', Delete: 'removes the top dog card', ArrowUp: 'dog facing', ArrowDown: 'dog facing', ArrowLeft: 'dog facing', ArrowRight: 'dog facing',
  KeyW: 'dog facing (W A S D option)', KeyA: 'dog facing (W A S D option)', KeyD: 'dog facing (W A S D option)', Enter: 'picks the top dog card, then sets its timing', NumpadEnter: 'picks the top dog card, then sets its timing', Tab: 'moves the focus' };
const DW_RESERVED_KEYS = { ' ': 'Space', s: 'KeyS', x: 'KeyX', h: 'KeyH', m: 'KeyM', e: 'KeyE', p: 'KeyP', w: 'KeyW', a: 'KeyA', d: 'KeyD' };   // the tool reads these by the letter typed
const DW_ADJ_DEF = ['BracketLeft', 'BracketRight'];
/* v31.27 (Thomas, 2026-11-22): his keys are the defaults - the numpad groups, with rollover on R, and flapper F, good-boy G,
   mess O, wiggle-bum B added. Every key stays reassignable; "Reset these keys" comes back to this set. */
const DW_ANIM_DEF_EXTRA = { 80: 'KeyR', 88: 'KeyF', 104: 'KeyG', 176: 'KeyO', 200: 'KeyB' };
const dwAnimDef = () => { const o = {}; if (DWC) for (const [g, bs] of Object.entries(DWC.NUMPAD)) for (const b of bs) o[b] = 'Numpad' + g; return Object.assign(o, DW_ANIM_DEF_EXTRA); };
const dwAnimKeys = () => Object.assign(dwAnimDef(), L.dwAnimKeys || {});
const dwAdjKeys = () => (Array.isArray(L.dwAdjKeys) && L.dwAdjKeys.length === 2 ? L.dwAdjKeys : DW_ADJ_DEF);
const CODE_TXT = { ArrowUp: '↑', ArrowDown: '↓', ArrowLeft: '←', ArrowRight: '→', Escape: 'Esc', BracketLeft: '[', BracketRight: ']', Minus: '-', Equal: '=', Semicolon: ';', Quote: "'", Comma: ',', Period: '.', Slash: '/', Backslash: '\\', Backquote: '`', IntlBackslash: '<',
  NumpadAdd: 'Num +', NumpadSubtract: 'Num −', NumpadMultiply: 'Num *', NumpadDivide: 'Num /', NumpadDecimal: 'Num .', Delete: 'Del', Insert: 'Ins', PageUp: 'PgUp', PageDown: 'PgDn' };
const codeTxt = c => (!c ? '—' : CODE_TXT[c] || (/^Key[A-Z]$/.test(c) ? c[3] : /^Digit\d$/.test(c) ? c[5] : /^Numpad\d$/.test(c) ? 'Num ' + c[6] : c));
/* why a key cannot be assigned (null = it can). kind 'anim' | 'adj'; slot = the base / 0-1 being set */
function dwKeyRefused(e, kind, slot) {
  const c = e.code || '';
  if (!c || /^(Shift|Control|Alt|Meta|OS)/.test(c) || c === 'CapsLock' || c === 'ContextMenu' || /^F\d+$/.test(c)) return 'that key cannot be used';
  if (DW_RESERVED[c]) return `${codeTxt(c)} is taken: ${DW_RESERVED[c]}`;
  const kk = e.key && e.key.length === 1 ? e.key.toLowerCase() : e.key;
  if (DW_RESERVED_KEYS[kk]) return `${codeTxt(c)} types "${kk === ' ' ? 'space' : kk}" on your layout, which is taken: ${DW_RESERVED[DW_RESERVED_KEYS[kk]]}`;
  if (e.key === L.startKey) return `${codeTxt(c)} is your start key`;
  const adj = dwAdjKeys(), ak = dwAnimKeys();
  if (kind === 'anim' && adj.includes(c)) return `${codeTxt(c)} moves the dog cards ${adj[0] === c ? 'earlier' : 'later'}`;
  if (kind !== 'fs' && L.fsKey && L.fsKey !== 'Control' && c === L.fsKey) return `${codeTxt(c)} is the Freestyle key`;
  if (kind === 'fs') {
    if (adj.includes(c)) return `${codeTxt(c)} moves the dog cards ${adj[0] === c ? 'earlier' : 'later'}`;
    const b = Object.keys(ak).find(x => ak[x] === c);
    if (b != null) return `${codeTxt(c)} is the key of "${dwName(+b)}"`;
    if (/^Arrow/.test(c) || ['KeyW', 'KeyA', 'KeyS', 'KeyD', 'KeyH', 'KeyM', 'KeyE', 'KeyP', 'KeyX', 'Enter', 'Escape', 'Backspace', 'Delete', 'Tab'].includes(c)) return `${codeTxt(c)} is taken by the tool`;
  }
  if (kind === 'adj') {
    if (adj[1 - slot] === c) return `${codeTxt(c)} is the other card-timing key`;
    const b = Object.keys(ak).find(x => ak[x] === c);
    if (b != null) return `${codeTxt(c)} is the key of "${dwName(+b)}"`;
  }
  return null;
}
/* the groups in use: [{gid, code, bases, label}]; gid = the numpad digit for an untouched default group, else 1000 + its first base */
let dwGroupCache = null;
function dwGroups() {
  if (dwGroupCache) return dwGroupCache;
  const ak = dwAnimKeys(), by = {};
  for (const [b, c] of Object.entries(ak)) if (c) (by[c] = by[c] || []).push(+b);
  const defSig = {}; if (DWC) for (const [g, bs] of Object.entries(DWC.NUMPAD)) defSig[bs.slice().sort((a, b) => a - b).join(',')] = +g;
  const out = [];
  for (const [code, bs] of Object.entries(by)) {
    bs.sort((a, b) => a - b);
    const d = defSig[bs.join(',')];
    out.push({ gid: d != null ? d : 1000 + bs[0], code, bases: bs, label: d != null ? DWC.NUMPAD_TXT[d] : bs.map(dwName).join(' / ') });
  }
  return (dwGroupCache = out);
}
const dwGroupOf = gid => dwGroups().find(g => g.gid === gid);
const dwGroupTxt = gid => { const g = dwGroupOf(gid); return g ? `${codeTxt(g.code)} ${g.label}` : (DWC && DWC.NUMPAD_TXT[gid] != null ? `${gid} ${DWC.NUMPAD_TXT[gid]}` : 'animation'); };
function dwApplyGroups() {                                      // tell the matcher which animations share a key
  dwGroupCache = null;
  if (!DWC) return;
  if (DWC.setGroups(dwGroups().map(g => [g.gid, g.bases])) && run.dw) run.dw.dirty = true;
}
let dwCap = null;                                               // a key being assigned in Settings: {kind, slot, el}
function dwCapture(e) {
  const cp = dwCap; e.preventDefault(); e.stopPropagation();
  if (e.code === 'Escape') { dwCap = null; dwKeyTable(); return; }
  if (cp.kind === 'anim' && (e.code === 'Backspace' || e.code === 'Delete')) { L.dwAnimKeys = Object.assign({}, L.dwAnimKeys, { [cp.slot]: '' }); dwCap = null; save(); dwApplyGroups(); dwKeyTable(); return; }
  if (/^(Shift|Control|Alt|Meta|OS)/.test(e.code || '')) return;   // wait for the real key
  const why = dwKeyRefused(e, cp.kind, cp.slot);
  if (why) { dwKeyTable(why); return; }
  if (cp.kind === 'anim') L.dwAnimKeys = Object.assign({}, L.dwAnimKeys, { [cp.slot]: e.code });
  else { const a = dwAdjKeys().slice(); a[cp.slot] = e.code; L.dwAdjKeys = a; }
  dwCap = null; save(); dwApplyGroups(); dwKeyTable();
}
/* Settings: one row per animation the route's dog shows (share of the wait, share of it in a readable facing), its key */
function dwAnimStats() {
  const R = routeDef().dw ? routeDef() : (LuckyCore.routes().map(r => LuckyCore.routeOf(r.id)).find(r => r && r.dw) || null), st = {};
  if (!R) return [];
  let T = 0;
  for (const Ln of R.dw.lines) for (const v of Ln.vis) { const d = (v[1] - v[0]) * (Ln.w || 1), o = st[v[4]] = st[v[4]] || { b: v[4], t: 0, rd: 0, long: 0, n: 0 }; o.t += d; T += d; o.n++; if (DWC.READABLE.has(v[2])) o.rd += d; if (v[1] - v[0] >= 30) o.long++; }
  return Object.values(st).map(o => ({ b: o.b, share: o.t / T, readable: o.rd / o.t, long: o.long / o.n })).sort((a, b) => b.share - a.share);
}
function dwKeyTable(msg) {
  const el = $('lkDwKeyTbl'); if (!el || !DWC) return;
  const ak = dwAnimKeys(), adj = dwAdjKeys(), rows = dwAnimStats(), cnt = {};
  for (const c of Object.values(ak)) if (c) cnt[c] = (cnt[c] || 0) + 1;
  const btn = (kind, slot, code) => { const on = dwCap && dwCap.kind === kind && String(dwCap.slot) === String(slot);
    return `<button type="button" class="lkkeybtn${on ? ' cap' : ''}" data-dwk="${kind}:${slot}">${on ? 'press a key…' : codeTxt(code)}</button>`; };
  el.innerHTML = (msg ? `<div class="small" style="color:#ef6f6f;margin:3px 0">${msg}</div>` : '') +
    `<table class="lkkeytbl"><tr><th>animation</th><th>share of the wait</th><th>facing S / N / east</th><th>key</th><th></th></tr>` +
    rows.map(r => `<tr><td>${dwName(r.b)}</td><td class="mono">${(100 * r.share).toFixed(1)}%</td><td class="mono">${Math.round(100 * r.readable)}%</td><td>${btn('anim', r.b, ak[r.b] || '')}</td>` +
      `<td class="mut">${ak[r.b] && cnt[ak[r.b]] > 1 ? 'shares its key: either animation fits it' : r.long < 0.2 ? 'mostly a flicker (under 0.5 s)' : ''}</td></tr>`).join('') +
    `<tr><td>dog cards earlier</td><td></td><td></td><td>${btn('adj', 0, adj[0])}</td><td class="mut">also: idle, cast 1 frame earlier</td></tr>` +
    `<tr><td>dog cards later</td><td></td><td></td><td>${btn('adj', 1, adj[1])}</td><td class="mut">also: idle, cast 1 frame later</td></tr></table>` +
    `<div class="small mut" style="margin-top:3px">Click a key, then press the new one. Backspace or Delete = no key for that animation · Esc = leave it. Two animations on one key become one group. ` +
    `Never assignable: ${[...new Set(Object.keys(DW_RESERVED).map(c => (/^Arrow/.test(c) ? 'arrows' : codeTxt(c))))].join(', ')}, your start key, Shift / Ctrl / Alt / Cmd, F1–F12.</div>`;
  el.querySelectorAll('[data-dwk]').forEach(b => { b.onclick = () => { const [kind, slot] = b.dataset.dwk.split(':'); dwCap = { kind, slot: +slot }; b.blur(); dwKeyTable(); }; });
  dwKeyChips();
}
function dwKeyChips() {                                         // the front page's key chips follow the assignment
  const gs = dwGroups(), adj = dwAdjKeys(), np = gs.length === 10 && gs.every(g => /^Numpad\d$/.test(g.code));
  const onNum = gs.filter(g => /^Numpad\d$/.test(g.code)), off = gs.filter(g => !/^Numpad\d$/.test(g.code));   // v31.27: numpad summary + the other keys
  if ($('lkKeyAnim')) $('lkKeyAnim').innerHTML = np ? '<kbd>Num 0–9</kbd> dog animation' : !gs.length ? 'no animation keys set'
    : onNum.length >= 6 ? '<kbd>Num 0–9</kbd> dog animation · ' + off.map(g => `<kbd>${codeTxt(g.code)}</kbd> ${g.label}`).join(' ')
    : gs.map(g => `<kbd>${codeTxt(g.code)}</kbd> ${g.label}`).join(' ');
  if ($('lkKeyAdj')) $('lkKeyAdj').innerHTML = `<kbd>${codeTxt(adj[0])} ${codeTxt(adj[1])}</kbd> dog cards earlier / later · idle: cast ±1 frame · <kbd>Enter</kbd> pick the top dog, again: timing set · <kbd>Del</kbd> top dog card out · <kbd>Backspace</kbd> undo`;
}
const FAC_OF = { '0,1': 0, '-1,1': 1, '-1,0': 2, '-1,-1': 3, '0,-1': 4, '1,-1': 5, '1,0': 6, '1,1': 7 };   // [dx, dy] screen (y down) -> 0..7
const DIRKEY = { arrows: { ArrowUp: [0, -1], ArrowDown: [0, 1], ArrowLeft: [-1, 0], ArrowRight: [1, 0] },
                 wasd: { KeyW: [0, -1], KeyS: [0, 1], KeyA: [-1, 0], KeyD: [1, 0] } };
function dwKey(e) {
  const w = run.dw;
  if (!w || run.wall0 === null || run.preview) return false;
  const dk = DIRKEY[L.dwKeys === 'wasd' ? 'wasd' : 'arrows'], dir = dk[e.code], ag = dir ? null : dwGroups().find(g => g.code === e.code), np = ag, adj = dwAdjKeys();
  const t = (evTime(e) - run.wall0) / viMs() + 1;
  if ((e.code === adj[0] || e.code === adj[1]) && (t < dwT() || dcHas(dwRoute()))) { for (let i = 0, n = e.shiftKey ? 10 : 1; i < n; i++) dwNudge(e.code === adj[0] ? -2 : 2); return true; }   // v30.10: line the tool's dogs up with the TV; v31.2: after the cast = step the cast frame
  /* v30.32: Delete = take the top dog card out of the pool (the x of the most likely card); Backspace undoes the last
     thing done - a removal when that came after the last arrow / animation key, else the last log as before */
  /* v32.5 (Thomas 2026-11-23 19:58: "adding enter as a key to autoselect the most likely dog without clicking it ... hit
     enter when the top dog is right and then of course that gets to tuning after"): before the cast, with no dog chosen,
     Enter = a click on the top card (the most likely dog); Enter again = its timing is set (v31.4, below) */
  if ((e.code === 'Enter' || e.code === 'NumpadEnter') && t < dwT() && !w.pick && run.wall0 !== null) {
    if (!e.repeat) { const c = dwComp(), top = c && c.lines[0]; if (top) { dwPick(top.dwi); cueFlash(`TOP DOG ${R0name(top.dwi)} · ${codeTxt(adj[0])} ${codeTxt(adj[1])} TUNE · ENTER WHEN IN STEP`, 'info', 1100); } }
    return true;
  }
  if ((e.code === 'Enter' || e.code === 'NumpadEnter') && dwCarLine(t)) { if (!e.repeat) dwConfirm(t); return true; }   // v31.4
  if (e.code === 'Delete' && t < dwT()) { if (!e.repeat) { const c = dwComp(), pk = run.dw && run.dw.pick ? run.dw.pick.dwi : null, tg = c && c.lines.find(x => x.dwi !== pk); if (c && c.lines.length > 1 && tg) dwRemove(tg.dwi); } return true; }   // v31.12: never the dog you picked
  if (e.key === 'Backspace' && !e.repeat && w.pick && t < dwT()) { dwPick(w.pick.dwi); cueFlash('SELECTION UNDONE', 'info', 600); return true; }   // v31.20: Backspace undoes the selection first
  if (e.key === 'Backspace' && !e.repeat && t >= dwT() && !run.tapInfo && !fsOn() && (w.exact != null || w.tune != null)) { w.tune = null; dwLock(null); w.carOff = true; dwCardKey = ''; cueFlash('SELECTION UNDONE', 'info', 600); return true; }
  if (e.key === 'Backspace' && t < dwT() && w.out && w.out.length && (!w.open || !w.logs.length || (w.outT[w.outT.length - 1] || 0) >= w.logs[w.logs.length - 1].t)) { dwRestore(); return true; }
  if (!w.open) return !!(dir || np) && w.frozen;                  // after HANDS ON B: swallow stray gear keys (no S toggle)
  if (e.key === 'Backspace' && w.logs.length) { w.undone.push(w.logs.pop()); w.chord = null; w.dirty = true; return true; }
  if (ag) { w.logs.push({ t, g: ag.gid }); w.chord = null; w.dirty = true; cueFlash(`DOG ${ag.label.toUpperCase()}`, 'info', 450); return true; }
  if (!dir) return false;
  w.held.set(e.code, dir);
  const c = w.chord;
  if (c && t - c.t <= 0.25 * 1000 / viMs() && c.keys.size === 1 && !c.keys.has(e.code)) {
    const d0 = [...c.keys.values()][0];
    if (d0[0] * dir[0] + d0[1] * dir[1] === 0) {                    // orthogonal: the same log becomes the diagonal
      c.keys.set(e.code, dir);
      const v = [d0[0] + dir[0], d0[1] + dir[1]];
      c.log.f = FAC_OF[v.join(',')]; w.dirty = true;
      cueFlash(`DOG ${DWC.ARROW[c.log.f]} ${DWC.FACING[c.log.f]}`, 'info', 450);
      return true;
    }
  }
  const log = { t, f: FAC_OF[dir.join(',')] };
  w.logs.push(log); w.dirty = true;
  w.chord = { t, log, keys: new Map([[e.code, dir]]) };
  cueFlash(`DOG ${DWC.ARROW[log.f]} ${DWC.FACING[log.f]}`, 'info', 450);
  return true;
}
document.addEventListener('keyup', e => {
  if (run.bite && e.key === L.startKey && root.HM64Arena === 'lucky') { biteRelease(evTime(e), keyName() + ' release'); e.preventDefault(); }   // v30.26
  if (run.practice && e.key === L.startKey && root.HM64Arena === 'lucky') { practiceRelease(evTime(e), keyName() + ' release'); e.preventDefault(); }   // v30.27
  if (run.spc && e.key === L.startKey && root.HM64Arena === 'lucky' && run.wall0 !== null) { holdUp((evTime(e) - run.wall0) / viMs() + 1); e.preventDefault(); }   // v31.6
  const w = run.dw;
  if (!w) return;
  w.held.delete(e.code);
  if (w.chord && ![...w.chord.keys.keys()].some(k => w.held.has(k))) w.chord = null;   // released: the next press is a new turn
}, true);
function dwLamp(t) {                                            // the lamp's sub line while the watch is open
  const w = run.dw;
  if (!w || !w.open) return null;
  const hob = fsOn() ? 'FREESTYLE: you choose the cast' : `HANDS ON B ${((dwT() - dwLeadVI() - t) * viMs() / 1000).toFixed(1)} s`;
  if (!w.logs.length) return `WATCH THE DOG: first arrow = its facing · ${hob}`;
  const s = w.sum;
  return `dog-watch: ${w.logs.length} log${w.logs.length > 1 ? 's' : ''}` + (s && s.top ? ` · top line ${Math.round(100 * s.top.p)}% · ${s.left} left` : '') +
    ` · ${hob}`;
}
/* ---- v30.10 (Thomas, 2026-11-17): competing lines + manual adjustment. The dog-watch box shows the three most likely
   dog lines as the Dog Oracle shows its potential dogs: each card plays what THAT line's dog does at this moment (sprite,
   animation, facing, time to its next change), from the lab trace of the line at its most likely alignment on the
   stopwatch (alignment a: trace VI k = stopwatch t + a; a = READY offset of the variant - 1). The state line says how
   sure the app is: LOCKED from 90% on one line. Manual (optional): click the card that does what the TV dog does = "this
   is my dog"; [ and ] (or the buttons) move the tool's dogs 1 game frame earlier / later until they turn with the TV.
   A pick replaces the plan by that line's cast table at the alignment you lined up (a +- DW_EYE VIs by eye): the cast
   table index of a cast at stopwatch T is T + a + 1, whatever part of a is the READY time and what part is the clock. */
const DW_EYE = 4, DW_LOCK = 0.9, DW_DROP = 0.05, DW_PICK_MIN = 90, DW_PICK_LEAD = 120;   // VIs: 1.5 s / 2 s
/* P(the landed cast frame has a Nut on some bite) for a cast aimed at each stopwatch VI, over the plan's variants and the
   B spread sig (VIs). With the dog line known the bite taps pin the frame, and the lamp's calls then lose no Nut (UI lab:
   0 lost of 269), so this is what a cast is worth. -> { at(T), best: {t, p} from tMin on, peak: {t, p} over the table } */
function anyBiteCurve(Q, sig, tMin) {
  const ser = Q.series, vs = Q.variants.filter(x => x.w > 0), W = vs.reduce((a, x) => a + x.w, 0) || 1, R3 = Math.ceil(3 * sig), ker = [];
  for (let d = -R3; d <= R3; d++) ker.push(Math.exp(-0.5 * (d / Math.max(1, sig)) ** 2));
  const kz = ker.reduce((a, b) => a + b, 0);
  const hit = vs.map(x => { const S = ser[x.s], h = new Uint8Array(S.len), known = i => i >= 0 && i < S.len && S.n1[i] >= 0 && S.n2[i] >= 0;
    for (let i = 0; i < S.len; i++) { const j = known(i) ? i : known(i - 1) ? i - 1 : known(i + 1) ? i + 1 : -1;   // the tables hold one entry per game frame (2 VIs): an odd VI is the frame before it
      h[i] = j >= 0 && (S.n1[j] > 0 || S.n2[j] > 0 || (S.bx && S.bx[j] && S.bx[j].some(b => b < 0))) ? 1 : 0; }
    return h; });
  const at = T => { if (T == null) return null; let p = 0;
    vs.forEach((x, j) => { const S = ser[x.s], c = Math.round(T) + x.o - S.v0; let q = 0;
      for (let d = -R3; d <= R3; d++) { const i = c + d; if (i >= 0 && i < S.len && Math.round(T) + d >= (x.minT || 1) && hit[j][i]) q += ker[d + R3]; }
      p += x.w * q / kz; });
    return p / W; };
  let lo = Infinity, hi = -Infinity;
  for (const x of vs) { const S = ser[x.s]; lo = Math.min(lo, S.v0 - x.o); hi = Math.max(hi, S.v0 - x.o + S.len - 1); }
  let best = null, peak = null;
  for (let T = Math.max(1, Math.floor(lo)); T <= hi; T++) { const p = at(T); if (!peak || p > peak.p) peak = { t: T, p }; if (T >= tMin && (!best || p > best.p)) best = { t: T, p }; }
  return { at, best, peak, lo: Math.max(1, Math.floor(lo)), hi };
}
/* v30.32 (Thomas, 2026-11-20): "the top card does something my dog is not doing, and there is no time to key it" - a
   small x on each dog card takes that line out of the pool for this attempt (its weight x DW_OUT: gone from the cards,
   the plan and the cast), "Undo x" puts the last one back. It is the player's override, like a pick: the app cannot
   check it. A removed line that carries a pick loses the pick; the last line left cannot be removed. */
const DW_OUT = 1e-6;
const dwOutHas = (w, dwi) => !!(w && w.out && (w.out.includes(dwi) || (w.outX && w.outX.some(m => m && m.includes(dwi)))));   // v31.17: a removed family card takes its joined sisters along
const dwOutF = w => (w && w.out && w.out.length ? c => (dwOutHas(w, c.dwi) ? DW_OUT : 1) : () => 1);
function dwOutApply(w) {
  const t = (now() - run.wall0) / viMs() + 1;
  w.dirty = true; w.comp = null; dwCardKey = '';
  if (t < dwT()) dwUpdate(t, !!w.frozen);
  dwCards(t);
}
function dwRemove(dwi) {
  const w = run.dw, R = dwRoute(); if (!w || !R || run.wall0 === null || run.preview) return false;
  const t = (now() - run.wall0) / viMs() + 1, c = dwComp();
  if (t >= castCueT() || !c || c.lines.length < 2 || !c.lines.some(x => x.dwi === dwi)) return false;
  if (w.pick && w.pick.dwi === dwi) { w.pick = null; dwQuiet(w, t, true); }
  { const fx = c.lines.find(x => x.dwi === dwi); (w.outX || (w.outX = [])).length = (w.out || []).length; w.outX.push(fx && fx.fam ? fx.fam.m.slice() : null); }
  (w.out || (w.out = [])).push(dwi); (w.outT || (w.outT = [])).push(t); w.outs = (w.outs || 0) + 1;
  cueFlash(`${R.dw.lines[dwi].li >= 0 ? 'L' + (R.dw.lines[dwi].li + 1) : 'LINE'} REMOVED · Backspace puts it back`, 'info', 900);
  dwOutApply(w);
  return true;
}
function dwRestore() {
  const w = run.dw; if (!w || !w.out || !w.out.length || run.wall0 === null) return false;
  w.out.pop(); if (w.outT) w.outT.pop(); if (w.outX) w.outX.length = w.out.length; cueFlash('DOG LINE PUT BACK', 'info', 700); dwOutApply(w);
  return true;
}
function dwComp() {
  const w = run.dw, R = dwRoute();
  if (!w || !R) return null;
  if (!w.cands) w.cands = DWC.candidates(R, w.base, LuckyCore.selection.pace, anchor());
  const g3 = w.g3, oF = dwOutF(w), l3 = c => oF(c) * (g3 ? Math.exp(-0.5 * ((g3.tau3 - c.mt - g3.r3) / g3.sd) ** 2) : 1);
  const lk = w.lk && w.lk.length === w.cands.length ? w.lk : null, by = new Map();
  let Z = 0;
  w.cands.forEach((c, i) => {
    const p = c.w * l3(c) * (lk ? lk[i] : 1);
    if (!(p > 0) || dwOutHas(w, c.dwi)) return;   // v30.32: a card removed by its x is out of the pool
    Z += p;
    let o = by.get(c.dwi); if (!o) by.set(c.dwi, o = { dwi: c.dwi, p: 0, sa: 0, saa: 0 });
    const a = c.ko - c.mt; o.p += p; o.sa += p * a; o.saa += p * a * a;
  });
  let lines = [...by.values()].map(o => ({ dwi: o.dwi, p: o.p / Z, a: o.sa / o.p, sd: Math.sqrt(Math.max(0, o.saa / o.p - (o.sa / o.p) ** 2)), li: R.dw.lines[o.dwi].li })).sort((x, y) => y.p - x.p);
  lines = dwFold(R, w, lines);
  return (w.comp = { at: now(), n: w.logs.length, g3: !!g3, out: (w.out || []).length, lines, left: lines.filter(x => x.p >= 0.01).length });
}
/* v31.17 SISTER LINES (Thomas 2026-11-21 14:43 / 14:47; tools/dw_families.py -> R.dw.fam[dwi] = [rep, d, join]).
   Most dog lines are the same dog path as another line, moved by a whole number of game frames, from some moment on
   (0 - 28 s after READY); from then on their casts are the same too. A line that has JOINED its family (its own dog is
   FAM_MARGIN past the joining moment) is shown on one card with its joined sisters: share = their sum, the dog = the
   heaviest of them (or the one the player chose) at its own timing; the frame keys find the true timing. Before the
   joining moment a line stays its own card: always accurate. Display only - the weighing of the lines is untouched.
   trace_rep[k] == trace_m[k + d]  ->  a sister m at alignment a_m is the dog of line x at alignment a_m - d_m + d_x. */
const FAM_MARGIN = 60;
function dwFold(R, w, lines) {
  const F = R.dw.fam; if (!F || L.dwFamily === false || run.wall0 === null) return lines;
  const t = (now() - run.wall0) / viMs() + 1, grp = new Map(), out = [];
  for (const x of lines) { const f = F[x.dwi]; if (!f) { out.push(x); continue; }
    const joined = t + x.a - f[1] >= f[2] + FAM_MARGIN;
    if (!joined) { out.push(x); continue; }
    let g = grp.get(f[0]); if (!g) grp.set(f[0], g = []); g.push(x); }
  for (const g of grp.values()) {
    if (g.length < 2) { out.push(g[0]); continue; }
    const held = [w.pick && w.pick.dwi, w.exact, w.tune, w.lock && w.lock.dwi].filter(v => v != null);
    const keep = g.find(x => held.includes(x.dwi)) || g.find(x => x.li >= 0) || g[0];      // g is by share: the heaviest with a table
    const dk = F[keep.dwi][1], p = g.reduce((q, x) => q + x.p, 0);
    out.push(Object.assign({}, keep, { p, fam: { n: g.length, m: g.map(x => x.dwi),
      sis: g.filter(x => x !== keep).map(x => ({ dwi: x.dwi, li: x.li, p: x.p, df: Math.round((x.a - F[x.dwi][1] + dk - keep.a) / 2) })) } }));
  }
  return out.sort((x, y) => y.p - x.p);
}
function dwShow(R, dwi, k) {                                    // what the line's dog shows at trace VI k
  const vis = R.dw.lines[dwi].vis;
  let lo = 0, hi = vis.length - 1, j = -1;
  while (lo <= hi) { const m = (lo + hi) >> 1; if (vis[m][1] <= k) lo = m + 1; else if (vis[m][0] > k) hi = m - 1; else { j = m; break; } }
  if (j < 0) return null;
  let n = j + 1; while (n < vis.length && vis[n][2] === vis[j][2] && vis[n][4] === vis[j][4]) n++;
  return { base: vis[j][4], dir: vis[j][2], next: n < vis.length ? { k: vis[n][0], base: vis[n][4], dir: vis[n][2] } : null };
}
const dwName = b => (D.names && D.names[b]) || (b === 32 ? 'stand' : 'anim ' + b);
dwApplyGroups();
/* v31.2: after the cast the cards play each line's dog for the frame the cast landed on (D.dogcast); the nudge keys
   then step that frame (one game frame = 2 VIs) instead of the cards' timing */
const DCAST = (D && D.dogcast) || null;
const dcHas = R => !!(DCAST && R && R.dw && R.dw.lines.some(l => DCAST.lines[l.key]));
function dcFrame(R, dwi, df) {                                   // the stopwatch VI this card takes as the cast frame (df: carousel offset in game frames)
  const w = run.dw, ti = run.tapInfo, step = 2 * (((w && w.cadj) || 0) + (df || 0));
  /* v31.13: a dog the player locked keeps the frame it was locked at; [ ] move it from there. Bite marks made later
     do not move it (a first bite fits several neighbouring frames; the dog seen in step does not). */
  if (w && w.lock && w.lock.dwi === dwi && w.exact === dwi) return { c: w.lock.kc0 - w.lock.a + step, src: 'lock', a: w.lock.a };
  let c = run.castTap !== null && run.castTap !== undefined ? run.castTap : run.T, src = run.castTap != null ? 'tap' : 'aim';
  if (ti && ti.fit && ti.sc && ti.sc.length) {                    // the bite marks weigh the landed frames of this line
    /* v31.13 BUG FIX (present since v31.2): every scenario of the bite marks is a (READY offset o, landed table frame
       pv) pair; its lab label is pv - 1 and its stopwatch time pv - o. The old code took only the landed offset d,
       summed over all READY offsets, and then added THE CARD'S alignment - a label up to several frames off, so after
       a bite mark the card (and a locked frame's bite schedule) jumped to a neighbouring frame's dog and bites. */
    const sx = R.sidxs[R.dw.lines[dwi].li], m = new Map();
    for (const e of ti.sc) if (e.path === sx && e.pv != null) { const o = +String(e.pair).split(':')[1], k = e.pv + ':' + o; m.set(k, (m.get(k) || 0) + e.w); }
    if (m.size) { const [pv, o] = [...m.entries()].sort((x, y) => y[1] - x[1])[0][0].split(':').map(Number); return { c: pv - o + step, src: 'bite', a: o - 1 }; }
  }
  return { c: Math.round(c) + step, src };
}
function dcLabel(R, dwi, a, df) {                                 // cast frames are the even trace labels; a = the alignment the label was taken at
  const fr = dcFrame(R, dwi, df), A = fr.a != null ? fr.a : a;
  let kc = Math.round(fr.c + A); kc -= ((kc % 2) + 2) % 2;
  return { kc, src: fr.src, a: A };
}
function dwLock(dwi) {                                            // v31.13: this dog at the frame its card shows now
  const w = run.dw, R = dwRoute(); if (!w || !R) return;
  if (dwi == null) { w.exact = null; w.lock = null; return; }
  w.exact = null; w.lock = null;
  const a = dcCardA(dwi), L0 = a === null ? null : dcLabel(R, dwi, a, 0);
  w.exact = dwi; w.lock = L0 ? { dwi, kc0: L0.kc - 2 * (w.cadj || 0), a: L0.a } : null;
}
/* v31.3 (Thomas, 2026-11-20): with the line AND the frame known, the bites are known. The exact schedule of a card's
   frame: every bite while B is held (stopwatch VI) and what letting go at it catches (N = Power Nut, s / m / l fish). */
function dcBites(R, dwi, a, df) {
  if (!DCAST) return null;
  const LB = dcLabel(R, dwi, a, df); a = LB.a;                    // times are converted at the alignment the label was taken at
  const ln = DCAST.lines[R.dw.lines[dwi].key], kc = LB.kc, j = ln ? (kc - ln.k0) / 2 : -1;
  if (!ln || j < 0 || j >= ln.idx.length || ln.idx[j] < 0) return null;
  const cid = ln.idx[j], bites = [];
  let f = DCAST.F[cid], st = DCAST.S[cid], lab = kc + f;
  while (f >= 0 && st >= 0 && bites.length < 16) {
    bites.push({ n: bites.length + 1, t: lab - a, o: DCAST.O[st] });
    if (DCAST.N[st] < 0) break;
    lab += DCAST.N[st]; st = DCAST.X[st];
  }
  return { kc, bites, nut: bites.find(b => b.o === 'N') || null };
}
const DC_FISH = { N: 'NUT', s: 'small fish', m: 'medium fish', l: 'large fish', d: 'day ends', x: 'miss' };
function dcCardA(dwi) {                                          // the timing this card is played at (as dwCards does)
  const w = run.dw, c = w && (w.comp || dwComp()), ln = c && c.lines.find(x => x.dwi === dwi);
  return ln ? (w.pick && w.pick.dwi === dwi ? w.pick.a0 : ln.a) + w.adj : null;
}
function dcExact(t) {                                            // the card the player said is his dog after the cast
  const w = run.dw, R = dwRoute();
  if (!w || w.exact == null || !R || run.wall0 === null || run.preview || t < dwT() || !dcHas(R)) return null;
  const a = dcCardA(w.exact); if (a === null) return null;
  const B = dcBites(R, w.exact, a);
  return { dwi: w.exact, name: R.dw.lines[w.exact].li >= 0 ? 'L' + (R.dw.lines[w.exact].li + 1) : 'this line', a, B };
}
function exactCue(t) {
  const x = dcExact(t); if (!x) return null;
  const vi = viMs(), who = `if ${x.name} at this frame is your dog`;
  if (!x.B) return { kind: 'info', big: 'NO DATA FOR THIS FRAME', sub: who };
  const list = x.B.bites.map(b => `${b.n}: ${DC_FISH[b.o] || b.o} ${fmtS1(b.t)} s`).join(' · ');
  const nb = x.B.nut;
  if (!nb) return { kind: 'bad', big: 'NO NUT ON THIS CAST', sub: `${who} · bites ${list || 'none in the data'}` };
  const dt = (nb.t - t) * vi;
  if (dt <= 0 && dt > -(WINDOW_VI + 6) * vi) return { kind: 'nut', big: `LET GO NOW · BITE ${nb.n} = NUT`, sub: who, bar: Math.max(0, 1 + dt / (WINDOW_VI * vi)), glow: 1 };
  if (dt <= 0) return { kind: 'info', big: `THE NUT WAS BITE ${nb.n}`, sub: `${who} · it showed at ${fmtS1(nb.t)} s` };
  const cur = x.B.bites.find(b => b.t > t - WINDOW_VI);
  if (cur && cur.n < nb.n) return { kind: 'hold', big: `BITE ${cur.n}: HOLD · NUT IS BITE ${nb.n}`, sub: `${who} · bite ${cur.n} (${DC_FISH[cur.o] || cur.o}) ${t < cur.t ? 'in ' + ((cur.t - t) * vi / 1000).toFixed(1) + ' s' : 'now'} · Nut in ${(dt / 1000).toFixed(1)} s` };
  return { kind: dt <= 1500 ? 'ready' : 'hold', big: `LET GO AT BITE ${nb.n} · NUT`, sub: `${who} · in ${(dt / 1000).toFixed(1)} s (${fmtS1(nb.t)} s)`, bar: dt <= 3000 ? 1 - dt / 3000 : null, glow: dt <= 600 ? 0.8 : 0 };
}
function dcShow(R, dwi, t, a, df) {                               // undefined = no data; else {base, dir, cast: true, df}
  const LB = dcLabel(R, dwi, a, df), kc = LB.kc, fr = LB; a = LB.a;
  const nat = dwShow(R, dwi, kc);
  const code = LuckyCore.dogAfterCast(DCAST, R.dw.lines[dwi].key, kc, Math.round(t + a) - kc, dcRel(), nat ? nat.base * 8 + nat.dir : 0);
  return code === undefined ? undefined : { base: code >> 3, dir: code & 7, next: null, cast: true, src: fr.src };
}
function dcRel() {                                               // the bite B is let go at, as far as the app knows
  const ti = run.tapInfo;
  if (ti && ti.released) return ti.released;
  return run.pol === 'bite1' ? 1 : 0;
}
function dwNudge(dv) {
  const w = run.dw; if (!w) return;
  if (run.wall0 !== null && (now() - run.wall0) / viMs() + 1 >= dwT() && dcHas(dwRoute())) {
    w.cadj = Math.max(-150, Math.min(150, (w.cadj || 0) + Math.sign(dv))); dwCardKey = '';
    if (w.exact == null) { const cl = dwCarLine((now() - run.wall0) / viMs() + 1); if (cl) { w.cadj -= Math.sign(dv); dwLock(cl.dwi); w.cadj += Math.sign(dv); } }   // v31.13: scrolling a dog after the cast locks it in (at the frame it showed, then moved)
    return;
  }
  w.adj = Math.max(-240, Math.min(240, w.adj + dv)); if (w.pick) { w.dirty = true; w.tuned = false; } dwCardKey = '';
}
/* v31.4 (Thomas, 2026-11-20): the carousel. A clicked dog takes the whole card row: the same dog as many times as
   there are cards, each one game frame apart, the tuned one in the middle. [ ] scroll it (the cards' timing before
   the cast, the cast frame after it); a side card clicked comes to the middle; Enter (or the middle card) says "this
   one". Before the cast that closes the carousel (the pick stands); after the cast it sets line + frame and the lamp
   calls the bites (v31.3). */
function dwCarLine(t) {
  const w = run.dw, R = dwRoute(); if (!w || !R) return null;
  const post = t >= dwT() && dcHas(R);
  const dwi = post ? (w.carOff ? null : w.tune != null ? w.tune : w.pick ? w.pick.dwi : null) : (w.pick && !w.tuned ? w.pick.dwi : null);
  return dwi == null ? null : { dwi, post };
}
function dwConfirm(t) {
  const w = run.dw, car = dwCarLine(t); if (!w || !car) return false;
  if (!car.post) { w.tuned = true; dwCardKey = ''; cueFlash('TIMING SET · [ ] open it again', 'info', 800); return true; }
  if (w.exact !== car.dwi) dwLock(car.dwi); w.exacts = (w.exacts || 0) + 1; dwCardKey = '';   // v31.13: Enter / the middle frame only ever lock (a click on the dog's card lets go)
  const x = dcExact(t);
  cueFlash(x ? (x.B && x.B.nut ? `FRAME SET · NUT ON BITE ${x.B.nut.n}` : 'FRAME SET · NO NUT ON THIS CAST') : 'FRAME CLEARED', x && x.B && x.B.nut ? 'go' : 'info', 900);
  return true;
}
function dwCarClick(off) {
  const t = (now() - run.wall0) / viMs() + 1;
  if (!off) { dwConfirm(t); return; }
  for (let i = 0; i < Math.abs(off); i++) dwNudge(off < 0 ? -2 : 2);
}
/* v30.25: the spans in which a dog is picked (no arrows expected): opened at the pick, closed when it is cleared / dropped */
function dwQuiet(w, t, had) {
  const q = w.quiet || (w.quiet = []), open = q.length && q[q.length - 1][1] === Infinity;
  if (w.pick && !open) q.push([t, Infinity]);
  else if (!w.pick && open) q[q.length - 1][1] = t;
}
const R0name = dwi => { const R = dwRoute(), li = R ? R.dw.lines[dwi].li : -1; return li >= 0 ? 'L' + (li + 1) : 'DOG'; };
function dwPick(dwi) {
  const w = run.dw; if (!w || run.wall0 === null) return;
  const c = (w.comp || dwComp()), ln = c && c.lines.find(x => x.dwi === dwi);
  const t = (now() - run.wall0) / viMs() + 1, had = !!w.pick;
  if (t >= dwT() && dcHas(dwRoute())) {                           // v31.4: after the cast a click opens the carousel on that dog; Enter sets the frame
    if (!ln) return;
    const cur = dwCarLine(t);
    if (cur && cur.dwi === dwi && w.exact === dwi) { w.tune = null; dwLock(null); w.carOff = true; dwCardKey = ''; return; }   // the same card again: let go of it
    /* v31.13 (Thomas 2026-11-21 10:34): no Enter needed - the click says "this is my dog at this frame"; [ ] then change
       the frame that is locked in */
    w.tune = dwi; w.carOff = false; dwLock(dwi); dwCardKey = '';
    cueFlash(`TUNING ${R0name(dwi)} · [ ] scroll · Enter when it matches`, 'info', 1100);
    return;
  }
  w.pick = w.pick && w.pick.dwi === dwi ? null : ln ? { dwi, a0: ln.a } : null; w.tuned = false;
  dwQuiet(w, t, had);
  w.dropped = null; w.picks = (w.picks || 0) + (w.pick ? 1 : 0);
  w.dirty = true; dwCardKey = '';
  if (t < dwT()) dwUpdate(t, !!w.frozen);
}
let dwCardKey = '';
/* v31.5 (Thomas 2026-11-20 20:11): the carousel is three compact rows - a frame earlier, the tuned frame, a frame
   later, top to bottom - that drop out of the bottom of the tuned dog's card. The dog lines above stay as they are,
   so the other dogs remain in view and the place of the carousel follows the "most likely dog on the left / middle /
   right" setting through the card it hangs from. Always three, whatever the number of dog cards. */
/* v31.11 (Thomas 2026-11-20 23:05): mouse over a dog card = a look ahead on that line: what its dog does now and the
   next things it will do, each with a live countdown to its start and how long it lasts, so the player can wait for
   one of them on the TV and then click the card. Read from the line's lab trace at the card's own timing (the same
   alignment the card plays at), so it is exactly what the card will show. Before the cast only: after it the dog
   depends on the frame the cast landed on. The panel never takes the mouse (pointer-events: none). */
let dwPeekDwi = null, dwPeekKey = '';
function dwPeekHide() { const p = $('lkPeek'); if (p && !p.hidden) p.hidden = true; dwPeekKey = ''; }
function dwPeek(t, show, R, w) {
  if (!L.dwPeekOn) { dwPeekHide(); return; }                       // v31.20: "Mouseover forecast", off by default
  const host = $('lkCompCards');
  if (!host.dataset.peek) {
    host.dataset.peek = '1';
    host.addEventListener('mouseover', e => { const cd = e.target.closest ? e.target.closest('.lkdog') : null; dwPeekDwi = cd ? +cd.dataset.dwi : null; });
    host.addEventListener('mouseleave', () => { dwPeekDwi = null; dwPeekHide(); });
  }
  const x = dwPeekDwi != null ? show.find(y => y.dwi === dwPeekDwi) : null, card = x ? host.querySelector('.lkdog[data-dwi="' + x.dwi + '"]') : null;
  if (!x || !card) { dwPeekHide(); return; }
  let p = $('lkPeek');
  if (!p) { p = document.createElement('div'); p.id = 'lkPeek'; p.className = 'lkpeek'; p.hidden = true; document.body.appendChild(p); }
  const name = x.li >= 0 ? 'L' + (x.li + 1) : 'no table', a = (w.pick && w.pick.dwi === x.dwi ? w.pick.a0 : x.a) + w.adj, k = t + a, vis = R.dw.lines[x.dwi].vis;
  const post = t >= dwT();
  const runs = [];                                                // [from, to, base, dir]: neighbours showing the same thing joined
  if (!post) for (const r of vis) {
    if (r[1] <= k) continue;
    const l = runs[runs.length - 1];
    if (l && l[2] === r[4] && l[3] === r[2] && r[0] <= l[1]) { l[1] = r[1]; continue; }
    if (runs.length >= 6) break;
    runs.push([r[0], r[1], r[4], r[2]]);
  }
  const key = x.dwi + '|' + post + '|' + runs.map(r => r[0]).join(',');
  if (key !== dwPeekKey || p.hidden) {
    dwPeekKey = key; p.hidden = false;
    p.innerHTML = `<div class="ph"><b>${name}</b> · what its dog does next <span class="mut">(at this card's timing)</span></div>` +
      (post ? '<div class="mut">After the cast the dog depends on the frame your cast landed on: no look-ahead here. Use the three frames under the card.</div>'
        : runs.length ? runs.map((r, i) => `<div class="pr${i === 0 && r[0] <= k ? ' now' : ''}"><img alt="" src="${D.sprites[r[2] + '_' + r[3]] || ''}"><span class="pn"><b>${dwName(r[2])}</b> ${DWC.ARROW[r[3]]} ${DWC.FACING[r[3]]}</span><span class="pt"></span></div>`).join('')
          : '<div class="mut">Past the end of this line\'s trace.</div>');
  }
  if (!post) p.querySelectorAll('.pr').forEach((el, i) => {
    const r = runs[i]; if (!r) return;
    const inS = (r[0] - k) * viMs() / 1000, len = (r[1] - r[0]) * viMs() / 1000, left = (r[1] - k) * viMs() / 1000;
    const last = i === runs.length - 1 && r[1] >= vis[vis.length - 1][1];
    const tx = inS <= 0 ? `now · ${last ? 'to the end of the trace' : left.toFixed(1) + ' s left'}` : `in ${inS.toFixed(1)} s · lasts ${len.toFixed(1)} s`;
    const pt = el.querySelector('.pt'); if (pt.textContent !== tx) pt.textContent = tx;
    el.classList.toggle('soon', inS > 0 && inS <= 1);
  });
  const rc = card.getBoundingClientRect(), ph = p.offsetHeight, pw = p.offsetWidth;
  /* under the card; when the window is too short for that, beside it (right, else left) - never above it, where the
     lamp and the histogram are */
  let top = rc.bottom + 6, left = Math.max(4, Math.min(rc.left, root.innerWidth - pw - 4));
  if (top + ph > root.innerHeight - 4) { top = Math.max(4, root.innerHeight - ph - 4); left = rc.right + 6 + pw <= root.innerWidth - 4 ? rc.right + 6 : Math.max(4, rc.left - pw - 6); }
  if (p.dataset.xy !== left + ',' + top) { p.dataset.xy = left + ',' + top; p.style.left = left + 'px'; p.style.top = top + 'px'; }
}
let dwCarKey = '';
function dwCarHide() { const col = $('lkCar'); if (col && !col.hidden) { col.hidden = true; col.innerHTML = ''; } dwCarKey = ''; }
function dwCarCol(t, car, show, R, c) {
  const w = run.dw, host = $('lkCompCards');
  let col = $('lkCar');
  if (!col) { col = document.createElement('div'); col.id = 'lkCar'; col.className = 'lkcar'; col.hidden = true; host.parentNode.insertBefore(col, host.nextSibling); }
  if (!car) { dwCarHide(); return; }
  const x = show.find(y => y.dwi === car.dwi), name = R.dw.lines[car.dwi].li >= 0 ? 'L' + (R.dw.lines[car.dwi].li + 1) : 'no table';
  const key = car.dwi + '|' + car.post + '|' + (w.exact === car.dwi);
  if (key !== dwCarKey || col.hidden) {
    dwCarKey = key; col.hidden = false;
    col.innerHTML = '<div class="crs">' + [-1, 0, 1].map(off => `<div class="carrow${off === 0 ? ' ctr' + (w.exact === car.dwi ? ' exact' : '') : ''}" data-off="${off}" title="${off === 0 ? 'The tuned frame. Click it or press Enter when it stays with your dog.' : 'Click: bring this one to the middle'}">` +
      `<span class="co">${off === 0 ? '●' : off > 0 ? '+1' : '−1'}</span><img alt=""><span class="ct"><b class="cardtxt"></b><i class="cw">${name} · ${off === 0 ? 'tuned' : (car.post ? 'frame' : Math.round(2 * viMs()) + ' ms') + (off > 0 ? ' later' : ' earlier')}</i><i class="nx"></i></span></div>`).join('') + '</div>' +
      `<div class="cn" title="How far you have scrolled this dog from where the app put it: + = later, − = earlier. ${car.post ? 'After the cast: cast frames from the ' + (run.tapInfo && run.tapInfo.fit ? 'frame the bite tap points to' : run.castTap != null ? 'cast tap' : 'aimed frame') : 'Before the cast: game frames from the app’s best guess of the timing'}."><b></b><i>frames</i><i class="ms"></i><i class="fr">${car.post ? 'cast frame' : 'timing'}</i></div>`;
    for (const el of col.querySelectorAll('.carrow')) { el.onmousedown = e => e.preventDefault(); el.onclick = () => dwCarClick(+el.dataset.off); }
  }
  const card = host.querySelector('.lkdog[data-dwi="' + car.dwi + '"]');
  if (card) { const ml = Math.max(0, Math.min(card.offsetLeft - host.offsetLeft - host.scrollLeft, host.clientWidth - col.offsetWidth)); if (col.dataset.ml !== String(ml)) { col.dataset.ml = String(ml); col.style.marginLeft = ml + 'px'; } }
  const lit = car.post, a0 = (w.pick && w.pick.dwi === car.dwi ? w.pick.a0 : x ? x.a : 0) + w.adj;
  { const nfr = lit ? (w.cadj || 0) : Math.round(w.adj / 2), cn = col.querySelector('.cn'), tx = (nfr > 0 ? '+' : nfr < 0 ? '−' : '') + Math.abs(nfr);   // v31.6: how far the dog has been scrolled
    const b = cn.querySelector('b'); if (b.textContent !== tx) { b.textContent = tx; cn.querySelector('.ms').textContent = (nfr > 0 ? '+' : nfr < 0 ? '−' : '') + Math.round(Math.abs(nfr) * 2 * viMs()) + ' ms'; cn.classList.toggle('zero', nfr === 0); } }
  col.querySelectorAll('.carrow').forEach(el => {
    const off = +el.dataset.off, a = a0 + (lit ? 0 : 2 * off), df = lit ? off : 0;
    const shc = lit ? dcShow(R, car.dwi, t, a, df) : null, sh = lit ? (shc || null) : dwShow(R, car.dwi, Math.round(t + a)), img = el.querySelector('img'), src = sh ? D.sprites[sh.base + '_' + sh.dir] || '' : '';
    el.classList.toggle('gone', lit && shc === undefined);
    if (img.dataset.src !== src) { img.dataset.src = src; if (src) img.src = src; else img.removeAttribute('src'); }
    const txt = sh ? `${dwName(sh.base)} ${DWC.ARROW[sh.dir]} ${DWC.FACING[sh.dir]}` : lit ? 'no data after this cast' : t + a < 0 ? 'before READY' : 'past the trace';
    const ct = el.querySelector('.cardtxt'); if (ct.textContent !== txt) ct.textContent = txt;
    const bq = lit && shc ? dcBites(R, car.dwi, a, df) : null;
    const nx = lit ? (shc ? (bq && bq.nut ? `NUT on bite ${bq.nut.n}, ${fmtS1(bq.nut.t)} s` : bq && bq.bites.length ? `no Nut (${bq.bites.length} bite${bq.bites.length > 1 ? 's' : ''})` : 'no bite in the data') : '') : sh && sh.next ? `next ${((sh.next.k - (t + a)) * viMs() / 1000).toFixed(1)} s: ${sh.next.dir !== sh.dir ? DWC.ARROW[sh.next.dir] + ' ' : ''}${sh.next.base !== sh.base ? dwName(sh.next.base) : ''}` : '';
    const ne = el.querySelector('.nx'); if (ne.textContent !== nx) ne.textContent = nx;
  });
}
function dwCards(t) {
  const box = $('lkComp'); if (!box) return;
  const w = run.dw, R = dwRoute(), live = !!(w && R && run.wall0 !== null && !run.preview && !run.practice && !run.bite);
  $('lkDwManual').hidden = !R;
  if (!live) {
    dwCarHide();                                                  // v31.7 BUG FIX: the carousel stayed on screen after the attempt ended
    { const bx = $('lkDw'), hd = $('lkCompHead'), cc = $('lkCompCards'); if (cc) cc.classList.remove('cal'); if (bx) bx.classList.remove('cal'); if (hd && hd.classList.contains('cal')) { hd.classList.remove('cal'); hd.textContent = 'Competing lines'; } }
    dwPeekHide();
    if (dwCardKey !== 'idle') { dwCardKey = 'idle'; if ($('lkDwOutUndo')) { $('lkDwOutUndo').disabled = true; $('lkDwOutUndo').textContent = 'Undo ×'; } $('lkCompCards').innerHTML = ''; $('lkCompState').textContent = ''; $('lkDwAdj').textContent = '';
      $('lkCompTxt').textContent = 'During an attempt: the three most likely dog lines, each playing what its dog does at that moment, and how sure the app is of the line.'; }
    return;
  }
  let c = w.comp;
  if (!c || c.n !== w.logs.length || c.g3 !== !!w.g3 || c.out !== (w.out || []).length || now() - c.at > 700) c = dwComp();
  if (!c || !c.lines.length) { dwCarHide(); return; }
  const nShow = [3, 5, 7].includes(+L.dwCards) ? +L.dwCards : 3;
  let show = c.lines.slice(0, nShow);
  const car = dwCarLine(t);
  /* v31.12 (Thomas 2026-11-21 09:14: "when a player selects a dog, keep that in the number 1 position, it's hard to
     gauge if it's synced with it jumping around"): the dog the player chose - the pick, else the dog being tuned or
     set after the cast - always takes the first place of the row (where the fill setting puts the most likely dog),
     whatever its share does; the others follow in their order. */
  const mine = t >= dwT() && dcHas(R) ? (car ? car.dwi : w.exact != null ? w.exact : null)        // after the cast: the dog being tuned / locked (Backspace lets go of it)
    : w.pick ? w.pick.dwi : car ? car.dwi : w.exact != null ? w.exact : null;
  if (mine != null) {
    const ml = c.lines.find(x => x.dwi === mine) || { dwi: mine, p: 0, a: w.pick && w.pick.dwi === mine ? w.pick.a0 : 0, sd: 0, li: R.dw.lines[mine].li };
    /* v31.20 (Thomas 2026-11-21 15:41): a selected dog owns the whole area - the other dogs go, the dog is drawn
       large where the fill setting puts it (left / middle / right, nearest the TV), with its three frames under it.
       Backspace or a click on it gives the row back. */
    show = [ml];
  }
  const cal = mine != null;
  { const bx = $('lkDw'), hd = $('lkCompHead'); if (bx) bx.classList.toggle('cal', cal); if (hd) { hd.classList.toggle('cal', cal); const tx = cal ? `Calibrate your dog · ${codeTxt(dwAdjKeys()[0])} ${codeTxt(dwAdjKeys()[1])} = one frame · Shift = 10 · Backspace = the other dogs` : 'Competing lines'; if (hd.textContent !== tx) hd.textContent = tx; } }
  /* v31.5: the row always stays the dog lines; the carousel is a column of three (a frame earlier / the tuned one /
     a frame later) that drops out of the bottom of the tuned dog's card, wherever the fill setting puts that card */
  /* v30.16: where the most likely dog sits - left (the others to its right), right (the others to its left), or the
     middle (2nd right of it, 3rd left, 4th right ...) */
  if (L.dwFill === 'rtl') show = show.slice().reverse();
  else if (L.dwFill === 'mid') { const m = []; show.forEach((x, i) => (i === 0 ? m.push(x) : i % 2 ? m.push(x) : m.unshift(x))); show = m; }
  $('lkCompCards').className = 'cards n' + (cal ? 3 : nShow) + (cal ? ' cal' : '') + (L.dwFill === 'mid' ? ' mid' : L.dwFill === 'rtl' ? ' rtl' : '');
  const name = x => (x.li >= 0 ? 'L' + (x.li + 1) : 'no table') + (x.fam ? ` <b style="color:#7fd6ff" title="One dog path: ${x.fam.n} lines that have become the same dog, a few frames apart (${x.fam.sis.slice(0, 6).map(q => (q.li >= 0 ? 'L' + (q.li + 1) : 'line') + ' ' + (q.df >= 0 ? '+' : '−') + Math.abs(q.df) + ' frames ' + Math.round(100 * q.p) + '%').join(', ')}). Use the frame keys to find its timing; Shift = 10 frames.">+${x.fam.n - 1}</b>` : '');
  const nameT = x => (x.li >= 0 ? 'L' + (x.li + 1) : 'no table') + (x.fam ? ` +${x.fam.n - 1}` : '');   // v31.28: plain text for textContent (the HTML badge showed as markup in the summary)
  const key = show.map(x => x.dwi + ':' + Math.round(100 * x.p) + (x.fam ? 'f' + x.fam.n : '')).join(',') + '|' + (w.pick ? w.pick.dwi : '') + '|' + nShow + L.dwFill + '|' + (w.out || []).length + (c.lines.length > 1) + '|' + (w.exact == null ? '' : w.exact) + '|' + (car ? 'car' + car.dwi + car.post : '');
  { const ub = $('lkDwOutUndo'), n = (w.out || []).length; if (ub) { ub.disabled = !n; ub.textContent = n ? `Undo × (${n} removed)` : 'Undo ×'; } }
  if (key !== dwCardKey) {
    dwCardKey = key;
    $('lkCompCards').innerHTML = show.map(x => `<div class="card lkdog${w.pick && w.pick.dwi === x.dwi ? ' sel' : ''}${w.exact === x.dwi ? ' exact' : ''}${x === c.lines[0] ? ' top' : ''}${car && car.dwi === x.dwi ? ' tune' : ''}" data-dwi="${x.dwi}" title="Click (or Enter for the top card): this is my dog — three frames of it drop out below the card, to tune with [ ] and confirm with Enter.">` + (c.lines.length > 1 ? `<span class="lkx" data-dwx="${x.dwi}" title="Not my dog: take this line out of the pool for this attempt (Backspace or Undo × puts it back; Del removes the top card)">×</span>` : '') +
      `<div class="row between"><span class="share">${Math.round(100 * x.p)}%</span><span class="small mut">${name(x)}${(h => (h && h.x >= 1.5 ? ` <b style="color:#5fd38d" title="You are on this line more often than most: ${h.visits.toFixed(1)} of your attempts">×${h.x.toFixed(1)}</b>` : h && h.x <= 0.67 && lineHabitCached().n >= 5 ? ` <span style="color:#ef6f6f" title="You are rarely on this line">×${h.x.toFixed(1)}</span>` : ''))(habitOfLine(x.li))}</span></div>` +
      `<img class="big" alt=""><div class="small mono cardtxt"></div><div class="bar"><i style="width:${(100 * x.p).toFixed(1)}%"></i></div><div class="small mut nx"></div></div>`).join('');
    for (const el of $('lkCompCards').querySelectorAll('.lkdog')) el.onclick = () => dwPick(+el.dataset.dwi);
    for (const el of $('lkCompCards').querySelectorAll('.lkx')) { el.onmousedown = e => e.preventDefault(); el.onclick = e => { e.stopPropagation(); dwRemove(+el.dataset.dwx); }; }
  }
  const els = $('lkCompCards').querySelectorAll('.lkdog');
  const dcOn = dcHas(R); let anyLit = false;                     // v31.2: the cards play on after the cast
  show.forEach((x, i) => {
    const el = els[i]; if (!el) return;
    const off = 0, lit = dcOn && t >= dwT(), a = (w.pick && w.pick.dwi === x.dwi ? w.pick.a0 : x.a) + w.adj, df = 0;
    const shc = lit ? dcShow(R, x.dwi, t, a, df) : null, sh = lit ? (shc || null) : dwShow(R, x.dwi, Math.round(t + a)), img = el.querySelector('img'), src = sh ? D.sprites[sh.base + '_' + sh.dir] || '' : '';
    el.classList.toggle('gone', lit && shc === undefined);
    if (lit && shc) anyLit = true;
    if (img.dataset.src !== src) { img.dataset.src = src; if (src) img.src = src; else img.removeAttribute('src'); }
    const txt = sh ? `${dwName(sh.base)} ${DWC.ARROW[sh.dir]} ${DWC.FACING[sh.dir]}` : lit ? 'no data after this cast' : t + a < 0 ? 'before READY' : 'past the trace';
    const ct = el.querySelector('.cardtxt'); if (ct.textContent !== txt) ct.textContent = txt;
    const bq = lit && shc ? dcBites(R, x.dwi, a, df) : null;
    const nx = lit ? (shc ? (bq && bq.nut ? `this frame: NUT on bite ${bq.nut.n}, ${fmtS1(bq.nut.t)} s` : bq && bq.bites.length ? `this frame: no Nut (${bq.bites.length} bite${bq.bites.length > 1 ? 's' : ''})` : 'this frame: no bite in the data') : '') : sh && sh.next ? `next ${((sh.next.k - (t + a)) * viMs() / 1000).toFixed(1)} s: ${sh.next.dir !== sh.dir ? DWC.ARROW[sh.next.dir] + ' ' : ''}${sh.next.base !== sh.base ? dwName(sh.next.base) : ''}` : '';
    const ne = el.querySelector('.nx'); if (ne.textContent !== nx) ne.textContent = nx;
  });
  dwCarCol(t, car, show, R, c);
  dwPeek(t, show, R, w);
  const top = c.lines[0], ti = run.tapInfo;
  /* v30.17: once the line is in the water the real dog leaves every track shown here: fishing draws a random number on
     every frame from the same generator the dog uses, and the lab traces were recorded with no cast. The cards say so. */
  const cast = t >= dwT();                                       // v30.18: dimmed from the cast cue on; v31.2: only when there is no after-cast data
  $('lkCompCards').classList.toggle('stale', cast && !dcOn);
  let state, cls = '';
  if (w.pick) { state = `YOUR PICK: ${nameT({ li: R.dw.lines[w.pick.dwi].li })}`; cls = 'ok'; }
  else if (top.p >= DW_LOCK) { state = `LOCKED: ${nameT(top)} ${Math.round(100 * top.p)}%`; cls = 'ok';
    if (w.locked !== top.dwi) { w.locked = top.dwi; if (t < dwT()) cueFlash(`DOG LINE LOCKED · ${nameT(top)}`, 'go', 900); } }
  else { state = top.p >= 0.6 ? `leaning: ${nameT(top)} ${Math.round(100 * top.p)}%` : `${c.left} lines competing`; w.locked = null; }
  const se = $('lkCompState'); if (se.textContent !== state) { se.textContent = state; se.style.color = cls ? 'var(--ok)' : ''; }
  let txt = !w.pick && w.dropped ? `Your pick (${nameT({ li: R.dw.lines[w.dropped.dwi].li })}) was dropped: your arrows do not fit that dog. The app's own weighing is back — ` +
      c.lines.slice(0, 3).map(x => `${nameT(x)} ${Math.round(100 * x.p)}%`).join(' · ') + '.'
    : w.pick ? (w.pickNote || `Reading ${nameT({ li: R.dw.lines[w.pick.dwi].li })} at the timing you lined up (±${Math.round(DW_EYE * viMs())} ms by eye): best cast still ahead${w.p != null ? ` → Nut ${pct(w.p)} on any bite` : ''}` +
      `${w.pickLate ? ` (this line's best moment, ${fmtS(w.pickLate.t)} at ${pct(w.pickLate.p)}, has passed)` : ''}. Click the card again to go back to the app's own weighing.`)
    : top.p >= DW_LOCK ? `The app is sure of the dog line${w.p != null ? `: Nut ${pct(w.p)} for this cast` : ''}. Timing on that line ±${Math.round(Math.max(top.sd, 1) * viMs())} ms.`
    : `Not sure yet: ${c.lines.slice(0, 3).map(x => `${nameT(x)} ${Math.round(100 * x.p)}%`).join(' · ')}${c.left > 3 ? ` · ${c.left - 3} more ≥ 1%` : ''}. ${w.logs.length ? '' : 'From the route taps only so far. '}Arrows narrow it; or click your dog.`;
  if (ti && ti.fit && ti.sc && ti.sc.length) {                    // after the cast: what the bite taps say
    const m = new Map(); let Z = 0; for (const e of ti.sc) { m.set(e.path, (m.get(e.path) || 0) + e.w); Z += e.w; }
    const [bs, bp] = [...m.entries()].sort((x, y) => y[1] - x[1])[0], bl = R.sidxs.indexOf(bs);
    txt += ` After the bite tap${ti.taus && ti.taus.length > 1 ? 's' : ''}: L${bl + 1} ${Math.round(100 * bp / Z)}%.`;
  }
  if (car) txt = car.post ? `TUNING ${nameT({ li: R.dw.lines[car.dwi].li })}: three frames of the same dog under its card, one cast frame (33 ms) apart, the tuned frame in the middle (cast frame ${(w.cadj || 0) >= 0 ? '+' : '−'}${Math.abs(w.cadj || 0)} from the ${run.tapInfo && run.tapInfo.fit ? 'bite tap' : run.castTap != null ? 'cast tap' : 'aim'}). They look alike for 1–3 s after the cast, then part. ${codeTxt(dwAdjKeys()[0])} ${codeTxt(dwAdjKeys()[1])} scroll; click the upper or lower one to bring it to the middle; Enter (or the middle one) when the middle one stays with your dog — the lamp then calls the bites.` +
      (() => { const x = dcExact(t); if (!x) return ''; if (!x.B) return ' FRAME SET: no data for this frame.'; return ' FRAME SET: ' + (x.B.bites.map(b => `bite ${b.n} at ${fmtS1(b.t)} s = ${DC_FISH[b.o] || b.o}`).join(', ') || 'no bite in the data') + '. Enter again clears it.'; })() + ' “Clear my pick” goes back to all dogs.'
    : `TUNING ${nameT({ li: R.dw.lines[car.dwi].li })}: three frames of the same dog under its card, one game frame (33 ms) apart. ${codeTxt(dwAdjKeys()[0])} ${codeTxt(dwAdjKeys()[1])} scroll the timing (now ${w.adj >= 0 ? '+' : '−'}${Math.round(Math.abs(w.adj) * viMs())} ms); Enter (or a click on the middle one) when the middle one moves with your dog: that closes it; “Clear my pick” goes back to all dogs.` + (w.pickNote ? ' ' + w.pickNote : '');
  else if (cast && dcOn) txt = `After the cast each card plays its line's dog for ONE cast frame: the ${run.tapInfo && run.tapInfo.fit ? 'frame the bite tap points to' : run.castTap != null ? 'cast tap' : 'aimed frame'}${w.cadj ? ` ${w.cadj > 0 ? '+' : '−'}${Math.abs(w.cadj)}` : ''}. The dog depends on the exact frame your cast landed on — one frame off and the card parts from your TV 1–3 s after the cast. ${codeTxt(dwAdjKeys()[0])} ${codeTxt(dwAdjKeys()[1])} now step that frame: when a card stays with your dog, that is the frame you landed on.` +
      (dcRel() ? ` Shown as let go at bite ${dcRel()}.` : ' Shown as B held.') +
      (() => { const x = dcExact(t); if (!x) return ' Click the card that stays with your dog: the lamp then calls the bites exactly.';
        if (!x.B) return ` FRAME SET on ${x.name}: no data for this frame.`;
        let s2 = ` FRAME SET on ${x.name}: ` + (x.B.bites.map(b => `bite ${b.n} at ${fmtS1(b.t)} s = ${DC_FISH[b.o] || b.o}`).join(', ') || 'no bite in the data') + '.';
        const ti2 = run.tapInfo;
        if (ti2 && ti2.taus && ti2.taus.length && x.B.bites.length) { const off = (ti2.taus[0] - lagMu() - x.B.bites[0].t) * viMs();
          s2 += Math.abs(off) <= 250 ? ` ✓ Your bite-1 tap fits this frame (${msTxt(Math.round(off))}).` : ` ✗ Your bite-1 tap is ${(Math.abs(off) / 1000).toFixed(1)} s ${off < 0 ? 'before' : 'after'} this frame's first bite: not this frame, or not this line.`; }
        return s2 + ' Click the card again to clear.'; })() + (txt.includes('After the bite tap') ? txt.slice(txt.indexOf(' After the bite tap')) : '');
  else if (cast) txt = 'Cast: the dog cards stop here (the real dog no longer follows them once you fish). Watch the lamp and the bites.' + (txt.includes('After the bite tap') ? txt.slice(txt.indexOf(' After the bite tap')) : '');
  else if (!w.pick && top.p < DW_LOCK) txt += ` A card's timing is the app's best guess (±${Math.round(2 * Math.hypot(Math.max(top.sd, 1), clockSd() / viMs()) * viMs() / 10) * 10} ms): it can run a little ahead of or behind your TV until you line it up with ${codeTxt(dwAdjKeys()[0])} ${codeTxt(dwAdjKeys()[1])}.`;
  const te = $('lkCompTxt'); if (te.textContent !== txt) te.textContent = txt;
  const aj = cast && dcOn ? `cast frame ${(w.cadj || 0) >= 0 ? '+' : '−'}${Math.abs(w.cadj || 0)}` : `${w.adj >= 0 ? '+' : '−'}${(Math.abs(w.adj) * viMs() / 1000).toFixed(2)} s`; if ($('lkDwAdj').textContent !== aj) $('lkDwAdj').textContent = aj;
}
let dwLast = '';
function dwRender(t) {
  const w = run.dw, R = dwRoute();
  if (!R) return;
  const keysTxt = `${L.dwKeys === 'wasd' ? 'W A S D' : 'arrows'} = facing (first = its facing now; two keys = diagonal) · ` +
    dwGroups().map(g => `${codeTxt(g.code)} ${g.label}`).join(' · ') + ' · Enter = pick the top dog (again: its timing is set) · Backspace = undo';
  const state = !w || run.wall0 === null ? 'off' : w.frozen ? 'HANDS ON B' : w.open ? 'WATCHING' : 'waits for the dock end';
  const s = w && w.sum, n = w ? w.logs.length : 0;
  const top = s && s.top ? `top line ${R.dw.lines[s.top.dwi].li >= 0 ? 'L' + (R.dw.lines[s.top.dwi].li + 1) : '(no table)'} ${Math.round(100 * s.top.p)}% · ${s.left} line${s.left === 1 ? '' : 's'} ≥ 1%` +
    (s.uncast >= 0.05 ? ` · <span style="color:#ffd28a">${Math.round(100 * s.uncast)}% on lines without a cast table</span>` : '') : '';
  const cast = w && (w.logs.length || w.moved) ? ` · cast ${fmtS(run.T)}${w.moved ? ` (moved ${w.moved >= 0 ? '+' : '−'}${(Math.abs(w.moved) * viMs() / 1000).toFixed(2)} s)` : ''} → ${pct(w.p != null ? w.p : NaN)}` : '';
  const kc = dwCal(), wn = dwWin();
  const calTxt = wn.learned ? ` Your arrow reaction: ${(wn.lo * viMs() / 1000).toFixed(2)}–${(wn.hi * viMs() / 1000).toFixed(2)} s (learned from ${wn.learned} logs on ${kc.attempts} attempts).`
    : ` Arrow reaction: ${(wn.lo * viMs() / 1000).toFixed(2)}–${(wn.hi * viMs() / 1000).toFixed(2)} s assumed${kc.lags.length ? ` (${kc.lags.length} of 8 logs learned so far)` : ''}; it learns from attempts whose bite taps name the line.`;
  const sum = !w || run.wall0 === null ? `Ticked in Settings: from the dock-end tap to HANDS ON B (${(+L.dwLead).toFixed(1)} s before the cast), log the dog.` + calTxt
    : !n ? (w.open ? (L.dwStrict ? 'Press the arrow of the way the dog faces now; from then on EVERY facing, in order (catch up if it flips quickly); an animation key when you can read what it does.'
        : 'An arrow = the way the dog faces on your TV right now (any moment while it faces that way). A new arrow whenever it faces a new way; an animation key when you can read what it does (it counts with the facing you keyed; no hurry, skipping one costs nothing).') : '')
    : top + cast;
  const ready = run.gp && run.gp.cue && run.gp.cue.dock != null ? (run.gp.cue.dock - run.wall0) / viMs() + 1 : (w && w.openAt) || 0;
  const chips = w ? w.logs.slice(-10).map(l => `<span title="${((l.t - ready) * viMs() / 1000).toFixed(2)} s after the dock end">${l.f != null ? DWC.ARROW[l.f] + ' ' + DWC.FACING[l.f] : dwGroupTxt(l.g)} <i class="mut">${((l.t - ready) * viMs() / 1000).toFixed(1)}</i></span>`).join('') : '';
  const sb = $('lkDwStrict'), li = $('lkDwLate');
  if (sb) { sb.checked = !!L.dwStrict; $('lkDwStrictLbl').className = 'lkspar' + (L.dwStrict ? ' on' : ''); if (document.activeElement !== li) li.value = Math.round(+L.dwLateMs || 1000); li.disabled = false;
    $('lkDwStrictTxt').textContent = L.dwStrict ? `Strict: once you press the first arrow, every facing of the dog must be keyed, in order, while it shows (or within ${Math.round(dwLateVI() * viMs())} ms of the turn if it has already turned again). Lines whose facings come in another order, or that turn while you key nothing, drop out.`
      : `Off: an arrow means "the dog faces this way now" — key it at any moment while it does. A facing you never key costs a line a little, once it is over or has shown for ${Math.round(dwLateVI() * viMs())} ms.`; }
  const key = state + '|' + sum + '|' + chips;
  if (key === dwLast) return;
  dwLast = key;
  $('lkDwState').textContent = state; $('lkDwSum').innerHTML = sum; $('lkDwLogs').innerHTML = chips; $('lkDwKeys').textContent = keysTxt;
  if (!w || run.wall0 === null) $('lkDw').classList.remove('on', 'frozen');
}
function dwRecord() {                                           // stored with the attempt: logs (s after the dock end) + the top line
  const w = run.dw, R = dwRoute(), g = run.gp;
  const ready = g && g.cue && g.cue.dock != null ? (g.cue.dock - run.wall0) / viMs() + 1 : w.openAt || 0;
  return { logs: w.logs.map(l => [+((l.t - ready) * viMs() / 1000).toFixed(3), l.f != null ? 'F' + l.f : 'N' + l.g]),
           top: w.sum && w.sum.top && R ? R.dw.lines[w.sum.top.dwi].key : null, p: w.sum && w.sum.top ? +w.sum.top.p.toFixed(3) : null,
           moved: Math.round(w.moved * viMs()), keys: L.dwKeys,
           ...(w.pick && R ? { pick: R.dw.lines[w.pick.dwi].key, adj: Math.round(w.adj * viMs()) } : {}), ...(w.drops ? { drops: w.drops } : {}), ...(w.cadj ? { cadj: w.cadj } : {}), ...(w.exact != null && R ? (() => { const a = dcCardA(w.exact), B = a === null ? null : dcBites(R, w.exact, a); return { exact: { line: R.dw.lines[w.exact].key, kc: B ? B.kc : null, nut: B && B.nut ? B.nut.n : 0, bites: B ? B.bites.map(b => [+((b.t - 1) * viMs() / 1000).toFixed(2), b.o]) : [] } }; })() : {}), ...(w.out && w.out.length && R ? { out: w.out.map(d => R.dw.lines[d].key) } : {}),
           ...(w.strict ? { strict: Math.round(dwLateVI() * viMs()) } : {}),
           ...(w.clock && w.clock.n ? { clk: [Math.round(w.clock.d * viMs()), Math.round(w.clock.sd * viMs())] } : {}),
           ...(w.cal ? { cal: { lags: w.cal.lagF.concat(w.cal.lagG).map(v => Math.round(v * viMs())), turns: w.cal.turns, missed: w.cal.missed, stray: w.cal.stray } } : {}) };
}
function dwDiag(ti) {                                           // dog-watch vs what the bite taps say (the lab check of the logs)
  const w = run.dw, R = dwRoute();
  if (!w || !R || !w.sum || !w.sum.top) return `dog-watch: ${w.logs.length} logs`;
  const top = R.dw.lines[w.sum.top.dwi];
  let s = `dog-watch: ${w.logs.length} logs → line ${top.li >= 0 ? 'L' + (top.li + 1) : '(no table)'} ${pct(w.sum.top.p)}`;
  if (ti && ti.sum && ti.sum.pathShare >= 0.3) {
    const li = R.sidxs.indexOf(ti.sum.path);
    s += li === top.li ? ' = the line the bite points to ✓' : ` (the bite points to L${li + 1}, ${pct(ti.sum.pathShare)})`;
  }
  return s;
}
function dwSettings() {
  if (!$('lkDwOn')) return;
  $('lkDwOn').checked = !!L.dwOn; $('lkDwKeys2').value = L.dwKeys === 'wasd' ? 'wasd' : 'arrows'; $('lkDwLead').value = L.dwLead;
  $('lkDwPad').textContent = routeDef().dw ? '' : 'This route has no dog traces: the watch stays off here.';
  dwKeyTable();
}
if ($('lkDwOn')) {
  $('lkDwOn').onchange = e => { L.dwOn = e.target.checked; save(); dwSettings(); };
  $('lkDwKeys2').onchange = e => { L.dwKeys = e.target.value; save(); };
  if ($('lkRelLine')) { $('lkRelLine').checked = L.relLine !== false; $('lkRelLine').onchange = e => { L.relLine = e.target.checked; save(); }; }
  /* v32.6 (Thomas 2026-11-24: "a checkbox in the histogram settings to "show release window" and that either enables or
     disables the bottom histogram bar representing the release windows so it looks like what it did before we added
     it"): off = no release lane under the histogram - in Freestyle the "let go here" lane and its threads (v31.18), in
     the app's own odds the lane of bites after the cast with its release band; the cast bars take the whole height. The
     lamp and the countdowns keep working from the same data (the lane is still worked out, only not drawn). */
  if ($('lkRelWin')) { $('lkRelWin').checked = L.relWin !== false; $('lkRelWin').onchange = e => { L.relWin = e.target.checked; save(); }; }
  if ($('lkDwKeyReset')) $('lkDwKeyReset').onclick = () => { if (confirm('Put the animation keys back to the defaults (numpad, rollover R, flapper F, good-boy G, mess O, wiggle-bum B) and the card-timing keys on [ and ]?')) { delete L.dwAnimKeys; delete L.dwAdjKeys; dwCap = null; save(); dwApplyGroups(); dwKeyTable(); } };
  $('lkDwLead').onchange = e => { L.dwLead = Math.max(1, Math.min(6, +e.target.value || 2)); save(); dwSettings(); };
}

/* ---------------------------------------------------------------- keyboard (only while this arena is shown) */
const SCROLL_KEYS = ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'PageUp', 'PageDown', 'Home', 'End'];
const engaged = () => run.wall0 !== null || !!run.practice || !!run.bite || !!pierOnly;
/* an attempt or a drill begins: nothing keeps the keyboard focus, and the histogram / lamp / Jack are on screen */
function engage() {
  const a = document.activeElement;
  if (a && a !== document.body && a.blur && !(a.tagName === 'INPUT' && !['range', 'checkbox', 'radio', 'button'].includes(a.type)) && a.tagName !== 'TEXTAREA') a.blur();
  const d = $('lkDeck');
  if (d && d.getBoundingClientRect) { const r = d.getBoundingClientRect(); if (r.top < -4 || r.top > (window.innerHeight || 800) * 0.4) { try { window.scrollTo({ top: Math.max(0, (window.scrollY || 0) + r.top - 8), behavior: 'auto' }); } catch (err) { window.scrollTo(0, 0); } } }
}
/* v31.14 the freestyle key. Default Ctrl (either side): the press itself is the moment. Ctrl is also the modifier of
   browser shortcuts, so if another key goes down while Ctrl is still held (Ctrl+R, Ctrl+C ...) the toggle is undone. */
let fsCap = false, fsHeld = null;
function fsKeyDown(e) {
  if (e.key === 'Backspace' && fsOn() && run.fs.cast != null && !run.tapInfo && run.wall0 !== null) { fsUnmark(); e.preventDefault(); return true; }
  if (fsHeld && e.key !== 'Control' && e.ctrlKey) {                // a shortcut (Ctrl+C ...): a letter straight after Ctrl - the toggle is taken back
    const h = fsHeld; fsHeld = null;
    if (h.ok && /^[a-z]$/i.test(e.key) && evTime(e) - h.at < 600) { fsUndo(h); return true; }
    return false;
  }
  if (!isFsKey(e) || e.repeat) return false;
  if (e.key === 'Control' && (e.altKey || e.metaKey || e.shiftKey)) return false;
  const snap = fsSnap(), ok = fsToggle();
  if (e.key === 'Control') fsHeld = { ok, snap, at: evTime(e) }; else e.preventDefault();
  return true;
}
function fsSnap() { return { free: !!L.free, fs: run.fs ? Object.assign({}, run.fs) : null, castTap: run.castTap, T: run.T }; }
function fsUndo(h) { L.free = h.snap.free; save(); if (h.snap.fs && run.fs) { Object.assign(run.fs, h.snap.fs); run.castTap = h.snap.castTap; if (run.wall0 !== null && h.snap.T != null) run.T = h.snap.T; } dwCardKey = ''; fsSync(); }
function fsCapture(e) {
  e.preventDefault(); e.stopPropagation();
  if (e.key === 'Escape') { fsCap = false; fsSync(); fsCapTxt(''); return; }
  if (e.key === 'Control') { L.fsKey = 'Control'; fsCap = false; save(); fsSync(); fsCapTxt('Freestyle key: Ctrl'); return; }
  const bad = e.key === ' ' || e.code === 'Space' ? 'Space cannot be the freestyle key' : dwKeyRefused(e, 'fs');
  if (bad) { fsCapTxt(bad + ' — press another key (Esc = keep ' + fsKeyName() + ')'); return; }
  L.fsKey = e.code; fsCap = false; save(); fsSync(); fsCapTxt('Freestyle key: ' + fsKeyName());
}
function fsCapTxt(x) { const b = $('lkFreeKey'); if (b) { b.textContent = fsCap ? 'press a key…' : 'key'; b.classList.toggle('on', fsCap); } const n = $('lkFreeNote'); if (n) n.textContent = x || ''; }
document.addEventListener('keyup', e => { if (e.key === 'Control') fsHeld = null; });
window.addEventListener('blur', () => { fsHeld = null; });
document.addEventListener('keydown', e => {
  if (root.HM64Arena !== 'lucky') return;
  if (fsCap) { fsCapture(e); return; }
  if (dwCap) { dwCapture(e); return; }
  if (capturing) { e.preventDefault(); L.startKey = e.key; capturing = false; save(); fillLSettings(); refresh(); return; }
  /* v30.29 BUG FIX (Thomas, 2026-11-20: "I hit Space to start, then an arrow key, and the page shot down to the
     bottom"). The tool's keys must never scroll the page. Two holes: (1) a key's auto-repeat left this handler before
     anything cancelled it - a HELD Space (the hold-and-let-go drills since v30.26) or a held arrow scrolled the page on
     every repeat; (2) an arrow pressed during an attempt while the dog-watch was not open was not cancelled at all.
     Now: the start key / Space never scrolls; while the tool is engaged (attempt, practice, pier-only armed) the
     arrows, Page Up / Down, Home and End do not scroll either, and a focused drop-down or slider does not take them. */
  const tg = e.target, typing = tg && ((tg.tagName === 'INPUT' && !['range', 'checkbox', 'radio', 'button'].includes(tg.type)) || tg.tagName === 'TEXTAREA' || tg.isContentEditable);
  const dlg = !!document.querySelector('dialog[open]');
  if (!typing && !dlg) {
    const eng = engaged();
    if (e.key === L.startKey || e.key === ' ' || (eng && SCROLL_KEYS.includes(e.key))) e.preventDefault();
    if (eng && tg && (tg.tagName === 'SELECT' || (tg.tagName === 'INPUT' && tg.type === 'range')) && tg.blur) tg.blur();
  }
  if (typing || dlg || e.repeat) return;
  const k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
  if (run.bite) {                                               // v30.19 bite practice owns the keys the same way
    if (e.key === L.startKey) { if (!e.repeat) biteInput(evTime(e), keyName()); e.preventDefault(); return; }   // release mode: the press is the hold, the keyup below is the answer
    if (e.key === 'Escape') { biteStop(); e.preventDefault(); return; }
    if (['h', 'm', 'e', 'p', '[', ']'].includes(k)) e.preventDefault();
    return;
  }
  if (run.practice) {                                           // practice owns the keys: start key = press, Esc = stop
    if (e.key === L.startKey) { if (!e.repeat) practiceInput(evTime(e), keyName()); e.preventDefault(); return; }   // v30.27: a held key repeats
    if (e.key === 'Escape') { practiceStop(); e.preventDefault(); return; }
    if (['h', 'm', 'e', 'p', '[', ']'].includes(k)) e.preventDefault();
    return;
  }
  if (fsKeyDown(e)) return;                                     // v31.14 freestyle
  if (dwKey(e)) { e.preventDefault(); return; }                 // v30 dog-watch: facing gear + numpad while it is open
  if (e.key === L.startKey) {
    if (run.wall0 !== null && !run.preview && fsWait() && run.gp && run.gp.cue && run.gp.cue.dock && run.castTap === null) {   // v31.29 freestyle: after the dock-end tap Space is the cast, never another sequence tap
      if (evTime(e) - run.gp.last < 300) { e.preventDefault(); return; }   // key bounce of the dock-end tap
    } else if (run.wall0 !== null && !run.preview && seqOpen((now() - run.wall0) / viMs() + 1)) {   // tap sequence (fade-in start)
      seqPress(evTime(e)); e.preventDefault(); return;
    }
    if (pierRetap(evTime(e))) { e.preventDefault(); return; }       // v30.24: pier only, before the cast: the dock-end tap again
    if (run.wall0 !== null && !run.preview) {
      const t = (now() - run.wall0) / viMs() + 1;
      if (fsWait()) { if (run.dw && (run.dw.open || run.dw.frozen)) fsMark((evTime(e) - run.wall0) / viMs() + 1); e.preventDefault(); return; }   // v31.14 freestyle: Space = I am casting
      if (holdRe(t)) { e.preventDefault(); return; }             // v31.7: hold mode, Space down again = still holding B
      const hd = holdDown(t);                                     // v31.6: watched around the cast - held = hold mode
      if (isCastTap(t)) registerCast(t); else if (hd || (run.hold && run.hold.up === null)) { /* decided by holdTick / holdUp */ } else if (run.tapInfo) registerTap2(t); else registerTap(t);
      e.preventDefault(); return;
    }
    start(evTime(e)); e.preventDefault(); return;
  }
  if (e.key === 'Backspace' && run.tapInfo && run.tapInfo.taus && run.tapInfo.taus.length > 1 && !run.tapInfo.saved) {
    const ti = run.tapInfo, taus = ti.taus.slice(0, -1);
    if (taus.length === 1) { const t0 = taus[0]; run.tapInfo = null; registerTap(t0); } else applyTaps(ti, taus, true);
    e.preventDefault(); return;
  }
  if (e.key === 'Backspace' && run.tapInfo && !run.tapInfo.saved) { run.tapInfo = null; e.preventDefault(); return; }
  if (e.key === 'Backspace' && run.castTap !== null && !run.tapInfo) { run.castTap = null; run.castErrMs = null; e.preventDefault(); return; }
  if (e.key === 'Escape') { stop(true); e.preventDefault(); return; }
  if (k === 's' && sparrowTable()) { setSparrows(route() !== sparrowTable().id); e.preventDefault(); return; }
  if (k === 'x' && pierCan() && (anchor() !== 'pier' || pierOnly)) { setPierOnly(!pierOnly); e.preventDefault(); return; }   // v31.27: not with the one-tap dock-end start
  if (k === 'h') { record(true); e.preventDefault(); return; }
  if (k === 'm') { record(false, 'fish'); e.preventDefault(); return; }
  if (k === 'e') { record(false, 'empty'); e.preventDefault(); return; }
  if (k === 'p') { preview(); e.preventDefault(); return; }
  { const adj = dwAdjKeys(); if (e.code === adj[0] || e.code === adj[1]) { L.castT = Math.max(run.plan.firstT, Math.min(LuckyCore.TMAX, run.T + (e.code === adj[0] ? -2 : 2))); save(); refresh(); e.preventDefault(); } }
}, true);

/* status line while the tap sequence is open */
function seqMsg(t) {
  const g = run.gp;
  if (!g || !g.cue || !(t < run.T - 90) || run.castTap !== null || run.tapInfo) return null;
  const sg = v => (v >= 0 ? '+' : '') + Math.round(v), cues = tapCues();
  if (g.cue.dock) {
    if (now() - g.cue.dock > 6000) return null;
    if (!g.g3) return ['Dock end ✓ — fitting your beach timing…', 'go'];
    if (g.g3.off) return ['Dock end tap fits none of the route timings: ignored', 'hold'];
    const gu = g.g3.guess, bands = gu ? `${gu.l1} ${Math.round(100 * gu.p1)}%${gu.sure2 ? ', 2nd cut ' + gu.l2.toLowerCase() + ' ' + Math.round(100 * gu.p2) + '%' : ''}`
      : (g.g3.bands || []).filter(x => x.p >= 0.05).map(x => `${x.label} ${Math.round(100 * x.p)}%`).join(' · ');
    return [`Dock end ✓ ${bands ? '— beach timing: ' + bands : ''}${g.g3.moved ? ` · cast moved ${sg((g.g3.T - g.g3.T0) * viMs())} ms (${pct(g.g3.p)})` : ` · cast stays (${pct(g.g3.p)})`}`, 'go'];
  }
  const last = Math.max(-1, ...cues.map((c, i) => (g.cue[c.id] != null ? i : -1))), next = cues[last + 1];
  const done = cues.filter(c => g.cue[c.id] != null).map(c => c.short + ' ✓').join(' · ') || 'tap ✓';
  return [next ? `${done} — next: ${next.short}` : done, 'go'];
}
/* ---------------------------------------------------------------- frame */
function frame() {
  if (root.HM64Arena === 'lucky') {
    const t = run.wall0 === null ? 0 : (now() - run.wall0) / viMs() + 1;
    const live = run.wall0 !== null;
    $('lkClock').textContent = live ? ((t - 1) * viMs() / 1000).toFixed(2) + ' s' : '0.00 s';
    $('lkStart').textContent = run.bite ? 'Stop bite practice (Esc)' : run.practice ? 'Stop practice (Esc)' : live ? 'Stop (Esc)' : `Start when ${doubleOn() ? 'the first tap cue (' + (clockCues()[0] || CUES[1]).short + ')' : startName()} (${keyName()})`;
    biteTick(); practiceTick();
    const [pose, u, info] = run.bite ? bitePose() : poseAt(t);
    const cv = $('lkAngler'), W = cv.width = cv.clientWidth * devicePixelRatio, H = cv.height = cv.clientHeight * devicePixelRatio;
    if (JACK && L.figure !== 'stick' && !Object.keys(customSprites).length) drawJackScene(cv.getContext('2d'), W, H, run.bite ? biteJack() : (run.practice && run.practice.combo && comboJack(t)) || jackState(t), L.facing);
    else drawAngler(cv.getContext('2d'), W, H, pose, u, L.facing, info);
    const T = run.T;
    let msg = '', cls = '';
    if (!live) msg = run.result === 'nut' ? 'Power Nut! Logged.' : run.result === 'miss' ? 'Logged. Reset the console and go again.'
      : anchor() === 'dog' ? `Put the dog down: press ${keyName()} together with A.`
      : anchor() === 'fadein' ? `Tap ${keyName()} at: ${tapCues().map(c => c.short).join(', ')} (miss any one).`
      : anchor() === 'beach' ? `Press ${keyName()} when the beach appears.`
      : anchor() === 'pier' ? `Press ${keyName()} when Jack stops at the pier end.` : 'Get to READY, then press the start key.';
    else if (seqMsg(t)) { [msg, cls] = seqMsg(t); }
    else if (run.plan.k && t < run.plan.whistleEnd + 6) { msg = `Mash C-right — stop at whistle #${run.plan.k}`; cls = 'wh'; }
    else if (fsWait()) { msg = `Freestyle — cast when you like, tap ${keyName()} as you cast`; cls = ''; }
    else if (t < castCueT()) { msg = `Cast in ${((castCueT() - t) * viMs() / 1000).toFixed(1)} s`; cls = castCueT() - t < 90 ? 'go' : ''; }
    else if (t < T + G_CAST + 30) { msg = fsOn() ? 'Freestyle cast marked' : run.castTap !== null ? `Cast logged ${run.castErrMs >= 0 ? '+' : ''}${Math.round(run.castErrMs)} ms vs the CAST cue — listen for the plop` : `Cast! ${L.castTap ? 'Tap ' + keyName() + ' with B · ' : ''}listen for the plop (0.6 s)`; cls = 'go'; }
    else if (run.tapInfo && run.tapInfo.holdish) {                 // bite 1 (and maybe more) held and tapped: the forecast for the next bite
      const ti = run.tapInfo, nb = ti.taus.length + 1, sp = spansTxt(ti.spans2), inSp = ti.spans2.some(([a, b]) => t >= a - 40 && t < b + 10);
      const hl = spansTxt(ti.holds2 || []);
      if (ti.released) { const pr = ti.pb[ti.released - 1]; msg = `Bite ${ti.released} at ${fmtS(ti.taus[ti.released - 1])} was ${verdict(pr)} — H Nut · M fish · E empty line`; cls = pr >= 0.8 ? 'go' : 'hold'; }
      else if (!ti.fit) { msg = `Bite ${nb - 1} at ${fmtS(ti.taus[nb - 2])} fits no dog line${ti.nofit && ti.nofit.k === 'none' ? ' (off the tables: no cast within ±0.75 s gives it)' : ''} — release bite ${nb} anyway`; cls = 'hold'; }
      else if (ti.dud) { msg = `DUD: ${nb > 2 ? 'no later bite' : "bite 2"} can be the Nut (${pct(ti.pAny)}) — reset now (M)`; cls = 'hold'; }
      else if (inHold(t)) { msg = `A bite now → KEEP HOLDING and tap ${keyName()}: the Nut is on a later bite`; cls = 'wh'; }
      else { msg = inSp ? `Nut-bite moment — release the instant bite ${nb} shows (Nut ${pct(ti.pNut)})`
        : `Bite ${nb} → Nut ${pct(ti.pNut)} if it bites at ${sp || '?'}${hl ? ` · a bite at ${hl}: keep holding` : ''} · tap ${keyName()} at bite ${nb}`; cls = 'go'; }
    }
    else if (run.pol === 'zone') { const zn = inZone(t); msg = run.tapInfo ? `Bite at ${fmtS(run.tapInfo.tau)} was ${verdict(run.tapInfo.p1)}` : (zn ? 'Bite now → RELEASE (tap it)' : `Bite now → HOLD and tap ${keyName()}`); cls = zn ? 'go' : 'hold'; }
    else if (run.pol === 'bite1') {
      const nb = nutBites().find(([a, b]) => t >= a - 40 && t < b + 10);
      msg = run.tapInfo ? `Bite at ${fmtS(run.tapInfo.tau)} was ${verdict(run.tapInfo.p1)} — H Nut · M fish · E empty line`
        : nb ? 'Nut-bite moment — release the instant it bites' : 'Release at the bite';
      cls = 'go';
    }
    else if (run.pol === 'tap' || run.pol === 'hold') {
      const ti = run.tapInfo;
      if (!ti) { msg = `Keep holding B · tap ${keyName()} when bite 1 shows · let go of B at bite 2`; cls = 'hold'; }
      else if (!ti.fit) { msg = `Bite at ${fmtS(ti.tau)} fits no dog line${ti.nofit && ti.nofit.k === 'none' ? ' (off the tables: no cast within ±0.75 s gives it)' : ''} — release bite 2 anyway`; cls = 'hold'; }
      else if (ti.dud) { msg = `DUD (${pct(ti.pNut)}) — reset now (M)`; cls = 'hold'; }
      else { msg = `Bite 2 → Nut ${pct(ti.pNut)} · release at bite 2${ti.nutT2 ? ' (~' + fmtS(ti.nutT2) + ')' : ''}`; cls = 'go'; }
    }
    else { msg = 'Hold bite 1 · release bite 2'; cls = 'hold'; }   // (no policy left here)
    const tr = t - R0();
    if (live && wakeNow(t)) { msg = 'Wake Jack: push the stick DOWN-RIGHT now'; cls = 'wh'; }
    if (run.preview && live) {
      const pv = run.preview;
      msg = `Preview: ${info}`;
      cls = pose === 'catch' ? 'go' : pose === 'bite' ? (info.includes('HOLD') ? 'hold' : 'go') : '';
      if (pose === 'wait' || pose === 'zone') msg = `Preview: bite 1 at ${fmtS(pv.bite1)} → ${pv.release1 ? 'release' : 'hold, release bite 2 at ' + fmtS(pv.bite2)}`;
    }
    dwTick(t);
    if (live) holdTick(t);
    if (live) relTick(t);
    renderCue(t, msg);
    if (run.bite) [msg, cls] = biteMsg();
    if (run.practice) {
      [msg, cls] = practiceMsg(t);
      if (!L.pracLine && run.practice.state === 'armed') $('lkClock').textContent = '·';
      if (navigator.getGamepads) for (const gp of navigator.getGamepads()) {   // any controller button = a press
        if (!gp) continue;
        const prev = run.practice.pads[gp.index] || [];
        gp.buttons.forEach((b, i) => { if (b.pressed && !prev[i]) practiceInput(gp.timestamp > 0 && gp.timestamp < 1e11 ? gp.timestamp : now(), 'controller'); });
        if (run.practice && prev.some(Boolean) && !gp.buttons.some(b => b.pressed)) practiceRelease(gp.timestamp > 0 && gp.timestamp < 1e11 ? gp.timestamp : now(), 'controller release');
        if (run.practice) run.practice.pads[gp.index] = gp.buttons.map(b => b.pressed);
      }
    }
    const el = $('lkStatus'); el.textContent = msg; el.className = 'lkstatus ' + cls;
    if (live && !run.preview && !run.practice) {
      if (t > runEnd()) { stop(true); cueFlash('END · attempt stopped, not logged', 'info', 1500); }
      else if (fsWait() && t > wakeEnd() + 90) { stop(true); cueFlash('END OF THE CAST DATA · attempt stopped, not logged', 'info', 1800); }   // v31.21: freestyle with no cast made - nothing left to cast on
    }
    drawTimeline(t);
  } else glowSet(0);
  requestAnimationFrame(frame);
}
/* ---------------------------------------------------------------- arena switch (footer) */
function setArena(a) {
  if (a !== 'lucky') a = 'ref';                                  // v31.0: the Dog Oracle page is gone; its tab is the Dog reference
  if (!$('refArena')) a = 'lucky';                               // v32.0: the hub's Lucky Timer page has no other arena
  root.HM64Arena = a; store.set('hm64v29_arena', a);
  $('oracleArena').hidden = true; if ($('refArena')) $('refArena').hidden = a === 'lucky'; $('luckyArena').hidden = a !== 'lucky';
  if (a !== 'lucky' && root.HM64DogRef) root.HM64DogRef.show();
  if (a === 'lucky' && root.HM64DogRef && root.HM64DogRef.hide) root.HM64DogRef.hide();   // v31.7: its tables and timers go while it is not selected
  if (a === 'lucky') { const hp = $('histPop'); if (hp) hp.hidden = true; refresh(); } else { stop(true); glowSet(0); }
  if ($('arOracle')) $('arOracle').classList.toggle('on', a !== 'lucky'); if ($('arLucky')) $('arLucky').classList.toggle('on', a === 'lucky');
}
if ($('arOracle')) $('arOracle').onclick = () => setArena('ref'); if ($('arLucky')) $('arLucky').onclick = () => setArena('lucky');   // v32.0: no arena buttons on the hub's pages
/* v32.16 (Thomas 2026-11-24 16:45): timing, keys and practice are set on the Settings page, which shares this page's
   storage on the website. Another tab (Settings, Dog practice, another Lucky Timer) that changes them fires 'storage'
   here: take the new values in, so this page neither works with old ones nor writes old ones back over them. */
if (root.HM64Timing) root.HM64Timing.onChange(key => {
  const T = root.HM64Timing;
  if (key == null || key === T.KEY.lucky) {
    const sv = store.get('hm64v29_lucky', {}) || {};
    for (const k of T.SHARED) if (k in sv) L[k] = sv[k];
    if ('cueV' in sv) L.cueV = sv.cueV; if ('castTapV' in sv) L.castTapV = sv.castTapV;
    dwApplyGroups(); if ($('lkDwKeyTbl')) dwKeyTable(); dwKeyChips();
  }
  if (key == null || key === T.KEY.cast) { const a = store.get('hm64v29_lucky_castprac', null); if (Array.isArray(a)) pracLog = a; }
  if (key == null || key === T.KEY.bite) { const a = store.get('hm64v30_lucky_biteprac', []); biteLog = Array.isArray(a) ? a : []; bpCache = null; }
  if (key == null || key === T.KEY.settings) {
    const sv = store.get('hm64v28_settings', {}) || {}, was = Core.settings.updateMs;
    Object.assign(OS, sv);
    if ('tapMuVI' in sv) Core.settings.tapMuVI = sv.tapMuVI;
    if (+sv.updateMs && +sv.updateMs !== +was) {                // a new frame period: every table here is in VIs of the old one
      if (run.wall0 === null && !run.practice && !run.bite) location.reload();
      else cueFlash('the frame period was changed in Settings: reload this page after the attempt', 'warn', 4000);
    }
  }
  pressCache = { key: null, v: null }; bestCache = null; ccache.clear(); persCache.clear();
  updateProfile(); fillLSettings(); refresh();
});
fillLSettings();
updateProfile();
setArena(store.get('hm64v29_arena', 'lucky'));                 // v31.27: a fresh browser opens on the Lucky Timer
refresh();
requestAnimationFrame(frame);
root.HM64LuckyApp = { timingFit, timingRows, dwRoute, fsRel: () => run.fsRel, fsTargetAt, fsRepBuild, frameOnce: frame, wakeList, wakeNow, wakeEnd, wakeReady, fsTarget, dwFold, dwOutHas, fsDoubles, fsNextDouble, fsMark, fsUnmark, fsClusters, fsToggle, fsOn, fsWait, fsComb, fsCue, fsSync, dwT, fsKeyDown, fsState: () => run.fs, dcFrame, dcLabel, dwLock, castRepBuild, castRepRead, castRepPlain, drawCastRep, knownView, dcNutAt, attOpenSet: v => { attOpen = v; renderAttempts(); }, dwPeekSet: d => { dwPeekDwi = d; }, holdDown, holdTick, holdUp, holdRe, dcBites, dcExact, exactCue, dcCardA, dcLabel, dcShow, dcFrame, dcHas, dcRel, dwRemove, dwRestore, dwRecord, whyNoFit, nofitTxt, siblingTables, run, refresh, start, stop, record, preview, registerTap, registerCast, registerTap2, nutBites, L, dwUpdate, dwKey, dwOpen, dwTick, get plans() { return plans; }, setSelection, paceRows,
                      seqPress, goal3, fadeStats, gapMs, applyGoal, attemptList, removeAttempt, restoreAttempt, landing, landStreak, timingDots, renderCompass, castAim, tbLine, frontOrder, frontDragTo, dwPick, dwNudge, dwComp, cueCorr, inZone, inHold, inRelease, held, viMs, sigVI,
  planP: () => P(run.plan),                                    // test hook: the plan with the personal profile weights
  /* test hook (UI lab, learning test): what the app has learned so far, read-only */
  learned: () => { const ps = pressReady(), pf = prof_(); let fs = null; try { fs = fadeStats(); } catch (e) { fs = null; }
    return { corr: cueCorr(), sigma: sigmaMs(), sigEff: sigEffMs(), autoB: autoB(), startDelay: startDelay(), clockSd: clockSd(), lagMu: lagMu(), lagSd: lagSd(),
             press: ps ? { n: ps.n, med: ps.med, sd: ps.sd } : null,
             prof: pf ? { n: pf.n, nCast: pf.nCast || 0, nNoCast: pf.nNoCast || 0, bias: pf.bias, kTied: pf.kTied != null ? pf.kTied : null, tieFree: !!pf.tieFree, lag: !!pf.lag } : null,
             fade: fs, taps: taps.length, dw: dwWin() }; }, biteSplit2: () => biteSplit(), dwRoute, setPierOnly, pierRetap, setSparrows, biteSplit, runEnd, get pierOnly() { return pierOnly; }, dockStat, autoB, TEST, tapStats, clockSd, sigEffMs, setStrategy, setBeachCue, CUES, STRATS, tapCues, get fade2() { return fade2; }, get dock() { return dock; }, get taprec() { return tsGet(curTs()); }, precision, curTs, tsKeys, cullRec, clearSet, migrateTapRec, tsGet, setSparrows, baseOf, variantOf, cueAt, cueFlash, personalKernel, pkParts, personalTxt, sigStd, renderCue, cueCorr, sigmaMs, pressData, startDelay, get cueNow() { return run.cueNow; },
  trustData, renderTrust, guardRows, renderGuard, clearStats, renderData, DATA_SETS,
  releaseLine, relCurve, relTick, offData, renderOff, lineHabit, renderHabit, saveDogLine, get dogLines() { return dogLines; }, get prof() { return prof; }, updateProfile,
  castCueT, curveC, drawTimeline, aimCheck, engaged, engage,
  practiceRelease, practiceTick, comboJack, comboTxt,
  biteHold, biteRelease, biteAnswer, bpMode, bpReactKind,
  biteStart, biteStop, biteInput, biteTick, bpStats, biteForget, renderBite, biteJack, get biteLog() { return biteLog; }, BP, tapMu, tapSd,
  dwGroups, dwApplyGroups, dwKeyRefused, dwKeyTable, dwAnimKeys, dwAdjKeys, DW_RESERVED, codeTxt,
  practiceStart, practiceStop, practiceInput, practicePress, applyCastProfile, castStats, practiceMsg, get pracLog() { return pracLog; },
                      get tally() { return tally; }, routeDef,
                      drawAngler, drawJackScene, jackState,
                      get JACK() { return JACK; }, get prof() { return prof; }, get taps() { return taps; } };
})(typeof window !== 'undefined' ? window : globalThis);
