/* HM64 Settings page (settings.html, v32.16). Thomas 2026-11-24 16:45: "take the tap and timing part of the application
   and move it to a harmonized "settings" option on the hub ... the seperate sections can all collect and use data from
   each other if they use the same format ... they can all add to the same integer in your local storage to keep track of
   number of attempts consistently. theres no need to have that part on every single page table individually, so bring
   it all under one section under the settings." His picks: its own page; timing, keys and practice move here (the attempt
   log and its learning stay on each tool page, which feeds this page what it learns); one attempt count for Lucky Timer
   attempts and Dog practice whole attempts; export / import for files opened from a folder.

   Everything here reads and writes the stores the Lucky Timer has always used (hm64_timing_v32.js), so the Lucky Timer,
   the Casting tables and Dog practice use what is set here and add to it. What only a page with dog tables can work out
   (the clock shift from bite taps, how well the console offset is known, where casts landed) comes from the record the
   Lucky Timer keeps (hm64v32_timing_fit). The drills are the Lucky Timer's cast practice (quick mode: the cue 4 s after
   each start, pulses at -1.5 / -1 / -0.5 s, the press window +-0.6 s; the hold-to-the-bite combo) and bite practice
   (hold and let go, or tap), with the same timings and the same records. */
(function (root) {
  'use strict';
  const T = root.HM64Timing, X = root.HM64_SET || {}, DWC = root.HM64DogWatch || null;
  const $ = id => document.getElementById(id);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const now = () => performance.now();
  const evTime = e => (e && e.timeStamp > 0 && e.timeStamp < 1e11 ? e.timeStamp : now());
  const msTxt = x => `${x >= 0 ? '+' : ''}${Math.round(x)} ms`;
  const sg = v => (v >= 0 ? '+' : '−') + Math.abs(Math.round(v));
  const med = a => { const v = a.slice().sort((x, y) => x - y); return v.length ? v[Math.floor((v.length - 1) / 2)] : NaN; };
  const vi = () => T.viMs();
  const G_CAST = 36, G_PULL = 20, G_CATCH = 54, START1_MS = 60;
  const PRAC = T.PRAC, BP = T.BP;
  const keyName = () => { const k = T.lucky().startKey; return k === ' ' ? 'Space' : k; };
  const isStartKey = e => e.key === T.lucky().startKey;

  /* ================================================================ attempts */
  function renderAttempts() {
    const n = T.attempts(), by = T.attemptsBy();
    const since = by.since ? new Date(by.since).toLocaleDateString() : '';
    $('stAttN').textContent = n.toLocaleString();
    $('stAttBy').innerHTML = `Lucky Timer <b>${by.lucky}</b> · Dog practice whole attempts <b>${by.practice}</b>` +
      (by.before ? ` · <b>${by.before}</b> already on record when the count began${since ? ' (' + esc(since) + ')' : ''}: your logged Lucky Timer attempts and Dog practice whole attempts` : '') + '.';
  }

  /* ================================================================ your timing: the compass, the four rows */
  const PLACEHOLDER = [
    { id: 'dock', tri: true, label: 'dock end tap', x: null, y: null, n: 0, need: 5, what: 'vs the start-tap delay (Lucky Timer attempts)' },
    { id: 'press', label: 'B press on CAST', x: null, y: null, n: 0, need: 5, what: 'cast practice + real casts' },
    { id: 'bite', label: 'bite tap (Space)', x: null, y: null, n: 0, need: 3, what: 'your bite reaction in attempts (Lucky Timer)' },
    { id: 'bprac', label: 'bite practice', x: null, y: null, n: 0, need: BP.min, what: 'your reaction to the bite animation' },
    { id: 'clock', label: 'clock shift', x: null, y: null, n: 0, need: 8, what: 'stopwatch vs console, from the bite taps (Lucky Timer)' },
    { id: 'land', label: 'where casts landed', x: null, y: null, n: 0, need: 3, what: 'the early / late calls (Lucky Timer)' }];
  function liveDots() {                                           // the Lucky Timer's timingDots, the practice parts recomputed now
    const L = T.lucky(), f = T.fit(), pd = T.pressData(L), ps = T.pressReady(L), bs = T.bpReact().s, dly = L.startTapMs;
    const dots = (f && Array.isArray(f.dots) ? f.dots : PLACEHOLDER).map(d => Object.assign({}, d));
    const put = d => { const i = dots.findIndex(x => x.id === d.id); if (i >= 0) dots[i] = d; else dots.push(d); };
    put({ id: 'press', label: 'B press on CAST', x: ps ? ps.med : (pd.s && pd.s.n ? pd.s.med : null), y: ps && isFinite(ps.sd) ? ps.sd : null, n: pd.s ? pd.s.n : 0, need: 5, what: 'cast practice + real casts with the cast tap' });
    put({ id: 'bprac', label: 'bite practice', x: bs ? bs.med - dly : null, y: bs && isFinite(bs.sd) ? bs.sd : null, n: bs ? bs.n : 0, need: BP.min, what: 'your reaction to the bite animation, vs the start-tap delay' });
    const rt = T.startTaps().map(r => r.ms).filter(Number.isFinite).slice(-40);
    if (rt.length) { const s = T.castStats(rt); put({ id: 'ready', label: 'READY tap (Dog practice)', x: s.med - dly, y: rt.length >= 5 && isFinite(s.sd) ? s.sd : null, n: rt.length, need: 5, what: 'your tap when Jack stops, vs the start-tap delay' }); }
    return dots;
  }
  const COL = { exit: '#b9cbd8', dock: '#b9cbd8', press: '#5fd38d', bite: '#e7c14a', bprac: '#f0a04a', clock: '#b48cff', land: '#ff9d7a', ready: '#7fd6ff' };
  function drawCompass() {                                        // the Lucky Timer's renderCompass, the same picture
    const cv = $('stCompass'); if (!cv) return;
    const dots = liveDots(), Wc = cv.clientWidth || 0; if (!Wc) return;
    const dpr = root.devicePixelRatio || 1, H = 300; cv.width = Wc * dpr; cv.height = H * dpr; cv.style.height = H + 'px';
    const g = cv.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, Wc, H);
    const XM = 300, YM = 160, padL = 34, padR = 10, padT = 16, padB = 22;
    const Xp = ms => padL + (Math.max(-XM, Math.min(XM, ms)) + XM) / (2 * XM) * (Wc - padL - padR), Yp = sd => padT + Math.max(0, Math.min(YM, sd)) / YM * (H - padT - padB);
    g.fillStyle = '#0b141c'; g.fillRect(padL, padT, Wc - padL - padR, H - padT - padB);
    g.fillStyle = '#5fd38d14'; g.fillRect(Xp(-50), Yp(0), Xp(50) - Xp(-50), Yp(60) - Yp(0));
    g.lineWidth = 1; g.font = '10px system-ui, sans-serif';
    for (const ms of [-300, -200, -100, 0, 100, 200, 300]) { g.beginPath(); g.moveTo(Xp(ms), padT); g.lineTo(Xp(ms), H - padB); g.strokeStyle = ms ? '#1f2d38' : '#5b7385'; g.stroke(); g.textAlign = 'center'; g.fillStyle = '#8ea3b2'; g.fillText((ms > 0 ? '+' : '') + ms, Xp(ms), H - padB + 11); }
    for (const sd of [0, 40, 80, 120, 160]) { g.beginPath(); g.moveTo(padL, Yp(sd)); g.lineTo(Wc - padR, Yp(sd)); g.strokeStyle = sd === 80 ? '#5b7385' : '#1f2d38'; g.stroke(); g.textAlign = 'right'; g.fillStyle = '#8ea3b2'; g.fillText('±' + sd, padL - 3, Yp(sd) + 3); }
    g.textAlign = 'left'; g.fillStyle = '#6fb7ff'; g.fillText('EARLY · steady', padL + 4, padT + 11); g.fillText('EARLY · loose', padL + 4, H - padB - 5);
    g.textAlign = 'right'; g.fillStyle = '#ff9d7a'; g.fillText('LATE · steady', Wc - padR - 4, padT + 11); g.fillText('LATE · loose', Wc - padR - 4, H - padB - 5);
    g.textAlign = 'center'; g.fillStyle = '#8ea3b2'; g.fillText('ms from where the app expects it', (padL + Wc - padR) / 2, H - 1);
    const tri = dots.filter(d => d.tri && d.x != null && d.y != null);
    if (tri.length >= 2) { g.beginPath(); tri.forEach((d, i) => (i ? g.lineTo(Xp(d.x), Yp(d.y)) : g.moveTo(Xp(d.x), Yp(d.y)))); g.closePath(); g.fillStyle = '#b9cbd822'; g.fill(); g.strokeStyle = '#b9cbd866'; g.stroke(); }
    let row = 0;
    for (const d of dots) {
      if (d.x == null) continue;
      const x = Xp(d.x), y = Yp(d.y == null ? 80 : d.y), col = COL[d.id] || '#b9cbd8', ok = d.n >= d.need && d.y != null;
      g.beginPath(); g.arc(x, y, 5, 0, 6.2832); g.lineWidth = 2; g.strokeStyle = col; g.fillStyle = col; if (ok) g.fill(); else g.stroke();
      g.font = '11px system-ui, sans-serif'; g.textAlign = x > Wc * 0.62 ? 'right' : 'left'; g.fillStyle = col;
      g.fillText(`${d.label} ${d.x >= 0 ? '+' : '−'}${Math.abs(Math.round(d.x))}`, x + (x > Wc * 0.62 ? -9 : 9), y + [-9, 15, -21, 27][row++ % 4]);
    }
    const verdict = d => (d.x == null ? '<span class="mut">no data yet</span>' : d.n < d.need ? `<span class="mut">${d.n} of ${d.need} needed</span>` :
      (Math.abs(d.x) <= 50 ? '<span style="color:#8ff0a4">on time</span>' : d.x < 0 ? '<span style="color:#6fb7ff">early</span>' : '<span style="color:#ff9d7a">late</span>') +
      (d.y == null ? '' : d.y <= 60 ? ', steady' : d.y <= 110 ? ', fair' : ', <span style="color:#ff9d7a">loose</span>'));
    const f = T.fit(), b = f ? f.b || 0 : 0, corr = T.cueCorr(), tot = corr - b * vi();
    $('stCompassTbl').innerHTML = '<table class="sttbl"><tr><th></th><th>offset</th><th>spread</th><th>from</th><th></th></tr>' + dots.map(d =>
      `<tr><td><span style="color:${COL[d.id] || '#b9cbd8'}">●</span> ${esc(d.label)}</td><td class="mono">${d.x == null ? '—' : sg(d.x) + ' ms'}</td><td class="mono">${d.y == null ? '—' : '±' + Math.round(d.y) + ' ms'}</td><td class="mut">${esc(d.what || '')}${d.n ? ` (${d.n})` : ''}</td><td>${verdict(d)}</td></tr>`).join('') + '</table>' +
      `<div style="margin-top:5px"><b>Total cast offset: the CAST cue is shown ${Math.abs(Math.round(tot))} ms ${tot <= 0 ? 'early' : 'late'} for you</b> = your B-press habit ${sg(corr)} ms ` +
      `(${T.lucky().biasAuto === false ? 'set by hand' : T.pressReady() ? 'learned' : 'none yet'}) ${b ? `and the clock shift ${sg(-b * vi())} ms (${b} VI${Math.abs(b) === 1 ? '' : 's'}, learned by the Lucky Timer from your bite taps)` : 'and no clock shift (the Lucky Timer learns it after 8 attempts with a bite tap)'}. ` +
      `Timing spread in use: ±${T.sigmaMs()} ms. ` + tbLine() + '</div>';
    if ($('stTbFix')) $('stTbFix').onclick = () => { T.setConsole({ updateMs: T.NTSC_UPDATE_MS }); renderAll(); };
  }
  function timingRows() {                                         // the Lucky Timer's four rows; the press and spread rows live
    const L = T.lucky(), f = T.fit(), d = T.pressData(L), ps = T.pressReady(L), corr = T.cueCorr(L), b = f ? f.b || 0 : 0, dly = L.startTapMs;
    const fr = id => (f && Array.isArray(f.rows) ? f.rows.find(r => r[0] === id) : null);
    const st = fr('start'), bt = fr('bite');
    const startVal = `${Math.round(dly + b * vi())} ms after the cue`;
    const startSrc = st && f.startDelay === dly ? st[3] : !L.autoTune ? 'set by hand' : b ? `${dly} set + ${sg(b * vi())} learned by the Lucky Timer from your bite taps` : `${dly} set; the Lucky Timer learns a correction from your bite taps after 8`;
    const pressVal = ps ? `${msTxt(ps.med)} vs CAST` : '—';
    const pressSrc = L.biasAuto === false ? `set by hand: CAST cue ${sg(corr)} ms` : ps ? `${ps.n} presses (${d.pr.length} practice + ${d.at.length} real casts) → CAST cue ${sg(corr)} ms`
      : `no presses yet (${d.es.length}/5): cast practice below${L.castTap ? ', or the cast tap in attempts' : ''}`;
    const sig = T.sigmaMs(L), varyVal = `±${sig} ms`;
    const varySrc = L.sigmaAuto === false ? `set by hand ±${sig}` : ps && isFinite(ps.sd) ? `B presses ±${Math.round(ps.sd)} + start tap ±${START1_MS} + clock offset known ±${Math.round(T.offsetSdMs())}` : `assumed ±${sig} (no presses yet)`;
    return [['Start taps', startVal, startSrc], ['B press on CAST', pressVal, pressSrc],
            ['Bite taps', bt ? bt[2] : '—', bt ? bt[3] : 'learned by the Lucky Timer after 3 bite taps in attempts'], ['How much you vary', varyVal, varySrc]];
  }
  const NTSC_HZ = 59.8261054535;
  function tbLine() {
    const u = 2 * vi(), off = Math.abs(u - T.NTSC_UPDATE_MS) > 0.0015;
    return off ? `<span style="color:#ef6f6f"><b>Time base check: the console frame period in use is ${u.toFixed(4)} ms, not the NTSC N64's ${T.NTSC_UPDATE_MS.toFixed(3)} ms.</b> <button type="button" id="stTbFix" class="small">Use ${T.NTSC_UPDATE_MS.toFixed(3)} ms</button></span>`
      : `Time base: NTSC N64, ${u.toFixed(3)} ms per game update = 2 video frames of ${vi().toFixed(3)} ms (${(1000 / vi()).toFixed(3)} Hz; console nominal ${NTSC_HZ.toFixed(3)} Hz) ✓`;
  }
  function renderTiming() {
    drawCompass();
    const row = r => `<tr><td>${r[0]}</td><td><b>${r[1]}</b></td><td class="mut">${r[2]}</td></tr>`;
    $('stRows').innerHTML = '<table class="sttbl">' + timingRows().map(row).join('') + '</table>';
    const f = T.fit();
    $('stFit').innerHTML = f ? `What only a page with the dog tables can work out (the clock shift, the bite taps, the dock-end tap, where casts landed) is as the <b>Lucky Timer</b> last worked it out: ` +
        `${esc(f.set_label || f.set || 'a game file')}, ${esc(new Date(f.at).toLocaleString())}. It updates whenever a Lucky Timer page is open.`
      : 'Nothing learned from attempts yet: play attempts on the Lucky Timer and what they teach (the clock shift, your bite taps, where your casts landed) shows here too.';
    renderManual();
  }

  /* ================================================================ set by hand */
  function renderManual() {
    const L = T.lucky(), ps = T.pressReady(L);
    $('stStartDelay').value = L.startTapMs;
    $('stAutoTune').checked = !!L.autoTune;
    $('stBias').value = T.cueCorr(L); $('stBias').disabled = L.biasAuto !== false && !!ps;
    $('stBiasAuto').checked = L.biasAuto !== false;
    const sig = T.sigmaMs(L);
    $('stSigma').value = sig; $('stSigmaV').textContent = sig + ' ms'; $('stSigma').disabled = L.sigmaAuto !== false && !!(ps && isFinite(ps.sd));
    $('stSigmaAuto').checked = L.sigmaAuto !== false;
    const rt = T.startTaps().map(r => r.ms).filter(Number.isFinite).slice(-40), s = rt.length ? T.castStats(rt) : null;
    $('stReady').innerHTML = s ? `Your taps when Jack stops in Dog practice's whole attempt: <b>${Math.round(s.med)} ms</b> after he stops (median of ${rt.length}` +
        `${isFinite(s.sd) && rt.length >= 5 ? `, spread ±${Math.round(s.sd)} ms` : ''}). ` +
        (rt.length >= 5 ? `<button type="button" id="stUseReady" class="small">Use ${Math.round(s.med)} ms as my start-tap delay</button>` : `${5 - rt.length} more and it can set your start-tap delay.`)
      : 'Dog practice\'s whole attempt measures your tap when Jack stops; after 5 of them it can set your start-tap delay here.';
    if ($('stUseReady')) $('stUseReady').onclick = () => { T.setLucky({ startTapMs: Math.round(s.med) }); renderAll(); };
  }
  function wireManual() {
    $('stStartDelay').onchange = e => { const v = Math.max(-300, Math.min(800, Math.round(+e.target.value || 0))); T.setLucky({ startTapMs: v }); renderAll(); };
    $('stAutoTune').onchange = e => { T.setLucky({ autoTune: e.target.checked }); renderAll(); };
    $('stBias').onchange = e => { T.setLucky({ biasMs: Math.round(+e.target.value || 0) }); renderAll(); };
    $('stBiasAuto').onchange = e => {                               // switching to manual starts from the value it had
      const ps = T.pressReady(), p = { biasAuto: e.target.checked };
      if (!e.target.checked) p.biasMs = ps ? -Math.round(ps.med) : T.lucky().biasMs;
      T.setLucky(p); renderAll();
    };
    $('stSigma').oninput = e => { $('stSigmaV').textContent = e.target.value + ' ms'; };
    $('stSigma').onchange = e => { T.setLucky({ sigmaMs: +e.target.value }); renderAll(); };
    $('stSigmaAuto').onchange = e => {
      const ps = T.pressReady(), p = { sigmaAuto: e.target.checked };
      if (!e.target.checked) p.sigmaMs = ps && isFinite(ps.sd) ? T.sigmaFrom(ps.sd) : T.lucky().sigmaMs;
      T.setLucky(p); renderAll();
    };
  }

  /* ================================================================ practice: the drills */
  let D = null;                                                   // the running drill
  let actx = null;
  function audio() { if (!T.lucky().audio) return null; try { actx = actx || new (root.AudioContext || root.webkitAudioContext)(); return actx; } catch (e) { return null; } }
  function beepAt(wall, f, dur) {
    const a = audio(); if (!a) return;
    const t = a.currentTime + Math.max(0, (wall - now()) / 1000), o = a.createOscillator(), g = a.createGain();
    o.frequency.value = f; o.connect(g); g.connect(a.destination);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.25, t + 0.005); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.start(t); o.stop(t + dur + 0.02);
  }
  const gapMs = () => PRAC.gap[0] + Math.random() * (PRAC.gap[1] - PRAC.gap[0]);
  function stopDrill() { if (D) clearTimeout(D.timer); D = null; renderPractice(); }
  /* cast practice (quick mode): the cue 4 s after each start; press the start key on CAST; combo: keep holding, let go at the bite */
  function castStart() {
    stopDrill();
    const L = T.lucky();
    D = { kind: 'cast', combo: L.pracCombo !== false, line: !!L.pracLine, audioOn: !!L.audio, mode: T.pracMode(L), state: 'gap', rep: 0, cue: null, timer: null, session: [], last: null, rel: null, hb: null, held: false };
    castSchedule(700); renderPractice();
  }
  function castSchedule(ms) { if (!D) return; clearTimeout(D.timer); D.state = 'gap'; D.timer = setTimeout(castRep, ms); }
  function castRep() {
    if (!D || D.kind !== 'cast') return;
    D.cue = now() + PRAC.lead;
    [-1500, -1000, -500].forEach(d => beepAt(D.cue + d, 440, 0.06)); beepAt(D.cue, 880, 0.14);
    D.state = 'armed'; D.rep++; D.early = false; D.last = null; D.rel = null; D.hb = null;
    clearTimeout(D.timer); D.timer = setTimeout(() => castPress(null), D.cue - now() + PRAC.win);
  }
  function castPress(ts, src) {
    if (!D || D.kind !== 'cast') return false;
    if (D.state !== 'armed') return false;
    if (ts !== null && ts < D.cue - PRAC.win) { D.early = true; return true; }   // far too early: ignored, still armed
    clearTimeout(D.timer);
    const rec = { e: ts === null ? null : Math.round((ts - D.cue) * 10) / 10, m: D.mode, src: src || keyName(), ...(D.audioOn ? {} : { v: 1 }) };
    T.addCast(rec); rec.at = Date.now();
    D.session.push(rec); D.last = rec; D.state = 'done';
    if (D.combo && ts !== null) {
      const lands = ts + G_CAST * vi();
      D.state = 'hold'; D.hb = { press: ts, at: lands + BP.gap[0] + Math.random() * (BP.gap[1] - BP.gap[0]), shown: null };
      renderPractice(); return true;
    }
    D.timer = setTimeout(() => { if (D && D.kind === 'cast') castSchedule(gapMs()); }, Math.max(0, D.cue + 900 - now()));
    renderPractice(); return true;
  }
  function castRelease(ts, src) {
    if (!D || D.kind !== 'cast' || D.state !== 'hold') return false;
    const h = D.hb;
    if (h.shown == null || ts < h.shown) castRel({ r: null, k: 'early', src: src || keyName() + ' release' });
    else { const r = Math.round((ts - h.shown) * 10) / 10; castRel({ r, k: r <= T.bpWin() ? 'ok' : 'late', src: src || keyName() + ' release' }); }
    return true;
  }
  function castRel(rec) {                                         // the release half of a combo rep, into the bite store (m rel, c 1)
    rec.m = 'rel'; rec.c = 1; T.addBite(rec);
    D.rel = rec; D.state = 'rdone'; D.doneAt = now();
    clearTimeout(D.timer);
    D.timer = setTimeout(() => { if (D && D.kind === 'cast') { D.state = 'done'; castSchedule(gapMs()); } }, BP.show + 400);
    renderPractice();
  }
  /* bite practice: hold and let go at the bite (as B), or tap at the bite */
  function biteStart() {
    stopDrill();
    const rel = T.lucky().bpMode !== 'tap';
    D = { kind: 'bite', mode: rel ? 'rel' : 'tap', state: rel ? 'ready' : 'wait', held: false, t0: now(), at: 0, shown: null, doneAt: 0, last: null, session: [] };
    if (!rel) biteNext(500);
    renderPractice();
  }
  function biteNext(lead) { D.state = 'wait'; D.t0 = now(); D.shown = null; D.at = D.t0 + (lead || 0) + BP.gap[0] + Math.random() * (BP.gap[1] - BP.gap[0]); }
  function biteRecord(rec) { rec.m = D.mode; T.addBite(rec); D.session.push(rec); D.last = rec; D.state = 'done'; D.doneAt = now(); renderPractice(); }
  function biteAnswer(ts, src) {
    if (D.state === 'done' || D.state === 'ready') return true;
    if (D.state === 'wait' || ts < D.shown) { biteRecord({ r: null, k: 'early', src: src || keyName() }); return true; }
    const r = Math.round((ts - D.shown) * 10) / 10;
    biteRecord({ r, k: r <= T.bpWin() ? 'ok' : 'late', src: src || keyName() });
    return true;
  }
  /* input: the start key, a mouse / touch on the picture, a controller button */
  function down(ts, src) {
    if (!D) return false;
    if (D.kind === 'cast') return castPress(ts, src);
    if (D.mode === 'rel') { if (D.held) return true; D.held = true; if (D.state === 'ready') biteNext(0); return true; }
    return biteAnswer(ts, src);
  }
  function up(ts, src) {
    if (!D) return false;
    if (D.kind === 'cast') return castRelease(ts, src);
    if (D.mode !== 'rel' || !D.held) return true;
    D.held = false;
    if (D.state === 'wait' || D.state === 'bite') biteAnswer(ts, src || keyName() + ' release');
    return true;
  }
  let pads = {};
  function tick() {
    const n = now();
    if (D && D.kind === 'cast' && D.state === 'hold') {
      const h = D.hb;
      if (h.shown == null && n >= h.at) h.shown = n;
      else if (h.shown != null && n - h.shown > BP.miss) castRel({ r: null, k: 'miss', src: '' });
    }
    if (D && D.kind === 'bite') {
      if (D.state === 'wait' && n >= D.at) { D.state = 'bite'; D.shown = n; }
      else if (D.state === 'bite' && n - D.shown > BP.miss) biteRecord({ r: null, k: 'miss', src: '' });
      else if (D.state === 'done' && n - D.doneAt > BP.show) { if (D.mode === 'rel' && !D.held) { D.state = 'ready'; D.t0 = n; } else biteNext(0); }
    }
    if (D && navigator.getGamepads) for (const gp of navigator.getGamepads()) {
      if (!gp) continue;
      const prev = pads[gp.index], cur = gp.buttons.map(x => x.pressed);
      if (prev) {
        const i = cur.findIndex((v, j) => v !== prev[j]);
        if (i >= 0) { const ts = gp.timestamp > 0 && gp.timestamp < 1e11 ? gp.timestamp : n; if (cur[i]) down(ts, 'controller press'); else if (!cur.some(Boolean)) up(ts, 'controller release'); }
      }
      pads[gp.index] = cur;
    }
    drawTv(); drawLamp();
    requestAnimationFrame(tick);
  }
  /* what the picture shows: Jack's catalog frames on Thomas's READY screenshot, as the Lucky Timer's preview */
  function jackState() {
    const n = now(), v = vi();
    if (!D) return { anim: 'idle', info: 'start a drill below' };
    if (D.kind === 'cast') {
      if (D.state === 'hold') {
        const h = D.hb, e = (n - h.press) / v;
        if (h.shown != null) { const eb = (n - h.shown) / v; return eb < G_PULL ? { anim: 'bite', e: eb, float: 'floatBite', ft: eb, info: '' } : { anim: 'wait', info: '' }; }
        if (e < G_CAST) return e < 4 ? { anim: 'idle', info: 'cast!' } : { anim: 'cast', e: e - 4, info: 'holding…' };
        return { anim: 'wait', float: 'float', ft: e - G_CAST, info: 'holding… let go at the bite' };
      }
      if (D.state === 'rdone' && D.rel) {
        const r = D.rel, e = (n - D.doneAt) / v;
        if (r.k === 'ok') return e < G_CATCH - G_PULL ? { anim: 'land', e, info: `caught · ${Math.round(r.r)} ms` } : { anim: 'idle', info: `caught · ${Math.round(r.r)} ms` };
        return { anim: 'idle', info: r.k === 'late' ? `late by ${Math.round(r.r - T.bpWin())} ms` : r.k === 'early' ? 'let go too early' : 'missed' };
      }
      if (D.state === 'armed') { const left = (D.cue - n) / 1000; return { anim: 'idle', info: left > 0 ? `cast in ${left.toFixed(1)} s` : 'cast!' }; }
      return { anim: 'idle', info: D.last ? (D.last.e == null ? 'no press' : `cast ${msTxt(D.last.e)}`) : 'get ready…' };
    }
    if (D.state === 'ready') return { anim: 'idle', info: `hold ${keyName()} to cast` };
    if (D.state === 'wait') return { anim: 'wait', float: 'float', ft: (n - D.t0) / v, info: D.mode === 'rel' ? 'holding… let go at the bite' : 'waiting for a bite…' };
    if (D.state === 'bite') { const e = (n - D.shown) / v; return e < G_PULL ? { anim: 'bite', e, float: 'floatBite', ft: e, info: '' } : { anim: 'wait', info: '' }; }
    const r = D.last, e = (n - D.doneAt) / v;
    if (r.k === 'ok') return e < G_CATCH - G_PULL ? { anim: 'land', e, info: `caught · ${Math.round(r.r)} ms` } : { anim: 'idle', info: `caught · ${Math.round(r.r)} ms` };
    return { anim: r.k === 'early' ? 'wait' : 'idle', float: r.k === 'early' ? 'float' : null, ft: (n - D.t0) / v, info: r.k === 'late' ? `late by ${Math.round(r.r - T.bpWin())} ms` : r.k === 'early' ? 'too early' : 'missed' };
  }
  const JACK = X.jack && X.jack.facings ? X.jack : null, BEACH = X.beach && X.beach.img ? X.beach : null;
  const imgs = new Map();
  const img = src => { let m = imgs.get(src); if (!m) { m = new Image(); m.src = src; imgs.set(src, m); } return m; };
  function frameOf(a, e) {
    const tot = a.ticks.reduce((x, y) => x + y, 0) || 1;
    let k = Math.max(0, Math.floor(e || 0));
    if (a.loop) k %= tot; else if (k >= tot) return a.frames.length - 1;
    for (let i = 0; i < a.ticks.length; i++) { if (k < a.ticks[i]) return i; k -= a.ticks[i]; }
    return a.frames.length - 1;
  }
  function drawTv() {
    const cv = $('stTv'); if (!cv) return;
    const W = 400, H = 300, r = root.devicePixelRatio || 1;
    if (cv.width !== Math.round(W * r)) { cv.width = Math.round(W * r); cv.height = Math.round(H * r); }
    const g = cv.getContext('2d'); g.setTransform(r, 0, 0, r, 0, 0);
    const st = jackState();
    g.fillStyle = '#4c6584'; g.fillRect(0, 0, W, H);
    let s = 2, ax = 160, ay = 140;
    if (BEACH) {
      const k = W / BEACH.w, bim = img(BEACH.img), jp = BEACH.jack.SE;
      if (bim.complete && bim.naturalWidth) g.drawImage(bim, 0, 0, BEACH.w * k, BEACH.h * k);
      s = k * BEACH.pxPerNative; ax = (jp[0] - BEACH.x0) * k; ay = (jp[1] - BEACH.y0) * k;
    }
    g.imageSmoothingEnabled = false;
    if (JACK) {
      const F = JACK.facings.SE, sc = JACK.scene.SE;
      const draw = (a, i, x, y) => { const m = img(a.frames[i]); if (m.complete && m.naturalWidth) g.drawImage(m, Math.round(x - a.ax * s), Math.round(y - a.ay * s), a.w * s, a.h * s); };
      g.fillStyle = '#0b162466'; g.beginPath(); g.ellipse(ax, ay + 2 * s, 9 * s, 3.5 * s, 0, 0, 6.283); g.fill();
      const an = F[st.anim] || F.idle; draw(an, frameOf(an, st.e), ax, ay);
      if (st.float && JACK.extras[st.float]) draw(JACK.extras[st.float], frameOf(JACK.extras[st.float], st.ft), ax + sc.float[0] * s, ay + sc.float[1] * s);
    }
    g.fillStyle = '#000a'; g.fillRect(0, H - 22, W, 22); g.fillStyle = '#dce6ec'; g.font = '12px ui-monospace,monospace'; g.textBaseline = 'middle'; g.fillText(st.info || '', 8, H - 11);
  }
  function drawLamp() {                                           // the cues: pulses at -1.5 / -1 / -0.5 s, CAST, the moving line
    const el = $('stLamp'); if (!el) return;
    const n = now();
    let cls = 'lamp', big = '', sub = '';
    if (!D) { big = 'PRACTICE'; sub = 'pick a drill'; }
    else if (D.kind === 'cast') {
      if (D.state === 'armed') {
        const left = D.cue - n, pulse = [1500, 1000, 500].some(d => Math.abs(left - d) < 110);
        if (Math.abs(left) < 260) { cls += ' go'; big = 'CAST'; sub = `press ${keyName()} now`; }
        else if (left > 0) { cls += pulse ? ' pulse' : ''; big = `CAST in ${(left / 1000).toFixed(1)}`; sub = D.early ? 'too early: wait for CAST' : `press ${keyName()} on CAST`; }
        else { big = 'CAST'; sub = 'late…'; }
      } else if (D.state === 'hold') { big = 'HOLDING'; sub = 'let go the instant the rod dips'; cls += D.hb && D.hb.shown != null && n - D.hb.shown < G_PULL * vi() ? ' go' : ''; }
      else if (D.state === 'rdone' && D.rel) { const c = D.last, r = D.rel; big = r.k === 'ok' ? `CAUGHT ${Math.round(r.r)} ms` : r.k === 'late' ? `LATE +${Math.round(r.r - T.bpWin())} ms` : r.k === 'early' ? 'TOO EARLY' : 'MISSED'; sub = c && c.e != null ? `cast ${msTxt(c.e)}` : ''; cls += r.k === 'ok' ? ' go' : ' bad'; }
      else if (D.last) { big = D.last.e == null ? 'NO PRESS' : `CAST ${msTxt(D.last.e)}`; sub = 'next cast soon'; cls += D.last.e != null && Math.abs(D.last.e) <= vi() ? ' go' : ''; }
      else { big = 'GET READY'; sub = `press ${keyName()} on CAST`; }
    } else {
      if (D.state === 'done' && D.last) { const r = D.last; big = r.k === 'ok' ? `CAUGHT ${Math.round(r.r)} ms` : r.k === 'late' ? `LATE +${Math.round(r.r - T.bpWin())} ms` : r.k === 'early' ? 'TOO EARLY' : 'MISSED'; cls += r.k === 'ok' ? ' go' : ' bad'; sub = r.k === 'ok' ? `${Math.round(T.bpWin() - r.r)} ms to spare` : ''; }
      else if (D.mode === 'rel' && D.state === 'ready') { big = `HOLD ${keyName().toUpperCase()}`; sub = 'press and hold to cast, let go at the bite'; }
      else { big = D.mode === 'rel' ? 'HOLDING — LET GO AT THE BITE' : 'TAP AT THE BITE'; sub = 'watch Jack, not this lamp'; }
    }
    if (el.dataset.k !== cls + big + sub) { el.dataset.k = cls + big + sub; el.className = cls; el.innerHTML = `<b>${esc(big)}</b><span>${esc(sub)}</span>`; }
    const ln = $('stLine');                                       // the moving cast line (the "moving line" mode)
    if (ln) {
      const show = !!(D && D.kind === 'cast' && D.line && (D.state === 'armed' || D.state === 'gap'));
      ln.style.visibility = show ? 'visible' : 'hidden';
      if (show) {
        const W = ln.clientWidth || 400, H = 26, r = root.devicePixelRatio || 1;
        if (ln.width !== Math.round(W * r)) { ln.width = Math.round(W * r); ln.height = Math.round(H * r); }
        const g = ln.getContext('2d'); g.setTransform(r, 0, 0, r, 0, 0); g.clearRect(0, 0, W, H);
        const mark = W * 0.8; g.fillStyle = '#0b141c'; g.fillRect(0, 4, W, H - 8);
        g.fillStyle = '#ffffff'; g.fillRect(mark - 1, 0, 2, H); g.fillStyle = '#8ea3b2'; g.font = '10px system-ui'; g.fillText('CAST', mark + 4, 12);
        if (D.state === 'armed') { const left = D.cue - n, x = mark - Math.max(-600, left) / PRAC.lead * mark; g.fillStyle = '#5fd38d'; g.fillRect(Math.max(0, x - 3), 6, 6, H - 12); }
      }
    }
  }
  /* histograms and the lines under them (the Lucky Timer's) */
  function drawPracHist(es, s, ea) {
    const cv = $('stPracHist'); if (!cv || !cv.clientWidth) return;
    const dpr = root.devicePixelRatio || 1, W = cv.width = Math.max(10, cv.clientWidth * dpr), H = cv.height = 64 * dpr, g = cv.getContext('2d'), top = 13 * dpr;
    g.clearRect(0, 0, W, H);
    const R = s && isFinite(s.sd) ? Math.max(100, Math.min(300, Math.ceil((Math.abs(s.med) + 4 * s.sd) / 50) * 50)) : 300;
    const bw = vi(), nb = Math.round(2 * R / bw), lo = -nb / 2 * bw, hi = nb / 2 * bw, Xh = ms => (ms - lo) / (hi - lo) * W;
    const bins = new Array(nb).fill(0), binA = new Array(nb).fill(0);
    const put = (arr, e) => { arr[Math.floor((Math.max(lo, Math.min(hi - 1e-6, e)) - lo) / bw)]++; };
    es.forEach(e => put(bins, e)); ea.forEach(e => put(binA, e));
    const mx = Math.max(1, ...bins, ...binA), base = H - 12 * dpr;
    g.fillStyle = '#6fb7ff'; bins.forEach((v, i) => { if (v) { const h = v / mx * (base - top); g.fillRect(Xh(lo + i * bw) + 1, base - h, Math.max(1, Xh(lo + (i + 1) * bw) - Xh(lo + i * bw) - 2), h); } });
    g.fillStyle = '#ffd54a'; binA.forEach((v, i) => { if (v) { const h = v / mx * (base - top); g.fillRect(Xh(lo + (i + 0.5) * bw) - 1.5 * dpr, base - h, 3 * dpr, h); } });
    g.strokeStyle = '#ffffff'; g.lineWidth = 1.5 * dpr; g.beginPath(); g.moveTo(Xh(0), top); g.lineTo(Xh(0), base); g.stroke();
    if (s) { g.strokeStyle = '#ff9a50'; g.setLineDash([3 * dpr, 3 * dpr]); g.beginPath(); g.moveTo(Xh(s.med), top); g.lineTo(Xh(s.med), base); g.stroke(); g.setLineDash([]); }
    g.fillStyle = '#8ea3b2'; g.font = `${9 * dpr}px ui-monospace,monospace`;
    for (let ms = -R; ms <= R; ms += 100) { const tx = (ms > 0 ? '+' : '') + ms, w = g.measureText(tx).width; g.fillText(tx, Math.max(0, Math.min(W - w, Xh(ms) - w / 2)), H - 2 * dpr); }
    g.fillText('blue: practice · yellow: real casts · white: the CAST cue · orange: your median', 2 * dpr, 9 * dpr);
  }
  function drawBiteHist(st, mode) {
    const cv = $('stBpHist'); if (!cv || !cv.clientWidth) return;
    const dpr = root.devicePixelRatio || 1, W = cv.width = Math.max(10, cv.clientWidth * dpr), H = cv.height = 64 * dpr, g = cv.getContext('2d'), top = 13 * dpr, base = H - 12 * dpr;
    g.clearRect(0, 0, W, H);
    const bw = vi(), nb = 36, hi = nb * bw, Xh = ms => ms / hi * W, win = T.bpWin(), bins = new Array(nb).fill(0);
    for (const r of T.biteLog()) if (T.bpKind(r) === mode && Number.isFinite(r.r) && r.r >= 0) bins[Math.min(nb - 1, Math.floor(r.r / bw))]++;
    const mx = Math.max(1, ...bins);
    g.fillStyle = '#5fd38d18'; g.fillRect(0, top, Xh(win), base - top);
    bins.forEach((v, i) => { if (v) { const h = v / mx * (base - top); g.fillStyle = (i + 0.5) * bw <= win ? '#5fd38d' : '#ef6f6f'; g.fillRect(Xh(i * bw) + 1, base - h, Math.max(1, Xh(bw) - 2), h); } });
    g.strokeStyle = '#ffffff'; g.lineWidth = 1.5 * dpr; g.beginPath(); g.moveTo(Xh(win), top); g.lineTo(Xh(win), base); g.stroke();
    if (st.s) { g.strokeStyle = '#ff9a50'; g.setLineDash([3 * dpr, 3 * dpr]); g.beginPath(); g.moveTo(Xh(st.s.med), top); g.lineTo(Xh(st.s.med), base); g.stroke(); g.setLineDash([]); }
    g.fillStyle = '#8ea3b2'; g.font = `${9 * dpr}px ui-monospace,monospace`;
    for (let ms = 0; ms <= hi; ms += 100) { const tx = ms + (ms + 100 > hi ? ' ms' : ''), w = g.measureText(tx).width; g.fillText(tx, Math.max(0, Math.min(W - w, Xh(ms) - w / 2)), H - 2 * dpr); }
    g.fillText('green caught · red late · white end of the bite window · orange median', 2 * dpr, 9 * dpr);
  }
  const MODE_TXT = (L, m) => (L.audio ? { line: 'moving line + beeps', beeps: 'beeps only' } : { line: 'moving line + pulses', beeps: 'pulses only' })[m];
  function renderPractice() {
    const L = T.lucky(), mode = T.pracMode(L), es = T.pracErrs(mode, L), s = T.castStats(es), ea = T.attemptErrs(L), sa = T.castStats(ea);
    $('stCastBtn').textContent = D && D.kind === 'cast' ? 'Stop (Esc)' : L.pracCombo !== false ? 'Cast + bite practice' : 'Cast practice';
    $('stBiteBtn').textContent = D && D.kind === 'bite' ? 'Stop (Esc)' : 'Bite practice';
    $('stPracLine').checked = !!L.pracLine; $('stPracCombo').checked = L.pracCombo !== false;
    $('stBpMode').checked = L.bpMode === 'tap'; $('stBpUse').checked = L.bpUse !== false;
    const want = L.audio ? 'a' : 'v', miss = T.castLog().filter(r => r.m === mode && r.e === null && T.cueKind(r) === want).length;
    const parts = [];
    if (!s) parts.push(`No presses yet in <b>${MODE_TXT(L, mode)}</b> mode${L.audio ? '' : ' (presses made with sound are kept apart)'}. Start the drill and press ${esc(keyName())} on CAST.`);
    else {
      parts.push(`<b>${MODE_TXT(L, mode)}</b>: ${s.n} press${s.n === 1 ? '' : 'es'}${miss ? ` (+${miss} missed)` : ''} · you press <b>${msTxt(s.med)}</b> vs CAST (median) · spread <b>${isFinite(s.sd) ? Math.round(s.sd) + ' ms' : '—'}</b>${s.out ? ` (${s.out} far off left out)` : ''}`);
      parts.push(`on the right game frame: ${Math.round(100 * s.raw1)}% as you press now, ${Math.round(100 * s.cor1)}% once the cue is shifted by ${msTxt(-s.med)} (within ±1 frame: ${Math.round(100 * s.cor2)}%)`);
      if (s.n >= 5 && isFinite(s.sd)) parts.push(`with this profile: cast-cue correction ${msTxt(-s.med)}, timing spread ${T.sigmaFrom(s.sd)} ms (your ${Math.round(s.sd)} ms + start tap ${PRAC.startSd} + clock offset ±${Math.round(T.offsetSdMs())} ms) · in use: ${msTxt(T.cueCorr(L))}, ${T.sigmaMs(L)} ms`);
    }
    if (D && D.kind === 'cast' && D.session.length >= 3) { const ss = T.castStats(D.session.filter(r => Number.isFinite(r.e)).map(r => r.e)); if (ss) parts.push(`this session: ${ss.n} · ${msTxt(ss.med)} · spread ${isFinite(ss.sd) ? Math.round(ss.sd) + ' ms' : '—'}`); }
    if (sa) parts.push(`in real attempts (${esc(keyName())} tapped with B): ${sa.n} casts · ${msTxt(sa.med)} vs the CAST cue · spread ${isFinite(sa.sd) ? Math.round(sa.sd) + ' ms' : '—'}`);
    $('stPracTxt').innerHTML = parts.join('<br>');
    $('stPracApply').hidden = L.biasAuto !== false && L.sigmaAuto !== false;
    drawPracHist(es, s, ea);
    const bm = L.bpMode === 'tap' ? 'tap' : 'rel', bs = T.bpStats(null, bm), br = T.bpReact(), w = Math.round(T.bpWin()), bparts = [];
    if (!bs.n && !bs.miss && !bs.early) bparts.push(`No reactions yet (${bm === 'rel' ? 'hold and let go' : 'tap'} mode). The window to catch a bite is ${w} ms (${T.WINDOW_VI} video frames).`);
    else {
      bparts.push(`${bm === 'rel' ? 'Let go' : 'Tap'} mode: ${bs.n + bs.miss + bs.early} bites · caught <b>${bs.share == null ? '—' : Math.round(100 * bs.share) + '%'}</b> · ${bs.late} late · ${bs.miss} missed · ${bs.early} too early` +
        (bs.s ? ` · your reaction <b>${Math.round(bs.s.med)} ms</b> (median), spread ${isFinite(bs.s.sd) ? Math.round(bs.s.sd) + ' ms' : '—'}` : ''));
      bparts.push(br.s && br.s.n >= BP.min && isFinite(br.s.sd) ? (L.bpUse === false ? 'not in use (box off): the bite-tap delay stays at its stock value'
        : `in use as your bite-tap delay: ${Math.round(br.s.med)} ± ${Math.round(br.s.sd)} ms from ${br.s.n} ${br.kind === 'tap' ? 'taps' : 'releases'}${br.kind === 'rel' ? ' (a stand-in: in an attempt you PRESS Space at the bite; 8 reactions in tap mode would measure that itself)' : ''}, until your attempts have measured your own`)
        : `${Math.max(1, BP.min - (br.s ? br.s.n : 0))} more reaction${BP.min - (br.s ? br.s.n : 0) === 1 ? '' : 's'} and it replaces the stock bite-tap delay (${Math.round((T.console().tapMuVI || 13) * vi())} ms)`);
    }
    if (D && D.kind === 'bite' && D.session.length >= 3) { const ss = T.bpStats(D.session, D.mode); if (ss.s) bparts.push(`this session: ${ss.n + ss.miss} bites · caught ${Math.round(100 * ss.share)}% · ${Math.round(ss.s.med)} ms`); }
    $('stBpTxt').innerHTML = bparts.join('<br>');
    drawBiteHist(bs, bm);
  }
  function wirePractice() {
    $('stCastBtn').onclick = e => { if (D && D.kind === 'cast') stopDrill(); else castStart(); e.target.blur(); };
    $('stBiteBtn').onclick = e => { if (D && D.kind === 'bite') stopDrill(); else biteStart(); e.target.blur(); };
    $('stPracLine').onchange = e => { T.setLucky({ pracLine: e.target.checked }); if (D && D.kind === 'cast') castStart(); renderAll(); e.target.blur(); };
    $('stPracCombo').onchange = e => { T.setLucky({ pracCombo: e.target.checked }); if (D && D.kind === 'cast') castStart(); renderAll(); e.target.blur(); };
    $('stBpMode').onchange = e => { T.setLucky({ bpMode: e.target.checked ? 'tap' : 'rel' }); if (D && D.kind === 'bite') biteStart(); renderAll(); e.target.blur(); };
    $('stBpUse').onchange = e => { T.setLucky({ bpUse: e.target.checked }); renderAll(); e.target.blur(); };
    $('stPracForget').onclick = () => { const L = T.lucky(), m = T.pracMode(L); if (confirm(`Forget your ${MODE_TXT(L, m)} practice presses?`)) { T.forgetCast(m, L.audio ? 'a' : 'v'); renderAll(); } };
    $('stBpForget').onclick = () => { if (confirm('Forget all your bite reactions (bite practice and the release half of cast + bite practice)?')) { T.forgetBite(); renderAll(); } };
    $('stPracApply').onclick = () => {                              // the Lucky Timer's applyCastProfile: into the hand-set values
      const L = T.lucky(), s = T.castStats(T.pracErrs(T.pracMode(L), L));
      if (!s || s.n < 5 || !isFinite(s.sd)) { $('stPracTxt').insertAdjacentHTML('beforeend', ' <b>Need 5 presses in this mode first.</b>'); return; }
      T.setLucky({ biasMs: -Math.round(s.med), sigmaMs: T.sigmaFrom(s.sd) }); renderAll();
    };
    const tv = $('stTv');
    tv.addEventListener('pointerdown', e => { if (!D) return; e.preventDefault(); try { tv.setPointerCapture(e.pointerId); } catch (x) { /* synthetic */ } down(evTime(e), 'mouse'); });
    tv.addEventListener('pointerup', e => { if (D) up(evTime(e), 'mouse release'); });
  }

  /* ================================================================ keys (the Lucky Timer's rules, v30.20 / v31.27) */
  const DW_RESERVED = { Space: 'every tap (start, clock cues, dock end, bites)', KeyS: 'sparrows at the door', KeyX: 'pier only', KeyH: 'result: Nut', KeyM: 'result: fish',
    KeyE: 'result: empty line', KeyP: 'preview', Escape: 'stop', Backspace: 'undo', Delete: 'removes the top dog card', ArrowUp: 'dog facing', ArrowDown: 'dog facing', ArrowLeft: 'dog facing', ArrowRight: 'dog facing',
    KeyW: 'dog facing (W A S D option)', KeyA: 'dog facing (W A S D option)', KeyD: 'dog facing (W A S D option)', Enter: 'picks the top dog card, then sets its timing', NumpadEnter: 'picks the top dog card, then sets its timing', Tab: 'moves the focus' };
  const DW_RESERVED_KEYS = { ' ': 'Space', s: 'KeyS', x: 'KeyX', h: 'KeyH', m: 'KeyM', e: 'KeyE', p: 'KeyP', w: 'KeyW', a: 'KeyA', d: 'KeyD' };
  const DW_ADJ_DEF = ['BracketLeft', 'BracketRight'];
  const DW_ANIM_DEF_EXTRA = { 80: 'KeyR', 88: 'KeyF', 104: 'KeyG', 176: 'KeyO', 200: 'KeyB' };
  const dwAnimDef = () => { const o = {}; if (DWC) for (const [g, bs] of Object.entries(DWC.NUMPAD)) for (const b of bs) o[b] = 'Numpad' + g; return Object.assign(o, DW_ANIM_DEF_EXTRA); };
  const dwAnimKeys = () => Object.assign(dwAnimDef(), T.lucky().dwAnimKeys || {});
  const dwAdjKeys = () => { const a = T.lucky().dwAdjKeys; return Array.isArray(a) && a.length === 2 ? a : DW_ADJ_DEF; };
  const CODE_TXT = { ArrowUp: '↑', ArrowDown: '↓', ArrowLeft: '←', ArrowRight: '→', Escape: 'Esc', BracketLeft: '[', BracketRight: ']', Minus: '-', Equal: '=', Semicolon: ';', Quote: "'", Comma: ',', Period: '.', Slash: '/',
    NumpadAdd: 'Num +', NumpadSubtract: 'Num −', NumpadMultiply: 'Num *', NumpadDivide: 'Num /', NumpadDecimal: 'Num .', Delete: 'Del', Insert: 'Ins', PageUp: 'PgUp', PageDown: 'PgDn' };
  const codeTxt = c => (!c ? '—' : CODE_TXT[c] || (/^Key[A-Z]$/.test(c) ? c[3] : /^Digit\d$/.test(c) ? c[5] : /^Numpad\d$/.test(c) ? 'Num ' + c[6] : c));
  const dwName = b => (X.names && X.names[b]) || (b === 32 ? 'stand' : 'anim ' + b);
  function dwKeyRefused(e, kind, slot) {
    const c = e.code || '', L = T.lucky(), fsKey = (T.get(T.KEY.lucky, {}) || {}).fsKey;
    if (!c || /^(Shift|Control|Alt|Meta|OS)/.test(c) || c === 'CapsLock' || c === 'ContextMenu' || /^F\d+$/.test(c)) return 'that key cannot be used';
    if (DW_RESERVED[c]) return `${codeTxt(c)} is taken: ${DW_RESERVED[c]}`;
    const kk = e.key && e.key.length === 1 ? e.key.toLowerCase() : e.key;
    if (DW_RESERVED_KEYS[kk]) return `${codeTxt(c)} types "${kk === ' ' ? 'space' : kk}" on your layout, which is taken: ${DW_RESERVED[DW_RESERVED_KEYS[kk]]}`;
    if (e.key === L.startKey) return `${codeTxt(c)} is your start key`;
    const adj = dwAdjKeys(), ak = dwAnimKeys();
    if (kind === 'anim' && adj.includes(c)) return `${codeTxt(c)} moves the dog cards ${adj[0] === c ? 'earlier' : 'later'}`;
    if (fsKey && fsKey !== 'Control' && c === fsKey) return `${codeTxt(c)} is the Freestyle key`;
    if (kind === 'adj') {
      if (adj[1 - slot] === c) return `${codeTxt(c)} is the other card-timing key`;
      const b = Object.keys(ak).find(x => ak[x] === c);
      if (b != null) return `${codeTxt(c)} is the key of "${dwName(+b)}"`;
    }
    return null;
  }
  let cap = null;                                                 // a key being set: {kind: 'start' | 'anim' | 'adj', slot}
  function renderKeys(msg) {
    const L = T.lucky(), ak = dwAnimKeys(), adj = dwAdjKeys(), rows = Array.isArray(X.anim) ? X.anim : [], cnt = {};
    for (const c of Object.values(ak)) if (c) cnt[c] = (cnt[c] || 0) + 1;
    const on = (kind, slot) => cap && cap.kind === kind && String(cap.slot) === String(slot);
    const btn = (kind, slot, code) => `<button type="button" class="keybtn${on(kind, slot) ? ' cap' : ''}" data-k="${kind}:${slot}">${on(kind, slot) ? 'press a key…' : esc(codeTxt(code))}</button>`;
    $('stStartKey').textContent = cap && cap.kind === 'start' ? 'press a key…' : keyName();
    if ($('stKeyNow')) $('stKeyNow').textContent = keyName();
    $('stStartKey').classList.toggle('cap', !!(cap && cap.kind === 'start'));
    $('stFacing').value = L.dwKeys === 'wasd' ? 'wasd' : 'arrows';
    $('stKeyTbl').innerHTML = (msg ? `<div class="small" style="color:#ef6f6f;margin:3px 0">${esc(msg)}</div>` : '') +
      `<table class="sttbl"><tr><th>animation</th><th>share of the wait</th><th>facing S / N / east</th><th>key</th><th></th></tr>` +
      rows.map(r => `<tr><td>${esc(dwName(r.b))}</td><td class="mono">${(100 * r.share).toFixed(1)}%</td><td class="mono">${Math.round(100 * r.readable)}%</td><td>${btn('anim', r.b, ak[r.b] || '')}</td>` +
        `<td class="mut">${ak[r.b] && cnt[ak[r.b]] > 1 ? 'shares its key: either animation fits it' : r.long < 0.2 ? 'mostly a flicker (under 0.5 s)' : ''}</td></tr>`).join('') +
      `<tr><td>dog cards earlier</td><td></td><td></td><td>${btn('adj', 0, adj[0])}</td><td class="mut">also: idle, cast 1 frame earlier</td></tr>` +
      `<tr><td>dog cards later</td><td></td><td></td><td>${btn('adj', 1, adj[1])}</td><td class="mut">also: idle, cast 1 frame later</td></tr></table>` +
      `<div class="small mut" style="margin-top:3px">Click a key, then press the new one. Backspace or Delete = no key for that animation · Esc = leave it. Two animations on one key become one group. ` +
      `Never assignable: ${[...new Set(Object.keys(DW_RESERVED).map(c => (/^Arrow/.test(c) ? 'arrows' : codeTxt(c))))].join(', ')}, your start key, Shift / Ctrl / Alt / Cmd, F1–F12. ` +
      `The shares are those of ${esc(X.anim_from || 'the first game file')}.</div>`;
    $('stKeyTbl').querySelectorAll('[data-k]').forEach(b => { b.onclick = () => { const [kind, slot] = b.dataset.k.split(':'); cap = { kind, slot: +slot }; b.blur(); renderKeys(); }; });
  }
  function wireKeys() {
    $('stStartKey').onclick = e => { cap = { kind: 'start', slot: 0 }; e.target.blur(); renderKeys(); };
    $('stFacing').onchange = e => { T.setLucky({ dwKeys: e.target.value }); e.target.blur(); renderAll(); };
    $('stKeyReset').onclick = () => {
      if (confirm('Put the animation keys back to the defaults (numpad, rollover R, flapper F, good-boy G, mess O, wiggle-bum B) and the card-timing keys on [ and ]?')) { cap = null; T.setLucky({ dwAnimKeys: null, dwAdjKeys: null }); renderAll(); }
    };
    document.addEventListener('keydown', e => {                    // a key being set takes the press
      if (!cap) return;
      e.preventDefault(); e.stopPropagation();
      const c = e.code || '';
      if (c === 'Escape') { cap = null; renderKeys(); return; }
      if (cap.kind === 'start') {
        if (/^(Shift|Control|Alt|Meta|OS)/.test(c)) return;
        if (['Enter', 'Escape', 'Backspace', 'Tab', 'Delete'].includes(e.key) || /^F\d+$/.test(c)) { renderKeys(`${e.key} cannot be the start key`); return; }
        cap = null; T.setLucky({ startKey: e.key }); renderAll(); return;
      }
      if (cap.kind === 'anim' && (c === 'Backspace' || c === 'Delete')) { const a = Object.assign({}, T.lucky().dwAnimKeys || {}, { [cap.slot]: '' }); cap = null; T.setLucky({ dwAnimKeys: a }); renderAll(); return; }
      if (/^(Shift|Control|Alt|Meta|OS)/.test(c)) return;
      const why = dwKeyRefused(e, cap.kind, cap.slot);
      if (why) { renderKeys(why); return; }
      const x = cap; cap = null;
      if (x.kind === 'anim') T.setLucky({ dwAnimKeys: Object.assign({}, T.lucky().dwAnimKeys || {}, { [x.slot]: c }) });
      else { const a = dwAdjKeys().slice(); a[x.slot] = c; T.setLucky({ dwAdjKeys: a }); }
      renderAll();
    }, true);
  }

  /* ================================================================ cues, the cast tap, the console */
  function renderCues() {
    const L = T.lucky(), S = T.console();
    $('stAudio').checked = !!L.audio; $('stCastTap').checked = !!L.castTap; $('stTapPrec').value = L.tapPrecMs;
    $('stUpdateMs').value = (+S.updateMs).toFixed(3);
    $('stTb').innerHTML = tbLine();
    if ($('stTbFix')) $('stTbFix').onclick = () => { T.setConsole({ updateMs: T.NTSC_UPDATE_MS }); renderAll(); };
    $('stTapMu').value = Math.round((+S.tapMuVI || 13) * vi());
  }
  function wireCues() {
    $('stAudio').onchange = e => { T.setLucky({ audio: e.target.checked }); renderAll(); };
    $('stCastTap').onchange = e => { T.setLucky({ castTap: e.target.checked }); renderAll(); };
    $('stTapPrec').onchange = e => { T.setLucky({ tapPrecMs: Math.max(5, Math.min(200, Math.round(+e.target.value || 40))) }); renderAll(); };
    $('stUpdateMs').onchange = e => { const v = +e.target.value; if (v > 30 && v < 37) T.setConsole({ updateMs: v }); renderAll(); };
    $('stTapMu').onchange = e => { const v = +e.target.value; if (v >= 0 && v <= 800) T.setConsole({ tapMuVI: v / vi() }); renderAll(); };
  }

  /* ================================================================ your data: a file */
  function wireData() {
    $('stExport').onclick = () => {
      const o = T.exportAll(), n = Object.keys(o.keys).length;
      const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(o, null, 1)], { type: 'application/json' }));
      a.download = `hm64-settings_${new Date().toISOString().slice(0, 10)}.json`; document.body.appendChild(a); a.click(); a.remove();
      $('stDataTxt').textContent = `Saved ${n} stored item${n === 1 ? '' : 's'} to ${a.download}.`;
    };
    $('stImport').onclick = () => $('stImportFile').click();
    $('stImportFile').onchange = e => {
      const f = e.target.files && e.target.files[0]; if (!f) return;
      f.text().then(t => {
        const o = JSON.parse(t), n = Object.keys(o.keys || {}).length;
        if (!confirm(`Replace ${n} stored item${n === 1 ? '' : 's'} of this browser with the ones in ${f.name} (saved ${o.at || '?'})? Everything else stays.`)) return;
        const k = T.importAll(o); $('stDataTxt').textContent = `Took in ${k} item${k === 1 ? '' : 's'} from ${f.name}.`; renderAll();
      }).catch(err => { $('stDataTxt').textContent = 'Not an HM64 settings file: ' + (err && err.message || err); });
      e.target.value = '';
    };
  }

  /* ================================================================ the page */
  function renderAll() { renderAttempts(); renderTiming(); renderPractice(); renderKeys(); renderCues(); }
  document.addEventListener('keydown', e => {
    if (cap) return;
    if (e.code === 'Escape' && D) { stopDrill(); return; }
    if (!D || !isStartKey(e)) return;
    e.preventDefault(); if (e.repeat) return;
    down(evTime(e));
  });
  document.addEventListener('keyup', e => { if (cap || !D || !isStartKey(e)) return; e.preventDefault(); up(evTime(e)); });
  T.onChange(() => renderAll());                                  // another tab (a Lucky Timer, Dog practice) changed something
  wireManual(); wirePractice(); wireKeys(); wireCues(); wireData();
  T.attempts();
  renderAll();
  root.addEventListener('resize', () => { drawCompass(); renderPractice(); });
  requestAnimationFrame(tick);
  root.HM64Settings = { renderAll, liveDots, timingRows, castStart, biteStart, stopDrill, down, up, tick, get drill() { return D; }, dwKeyRefused };
})(typeof window !== 'undefined' ? window : globalThis);
