"""Harbingers of the Dog reference (hm64_dogref_v31.js analyse(), section 2) rebuilt in Python, checked against the
app's own list, then: for each harbinger, the best blind 5-s cast band after it is seen (bite 1 or bite 2), over ALL
arrivals that show it (the named line and the few others).

usage: python3 -I harb_bands.py <dogcast.json> <lucky_routes.json> <harb_app.json>
"""
import sys, json, collections
sys.path.insert(0, "/home/claude/x/scripts")
from hm64blind import Data, band

D = Data(sys.argv[1], sys.argv[2])
app = json.load(open(sys.argv[3]))
R = D.R
VI = app["vi"]                       # 16.715 ms: the stopwatch's VI, as the Dog reference counts
LOOK_VI, HARB_UNTIL, HARB_BIN = 30, 600, 120
DIRN = ["S", "SW", "W", "NW", "N", "NE", "E", "SE"]
names = app["names"]
dwl = R["dw"]["lines"]
cands = [dict(dwi=c[0], ko=c[1], mt=c[2], w=c[3], pv=c[4]) for c in app["cands"]]
W = sum(c["w"] for c in cands)

# ---- arrive groups (pinned lines) and harbingers, exactly as the page
def show_at(dwi, k):
    for r in dwl[dwi]["vis"]:
        if r[0] <= k < r[1]:
            return r
    return None

def by_line(cs):
    m = collections.defaultdict(float)
    for c in cs:
        m[c["dwi"]] += c["w"]
    return sorted(m.items(), key=lambda x: -x[1])

G = collections.OrderedDict()
for c in cands:
    r = show_at(c["dwi"], LOOK_VI + c["ko"] - c["mt"] + 1)
    k2 = f"{r[4]}_{r[2]}" if r else "?"
    G.setdefault(k2, []).append(c)
pinned = set()
for k2, cs in G.items():
    ls = by_line(cs)
    if ls[0][1] / sum(c["w"] for c in cs) >= 0.9:
        pinned.add(ls[0][0])

H = collections.OrderedDict()
for c in cands:
    a = c["ko"] - c["mt"] + 1
    seen = set()
    for r in dwl[c["dwi"]]["vis"]:
        t = r[0] - a
        if t > HARB_UNTIL:
            break
        if t <= LOOK_VI or r[1] - r[0] < 18:
            continue
        k2 = (r[4], r[2], int(t // HARB_BIN))
        if k2 in seen:
            continue
        seen.add(k2)
        h = H.setdefault(k2, dict(base=r[4], dir=r[2], bin=int(t // HARB_BIN), w=0.0, cs=[], ts=0.0))
        h["w"] += c["w"]; h["cs"].append(c); h["ts"] += c["w"] * t
harb = []
for h in H.values():
    ls = by_line(h["cs"]); pure = ls[0][1] / h["w"]
    if pure < 0.85 or h["w"] / W < 0.004:
        continue
    harb.append(dict(h, t=h["ts"] / h["w"], share=h["w"] / W, pure=pure, dwi=ls[0][0]))
harb.sort(key=lambda x: -(x["share"] * x["pure"]))
keep, per = [], collections.Counter()
for h in harb:
    if h["dwi"] in pinned or per[h["dwi"]] >= 2:
        continue
    per[h["dwi"]] += 1; keep.append(h)
    if len(keep) >= 14:
        break
keep.sort(key=lambda x: (x["dwi"], x["t"]))

# ---- check against the app
ok = len(keep) == len(app["harb"])
for mine, a in zip(keep, app["harb"]):
    same = (mine["base"] == a["base"] and mine["dir"] == a["dir"] and mine["dwi"] == a["dwi"]
            and abs(mine["share"] - a["share"]) < 1e-4 and abs(mine["pure"] - a["pure"]) < 1e-3
            and abs(mine["t"] - a["tVI"]) < 0.05)
    ok &= same
print("harbinger list = app's:", ok, f"({len(keep)} rows)")

# ---- bands
def lname(dwi):
    li = dwl[dwi]["li"]
    return f"L{li+1}" if li >= 0 else "no table"

def variants_of(cs):
    out, nocov = [], 0.0
    for c in cs:
        li = dwl[c["dwi"]]["li"]
        if li < 0 or c["pv"] < 0:
            nocov += c["w"]; continue
        out.append((li, c["w"], c["ko"] - c["mt"] + 1, c["mt"]))
    return out, nocov

def best_band(vs, start_vi, width_vi=None, step_vi=None, end_vi=None):
    width_vi = width_vi or round(5000 / VI)          # 5 s on the stopwatch
    step_vi = step_vi or 30                          # 0.5 s steps
    end_vi = end_vi or round(76000 / VI)
    best = None
    s = start_vi + (-start_vi) % 2
    while s + width_vi <= end_vi:
        p1, p2, _ = band(D, vs, s, s + width_vi)
        for pol, p in (("1st bite", p1), ("2nd bite", p2)):
            if best is None or p > best[0]:
                best = (p, pol, s)
        s += step_vi
    return best

sec = lambda v: v * VI / 1000
allv = [(li, w, o, mt) for li, w, o, mt in D.vars]
b0 = best_band(allv, 0)
print(f"\nNO harbinger (all arrivals): best 5-s band {sec(b0[2]):.1f}-{sec(b0[2])+5:.1f} s, {b0[1]}, "
      f"{100*b0[0]:.2f}% (1 in {1/b0[0]:.0f}, {b0[0]*51:.1f}x 1/51)")

rows = []
for h, a in zip(keep, app["harb"]):
    vs, nocov = variants_of(h["cs"])
    start = int(h["t"]) + 60 + 30                    # as the page: seen + 1.5 s before a cast
    b = best_band(vs, start)
    # also: the best band with no lower limit except "after seen", restricted to before 40 s (no stay-awake push)
    b40 = best_band(vs, start, end_vi=round(40000 / VI))
    lines = by_line(h["cs"])
    tot = sum(w for _, w in lines)
    mix = ", ".join(f"{lname(d)} {100*w/tot:.0f}%" for d, w in lines[:3])
    rows.append(dict(dog=f"{names.get(str(h['base']), h['base'])} {DIRN[h['dir']]}", t=sec(h["t"]), share=h["share"],
                     line=lname(h["dwi"]), pure=h["pure"], mix=mix, nocov=nocov / h["w"],
                     band=(sec(b[2]), sec(b[2]) + 5, b[1], b[0]), band40=(sec(b40[2]), sec(b40[2]) + 5, b40[1], b40[0]),
                     app=a["cast"]))
for r in rows:
    lo, hi, pol, p = r["band"]; lo4, hi4, pol4, p4 = r["band40"]
    print(f"{r['dog']:<22} @{r['t']:4.1f}s  seen {100*r['share']:5.2f}%  {r['line']} {100*r['pure']:.0f}% [{r['mix']}]"
          f" no-table {100*r['nocov']:.1f}%\n"
          f"     best 5-s band {lo:5.1f}-{hi:5.1f} s {pol}: {100*p:5.2f}% (1 in {1/p:.0f}, {p*51:.1f}x)"
          f" | before 40 s: {lo4:4.1f}-{hi4:4.1f} s {pol4}: {100*p4:5.2f}% | app's aimed cast ±150 ms: {r['app']}")
json.dump(dict(none=b0, rows=rows), open("/home/claude/x/harb_bands.json", "w"), indent=1)
