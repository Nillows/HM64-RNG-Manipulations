"""Route-weighted blind-cast Nut rates on beach-lineup2 (and its sparrow-door table).

Blind cast = B pressed on a uniformly random game frame inside a window of cast time after READY, on a dog line drawn
by its route weight. Outcome by policy: reel in bite 1, reel in bite 2 (hold bite 1), and for reference "Nut on bite 1
or 2" / "Nut on any bite" (not blind: needs to know which bite to let go).

usage: python3 -I blind_weighted.py <dogcast.json> <lucky_routes.json>
"""
import json, sys, collections

dc = json.load(open(sys.argv[1]))
lr = json.load(open(sys.argv[2]))
S, F, X, N, O = dc["S"], dc["F"], dc["X"], dc["N"], dc["O"]
VI = 60.0  # lab labels: 60 polls = 1 s (docs' convention)


def chain(cid, kcast):
    """[(bite_label_after_READY, outcome), ...] for a cast."""
    out = []
    if cid < 0 or F[cid] < 0:
        return out
    s, t = S[cid], kcast + F[cid]
    while s >= 0:
        out.append((t, O[s]))
        if N[s] < 0:
            break
        t += N[s]
        s = X[s]
    return out


# ---- check 1: unweighted per-cast counts of the d90 casts (cid < 39,060) vs HM64_FULLDAY.md (1,253 / 990 / 172)
cnt = collections.Counter()
for cid in range(39060):
    s, i = S[cid], 1
    while s >= 0 and i <= 6:
        if O[s] == "N":
            cnt[i] += 1
        if N[s] < 0:
            break
        s, i = X[s], i + 1
print("check d90 casts, Nut by bite:", dict(sorted(cnt.items())))

routes = {r["id"]: r for r in lr["routes"]}


def check_lineframes():
    info = routes["lineup-lineup2"]["line_info"]
    tot = nut = 0
    for li in info:
        L = dc["lines"][li["key"]]
        for j, cid in enumerate(L["idx"]):
            k = L["k0"] + 2 * j
            if k > 2398:
                break
            tot += 1
            nut += any(o == "N" for _, o in chain(cid, k))
    print("check lineup2 line-frames 6..2398: any-bite Nut", nut, "of", tot, "(doc: 6,564 of 90,972)")


check_lineframes()


def weighted(route_id, windows):
    r = routes[route_id]
    info = r["line_info"]
    wsum = sum(li["w"] for li in info)
    lines = []
    for li in info:
        L = dc["lines"][li["key"]]
        fr = []
        for j, cid in enumerate(L["idx"]):
            k = L["k0"] + 2 * j
            ch = chain(cid, k)
            fr.append((k, ch))
        lines.append((li["w"] / wsum, fr))
    rows = []
    for lo, hi in windows:
        acc = collections.Counter()
        wt = 0.0
        for w, fr in lines:
            sel = [(k, ch) for k, ch in fr if lo * VI <= k < hi * VI]
            if not sel:
                continue
            wt += w
            n = len(sel)
            for k, ch in sel:
                b1 = bool(ch) and ch[0][1] == "N"
                b2 = len(ch) > 1 and ch[1][1] == "N"
                acc["b1"] += w * b1 / n
                acc["b2"] += w * b2 / n
                acc["b12"] += w * (b1 or b2) / n
                acc["any"] += w * any(o == "N" for _, o in ch) / n
                if ch:
                    acc["t1"] += w * (ch[0][0] - k) / VI / n
                    acc["n1"] += w / n
                if len(ch) > 1:
                    acc["t2"] += w * (ch[1][0] - k) / VI / n
                    acc["n2"] += w / n
                acc["has2"] += w * (len(ch) > 1) / n
        rows.append((lo, hi, wt, {k: (v / wt if wt else 0) for k, v in acc.items()},
                     acc["t1"] / acc["n1"] if acc["n1"] else 0, acc["t2"] / acc["n2"] if acc["n2"] else 0))
    return rows, wsum, len(info)


def show(route_id, windows):
    rows, wsum, nl = weighted(route_id, windows)
    print(f"\n=== {route_id}: {nl} lines, listed weight {wsum:.4f} -> normalised")
    print(f"{'cast window s':>14} {'bite1':>7} {'1 in':>5} {'x1/51':>6} {'bite2':>7} {'1 in':>5} {'x1/51':>6}"
          f" {'b1|b2':>7} {'any':>7} {'to b1 s':>8} {'to b2 s':>8} {'has b2':>7}")
    for lo, hi, wt, a, t1, t2 in rows:
        b1, b2 = a.get("b1", 0), a.get("b2", 0)
        print(f"{lo:>6.0f}-{hi:<6.0f} {100*b1:6.2f}% {1/b1 if b1 else 0:5.0f} {b1*51:6.2f} {100*b2:6.2f}%"
              f" {1/b2 if b2 else 0:5.0f} {b2*51:6.2f} {100*a.get('b12',0):6.2f}% {100*a.get('any',0):6.2f}%"
              f" {t1:8.1f} {t2:8.1f} {100*a.get('has2',0):6.1f}%")


wins = [(0, 5), (5, 10), (10, 15), (15, 20), (20, 25), (25, 30), (30, 35), (35, 40), (40, 45), (45, 50), (50, 55),
        (55, 60), (60, 65), (65, 70), (70, 75), (75, 80),
        (0, 30), (0, 40), (40, 60), (0, 60), (0, 75)]
show("lineup-lineup2", wins)
show("lineup-lineup2-sparrow-door", [(0, 40), (40, 60), (0, 60), (0, 75)])
