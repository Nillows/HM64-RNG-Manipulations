"""Close-up of blind casts 60-65 s after READY on beach-lineup2: which cast frames give the Nut on bite 1 (green) or
bite 2 (gold), per dog line (row height = route share), plus the route-weighted share per frame on top.

usage: python3 -I closeup_6065.py <dogcast.json> <lucky_routes.json> <out.png> [lo_s hi_s]
"""
import json, sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

dc = json.load(open(sys.argv[1]))
lr = json.load(open(sys.argv[2]))
out = sys.argv[3]
lo_s, hi_s = (float(sys.argv[4]), float(sys.argv[5])) if len(sys.argv) > 5 else (60.0, 65.0)
S, F, X, N, O = dc["S"], dc["F"], dc["X"], dc["N"], dc["O"]
route = next(r for r in lr["routes"] if r["id"] == "lineup-lineup2")
info = route["line_info"]
wsum = sum(li["w"] for li in info)

BG, PANEL, INK, MUT, GRID = "#0d1720", "#13222f", "#dce6ec", "#8ea3b2", "#24384a"
GREEN, GOLD = "#5fd38d", "#e7c14a"

k_lo, k_hi = int(round(lo_s * 60)), int(round(hi_s * 60))
frames = list(range(k_lo, k_hi, 2))
nf = len(frames)


def bites(cid, k):
    if cid < 0 or F[cid] < 0:
        return []
    s, out_ = S[cid], []
    while s >= 0 and len(out_) < 2:
        out_.append(O[s])
        if N[s] < 0:
            break
        s = X[s]
    return out_


rows = []  # (w, [code per frame]) code 0 none, 1 Nut bite 1, 2 Nut bite 2
for li in info:
    L = dc["lines"][li["key"]]
    codes = []
    for k in frames:
        j = (k - L["k0"]) // 2
        b = bites(L["idx"][j], k)
        codes.append(1 if b[:1] == ["N"] else 2 if b[1:2] == ["N"] else 0)
    rows.append((li["w"] / wsum, codes))

share1 = np.array([sum(w for w, c in rows if c[i] == 1) for i in range(nf)])
share2 = np.array([sum(w for w, c in rows if c[i] == 2) for i in range(nf)])
m1, m2 = share1.mean(), share2.mean()
print(f"frames {nf}, bite-1 Nut share {100*m1:.2f}%, bite-2 {100*m2:.2f}%, frames with any bite-1 Nut line:"
      f" {int((share1 > 0).sum())}, max frame {100*share1.max():.1f}%")

plt.rcParams.update({"font.family": "DejaVu Sans", "text.color": INK, "axes.labelcolor": MUT,
                     "xtick.color": MUT, "ytick.color": MUT})
fig = plt.figure(figsize=(16, 10), dpi=110, facecolor=BG)
gs = fig.add_gridspec(2, 1, height_ratios=[1, 2.4], hspace=0.08, left=0.085, right=0.94, top=0.86, bottom=0.075)
ax1, ax2 = fig.add_subplot(gs[0]), fig.add_subplot(gs[1])
for ax in (ax1, ax2):
    ax.set_facecolor(PANEL)
    for sp in ax.spines.values():
        sp.set_visible(False)

x = np.arange(nf)
xs = lo_s + x * 2 / 60.0
# top: route-weighted share of arrivals whose cast on this frame lands the Nut on bite 1
ax1.bar(xs, 100 * share1, width=2 / 60 * 0.72, color=GREEN, align="edge", linewidth=0)
ax1.axhline(100 / 51, color=MUT, lw=1.2, ls=(0, (4, 3)))
ax1.text(1.004, 100 / 51 - 0.3, "1/51 1.96%", color=MUT, ha="left", va="top", fontsize=9.5, transform=ax1.get_yaxis_transform())
ax1.axhline(100 * m1, color=INK, lw=1.2)
ax1.text(1.004, 100 * m1 + 0.3, f"avg {100*m1:.2f}%", color=INK, ha="left", va="bottom", fontsize=9.5,
         fontweight="bold", transform=ax1.get_yaxis_transform())
ax1.set_xlim(lo_s, hi_s)
ax1.set_ylim(0, max(100 * share1.max() * 1.12, 10))
ax1.set_ylabel("share of routes\nwith a bite-1 Nut (%)", fontsize=11)
ax1.tick_params(axis="x", labelbottom=False, length=0)
ax1.tick_params(axis="y", length=0, labelsize=10)
ax1.grid(axis="y", color=GRID, lw=0.8)
ax1.set_axisbelow(True)

# bottom: one row per dog line, height = route share, one column per game frame
y = 0.0
fw = 2 / 60.0
labels = []
for i, (w, codes) in enumerate(rows):
    for f, c in enumerate(codes):
        if c:
            ax2.add_patch(Rectangle((lo_s + f * fw + fw * 0.08, y * 100), fw * 0.84, w * 100,
                                    facecolor=GREEN if c == 1 else GOLD, edgecolor="none",
                                    hatch=None if c == 1 else "////"))
    if w >= 0.025:
        labels.append(((y + w / 2) * 100, f"L{i+1}  {100*w:.1f}%"))
    y += w
    if w >= 0.01:
        ax2.axhline(y * 100, color=BG, lw=0.6)
rest = [i for i, (w, _) in enumerate(rows) if w < 0.025]
if rest:
    y0 = sum(w for w, _ in rows[:rest[0]])
    yr = sum(rows[i][0] for i in rest)
    labels.append(((y0 + yr / 2) * 100, f"L{rest[0]+1}–L{len(rows)}  {100*yr:.1f}%"))
ax2.set_xlim(lo_s, hi_s)
ax2.set_ylim(100, 0)
ax2.set_yticks([p for p, _ in labels])
ax2.set_yticklabels([t for _, t in labels], fontsize=9.5)
ax2.tick_params(axis="y", length=0)
ax2.set_xticks(np.arange(lo_s, hi_s + 0.001, 0.5))
ax2.set_xticklabels([f"{v:.1f}" for v in np.arange(lo_s, hi_s + 0.001, 0.5)], fontsize=10)
ax2.tick_params(axis="x", length=0)
for v in np.arange(lo_s, hi_s + 0.001, 1.0):
    ax2.axvline(v, color=GRID, lw=0.8, zorder=0)
    ax1.axvline(v, color=GRID, lw=0.8, zorder=0)
ax2.set_xlabel("cast time after READY (s) · one column per game frame", fontsize=11)
ax2.text(-0.075, 0.5, "dog lines, heaviest at the top\n(row height = share of routes)", transform=ax2.transAxes,
         rotation=90, ha="center", va="center", color=MUT, fontsize=11)

fig.text(0.085, 0.955, f"Blind casts {lo_s:.0f}–{hi_s:.0f} s after READY · reel in bite 1", fontsize=19,
         fontweight="bold", color=INK, ha="left")
fig.text(0.085, 0.915, f"beach-lineup2 · 76 dog lines weighted by route · {nf} game frames · Nut on bite 1 "
         f"{100*m1:.2f}% (≈ 1 in {1/m1:.0f}, {m1*51:.1f}× 1/51) · on bite 2 {100*m2:.2f}%",
         fontsize=12, color=MUT, ha="left")
# legend (identity never colour-alone: labelled swatches)
lx = 0.985
fig.patches.append(Rectangle((lx - 0.255, 0.952), 0.012, 0.018, transform=fig.transFigure, facecolor=GREEN))
fig.text(lx - 0.239, 0.961, "Nut on bite 1", fontsize=11.5, color=INK, va="center")
fig.patches.append(Rectangle((lx - 0.135, 0.952), 0.012, 0.018, transform=fig.transFigure, facecolor=GOLD,
                             hatch="////", edgecolor=PANEL))
fig.text(lx - 0.119, 0.961, "Nut on bite 2", fontsize=11.5, color=INK, va="center")
fig.savefig(out, facecolor=BG)
print("saved", out)
