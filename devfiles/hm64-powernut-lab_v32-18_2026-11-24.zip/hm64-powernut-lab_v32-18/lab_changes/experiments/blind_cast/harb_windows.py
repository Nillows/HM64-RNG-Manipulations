"""Best 1 / 2 / 3 / 4 / 5-s blind windows per Dog-reference harbinger (and with no harbinger), lineup2.
Per-frame route-weighted Nut share over the arrivals showing the harbinger (READY offsets applied), then the best
window mean per width, bite 1 or bite 2. Windows start >= 1.5 s after the harbinger is seen; stopwatch VI 16.715 ms.

usage: python3 -I harb_windows.py <dogcast.json> <lucky_routes.json> <harb_app.json>
"""
import sys, json, collections
import numpy as np
sys.path.insert(0, "/home/claude/x/scripts")
from hm64blind import Data

D = Data(sys.argv[1], sys.argv[2])
app = json.load(open(sys.argv[3]))
VI = app["vi"]
dwl = D.R["dw"]["lines"]
DIRN = ["S", "SW", "W", "NW", "N", "NE", "E", "SE"]
names = app["names"]
EMAX = round(76000 / VI)                                    # elapsed VIs since READY scanned (Nut ends at 75 s)
E = np.arange(0, EMAX + 2, 2)                                # one entry per game frame (even elapsed VIs)


def shares(variants):
    """per game frame: weighted share of arrivals whose cast there gives the Nut on bite 1 / bite 2"""
    s1, s2 = np.zeros(len(E)), np.zeros(len(E))
    wt = 0.0
    for li, w, o, mt in variants:
        f1 = np.zeros(len(E)); f2 = np.zeros(len(E))
        for i, e in enumerate(E):
            if e + 1 < mt:
                continue
            lab = e + o; lab -= lab % 2
            a, b = D.nut_flags(li, lab)
            f1[i], f2[i] = a, b
        s1 += w * f1; s2 += w * f2; wt += w
    return s1 / wt, s2 / wt


def best(s1, s2, start_vi, width_s):
    n = max(1, round(width_s * 1000 / VI / 2))              # game frames in the window
    i0 = int(np.searchsorted(E, start_vi))
    out = None
    for pol, s in (("1st", s1), ("2nd", s2)):
        c = np.concatenate([[0.0], np.cumsum(s)])
        m = (c[n:] - c[:-n]) / n                             # mean over frames i .. i+n-1, window starting at i
        m[:i0] = -1
        i = int(np.argmax(m))
        if out is None or m[i] > out[0]:
            out = (float(m[i]), pol, E[i] * VI / 1000, (E[i] + 2 * n) * VI / 1000, n)
    return out


cands = [dict(dwi=c[0], ko=c[1], mt=c[2], w=c[3], pv=c[4]) for c in app["cands"]]
# arrivals showing each harbinger: same grouping as the page (2-s bins, seen 0.5-10 s, >= 18 VIs on screen)
groups = collections.defaultdict(list)
for c in cands:
    a = c["ko"] - c["mt"] + 1
    seen = set()
    for r in dwl[c["dwi"]]["vis"]:
        t = r[0] - a
        if t > 600:
            break
        if t <= 30 or r[1] - r[0] < 18:
            continue
        k = (r[4], r[2], int(t // 120))
        if k not in seen:
            seen.add(k); groups[k].append(c)

WID = [1, 2, 3, 4, 5]
res = {"vi": VI, "widths": WID, "rows": []}
allv = list(D.vars)
s1, s2 = shares(allv)
row = {"dog": "none", "line": "all arrivals", "t": 0.0, "share": 1.0, "best": [best(s1, s2, 0, w) for w in WID]}
res["rows"].append(row)
for h in app["harb"]:
    k = (h["base"], h["dir"], int(h["tVI"] // 120))
    cs = groups[k]
    vs = []
    for c in cs:
        li = dwl[c["dwi"]]["li"]
        if li >= 0 and c["pv"] >= 0:
            vs.append((li, c["w"], c["ko"] - c["mt"] + 1, c["mt"]))
    s1, s2 = shares(vs)
    start = int(h["tVI"]) + 90
    res["rows"].append({"dog": f"{h['name']} {DIRN[h['dir']]}", "line": h["line"], "t": h["t"], "share": h["share"],
                        "best": [best(s1, s2, start, w) for w in WID]})
for r in res["rows"]:
    print(f"{r['dog']:<20} {r['line']:<12} seen {r['t']:4.1f} s ({100*r['share']:.1f}%)")
    for w, b in zip(WID, r["best"]):
        p, pol, lo, hi, n = b
        print(f"   {w} s ({n:3d} frames): {lo:5.2f}-{hi:5.2f} s  {pol} bite  {100*p:5.1f}%  1 in {1/p:4.1f}  {p*51:4.1f}x 1/51")
json.dump(res, open("/home/claude/x/harb_windows.json", "w"), indent=1)
