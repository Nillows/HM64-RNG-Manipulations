"""v31.30 patch of webapp/hm64_dogref_v31.js (Thomas 2026-11-23): casts past 40 s from the cast pack, harbinger casts
over every arrival that shows the harbinger, and the "Optimal Blind Casting" tab.
Exact-string replacements, each anchor must occur exactly once (fails loudly otherwise).

usage: python3 -I patch_blind.py <path to hm64_dogref_v31.js>
"""
import sys

p = sys.argv[1]
s = open(p, encoding="utf8").read()


def rep(old, new):
    global s
    n = s.count(old)
    assert n == 1, f"anchor found {n} times: {old[:90]!r}"
    s = s.replace(old, new)


# ---- 1. settings: the new tab first, opened once for everyone
rep("let S = { route: null, sig: 150, delay: 150, tab: 'lines',",
    "let S = { route: null, sig: 150, delay: 150, tab: 'blind',")
rep("const TABS = [['lines', 'First 10 seconds, by line'], ['arrive', 'As you stop'], ['harb', 'Harbingers']];   // v31.1: tabs; the line page first",
    "const TABS = [['blind', 'Optimal Blind Casting'], ['lines', 'First 10 seconds, by line'], ['arrive', 'As you stop'], ['harb', 'Harbingers']];   // v31.1: tabs; v31.30: Optimal Blind Casting first")
rep("if (S.qv !== 2) { S.quick = 10; S.qv = 2; }                       // v31.10: the floor Thomas asked for (\"fastest nut above 10%\") is the default",
    "if (S.qv !== 2) { S.quick = 10; S.qv = 2; }                       // v31.10: the floor Thomas asked for (\"fastest nut above 10%\") is the default\n"
    "  if (S.bv !== 1) { S.tab = 'blind'; S.bv = 1; }                   // v31.30: everyone lands once on the new Optimal Blind Casting tab")

# ---- 2. the cast pack: flags, shares, windows, aimed casts
rep("  const lineName = (R, dwi) => { const li = R.dw.lines[dwi].li; return li >= 0 ? 'L' + (li + 1) : 'no table'; };\n",
    """  const lineName = (R, dwi) => { const li = R.dw.lines[dwi].li; return li >= 0 ? 'L' + (li + 1) : 'no table'; };

  /* ---------------------------------------------------------------- v31.30: casts past 40 s, Optimal Blind Casting
     (Thomas 2026-11-23). The cast tables behind the odds of this page (LuckyCore) end 40 s after Jack stops; the cast
     pack D.dogcast (the Lucky Timer's dog-after-the-cast data) holds every cast frame of every dog line to 120 s with
     its bites, so every aimed cast (0-75 s) and the blind windows are read from there. A plan variant = a dog line + its READY
     offset o: a cast t stopwatch VIs after the stop (t = 1 at the stop) lands on pack label t - 1 + o (as dcBites in
     the Lucky Timer). Odds = shares of the route-weighted arrivals, as everywhere on this page. Checked against an
     independent script on 2026-11-23 (claude/HM64_BLIND_CAST_2026-11-23.md). */
  const DC = DATA.dogcast || null;
  const END_S = 76, WAKE_S = 33.4, NAP_S = 39.4, BLIND_S = 1;
  // END_S: the Nut ends 75 s after the stop; WAKE_S / NAP_S: Jack
  // lies down 40 s after the stop unless the stick is pushed (the Lucky Timer's wake line at 33.4 s; the lab pushes on
  // casts later than 39.4 s); BLIND_S: the width of a blind window (B anywhere in it)
  const flagCache = new Map();
  function flagsOf(key) {                                       // per pack label / 2: Nut on bite 1 / on bite 2 (bite 1 held)
    if (flagCache.has(key)) return flagCache.get(key);
    const ln = DC && DC.lines[key];
    let f = null;
    if (ln) {
      const n = ln.k0 / 2 + ln.idx.length, b1 = new Uint8Array(n), b2 = new Uint8Array(n);
      ln.idx.forEach((cid, j) => {
        if (cid < 0 || DC.F[cid] < 0) return;
        const st = DC.S[cid], i = ln.k0 / 2 + j;
        if (st < 0) return;
        if (DC.O[st] === 'N') b1[i] = 1;
        if (DC.N[st] >= 0 && DC.X[st] >= 0 && DC.O[DC.X[st]] === 'N') b2[i] = 1;
      });
      f = { b1, b2 };
    }
    flagCache.set(key, f);
    return f;
  }
  /* per game frame i after the stop (elapsed VI 2i): the weighted share of the arrivals whose cast there gives the
     Nut on bite 1 (s1) / on bite 2 (s2); vars = [{ key, o, w }] */
  function shares(vars) {
    const nF = Math.floor(END_S * 1000 / VI() / 2) + 1, s1 = new Float64Array(nF), s2 = new Float64Array(nF);
    let W = 0, Wd = 0;
    for (const v of vars) {
      W += v.w;
      const f = flagsOf(v.key); if (!f) continue;
      Wd += v.w;
      for (let i = 0; i < nF; i++) {
        let lab = 2 * i + v.o; lab -= ((lab % 2) + 2) % 2;
        const j = lab / 2;
        if (j < 0 || j >= f.b1.length) continue;
        if (f.b1[j]) s1[i] += v.w;
        if (f.b2[j]) s2[i] += v.w;
      }
    }
    if (Wd > 0) for (let i = 0; i < nF; i++) { s1[i] /= Wd; s2[i] /= Wd; }
    return { s1, s2, cover: W > 0 ? Wd / W : 0 };
  }
  const POL2 = [['bite1', 's1'], ['hold', 's2']];
  /* the best window of BLIND_S seconds starting at elapsed VI >= fromVI: B pressed anywhere in it, one rule */
  function bestWindow(sh, fromVI) {
    const n = Math.max(1, Math.round(BLIND_S * 1000 / VI() / 2)), i0 = Math.max(0, Math.ceil(fromVI / 2));
    let b = null;
    for (const [pol, k] of POL2) {
      const a = sh[k]; let sum = 0;
      for (let i = 0; i < a.length; i++) {
        sum += a[i]; if (i >= n) sum -= a[i - n];
        const st = i - n + 1;
        if (st < i0) continue;
        if (!b || sum / n > b.p + 1e-12) b = { pol, p: sum / n, st, n };
      }
    }
    return b && b.p > 0 ? { pol: b.pol, p: b.p, t: 2 * b.st + b.n + 1, lo: 2 * b.st + 1, hi: 2 * (b.st + b.n) + 1 } : null;
  }
  /* per game frame: P(Nut) of a cast aimed there, the B press off by a bell curve of sd sigVI (as LuckyCore's smoothing) */
  function aimedCurves(sh, sigVI) {
    const sd = Math.max(0.25, sigVI / 2), r = Math.ceil(3 * sd), g = new Float64Array(2 * r + 1);
    let z = 0;
    for (let d = -r; d <= r; d++) { g[d + r] = Math.exp(-0.5 * (d / sd) ** 2); z += g[d + r]; }
    const out = {};
    for (const [pol, k] of POL2) {
      const a = sh[k], P = new Float64Array(a.length);
      for (let i = 0; i < a.length; i++) {
        let q = 0;
        for (let d = -r; d <= r; d++) { const j = i + d; if (j >= 0 && j < a.length) q += g[d + r] * a[j]; }
        P[i] = q / z;
      }
      out[pol] = P;
    }
    return out;
  }
  /* v31.30: a row's casts from the cast pack - the best cast per rule over 0-75 s, the quick cast, and the by-the-clock
     rule (LuckyCore's zone policy, inside its 40-s tables). The 40-s tables leave out, at each moment, the arrivals
     whose line has no table there (e.g. 6% of the L4 flapper-SW arrivals at 5.8 s: 17.4% shown, 16.4% over all of
     them); the pack has every line at every frame. Times are stopwatch VIs (t = 2i + 1 for game frame i after the stop). */
  function evalPack(Q, sigVI, tMin, floor) {
    const sh = shares(packVars(Q)); if (!(sh.cover > 0)) return null;
    const cv = aimedCurves(sh, sigVI), i0 = Math.max(0, Math.ceil((tMin - 1) / 2)), o = {};
    for (const [pol] of POL2) {
      const P = cv[pol]; let b = -1;
      for (let i = i0; i < P.length; i++) if (b < 0 || P[i] > P[b] + 1e-12) b = i;
      if (b >= 0 && P[b] > 0) o[pol] = { t: 2 * b + 1, p: P[b] };
    }
    const simple = !o.hold || (o.bite1 && o.bite1.p >= o.hold.p) ? 'bite1' : 'hold';
    o.simple = o[simple] ? simple : (o.hold ? 'hold' : null);
    if (!o.simple) return null;
    o.late = isLate(o[o.simple].t);
    try {                                                         // by the clock: inside the 40-s tables only
      const g = C.goal; let b;
      try { C.setGoal(null); b = C.best(Q, sigVI, tMin); } finally { C.setGoal(g || null); }
      if (b && b.zone && b.zone.p > 0) {
        const z = C.zoneAt(Q, b.zone.t, sigVI, sigVI, true);
        o.zone = { t: b.zone.t, p: b.zone.p, zones: z && z.zones ? z.zones.filter(w => w[1] > b.zone.t).slice(0, 4) : [] };
      }
    } catch (e) { /* no clock rule */ }
    /* the QUICK cast (v31.8 rule): the first moment one of the two rules reaches `floor`, at the top of that rise
       (at most 1.5 s on), kept when it comes at least 1 s before the best cast */
    if (floor > 0) {
      const end = (o[o.simple].t - 61) / 2;
      let q = null;
      for (const [pol] of POL2) {
        if (!o[pol]) continue;
        const P = cv[pol];
        for (let i = i0; i < end; i++) {
          if (!(P[i] >= floor)) continue;
          let u = i; while (u + 1 < end && u - i < 45 && P[u + 1] >= P[u]) u++;
          if (!q || i < q.i0 || (i === q.i0 && P[u] > q.p)) q = { t: 2 * u + 1, p: P[u], pol, i0: i };
          break;
        }
      }
      o.quick = q;
    }
    return o;
  }
  function packVars(Q) {                                         // a plan's variants as pack lines (series -> dog line key)
    const R = Q.refR; if (!R || !R.dw) return [];
    let m = R._sKey;
    if (!m) { m = R._sKey = new Map(); (R.sidxs || []).forEach((sx, li) => { const dwi = R.dw.of_line[li]; if (dwi != null && dwi >= 0) m.set(sx, R.dw.lines[dwi].key); }); }
    return Q.variants.filter(x => x.w > 0 && m.has(x.s)).map(x => ({ key: m.get(x.s), o: x.o, w: x.w }));
  }
  const candVars = (R, cs) => cs.map(c => ({ key: R.dw.lines[c.dwi].key, o: c.ko - c.mt + 1, w: c.w }));
  const isLate = t => secs(t) > NAP_S;
  const WAKE2_S = 2 * WAKE_S, NAP2_S = WAKE_S + NAP_S;          // a cast after ~72.8 s needs a 2nd push (the wake line at 66.9 s)
  const pushWhen = t => (secs(t) > NAP2_S ? `at about ${WAKE_S.toFixed(0)} s and again at about ${WAKE2_S.toFixed(0)} s` : `once at about ${WAKE_S.toFixed(0)} s`);
  const PUSH_TXT = `Cast after 40 s: push the stick ↘ once at about ${WAKE_S.toFixed(0)} s (and again at about ${WAKE2_S.toFixed(0)} s for a cast after ${NAP2_S.toFixed(0)} s), or Jack lies down (never push after casting).`;
""")

# ---- 3. plans carry their route, so a plan's variants can be read in the pack
rep("return vars.length ? Object.assign({}, X.plan, { variants: vars, k: 'ref' + (++uid), maxBite: 0 }) : null;",
    "return vars.length ? Object.assign({}, X.plan, { variants: vars, k: 'ref' + (++uid), maxBite: 0, refR: X.R }) : null;")

# ---- 4. evalPlan: every aimed cast from the cast pack (0-75 s); the 40-s tables only for the by-the-clock rule
a = s.index("  function evalPlan(Q, sigVI, tMin, floor) {\n")
b = s.index("    return o.simple ? o : null;\n  }\n", a) + len("    return o.simple ? o : null;\n  }\n")
assert s.count("  function evalPlan(Q, sigVI, tMin, floor) {\n") == 1
s = s[:a] + """  function evalPlan(Q, sigVI, tMin, floor) {
    if (!Q) return null;
    tMin = Math.max(1, Math.round(tMin));
    if (DC && Q.refR) return evalPack(Q, sigVI, tMin, floor);     // v31.30: the cast pack, 0-75 s
""" + s[a + len("  function evalPlan(Q, sigVI, tMin, floor) {\n"):].replace("    if (!Q) return null;\n    tMin = Math.max(1, Math.round(tMin));\n", "", 1)

# ---- 5. harbingers: the cast over every arrival that shows it (not only its line's); keep the set for the blind tab
rep("harb.push({ base: h.base, dir: h.dir, t: h.ts / h.w, share: h.w / W, pure, line: lineName(R, ls[0][0]), dwi: ls[0][0], cs: h.cs.filter(c => c.dwi === ls[0][0]), cast: null });",
    "harb.push({ base: h.base, dir: h.dir, bin: h.bin, t: h.ts / h.w, share: h.w / W, pure, line: lineName(R, ls[0][0]), dwi: ls[0][0], cs: h.cs, all: h.cs, cast: null });   // v31.30: cs = every arrival showing it (was: its line's only)")
rep("    keep.sort((a, b) => a.dwi - b.dwi || a.t - b.t);\n",
    """    keep.sort((a, b) => a.dwi - b.dwi || a.t - b.t);
    /* v31.30: Optimal Blind Casting - per harbinger the best 1-s window to cast in (B anywhere in it), over every
       arrival that shows it; one behaviour of one line in neighbouring 2-s bins is one row; then "none of these by
       10 s" (the arrivals showing none of them) and "not watching the dog" (all arrivals). */
    const brows = [];
    for (const h of keep) {
      const m = brows.find(b => b.base === h.base && b.dir === h.dir && b.dwi === h.dwi && b.bins.some(x => Math.abs(x - h.bin) === 1));
      if (m) {
        const have = new Set(m.cs);
        for (const c of h.all) if (!have.has(c)) m.cs.push(c);
        m.bins.push(h.bin); m.tMax = Math.max(m.tMax, h.t); m.tw += h.t * h.share; m.sw += h.share;
      } else brows.push({ base: h.base, dir: h.dir, dwi: h.dwi, line: h.line, bins: [h.bin], cs: h.all.slice(), tMax: h.t, tw: h.t * h.share, sw: h.share });
    }
    const seenAny = new Set();
    for (const b of brows) { b.t = b.tw / b.sw; b.share = b.cs.reduce((q, c) => q + c.w, 0) / W; b.win = null; for (const c of b.cs) seenAny.add(c); }
    const gW = new Map(); for (const r of brows) gW.set(r.dwi, Math.max(gW.get(r.dwi) || 0, r.share));   // rows: the line whose sign is seen most first, then by when it shows
    brows.sort((a, b) => gW.get(b.dwi) - gW.get(a.dwi) || a.dwi - b.dwi || a.t - b.t);
    out.blind = { rows: brows, none: { cs: cands.filter(c => !seenAny.has(c)), win: null }, all: { win: null } };
    out.blind.none.share = out.blind.none.cs.reduce((q, c) => q + c.w, 0) / W;
    for (const b of brows) tasks.push(() => { b.win = bestWindow(shares(candVars(R, b.cs)), Math.floor(b.tMax) + MIN_CAST_AFTER_LOOK + 30); delete b.cs; });
    tasks.push(() => { const B = out.blind.none; B.win = bestWindow(shares(candVars(R, B.cs)), HARB_UNTIL + MIN_CAST_AFTER_LOOK + 30); delete B.cs; });
    tasks.push(() => { out.blind.all.win = bestWindow(shares(candVars(R, cands)), 0); });
""")
rep("tasks.push(() => { h.cast = evalPlan(subPlan(X, pvsOf(h.cs)), sigVI, Math.round(h.t) + MIN_CAST_AFTER_LOOK + 30, floor); delete h.cs; });",
    "tasks.push(() => { h.cast = evalPlan(subPlan(X, pvsOf(h.cs)), sigVI, Math.round(h.t) + MIN_CAST_AFTER_LOOK + 30, floor); delete h.cs; delete h.all; });")

# ---- 6. a cast after 40 s says so
rep("    let h = qMain ? quick + best : best + quick;\n",
    "    let h = qMain ? quick + best : best + quick;\n"
    "    if (isLate(s.t) && !qMain) h += `<div class=\"rfclock\">Cast after 40 s: push the stick ↘ ${pushWhen(s.t)}, or Jack lies down (never push after casting).</div>`;   // v31.30\n")

# ---- 7. the Optimal Blind Casting pane
rep("    const P = { lines: h, arrive: pArrive, harb: pHarb };",
    """    const pLines = h;
    /* v31.30 (Thomas 2026-11-23: "simple and direct. If you see x at y cast at z for odds%") */
    const one = p => (p > 0 ? `1 in ${1 / p < 10 ? (1 / p).toFixed(1) : Math.round(1 / p)}` : '');
    const bwin = (w, id, lab) => (!w ? '<span class="mut">…</span>' : `<button class="rfcast main" data-t="${w.t}" data-id="${id}" title="Show this cast on the stopwatch">${fx(secs(w.t), 1)} s</button> <span class="mut">(${fx(secs(w.lo), 1)}–${fx(secs(w.hi), 1)})</span>`);
    const bodds = w => (!w ? '' : `<b>${pct(w.p)}</b> <span class="mut">${one(w.p)}</span>`);
    const BL = o.blind || { rows: [], none: {}, all: {} };
    const sx = v => String(Math.round(v * 10) / 10);
    const between = r => `${sx(Math.max(LOOK_VI, Math.min(...r.bins) * HARB_BIN) * VI() / 1000)}–${sx(Math.min(HARB_UNTIL, (Math.max(...r.bins) + 1) * HARB_BIN) * VI() / 1000)} s`;
    const pushTag = w => (w && isLate(w.t) ? `<div class="rfclock">+ push the stick ↘ ${pushWhen(w.t)}</div>` : '');
    h = `<h3>Optimal Blind Casting</h3>
      <div class="mut">Press <kbd>Space</kbd> the moment Jack stops at the end of the pier and watch the dog for 10 s. If it starts one of these, cast at the time shown — anywhere in that second — and let go of B as the row says. Click a row to put its cast on the stopwatch.</div>
      <table class="rftab rfblind"><tr><th></th><th>if the dog starts</th><th>between</th><th>cast at</th><th>let go of B</th><th>Power Nut</th></tr>` +
      BL.rows.map((r, i) => `<tr><td>${dog(r.base, r.dir)}</td><td>${what(r.base, r.dir)}</td><td class="num">${between(r)}</td><td>${bwin(r.win, 'b' + i)}${pushTag(r.win)}</td><td>${r.win ? POLTXT[r.win.pol] : ''}</td><td class="num">${bodds(r.win)}</td></tr>`).join('') +
      `<tr><td></td><td><b>none of these</b></td><td class="num">by 10 s</td><td>${bwin(BL.none.win, 'bn')}${pushTag(BL.none.win)}</td><td>${BL.none.win ? POLTXT[BL.none.win.pol] : ''}</td><td class="num">${bodds(BL.none.win)}</td></tr></table>` +
      (BL.all.win ? `<div class="mut">Not watching the dog at all: cast at <b>${fx(secs(BL.all.win.t), 1)} s</b> (${fx(secs(BL.all.win.lo), 1)}–${fx(secs(BL.all.win.hi), 1)}), ${POLTXT[BL.all.win.pol]}: <b>${pct(BL.all.win.p)}</b> (${one(BL.all.win.p)}).</div>` : '') +
      `<div class="mut">Every time counts from the moment Jack stops. ${PUSH_TXT} The odds are the share of the lab's arrivals on this table that show what the row says and land the Power Nut with B pressed anywhere in that second (1/51 = 2% for comparison). The same harbingers, with a cast aimed to a fraction of a second, are on the Harbingers tab.</div>`;
    const pBlind = h;
    h = pLines;
    const P = { blind: pBlind, lines: h, arrive: pArrive, harb: pHarb };""")

# ---- 8. the stopwatch: the push reminder for a cast after 40 s
rep("    $('rfBar').style.width = tg && run ? Math.max(0, Math.min(100, 100 * s / tg)) + '%' : '0%';",
    """    if (tg !== null && tg > NAP_S) {                              // v31.30: the stay-awake push(es) for a cast after 40 s
      const two = tg > NAP2_S, near = x => run && s >= x - 1 && s < x + 2.5 && left > 0;
      $('rfTarget').innerHTML += near(WAKE_S) || (two && near(WAKE2_S)) ? ' — <b style="color:#ff9a6a">PUSH THE STICK ↘ NOW</b>'
        : `<br><span class="mut">Push the stick ↘ ${two ? `at about ${WAKE_S.toFixed(0)} s and again at about ${WAKE2_S.toFixed(0)} s` : `once at about ${WAKE_S.toFixed(0)} s`}, or Jack lies down.</span>`;
    }
    $('rfBar').style.width = tg && run ? Math.max(0, Math.min(100, 100 * s / tg)) + '%' : '0%';""")

# ---- 9. How it works
rep("<p><b>Dog reference.</b> A manual method: no keys to log, nothing learned, nothing stored but three settings. Three tabs. <i>First 10 seconds, by line</i> (the first page):",
    "<p><b>Dog reference.</b> A manual method: no keys to log, nothing learned, nothing stored but three settings. Four tabs. <i>Optimal Blind Casting</i> (the first page): if the dog does one of the listed things in the first 10 s after Jack stops, cast at the time shown — anywhere in that second — and let go at the bite it says; the odds are those of a cast anywhere in that second. <i>First 10 seconds, by line</i>:")
rep("A cast comes with its rule — let go at the 1st bite, or hold it and let go at the 2nd — and, where it is worth 2 points or more, a rule by the clock:",
    "Casts reach 75 s after Jack stops (the Power Nut ends there); a cast after 40 s needs one push of the stick ↘ at about 33 s (a cast after 73 s a second one at about 67 s), or Jack lies down. A cast comes with its rule — let go at the 1st bite, or hold it and let go at the 2nd — and, where it is worth 2 points or more, a rule by the clock:")

open(p, "w", encoding="utf8").write(s)
print("patched", p)
