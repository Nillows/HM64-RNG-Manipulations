"""Independent check of the v31.30 Dog reference numbers (Optimal Blind Casting rows, harbinger / line / 'all' casts)
against the cast pack, written without the app's code. Candidates (dog line, READY offset, weight) come from the page
(ui_harbdump.js output); everything else from dogcast.json / lucky_routes.json.

usage: python3 -I verify_v3130.py <dogcast.json> <lucky_routes.json> <harb_app.json> <blind_app30.json>
"""
import sys, json, collections
import numpy as np

dc = json.load(open(sys.argv[1])); lr = json.load(open(sys.argv[2]))
app = json.load(open(sys.argv[3])); got = json.load(open(sys.argv[4]))["main"]
R = next(r for r in lr["routes"] if r["id"] == "lineup-lineup2")
VI = app["vi"]; dwl = R["dw"]["lines"]
S, F, X, N, O = dc["S"], dc["F"], dc["X"], dc["N"], dc["O"]
nF = int(76 * 1000 / VI / 2) + 1

def flags(key):
    ln = dc["lines"][key]; n = ln["k0"] // 2 + len(ln["idx"])
    b1 = np.zeros(n); b2 = np.zeros(n)
    for j, cid in enumerate(ln["idx"]):
        if cid < 0 or F[cid] < 0 or S[cid] < 0: continue
        s = S[cid]; i = ln["k0"] // 2 + j
        b1[i] = O[s] == "N"
        b2[i] = N[s] >= 0 and X[s] >= 0 and O[X[s]] == "N"
    return b1, b2
FL = {}
def shares(vs):                      # vs: [(key, o, w)]
    s1 = np.zeros(nF); s2 = np.zeros(nF); W = 0
    for key, o, w in vs:
        if key not in FL: FL[key] = flags(key)
        b1, b2 = FL[key]; W += w
        lab = 2 * np.arange(nF) + o; lab -= lab % 2; j = lab // 2
        ok = (j >= 0) & (j < len(b1))
        s1[ok] += w * b1[j[ok]]; s2[ok] += w * b2[j[ok]]
    return s1 / W, s2 / W

def window(s1, s2, from_vi, n=None):
    n = n or max(1, round(1000 / VI / 2)); i0 = int(np.ceil(from_vi / 2)); best = None
    for pol, s in (("bite1", s1), ("hold", s2)):
        c = np.concatenate([[0], np.cumsum(s)]); m = (c[n:] - c[:-n]) / n
        for st in range(i0, len(m)):
            if best is None or m[st] > best[1] + 1e-12: best = (pol, m[st], st)
    pol, p, st = best
    return dict(pol=pol, p=p, t=(2 * st + n) * VI / 1000, lo=2 * st * VI / 1000, hi=2 * (st + n) * VI / 1000)

def aimed(s1, s2, t_min, sig_ms=150):
    sd = max(0.25, sig_ms / VI / 2); r = int(np.ceil(3 * sd)); d = np.arange(-r, r + 1); g = np.exp(-0.5 * (d / sd) ** 2); g /= g.sum()
    i0 = int(np.ceil((t_min - 1) / 2)); best = None
    for pol, s in (("bite1", s1), ("hold", s2)):
        P = np.convolve(s, g, mode="same")
        i = i0 + int(np.argmax(P[i0:]))
        if best is None or P[i] > best[1] + 1e-12: best = (pol, P[i], i)
    return dict(rule=best[0], p=best[1], at=2 * best[2] * VI / 1000)

cands = [dict(dwi=c[0], ko=c[1], mt=c[2], w=c[3], pv=c[4], i=k) for k, c in enumerate(app["cands"])]
key = lambda c: dwl[c["dwi"]]["key"]; off = lambda c: c["ko"] - c["mt"] + 1
allv = lambda cs: [(key(c), off(c), c["w"]) for c in cs]
tabv = lambda cs: [(key(c), off(c), c["w"]) for c in cs if c["pv"] >= 0]

# harbinger groups (as the page)
groups = collections.defaultdict(list)
for c in cands:
    a = off(c); seen = set()
    for r in dwl[c["dwi"]]["vis"]:
        t = r[0] - a
        if t > 600: break
        if t <= 30 or r[1] - r[0] < 18: continue
        k = (r[4], r[2], int(t // 120))
        if k not in seen: seen.add(k); groups[k].append(c)

bad = 0
def cmp(label, mine, theirs, keys, tol):
    global bad
    ok = all((mine[k] == theirs[k]) if isinstance(mine[k], str) else abs(mine[k] - theirs[k]) <= tol[k] for k in keys)
    bad += not ok
    print(("OK  " if ok else "DIFF"), label, {k: (round(mine[k], 4) if not isinstance(mine[k], str) else mine[k]) for k in keys},
          "" if ok else {k: theirs[k] for k in keys})

TOLW = dict(pol=0, p=2e-5, t=2e-3, lo=2e-3, hi=2e-3)
TOLA = dict(rule=0, p=1e-4, at=2e-3)
# harbinger casts (aimed, all arrivals with tables) and the blind rows
seen_any = set()
for h in got["harb"]:
    hh = next(x for x in app["harb"] if x["name"] == h["name"] and x["dir"] is not None and abs(x["t"] - h["t"]) < 0.02)
    cs = groups[(hh["base"], hh["dir"], int(hh["tVI"] // 120))]
    s1, s2 = shares(tabv(cs))
    cmp(f"harb cast {h['name']} {h['line']}", aimed(s1, s2, round(hh["tVI"]) + 90), h["cast"], ["rule", "p", "at"], TOLA)
for b in got["blind"]:
    hs = [x for x in app["harb"] if x["name"] == b["name"] and x["dwi"] == b["dwi"] and int(x["tVI"] // 120) in b["bins"]]
    cs = {}
    for x in hs:
        for c in groups[(x["base"], x["dir"], int(x["tVI"] // 120))]: cs[c["i"]] = c
    cs = list(cs.values()); seen_any.update(c["i"] for c in cs)
    s1, s2 = shares(allv(cs))
    cmp(f"blind {b['name']} {b['line']} bins {b['bins']}", window(s1, s2, int(max(x["tVI"] for x in hs)) + 90), b["win"], ["pol", "p", "t", "lo", "hi"], TOLW)
none = [c for c in cands if c["i"] not in seen_any]
s1, s2 = shares(allv(none))
print("none share", round(sum(c["w"] for c in none) / sum(c["w"] for c in cands), 5), "app", got["none"]["share"])
cmp("blind none of these", window(s1, s2, 600 + 90), got["none"]["win"], ["pol", "p", "t", "lo", "hi"], TOLW)
s1, s2 = shares(allv(cands))
cmp("blind not watching", window(s1, s2, 0), got["notWatching"], ["pol", "p", "t", "lo", "hi"], TOLW)
s1, s2 = shares(tabv(cands))
cmp("cast 'cannot tell the dog'", aimed(s1, s2, 90), got["all"], ["rule", "p", "at"], TOLA)
# line casts (the line's own arrivals)
for L in got["lines"]:
    li = int(L["name"][1:]) - 1; dwi = R["dw"]["of_line"][li]
    cs = [c for c in cands if c["dwi"] == dwi]
    s1, s2 = shares(tabv(cs))
    cmp(f"line cast {L['name']}", aimed(s1, s2, 90), L["cast"], ["rule", "p", "at"], TOLA)
print("\nDIFFERENCES:", bad)
