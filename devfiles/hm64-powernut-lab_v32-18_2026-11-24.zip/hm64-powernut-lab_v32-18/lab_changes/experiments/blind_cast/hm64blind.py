"""Shared helpers: blind-cast odds on a Lucky Timer route with the plan's READY offsets.

A plan variant (li, w, o, mt) of group 'all', anchor 'pier' = dog line li reached with its READY o VIs after the line's
label 0 (the app: cast-pack label = VIs since the player's READY + o; hm64_lucky_v29.js dcBites / v31.13 note).
"""
import json


class Data:
    def __init__(self, dogcast, routes, route_id="lineup-lineup2", group="all", anchor="pier"):
        self.dc = json.load(open(dogcast))
        lr = json.load(open(routes))
        self.R = next(r for r in lr["routes"] if r["id"] == route_id)
        g = next(x for x in self.R["groups"] if x["id"] == group)
        self.vars = [tuple(v) for v in g["v"][anchor]]            # (li, w, o, mt)
        self.vu = [tuple(v) for v in g.get("vu", {}).get(anchor, [])]   # (dwi, w, o, mt): lines without cast tables
        self.info = self.R["line_info"]
        self.cover = g.get("cover")
        dc = self.dc
        self.S, self.F, self.X, self.N, self.O = dc["S"], dc["F"], dc["X"], dc["N"], dc["O"]
        self._chain = {}

    def chain(self, li, label):
        """bites [(label, outcome)] of a cast at pack label `label` (even) on line li, up to 3 bites"""
        key = (li, label)
        if key in self._chain:
            return self._chain[key]
        L = self.dc["lines"].get(self.info[li]["key"])
        out = []
        if L is not None:
            j = (label - L["k0"]) // 2
            if 0 <= j < len(L["idx"]):
                cid = L["idx"][j]
                if cid >= 0 and self.F[cid] >= 0:
                    s, t = self.S[cid], label + self.F[cid]
                    while s >= 0 and len(out) < 3:
                        out.append((t, self.O[s]))
                        if self.N[s] < 0:
                            break
                        t += self.N[s]
                        s = self.X[s]
        self._chain[key] = out
        return out

    def nut_flags(self, li, label):
        ch = self.chain(li, label)
        return (len(ch) > 0 and ch[0][1] == "N", len(ch) > 1 and ch[1][1] == "N")


def band(D, variants, lo_vi, hi_vi):
    """route-weighted P(Nut) for B pressed on a uniformly random game frame with elapsed VIs since READY in
    [lo_vi, hi_vi); variants = [(li, w, o, mt)]. Returns (p_bite1, p_bite2, weight used)."""
    num1 = num2 = wt = 0.0
    for li, w, o, mt in variants:
        frames = [e for e in range(lo_vi - (lo_vi % 2), hi_vi, 2) if e >= lo_vi and e + 1 >= mt]
        if not frames:
            continue
        n1 = n2 = 0
        for e in frames:
            lab = e + o
            lab -= lab % 2
            a, b = D.nut_flags(li, lab)
            n1 += a
            n2 += b
        num1 += w * n1 / len(frames)
        num2 += w * n2 / len(frames)
        wt += w
    return (num1 / wt if wt else 0.0, num2 / wt if wt else 0.0, wt)
