#!/bin/bash
# uitest.sh <app.html> <tests/ui_x.js> [budget ms] [pre.js: runs before the app, e.g. to seed localStorage]  -> the test's JSON
set -e
H="$1"; T="$2"; B="${3:-90000}"; PRE="${4:-}"; O="/tmp/ui_$(basename "$T" .js)_$$.html"; U="/tmp/chrome_prof_$$"
python3 - "$H" "$T" "$O" "$PRE" <<'PY'
import sys
h=open(sys.argv[1],encoding="utf8").read(); t=open(sys.argv[2],encoding="utf8").read()
if sys.argv[4]:
    pre=open(sys.argv[4],encoding="utf8").read(); i=h.find("<script>"); h=h[:i]+"<script>"+pre+"</script>"+h[i:]
i=h.rfind("</body>"); open(sys.argv[3],"w",encoding="utf8").write(h[:i]+"<script>"+t.replace("</","<\\/")+"</script>"+h[i:])
PY
timeout 420 google-chrome --headless=new --no-sandbox --disable-gpu --user-data-dir="$U" --virtual-time-budget=$B --dump-dom "file://$O" 2>/dev/null | python3 -c "
import sys,re,html
d=sys.stdin.read(); m=re.search(r'<pre id=\"testout\">(.*?)</pre>',d,re.S)
print(html.unescape(m.group(1)) if m else 'NO TEST OUTPUT (%d bytes of DOM)'%len(d))"
