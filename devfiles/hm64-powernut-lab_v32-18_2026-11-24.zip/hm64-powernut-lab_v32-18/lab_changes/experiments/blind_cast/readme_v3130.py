"""README v31.30: the 'Optimal Blind Casting' section, generated from the app's own numbers (ui_blinddump.js output),
plus the small edits elsewhere. Formats mirror hm64_dogref_v31.js (pct, 1 in n, the 'between' ranges).

usage: python3 -I readme_v3130.py <README v31.29> <blind_app30.json> <out README>
"""
import sys, json, math

src, dump, dst = sys.argv[1:4]
s = open(src, encoding="utf8").read()
o = json.load(open(dump)); m = o["main"]
VI = 16.715
DIRW = {0: "↓ down", 1: "↙ down-left", 2: "← left", 3: "↖ up-left", 4: "↑ up", 5: "↗ up-right", 6: "→ right", 7: "↘ down-right"}


def pct(p):                                   # as the page: one decimal under 9.95 %, else none
    return f"{100 * p:.1f}%" if p < 0.0995 else f"{100 * p:.0f}%"


def one(p):
    return f"1 in {1 / p:.1f}" if 1 / p < 10 else f"1 in {round(1 / p)}"


def sx(v):                                    # String(Math.round(v * 10) / 10)
    r = math.floor(v * 10 + 0.5) / 10
    return str(int(r)) if r == int(r) else str(r)


def between(bins):
    lo = max(30, min(bins) * 120) * VI / 1000
    hi = min(600, (max(bins) + 1) * 120) * VI / 1000
    return f"{sx(lo)}–{sx(hi)} s"


def rule(pol):
    return "let go at the 1st bite" if pol == "bite1" else "hold the 1st bite, let go at the 2nd"


def late(w):
    return w["t"] > 39.4


lines = []
for r in m["blind"]:
    w = r["win"]
    push = " · push ↘ at 33 s" if late(w) else ""
    lines.append(f"- If you see **{r['name']}** facing **{DIRW[r['dir']]}** at **{between(r['bins'])}**, cast at **{w['t']:.1f} s** "
                 f"for **{pct(w['p'])}** ({one(w['p'])}) — {rule(w['pol'])}{push}.")
    # the same row in the page (DOM text) must carry the same numbers
    dom = next((x for x in o["dom"]["rows"] if x.startswith(f"{r['name']} ") and between(r['bins']).replace(' s', '') in x
                and f"{w['t']:.1f} s" in x), None)
    assert dom and pct(w["p"]) in dom and one(w["p"]) in dom, (r["name"], dom)
w = m["none"]["win"]
lines.append(f"- If you see **none of these** by 10 s, cast at **{w['t']:.1f} s** for **{pct(w['p'])}** ({one(w['p'])}) — "
             f"{rule(w['pol'])}{' · push ↘ at 33 s' if late(w) else ''}.")
w = m["notWatching"]
lines.append(f"- Not watching the dog at all: cast at **{w['t']:.1f} s** for **{pct(w['p'])}** ({one(w['p'])}) — "
             f"{rule(w['pol'])}{' · push ↘ at 33 s' if late(w) else ''}.")

section = """## Optimal Blind Casting
No live tool needed, only a stopwatch and your eyes. Start the stopwatch the moment Jack stops at the end of the pier
(where you would tap Space, section 3.5) and watch the dog for 10 seconds. If it starts one of these, press **B at the
time shown — anywhere within half a second of it** — and let go of B as the line says.

""" + "\n".join(lines) + """

**Push ↘ at 33 s:** a cast after 40 s needs one push of the stick **down-right** at about 33 s, or Jack lies down at
40 s (section 3.6). Never push after you have cast. **Hold the 1st bite, let go at the 2nd** = keep B held through the
first bite and let go when the second one comes.

The odds are the share of the lab's arrivals on this route (the file in section 2, no sparrows at the door) that show
the sign and land the Power Nut with B pressed anywhere in that second; 1 in 51 (2%) is the game's base chance per
catch. Emulator data. With **sparrows at the door** (section 3.2) the dog lines are different: use the app's list with the
Sparrows box ticked.

<img src="media/app_blind.png" width="700" alt="The Optimal Blind Casting tab of the Dog reference">

<sub><b>The same list in the app</b>: the first tab of the <b>Dog reference</b> (footer). Space starts its stopwatch when
Jack stops; click a row and it counts down to that cast. The Harbingers tab has the same signs with a cast aimed to a
fraction of a second.</sub>

---

"""


def rep(old, new):
    global s
    n = s.count(old)
    assert n == 1, (n, old[:80])
    s = s.replace(old, new)


rep("# HM64 Power Nut Tool v31.29\n", "# HM64 Power Nut Tool v31.30\n")
rep("## Contents\n", "## Contents\n**Only want a stopwatch? Start with [Optimal Blind Casting](#optimal-blind-casting).**\n\n")
rep("   controller; the keyboard is only for the tool.\n\n---\n\n## 2. Setting up the game file",
    "   controller; the keyboard is only for the tool.\n\nNo tool at all? [Optimal Blind Casting](#optimal-blind-casting) "
    "below tells you, from what the dog does in the first 10 s, when to cast.\n\n---\n\n" + section + "## 2. Setting up the game file")
rep("The **Lucky Timer** tab (footer) is the tool. The **Dog reference** tab is a printable manual method (section 10).",
    "The **Lucky Timer** tab (footer) is the tool. The **Dog reference** tab is a printable manual method; its first tab is\n"
    "[Optimal Blind Casting](#optimal-blind-casting) (more in section 10).")
rep("""A manual method for when the live tool is not wanted: what the dog is doing as Jack stops at the end of the pier →
which line you are likely on → how long to wait before casting (best-odds and quick casts per behaviour), the
"harbinger" behaviours that give a line away, and a simple Space stopwatch (Space when Jack stops, Esc to stop; click
a cast time in the tables to count down to it). Tabs: **First 10 seconds, by line** · **As you stop** · **Harbingers**.""",
    """A manual method for when the live tool is not wanted: what the dog is doing as Jack stops at the end of the pier →
which line you are likely on → how long to wait before casting (best-odds and quick casts per behaviour), the
"harbinger" behaviours that give a line away, and a simple Space stopwatch (Space when Jack stops, Esc to stop; click
a cast time in the tables to count down to it). Tabs: **Optimal Blind Casting** (the list above, first) · **First 10
seconds, by line** · **As you stop** · **Harbingers**. Casts reach 75 s after Jack stops (the Power Nut ends there); a
cast after 40 s says so and needs the push ↘ at about 33 s (a cast after 73 s a second one at about 67 s); the
stopwatch shows PUSH THE STICK ↘ NOW at those moments.""")
rep("<sub><b>The Dog reference tab</b>, the manual method, on its first tab.</sub>",
    "<sub><b>The Dog reference tab</b>, the manual method, on its first tab (Optimal Blind Casting).</sub>")
assert "v31.29" not in s, "a v31.29 mention is left"
open(dst, "w", encoding="utf8").write(s)
print("\n".join(lines))
print("written", dst)
