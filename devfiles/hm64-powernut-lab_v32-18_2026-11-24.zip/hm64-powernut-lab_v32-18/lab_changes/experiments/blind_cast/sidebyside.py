"""Side by side: blind casts in two 5-s windows on beach-lineup2. Per game frame, Nut on bite 1 (green) / bite 2
(gold, hatched), per dog line (row height = route share) and route-weighted share per frame on top (stacked).

usage: python3 -I sidebyside.py <dogcast.json> <lucky_routes.json> <out.png> <loA> <hiA> <loB> <hiB>
"""
import json, sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

dc = json.load(open(sys.argv[1]))
lr = json.load(open(sys.argv[2]))
out = sys.argv[3]
wins = [(float(sys.argv[4]), float(sys.argv[5])), (float(sys.argv[6]), float(sys.argv[7]))]
S, F, X, N, O = dc["S"], dc["F"], dc["X"], dc["N"], dc["O"]
route = next(r for r in lr["routes"] if r["id"] == "lineup-lineup2")
info = route["line_info"]
wsum = sum(li["w"] for li in info)
W = [li["w"] / wsum for li in info]

BG, PANEL, INK, MUT, GRID = "#0d1720", "#13222f", "#dce6ec", "#8ea3b2", "#24384a"
GREEN, GOLD = "#5fd38d", "#e7c14a"
FW = 2 / 60.0


def code(cid):
    if cid < 0 or F[cid] < 0:
        return 0
    s = S[cid]
    if O[s] == "N":
        return 1
    if N[s] >= 0 and O[X[s]] == "N":
        return 2
    return 0


def window(lo, hi):
    frames = list(range(int(round(lo * 60)), int(round(hi * 60)), 2))
    rows = []
    for li in info:
        L = dc["lines"][li["key"]]
        rows.append([code(L["idx"][(k - L["k0"]) // 2]) for k in frames])
    s1 = np.array([sum(W[i] for i, c in enumerate(rows) if c[f] == 1) for f in range(len(frames))])
    s2 = np.array([sum(W[i] for i, c in enumerate(rows) if c[f] == 2) for f in range(len(frames))])
    return frames, rows, s1, s2


data = [window(*w) for w in wins]
ymax = max(100 * (d[2] + d[3]).max() for d in data) * 1.1

plt.rcParams.update({"font.family": "DejaVu Sans", "text.color": INK, "axes.labelcolor": MUT,
                     "xtick.color": MUT, "ytick.color": MUT})
fig = plt.figure(figsize=(22, 11), dpi=100, facecolor=BG)
gs = fig.add_gridspec(2, 2, height_ratios=[1, 2.4], hspace=0.07, wspace=0.05, left=0.075, right=0.99,
                      top=0.84, bottom=0.07)
for col, ((lo, hi), (frames, rows, s1, s2)) in enumerate(zip(wins, data)):
    ax1, ax2 = fig.add_subplot(gs[0, col]), fig.add_subplot(gs[1, col])
    for ax in (ax1, ax2):
        ax.set_facecolor(PANEL)
        for sp in ax.spines.values():
            sp.set_visible(False)
    xs = lo + np.arange(len(frames)) * FW
    ax1.bar(xs, 100 * s1, width=FW * 0.72, color=GREEN, align="edge", linewidth=0)
    ax1.bar(xs, 100 * s2, bottom=100 * s1, width=FW * 0.72, color=GOLD, align="edge", linewidth=0, hatch="////",
            edgecolor=PANEL)
    ax1.axhline(100 / 51, color=MUT, lw=1.2, ls=(0, (4, 3)))
    ax1.set_xlim(lo, hi)
    ax1.set_ylim(0, ymax)
    ax1.grid(axis="y", color=GRID, lw=0.8)
    ax1.set_axisbelow(True)
    ax1.tick_params(axis="x", labelbottom=False, length=0)
    ax1.tick_params(axis="y", length=0, labelsize=10, labelleft=(col == 0))
    if col == 0:
        ax1.set_ylabel("share of routes\nwith a Nut (%)", fontsize=11)
        ax1.text(lo + 0.03, 100 / 51 + 0.5, "1/51 = 1.96%", color=MUT, fontsize=10, va="bottom",
                 bbox=dict(facecolor=PANEL, edgecolor="none", pad=1))
    m1, m2 = s1.mean(), s2.mean()
    print(f"{lo}-{hi}: bite1 {100*m1:.2f}% bite2 {100*m2:.2f}%")
    head = f"Casts {lo:.0f}–{hi:.0f} s after READY"
    fig.text(ax1.get_position().x0, 0.895, head, fontsize=16, fontweight="bold", color=INK, ha="left")
    sub = (f"reel in bite 1: {100*m1:.2f}%" + (f" (1 in {1/m1:.0f}, {m1*51:.1f}× 1/51)" if m1 else "") +
           f"   ·   reel in bite 2: {100*m2:.2f}%" + (f" (1 in {1/m2:.0f}, {m2*51:.1f}×)" if m2 >= 0.005 else ""))
    fig.text(ax1.get_position().x0, 0.862, sub, fontsize=12, color=MUT, ha="left")

    y = 0.0
    labels = []
    for i, codes in enumerate(rows):
        w = W[i]
        for f, c in enumerate(codes):
            if c:
                ax2.add_patch(Rectangle((lo + f * FW + FW * 0.08, y * 100), FW * 0.84, w * 100,
                                        facecolor=GREEN if c == 1 else GOLD, edgecolor=PANEL if c == 2 else "none",
                                        linewidth=0, hatch=None if c == 1 else "////"))
        if w >= 0.025:
            labels.append(((y + w / 2) * 100, f"L{i+1}  {100*w:.1f}%"))
        y += w
        if w >= 0.01:
            ax2.axhline(y * 100, color=BG, lw=0.6)
    rest = [i for i, w in enumerate(W) if w < 0.025]
    y0, yr = sum(W[:rest[0]]), sum(W[i] for i in rest)
    labels.append(((y0 + yr / 2) * 100, f"L{rest[0]+1}–L{len(W)}  {100*yr:.1f}%"))
    ax2.set_xlim(lo, hi)
    ax2.set_ylim(100, 0)
    ax2.set_yticks([p for p, _ in labels])
    ax2.set_yticklabels([t for _, t in labels] if col == 0 else [], fontsize=9.5)
    ax2.tick_params(length=0)
    ticks = np.arange(lo, hi + 0.001, 0.5)
    ax2.set_xticks(ticks)
    ax2.set_xticklabels([f"{v:.1f}" for v in ticks], fontsize=10)
    for v in np.arange(lo, hi + 0.001, 1.0):
        ax1.axvline(v, color=GRID, lw=0.8, zorder=0)
        ax2.axvline(v, color=GRID, lw=0.8, zorder=0)
    ax2.set_xlabel("cast time after READY (s) · one column per game frame", fontsize=11)

fig.text(0.075, 0.955, "Blind casts with the dog drawing · beach-lineup2, 76 dog lines weighted by route",
         fontsize=19, fontweight="bold", color=INK, ha="left")
fig.text(0.012, 0.40, "dog lines, heaviest at the top (row height = share of routes)", rotation=90, ha="center",
         va="center", color=MUT, fontsize=11)
lx = 0.99
fig.patches.append(Rectangle((lx - 0.205, 0.951), 0.01, 0.02, transform=fig.transFigure, facecolor=GREEN))
fig.text(lx - 0.191, 0.961, "Nut on bite 1", fontsize=12, color=INK, va="center")
fig.patches.append(Rectangle((lx - 0.105, 0.951), 0.01, 0.02, transform=fig.transFigure, facecolor=GOLD,
                             hatch="////", edgecolor=PANEL))
fig.text(lx - 0.091, 0.961, "Nut on bite 2", fontsize=12, color=INK, va="center")
fig.savefig(out, facecolor=BG)
print("saved", out)
