/* headless: LuckyCore's curve vs a plain Gaussian over the cast pack, same plan (the L4 flapper-SW-3.1 s arrivals) */
(function () { const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => { const C = window.HM64Lucky, R = window.HM64DogRef, A = window.HM64LuckyApp, $ = id => document.getElementById(id), out = { errors: [] };
    try {
      $('arOracle').click(); await sleep(200);
      const X = R.ctx('lineup-lineup2'), vi = A.viMs(), sigVI = 150 / vi;
      // the flapper SW group in bin 1 (2.0-4.0 s), as analyse(): trace runs >= 18 VIs, seen 30..600 VIs after the stop
      const cs = [];
      for (const c of X.cands) { const a = c.ko - c.mt + 1; for (const r of X.R.dw.lines[c.dwi].vis) { const t = r[0] - a; if (t > 600) break; if (t <= 30 || r[1] - r[0] < 18) continue; if (r[4] === 88 && r[2] === 1 && Math.floor(t / 120) === 1) { cs.push(c); break; } } }
      const pvs = new Set(cs.filter(c => c.pv >= 0).map(c => c.pv));
      const vars = []; X.plan.variants.forEach((x, pv) => { if (pvs.has(pv) && x.w > 0) vars.push(x); });
      const Q = Object.assign({}, X.plan, { variants: vars, k: 'cmp1', maxBite: 0 });
      const P = C.curve(Q, sigVI, 'bite1').P, Cv = C.curve(Q, sigVI, 'bite1').C;
      out.n = cs.length; out.vars = vars.length; out.W = vars.reduce((q, x) => q + x.w, 0);
      out.lucky = []; for (let t = 330; t <= 360; t += 1) out.lucky.push([t, +(P[t] || 0).toFixed(4), +(Cv[t] || 0).toFixed(4)]);
      // raw (unsmoothed) per-frame share from the LuckyCore series, and how many variants have data at t
      const ser = Q.series;
      out.raw = []; for (let t = 340; t <= 350; t++) { let num = 0, den = 0, nd = 0; for (const x of vars) { const s = ser[x.s], i = t + x.o - s.v0; if (i < 0 || i >= s.len) { nd++; continue; } if (s.n1[i] < 0) continue; num += x.w * s.n1[i]; den += x.w; } out.raw.push([t, den ? +(num / den).toFixed(4) : null, +den.toFixed(4), nd]); }
      out.v0 = [...new Set(vars.map(x => ser[x.s].v0))]; out.os = vars.map(x => x.o).slice(0, 30);
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, 1500);
})();
