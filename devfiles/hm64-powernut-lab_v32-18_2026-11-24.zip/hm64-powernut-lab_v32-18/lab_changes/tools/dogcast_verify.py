"""Check a dog-after-the-cast pack against every raw cast row it was made from (2026-11-23).

  python3 -I tools/dogcast_verify.py PACK.json RESULTS_DIR [RESULTS_DIR ...]

For every cast in every FD_casts_b*.jsonl: the pack's bite chain from that cast frame (bite label = cast label + F, then
+ N per held bite; catch O) must equal the row's bites (label and catch) over their common length. A row whose cast
frame the pack has no cast for, or whose chain differs, is counted and the first few are printed. Exit 1 on any.
"""
import glob, json, os, sys


def main():
    pack = json.load(open(sys.argv[1]))
    ok = bad = missing = rows = 0
    ex = []
    for res in sys.argv[2:]:
        for fn in sorted(glob.glob(os.path.join(res, "FD_casts_b*.jsonl"))):
            for line in open(fn):
                r = json.loads(line)
                ln = pack["lines"].get(r["key"])
                for c in r.get("casts", []):
                    rows += 1                     # every row, also those without a hash check ("ok" false = no Z7 twin)
                    i = (c["k"] - ln["k0"]) // 2 if ln else -1
                    cid = ln["idx"][i] if ln and 0 <= i < len(ln["idx"]) else -1
                    if cid < 0:
                        missing += 1
                        if len(ex) < 8: ex.append(("missing", os.path.basename(res), r["key"][:8], c["k"]))
                        continue
                    f, st, got = pack["F"][cid], pack["S"][cid], []
                    lab = c["k"] + f
                    while f >= 0 and st >= 0 and len(got) < 60:
                        got.append((lab, pack["O"][st]))
                        if pack["N"][st] < 0:
                            break
                        lab += pack["N"][st]; st = pack["X"][st]
                    want = [(b[0], b[1][0]) for b in c["b"]]
                    n = min(len(got), len(want))
                    if got[:n] == want[:n] and (len(want) == 0 or n > 0):
                        ok += 1
                    else:
                        bad += 1
                        if len(ex) < 8: ex.append(("differs", os.path.basename(res), r["key"][:8], c["k"], got[:3], want[:3]))
    print(f"{rows} cast rows: {ok} equal to the pack, {bad} differ, {missing} not in the pack")
    for e in ex:
        print("  ", e)
    sys.exit(0 if bad == 0 and missing == 0 else 1)


if __name__ == "__main__":
    main()
