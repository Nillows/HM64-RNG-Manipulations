"""Cross-save twin dog lines (v32.18, 2026-11-24: "are horse runs even necessary?").

Line i of game file A and line m of game file B are twins with shift d (VIs) when A's dog trace (dw vis runs, every
table of the file's routes json) at label k equals B's at k + d from `trace join` on. For each twin pair the cast frames
after the join are compared in the two cast packs: bites 1-2 (time - d and catch) and every bite within 60 s.

  python3 -I tools/cross_twins.py ROUTES_A PACK_A ROUTES_B PACK_B [--json out.json]

Prints: A's weight with a twin in B (from READY / by 10 s / by 20 s), the agreement of twin casts, the shifts by weight,
and the heaviest 25 lines of A. Results 2026-11-24 (HM64_RAIN_2026-11-23.md): sunny horse vs no horse 99.7% twins, shift
not constant (0 for 52% of the weight, then +22, +6, +30 ...), bites 1-2 agree 98.7%; rainy horse vs no horse 93.7%, shift
0 for 85%, 96.7%."""
import json, sys, collections, bisect
import numpy as np

def lines_of(rp):
    R = json.load(open(rp))["routes"]
    out = {}
    for r in R:
        dw = r.get("dw")
        if not dw: continue
        for L in dw["lines"]:
            o = out.setdefault(L["key"], {"key": L["key"], "w": 0.0, "vis": L["vis"]})
            o["w"] += L["w"]
    tot = sum(o["w"] for o in out.values())
    for o in out.values(): o["w"] /= tot
    return out

def trace(vis, n):
    a = np.full(n, -1, dtype=np.int32)
    for k0, k1, f, c, b in vis:
        a[max(0, k0):min(n - 1, k1) + 1] = b * 8 + f
    return a

def chains(P, key, cap=40):
    ln = P["lines"].get(key)
    out = {}
    if not ln: return out
    for j, c in enumerate(ln["idx"]):
        if c < 0: continue
        k = ln["k0"] + 2 * j
        st, lab, ch = P["S"][c], k + P["F"][c], []
        if P["F"][c] < 0: out[k] = (); continue
        while st >= 0 and len(ch) < cap:
            ch.append((lab, P["O"][st]))
            if P["N"][st] < 0: break
            lab += P["N"][st]; st = P["X"][st]
        out[k] = tuple(ch)
    return out

def same_chain(a, b, d, lim):
    n = min(len(a), len(b))
    for i in range(n):
        if a[i][0] + d != b[i][0] or a[i][1] != b[i][1]: return False
    longer = a if len(a) > len(b) else b
    return all(x[0] > lim for x in longer[n:])

def runs(t):
    """change points of a trace: [(label, code)]"""
    idx = np.nonzero(np.diff(t))[0] + 1
    return [(0, int(t[0]))] + [(int(i), int(t[i])) for i in idx]

def main():
    rA, pA, rB, pB = sys.argv[1:5]
    A, B = lines_of(rA), lines_of(rB)
    PA, PB = json.load(open(pA)), json.load(open(pB))
    n = min(max(v["vis"][-1][1] for v in A.values()), max(v["vis"][-1][1] for v in B.values())) + 2
    lim = min(PA.get("until", 5398), PB.get("until", 5398)) - 420
    TA = {k: trace(v["vis"], n) for k, v in A.items()}; TB = {k: trace(v["vis"], n) for k, v in B.items()}
    # suffix index of B: the last 6 change points (codes + gaps) of each trace before n - 400
    def sig(t, end):
        rr = [x for x in runs(t[:end]) if x[0] > 0]
        if len(rr) < 7: return None, None
        last = rr[-7:]
        return tuple((last[i][1], last[i + 1][0] - last[i][0]) for i in range(6)), last[0][0]
    CA = {k: chains(PA, k) for k in A}; CB = {k: chains(PB, k) for k in B}
    res = []
    for ka in sorted(A, key=lambda k: -A[k]["w"]):
        ta = TA[ka]; best = None
        for kb in B:
            tb = TB[kb]
            for d in range(-600, 601, 2):
                lo, hi = max(1800, 1800 - d), min(n, n - d) - 2
                if hi - lo < 1500: continue
                if not np.array_equal(ta[lo:hi], tb[lo + d:hi + d]) or (ta[lo:hi] < 0).all(): continue
                k0 = max(0, -d)
                diff = np.nonzero(ta[k0:hi] != tb[k0 + d:hi + d])[0]
                join = int(diff[-1]) + k0 + 1 if len(diff) else k0
                ca, cb = CA[ka], CB[kb]
                ks = [k for k in ca if (k + d) in cb]
                bad = [k for k in ks if k >= join and not same_chain(ca[k], cb[k + d], d, lim)]
                agree_all = sum(1 for k in ks if same_chain(ca[k], cb[k + d], d, lim))
                cjoin = max(bad) + 2 if bad else join
                kj = [k for k in ks if k >= join]
                b12 = sum(1 for k in kj if ca[k][:2] == tuple((x - d, o) for x, o in cb[k + d][:2]))
                w60 = lambda c, k, dd=0: tuple((x - dd, o) for x, o in c if x - dd < k + 3590)
                b60 = sum(1 for k in kj if w60(ca[k], k) == w60(cb[k + d], k, d))
                cand = (join, abs(d), -b12, kb, d, join, len(ks), agree_all, len(bad), len(kj), b12, b60, cjoin)
                if best is None or cand < best: best = cand
                break
        if best:
            _, _, _, kb, d, join, nks, agree, nbad, nkj, b12, b60, cjoin = best
            res.append({"a": ka, "wa": A[ka]["w"], "b": kb, "wb": B[kb]["w"], "d": d, "trace_join": join, "join": cjoin,
                        "casts": nks, "agree": agree, "bad_after_trace_join": nbad, "kj": nkj, "b12": b12, "b60": b60})
        else:
            res.append({"a": ka, "wa": A[ka]["w"], "b": None})
    W = lambda f: sum(r["wa"] for r in res if f(r))
    print(f"A {rA.split('/')[-1]}: {len(A)} lines; B {rB.split('/')[-1]}: {len(B)} lines; traces to {n} VIs, chains compared to {lim}")
    tw_ = [r for r in res if r["b"]]
    print(f"A weight with a twin in B (same dog trace, shifted, from some moment on): {W(lambda r: r['b'] is not None):.4f}; "
          f"the same dog from READY (trace join <= 10 VIs): {W(lambda r: r['b'] and r['trace_join'] <= 10):.4f}; by 10 s: "
          f"{W(lambda r: r['b'] and r['trace_join'] <= 598):.4f}; by 20 s: {W(lambda r: r['b'] and r['trace_join'] <= 1196):.4f}")
    sw = sum(r["wa"] for r in tw_) or 1
    print(f"twins, cast frames after the trace join, A-weighted: bites 1-2 (time + catch) agree {sum(r['wa'] * r['b12'] / max(1, r['kj']) for r in tw_) / sw:.4f}; "
          f"every bite within 60 s of the cast agrees {sum(r['wa'] * r['b60'] / max(1, r['kj']) for r in tw_) / sw:.4f}")
    ds = collections.Counter(); 
    for r in res:
        if r["b"]: ds[r["d"]] += r["wa"]
    print("shift d (VIs) by A weight:", ", ".join(f"{d:+d}: {w:.3f}" for d, w in sorted(ds.items(), key=lambda x: -x[1])[:12]))
    tw = collections.Counter(r["b"] for r in res if r["b"])
    print(f"B lines used as twins: {len(tw)}; B lines twin of 2+ A lines: {sum(1 for v in tw.values() if v > 1)}")
    for r in res[:25]:
        if r["b"]: print(f"  {r['a'][:8]} w {r['wa']:.4f} -> {r['b'][:8]} w {r['wb']:.4f} d {r['d']:+4d} trace join {r['trace_join'] / 59.826:5.1f} s; after it b1-2 {r['b12']}/{r['kj']}, 60 s {r['b60']}/{r['kj']}")
        else: print(f"  {r['a'][:8]} w {r['wa']:.4f} -> no twin")
    if "--json" in sys.argv:
        json.dump(res, open(sys.argv[sys.argv.index("--json") + 1], "w"))

main()
