#!/usr/bin/env python3
"""Why do twin dog lines of two game files cast differently now and then? (v32.18, 2026-11-24)

For every twin pair from tools/cross_twins.py (--json) whose dog traces agree from READY, and every cast frame both
files cast themselves (raw full-day rows on both sides), compare bites 1-2 and the dog's visibility-grid changes
(`g` in the raw rows: the dog's tile entering / leaving the visibility grid; off the grid it does not animate, so it makes
no decisions and draws no numbers [DECOMP animals.c updateDog: only on checkEntityAnimationStateChanged]) up to bite 2.

  python3 -I tools/twin_grid_check.py TWINS.json PACK_A PACK_B --raw-a DIR [DIR ...] --raw-b DIR [DIR ...]

Result 2026-11-24 (lab files with the dog 2.2 units apart on one tile): sunny horse vs no horse, 739 of the 745 twin cast
frames whose bites 1-2 differ also differ in the grid changes (0.4% of the agreeing ones do); rainy, 1,355 of 1,436.
"""
import argparse, collections, glob, json, os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def chains(P, key, cap=40):
    ln = P["lines"].get(key)
    out = {}
    if not ln:
        return out
    for j, c in enumerate(ln["idx"]):
        if c < 0:
            continue
        k = ln["k0"] + 2 * j
        if P["F"][c] < 0:
            out[k] = ()
            continue
        st, lab, ch = P["S"][c], k + P["F"][c], []
        while st >= 0 and len(ch) < cap:
            ch.append((lab, P["O"][st]))
            if P["N"][st] < 0:
                break
            lab += P["N"][st]
            st = P["X"][st]
        out[k] = tuple(ch)
    return out


def raw(dirs):
    out = {}
    for d in dirs:
        for fp in sorted(glob.glob(os.path.join(d, "FD_casts_b*.jsonl"))):
            for line in open(fp):
                r = json.loads(line)
                for c in r["casts"]:
                    out[(r["key"], c["k"])] = tuple(c.get("g") or ())
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("twins"); ap.add_argument("pack_a"); ap.add_argument("pack_b")
    ap.add_argument("--raw-a", nargs="+", required=True); ap.add_argument("--raw-b", nargs="+", required=True)
    ap.add_argument("--join-max", type=int, default=60, help="twins whose traces agree from this VI on (READY = 0)")
    a = ap.parse_args()
    PA, PB, T = json.load(open(a.pack_a)), json.load(open(a.pack_b)), json.load(open(a.twins))
    RA, RB = raw(a.raw_a), raw(a.raw_b)
    cnt = collections.Counter()
    for r in T:
        if not r.get("b") or r["trace_join"] > a.join_max:
            continue
        ca, cb, d = chains(PA, r["a"]), chains(PB, r["b"]), r["d"]
        for k in ca:
            if k + d not in cb or k < r["trace_join"]:
                continue
            x, y = ca[k][:2], tuple((t - d, o) for t, o in cb[k + d][:2])
            ga, gb = RA.get((r["a"], k)), RB.get((r["b"], k + d))
            if ga is None or gb is None:
                cnt["no raw row on one side (a cast shared by hash)"] += 1
                continue
            lim = min(x[-1][0] if x else 99999, y[-1][0] if y else 99999) + 40
            grid = [t for t in ga[0::2] if t <= lim] != [t - d for t in gb[0::2] if t - d <= lim]
            cnt[("bites 1-2 " + ("agree" if x == y else "differ"), "grid changes " + ("differ" if grid else "same"))] += 1
    for k, v in sorted(cnt.items(), key=str):
        print(f"  {k}: {v}")


if __name__ == "__main__":
    main()
