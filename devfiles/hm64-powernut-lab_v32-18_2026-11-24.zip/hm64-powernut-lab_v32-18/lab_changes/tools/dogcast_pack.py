"""
Dog after the cast -> a compact pack for the app (2026-11-20). Input: a results folder of the full-day lab limited to
90 s (FD1_lines.jsonl + FD_casts_b*.jsonl). Output: webapp/assets/dogcast.json, embedded as D.dogcast by export_webapp.

What the lab showed and the pack uses: (1) the dog after a cast is a function of the cast frame; (2) the game state at
a bite fixes everything after it (184,153 bites are 6,019 states; release tails identical on every repeat). So:
  lines[key] = {k0, idx: [cast id per cast frame k0, k0+2, ... ; -1 = none]}     (a frame whose state another line
               already cast points to that cast: its dog is the same, measured from the cast)
  casts      : P[id] = dog changes from the cast to its first bite, flat [dk, code, dk, code, ...] (dk from the previous
               entry, the first from the cast frame; code = animation base * 8 + screen facing);
               F[id] = VIs from the cast to the first bite (-1 = no bite in the data); S[id] = that bite's state;
               E[id] = VIs from the cast to the end of its data
  states     : R[s] = dog changes from the bite to the next bite while B stays held; N[s] = VIs to the next bite (-1 =
               none in the data); X[s] = the next bite's state; L[s] = VIs of data after the bite when N is -1;
               T[s] = dog changes for `tail` VIs after the bite when B is let go 4 polls after it; O[s] = the catch
  python3 tools/dogcast_pack.py RESULTS_DIR [--out webapp/assets/dogcast.json] [--app-data DATA.json]
"""
import argparse, bisect, glob, json, os, sys, collections
from array import array


def undelta(d):
    out, k = [], 0
    for i in range(0, len(d), 2):
        k = d[i] if i == 0 else k + d[i]
        out.append((k, d[i + 1]))
    return out


def _rel_tail(t, lab):
    t = list(t)
    if len(t) >= 2 and t[0] != -1:
        t[0] -= lab                                       # first change: absolute label -> VIs after the bite
    if len(t) >= 2 and t[-2] == -1:
        t[-1] -= lab                                      # beach-check failure label, likewise
    return tuple(t)


def split_bite_states(files):
    """v32.18 (2026-11-24, rainy runs): a bite's state is keyed by its cast_hash (hm64/zigzag.py: RNG, dogInfo, dog
    entity + sprite, Jack's action / facing). On rainy mornings the weather sprites draw random numbers every frame
    [DECOMP system/map.c setupWeatherSprites] and are not in that hash, so two bites with equal hashes can have different
    futures (rain120: 691 of 41,732 repeated bite hashes on the horse save; none on any sunny run). Every occurrence of a
    hash is compared with the others on their common horizon (the later bites and catches, the dog while B is held, the
    dog after each release); occurrences that disagree get their own state. Returns {(cast number, bite index):
    cluster >= 1} (cluster 0 = the plain hash, so a run without conflicts packs exactly as before) and counts."""
    rows, occ = [], collections.defaultdict(list)
    for fp in files:
        for l in open(fp):
            r = json.loads(l)
            for c in r.get("casts", []):
                ci = len(rows)
                runs = undelta(c["d"])
                bs = tuple((b[0], b[1]) for b in c["b"])
                rows.append((c["e"][0], bs, array("i", [x for x, _ in runs]), array("i", [y for _, y in runs]),
                             tuple(_rel_tail(t, bs[i][0]) for i, t in enumerate(c["t"]))))
                for i, b in enumerate(c["b"]):
                    occ[b[2]].append((ci, i))

    def future(o, h):
        e, bs, labs, codes, ts = rows[o[0]]
        L = bs[o[1]][0]
        bl = tuple((lab - L, ca) for lab, ca in bs[o[1]:] if lab - L < h)
        tl = ts[o[1]:o[1] + len(bl)]
        j = bisect.bisect_right(labs, L) - 1
        dog = [codes[j] if j >= 0 else None]
        for m in range(j + 1, len(labs)):
            if labs[m] - L >= h:
                break
            dog += [labs[m] - L, codes[m]]
        return bl, tl, dog

    horizon = lambda o: rows[o[0]][0] - rows[o[0]][1][o[1]][0]
    out, n_hash, n_split, n_occ = {}, 0, 0, 0
    for h, os_ in occ.items():
        if len(os_) < 2:
            continue
        n_hash += 1
        reps = []
        for o in sorted(os_, key=lambda o: -horizon(o)):
            ho = horizon(o)
            for cl, rep in enumerate(reps):
                if future(o, ho) == future(rep, ho):
                    break
            else:
                cl = len(reps)
                reps.append(o)
            if cl:
                out[o] = cl
                n_occ += 1
        n_split += len(reps) > 1
    return out, (n_hash, n_split, n_occ)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("res", nargs="+", help="results folders (v31.14: several, e.g. d90 and d110; the lines are read from the one whose no-cast paths run longest)")
    ap.add_argument("--cast-until", type=int, default=0, help="last cast label + 2 (default: 2400, or past the latest cast found)")
    ap.add_argument("--out", default="webapp/assets/dogcast.json")
    ap.add_argument("--app-data")
    a = ap.parse_args()
    L = {}
    for d in a.res:
        for l in open(os.path.join(d, "FD1_lines.jsonl")):
            r = json.loads(l)
            if r.get("ok") and (r["key"] not in L or len(r["hs"]) > len(L[r["key"]]["hs"])):
                L[r["key"]] = r
    kmax = 0
    P, F, S, E = [], [], [], []
    by_hash, by_kk = {}, {}
    sid, SR, SN, SX, SL, ST, SO = {}, [], [], [], [], [], []
    ALT = {}
    n_b = 0

    def state(h):
        if h not in sid:
            sid[h] = len(SR)
            SR.append(None); SN.append(-1); SX.append(-1); SL.append(0); ST.append(None); SO.append("")
        return sid[h]
    files = [f for d in a.res for f in sorted(glob.glob(os.path.join(d, "FD_casts_b*.jsonl")))]
    split, (n_hash, n_split, n_occ) = split_bite_states(files)
    bkey = lambda ci, i, h: h if (ci, i) not in split else f"{h}#{split[(ci, i)]}"
    ci = -1
    for fp in files:
        for l in open(fp):
            r = json.loads(l)
            hs = {int(k): h for k, h in r["_job"]["casts"]}
            for c in r.get("casts", []):
                ci += 1
                k, runs, bs, end = c["k"], undelta(c["d"]), c["b"], c["e"][0]
                kmax = max(kmax, k)
                fb = bs[0][0] if bs else None
                pre, prev = [], k
                for kk, code in runs:
                    if kk <= k or (fb is not None and kk >= fb) or kk > end:
                        continue
                    pre += [kk - prev, code]; prev = kk
                cid = len(P)
                P.append(pre); F.append(fb - k if fb is not None else -1); E.append(end - k)
                S.append(state(bkey(ci, 0, bs[0][2])) if bs else -1)
                if hs.get(k):
                    by_hash.setdefault(hs[k], cid)
                by_kk[(r["key"], k)] = cid
                for i, b in enumerate(bs):
                    n_b += 1
                    s = state(bkey(ci, i, b[2]))
                    nxt = bs[i + 1][0] if i + 1 < len(bs) else None
                    seg, prev = [], b[0]
                    for kk, code in runs:
                        if kk < b[0] or (nxt is not None and kk >= nxt) or kk > end:
                            continue
                        seg += [kk - prev, code]; prev = kk
                    span = (nxt if nxt is not None else end) - b[0]
                    if nxt is not None:
                        x = state(bkey(ci, i + 1, bs[i + 1][2]))
                        ALT.setdefault(s, {})[x] = (nxt - b[0], bs[i + 1][1])
                        if SN[s] < 0:
                            SR[s], SN[s], SX[s] = seg, nxt - b[0], x
                    elif SN[s] < 0 and span > SL[s]:
                        SR[s], SL[s] = seg, span
                    if ST[s] is None:
                        t = c["t"][i]
                        if len(t) >= 2 and t[-2] == -1:
                            t = t[:-2]
                        tr, prev, out = undelta(t), b[0], []
                        for kk, code in tr:
                            out += [max(0, kk - prev), code]; prev = max(kk, prev)
                        ST[s] = out
                        SO[s] = b[1]
    # v32.1: a bite's state hash does not fix the NEXT bite's hash (it does fix its time and catch: the hash also holds
    # something the fishing never reads), so one state can have several next states that all bite alike. The first one
    # seen may be a chain whose data ends early; keep the next state whose known chain runs longest.
    import sys
    sys.setrecursionlimit(100000)
    depth, swapped = {}, 0

    def run(s):
        if s in depth:
            return depth[s]
        depth[s] = 0
        if SN[s] >= 0:
            depth[s] = 1 + run(SX[s])
            for x, (gap, catch) in ALT.get(s, {}).items():
                if x != SX[s] and gap == SN[s] and 1 + run(x) > depth[s]:
                    depth[s] = 1 + run(x)
        return depth[s]
    for s in range(len(SR)):
        run(s)
    for s, alts in ALT.items():
        best = SX[s]
        for x, (gap, catch) in alts.items():
            if gap == SN[s] and depth[x] > depth[best]:
                best = x
        if best != SX[s]:
            SX[s] = best; swapped += 1
    lines, miss, tot = {}, 0, 0
    clast = a.cast_until or max(2400, kmax + 2)
    for key, r in L.items():
        h0, step, hs = r["h0"], r["step"], r["hs"]
        idx = []
        for k in range(6, clast, 2):
            tot += 1
            i = (k - h0) // step
            cid = by_kk.get((key, k))
            if cid is None and 0 <= i < len(hs):
                cid = by_hash.get(hs[i])
            if cid is None:
                miss += 1
            idx.append(-1 if cid is None else cid)
        lines[key] = {"k0": 6, "idx": idx}
    pack = {"v": 1, "until": 5398 if clast <= 2400 else 6598, "cast_until": clast, "tail": 240, "lines": lines, "P": P, "F": F, "S": S, "E": E,
            "R": [x or [] for x in SR], "N": SN, "X": SX, "L": SL, "T": [x or [] for x in ST], "O": "".join(o[:1] or "?" for o in SO)}
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    json.dump(pack, open(a.out, "w"), separators=(",", ":"))
    print(f"bite hashes seen more than once: {n_hash}; with futures that disagree (split): {n_split}, "
          f"{n_occ} bites moved to a state of their own")
    print(f"{len(L)} lines, {len(P)} casts, {n_b} bites -> {len(SR)} states ({swapped} next-state links moved to a longer chain); cast frames 0.1-{clast / 59.826:.0f} s: {tot}, without a cast {miss}; "
          f"{os.path.getsize(a.out) / 1e6:.2f} MB -> {a.out}")
    # how fast do neighbouring cast frames' dogs part? (the card is only right for the right frame)
    def dog_after(key, k, span):
        cid = lines[key]["idx"][(k - 6) // 2]
        if cid < 0:
            return None
        out, t = [], 0
        it = P[cid]
        for i in range(0, len(it), 2):
            t += it[i]; out.append((t, it[i + 1]))
        f, s = F[cid], S[cid]
        while f >= 0 and f < span and s >= 0:
            t = f
            it = pack["R"][s]
            for i in range(0, len(it), 2):
                t += it[i]; out.append((t, it[i + 1]))
            if SN[s] < 0:
                break
            f, s = f + SN[s], SX[s]
        return [(t, c) for t, c in out if t < span]
    import random
    random.seed(1)
    keys = list(lines)
    first = []
    same10 = 0
    for _ in range(4000):
        key = random.choice(keys); k = random.randrange(100, 2300, 2)
        A, B = dog_after(key, k, 900), dog_after(key, k + 2, 900)
        if A is None or B is None:
            continue
        B = [(t + 2, c) for t, c in B]                    # the same wall clock
        d = None
        for (ta, ca), (tb, cb) in zip(A, B):
            if ca != cb or abs(ta - tb) > 2:
                d = min(ta, tb); break
        if d is None and len(A) != len(B):
            d = min(A[min(len(A), len(B)) - 1][0] if min(len(A), len(B)) else 0, 900)
        if d is None:
            same10 += 1
        else:
            first.append(d)
    first.sort()
    n = len(first) + same10
    q = lambda p: first[int(p * (len(first) - 1))] * 16.715 / 1000 if first else 0
    print(f"cast one game frame apart ({n} pairs): the two dogs are the same for 15 s in {100 * same10 / n:.0f}%; otherwise they "
          f"part {q(0.1):.1f} / {q(0.5):.1f} / {q(0.9):.1f} s after the cast (10% / median / 90%)")
    if a.app_data:
        D = json.load(open(a.app_data))
        ok = bad = 0
        for R in D["lroutes"] if isinstance(D["lroutes"], list) else D["lroutes"].values():
            if not R.get("dw"):
                continue
            for ln in R["dw"]["lines"]:
                r = L.get(ln["key"])
                if not r:
                    bad += 1; continue
                mine = undelta(r["d"])
                st = lambda k: next((c for kk, c in reversed(mine) if kk <= k), None)
                good = all(st(v[0] + 1) == v[4] * 8 + v[2] for v in ln["vis"] if 8 < v[0] < 1990 and v[1] - v[0] > 2)
                ok += good; bad += (not good)
        print(f"app dog lines against the lab's no-cast traces (first 33 s): {ok} agree, {bad} do not")


if __name__ == "__main__":
    sys.exit(main())
