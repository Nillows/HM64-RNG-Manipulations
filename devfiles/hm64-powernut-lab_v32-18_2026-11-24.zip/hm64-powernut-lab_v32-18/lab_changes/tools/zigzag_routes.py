"""
Pack a zigzag campaign result (tools/zigzag_campaign.py: zz_lines.json, Z6_lines.jsonl, Z7_casts.jsonl) as a
multi-line Lucky Timer route for the web app (data key `lroutes`, same file as tools/route_tables.py).

  python3 -I tools/zigzag_routes.py RESULTS_DIR --id nodog-zigzag-fast --label "..." \
      [--out webapp/assets/lucky_routes.json]

- Every dog line that has casts becomes one cast series, packed like the dog paths (tools/export_webapp.path_casts):
  cast k = VIs after the line representative's READY, read in VI k+1, bites shifted the same way. Casts exist on even
  k only (one per game frame), so odd VIs stay unknown (parity None), as for the other route tables.
- Every member route (beach state x first cut D x second cut B, with its route weight) becomes a weighted variant:
    anchor 'pier'  (Space when Jack stops at the dock end = READY):  path VI = t + k_off,            first t = 1
    anchor 'beach' (Space at the beach load):                        path VI = t + k_off - ready_rel, first t = ready_rel + 1
  (k_off = the member's READY in VIs after its line representative's READY; ready_rel = VIs from the beach load).
  Variants with the same (line, offset, first t) are merged.
- Presets: by default (v29.7/29.8 format) `axes` = first cut, second cut and static `groups` for each combination.
  With --grades (experimental): `axes` = cabin grade (farm load 0-1 / 2 / 3-4 game frames after the fastest), crossroads grade (ranch
  load 0 / 1-2 / 3 frames after the fastest), first cut tight / mid / loose, second cut early / middle / late (dock-end
  spot; needs a first cut). `members` = every member route aggregated by (line, k_off, ready_rel, grades, cuts) with
  its weight (beach states reached by routes of different grades split by the route_weights chain); the app builds
  any combination of the four rows from them (LuckyCore.groupOf). `groups` keeps only "all".
"""
from __future__ import annotations

import argparse
import hashlib
import json
import statistics
import sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tools"))

from tools.export_webapp import path_casts   # noqa: E402
from tools import zigzag_report              # noqa: E402

D_FIRST = 84          # first cut that clears the small wall on every fast-zone beach state (82/83 never reach)


CUT1 = [   # first cut (down-left around the small wall): game frames after the earliest cut that clears it
    ("tight", "Tight", "0–1 frames late", "down-left within 1 game frame of the earliest cut that clears the small wall",
     lambda f: f <= 1),
    ("mid", "Mid", "2–3 frames late", "down-left 2–3 game frames after the earliest cut", lambda f: 2 <= f <= 3),
    ("loose", "Loose", "4+ frames late", "down-left 4 or more game frames after the earliest cut", lambda f: f >= 4),
]
CUT2 = [   # second cut (down-right onto the pier): where Jack stops at the dock end (dog-beach: 7-frame pier window;
           # other saves: 11 frames, texts via _save_texts)
    ("early", "Early", "near edge (dog side)", "down-right in the first 2 frames of the pier window: Jack stops at the "
     "dock end on the side nearest the dog (z 170–176)", lambda z: z <= 178),
    ("mid", "Middle", "middle of the pier", "down-right in frames 3–4 of the pier window: Jack stops in the middle of the "
     "dock end (z 182–188)", lambda z: 178 < z <= 190),
    ("late", "Late", "far edge", "down-right in frames 5–7 of the pier window: Jack stops at the far edge of the dock end "
     "(z 194–196)", lambda z: z > 190),
]


HOUSE = [  # cabin grade: farm load in game frames after the fastest house traversal (thirds of the 0-4 frame spread)
    ("fast", "Fast", "farm 0–1 frames late", "the farm loads 0–1 game frames after the fastest house run (both turns tight "
     "around the table, e.g. turn 1 at 276–277 and turn 2 at 328–329 for the fastest)", lambda f: f <= 1),
    ("mid", "Medium", "farm 2 frames late", "the farm loads 2 game frames after the fastest house run", lambda f: f == 2),
    ("slow", "Slow", "farm 3–4 frames late", "the farm loads 3–4 game frames after the fastest (the edge of the fast zone)",
     lambda f: f >= 3),
]
CROSS = [  # crossroads grade: ranch load in game frames after the fastest farm + crossroads (thirds of the 0-3 spread)
    ("fast", "Fast", "cut at 78–87", "the ranch loads on the fastest frame: the down-left cut in the sweet spot, "
     "1.30–1.45 s after the crossroads loads", lambda f: f == 0),
    ("mid", "Medium", "cut 74–77 / 88–101", "the ranch loads 1–2 game frames late: the cut a bit early (74–77) or late "
     "(88–101)", lambda f: 1 <= f <= 2),
    ("slow", "Slow", "cut 72–73 / 102–104", "the ranch loads 3 game frames late: the cut at the very edge of the fast zone",
     lambda f: f >= 3),
]


# lineup lab (2026-11-15): first cut fixed at the tightest (hug the small wall); the wait = how late Jack's first step is
# (a loose first turn corrected by turning up), in VIs after the earliest (whole game frames, 0-30)
WAIT = [
    ("w0", "Clean", "0–0.13 s late", "first step on time or up to 4 game frames late (no correction): wait 0–8 VIs",
     lambda W: W <= 8),
    ("w1", "Small fix", "0.17–0.30 s late", "first step 5–9 game frames late (a small correction after a loose first "
     "turn): wait 10–18 VIs", lambda W: 10 <= W <= 18),
    ("w2", "Big fix", "0.33–0.50 s late", "first step 10–15 game frames late (a bigger correction): wait 20–30 VIs",
     lambda W: W >= 20),
]
FADE_IN = 3      # VIs after the beach map change: the first non-black frame of the fade-in (rendered, rice; full ~VI 65)


def axes_lineup():
    return [{"id": "wait", "short": "wait", "label": "Your first step on the beach: how late (tight first turn, then hug "
             "the wall)", "opts": [{"id": i, "label": lb, "band": bd, "desc": ds} for i, lb, bd, ds, _ in WAIT]},
            {"id": "cut2", "short": "2nd cut", "needs": "wait", "label": "2nd cut: down-right onto the pier",
             "opts": [{"id": i, "label": lb, "band": bd, "desc": ds} for i, lb, bd, ds, _ in CUT2]}]


def groups_lineup():
    z = lambda m: m["spot"][1]
    out = [("all", "All", "every route", "All simulated routes of this preset", {}, lambda m: True)]
    for i1, lb1, bd1, ds1, f1 in WAIT:
        out.append((f"wait-{i1}", f"wait {lb1.lower()}", bd1, ds1[:1].upper() + ds1[1:], {"wait": i1},
                    lambda m, f1=f1: f1(m.get("W", 0))))
        for i2, lb2, bd2, ds2, f2 in CUT2:
            out.append((f"wait-{i1}+cut2-{i2}", f"wait {lb1.lower()} · 2nd cut {lb2.lower()}", bd2,
                        f"{ds1[:1].upper() + ds1[1:]}; second cut {ds2}", {"wait": i1, "cut2": i2},
                        lambda m, f1=f1, f2=f2: f1(m.get("W", 0)) and f2(z(m))))
    return out


def axes_def(grades=False):
    opts = lambda L: [{"id": i, "label": lb, "band": bd, "desc": ds} for i, lb, bd, ds, _ in L]
    pre = [{"id": "house", "short": "cabin", "label": "Cabin: how fast the farm loads after the house", "opts": opts(HOUSE)},
           {"id": "cross", "short": "crossroads", "label": "Crossroads: how fast the ranch loads", "opts": opts(CROSS)}]
    return (pre if grades else []) + [
            {"id": "cut1", "short": "1st cut", "label": "1st cut: down-left around the small wall",
             "opts": [{"id": i, "label": lb, "band": bd, "desc": ds} for i, lb, bd, ds, _ in CUT1]},
            {"id": "cut2", "short": "2nd cut", "needs": "cut1", "label": "2nd cut: down-right onto the pier",
             "opts": [{"id": i, "label": lb, "band": bd, "desc": ds} for i, lb, bd, ds, _ in CUT2]}]


def groups_def():
    """(id, label, band, desc, axes tags, member filter): all routes, each first cut, each first cut x second cut.
    No second-cut-only presets: the second cut is chosen after the first (its odds are per first cut)."""
    fr = lambda m: (m["D"] - D_FIRST) // 2      # game frames after the first possible first cut
    z = lambda m: m["spot"][1]
    out = [("all", "All", "every route", "All simulated routes of this preset", {}, lambda m: True)]
    for i1, lb1, bd1, ds1, f1 in CUT1:
        out.append((f"cut1-{i1}", f"1st cut {lb1.lower()}", bd1, "First cut " + ds1, {"cut1": i1},
                    lambda m, f1=f1: f1(fr(m))))
        for i2, lb2, bd2, ds2, f2 in CUT2:
            out.append((f"cut1-{i1}+cut2-{i2}", f"1st cut {lb1.lower()} · 2nd cut {lb2.lower()}", bd2,
                        f"First cut {ds1}; second cut {ds2}", {"cut1": i1, "cut2": i2},
                        lambda m, f1=f1, f2=f2: f1(fr(m)) and f2(z(m))))
    return out


def grade_split(res_dir):
    """Fraction of each beach state's route weight by (house grade, crossroads grade): the route_weights chain
    (menus per mash period, house (U, V), crossroads C, ranch) with the farm / ranch arrival of every path."""
    from tools import zigzag_campaign as Z
    out = Path(res_dir)
    cfg = dict(Z.PRESETS[_preset_of(out)])
    W = Z.route_weights(out, cfg)
    hw, hvi = Counter(), {}
    for r in Z.menu_rows(out, cfg):
        for row in r["rows"]:
            if row.get("house"):
                hw[(r["T"], row["house"])] += 1.0 / r["T"]
                hvi[row["house"]] = row["house_vi"]
    keep = {h for h, v in hvi.items() if cfg.get("house_lo", 0) <= v - W["h0"] <= cfg["house_slack"]}
    h2f = defaultdict(Counter)
    for r in Z.mine(Z.ok_rows(out / "Z2_house.jsonl"), cfg, Us="Us", Vs="Vs"):
        if r["h"] in keep:
            for U, V, rel, key, draw in r["rows"]:
                if rel is not None and rel - W["fmin"] <= cfg["farm_slack"]:
                    h2f[r["h"]][(key, (rel - W["fmin"]) // 2)] += 1
    f2r = defaultdict(Counter)
    for r in Z.mine(Z.ok_rows(out / "Z3_cross.jsonl"), cfg, Cs="Cs"):
        for C, rel, key, draw in r["rows"]:
            if rel is not None and rel - W["rmin"] <= cfg["ranch_slack"]:
                f2r[r["f"]][(key, (rel - W["rmin"]) // 2)] += 1
    r2b = {r["r"]: r["b"] for r in Z.ok_rows(out / "Z4_ranch.jsonl") if r.get("b")}
    hg = lambda fr: next(i for i, (*_, f) in enumerate(HOUSE) if f(fr))
    cg = lambda fr: next(i for i, (*_, f) in enumerate(CROSS) if f(fr))
    byT = defaultdict(lambda: defaultdict(Counter))
    for (T, h), wh in hw.items():
        if h not in keep:
            continue
        nf = sum(h2f[h].values())
        for (f, hfr), cf in h2f[h].items():
            nr = sum(f2r[f].values())
            for (rr, cfr), cr in f2r[f].items():
                b = r2b.get(rr)
                if b:
                    byT[T][b][(hg(hfr), cg(cfr))] += wh * cf / nf * cr / nr
    pooled = defaultdict(Counter)
    for T, d in byT.items():
        tot = sum(sum(c.values()) for c in d.values())
        for b, c in d.items():
            for k, w in c.items():
                pooled[b][k] += w / tot / len(byT)
    return {b: {k: w / sum(c.values()) for k, w in c.items()} for b, c in pooled.items()}


def house_split(res_dir):
    """Fraction of each beach state's route weight by house arrival (house VI): the route_weights chain (menus per
    mash period, house (U, V), crossroads C, ranch), pooled over mash periods like the route weights. Beach states
    reached from several mornings (merged by the farm or later) are split by their paths."""
    from tools import zigzag_campaign as Z
    out = Path(res_dir)
    cfg = dict(Z.PRESETS[_preset_of(out)])
    W = Z.route_weights(out, cfg)
    hw, hvi = Counter(), {}
    for r in Z.menu_rows(out, cfg):
        for row in r["rows"]:
            if row.get("house"):
                hw[(r["T"], row["house"])] += 1.0 / r["T"]
                hvi[row["house"]] = row["house_vi"]
    keep = {h for h, v in hvi.items() if Z.house_ok(v, W["h0"], cfg)}
    h2f = defaultdict(Counter)
    for r in Z.mine(Z.ok_rows(out / "Z2_house.jsonl"), cfg, Us="Us", Vs="Vs"):
        if r["h"] in keep:
            for U, V, rel, key, draw in r["rows"]:
                if rel is not None and rel - W["fmin"] <= cfg["farm_slack"]:
                    h2f[r["h"]][key] += 1
    f2r = defaultdict(Counter)
    for r in Z.mine(Z.ok_rows(out / "Z3_cross.jsonl"), cfg, Cs="Cs"):
        for C, rel, key, draw in r["rows"]:
            if rel is not None and rel - W["rmin"] <= cfg["ranch_slack"]:
                f2r[r["f"]][key] += 1
    r2b = {r["r"]: r["b"] for r in Z.ok_rows(out / "Z4_ranch.jsonl") if r.get("b")}
    byT = defaultdict(lambda: defaultdict(Counter))
    for (T, h), wh in hw.items():
        if h not in keep:
            continue
        nf = sum(h2f[h].values())
        for f, cf in h2f[h].items():
            nr = sum(f2r[f].values())
            for rr, cr in f2r[f].items():
                b = r2b.get(rr)
                if b:
                    byT[T][b][hvi[h]] += wh * cf / nf * cr / nr
    pooled = defaultdict(Counter)
    for T, d in byT.items():
        tot = sum(sum(c.values()) for c in d.values())
        for b, c in d.items():
            for k, w in c.items():
                pooled[b][k] += w / tot / len(byT)
    return {b: {k: w / sum(c.values()) for k, w in c.items()} for b, c in pooled.items()}


def cast_results_all(out):
    """hash -> (full, [(d, nut), ...]) every bite of a cast, d = bite VI - cast k (2026-11-16, lab code zigzag-4f: bites
    after the second are followed while they show by the preset's bite_until; `full` = the run followed later bites, so
    the list is complete up to that horizon; runs before zigzag-4f only have bites 1-2 -> full False)"""
    res = {}
    for r in zigzag_report._rows(Path(out) / "Z7_casts.jsonl"):
        for c in r.get("casts", []):
            if c["status"] != "ok" or c.get("hash_ok") is False:
                continue
            b = [(x["bite"] - c["k"], bool(x["nut"])) for x in c.get("bites", []) if x.get("bite") is not None]
            res.setdefault(c["hash"], b)
    return res


def merged_results(res_dir, extra=()):
    """bites 1-2 per cast state from this run and older runs of the same save (cast states are keyed by their game-state
    hash, so a state cast in another run gives the same outcome: checked by hash, 0 differing). This run wins."""
    res, agree, disagree = zigzag_report.cast_results(Path(res_dir))
    cross = [0, 0]
    for d in extra:
        r2, _, _ = zigzag_report.cast_results(Path(d))
        for h, v in r2.items():
            if h in res:
                cross[0 if res[h] == v else 1] += 1
            else:
                res[h] = v
    return res, agree, disagree, cross


def pack_later_bites(packed, rec_k, later, full):
    """bites 3+ aligned with a path_casts series (index i = path VI lo + i): 0 = unknown (no every-bite data for that
    cast state), else [b3, b4, ...] with b = bite path VI - this VI (like b1 / b2), negative = a Nut bite; [] = no later bite showed by
    the run's bite horizon; -1 = the entry of VI i - parity (path_casts pairs the untested VI with the game frame it
    shares; the app copies it and shifts b by the parity)."""
    lo, n, par = packed["lo"], len(packed["n1"]), packed["parity"]
    src = {k + 1: k for k in rec_k}                       # cast k is read in VI k + 1
    out = []
    for i in range(n):
        v = lo + i
        k = src.get(v)
        if k is None and par is not None and v % 2 == 0 and src.get(v - par) is not None:
            k2 = src[v - par]
            out.append(-1 if k2 in later and full.get(k2) else 0)   # -1 = the same bites as VI i - parity (path_casts)
            continue
        if k is None or k not in later or not full.get(k):
            out.append(0)
            continue
        vk = k + 1
        row = []
        for d, nut in later[k][2:]:
            row.append(-(vk + d - v) if nut else vk + d - v)
        out.append(row)
    return out


def _bite_until(res_dir):
    from tools import zigzag_campaign as Z
    return Z.PRESETS.get(_preset_of(Path(res_dir)), {}).get("bite_until")


def dog_traces(res_dir):
    """per line: visible runs [k0, k1, screen facing, visual class, sprite base] after the representative's READY
    (Z6 observe rows), for the v30 dog-watch"""
    out = {}
    for r in zigzag_report._rows(Path(res_dir) / "Z6_lines.jsonl"):
        if r.get("ok") and r.get("obs"):
            out[r["key"]] = r["obs"]["vis"]
    return out


def _preset_of(out):
    """the preset a results folder was made with: its parent folder (results/<preset>/<label>) or a run log name;
    the longest matching preset name wins (lineup-sparrow-test before lineup-sparrow)"""
    from tools import zigzag_campaign as Z
    names = sorted(Z.PRESETS, key=len, reverse=True)
    for name in names:
        if out.parent.name == name:
            return name
    for name in names:
        if name in out.parent.name or any(name in f.name for f in out.glob("run-*.log")):
            return name
    return "zigzag-fast"


def build(res_dir, rid, label, note="", grades=False, save="nohorse-dogbeach-nopickup_0d78b95b", howto=None,
          lineup=False, houses=None, extra=(), every_bite=False, dogwatch=False):
    res_dir = Path(res_dir)
    lines = json.loads((res_dir / "zz_lines.json").read_text())
    res, agree, disagree, cross = merged_results(res_dir, extra)
    tab, nat = zigzag_report.line_tables(res_dir, lines, res)
    allb = cast_results_all(res_dir) if every_bite else {}
    hshare = None
    if houses:                         # only the mornings with these house arrivals: member weights x their path share
        hs = house_split(res_dir)
        w0 = sum(m["w"] for L in lines.values() for m in L["members"] if "k_off" in m) or 1.0
        for L in lines.values():
            for m in L["members"]:
                m["w"] *= sum(hs.get(m["b"].split("@w")[0], {}).get(v, 0.0) for v in houses)
            L["members"] = [m for m in L["members"] if m["w"] > 0]
            L["w"] = sum(m["w"] for m in L["members"] if "k_off" in m)
        lines = {k: L for k, L in lines.items() if L["w"] > 0}
        hshare = sum(L["w"] for L in lines.values()) / w0
    keys = [k for k in sorted(lines, key=lambda k: -lines[k]["w"]) if tab.get(k)]
    packed, info = [], []
    for k in keys:
        sig = "zz:" + k
        rec = {int(kk): (int(v[1]), int(v[0]), None if v[3] is None or v[2] is None else int(bool(v[3])),
                         None if v[2] is None else int(v[2]))
               for kk, v in tab[k].items() if v[0] is not None}
        c, conf, _ = path_casts([{"id": 0}], [[0, 0, 1.0, sig]], {sig: rec})
        if every_bite:                                   # bites 3+ of every cast state cast in this run (not in `extra`)
            hk = {kk: h for kk, h in nat[k]["hashes"] if kk % 2 == 0}
            later = {kk: allb[hk[kk]] for kk in rec if hk.get(kk) in allb}
            c[0]["bx"] = pack_later_bites(c[0], rec, later, {kk: True for kk in later})
        packed.append(c[0])
        info.append({"key": k, "wake_draw": lines[k]["rep"].get("wake_draw"), "w": lines[k]["w"],
                     "casts": len(rec), "nut1": sum(v[0] for v in rec.values()),
                     "nut2": sum(1 for v in rec.values() if v[2])})
    li = {k: i for i, k in enumerate(keys)}
    dw, dwi = None, {}
    if dogwatch:                                         # v30 dog-watch: every line's visible runs (cast or not)
        tr = dog_traces(res_dir)
        dkeys = [k for k in sorted(lines, key=lambda k: -lines[k]["w"]) if k in tr]
        dwi = {k: i for i, k in enumerate(dkeys)}
        dw = {"lines": [{"key": k, "w": round(lines[k]["w"], 7), "li": li.get(k, -1), "vis": tr[k]} for k in dkeys],
              "of_line": [dwi.get(k, -1) for k in keys], "until": max((v[1] for k in dkeys for v in tr[k]), default=0)}
    members = [(k, m) for k, L in lines.items() for m in L["members"] if "k_off" in m]
    W_all = sum(m["w"] for _, m in members) or 1.0
    ready_all = [m["ready_rel"] for _, m in members]
    r0_beach = int(statistics.median(ready_all)) if ready_all else 0
    split = grade_split(res_dir) if grades else {}
    fr = lambda m: (m["D"] - D_FIRST) // 2
    c1 = lambda m: next(i for i, (*_, f) in enumerate(CUT1) if f(fr(m)))
    c2 = lambda m: next(i for i, (*_, f) in enumerate(CUT2) if f(m["spot"][1]))
    agg = defaultdict(float)
    for k, m in members:
        for (hgr, cgr), fw in split.get(m["b"], {}).items():
            agg[(li.get(k, -1), m["k_off"], m["ready_rel"], hgr, cgr, c1(m), c2(m))] += m["w"] * fw
    Wm = sum(agg.values()) or 1.0
    member_rows = [[*key, float(f"{w / Wm:.6g}")] for key, w in sorted(agg.items())]
    groups = []
    for gid, glabel, band, desc, ax, f in (groups_lineup() if lineup else groups_def()[:1] if grades else groups_def()):
        sel = [(k, m) for k, m in members if f(m)]
        W = sum(m["w"] for _, m in sel)
        if W <= 0:
            continue
        v = {"pier": defaultdict(float), "beach": defaultdict(float)}
        if lineup:
            v["fadein"] = defaultdict(float)
        cw = 0.0
        vu = defaultdict(lambda: defaultdict(float))
        for k, m in sel:
            if k not in li:
                if dogwatch and k in dwi:                 # dog-watch: lines with traces but no cast table
                    vu["pier"][(dwi[k], m["k_off"], 1)] += m["w"] / W
                    vu["fadein"][(dwi[k], m["k_off"] - m["ready_rel"] + FADE_IN, m["ready_rel"] + 1 - FADE_IN)] += m["w"] / W
                continue
            cw += m["w"]
            v["pier"][(li[k], m["k_off"], 1)] += m["w"] / W
            v["beach"][(li[k], m["k_off"] - m["ready_rel"], m["ready_rel"] + 1)] += m["w"] / W
            if lineup:                                   # stopwatch from the first fade-in frame = map change + FADE_IN
                v["fadein"][(li[k], m["k_off"] - m["ready_rel"] + FADE_IN, m["ready_rel"] + 1 - FADE_IN)] += m["w"] / W
        if lineup:
            v.pop("beach")                               # this route starts at the fade-in or the dock end
        groups.append({"id": gid, "label": glabel, "band": band, "desc": desc, "ax": ax, "share": round(W / W_all, 4),
                       "cover": round(cw / W, 4),
                       "v": {a: [[i, round(w, 7), o, mt] for (i, o, mt), w in sorted(d.items())] for a, d in v.items()},
                       **({"vu": {a: [[i, round(w, 7), o, mt] for (i, o, mt), w in sorted(d.items())] for a, d in vu.items()}}
                          if dogwatch else {})})
    src = {"results": res_dir.name, "lines": len(lines), "lines_with_casts": len(keys), "members": len(members),
           "casts": len(res), "repeat_checks": [agree, len(disagree)],
           **({"extra": [Path(d).name for d in extra], "cross_checks": cross} if extra else {}),
           **({"every_bite": True, "bite_horizon": _bite_until(res_dir)} if every_bite else {}),
           "nut1": sum(x["nut1"] for x in info), "nut2": sum(x["nut2"] for x in info),
           "sha256": hashlib.sha256((res_dir / "zz_lines.json").read_bytes()).hexdigest()[:16],
           **({"houses": sorted(houses), "share_of_run": round(hshare, 4)} if houses else {})}
    return _save_texts(save, {
        "id": rid, "label": label, "note": note, "save": save,
        "route": "zig-zag (menus mashed, house UL/DL/D, crossroads L/DL, beach DR/DL/DR)",
        "howto": howto or ("Route: mash the menus; house: hold up-left through the fade, cut down-left around the table, then "
                  "down out the door; farm: left; crossroads: left, cut down-left; ranch: down-right; beach: hold "
                  "down-right through the load, cut down-left as soon as Jack clears the small wall, run along the "
                  "back, cut down-right into the pier, hold it to the dock end. If Jack stops dead on the pier, you "
                  "cut too early and touched the sleeping dog under it: that attempt is not in the table - restart."),
        "source": src, "lines": packed, "line_info": info, **({"dw": dw} if dogwatch else {}),
        "anchors": ([{"id": "fadein", "label": "when the beach starts to fade in (before Jack can move)", "kind": "beach",
                      "r0": r0_beach - FADE_IN},
                     {"id": "pier", "label": "when Jack stops at the dock end (READY)", "kind": "ready", "r0": 0}]
                    if lineup else
                    [{"id": "pier", "label": "when Jack stops at the dock end (READY)", "kind": "ready", "r0": 0},
                     {"id": "beach", "label": "at the beach load", "kind": "beach", "r0": r0_beach}]),
        "axes": axes_lineup() if lineup else axes_def(grades), "groups": groups,
        **({"axes_head": "Presets by your beach timing. Pick how late your first step is (tight first turn, then hug "
                         "the small wall; a loose turn you correct by turning up costs up to half a second), then your "
                         "2nd cut onto the pier. Each pick has its own best cast; ★ = best 2nd cut for that wait."}
           if lineup else {}),
        **({"members_cols": ["line", "k_off", "ready_rel", "house", "cross", "cut1", "cut2", "w"], "members": member_rows}
           if grades else {}),
    })


# v31.27 / v31.28 (2026-11-22): the "dog side" pier edge and the "sleeping dog under the pier" restart rule are true for the
# dog-beach save (0d78b95b, dog asleep under the pier) only; other saves (beach-lineup2: dog on the open beach) get
# neutral wording. Applied to the route's texts, never to its data (lines, line_info, dw).
_DOGBEACH_ONLY = [("near edge (dog side)", "near edge"),
                  ("at the dock end on the side nearest the dog (z 170–176)", "at the near edge of the dock end (z 170–176)"),
                  (" If Jack stops dead on the pier, you cut too early and touched the sleeping dog under it: that attempt"
                   " is not in the table - restart.", " If your down-right cut misses the pier, that attempt is not in the"
                   " table - restart."),
                  # v31.28: with the dog off the pier (beach-lineup2) the pier window is 22 VIs = 11 game frames, not 7
                  # (emulator scan 2026-11-22, D 84 and 86: stops z 155-176 in frames 1-6, 182-188 in 7-8, 194-196 in
                  # 9-11); the bands themselves are by z and unchanged.
                  ("down-right in the first 2 frames of the pier window: Jack stops at the near edge of the dock end"
                   " (z 170–176)", "down-right in the first 6 frames of the pier window: Jack stops at the near edge of"
                   " the dock end (z 155–176)"),
                  ("down-right in frames 3–4 of the pier window", "down-right in frames 7–8 of the pier window"),
                  ("down-right in frames 5–7 of the pier window", "down-right in frames 9–11 of the pier window")]


def _save_texts(save, route):
    if "dogbeach" in (save or ""):
        return route

    def fix(o):
        if isinstance(o, dict):
            return {k: (v if k in ("lines", "line_info", "dw", "members") else fix(v)) for k, v in o.items()}
        if isinstance(o, list):
            return [fix(v) for v in o]
        if isinstance(o, str):
            for x, y in _DOGBEACH_ONLY:
                o = o.replace(x, y)
        return o
    return fix(route)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("results")
    ap.add_argument("--id", required=True)
    ap.add_argument("--label", required=True)
    ap.add_argument("--note", default="")
    ap.add_argument("--out", default=str(ROOT / "webapp" / "assets" / "lucky_routes.json"))
    ap.add_argument("--lineup", action="store_true", help="lineup lab results (D 84 + beach waits): wait x 2nd cut "
                    "presets, fade-in and dock-end starts")
    ap.add_argument("--save", default="nohorse-dogbeach-nopickup_0d78b95b")
    ap.add_argument("--howto", default=None)
    ap.add_argument("--grades", action="store_true", help="add cabin / crossroads travel grades (member rows, groups built "
                    "in the app); measured 2026-11-14: no real edge on the fast zone (see HM64_DOGBEACH_SAVE.md)")
    ap.add_argument("--variant-of", default=None, help="this table is a variant of that route id (the app shows it as a "
                    "checkbox on that route, e.g. sparrows at the door)")
    ap.add_argument("--variant", default=None, help="variant name, e.g. sparrows")
    ap.add_argument("--extra", nargs="*", default=[], help="older result folders of the same save: their cast states "
                    "fill bites 1-2 where this run has none (matched by game-state hash)")
    ap.add_argument("--every-bite", action="store_true", help="pack bites 3+ (runs with bite_until, zigzag-4f+)")
    ap.add_argument("--dogwatch", action="store_true", help="pack every line's dog trace (observe runs) for the v30 "
                    "dog-watch")
    ap.add_argument("--houses", default=None, help="only these house arrivals (house VIs, comma-separated), e.g. "
                    "1046,1048 = the door-sparrow mornings of the lineup-sparrow run")
    a = ap.parse_args()
    houses = [int(x) for x in a.houses.split(",")] if a.houses else None
    entry = build(a.results, a.id, a.label, a.note, a.grades, save=a.save, howto=a.howto, lineup=a.lineup,
                  houses=houses, extra=a.extra, every_bite=a.every_bite, dogwatch=a.dogwatch)
    if a.variant_of:
        entry["variant_of"], entry["variant"] = a.variant_of, a.variant or "variant"
    out = Path(a.out)
    routes = json.loads(out.read_text())["routes"] if out.exists() else []
    routes = [r for r in routes if r["id"] != entry["id"]] + [entry]
    out.write_text(json.dumps({"routes": routes}, separators=(",", ":")))
    s = entry["source"]
    print(f"{entry['id']}: {s['lines_with_casts']} of {s['lines']} dog lines with casts, {s['members']} member routes, "
          f"{s['casts']} cast states (Nut b1 {s['nut1']}, b2 {s['nut2']}), repeat checks {s['repeat_checks']} -> {out} "
          f"({out.stat().st_size // 1024} KB)" + (f"; houses {s['houses']} = {100 * s['share_of_run']:.1f}% of the run"
                                                     if "houses" in s else ""))
    for g in entry["groups"]:
        print(f"  {g['id']:<22s} share {g['share']:.3f} cover {g['cover']:.3f}  variants "
              + " ".join(f"{a} {len(v)}" for a, v in g["v"].items()))


if __name__ == "__main__":
    main()
