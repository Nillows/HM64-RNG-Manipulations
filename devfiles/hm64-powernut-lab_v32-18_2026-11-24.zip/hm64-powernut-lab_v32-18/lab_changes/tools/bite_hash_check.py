"""Does a bite's state hash fix its future? (v32.18, 2026-11-24, the rain120 runs)

  python3 -I tools/bite_hash_check.py FULLDAY_DIR [FULLDAY_DIR ...]

Cast hashes cast more than once (in two windows or by two lines) and bite hashes seen more than once: do their futures
(the first 3 bites; the catch, gap and catch of the next bite) agree? Sunny runs: always. Rainy runs: cast hashes always,
bite hashes not always (the weather sprites draw random numbers every frame and are not in cast_hash), so
tools/dogcast_pack.py splits those (split_bite_states)."""
import glob, json, os, sys, collections
def undelta(d):
    out, k = [], 0
    for i in range(0, len(d), 2):
        k = d[i] if i == 0 else k + d[i]
        out.append((k, d[i + 1]))
    return out
res = sys.argv[1:]
castfut = collections.defaultdict(set)   # cast hash -> set of futures (rel first bite, catches, gaps)
castcnt = collections.Counter()
bitefut = collections.defaultdict(set)
bitecnt = collections.Counter()
rows = 0
for d in res:
    for fp in sorted(glob.glob(os.path.join(d, "FD_casts_b*.jsonl"))):
        for l in open(fp):
            r = json.loads(l)
            hs = {int(k): h for k, h in r["_job"]["casts"]}
            for c in r.get("casts", []):
                rows += 1
                k, bs, end = c["k"], c["b"], c["e"][0]
                H = 12  # compare up to the horizon common to all: first 3 bites relative
                fut = tuple((b[0] - k, b[1]) for b in bs[:3])
                h = hs.get(k)
                if h:
                    castfut[h].add((fut, min(end - k, 99999)))
                    castcnt[h] += 1
                for i, b in enumerate(bs[:-1]):
                    nb = bs[i + 1]
                    bitefut[b[2]].add((b[1], nb[0] - b[0], nb[1]))
                    bitecnt[b[2]] += 1
# cast hashes seen more than once: do the first-3-bite futures agree (on the common horizon)?
def agree(futs):
    fs = list(futs)
    ref = None
    for fut, end in fs:
        for fut2, end2 in fs:
            lim = min(end, end2)
            a = [x for x in fut if x[0] < lim]; b = [x for x in fut2 if x[0] < lim]
            n = min(len(a), len(b))
            if a[:n] != b[:n] or (len(a) != len(b) and n < 3):
                return False
    return True
multi = [h for h in castcnt if castcnt[h] > 1]
bad = [h for h in multi if not agree(castfut[h])]
print(f"{rows} casts; cast hashes cast more than once: {len(multi)} ({sum(castcnt[h] for h in multi)} casts); futures differ: {len(bad)} ({sum(castcnt[h] for h in bad)} casts)")
mb = [h for h in bitecnt if len(bitefut[h]) and bitecnt[h] > 1]
bb = [h for h in mb if len(bitefut[h]) > 1]
print(f"bite hashes with a next bite seen more than once: {len(mb)} ({sum(bitecnt[h] for h in mb)} bites); catch/next differ: {len(bb)} ({sum(bitecnt[h] for h in bb)} bites)")
