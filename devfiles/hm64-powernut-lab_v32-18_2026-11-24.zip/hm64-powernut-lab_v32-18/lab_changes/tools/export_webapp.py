"""
Build the v28 Dog Oracle web app: lab results -> one self-contained offline HTML.

  python3 tools/export_webapp.py --truth results/pulse-mac --casts results/oracle-mac [results/casttables ...]
         [--sprites catalog.json|HM64_v27_7a_OFFLINE_OBSERVER.html] [--names user_names_keys.json]
         [--out webapp/build]

Everything is in PATH TIME: the VI (60 Hz) timeline of one dog path's representative arrival
(W_lines). An arrival on that path at offset o sees path VI = its own VI after READY + o
(t=1 = first VI after READY). Arrivals on one path show the same dog at the same path VI, and
casting at the same path VI gives the same outcome (checked here; conflicts are counted).

Cast data per path and VI v ("press B so that it is first read during VI v"):
  n1/b1  bite 1: Nut (1) / fish (0) / unknown (.) and the path VI the bite shows (window start)
  n2/b2  bite 2 after holding B through bite 1 (casttables preset, hold_bites=2), else unknown
Release: every release poll bite+0..bite+19 gives the same catch (all 1,734 mapped windows).
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import re
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from tools.strategy_lab import NUT_CURVE, POSE_GROUPS, Truth  # noqa: E402
from tools import pace as pace_tables  # noqa: E402

TEMPLATE = ROOT / "webapp" / "HM64_Dog_Oracle_v28_template.html"
VERSION = "v31.30"


def load_jsonl(p):
    with open(p) as f:
        return [json.loads(x) for x in f if x.strip()]


def ladder_segments(dirs):
    """{signature: segments [t0,t1,screen,class,base]} from cast-table ladders (K2 = awake, longest first)."""
    out = {}
    for d in dirs:
        for name in ("K2_ladder.jsonl", "K_ladder.jsonl"):
            p = Path(d) / name
            if p.exists():
                for r in load_jsonl(p):
                    seg = r.get("segments") or []
                    if "_error" not in r and seg and (r["signature"] not in out or seg[-1][1] > out[r["signature"]][-1][1]):
                        out[r["signature"]] = seg
    return out


def path_tables(tr, ladders=None):
    """Path timelines (runs in path VI) and arrivals. Ladders of the representative arrivals (offset 0) extend the
    timelines past the observe run's horizon (awake ladders reach ~184 s)."""
    roots = sorted(tr.rep_of_root, key=lambda r: tr.line_no.get(r, 99))
    pidx = {r: k for k, r in enumerate(roots)}
    per = defaultdict(dict)                       # path -> {vi: (scr, cls, base)}
    conflicts = 0
    arrivals = []
    early = defaultdict(int)
    for i in sorted(range(len(tr.sigs)), key=lambda i: int(tr.offset[i])):   # representative (offset 0) first
        s = tr.sigs[i]
        root = int(tr.wl[i])
        if root not in pidx or tr.rep[i] is None:
            continue
        k, o = pidx[root], int(tr.offset[i])
        arr = [k, o, round(float(tr.w[i]), 3), s, []]
        arrivals.append(arr)
        m = per[k]
        last_conf = 0
        for t0, t1, scr, cls, base in tr.runs[i]:
            for t in range(max(t0, 1), min(t1, tr.T + 1)):
                v = (scr, -1 if cls is None else cls, base)
                old = m.get(t + o)
                if old is None:
                    m[t + o] = v
                elif old[:2] != v[:2]:            # same sprite class + facing = looks the same
                    conflicts += 1
                    early[min(t // 60, 9)] += 1
                    last_conf = max(last_conf, t)
        if last_conf:                             # this arrival's own first moments differ: keep its head
            arr[4] = [[t0, min(t1, last_conf + 1), scr, -1 if cls is None else cls, base]
                      for t0, t1, scr, cls, base in tr.runs[i] if t0 <= last_conf]
    ext = {"added_vi": 0, "overlap_vi": 0, "overlap_diff": 0}
    for k, root in enumerate(roots):
        seg = (ladders or {}).get(tr.rep_of_root[root])
        if not seg:
            continue
        m = per[k]
        for t0, t1, scr, cls, base in seg:
            for t in range(max(t0, 1), t1):
                v = (scr, -1 if cls is None else cls, base)
                old = m.get(t)
                if old is None:
                    m[t] = v
                    ext["added_vi"] += 1
                else:
                    ext["overlap_vi"] += 1
                    ext["overlap_diff"] += old[:2] != v[:2]
    if ladders:
        print("ladder extension:", ext)
    if conflicts:
        print("visible differences by seconds after the arrival's READY:", dict(sorted(early.items())),
              "- kept as per-arrival heads:", sum(1 for a in arrivals if a[4]), "arrivals")
    paths = []
    for k, root in enumerate(roots):
        m = per[k]
        lo, hi = min(m), max(m)
        runs, gaps = [], 0
        for v in range(lo, hi + 1):
            x = m.get(v)
            if x is None:
                gaps += 1
                x = (-1, -1, -1)
            if runs and tuple(runs[-1][2:4]) == x[:2] and runs[-1][1] == v:
                runs[-1][1] = v + 1
            else:
                runs.append([v, v + 1, *x])
        w = sum(a[2] for a in arrivals if a[0] == k)
        paths.append({"id": k, "line": tr.line_no.get(root), "rep": tr.rep_of_root[root], "weight": round(w, 2),
                      "lo": lo, "hi": hi + 1, "runs": runs, "gaps": gaps})
    return paths, arrivals, conflicts


def nap_points(dirs):
    """{signature: first cast poll that failed because the farmer was napping (player action 9 = IDLE_NAP)}.
    player.c: playerIdleCounter counts idle game frames; at 1200 (40 s) startAction(IDLE_NAP); any button only wakes him."""
    out = {}
    for d in dirs:
        for name in ("K_casts.jsonl", "B_natural.jsonl"):
            p = Path(d) / name
            if p.exists():
                for r in load_jsonl(p):
                    if r.get("status") == "cast_failed" and r.get("player_action") == 9 and not r.get("whistles"):
                        out[r["signature"]] = min(out.get(r["signature"], 10 ** 9), r["cast"])
    return out


def cast_records(dirs):
    """{signature: {cast_poll: (n1, b1_poll, n2, b2_poll)}} from B/P (oracle) and K (casttables) runs."""
    out = defaultdict(dict)
    for d in dirs:
        for name in ("B_natural.jsonl", "P_parity.jsonl", "K_casts.jsonl", "K_parity.jsonl", "K2_casts.jsonl", "K2_parity.jsonl"):
            p = Path(d) / name
            if not p.exists():
                continue
            for r in load_jsonl(p):
                if "_error" in r or r.get("whistles") or r.get("status") != "ok" or r.get("bite_poll") is None:
                    continue
                bites = r.get("bites") or [{"bite_poll": r["bite_poll"],
                                            "nut": bool(r["nut_releases"]) or "nut" in r["probes"].values()}]
                b1 = bites[0]
                b2 = bites[1] if len(bites) > 1 and bites[1].get("bite_poll") is not None else None
                new = (int(b1["nut"]), b1["bite_poll"], None if b2 is None else int(b2["nut"]),
                       None if b2 is None else b2["bite_poll"])
                old = out[r["signature"]].get(r["cast"])
                if old is None or (old[2] is None and new[2] is not None):
                    out[r["signature"]][r["cast"]] = new
    return out


def path_casts(paths, arrivals, recs):
    """Per path, per VI: outcome of pressing B first read in that VI (all arrivals pooled)."""
    by_sig = {a[3]: (a[0], a[1]) for a in arrivals}
    per = defaultdict(dict)                       # path -> {vi_of_poll: rec}
    conflicts, used = 0, set()
    for sig, T in recs.items():
        if sig not in by_sig:
            continue
        k, o = by_sig[sig]
        used.add(sig)
        for c, rec in T.items():
            v = c + 1 + o                         # poll c is read during VI c+1
            shifted = (rec[0], rec[1] + 1 + o, rec[2], None if rec[3] is None else rec[3] + 1 + o)
            old = per[k].get(v)
            if old is None:
                per[k][v] = shifted
            elif old[:2] != shifted[:2]:
                conflicts += 1
            elif old[2] is None and shifted[2] is not None:
                per[k][v] = shifted
    out = []
    for p in paths:
        m = per.get(p["id"])
        if not m:
            out.append(None)
            continue
        votes = defaultdict(int)                  # game frame pairing from tested odd neighbours of wins
        for v, rec in m.items():
            if rec[0] and v % 2 == 1:             # even poll c -> odd VI
                lo, hi = m.get(v - 1), m.get(v + 1)
                if hi is not None and lo is not None and (hi[0] != lo[0]):
                    votes[+1 if hi[0] else -1] += 1
        parity = max(votes, key=votes.get) if votes and len(votes) == 1 else None
        lo, hi = min(m), max(m) + 1
        filled = dict(m)
        if parity is not None:
            for v in range(lo, hi + 1):
                if v not in filled and v % 2 == 0:  # untested odd poll -> the game frame it shares
                    rep = v - parity
                    if rep in m:
                        filled[v] = m[rep]
        hi = max(filled) + 1
        n1 = "".join("." if filled.get(v) is None else str(filled[v][0]) for v in range(lo, hi))
        n2 = "".join("." if filled.get(v) is None or filled[v][2] is None else str(filled[v][2]) for v in range(lo, hi))
        b1 = [-1 if filled.get(v) is None else filled[v][1] - v for v in range(lo, hi)]
        b2 = [-1 if filled.get(v) is None or filled[v][3] is None else filled[v][3] - v for v in range(lo, hi)]
        out.append({"lo": lo, "n1": n1, "b1": b1, "n2": n2 if "1" in n2 or "0" in n2 else "",
                    "b2": b2 if "1" in n2 or "0" in n2 else [], "parity": parity,
                    "tested": len(m), "wins1": n1.count("1"), "wins2": n2.count("1"),
                    "votes": dict(votes)})
    return out, conflicts, len(used)


def anim_stats(paths, class_of, flicker_vi=21, horizon=4500):
    """Per animation base: median on-screen length (VI, route-weighted, from its onset), appearances per minute,
    and a class: 'flicker' (median < flicker_vi ~ 0.35 s: too short to log reliably), 'never' (not on any dock path)."""
    import statistics
    dur, seen, tot = defaultdict(list), defaultdict(float), sum(p["weight"] for p in paths) or 1
    for p in paths:
        w = p["weight"] / tot
        seq = []
        for t0, t1, sc, cl, b in p["runs"]:
            if b < 0 or t0 < 1 or t0 >= horizon:
                continue
            if seq and seq[-1][2] == b:
                seq[-1][1] = t1
            else:
                seq.append([t0, t1, b])
        for t0, t1, b in seq[1:]:                 # the pose showing at READY has no onset
            dur[b].append((t1 - t0, w))
            seen[b] += w
    out = {}
    for b in sorted({int(k.split("_")[0]) for k in class_of}):
        xs = sorted(dur.get(b, []))
        if not xs:
            out[str(b)] = {"medianVI": None, "perMin": 0, "class": "never"}
            continue
        W, acc, med = sum(w for _, w in xs), 0, xs[-1][0]
        for x, w in xs:
            acc += w
            if acc >= W / 2:
                med = x
                break
        out[str(b)] = {"medianVI": med, "perMin": round(seen[b] / (horizon / 3600), 2),
                       "class": "flicker" if med < flicker_vi else "ok"}
    return out


def release_window(dirs):
    rel = []
    for d in dirs:
        for name in ("B_natural.jsonl", "P_parity.jsonl"):
            p = Path(d) / name
            if p.exists():
                for r in load_jsonl(p):
                    w = r.get("window_outcomes")
                    if w and "n" in w["codes"]:
                        f = w["from_poll"] - r["bite_poll"]
                        idx = [i for i, ch in enumerate(w["codes"]) if ch == "n"]
                        rel.append((f + idx[0], f + idx[-1]))
    if not rel:
        return {"first": 0, "last": 19, "mapped": 0}
    return {"first": max(a for a, _ in rel), "last": min(b for _, b in rel), "mapped": len(rel)}


def sprites(src):
    if not src or not Path(src).exists():
        return {}
    txt = Path(src).read_text()
    if src.endswith(".html"):
        m = re.search(r'<script id="embedded" type="application/json">(.*?)</script>', txt, re.S)
        data = json.loads(m.group(1)) if m else {}
        ents = data.get("manifest", data).get("entries", []) if isinstance(data, dict) else []
    else:
        ents = json.loads(txt)["entries"]
    dirs = "S,SW,W,NW,N,NE,E,SE".split(",")
    out = {}
    for e in ents:
        if e.get("gif") and e.get("screenFacing") in dirs:
            out[f'{e["base"]}_{dirs.index(e["screenFacing"])}'] = e["gif"]
    return out


def render_html(data, out):
    """Write <out>/HM64_Dog_Oracle_<VERSION>_data.json and the single-file app; returns (path, html)."""
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    data["version"] = VERSION
    data["generated"] = dt.date.today().isoformat()            # the day this file was built (was left at the first export's date)
    js = json.dumps(data, separators=(",", ":"))
    (out / f"HM64_Dog_Oracle_{VERSION.replace('.', '_')}_data.json").write_text(js)
    core = (ROOT / "webapp" / "hm64_core_v28.js").read_text()
    app = (ROOT / "webapp" / "hm64_app_v28.js").read_text()
    lucky_js = (ROOT / "webapp" / "hm64_lucky_v29.js").read_text()
    dw_js = (ROOT / "webapp" / "hm64_dogwatch_v30.js").read_text()      # v30 dog-watch core (before the Lucky Timer)
    html = (TEMPLATE.read_text().replace("/*__HM64_DATA__*/null", js.replace("</", "<\\/"))
            .replace("<!--__HM64_CORE__-->", "<script>\n" + core + "\n</script>")
            .replace("<!--__HM64_APP__-->", "<script>\n" + app + "\n</script>")
            .replace("<!--__HM64_LUCKY__-->", "<script>\n" + dw_js + "\n</script>\n<script>\n" + lucky_js + "\n</script>")
            .replace("<!--__HM64_DOGREF__-->", "<script>\n" + (ROOT / "webapp" / "hm64_dogref_v31.js").read_text() + "\n</script>")
            .replace("__HM64_VERSION__", VERSION))
    assert "__HM64_" not in html.replace("__HM64_DATA__", ""), "template placeholder left"
    dest = out / f"HM64_Dog_Oracle_{VERSION.replace('.', '_')}.html"
    dest.write_text(html)
    return dest, html


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--truth", required=True)
    ap.add_argument("--casts", nargs="+", default=[])
    ap.add_argument("--sprites", default=None)
    ap.add_argument("--names", default=None)
    ap.add_argument("--out", default=str(ROOT / "webapp" / "build"))
    ap.add_argument("--jack", default=str(ROOT / "webapp" / "assets" / "jack_fishing.json"),
                    help="Thomas's Jack fishing frames for the Lucky Timer (tools/build_jack_assets.py); 'none' = stick figure")
    ap.add_argument("--routes", default=str(ROOT / "webapp" / "assets" / "lucky_routes.json"),
                    help="extra Lucky Timer routes (tools/route_tables.py) or 'none'")
    ap.add_argument("--beach", default=str(ROOT / "webapp" / "assets" / "beach_ready.json"),
                    help="Thomas's empty-pier screenshot for the Lucky Timer (tools/build_beach_asset.py); 'none' = drawn water")
    ap.add_argument("--lucky", default="auto",
                    help="lucky_tables.json from the lucky preset (Lucky Timer whistle plans); 'auto' = newest in --casts dirs")
    a = ap.parse_args()
    tr = Truth(Path(a.truth))
    cdirs = [a.truth] + list(a.casts)
    paths, arrivals, vis_conf = path_tables(tr, ladder_segments(cdirs))
    casts, cast_conf, used = path_casts(paths, arrivals, cast_records(cdirs))
    naps = nap_points(cdirs)
    by_sig = {a[3]: (a[0], a[1]) for a in arrivals}
    for sig, c in naps.items():                      # path VI of the first napping press (poll c read in VI c+1)
        if sig in by_sig:
            k, o = by_sig[sig]
            if casts[k] is not None:
                casts[k]["nap_vi"] = min(casts[k].get("nap_vi", 10 ** 9), c + 1 + o)
    eq = json.loads((ROOT / "hm64" / "data" / "sprite_equivalence.json").read_text())
    names = {"names": {}, "keys": {}}
    if a.names and Path(a.names).exists():
        names = json.loads(Path(a.names).read_text())
    lucky = None
    lp = a.lucky
    if lp == "auto":
        cands = [Path(d) / "lucky_tables.json" for d in cdirs if (Path(d) / "lucky_tables.json").exists()]
        lp = str(max(cands, key=lambda q: q.stat().st_mtime)) if cands else None
    if lp and lp != "none" and Path(lp).exists():
        lucky = json.loads(Path(lp).read_text())
        print(f"lucky tables: {lp} ({', '.join(str(x['k']) + ' whistle(s): ' + str(len(x['series'])) + ' series' for x in lucky['plans'])})")
    pace = pace_tables.build(a.truth, by_sig)
    print("pace groups (slack before the dog lands): " + ", ".join(
        f"{g['label']} {g['lo']}-{g['hi']} polls: {g['routes']} routes ({len(g['dog'])} dog-anchored variants)"
        for g in pace["groups"]))
    data = {
        "version": VERSION, "generated": dt.date.today().isoformat(), "lucky": lucky, "pace": pace,
        "jack": json.loads(Path(a.jack).read_text()) if a.jack != "none" and Path(a.jack).exists() else None,
        "beach": json.loads(Path(a.beach).read_text()) if a.beach != "none" and Path(a.beach).exists() else None,
        "lroutes": (json.loads(Path(a.routes).read_text())["routes"]
                    if a.routes != "none" and Path(a.routes).exists() else []),
        "dogcast": (json.loads((ROOT / "webapp" / "assets" / "dogcast.json").read_text())
                    if (ROOT / "webapp" / "assets" / "dogcast.json").exists() else None),
        "dirs": eq["dirs_index"].split(","), "class_of": eq["class_by_pose_and_direction"],
        "pose_groups": POSE_GROUPS, "names": names.get("names", {}), "keys": names.get("keys", {}),
        "paths": paths, "arrivals": [x[:3] + [x[4]] for x in arrivals], "arrival_sigs": [x[3] for x in arrivals],
        "casts": casts,
        "release": release_window(cdirs), "nut_curve": NUT_CURVE, "nap_polls": 2400,
        "anim_stats": anim_stats(paths, eq["class_by_pose_and_direction"]),
        "sprites": sprites(a.sprites),
        "checks": {"arrivals": len(arrivals), "paths": len(paths), "head_vi_kept": vis_conf,
                   "cast_conflicts": cast_conf, "arrivals_with_casts": used,
                   "routes_weighted": round(sum(x[2] for x in arrivals), 1)},
    }
    out = Path(a.out)
    dest, html = render_html(data, out)
    ck = data["checks"]
    print(f"{dest}: {ck['paths']} paths, {ck['arrivals']} arrivals ({ck['routes_weighted']} routes), "
          f"arrival-head VIs {ck['head_vi_kept']}, cast conflicts {ck['cast_conflicts']}, "
          f"{len(data['sprites'])} sprites, {len(html) // 1024} KB")
    for p, c in zip(paths, casts):
        if c:
            print(f"  path {p['id']:2d} line {p['line']}: weight {p['weight']:8.1f}  VI {p['lo']}..{p['hi']}  "
                  f"casts VI {c['lo']}..{c['lo'] + len(c['n1'])} ({c['tested']} tested, parity {c['parity']}, "
                  f"votes {c['votes']}) wins bite1 {c['wins1']} bite2 {c['wins2']} nap VI {c.get('nap_vi')}")
        else:
            print(f"  path {p['id']:2d} line {p['line']}: weight {p['weight']:8.1f}  VI {p['lo']}..{p['hi']}  no cast data")


if __name__ == "__main__":
    main()
