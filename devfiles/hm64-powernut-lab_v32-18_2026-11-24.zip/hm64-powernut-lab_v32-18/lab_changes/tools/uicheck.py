#!/usr/bin/env python3
"""HM64 UI lab - CONSISTENCY CHECK (2026-11-21, app v31.25). Browser only: no emulator, no ROM, no save.

Every scenario is one page of the real app in a headless Chromium, driven by uilab/uicheck_driver.js: a seeded random
walk of user actions (keys, clicks, settings) through one or two attempts and the practice drills, with a list of
invariants checked after every action. A violation = the app did something that cannot be right whatever the player
does (see CHECKS below). The seed reproduces a scenario exactly.

  uicheck.py run    --app APP.html --dir OUT --n 2000 [--seed0 1] [--procs 8] [--kinds mixed,free,normal]
  uicheck.py report --dir OUT        -> OUT/UICHECK.md
  uicheck.py one    --app APP.html --seed 123 [--kind free]      (prints one scenario's result)"""
import argparse, concurrent.futures as cf, html as _html, json, os, re, shutil, subprocess, sys, tempfile, time
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
FRAME_MS = os.environ.get("HM64_UILAB_FRAME_MS", "33")
PRE = """<script>(function(){try{localStorage.clear();}catch(e){}
window.__UILAB_RAF=1;window.requestAnimationFrame=function(cb){return window.__UILAB_DONE?0:setTimeout(function(){cb(performance.now());},%s);};
window.__UILAB_SC=%s;})();</script>"""
CHECKS = {
    "T1": "no 'undefined' / 'NaN' / '[object' in the lamp, status line, dog cards, carousel, freestyle text, last-attempt text",
    "P0": "a practice drill starts from its button and stops on Esc",
    "P1": "in a practice drill nothing of an attempt shows: no dog cards, no calibration view, no known-line histogram, no freestyle / wake / double lamp",
    "I1": "idle: no dog cards, no calibration view, no carousel, no forecast popup",
    "N0": "Space starts an attempt", "N1": "a new attempt starts clean: no picked / locked / removed dog, no cast, no bite marks of the last one",
    "C1": "calibration view <=> exactly one card and a dog selected; a picked dog (before the cast) never shares the row; never more cards than the setting",
    "C2": "the selected dog sits left / middle / right as the setting says",
    "M1": "the forecast popup only with 'Mouseover forecast' on",
    "F1": "freestyle: no CAST countdown, no HANDS ON B, the watch never freezes before a cast; outside freestyle no freestyle lamp",
    "F2": "the Freestyle box, the Ctrl key, the setting and the mode agree",
    "F3": "a marked cast is the cast tap",
    "F4": "the declared target is the rule's (nearest double / triple, else group); its bars carry the target catch in the lab data; its release window is the lab's bite",
    "F5": "the pink release line is inside the release window, and absent with the setting off",
    "F6": "Space in freestyle (2+ s after Jack stops) marks the cast",
    "F7": "LAST DOUBLE only when no later double exists",
    "W1": "wake lines sit at READY + n x 33.4 s, none after the last possible cast; WAKE JACK only inside its window and never after a marked cast",
    "K1": "the locked-frame histogram only with a locked dog",
    "D1": "the bars the app draws = an independent walk of the lab data (4 random frames per check)",
    "B1": "Backspace undoes a selection made before the cast",
    "S1": "the start key and the arrows never scroll the page during an attempt",
    "G1": "no edge glow and no lamp pulse with the glow setting off",
    "R0": "H / M / E / Esc end the attempt", "R1": "H / M / E log exactly one record, Esc none; freestyle flag right; a freestyle attempt adds no learning record; every logged attempt has a report",
    "R2": "the report reads without errors or broken text, its call is a known one, its close-up draws",
    "R3": "attempt list and report totals have no broken text", "R4": "remove / undo of an attempt change the list by exactly one",
    "Z1": "a freestyle attempt with no cast stops by itself at the end of the cast data",
}


def run_one(chrome, app_html, driver, sc, budget_ms, tmpdir, timeout=600):
    i = app_html.find("<script>"); j = app_html.rfind("</body>")
    page = app_html[:i] + PRE % (FRAME_MS, json.dumps(sc)) + app_html[i:j] + "<script>" + driver.replace("</", "<\\/") + "</script>" + app_html[j:]
    f = os.path.join(tmpdir, f"s{sc['seed']}.html"); prof = os.path.join(tmpdir, f"p{sc['seed']}")
    open(f, "w", encoding="utf8").write(page)
    cmd = [chrome, "--headless=new", "--no-sandbox", "--disable-gpu", "--disable-dev-shm-usage", "--hide-scrollbars", "--mute-audio", "--window-size=1440,900",
           f"--user-data-dir={prof}", f"--virtual-time-budget={int(budget_ms)}", "--dump-dom", "file://" + f]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        m = re.search(r'<pre id="testout">(.*?)</pre>', r.stdout, re.S)
        res = json.loads(_html.unescape(m.group(1))) if m else {"seed": sc["seed"], "kind": sc["kind"], "errors": [f"no output from the page ({len(r.stdout)} bytes of DOM)"], "noout": True}
    except Exception as e:                                         # noqa: BLE001
        res = {"seed": sc["seed"], "kind": sc["kind"], "errors": [f"browser: {e}"], "noout": True}
    finally:
        try:
            os.remove(f)
        except OSError:
            pass
        shutil.rmtree(prof, ignore_errors=True)
    return res


def chrome_of(a):
    c = a.chrome or os.environ.get("HM64_CHROME") or next((c for c in ("chromium", "chromium-browser", "google-chrome") if shutil.which(c)), None)
    if not c:
        sys.exit("no Chromium found (set HM64_CHROME)")
    return c


def load(p):
    return [json.loads(l) for l in open(p)] if os.path.exists(p) else []


def cmd_run(a):
    out = Path(a.dir); out.mkdir(parents=True, exist_ok=True)
    app_html = Path(a.app).read_text(encoding="utf8"); driver = (ROOT / "uilab" / "uicheck_driver.js").read_text(encoding="utf8")
    chrome = chrome_of(a); kinds = a.kinds.split(",")
    done = {r["seed"] for r in load(out / "check.jsonl") if not r.get("noout")}
    jobs = [dict(seed=s, kind=kinds[s % len(kinds)], route=a.route) for s in range(a.seed0, a.seed0 + a.n) if s not in done]
    json.dump(dict(app=os.path.basename(a.app), n=a.n, seed0=a.seed0, kinds=kinds, route=a.route, frame_ms=FRAME_MS), open(out / "plan.json", "w"))
    print(f"[check] {a.n} scenarios (seeds {a.seed0}..{a.seed0 + a.n - 1}), {len(jobs)} to run, {a.procs} browsers at a time ({chrome})", flush=True)
    tmp = tempfile.mkdtemp(prefix="uicheck-", dir="/dev/shm" if os.path.isdir("/dev/shm") else None)
    t0 = time.time(); n = nv = ne = 0
    try:
        with cf.ThreadPoolExecutor(max_workers=a.procs) as ex, open(out / "check.jsonl", "a") as f:
            futs = {ex.submit(run_one, chrome, app_html, driver, sc, a.budget, tmp, 3000): sc for sc in jobs}   # v31.29: 1500 s cut 13 long scenarios of check1
            for fu in cf.as_completed(futs):
                res = fu.result(); f.write(json.dumps(res) + "\n"); f.flush()
                n += 1; nv += bool(res.get("viol")); ne += bool(res.get("errors"))
                if n % 25 == 0 or n == len(jobs):
                    el = time.time() - t0
                    print(f"[check] {n}/{len(jobs)}  ({el / 60:.1f} min; {nv} scenarios with a violation, {ne} with an error; ETA {el / n * (len(jobs) - n) / 60:.0f} min)", flush=True)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def cmd_one(a):
    app_html = Path(a.app).read_text(encoding="utf8"); driver = (ROOT / "uilab" / "uicheck_driver.js").read_text(encoding="utf8")
    tmp = tempfile.mkdtemp(prefix="uicheck-")
    try:
        print(json.dumps(run_one(chrome_of(a), app_html, driver, dict(seed=a.seed, kind=a.kind, route=a.route), a.budget, tmp), indent=1))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def cmd_report(a):
    d = Path(a.dir); rows = {}
    for r in load(d / "check.jsonl"):
        if r["seed"] not in rows or not r.get("noout"):
            rows[r["seed"]] = r
    rows = [rows[k] for k in sorted(rows)]
    plan = json.load(open(d / "plan.json")) if (d / "plan.json").exists() else {}
    ok = [r for r in rows if not r.get("noout")]
    L = [f"# HM64 UI lab - consistency check ({plan.get('app', '?')})", "",
         f"Scenarios: {len(rows)} ({len(ok)} played, {len(rows) - len(ok)} gave no output). Actions played: {sum(r.get('steps', 0) for r in ok):,}. "
         f"With a violation: **{sum(bool(r.get('viol')) for r in ok)}**. With a script error: **{sum(bool(r.get('errors')) for r in ok)}**.", ""]
    L += ["## 1 Violations by check", "", "| check | what must hold | scenarios | first seeds | example |", "|---|---|---|---|---|"]
    by = defaultdict(list)
    for r in ok:
        for v in r.get("viol", []):
            by[v["id"]].append((r["seed"], v))
    for cid in sorted(by):
        seeds = [s for s, _ in by[cid]]; ex = by[cid][0][1]
        L.append(f"| {cid} | {CHECKS.get(cid.split('.')[0], '')} | {len(seeds)} | {' '.join(map(str, seeds[:6]))} | {ex['msg']} (after `{ex['after']}`) |")
    if not by:
        L.append("| - | no violation in any scenario | 0 | | |")
    L += ["", "Checks with no violation: " + ", ".join(k for k in CHECKS if not any(c.split('.')[0] == k for c in by)), ""]
    L += ["## 2 Script errors", ""]
    ec = Counter(re.sub(r"\d+", "#", e)[:150] for r in ok for e in r.get("errors", []))
    L += [f"- {n} x `{e}`" for e, n in ec.most_common(20)] or ["none"]
    L += ["", "## 3 What was exercised", "", "| | scenarios | times |", "|---|---|---|"]
    cov = Counter(); covs = Counter()
    for r in ok:
        for k, v in r.get("cov", {}).items():
            cov[k] += v; covs[k] += 1
    for k in sorted(cov):
        L.append(f"| {k} | {covs[k]} | {cov[k]:,} |")
    L += ["", "## 4 Settings covered (scenarios, and those with a violation)", ""]
    for key in ("start", "free", "tgt", "cards", "fill", "rel", "glow", "peek", "strict", "spar", "second", "drill", "end"):
        c = Counter(str(r.get("set", {}).get(key)) for r in ok); cv = Counter(str(r.get("set", {}).get(key)) for r in ok if r.get("viol"))
        L.append(f"- **{key}**: " + " · ".join(f"{k} {c[k]} ({cv[k]})" for k in sorted(c)))
    L += ["", "## 5 Violations by setting (share of scenarios with any violation)", ""]
    for key in ("start", "free", "drill", "second", "end", "tgt"):
        c = Counter(str(r.get("set", {}).get(key)) for r in ok); cv = Counter(str(r.get("set", {}).get(key)) for r in ok if r.get("viol"))
        L.append(f"- {key}: " + " · ".join(f"{k} {100 * cv[k] / c[k]:.0f}%" for k in sorted(c) if c[k]))
    L += ["", "## 6 The checks", ""] + [f"- **{k}** {v}" for k, v in CHECKS.items()]
    L += ["", "Reproduce one scenario: `python3 tools/uicheck.py one --app APP.html --seed N --kind K` (kind = the scenario's `kind`).", ""]
    (d / "UICHECK.md").write_text("\n".join(L), encoding="utf8")
    print("\n".join(L[:14 + len(by)]))


def main():
    ap = argparse.ArgumentParser(); sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("run", "one", "report"):
        p = sub.add_parser(name)
        p.add_argument("--app"); p.add_argument("--dir"); p.add_argument("--n", type=int, default=200); p.add_argument("--seed0", type=int, default=1)
        p.add_argument("--seed", type=int, default=1); p.add_argument("--kind", default="mixed"); p.add_argument("--kinds", default="mixed,free,mixed,normal")
        p.add_argument("--procs", type=int, default=4); p.add_argument("--route", default="lineup-lineup2"); p.add_argument("--budget", type=int, default=380000); p.add_argument("--chrome")
    a = ap.parse_args()
    {"run": cmd_run, "one": cmd_one, "report": cmd_report}[a.cmd](a)


if __name__ == "__main__":
    main()
