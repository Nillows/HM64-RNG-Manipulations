/* headless (v32.5): the Dog practice page. Each drill runs end to end with synthetic keys, and the scoring is checked
   against the truth the drill knows: tune (a card put exactly in step scores 0 frames; off by n scores n), read (keys
   simulated from the true dog by HM64DogWatch.simulateLogs, Enter picks the top card), whole (tap, Enter, tune to the
   truth, cast on a Nut frame of the true arrival, release at the Nut bite -> the Power Nut). */
(function () {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const key = (type, code, k, extra) => { const e = new KeyboardEvent(type, Object.assign({ code, key: k, bubbles: true, cancelable: true }, extra || {})); document.dispatchEvent(e); return e.defaultPrevented; };
  setTimeout(async () => {
    const X = window.HM64Practice, DW = window.HM64DogWatch, $ = id => document.getElementById(id), out = { errors: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    try {
      out.keys = { src: X.K.src, start: X.K.startKey, adj: X.K.adj, facing: X.K.facing, groups: X.K.groups.length };
      /* 1 tune: put the card exactly in step (the drill's own truth), Enter -> 0 frames; then 3 frames off */
      const tuneOnce = async extra => {
        X.newDrill('tune'); const S = X.S; await sleep(1700);
        const A = X.prep(S.R).Aof.get(S.a.dwi), need = S.a.o - A + S.lag;
        S.adj = 2 * Math.round(need / 2) + 2 * extra; key('keydown', 'Enter', 'Enter'); await sleep(50);
        return { off: S.res.off, eps: +S.res.eps.toFixed(2), tests: S.res.tests.map(t => t.ok), html: $('prReveal').textContent.slice(0, 140) };
      };
      out.tune0 = []; for (let i = 0; i < 6; i++) out.tune0.push(await tuneOnce(0));
      out.tune3 = await tuneOnce(3);
      /* the [ ] keys move the card two VIs a press, Shift ten presses */
      X.newDrill('tune'); await sleep(1700);
      const a0 = X.S.adj; key('keydown', X.K.adj[1], ']'); key('keydown', X.K.adj[1], ']'); key('keydown', X.K.adj[0], '[', { shiftKey: true });
      out.adjKeys = X.S.adj - a0;
      key('keydown', 'Escape', 'Escape');
      /* 2 read: simulated keys from the true dog for 8 s, then Enter = the top card */
      const reads = [];
      for (let n = 0; n < 6; n++) {
        X.newDrill('read'); const S = X.S; await sleep(1650);
        let seed = 12345 + n; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
        const c = X.prep(S.R).cands.find(x => x.dwi === S.a.dwi && x.o === S.a.o);
        const logs = DW.simulateLogs(S.R, c, 2, 480, rnd, { numpad: true });
        S.logs.push(...logs); S._c = null;
        S.base = 500; S.at = performance.now();                    // jump the drill's clock to 8.3 s after READY
        await sleep(30);
        const top = X.comp().lines[0];
        key('keydown', 'Enter', 'Enter'); await sleep(30);
        reads.push({ keys: logs.length, ok: S.res.ok, topP: +top.p.toFixed(3), truthTop: top.dwi === S.a.dwi || (top.fam || []).includes(S.a.dwi) });
      }
      out.read = reads;
      /* 3 whole: tap at READY, Enter (top card), tune to the truth, cast on a Nut frame, release at the Nut bite */
      const wholes = [];
      for (let n = 0; n < 4; n++) {
        X.PS.line = 'any';
        X.newDrill('whole'); const S = X.S;
        await sleep(2650);
        key('keydown', 'Space', ' '); await sleep(20); const lagMs = S.lag * 16.715;
        S.pick = null; X.pick(S.a.dwi, 'test');
        const A = S.pick.A; S.adj = 2 * Math.round((S.a.o + S.lag - A) / 2);
        key('keydown', 'Enter', 'Enter');
        /* a Nut group of the true arrival 1-20 s ahead: cast in the middle of its first frame */
        const key0 = S.R.dw.lines[S.a.dwi].key, gs = X.nutGroups(key0, S.a.o, X.eTrue() + 60, X.eTrue() + 1200);
        if (!gs.length) { wholes.push({ skip: 'no Nut frame ahead' }); key('keydown', 'Escape', 'Escape'); continue; }
        const g = gs[0], eC = 2 * g.i0 + 1;
        await sleep((eC - X.eTrue()) * 16.715);
        key('keydown', 'Space', ' '); await sleep(20);
        const nb = S.cast.rec ? S.cast.rec.nut : -1, b = S.cast.bites[nb];
        if (!b) { wholes.push({ castLab: S.cast.lab, noNut: true, g }); key('keyup', 'Space', ' '); continue; }
        await sleep((b.e + 6 - X.eTrue()) * 16.715);
        key('keyup', 'Space', ' '); await sleep(30);
        wholes.push({ lagMs: Math.round(lagMs), bite: g.b, nutBite: nb + 1, result: S.result, right: S.res.right, tuneOff: S.res.tuneOff, near: S.res.near && S.res.near.d, text: $('prReveal').textContent.slice(0, 120) });
      }
      out.whole = wholes;
      out.stats = $('prStats').textContent.slice(0, 220);
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const p = document.createElement('pre'); p.id = 'testout'; p.textContent = JSON.stringify(out); document.body.appendChild(p);
  }, 600);
})();
