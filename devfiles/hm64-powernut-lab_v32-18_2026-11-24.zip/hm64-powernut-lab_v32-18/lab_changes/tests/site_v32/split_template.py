"""One-time: cut the v28 single-page template into the partials of the v32 site (webapp/site/partials/).
Each partial is an exact slice of the old template, so a page that puts them back in the old order equals the old page."""
import sys
from pathlib import Path
src = Path(sys.argv[1]).read_text()
out = Path(sys.argv[2]); out.mkdir(parents=True, exist_ok=True)
def cut(start, end, incl_end=True):
    i = src.index(start); assert src.count(start) == 1, start
    j = src.index(end, i) + (len(end) if incl_end else 0)
    return i, j
spans = {}
i, j = cut('<style>\n', '</style></head>\n', incl_end=False); spans['app_css'] = (i + len('<style>\n'), j)
spans['ref_arena'] = cut('<main id="refArena">', '</main>\n')
spans['oracle_arena'] = cut('<main id="oracleArena" hidden>', '</main>\n')
spans['lucky_arena'] = cut('<main id="luckyArena" hidden>', '</main>\n')
i, _ = cut('<div id="cueGlow"></div>', '<footer>'); j = src.index('<footer>'); spans['lucky_overlays'] = (i, j)
i = src.index('<div id="kv" hidden>'); j = src.index('<dialog id="helpDlg">'); spans['lucky_dialogs'] = (i, j)
spans['help_dialog'] = cut('<dialog id="helpDlg">', '</dialog>\n')
spans['footer_fit'] = cut('<script>\n/* v30.30: the page keeps clear', '</script>\n')
for k, (a, b) in spans.items():
    (out / f'{k}.html').write_text(src[a:b])
    print(f'{k:16s} {a:6d}-{b:6d} {b - a:6d} chars')
# what is left between the slices (must be only the head, the footer, the script slots and the closing tags)
cov = sorted(spans.values()); pos = 0; left = []
for a, b in cov:
    if a > pos: left.append(src[pos:a])
    pos = b
left.append(src[pos:])
Path(sys.argv[3]).write_text('\n=====\n'.join(left))
