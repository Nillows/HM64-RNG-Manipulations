#!/bin/bash
cd /home/claude/x/v3130/lab
OUT=/home/claude/x/regress32; mkdir -p $OUT
OLD=../build/HM64_Dog_Oracle_v31_30.html; NEW=/tmp/site32/lucky-timer_sunny-no-horse.html
for t in "$@"; do
  timeout 600 bash /tmp/stab/uitest_long.sh $OLD tests/$t.js 120000 > $OUT/${t}_v3130.json 2>&1 &
  timeout 600 bash /tmp/stab/uitest_long.sh $NEW tests/$t.js 120000 tests/pre_site_arena_buttons.js > $OUT/${t}_v32.json 2>&1 &
  wait
  if cmp -s $OUT/${t}_v3130.json $OUT/${t}_v32.json; then echo "$t SAME"; else echo "$t DIFF"; fi
done
