"""Compare the v31.30 single page with the v32 Lucky Timer page: data (as JSON, version/generated aside) and the
rest of the HTML line by line."""
import sys, json, re, difflib
a = open(sys.argv[1]).read(); b = open(sys.argv[2]).read()
def split(h):
    m = re.search(r'<script>const HM64_DATA=(.*?);</script>\n', h, re.S)
    return h[:m.start()] + '<script>const HM64_DATA=…;</script>\n' + h[m.end():], json.loads(m.group(1).replace('<\\/', '</'))
ha, da = split(a); hb, db = split(b)
for k in ('version', 'generated'):
    print(f'data {k}: {da.get(k)} -> {db.get(k)}'); da.pop(k, None); db.pop(k, None)
print('data keys same order:', list(da) == list(db), '| data equal:', da == db)
if da != db:
    for k in da:
        if da[k] != db.get(k): print('  differs:', k)
d = list(difflib.unified_diff(ha.splitlines(), hb.splitlines(), lineterm='', n=0))
print(f'html diff lines: {len(d)}')
for line in d: print(line[:220])
