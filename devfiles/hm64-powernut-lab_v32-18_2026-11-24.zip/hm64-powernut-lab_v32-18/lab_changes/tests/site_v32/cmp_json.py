"""Compare two UI-test outputs after removing what differs between any two runs of one page: file names and line
numbers in error stacks, wall-clock timestamps. Prints the JSON paths that still differ."""
import json, re, sys
def norm(s):
    s = re.sub(r'file:///tmp/ui_[^:\s"]*?\.html:\d+:\d+', 'FILE', s)
    s = re.sub(r'(?<!")\b1[67]\d{11}\b(?!")', '"TS"', s)                   # Date.now() / epoch ms (a JSON number)
    s = re.sub(r'\b1[67]\d{11}\b', 'TS', s)                                 # inside a string
    return s
def load(p):
    t = open(p).read()
    try: return json.loads(norm(t))
    except Exception: return norm(t)
def walk(a, b, path, out):
    if type(a) != type(b): out.append((path, a, b)); return
    if isinstance(a, dict):
        for k in sorted(set(a) | set(b)): walk(a.get(k, '<missing>'), b.get(k, '<missing>'), f'{path}.{k}', out)
    elif isinstance(a, list):
        if len(a) != len(b): out.append((path + '[len]', len(a), len(b)))
        for i, (x, y) in enumerate(zip(a, b)): walk(x, y, f'{path}[{i}]', out)
    elif a != b: out.append((path, a, b))
a, b = load(sys.argv[1]), load(sys.argv[2])
out = []; walk(a, b, '', out)
print(f'{len(out)} differing values')
for p, x, y in out[: int(sys.argv[3]) if len(sys.argv) > 3 else 12]:
    print(f'  {p}: {str(x)[:90]!s} | {str(y)[:90]!s}')
