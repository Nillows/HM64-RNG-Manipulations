#!/bin/bash
cd /home/claude/x/v3130/lab
OUT=/home/claude/x/regress32/castdump; mkdir -p $OUT
for i in "$@"; do
  for v in v32 v3130; do
    if [ $v = v32 ]; then PAGE=/tmp/site32/casting-tables_sunny-no-horse.html; else PAGE=../build/HM64_Dog_Oracle_v31_30.html; fi
    TMO=900 timeout 1000 bash /home/claude/x/scripts/uitest_xl.sh $PAGE tests/ui_castdump.js 20000 /tmp/castset_$i.js > $OUT/${i}_$v.json 2>&1
    rm -f /tmp/ui_ui_castdump_*.html; rm -rf /tmp/chrome_prof_*
  done
  python3 -c "
import json,sys
a=json.load(open('$OUT/${i}_v3130.json')); b=json.load(open('$OUT/${i}_v32.json'))
x=a['combos'][0]; y=b['combos'][0]
d={k:(x[k],y[k]) for k in x if x[k]!=y[k]}
print('$i', x['label'], 'SAME' if not d and not a['errors'] and not b['errors'] else 'DIFF', d, a['errors'], b['errors'])" 2>&1 | cut -c1-300
done
