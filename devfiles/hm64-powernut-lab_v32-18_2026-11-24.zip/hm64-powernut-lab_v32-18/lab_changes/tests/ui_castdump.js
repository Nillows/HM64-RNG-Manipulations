/* headless (v32.0): the casting tables, every setting, as drawn - for comparing the v31 single page's Dog reference
   tab with the hub's Casting tables page. Works on both: on the single page it opens the Dog reference first.
   Output per setting: the route shown, a hash and the length of the whole #rfBody (every tab's pane is in it), the
   numbers of R.shown (the casts, rows and odds the tables are drawn from), and the stopwatch text of the first cast. */
(function () { const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => { const $ = id => document.getElementById(id), out = { errors: [], combos: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    try {
      if ($('arOracle')) { $('arOracle').click(); await sleep(80); }
      const R = window.HM64DogRef;
      const done = () => R.shown && R.shown.all && !/working out/.test($('rfBody').textContent)
        && R.shown.routeId === R.curRoute() && +R.shown.sigMs === +R.state.sig && +R.shown.quick === +R.state.quick;   // the tables of the current settings
      const wait = async () => { for (let i = 0; i < 2400 && !done(); i++) await sleep(50); return done(); };
      const hash = s => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; } return h.toString(16); };
      const round = (k, v) => (typeof v === 'number' ? +v.toPrecision(12) : v);
      const set = async (id, v) => { const e = $(id); e.value = String(v); e.onchange({ target: e }); await sleep(30); };
      const spar = async on => { const e = $('rfSpar'); if (e.checked !== on) { e.checked = on; e.onchange({ target: e }); } await sleep(30); };
      const snap = async label => {
        const ok = await wait(), body = $('rfBody').innerHTML;
        let shown = ''; try { shown = JSON.stringify(R.shown, round); } catch (e) { shown = 'unserialisable: ' + e.message; }
        const c = document.querySelector('#rfBody .rfcast'); let target = null;
        if (c) { c.click(); await sleep(30); target = $('rfTarget').textContent; }
        out.combos.push({ label, ok, route: R.shown && R.shown.routeId, sig: R.state.sig, aim: R.state.aim, quick: R.state.quick,
                          bodyLen: body.length, bodyHash: hash(body), shownLen: shown.length, shownHash: hash(shown),
                          panes: [...document.querySelectorAll('#rfBody .rfpane')].map(p => p.dataset.pane + ':' + p.querySelectorAll('tr').length).join(' '),
                          target });
      };
      out.start = { routes: [...$('rfRoute').options].map(o => o.value), sparDisabled: $('rfSpar').disabled, state: JSON.stringify(R.state) };
      /* every setting in full, so any subset can run on a fresh page (window.CASTDUMP_SET = indices, from a pre-script) */
      const ALL = [['default', false, 150, 'odds', 10], ['sparrows', true, 150, 'odds', 10], ['sparrows sig300', true, 300, 'odds', 10],
                   ['sig300', false, 300, 'odds', 10], ['sig100', false, 100, 'odds', 10], ['sig200', false, 200, 'odds', 10],
                   ['aim quick, quick 10', false, 150, 'quick', 10], ['aim quick, quick 5', false, 150, 'quick', 5],
                   ['aim quick, quick 8', false, 150, 'quick', 8], ['aim quick, quick 12', false, 150, 'quick', 12],
                   ['aim quick, quick 15', false, 150, 'quick', 15], ['sparrows aim quick 8', true, 150, 'quick', 8]];
      const pick = Array.isArray(window.CASTDUMP_SET) ? window.CASTDUMP_SET : ALL.map((x, i) => i);
      for (const i of pick) {
        const [label, sp, sig, aim, quick] = ALL[i];
        await wait(); await spar(sp); await wait();
        if (R.state.sig !== sig) await set('rfSig', sig);
        if (R.state.quick !== quick) await set('rfQuick', quick);
        if (R.state.aim !== aim) await set('rfAim', aim);
        await snap(label);
      }
      out.tEnd = Math.round(performance.now());
      out.vi = (window.HM64LuckyApp && window.HM64LuckyApp.viMs) ? window.HM64LuckyApp.viMs() : window.HM64Core.viMs();
    } catch (e) { out.errors.push('test: ' + e.message + ' ' + (e.stack || '').split('\n')[1]); }
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out, null, 1); document.body.appendChild(pre);
  }, 400);
})();
