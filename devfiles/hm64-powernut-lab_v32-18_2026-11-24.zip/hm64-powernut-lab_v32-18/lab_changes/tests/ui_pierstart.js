/* headless (Opus 2026-11-22, v31.26): the setup the tester README tells people to use — route lineup-lineup2, start
   "when Jack stops at the dock end (READY)" = ONE Space tap at the pier end, dog-watch on. Checks with real key events:
   fresh-browser defaults; one Space starts the attempt and opens the dog-watch; a cast suggestion exists; picking the top
   card -> calibration view + known-line histogram; [ ] tune; Ctrl -> freestyle; wake lines at READY + n x 33.4 s;
   Space on a double marks it; Esc stops unlogged; a normal attempt counts down to CAST. */
(function () {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => {
    const A = window.HM64LuckyApp, C = window.HM64Lucky, $ = id => document.getElementById(id), out = { errors: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    const vi = 33.430 / 2;
    const ev = (type, o) => { const e = new KeyboardEvent(type, Object.assign({ code: 'Space', key: ' ', bubbles: true, cancelable: true }, o || {})); document.dispatchEvent(e); return e.defaultPrevented; };
    const space = () => { ev('keydown'); ev('keyup'); };
    const tNow = () => (performance.now() - A.run.wall0) / vi + 1;
    const tick = () => { if (A.run.wall0 !== null) A.frameOnce(); };
    const lamp = () => ($('lkCueBig') ? $('lkCueBig').textContent : '') + ' | ' + ($('lkCueSub') ? $('lkCueSub').textContent : '');
    const host = () => $('lkCompCards'), cards = () => [...host().querySelectorAll('.lkdog')];
    try {
      localStorage.clear(); $('arLucky').click(); A.L.audio = false;
      out.fresh = { route: $('lkRoute').value, anchor: $('lkAnchor').value, dwOn: $('lkDwOn').checked, free: $('lkFree').checked,
                    routes: [...$('lkRoute').options].map(o => o.value + ' = ' + o.textContent) };
      $('lkRoute').value = 'lineup-lineup2'; $('lkRoute').onchange({ target: $('lkRoute') });
      out.anchors = [...$('lkAnchor').options].map(o => o.value + ' = ' + o.textContent);
      $('lkAnchor').value = 'pier'; $('lkAnchor').onchange({ target: $('lkAnchor') });
      $('lkDwOn').checked = true; $('lkDwOn').onchange({ target: $('lkDwOn') });
      const R = C.routeOf('lineup-lineup2');
      out.sel = { route: $('lkRoute').value, anchor: $('lkAnchor').value, dwOn: $('lkDwOn').checked, how: ($('lkHow').textContent || '').slice(0, 400) };
      out.idleLamp = lamp();
      /* attempt 1: one Space at the pier end */
      space(); await sleep(400); tick();
      out.start = { running: A.run.wall0 !== null, t: Math.round(tNow()), castT: A.run.T, castS: A.run.T ? +((A.run.T - 1) * vi / 1000).toFixed(2) : null,
                    dwOpen: !!(A.run.dw && A.run.dw.open), cards: cards().length, lamp: lamp(), status: ($('lkStatus').textContent || '').slice(0, 200) };
      await sleep(1500); tick();
      out.cards = { n: cards().length, top: cards()[0] && cards()[0].textContent.replace(/\s+/g, ' ').slice(0, 80) };
      const top = +cards()[0].dataset.dwi;
      cards()[0].click(); await sleep(80); tick();
      out.pick = { pick: !!(A.run.dw && A.run.dw.pick), dwi: A.run.dw && A.run.dw.pick && A.run.dw.pick.dwi === top, cal: host().classList.contains('cal'),
                   cardsShown: cards().length, known: A.run.known, castT: A.run.T, castS: A.run.T ? +((A.run.T - 1) * vi / 1000).toFixed(2) : null, lamp: lamp() };
      const adj0 = A.run.dw.adj; ev('keydown', { code: 'BracketRight', key: ']' }); tick(); ev('keydown', { code: 'BracketLeft', key: '[' }); tick();
      ev('keydown', { code: 'BracketRight', key: ']', shiftKey: true }); tick();
      out.tune = { adj0, afterRightLeftShiftRight: A.run.dw.adj };
      ev('keydown', { code: 'BracketLeft', key: '[', shiftKey: true }); tick();
      /* freestyle by the Ctrl key */
      ev('keydown', { code: 'ControlLeft', key: 'Control', ctrlKey: true }); ev('keyup', { code: 'ControlLeft', key: 'Control' }); await sleep(50); tick();
      const ready = A.wakeReady(), wl = A.wakeList();
      out.free = { on: A.fsOn(), box: $('lkFree').checked, wait: A.fsWait(), lamp: lamp(), readyT: Math.round(ready),
                   wakeAfterReadyS: wl.map(w => +((w - ready) * vi / 1000).toFixed(1)), wakeEndS: +((A.wakeEnd() - ready) * vi / 1000).toFixed(1),
                   doubles: A.fsDoubles(R, top).length, groups: A.fsClusters(R, top).length };
      const nd = A.fsNextDouble(tNow());
      out.next = nd && !nd.none ? { inS: +nd.inS.toFixed(1), last: !!nd.last, bite: nd.d.bite } : nd;
      if (nd && !nd.none && nd.inS < 100) {
        const waitMs = (nd.at + 1 - tNow()) * vi; for (let w = 0; w < waitMs; w += 500) { await sleep(Math.min(500, waitMs - w)); tick(); }
        out.atDouble = { lamp: lamp(), t: Math.round(tNow()) };
        space(); await sleep(60); tick();
        const cb = A.fsComb();
        out.mark = { cast: A.run.fs && A.run.fs.cast != null, comb: cb ? { dbl: !!cb.dbl, n: cb.n, bites: cb.bites, relInS: +((cb.rel - tNow()) * vi / 1000).toFixed(1) } : null, lamp: lamp() };
      }
      ev('keydown', { code: 'Escape', key: 'Escape' }); await sleep(100);
      const tally = JSON.parse(localStorage.getItem('hm64v29_lucky_tally') || '[]');
      out.esc = { stopped: A.run.wall0 === null, logged: tally.length };
      /* attempt 2: normal mode, no dog picked — the generic histogram's cast suggestion */
      if (A.fsOn()) { ev('keydown', { code: 'ControlLeft', key: 'Control', ctrlKey: true }); ev('keyup', { code: 'ControlLeft', key: 'Control' }); }
      await sleep(200);
      space(); await sleep(300); tick();
      const T = A.run.T, toCast = (T - 3 * 59.826 - tNow()) * vi;
      out.normal = { fs: A.fsOn(), castS: +((T - 1) * vi / 1000).toFixed(2), lampStart: lamp() }; await sleep(700); tick(); out.normal.lamp1s = lamp(); await sleep(1000); tick(); out.normal.lamp2s = lamp();
      for (let w = 0; w < toCast; w += 1000) { await sleep(Math.min(1000, toCast - w)); tick(); }
      out.normal.lamp3s = lamp();
      await sleep(3 * 1000 + 60); tick(); out.normal.lampCast = lamp();
      ev('keydown', { code: 'Escape', key: 'Escape' }); await sleep(100);
    } catch (e) { out.errors.push('test: ' + String(e && e.stack || e).slice(0, 400)); }
    const p = document.createElement('pre'); p.id = 'testout'; p.textContent = JSON.stringify(out); document.body.appendChild(p);
  }, 1500);
})();
