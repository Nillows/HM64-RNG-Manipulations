/* headless (Opus 2026-11-22, v31.27): a FRESH browser (no stored settings) opens ready for the tester setup.
   Run WITHOUT a pre-script and without clearing storage first. */
(function () {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => {
    const A = window.HM64LuckyApp, C = window.HM64Lucky, $ = id => document.getElementById(id), out = { errors: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    const vi = 33.430 / 2;
    const ev = (type, o) => { const e = new KeyboardEvent(type, Object.assign({ code: 'Space', key: ' ', bubbles: true, cancelable: true }, o || {})); document.dispatchEvent(e); return e.defaultPrevented; };
    const key = (code, k, o) => { ev('keydown', Object.assign({ code, key: k }, o || {})); ev('keyup', { code, key: k }); };
    const tick = () => { if (A.run.wall0 !== null) A.frameOnce(); };
    const vis = id => { const e = $(id); return !!(e && !e.hidden && e.offsetParent !== null); };
    const lamp = () => ($('lkCueBig') ? $('lkCueBig').textContent : '');
    const host = () => $('lkCompCards'), cards = () => [...host().querySelectorAll('.lkdog')];
    try {
      A.L.audio = false;
      const R = C.routeOf('lineup-lineup2');
      out.open = { arena: window.HM64Arena, luckyShown: vis('luckyArena'), refShown: vis('refArena'), stored: localStorage.getItem('hm64v29_lucky') !== null };
      out.defaults = { route: $('lkRoute').value, anchor: $('lkAnchor').value, dwOn: $('lkDwOn').checked, free: $('lkFree').checked, sparrows: $('lkSparrows').checked,
                       dwCards: $('lkDwCards').value, dwFill: $('lkDwFill').value };
      out.pierUi = { pierBoxShown: vis('lkPierLbl'), pierChipShown: vis('lkKeyPier'), strat: !!$('lkStrat'), tapBox: ($('lkTapBox').textContent || '').slice(0, 160),
                     startLine: /use it/.test($('lkPaceTxt') ? $('lkPaceTxt').innerHTML : '') };
      out.keys = { chip: ($('lkKeyAnim') ? $('lkKeyAnim').textContent : '').slice(0, 160) };
      const ord = id => +getComputedStyle($(id)).order;
      out.order = { lkPrev: ord('lkPrev'), lkPlanBox: ord('lkPlanBox'), lkDw: ord('lkDw') };
      out.texts = { howtoDogUnderPier: /sleeping dog/.test(R.howto || ''), howtoTail: (R.howto || '').slice(-80),
                    early: R.axes[1].opts[0].band + ' | ' + R.axes[1].opts[0].desc, groupsDogSide: JSON.stringify(R.groups).includes('dog side'),
                    how: ($('lkHow').textContent || '').includes('sleeping dog') };
      /* X while idle with the dog-end start: nothing */
      key('KeyX', 'x'); await sleep(50); out.xIdle = { pierOnly: vis('lkPierLbl') || ($('lkPierOnly') && $('lkPierOnly').checked) };
      /* one Space at the pier end */
      key('Space', ' '); await sleep(400); tick(); await sleep(1500); tick();
      out.attempt = { running: A.run.wall0 !== null, fs: A.fsOn(), dwOpen: !!(A.run.dw && A.run.dw.open), cards: cards().length, lamp: lamp() };
      const rects = cards().map(c => Math.round(c.getBoundingClientRect().left)), shares = cards().map(c => (c.textContent.match(/(\d+)%/) || [])[1]);
      out.attempt.rtl = { lefts: rects, shares };
      key('KeyX', 'x'); await sleep(50); tick(); out.attempt.afterX = { checked: $('lkPierOnly').checked, lamp: lamp() };
      /* R = rollover log key: a log is taken while the watch is open */
      const n0 = A.run.dw.logs.length; ev('keydown', { code: 'KeyR', key: 'r' }); ev('keyup', { code: 'KeyR', key: 'r' }); await sleep(30); tick();
      out.attempt.rKey = { logs: A.run.dw.logs.length - n0, last: A.run.dw.logs.slice(-1)[0] };
      ev('keydown', { code: 'Backspace', key: 'Backspace' }); await sleep(30); tick();
      const top = cards()[cards().length - 1]; top.click(); await sleep(80); tick();
      out.pick = { cal: host().classList.contains('cal'), cards: cards().length, known: A.run.known, lamp: lamp() };
      ev('keydown', { code: 'Escape', key: 'Escape' }); await sleep(150);
      out.esc = { stopped: A.run.wall0 === null, logged: JSON.parse(localStorage.getItem('hm64v29_lucky_tally') || '[]').length };
      /* the fade-in start brings back the multi-tap strategies and Pier only; back to the pier */
      $('lkAnchor').value = 'fadein'; $('lkAnchor').onchange({ target: $('lkAnchor') }); await sleep(50);
      out.fadein = { pierBoxShown: vis('lkPierLbl'), pierChipShown: vis('lkKeyPier'), strat: !!$('lkStrat'), startLine: /use it/.test($('lkPaceTxt').innerHTML) || /Start:/.test($('lkPaceTxt').innerHTML) };
      $('lkAnchor').value = 'pier'; $('lkAnchor').onchange({ target: $('lkAnchor') }); await sleep(50);
      /* sparrows: S keeps the pier start */
      key('KeyS', 's'); await sleep(80);
      out.sparrows = { checked: $('lkSparrows').checked, route: C.selection ? C.selection.route : null, anchor: $('lkAnchor').value, pierBoxShown: vis('lkPierLbl'), strat: !!$('lkStrat') };
      key('KeyS', 's'); await sleep(80); out.sparrows.off = { checked: $('lkSparrows').checked, anchor: $('lkAnchor').value };
      /* Reset these keys returns to the new defaults */
      window.confirm = () => true; if ($('lkDwKeyReset')) $('lkDwKeyReset').click(); await sleep(50);
      out.reset = { chip: ($('lkKeyAnim').textContent || '').slice(0, 160) };
    } catch (e) { out.errors.push('test: ' + String(e && e.stack || e).slice(0, 400)); }
    const p = document.createElement('pre'); p.id = 'testout'; p.textContent = JSON.stringify(out); document.body.appendChild(p);
  }, 2500);
})();
