(function () { const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => { const R = window.HM64DogRef, $ = id => document.getElementById(id), out = { errors: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    try {
      for (let i = 0; i < 2400 && !(R && R.shown && R.shown.blind && R.shown.blind.all && R.shown.blind.all.win && !/working out/.test($('rfBody').textContent)); i++) await sleep(50);
      const strip = (k, v) => (k === 'chart' || k === 'nLines' ? undefined : v);
      const s = JSON.stringify(R.shown, strip);
      let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
      out.len = s.length; out.hash = h;
      out.text = [...document.querySelectorAll('.rfpane')].map(p => p.textContent.replace(/\s+/g, ' ').length);
    } catch (e) { out.errors.push('test: ' + e.message); }
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, 400); })();
