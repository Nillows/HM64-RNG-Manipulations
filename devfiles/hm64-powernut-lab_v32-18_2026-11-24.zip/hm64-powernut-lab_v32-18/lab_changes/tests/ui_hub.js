/* headless (v32.6): the hub's picker. Ticks -> the game file -> the three buttons (always Casting tables, Lucky Timer,
   Dog practice, in that order) link to that file's pages; a file without tables greys them out; the choice is kept and
   #<set id> picks a file. */
(function () {
  setTimeout(() => {
    const $ = id => document.getElementById(id), out = { errors: [], states: [] };
    try {
      const cb = id => $('hubTicks').querySelector(`input[data-t="${id}"]`);
      const state = () => ({ name: $('hubName').textContent, badge: $('hubBadge').textContent, hash: location.hash,
        buttons: [...$('hubGo').querySelectorAll('a')].map(a => [a.querySelector('b').textContent, a.getAttribute('href'), a.classList.contains('off')]),
        needs: !$('hubNeeds').hidden });
      out.ticks = [...$('hubTicks').querySelectorAll('label')].map(l => [l.textContent.trim(), l.querySelector('input').disabled]);
      out.states.push(state());
      cb('horse').click(); out.states.push(state());
      cb('rainy').click(); out.states.push(state());
      cb('horse').click(); out.states.push(state());
      out.stored = localStorage.getItem('hm64v32_hub');
      location.hash = '#sunny-horse'; window.dispatchEvent(new HashChangeEvent('hashchange'));
      out.states.push(state());
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const p = document.createElement('pre'); p.id = 'testout'; p.textContent = JSON.stringify(out); document.body.appendChild(p);
  }, 300);
})();
