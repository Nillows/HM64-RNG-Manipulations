/* headless (v32.4): a clicked candle / line / timing filters the close-up's histogram by default (only its own
   candles, as the share of those arrivals); "keep every candle" brings back the v32.3 view (all candles, lines dimmed). */
(function () { const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => { const R = window.HM64DogRef, $ = id => document.getElementById(id), out = { errors: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    try {
      for (let i = 0; i < 2400 && !(R && R.shown && R.shown.blind && R.shown.blind.all && R.shown.blind.all.win && !/working out/.test($('rfBody').textContent)); i++) await sleep(50);
      const pick = window.__pick || 'ba';
      R.openChart(pick); await sleep(30);
      const d = $('rfChartDlg'), cv = $('rfcCanvas'), ch = R.charts.get(pick).ch, r0 = cv.getBoundingClientRect();
      const pf = Math.max(3, Math.min(8, Math.floor(860 / ch.s1.length))), sc = r0.width / (96 + ch.s1.length * pf + 36);
      const k = ch.pol === 'hold' ? 's2' : 's1', a0 = ch.st - ch.a; let best = a0; for (let i = a0; i < a0 + ch.n; i++) if (ch[k][i] > ch[k][best]) best = i;
      out.keepDefault = $('rfcKeep').checked;
      cv.dispatchEvent(new MouseEvent('click', { clientX: r0.left + (96 + best * pf + pf / 2) * sc, clientY: r0.top + 80 * sc, bubbles: true })); await sleep(20);
      const C = R.closeup, V = C.L.view;
      let outside = 0; for (let i = 0; i < ch.s1.length; i++) if (V.s1[i] === 0 && V.s2[i] === 0 && (ch.s1[i] > 0 || ch.s2[i] > 0)) outside++;
      const lit = ch.lines.filter(l => l.f1[best] > 0 || l.f2[best] > 0).length;
      out.candle = { filt: C.L.filt, lines: lit, of: ch.lines.length, groupShare: +(100 * V.gw).toFixed(2), atClicked: [+V.s1[best].toFixed(4), +V.s2[best].toFixed(4)],
        clickedCertain: V.s1[best] + V.s2[best] >= 1 - 1e-9, candlesGone: outside, of2: ch.s1.length,
        rowOdds: +(100 * ch.p).toFixed(2), viewOdds: +(100 * V.p).toFixed(2), head: document.querySelector('#rfcLines .rfcsel').textContent.slice(0, 260) };
      // keep every candle: the v32.3 view
      $('rfcKeep').checked = true; $('rfcKeep').onchange({ target: $('rfcKeep') }); await sleep(20);
      out.keep = { filt: R.closeup.L.filt, sameAsRow: R.closeup.L.view.s1.every((v, i) => v === ch.s1[i]), stored: R.state.keepAll, head: document.querySelector('#rfcLines .rfcsel').textContent.slice(0, 120) };
      $('rfcKeep').checked = false; $('rfcKeep').onchange({ target: $('rfcKeep') }); await sleep(20);
      // focus the first line, then its most common timing: exact frames 0 / 100%
      d.dispatchEvent(new Event('cancel', { cancelable: true })); await sleep(10);
      document.querySelector('#rfcLines tr.ln').click(); await sleep(10);
      const L1 = ch.lines[R.closeup.focus], V2 = R.closeup.L.view;
      out.line = { name: L1.name, sameAsLine: V2.s1.every((v, i) => Math.abs(v - L1.f1[i]) < 1e-9), odds: +(100 * V2.p).toFixed(2), head: document.querySelector('#rfcLines .rfcsel').textContent.slice(0, 160) };
      document.querySelector('#rfcLines tr.tm').click(); await sleep(10);
      const V3 = R.closeup.L.view;
      out.timing = { values: [...new Set(V3.s1.concat(V3.s2))].sort(), nutFrames: V3[k].filter(v => v > 0).length, odds: +(100 * V3.p).toFixed(2) };
      const b = d.getBoundingClientRect(); out.box = [b.left, b.width].map(Math.round);
    } catch (e) { out.errors.push('test: ' + e.message + ' ' + e.stack); }
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out, null, 1); document.body.appendChild(pre);
  }, 400); })();
