try { localStorage.setItem('hm64v32_hub', JSON.stringify({ rainy: false, horse: true })); } catch (e) { /* storage off */ }
