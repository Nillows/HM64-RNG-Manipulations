/* headless (v32.16): another tab (the Settings page) changes the shared store while a Lucky Timer page is open. The
   'storage' event fires only in OTHER tabs, so the test writes the store and dispatches the event itself, as the browser
   would. The page takes the new values in (start key, hand-set correction and spread, practice presses, bite reactions,
   the stock bite-tap delay) and a later save of its own does not write the old ones back. */
(function () {
  const t0 = Date.now();
  const go = () => {
    const A = window.HM64LuckyApp, out = { errors: [] };
    if (!A && Date.now() - t0 < 60000) return setTimeout(go, 300);
    try {
      const fire = (key) => window.dispatchEvent(new StorageEvent('storage', { key, newValue: localStorage.getItem(key) }));
      const J = k => JSON.parse(localStorage.getItem(k) || 'null');
      out.before = { key: A.L.startKey, corr: A.learned().corr, sigma: A.learned().sigma, prac: A.pracLog.length, bite: A.biteLog.length };
      const L = J('hm64v29_lucky') || {};
      Object.assign(L, { startKey: 'k', biasAuto: false, biasMs: 77, sigmaAuto: false, sigmaMs: 220 });
      localStorage.setItem('hm64v29_lucky', JSON.stringify(L)); fire('hm64v29_lucky');
      out.afterLucky = { key: A.L.startKey, corr: A.learned().corr, sigma: A.learned().sigma };
      const cp = (J('hm64v29_lucky_castprac') || []).concat([{ at: Date.now(), e: 12, m: 'line', src: 'Settings', v: 1 }]);
      localStorage.setItem('hm64v29_lucky_castprac', JSON.stringify(cp)); fire('hm64v29_lucky_castprac');
      const bp = (J('hm64v30_lucky_biteprac') || []).concat([{ at: Date.now(), r: 180, k: 'ok', w: 334, m: 'rel', src: 'Settings' }]);
      localStorage.setItem('hm64v30_lucky_biteprac', JSON.stringify(bp)); fire('hm64v30_lucky_biteprac');
      out.afterLogs = { prac: A.pracLog.length, bite: A.biteLog.length };
      const S = J('hm64v28_settings') || {}; S.tapMuVI = 15; localStorage.setItem('hm64v28_settings', JSON.stringify(S)); fire('hm64v28_settings');
      out.tapMuVI = A.tapMu();
      /* a save of the page's own (a route-box change saves L) keeps what the other tab wrote */
      A.setSparrows(false);
      const L2 = J('hm64v29_lucky');
      out.keptAfterSave = { key: L2.startKey, biasMs: L2.biasMs, sigmaMs: L2.sigmaMs, biasAuto: L2.biasAuto };
      out.setLine = (document.getElementById('lkSetLine') || {}).textContent || '';
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const p = document.createElement('pre'); p.id = 'testout'; p.textContent = JSON.stringify(out); document.body.appendChild(p);
  };
  setTimeout(go, 800);
})();
