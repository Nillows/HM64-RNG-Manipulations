/* headless (v32.0): the casting tables page loads, draws its tables and has no errors (quick check). */
(function () { const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => { const $ = id => document.getElementById(id), out = { errors: [] }, t0 = performance.now();
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    try {
      if ($('arOracle')) { $('arOracle').click(); await sleep(80); }
      const R = window.HM64DogRef;
      const done = () => R && R.shown && R.shown.all && !/working out/.test($('rfBody').textContent);
      for (let i = 0; i < 2400 && !done(); i++) await sleep(50);
      out.done = done(); out.ms = Math.round(performance.now() - t0);
      out.route = R && R.shown && R.shown.routeId; out.tabs = [...document.querySelectorAll('#rfBody .rftabs button')].map(b => b.textContent);
      out.rows = document.querySelectorAll('#rfBody tr').length; out.vi = window.HM64Core && window.HM64Core.viMs();
      out.first = (document.querySelector('#rfBody .rfpane:not([hidden])') || {}).textContent;
      out.first = out.first && out.first.slice(0, 600);
      $('helpBtn').click(); await sleep(30); out.help = $('helpBody').innerHTML.slice(0, 900);
    } catch (e) { out.errors.push('test: ' + e.message); }
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out, null, 1); document.body.appendChild(pre);
  }, 400);
})();
