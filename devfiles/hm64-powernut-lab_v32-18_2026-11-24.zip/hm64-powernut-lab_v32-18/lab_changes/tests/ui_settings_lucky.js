/* headless (v32.16): the Lucky Timer's own numbers for the store of pre_settings_seed.js (compare with ui_settings.js),
   the record it keeps for the Settings page, the attempt count at an attempt's start, and the moved sections hidden. */
(function () {
  const t0 = Date.now();
  const go = () => {
    const A = window.HM64LuckyApp, out = { errors: [] };
    if (!A && Date.now() - t0 < 60000) return setTimeout(go, 300);
    try {
      const l = A.learned(), T = window.HM64Timing;
      out.lucky = { corr: l.corr, sigma: l.sigma, press: l.press && { n: l.press.n, med: l.press.med, sd: +l.press.sd.toFixed(3) }, tapMuMs: Math.round(A.tapMu() * T.viMs() * 10) / 10 };
      out.timing = { corr: T.cueCorr(), sigma: T.sigmaMs(), press: T.pressReady() && { n: T.pressReady().n, med: T.pressReady().med, sd: +T.pressReady().sd.toFixed(3) }, bpMed: T.bpReact().s.med };
      out.hidden = ['lkStartKey', 'lkCompass', 'lkManual', 'lkBpBox', 'lkPracBox', 'lkCombo', 'lkDwKeyTbl', 'lkCastTap', 'lkAudio', 's_updateMs', 's_tapMu'].map(id => {
        const e = document.getElementById(id); return [id, e ? !e.offsetParent && getComputedStyle(e.closest('.v32moved') || e).display === 'none' : 'missing']; });
      out.setLine = (document.getElementById('lkSetLine') || {}).textContent || '';
      setTimeout(() => {
        out.fit = T.fit() && { set: T.fit().set, offsetSdMs: T.fit().offsetSdMs, b: T.fit().b, rows: T.fit().rows.map(r => r[1] + ': ' + r[2]), dots: T.fit().dots.length };
        const n0 = T.attempts(); A.start ? A.start() : null; out.attemptsAdded = T.attempts() - n0;
        const p = document.createElement('pre'); p.id = 'testout'; p.textContent = JSON.stringify(out); document.body.appendChild(p);
      }, 900);
      return;
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const p = document.createElement('pre'); p.id = 'testout'; p.textContent = JSON.stringify(out); document.body.appendChild(p);
  };
  setTimeout(go, 800);
})();
