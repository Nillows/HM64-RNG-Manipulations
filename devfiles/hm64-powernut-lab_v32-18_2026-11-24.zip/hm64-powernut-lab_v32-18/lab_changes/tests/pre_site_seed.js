/* pre-script (v32.1): settings stored by the Sunny, no-horse Lucky Timer of the same site (same origin on GitHub Pages). */
try { localStorage.setItem('hm64v29_lucky', JSON.stringify({ route: 'lineup-lineup2', routeAnchor: { 'lineup-lineup2': 'pier' }, dwOn: true, sparrows: false })); } catch (e) {}
