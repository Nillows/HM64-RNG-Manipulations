/* headless (v32.5, Thomas 2026-11-23 19:58: "adding enter as a key to autoselect the most likely dog without clicking
   it ... hit enter when the top dog is right and then of course that gets to tuning after"). Lucky Timer, one Space at
   the pier end, dog-watch on: Enter with no dog chosen = the top card (the most likely) is chosen, as a click; [ ] tune
   it; Enter again = its timing is set; Backspace undoes the choice; Enter then picks the (new) top card again. */
(function () {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => {
    const A = window.HM64LuckyApp, $ = id => document.getElementById(id), out = { errors: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    const ev = (type, o) => { const e = new KeyboardEvent(type, Object.assign({ code: 'Space', key: ' ', bubbles: true, cancelable: true }, o || {})); document.dispatchEvent(e); return e.defaultPrevented; };
    const enter = () => ev('keydown', { code: 'Enter', key: 'Enter' });
    const tick = () => { if (A.run.wall0 !== null) A.frameOnce(); };
    const cards = () => [...$('lkCompCards').querySelectorAll('.lkdog')];
    try {
      localStorage.clear(); $('arLucky').click(); A.L.audio = false;
      $('lkRoute').value = 'lineup-lineup2'; $('lkRoute').onchange({ target: $('lkRoute') });
      $('lkAnchor').value = 'pier'; $('lkAnchor').onchange({ target: $('lkAnchor') });
      $('lkDwOn').checked = true; $('lkDwOn').onchange({ target: $('lkDwOn') });
      out.idleEnter = enter();                                   // no attempt: Enter is left alone
      ev('keydown'); ev('keyup'); await sleep(1200); tick();
      tick(); await sleep(100); tick();
      const comp = A.dwComp(), top = comp.lines[0].dwi, topCard = cards().find(c => c.classList.contains('top'));
      out.before = { pick: A.run.dw.pick, topDwi: top, topCardDwi: topCard && +topCard.dataset.dwi };
      out.enter1 = { prevented: enter() }; await sleep(60); tick();
      out.enter1.pick = A.run.dw.pick && A.run.dw.pick.dwi; out.enter1.isTop = out.enter1.pick === top; out.enter1.tuned = A.run.dw.tuned;
      out.enter1.cal = $('lkCompCards').classList.contains('cal'); out.enter1.lamp = ($('lkCueBig') || {}).textContent;
      ev('keydown', { code: 'BracketRight', key: ']' }); ev('keydown', { code: 'BracketRight', key: ']' }); tick();
      out.tune = { adj: A.run.dw.adj, tuned: A.run.dw.tuned };
      out.enter2 = { prevented: enter() }; await sleep(30); tick();
      out.enter2.tuned = A.run.dw.tuned; out.enter2.pick = A.run.dw.pick && A.run.dw.pick.dwi;
      ev('keydown', { code: 'Backspace', key: 'Backspace' }); await sleep(30); tick();
      out.undo = { pick: A.run.dw.pick };
      enter(); await sleep(30); tick();
      out.again = { pick: A.run.dw.pick && A.run.dw.pick.dwi, isTop: A.run.dw.pick && A.run.dw.pick.dwi === A.dwComp().lines[0].dwi };
      out.keyHint = ($('lkKeyAdj') || {}).textContent;
      ev('keydown', { code: 'Escape', key: 'Escape' });
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const p = document.createElement('pre'); p.id = 'testout'; p.textContent = JSON.stringify(out); document.body.appendChild(p);
  }, 400);
})();
