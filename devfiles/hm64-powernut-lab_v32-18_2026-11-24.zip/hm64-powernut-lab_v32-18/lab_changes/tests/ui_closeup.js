/* headless (v32.3): the close-up of an Optimal Blind Casting window - (1) the dialog does not move or resize while the
   mouse runs over the chart (the v32.2 jitter); (2) clicking a candle lights the dog lines with a Nut there and lists
   them; the per-line "adds to" figures add up to the row's odds; ← → step the candle; Esc clears, then closes;
   (3) clicking a line focuses it. */
(function () { const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => { const R = window.HM64DogRef, $ = id => document.getElementById(id), out = { errors: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    try {
      for (let i = 0; i < 2400 && !(R && R.shown && R.shown.blind && R.shown.blind.all && R.shown.blind.all.win && !/working out/.test($('rfBody').textContent)); i++) await sleep(50);
      const pick = window.__pick || 'b0';
      R.openChart(pick); await sleep(50);
      const d = $('rfChartDlg'), cv = $('rfcCanvas'), ch = R.charts.get(pick).ch;
      const rects = [];
      const r0 = cv.getBoundingClientRect();
      for (let k = 0; k < 120; k++) {
        cv.dispatchEvent(new MouseEvent('mousemove', { clientX: r0.left + 2 + (r0.width - 4) * k / 119, clientY: r0.top + 60, bubbles: true }));
        const b = d.getBoundingClientRect(); rects.push([Math.round(b.left * 10) / 10, Math.round(b.width * 10) / 10, Math.round(b.top * 10) / 10, Math.round(b.height * 10) / 10]);
      }
      const uniq = a => [...new Set(a.map(x => JSON.stringify(x)))];
      out.dialogRects = uniq(rects);
      out.readSample = $('rfcRead').textContent.slice(0, 140);
      // (2) click the best candle inside the window
      const k = ch.pol === 'hold' ? 's2' : 's1', a0 = ch.st - ch.a;
      let best = a0; for (let i = a0; i < a0 + ch.n; i++) if (ch[k][i] > ch[k][best]) best = i;
      const L = R.charts.get(pick);
      const pf = Math.max(3, Math.min(8, Math.floor(860 / ch.s1.length))), sc = r0.width / (96 + ch.s1.length * pf + 36);
      const cx = r0.left + (96 + best * pf + pf / 2) * sc;
      cv.dispatchEvent(new MouseEvent('click', { clientX: cx, clientY: r0.top + 80 * sc, bubbles: true })); await sleep(30);
      const hits = ch.lines.filter(l => l.f1[best] > 0 || l.f2[best] > 0).map(l => l.name);
      out.sel = { frame: best, hitsExpected: hits, rowsHit: [...document.querySelectorAll('#rfcLines tr.hit')].map(tr => tr.cells[0].textContent),
        rowsDim: document.querySelectorAll('#rfcLines tr.dim').length, head: (document.querySelector('#rfcLines .rfcsel') || {}).textContent };
      const adds = ch.lines.reduce((q, l) => { const fr = ch.pol === 'hold' ? l.f2 : l.f1; let s = 0; for (let i = a0; i < a0 + ch.n; i++) s += fr[i]; return q + l.share * s / ch.n; }, 0);
      out.addsSum = [+(100 * adds).toFixed(3), +(100 * ch.p).toFixed(3)];
      // arrows
      d.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight', bubbles: true })); await sleep(20);
      out.afterRight = (document.querySelector('#rfcLines .rfcsel') || {}).textContent.slice(0, 40);
      // Esc: first clears
      const ev = new Event('cancel', { cancelable: true }); d.dispatchEvent(ev); await sleep(20);
      out.escClears = { prevented: ev.defaultPrevented, open: d.open, head: (document.querySelector('#rfcLines .rfcsel') || {}).textContent.slice(0, 40) };
      // (3) focus the first listed line
      const tr = document.querySelector('#rfcLines tr.ln'); tr.click(); await sleep(20);
      out.focus = { row: tr.cells[0].textContent, foc: document.querySelectorAll('#rfcLines tr.foc').length, head: (document.querySelector('#rfcLines .rfcsel') || {}).textContent.slice(0, 80) };
      out.listRows = [...document.querySelectorAll('#rfcLines tr.ln')].slice(0, 4).map(tr => [...tr.cells].map(c => c.textContent).join(' | '));
      const ev2 = new Event('cancel', { cancelable: true }); d.dispatchEvent(ev2);
      const ev3 = new Event('cancel', { cancelable: true }); d.dispatchEvent(ev3);
      out.secondEsc = { firstPrevented: ev2.defaultPrevented, secondPrevented: ev3.defaultPrevented };
    } catch (e) { out.errors.push('test: ' + e.message + ' ' + e.stack); }
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out, null, 1); document.body.appendChild(pre);
  }, 400); })();
