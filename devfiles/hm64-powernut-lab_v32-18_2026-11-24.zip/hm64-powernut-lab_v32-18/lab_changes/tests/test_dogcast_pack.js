// v31.2: LuckyCore.dogAfterCast (the app's decoder of webapp/assets/dogcast.json) against the Mac's raw rows.
//   node tests/test_dogcast.js RESULTS_DIR [samples]
// For sampled casts of every block: at 40 moments from the cast to the end of its data the decoder's dog (B held) must
// be the dog the lab recorded; and for each bite, 6 moments of the released path (B let go at that bite).
const fs = require('fs'), path = require('path'), rl = require('readline');
const C = require('../webapp/hm64_lucky_v29.js');
const dir = process.argv[2], N = +(process.argv[3] || 3000);
const pack = JSON.parse(fs.readFileSync(process.env.HM64_PACK || path.join(__dirname, '..', 'webapp', 'assets', 'dogcast.json')));
const undelta = d => { const o = []; let k = 0; for (let i = 0; i < d.length; i += 2) { k = i ? k + d[i] : d[i]; o.push([k, d[i + 1]]); } return o; };
const at = (runs, k) => { let c; for (const [kk, code] of runs) { if (kk <= k) c = code; else break; } return c; };
let seed = 7; const rnd = () => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);
(async () => {
  let sched = 0, schedBad = 0, casts = 0, held = 0, heldBad = 0, rel = 0, relBad = 0, nodata = 0, ex = [];
  const files = fs.readdirSync(dir).filter(f => /^FD_casts_b\d+\.jsonl$/.test(f));
  const total = 39060, keep = N / total;
  for (const f of files) {
    for await (const line of rl.createInterface({ input: fs.createReadStream(path.join(dir, f)) })) {
      const r = JSON.parse(line);
      for (const c of r.casts || []) {
        if (rnd() > keep) continue;
        casts++;
        const runs = undelta(c.d), k = c.k, end = Math.min(c.e[0], k + 6000), nat = at(runs, k);
        for (let i = 0; i < 40; i++) {
          const dt = Math.floor(rnd() * (end - k));
          const got = C.dogAfterCast(pack, r.key, k, dt, 0, nat), want = at(runs, k + dt);
          if (got === undefined) { nodata++; continue; }
          held++; if (got !== want) { heldBad++; if (ex.length < 6) ex.push(['held', r.key.slice(0, 8), k, dt, got, want]); }
        }
        { const ln = pack.lines[r.key], cid = ln.idx[(k - ln.k0) / 2]; let f = pack.F[cid], st = pack.S[cid], lab = k + f; const got = [];
          while (f >= 0 && st >= 0 && got.length < 40) { got.push(lab + ':' + pack.O[st]); if (pack.N[st] < 0) break; lab += pack.N[st]; st = pack.X[st]; }
          const want = c.b.map(b => b[0] + ':' + b[1][0]);
          sched++; if (got.slice(0, want.length).join() !== want.join()) { schedBad++; if (ex.length < 6) ex.push(['schedule', r.key.slice(0, 8), k, got.slice(0, 4), want.slice(0, 4)]); } }
        c.b.forEach((b, i) => {
          const tr = undelta(c.t[i].length >= 2 && c.t[i][c.t[i].length - 2] === -1 ? c.t[i].slice(0, -2) : c.t[i]);
          if (!tr.length) return;
          const last = Math.min(b[0] + 240, c.t[i].length >= 2 && c.t[i][c.t[i].length - 2] === -1 ? c.t[i][c.t[i].length - 1] - 1 : 1e9);
          for (let q = 0; q < 6; q++) {
            const lab = b[0] + 2 + Math.floor(rnd() * Math.max(1, last - b[0] - 2)), want = at(tr, lab);
            const got = C.dogAfterCast(pack, r.key, k, lab - k, i + 1, nat);
            if (got === undefined || want === undefined) { nodata++; continue; }
            rel++; if (got !== want) { relBad++; if (ex.length < 6) ex.push(['released at bite ' + (i + 1), r.key.slice(0, 8), k, lab - k, got, want]); }
          }
        });
      }
    }
  }
  console.log(`${casts} casts sampled · B held: ${held} moments, ${heldBad} wrong · B let go at a bite: ${rel} moments, ${relBad} wrong · no data returned ${nodata} · bite schedules (times and catches of every bite): ${sched}, ${schedBad} wrong`);
  for (const e of ex) console.log('  ', JSON.stringify(e));
})();
