/* headless (v32.5): the close-up's "Try it" panel. With the row's own inputs it gives the row's odds exactly (every
   chart); one line ticked = that line's own fractions and odds; aimed = the bell curve of the spread over the candles
   (checked against an independent sum); the dialog keeps one width while the inputs move. */
(function () {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => {
    const R = window.HM64DogRef, $ = id => document.getElementById(id), out = { errors: [], rows: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    try {
      for (let i = 0; i < 200 && !(R.shown && R.charts.size); i++) await sleep(250);
      await sleep(1500);
      const ids = [...R.charts.keys()];
      let worst = 0, worstLine = 0, worstAim = 0;
      const widths = new Set();
      for (const id of ids) {
        R.openChart(id); const x = R.closeup;
        $('rfcTryBtn').click(); await sleep(5);
        worst = Math.max(worst, Math.abs(x.ch.p - x.ch0.p));
        widths.add($('rfChartDlg').getBoundingClientRect().width);
        /* one line only */
        const L = x.ch0.lines[0];
        x.tr.off = new Set(x.ch0.lines.slice(1).map(l => l.key));
        $('rfcTryBtn').click(); $('rfcTryBtn').click(); await sleep(5);           // off + on = recompute
        const fr = x.ch0.pol === 'hold' ? L.f2 : L.f1, a0 = x.ch0.st - x.ch0.a;
        let mean = 0; for (let i = a0; i < a0 + x.ch0.n; i++) mean += fr[i]; mean /= x.ch0.n;
        worstLine = Math.max(worstLine, Math.abs(x.ch.p - mean), ...x.ch.s1.map((v, i) => Math.abs(v - L.f1[i])));
        /* aimed, 150 ms, all lines: an independent bell over the row's candles */
        x.tr.off.clear(); x.tr.mode = 'aim'; x.tr.sig = 150; x.tr.aim = a0 + Math.floor(x.ch0.n / 2);
        $('rfcTryBtn').click(); $('rfcTryBtn').click(); await sleep(5);
        const sd = Math.max(0.25, 150 / 16.715 / 2), r = Math.ceil(3 * sd), A = x.ch0.pol === 'hold' ? x.ch0.s2 : x.ch0.s1;
        let q = 0, z = 0; for (let d = -r; d <= r; d++) { const g = Math.exp(-0.5 * (d / sd) ** 2); z += g; q += g * A[x.tr.aim + d]; }
        worstAim = Math.max(worstAim, Math.abs(x.ch.p - q / z));
        widths.add($('rfChartDlg').getBoundingClientRect().width);
        /* the sliders move the chart live */
        $('rfcSig').value = '60'; $('rfcSig').dispatchEvent(new Event('input')); await sleep(5);
        const p60 = x.ch.p;
        widths.add($('rfChartDlg').getBoundingClientRect().width);
        if (id === 'b0') {
          out.b0 = { row: x.ch0.p, aim150: +(q / z).toFixed(4), aim60: +p60.toFixed(4), best60: x.ch.best && +x.ch.best.p.toFixed(4), lines: x.ch0.lines.length, text: $('rfcTryOut').textContent.slice(0, 400) };
          /* a clicked candle in the filtered view says why it is 100% */
          $('rfcTryReset').click(); await sleep(5);
          const cv = $('rfcCanvas'), Lz = x.L, rect = cv.getBoundingClientRect();
          let sel = null; for (let i = a0; i < a0 + x.ch.n; i++) if (x.ch.s1[i] > 0 || x.ch.s2[i] > 0) { sel = i; break; }
          const cx = rect.left + (Lz.L0 + sel * Lz.pf + Lz.pf / 2) * rect.width / Lz.W, cy = rect.top + 60 * rect.height / Lz.H;
          cv.dispatchEvent(new MouseEvent('click', { clientX: cx, clientY: cy, bubbles: true })); await sleep(5);
          out.b0.click = { sel: x.sel, filt: x.L.filt, head: $('rfcLines').querySelector('.rfcsel').textContent.slice(-170), clicked: +Math.max(x.L.view.s1[sel], x.L.view.s2[sel]).toFixed(3) };
        }
        $('rfcTryBtn').click();                                     // off for the next chart
        $('rfChartDlg').close();
      }
      out.charts = ids.length; out.maxGapRow = worst; out.maxGapOneLine = worstLine; out.maxGapAim = worstAim; out.widths = [...widths].map(w => Math.round(w));
      out.why = { blind: !!document.querySelector('.rfwhy'), lines: document.querySelectorAll('.rfwhy1').length };
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const p = document.createElement('pre'); p.id = 'testout'; p.textContent = JSON.stringify(out); document.body.appendChild(p);
  }, 400);
})();
