/* v32.16: a Dog practice page key override from before v32.16 (facing on W A S D), nothing set in the shared store */
try { localStorage.setItem('hm64v32_practice', JSON.stringify({ drill: 'whole', keys: { dwKeys: 'wasd', startKey: ' ' } })); localStorage.setItem('hm64v29_lucky', JSON.stringify({ cueV: 1, castTapV: 1 })); } catch (e) { /* storage off */ }
