/* headless (v32.16): the Casting tables use the player's timing from Settings (pre_settings_hand.js: spread ±220 ms by
   hand, start-tap delay 200 ms): the tables are worked out with ±220 ms, the line above them says so, the stopwatch
   starts 200 ms before the key press; the old page-own controls are hidden; a change from another tab redoes the tables. */
(function () { const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => { const $ = id => document.getElementById(id), out = { errors: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    try {
      const R = window.HM64DogRef;
      const done = () => R && R.shown && R.shown.all && !/working out/.test($('rfBody').textContent);
      for (let i = 0; i < 2400 && !done(); i++) await sleep(50);
      out.sig = R.shown && R.shown.sigMs; out.txt = $('rfTimTxt').textContent;
      out.hidden = ['rfSig', 'rfDelay'].map(id => getComputedStyle($(id).closest('.v32moved')).display);
      const t = performance.now(); R.start(t); out.t0 = Math.round(t - R.timer.t0); R.reset();
      out.first = ((document.querySelector('#rfBody .rfnote') || {}).textContent || '').slice(0, 120);
      const L = JSON.parse(localStorage.getItem('hm64v29_lucky')); L.sigmaMs = 100; localStorage.setItem('hm64v29_lucky', JSON.stringify(L));
      window.dispatchEvent(new StorageEvent('storage', { key: 'hm64v29_lucky' }));
      for (let i = 0; i < 2400 && !(done() && R.shown.sigMs === 100); i++) await sleep(50);
      out.sigAfter = R.shown && R.shown.sigMs; out.txtAfter = $('rfTimTxt').textContent;
    } catch (e) { out.errors.push('test: ' + (e && e.stack || e)); }
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, 400);
})();
