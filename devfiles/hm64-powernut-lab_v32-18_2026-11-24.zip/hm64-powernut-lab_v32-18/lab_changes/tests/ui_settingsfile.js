/* headless (v32.16): every tool page's footer has Settings (new tab) and "⇅ Settings file" (export / import for a page
   opened from a folder); the dialog opens, its keys stay inside, it closes. */
(function () {
  const t0 = Date.now();
  const go = () => {
    const $ = id => document.getElementById(id), out = { errors: [] };
    if (!$('sfDlg') && Date.now() - t0 < 60000) return setTimeout(go, 300);
    try {
      out.footer = [...document.querySelectorAll('footer a')].filter(a => /Settings/.test(a.textContent)).map(a => [a.textContent, a.getAttribute('href'), a.getAttribute('target')]);
      $('sfBtn').dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
      out.open = $('sfDlg').open; out.buttons = [...$('sfDlg').querySelectorAll('button')].map(b => b.textContent);
      let leaked = 0; const h = () => { leaked++; }; document.addEventListener('keydown', h);
      $('sfDlg').querySelector('button').dispatchEvent(new KeyboardEvent('keydown', { key: ' ', bubbles: true })); document.removeEventListener('keydown', h);
      out.keyLeaked = leaked; $('sfDlg').close(); out.closed = !$('sfDlg').open;
      out.exportN = Object.keys(window.HM64Timing.exportAll().keys).length;
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const p = document.createElement('pre'); p.id = 'testout'; p.textContent = JSON.stringify(out); document.body.appendChild(p);
  };
  setTimeout(go, 500);
})();
