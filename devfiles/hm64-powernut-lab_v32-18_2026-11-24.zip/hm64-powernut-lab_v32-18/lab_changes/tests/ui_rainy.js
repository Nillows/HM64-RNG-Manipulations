/* headless (v32.18): a game file's pages carry that file's tables only, and a file without a sparrow table (the rainy
   ones: no sparrows in the rain) shows no sparrow box anywhere. Run on the Lucky Timer, the Casting tables and the Dog
   practice page of any set; prints what each page holds so a rainy and a sunny run can be read side by side. */
(function () {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => {
    const $ = id => document.getElementById(id), out = { errors: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    try {
      const PG = typeof HM64_PAGE !== 'undefined' ? HM64_PAGE : {};
      out.page = { kind: PG.kind, set: PG.set, rainy: !!PG.rainy, needs: (PG.needs || []).length };
      const D = typeof HM64_DATA !== 'undefined' ? HM64_DATA : null;
      if (D) {
        const R = (D.lroutes || [])[0] || {};
        out.data = { routes: (D.lroutes || []).map(r => r.id), variants: (D.lroutes || []).filter(r => r.variant_of).length,
          lines: (R.lines || []).length, dwLines: R.dw ? R.dw.lines.length : 0, families: R.dw && R.dw.fam ? new Set(R.dw.fam.map(f => f[0])).size : 0,
          until: R.dw ? R.dw.until : null, pack: D.dogcast ? Object.keys(D.dogcast.lines).length : 0,
          dwInPack: R.dw && D.dogcast ? R.dw.lines.filter(l => D.dogcast.lines[l.key]).length : 0 };
      }
      if (PG.kind === 'lucky') {
        const A = window.HM64LuckyApp, C = window.HM64Lucky;
        if ($('arLucky')) $('arLucky').click();
        await sleep(200);
        const lbl = $('lkSparLbl');
        out.lucky = { route: $('lkRouteName') && $('lkRouteName').textContent, sparrowBox: lbl ? (lbl.hidden ? 'hidden' : 'shown') : 'none',
          sparrowDisabled: $('lkSparrows') ? $('lkSparrows').disabled : null,
          note: [...document.querySelectorAll('#settingsDlg [data-pane="lucky"] .small.mut')].map(e => e.textContent).filter(t => /sparrow/i.test(t)),
          plans: A.plans ? A.plans.length : 0, best: A.plans && A.plans[0] ? Math.round(A.run.T * 1000) / 1000 : null };
        // the S key on a page without a sparrow table changes nothing
        const before = $('lkSparrows') ? $('lkSparrows').checked : null;
        document.dispatchEvent(new KeyboardEvent('keydown', { code: 'KeyS', key: 's', bubbles: true, cancelable: true }));
        await sleep(50);
        out.lucky.sKey = { before, after: $('lkSparrows') ? $('lkSparrows').checked : null, sparrowBox: lbl ? (lbl.hidden ? 'hidden' : 'shown') : 'none' };
        // the dog after a cast comes from this file's pack: every dog line of the route has its casts
        const P = D.dogcast, Rt = D.lroutes[0];
        let ok = 0, miss = 0;
        for (const L of Rt.dw.lines) for (const k of [100, 600, 1200, 2400]) {
          const code = C.dogAfterCast(P, L.key, k, 30, 0, 0);
          if (code === undefined || code === null) miss++; else ok++;
        }
        out.lucky.dogAfterCast = { ok, miss };
      }
      if (PG.kind === 'casting') {
        if ($('arOracle')) { $('arOracle').click(); await sleep(80); }
        const R = window.HM64DogRef;
        const done = () => R && R.shown && R.shown.all && !/working out/.test($('rfBody').textContent);
        for (let i = 0; i < 2400 && !done(); i++) await sleep(50);
        const b = $('rfSpar');
        out.casting = { done: done(), route: R && R.shown && R.shown.routeId, rows: document.querySelectorAll('#rfBody tr').length,
          sparrowBox: b ? (b.parentNode.hidden ? 'hidden' : 'shown') : 'none', sparrowDisabled: b ? b.disabled : null,
          routes: [...$('rfRoute').options].map(o => o.value) };
      }
      if (PG.kind === 'practice') {
        await sleep(300);
        const Pr = window.HM64Practice;
        out.practice = { sparrowBox: $('prSparBox') ? ($('prSparBox').hidden ? 'hidden' : 'shown') : 'none',
          route: Pr && Pr.route ? (typeof Pr.route === 'function' ? (Pr.route() || {}).id : Pr.route.id) : null };
      }
    } catch (e) { out.errors.push('test: ' + e.message + ' ' + (e.stack || '').split('\n')[1]); }
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, 600);
})();
