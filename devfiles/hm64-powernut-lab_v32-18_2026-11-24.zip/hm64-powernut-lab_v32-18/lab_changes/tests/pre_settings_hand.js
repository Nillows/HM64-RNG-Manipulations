/* v32.16: a player who set the spread and the start-tap delay by hand on the Settings page (tests/ui_settings_casting.js) */
try { localStorage.setItem('hm64v29_lucky', JSON.stringify({ cueV: 1, castTapV: 1, sigmaAuto: false, sigmaMs: 220, startTapMs: 200 })); } catch (e) { /* storage off */ }
