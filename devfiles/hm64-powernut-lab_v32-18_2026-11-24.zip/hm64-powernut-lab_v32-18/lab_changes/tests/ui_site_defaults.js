/* headless (v32.1): a hub Lucky Timer page starts on its own game file's route. Run with tests/pre_site_seed.js (a
   stored setting from another page of the same site: route lineup-lineup2, its pier start) or with no pre-script
   (fresh browser). Reports the route / start the page chose, the route menu, the sparrow box, dog-watch, and that the
   page's route is kept per page once changed. */
(function () {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => {
    const A = window.HM64LuckyApp, C = window.HM64Lucky, $ = id => document.getElementById(id), out = { errors: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    try {
      out.page = (typeof HM64_PAGE !== 'undefined') ? { set: HM64_PAGE.set, defaults: HM64_PAGE.luckyDefaults || null, carry: HM64_PAGE.carry } : null;
      out.start = { route: C.selection.route, anchor: C.selection.anchor, Lroute: A.L.route, routeAnchor: A.L.routeAnchor };
      out.menu = [...$('lkRoute').options].map(o => o.value);
      out.dw = { on: A.L.dwOn, routeDw: !!(C.routeOf(C.selection.route).dw), lines: (C.routeOf(C.selection.route).dw || { lines: [] }).lines.length };
      out.sparrowBox = !!($('lkSparrows') && !$('lkSparrows').closest('[hidden]'));
      out.plans = A.plans.length; out.planTxt = ($('lkPlanTxt') || {}).textContent;
      // switch to the sparrow table and back: kept per page
      const sp = C.routes().find(r => r.variant_of === C.selection.route && r.variant === 'sparrows');
      out.sparrowTable = sp ? sp.id : null;
      if (sp && $('lkSparrows')) { $('lkSparrows').checked = true; $('lkSparrows').onchange({ target: $('lkSparrows') }); await sleep(50); }
      out.afterSparrow = { route: C.selection.route, anchor: C.selection.anchor, bySet: A.L.routeBySet || null };
      const st = JSON.parse(localStorage.getItem('hm64v29_lucky') || '{}');
      out.stored = { route: st.route, bySet: st.routeBySet || null };
      out.footer = [...document.querySelectorAll('footer a')].map(a => a.getAttribute('href'));
      out.chip = (document.querySelector('footer .chip.set') || {}).textContent;
    } catch (err) { out.errors.push(String(err && err.stack || err)); }
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out, null, 1); document.body.appendChild(pre);
  }, 600);
})();
