/* headless (v32.7): the hub's Guide and Not working? buttons open the guide on the game file that is ticked. */
(function () {
  setTimeout(() => {
    const $ = id => document.getElementById(id), out = { errors: [], seen: [] };
    try {
      const cb = id => $('hubTicks').querySelector(`input[data-t="${id}"]`);
      const st = () => [$('hubName').textContent, $('hubGuide').getAttribute('href'), $('hubNW').getAttribute('href')];
      out.seen.push(st()); cb('horse').click(); out.seen.push(st()); cb('rainy').click(); out.seen.push(st());
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const p = document.createElement('pre'); p.id = 'testout'; p.textContent = JSON.stringify(out); document.body.appendChild(p);
  }, 300);
})();
