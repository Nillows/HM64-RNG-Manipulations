/* headless (v32.6, Thomas 2026-11-24): Settings -> "Show the release window under the histogram". On by default; off
   hides the Freestyle release lane (and its threads) and, in the app's own odds, the lane of bites after the cast with
   its release band - the bars take the whole height. The lane's data (run.fsLive, used by the lamp) is still worked out. */
(function () {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => {
    const A = window.HM64LuckyApp, $ = id => document.getElementById(id), out = { errors: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    const ev = (type, o) => { const e = new KeyboardEvent(type, Object.assign({ code: 'Space', key: ' ', bubbles: true, cancelable: true }, o || {})); document.dispatchEvent(e); };
    const tick = () => { if (A.run.wall0 !== null) A.frameOnce(); };
    /* how much of the histogram's bottom 96 px is not background: the release lane is drawn there */
    const lowInk = () => { const cv = $('lkTimeline'), g = cv.getContext('2d'), h = Math.round(96 * devicePixelRatio), y0 = cv.height - h, d = g.getImageData(0, y0, cv.width, h - Math.round(26 * devicePixelRatio)).data;
      let n = 0; for (let i = 0; i < d.length; i += 4) if (d[i] + d[i + 1] + d[i + 2] > 120) n++; return n; };
    try {
      localStorage.clear(); $('arLucky').click(); A.L.audio = false;
      out.box = { exists: !!$('lkRelWin'), checked: $('lkRelWin').checked, label: $('lkRelWin').parentElement.textContent.trim().slice(0, 60) };
      /* the app's odds view (idle) */
      A.refresh(); await sleep(50); const idleOn = lowInk();
      $('lkRelWin').checked = false; $('lkRelWin').onchange({ target: $('lkRelWin') }); A.refresh(); await sleep(50); const idleOff = lowInk();
      out.idle = { on: idleOn, off: idleOff, stored: A.L.relWin };
      $('lkRelWin').checked = true; $('lkRelWin').onchange({ target: $('lkRelWin') });
      /* freestyle with the top dog chosen */
      $('lkDwOn').checked = true; $('lkDwOn').onchange({ target: $('lkDwOn') });
      ev('keydown'); ev('keyup'); await sleep(1200); tick();
      ev('keydown', { code: 'Enter', key: 'Enter' }); await sleep(50); tick();
      out.known = A.run.known; out.fs = A.fsOn();
      await sleep(2500); tick(); const fsOn = lowInk(), liveOn = A.run.fsLive ? A.run.fsLive.length : null;
      $('lkRelWin').checked = false; $('lkRelWin').onchange({ target: $('lkRelWin') }); tick();
      const fsOff = lowInk(), liveOff = A.run.fsLive ? A.run.fsLive.length : null;
      out.freestyle = { on: fsOn, off: fsOff, fsLiveOn: liveOn, fsLiveOff: liveOff };
      ev('keydown', { code: 'Escape', key: 'Escape' });
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const p = document.createElement('pre'); p.id = 'testout'; p.textContent = JSON.stringify(out); document.body.appendChild(p);
  }, 400);
})();
