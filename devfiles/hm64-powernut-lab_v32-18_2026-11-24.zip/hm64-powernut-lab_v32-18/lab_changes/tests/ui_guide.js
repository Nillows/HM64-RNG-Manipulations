/* headless (v32.7; v32.15: three pages). Run on guide.html, not-working.html and how-it-works.html (pre_guide_hub.js seeds
   the hub's ticks: horse). Each page: its own sections only, the nav (the page itself not a link; the other guide pages
   carry ?set= of the ticked file), the game file shown. guide.html: the picker opens the ticked file and switching it
   moves the other pages' links to the new file. not-working.html: the 10 answers, links back to the guide's setup /
   beach / awake on the file. how-it-works.html: the forest pictures. */
(function () {
  setTimeout(() => {
    const out = { errors: [] };
    try {
      const ids = [...document.querySelectorAll('[id]')].map(e => e.id);
      const has = l => l.filter(i => ids.includes(i));
      out.title = document.title.split(' · ')[0];
      out.guideIds = has(['setup', 'route', 'menus', 'sparrows', 'path', 'beach', 'space', 'awake']);
      out.oldIds = has(['not-working', 'how-it-works']);
      out.nw = ids.filter(i => i.startsWith('nw-'));
      out.imgs = [...document.querySelectorAll('figure img')].map(i => i.getAttribute('src'));
      out.nav = [...document.querySelectorAll('nav.top > *')].map(a => [a.tagName, a.textContent, a.getAttribute('href')]);
      out.G = window.HM64Guide ? [window.HM64Guide.set, window.HM64Guide.label] : null;
      out.keep = [...document.querySelectorAll('.wrap a[data-keep]')].map(a => [a.textContent, a.getAttribute('href')]);
      out.setname = [...document.querySelectorAll('.setname')].map(e => e.textContent);
      if (document.getElementById('gdPicks')) {
        out.sets = [...document.querySelectorAll('details.set')].map(d => [d.id, d.open, d.classList.contains('yours')]);
        const b = [...document.querySelectorAll('#gdPicks button')].find(x => x.dataset.set === 'sunny-no-horse');
        b.click();
        out.after = [...document.querySelectorAll('details.set')].map(d => [d.id, d.open, d.classList.contains('yours')]);
        out.navAfter = [...document.querySelectorAll('nav.top a[data-keep]')].map(a => a.getAttribute('href'));
        out.pages = [...document.querySelectorAll('#setup-sunny-horse .pages a')].map(a => a.getAttribute('href'));
      }
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const p = document.createElement('pre'); p.id = 'testout'; p.textContent = JSON.stringify(out); document.body.appendChild(p);
  }, 300);
})();
