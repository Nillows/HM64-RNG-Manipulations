/* headless (v32.2): the window thumbnails draw, one per Optimal Blind Casting row, and the close-up opens */
(function () { const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => { const $ = id => document.getElementById(id), out = { errors: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    try {
      const R = window.HM64DogRef;
      const done = () => R && R.shown && R.shown.blind && R.shown.blind.all && R.shown.blind.all.win && !/working out/.test($('rfBody').textContent);
      for (let i = 0; i < 2400 && !done(); i++) await sleep(50);
      const cvs = [...document.querySelectorAll('canvas.rfthumb')];
      out.rows = document.querySelectorAll('.rfblind tr').length - 1;
      out.thumbs = cvs.length;
      out.painted = cvs.filter(c => c.width > 0).length;
      out.sizes = cvs.slice(0, 3).map(c => c.style.width + 'x' + c.style.height);
      const sh = R.shown.blind;
      out.check = sh.rows.map(r => { const c = r.chart; if (!c) return null; const k = c.pol === 'hold' ? 's2' : 's1';
        const inW = c[k].slice(c.st - c.a, c.st - c.a + c.n); const avg = inW.reduce((q, v) => q + v, 0) / c.n;
        const sumL = c.lines.reduce((q, l) => q + l.share * l[k === 's1' ? 'f1' : 'f2'].slice(c.st - c.a, c.st - c.a + c.n).reduce((a, v) => a + v, 0) / c.n, 0);
        return [+(100 * r.win.p).toFixed(3), +(100 * avg).toFixed(3), +(100 * sumL).toFixed(3), c.lines.length, c.s1.length]; });
      const pick = window.__pick || 'b0';
      cvs.find(c => c.dataset.ch === pick).click(); await sleep(100);
      const d = $('rfChartDlg'); out.dlgOpen = !!(d && d.open); out.title = $('rfcTitle').textContent; out.sub = $('rfcSub').textContent; out.note = $('rfcNote').textContent;
      const cv = $('rfcCanvas'); out.big = cv.style.width + 'x' + cv.style.height;
      const r = cv.getBoundingClientRect();
      cv.dispatchEvent(new MouseEvent('mousemove', { clientX: r.left + r.width * 0.5, clientY: r.top + 40, bubbles: true }));
      await sleep(50); out.read = $('rfcRead').textContent;
      window.__shot = true;
    } catch (e) { out.errors.push('test: ' + e.message + ' ' + e.stack); }
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out, null, 1); document.body.appendChild(pre);
  }, 400); })();
