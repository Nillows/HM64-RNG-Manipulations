/* headless (v32.5, Thomas 19:58: "make sure the practice activities take preferences from the players specific keyboard
   layout"): the Dog practice page takes the Lucky Timer's stored keys (facing scheme, animation keys, tuning keys, start
   key, cards, start delay), labels them by the player's layout, and keys can be changed on the page. Seed:
   tests/pre_practice_keys.js. */
(function () {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const kd = (code, key, o) => { const e = new KeyboardEvent('keydown', Object.assign({ code, key, bubbles: true, cancelable: true }, o || {})); document.dispatchEvent(e); return e.defaultPrevented; };
  setTimeout(async () => {
    const X = window.HM64Practice, $ = id => document.getElementById(id), out = { errors: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    try {
      const K = X.K;
      out.keys = { src: K.src, facing: K.facing, adj: K.adj, start: K.startKey, cards: K.cards, fill: K.fill, delay: K.delayMs, sit: (K.groups.find(g => g.code === 'KeyJ') || {}).label };
      out.labels = { W: X.keyTxt('KeyW'), A: X.keyTxt('KeyA'), comma: X.keyTxt('Comma') };
      out.keyLine = $('prKeys').textContent.slice(0, 260);
      /* the start key q starts a drill; W A S D log facings; J logs sit */
      document.querySelector('#prDrills button[data-d="read"]').click();
      kd('KeyQ', 'q'); await sleep(1700);
      out.started = !!X.S && X.S.kind === 'read';
      kd('KeyA', 'a'); kd('KeyJ', 'j'); await sleep(30);
      out.logs = X.S.logs.map(l => (l.f != null ? 'f' + l.f : 'g' + l.g));
      out.cards = document.querySelectorAll('.prcard').length;
      kd('Escape', 'Escape');
      /* tuning keys , and . in the tune drill */
      document.querySelector('#prDrills button[data-d="tune"]').click(); X.newDrill('tune'); await sleep(1700);
      const a0 = X.S.adj; kd('Period', '.'); kd('Period', '.'); kd('Comma', ',');
      out.tune = X.S.adj - a0;
      kd('Escape', 'Escape');
      /* change a key on the page: the earlier key becomes K; then back to the Lucky Timer's keys */
      $('prKeyEdit').click(); await sleep(10);
      out.editor = !$('prKeyEd').hidden;
      $('prKeyEd').querySelector('button.prkey[data-kind="adj"][data-slot="0"]').click(); await sleep(5);
      const refused = kd('KeyW', 'w');                          // a facing key: refused
      out.refused = $('prKeyEd').textContent.match(/is a facing key/) ? 'facing key refused' : 'not refused';
      kd('KeyK', 'k'); await sleep(5);
      out.changed = { adj: X.K.adj, src: X.K.src, stored: JSON.parse(localStorage.getItem('hm64v32_practice')).keys.dwAdjKeys };
      $('prKeyLucky').click(); await sleep(5);
      out.back = { adj: X.K.adj, src: X.K.src };
      /* help */
      $('helpBtn').click(); await sleep(10);
      out.help = { open: $('helpDlg').open, h2: $('helpBody').querySelector('h2').textContent, why: /How the odds are worked out/.test($('helpBody').textContent) };
      void refused;
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const p = document.createElement('pre'); p.id = 'testout'; p.textContent = JSON.stringify(out); document.body.appendChild(p);
  }, 600);
})();
