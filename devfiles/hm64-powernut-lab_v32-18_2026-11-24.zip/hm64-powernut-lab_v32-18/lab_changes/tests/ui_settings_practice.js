/* headless (v32.16): Dog practice feeds the shared stores. Two whole attempts (tap at READY, Enter, tune to the truth,
   cast on a Nut frame, let go 6 VIs into the Nut bite): the shared attempt count +2 (practice), two READY taps
   (~50 ms after Jack stops), two bite reactions (~100 ms, ok, m rel, c 1, src Dog practice); the keys line points to
   Settings; a page key override from before v32.16 moved into the shared store (pre_settings_practice.js). */
(function () {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const key = (type, code, k, extra) => { const e = new KeyboardEvent(type, Object.assign({ code, key: k, bubbles: true, cancelable: true }, extra || {})); document.dispatchEvent(e); return e.defaultPrevented; };
  setTimeout(async () => {
    const X = window.HM64Practice, T = window.HM64Timing, $ = id => document.getElementById(id), out = { errors: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    try {
      out.migrated = { lucky: (JSON.parse(localStorage.getItem('hm64v29_lucky') || '{}') || {}).dwKeys, page: (JSON.parse(localStorage.getItem('hm64v32_practice') || '{}') || {}).keys || null, K: X.K.facing };
      out.keysLine = ($('prKeys').textContent || '').slice(-60);
      const n0 = T.attempts(), by0 = T.attemptsBy().practice, s0 = T.startTaps().length, b0 = T.biteLog().length;
      for (let n = 0; n < 2; n++) {
        X.PS.line = 'any'; X.newDrill('whole'); const S = X.S;
        await sleep(2650);
        key('keydown', 'KeyW' === X.K.startKey ? 'KeyW' : 'Space', X.K.startKey); await sleep(20);
        S.pick = null; X.pick(S.a.dwi, 'test');
        const A = S.pick.A; S.adj = 2 * Math.round((S.a.o + S.lag - A) / 2);
        key('keydown', 'Enter', 'Enter');
        const key0 = S.R.dw.lines[S.a.dwi].key, gs = X.nutGroups(key0, S.a.o, X.eTrue() + 60, X.eTrue() + 1200);
        if (!gs.length) { key('keydown', 'Escape', 'Escape'); continue; }
        const g = gs[0], eC = 2 * g.i0 + 1;
        await sleep((eC - X.eTrue()) * 16.715);
        key('keydown', 'Space', X.K.startKey); await sleep(20);
        const nb = S.cast.rec ? S.cast.rec.nut : -1, b = S.cast.bites[nb];
        if (!b) { key('keyup', 'Space', X.K.startKey); continue; }
        await sleep((b.e + 6 - X.eTrue()) * 16.715);
        key('keyup', 'Space', X.K.startKey); await sleep(30);
        out['result' + n] = S.result;
      }
      out.attempts = [T.attempts() - n0, T.attemptsBy().practice - by0];
      out.startTaps = T.startTaps().slice(s0).map(r => [r.ms, r.src]);
      out.bites = T.biteLog().slice(b0).map(r => [Math.round(r.r), r.k, r.m, r.c, r.src]);
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const p = document.createElement('pre'); p.id = 'testout'; p.textContent = JSON.stringify(out); document.body.appendChild(p);
  }, 600);
})();
