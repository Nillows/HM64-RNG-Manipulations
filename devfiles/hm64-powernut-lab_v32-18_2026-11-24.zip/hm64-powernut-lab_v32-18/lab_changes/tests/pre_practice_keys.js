/* seed (v32.5 test): a player whose Lucky Timer uses W A S D, tuning on , and . , sit on J and the start key q */
localStorage.clear();
localStorage.setItem('hm64v29_lucky', JSON.stringify({ dwKeys: 'wasd', dwAdjKeys: ['Comma', 'Period'], dwAnimKeys: { 40: 'KeyJ' }, startKey: 'q', dwCards: 3, dwFill: 'ltr', startTapMs: 180 }));
localStorage.setItem('hm64v32_keylabels', JSON.stringify({ KeyW: 'z', KeyA: 'q' }));
