/* headless: dump the Dog reference's harbinger list (lineup2, no sparrows, ±150 ms) and the candidates it is built from */
(function () { const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => { const A = window.HM64LuckyApp, R = window.HM64DogRef, $ = id => document.getElementById(id), out = { errors: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    try {
      $('arOracle').click(); await sleep(200);
      const sp = $('rfSpar'); if (sp && sp.checked) { sp.checked = false; sp.onchange({ target: sp }); }
      const rt = $('rfRoute'); if (rt.value !== 'lineup-lineup2') { rt.value = 'lineup-lineup2'; rt.onchange({ target: rt }); }
      const done = () => R.shown && R.shown.routeId === 'lineup-lineup2' && R.shown.all && !/working out/.test($('rfBody').textContent);
      for (let i = 0; i < 600 && !done(); i++) await sleep(50);
      const o = R.shown, vi = A.viMs(), s = t => +((t - 1) * vi / 1000).toFixed(2);
      const cast = c => (c ? { rule: c.simple, at: s(c[c.simple].t), p: +c[c.simple].p.toFixed(4) } : null);
      out.route = o.routeId; out.sig = o.sigMs; out.vi = vi; out.all = cast(o.all);
      out.harb = o.harb.map(r => ({ base: r.base, name: HM64_DATA.names[r.base] || ('anim ' + r.base), dir: r.dir, tVI: +r.t.toFixed(2), t: +(r.t * vi / 1000).toFixed(2), share: +r.share.toFixed(5), pure: +r.pure.toFixed(4), line: r.line, dwi: r.dwi, cast: cast(r.cast) }));
      out.arrivePinned = o.arrive.filter(r => r.lines[0].p >= 0.9).map(r => ({ dog: (HM64_DATA.names[r.base] || r.base) + ' ' + r.dir, share: +r.share.toFixed(4), line: r.lines[0].name }));
      const X = R.ctx('lineup-lineup2');
      out.cands = X.cands.map(c => [c.dwi, c.ko, c.mt, +c.w.toFixed(8), c.pv]);
      out.names = HM64_DATA.names;
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, 1500);
})();
