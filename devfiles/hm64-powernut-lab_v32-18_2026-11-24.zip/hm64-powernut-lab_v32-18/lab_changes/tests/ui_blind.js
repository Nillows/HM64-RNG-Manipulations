/* headless (v31.30): the Dog reference's Optimal Blind Casting tab and the casts past 40 s - dump everything the page
   computed (lineup2, no sparrows, ±150 ms), the DOM of the new tab, the stopwatch push reminder; then the sparrow table */
(function () { const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => { const A = window.HM64LuckyApp, R = window.HM64DogRef, $ = id => document.getElementById(id), out = { errors: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    try {
      $('arOracle').click(); await sleep(200);
      const done = id => R.shown && R.shown.routeId === id && R.shown.all && R.shown.blind && R.shown.blind.all.win && !/working out/.test($('rfBody').textContent);
      const wait = async id => { for (let i = 0; i < 900 && !done(id); i++) await sleep(50); };
      const sp = $('rfSpar'); if (sp && sp.checked) { sp.checked = false; sp.onchange({ target: sp }); }
      const rt = $('rfRoute'); if (rt.value !== 'lineup-lineup2') { rt.value = 'lineup-lineup2'; rt.onchange({ target: rt }); }
      await wait('lineup-lineup2');
      const vi = A.viMs(), s = t => +((t - 1) * vi / 1000).toFixed(3);
      const W = w => (w ? { pol: w.pol, p: +w.p.toFixed(5), t: s(w.t), lo: s(w.lo), hi: s(w.hi) } : null);
      const cast = c => (c ? { rule: c.simple, at: s(c[c.simple].t), p: +c[c.simple].p.toFixed(4), late: !!c.late } : null);
      const dump = () => { const o = R.shown; return {
        route: o.routeId, tab: R.state.tab, all: cast(o.all),
        blind: o.blind.rows.map(r => ({ name: (HM64_DATA.names[r.base] || r.base), dir: r.dir, dwi: r.dwi, line: r.line, bins: r.bins, t: +(r.t * vi / 1000).toFixed(2), tMaxVI: r.tMax, share: +r.share.toFixed(5), win: W(r.win) })),
        none: { share: +o.blind.none.share.toFixed(5), win: W(o.blind.none.win) }, notWatching: W(o.blind.all.win),
        harb: o.harb.map(r => ({ name: HM64_DATA.names[r.base] || r.base, dir: r.dir, t: +(r.t * vi / 1000).toFixed(2), line: r.line, share: +r.share.toFixed(5), pure: +r.pure.toFixed(4), cast: cast(r.cast) })),
        lines: o.lines.slice(0, 12).map(r => ({ name: r.name, share: +r.share.toFixed(4), cast: cast(r.cast) })),
        arrive: o.arrive.slice(0, 8).map(r => ({ dog: (HM64_DATA.names[r.base] || r.base) + ' ' + r.dir, share: +r.share.toFixed(4), line: r.lines[0].name, cast: cast(r.cast) })) }; };
      out.main = dump();
      // the DOM of the new tab (first tab, shown)
      const pane = document.querySelector('#rfBody .rfpane[data-pane="blind"]');
      out.dom = { tabs: [...document.querySelectorAll('#rfBody .rftabs button')].map(b => b.textContent + (b.classList.contains('on') ? '*' : '')), shown: pane && !pane.hidden,
        rows: pane ? [...pane.querySelectorAll('tr')].map(tr => tr.textContent.replace(/\s+/g, ' ').trim()) : [], text: pane ? pane.textContent.replace(/\s+/g, ' ').slice(0, 1600) : '' };
      // a click on the first row puts its cast on the stopwatch; the push reminder
      const tr = pane.querySelectorAll('tr')[1]; tr.click(); await sleep(30);
      out.target = { t: s(R.timer.target), txt: $('rfTarget').textContent };
      R.timer.t0 = performance.now() - 33000; R.start && 0; await sleep(120);
      const key = (code, k) => { const e = new KeyboardEvent('keydown', { code, key: k || code, bubbles: true, cancelable: true }); document.dispatchEvent(e); };
      out.push = $('rfTarget').textContent;
      key('Escape'); await sleep(30);
      // the sparrow table
      const ev = new KeyboardEvent('keydown', { code: 'KeyS', key: 's', bubbles: true, cancelable: true }); document.dispatchEvent(ev);
      await wait('lineup-lineup2-sparrow-door');
      out.sparrow = dump();
      out.help = (() => { $('helpBtn').click(); const t = $('helpBody').textContent; $('helpDlg').close(); const i = t.indexOf('Dog reference.'); return t.slice(i, i + 700); })();
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, 1500);
})();
