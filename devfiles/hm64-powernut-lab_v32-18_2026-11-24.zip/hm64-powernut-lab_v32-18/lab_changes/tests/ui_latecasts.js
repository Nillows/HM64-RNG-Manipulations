/* headless (v31.30): the latest cast time anywhere on the Dog reference (both tables, all tabs), to see whether any
   cast needs a second stay-awake push (casts after ~72.8 s: Jack lies down 40 s after the 33.4-s push) */
(function () { const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => { const A = window.HM64LuckyApp, R = window.HM64DogRef, $ = id => document.getElementById(id), out = { errors: [], tables: {} };
    try {
      $('arOracle').click(); await sleep(200);
      const vi = A.viMs(), s = t => +((t - 1) * vi / 1000).toFixed(2);
      const done = id => R.shown && R.shown.routeId === id && R.shown.all && R.shown.blind && R.shown.blind.all.win && !/working out/.test($('rfBody').textContent);
      for (const [id, spar] of [['lineup-lineup2', false], ['lineup-lineup2-sparrow-door', true]]) {
        R.setSparrow(spar);
        for (let i = 0; i < 900 && !done(id); i++) await sleep(50);
        const o = R.shown, ts = [];
        const add = (c, where) => { if (!c) return; for (const k of ['bite1', 'hold']) if (c[k]) ts.push([s(c[k].t), where + ':' + k]); if (c.quick) ts.push([s(c.quick.t), where + ':quick']); };
        add(o.all, 'all'); o.arrive.forEach((r, i) => { add(r.cast, 'arrive' + i); r.split.forEach((q, j) => add(q.cast, 'split' + i + '.' + j)); });
        o.harb.forEach((r, i) => add(r.cast, 'harb' + i)); o.lines.forEach(r => add(r.cast, r.name));
        o.blind.rows.forEach((r, i) => r.win && ts.push([s(r.win.hi), 'blind' + i])); ts.push([s(o.blind.none.win.hi), 'none']);
        ts.sort((a, b) => b[0] - a[0]);
        const main = []; o.lines.forEach(r => r.cast && main.push([r.name, s(r.cast[r.cast.simple].t)]));
        out.tables[id] = { n: ts.length, latest: ts.slice(0, 8), over728: ts.filter(x => x[0] > 72.8).length, mainOver728: main.filter(x => x[1] > 72.8) };
      }
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, 1500);
})();
