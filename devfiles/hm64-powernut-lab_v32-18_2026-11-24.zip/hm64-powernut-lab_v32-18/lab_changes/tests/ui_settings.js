/* headless (v32.16): the Settings page. With pre_settings_seed.js (a seeded store): no errors; the attempt count starts
   from what is on record; the numbers equal the Lucky Timer's (tests/ui_settings_lucky.js prints those for the same
   store); the cast drill writes a cast-practice press and (combo) a release in the Lucky Timer's formats; the bite drill
   a reaction; the start key and an animation key are set with the Lucky Timer's refusals; a hand-set value lands in the
   shared store; export / import round-trip. rAF does not run headless: the test calls HM64Settings.tick(). */
(function () {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => {
    const $ = id => document.getElementById(id), out = { errors: [] }, T = window.HM64Timing, S = window.HM64Settings;
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    try {
      out.attempts = [$('stAttN').textContent, $('stAttBy').textContent];
      out.numbers = { corr: T.cueCorr(), sigma: T.sigmaMs(), press: T.pressReady() && { n: T.pressReady().n, med: T.pressReady().med, sd: +T.pressReady().sd.toFixed(3) },
        bp: T.bpReact().s && { n: T.bpReact().s.n, med: T.bpReact().s.med, kind: T.bpReact().kind }, vi: T.viMs() };
      out.rows = S.timingRows().map(r => [r[0], r[1]]);
      out.dots = S.liveDots().map(d => [d.id, d.x == null ? null : Math.round(d.x), d.y == null ? null : Math.round(d.y), d.n]);
      out.compassTbl = ($('stCompassTbl').textContent || '').slice(0, 80);
      /* the cast drill: a press 30 ms late, then (combo) a release 200 ms after the bite */
      const n0 = T.castLog().length, b0 = T.biteLog().length;
      S.castStart(); await sleep(800);
      const D = S.drill; out.castArmed = D && D.state;
      S.down(D.cue + 30, 'test');
      out.afterPress = S.drill.state;
      S.drill.hb.at = performance.now() - 1; S.tick();
      out.shown = S.drill.hb.shown != null;
      S.up(S.drill.hb.shown + 200, 'test release');
      out.castRec = T.castLog().slice(n0); out.relRec = T.biteLog().slice(b0);
      S.stopDrill();
      /* the bite drill: hold, the bite shows, let go 150 ms later */
      const b1 = T.biteLog().length;
      S.biteStart(); S.down(performance.now(), 'test'); out.biteWait = S.drill.state;
      S.drill.at = performance.now() - 1; S.tick(); out.biteShown = S.drill.state;
      S.up(S.drill.shown + 150, 'test release'); out.biteRec = T.biteLog().slice(b1);
      S.drill.doneAt -= 5000; S.tick(); out.biteNext = S.drill.state;
      S.stopDrill();
      /* keys: the start key, then an animation key (q is now the start key: refused), then z */
      $('stStartKey').click();
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'q', code: 'KeyQ', bubbles: true }));
      out.startKey = T.lucky().startKey;
      const ab = $('stKeyTbl').querySelector('[data-k^="anim:"]'); const base = ab.dataset.k.split(':')[1]; ab.click();
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'q', code: 'KeyQ', bubbles: true }));
      out.refused = ($('stKeyTbl').querySelector('div.small') || {}).textContent || '';
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'z', code: 'KeyZ', bubbles: true }));
      out.animKey = [base, (T.lucky().dwAnimKeys || {})[base]];
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', bubbles: true }));
      /* a hand-set value */
      $('stStartDelay').value = '180'; $('stStartDelay').dispatchEvent(new Event('change'));
      out.startTapMs = T.lucky().startTapMs;
      $('stSigmaAuto').checked = false; $('stSigmaAuto').dispatchEvent(new Event('change'));
      out.sigmaHand = [T.lucky().sigmaAuto, T.lucky().sigmaMs, T.sigmaMs()];
      /* export / import */
      const ex = T.exportAll(); out.exportKeys = Object.keys(ex.keys).sort();
      localStorage.setItem('hm64v29_lucky', '{}'); const k = T.importAll(ex); out.importN = k; out.afterImport = T.lucky().startKey;
      /* the other fields of the Lucky Timer's object survive a Settings write */
      out.keepsOthers = JSON.parse(localStorage.getItem('hm64v29_lucky')).route;
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const p = document.createElement('pre'); p.id = 'testout'; p.textContent = JSON.stringify(out); document.body.appendChild(p);
  }, 400);
})();
