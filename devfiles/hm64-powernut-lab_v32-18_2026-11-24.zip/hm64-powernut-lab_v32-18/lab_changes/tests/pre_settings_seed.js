/* v32.16: a seeded store for tests/ui_settings.js and tests/ui_settings_lucky.js (the same numbers on both pages) */
try {
  const set = (k, v) => localStorage.setItem(k, JSON.stringify(v));
  set('hm64v30_tb', { from: 33.43, to: 33.43, changed: false, at: '2026-11-24T00:00:00Z' });
  set('hm64v28_settings', { updateMs: 33.43 });
  set('hm64v29_lucky', { route: 'lineup-lineup2', routeAnchor: { 'lineup-lineup2': 'pier' }, cueV: 1, castTapV: 1, startTapMs: 140, pracLine: true, audio: false, autoTune: true });
  const es = [20, 35, -10, 50, 28, 40, 15, 60, 33, 25, 5, 45, 400];
  set('hm64v29_lucky_castprac', es.map((e, i) => ({ at: 1764000000000 + i, e, m: 'line', src: 'Space', v: 1 })).concat([{ at: 1764000000100, e: null, m: 'line', src: 'Space', v: 1 }, { at: 1764000000101, e: 90, m: 'beeps', src: 'Space', v: 1 }]));
  const rs = [210, 230, 190, 250, 205, 220, 240, 300, 199, 215];
  set('hm64v30_lucky_biteprac', rs.map((r, i) => ({ at: 1764000000200 + i, r, k: r <= 334 ? 'ok' : 'late', w: 334, m: 'rel', c: 1, src: 'Space release' })).concat([{ at: 1764000000300, r: null, k: 'early', w: 334, m: 'rel', src: '' }]));
  set('hm64v29_lucky_tally', [30, 40, 25].map((c, i) => ({ at: 1764000000400 + i, aid: 1764000000400 + i, plan: 'x', pol: 'auto', T: '20.0', hit: false, outcome: 'miss', sigma: 150, castErrMs: c, v: 1 })));
  set('hm64v32_practice_stats', { tune: [], read: [], whole: [{ at: 1 }, { at: 2 }] });
} catch (e) { /* storage off */ }
