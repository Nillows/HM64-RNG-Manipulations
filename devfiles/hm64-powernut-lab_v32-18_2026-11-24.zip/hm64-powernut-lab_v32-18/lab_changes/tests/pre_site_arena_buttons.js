/* test adapter (v32.0 hub pages): the v31 tests click the footer's arena buttons to open the Lucky Timer; the hub's
   Lucky Timer page has no arena buttons (it is always the Lucky Timer), so this adds two hidden ones before the app
   runs. A click on either one keeps the Lucky Timer (setArena forces it on a page without the Dog reference). */
(function () {
  var f = document.querySelector('footer'); if (!f) return;
  ['arOracle', 'arLucky'].forEach(function (id) { if (!document.getElementById(id)) { var b = document.createElement('button'); b.id = id; b.hidden = true; f.appendChild(b); } });
})();
