/* headless (v32.3): every line's timings, weighted by their shares, give back the line's drawn Nut fractions */
(function () { const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => { const R = window.HM64DogRef, $ = id => document.getElementById(id), out = { errors: [] };
    try {
      for (let i = 0; i < 2400 && !(R && R.shown && R.shown.blind && R.shown.blind.all && R.shown.blind.all.win && !/working out/.test($('rfBody').textContent)); i++) await sleep(50);
      out.check = R.checkTimings();
    } catch (e) { out.errors.push(String(e)); }
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, 400); })();
