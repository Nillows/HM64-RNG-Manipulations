/* headless (v31.30): a cast after 73 s asks for two pushes; the stopwatch says PUSH at ~33 s and ~67 s, not in between */
(function () { const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => { const A = window.HM64LuckyApp, R = window.HM64DogRef, $ = id => document.getElementById(id), out = { errors: [] };
    try {
      $('arOracle').click(); await sleep(200);
      const done = () => R.shown && R.shown.routeId === 'lineup-lineup2' && R.shown.blind && R.shown.blind.all.win && !/working out/.test($('rfBody').textContent);
      for (let i = 0; i < 900 && !done(); i++) await sleep(50);
      const vi = A.viMs(), s = t => (t - 1) * vi / 1000;
      let late = null, mid = null;
      for (const r of R.shown.arrive) for (const c of [r.cast, ...r.split.map(q => q.cast)]) if (c) { const t = c[c.simple].t; if (s(t) > 72.8 && !late) late = t; if (s(t) > 41 && s(t) < 70 && !mid) mid = t; }
      out.lateShown = late; if (!late) late = Math.round(74.18 * 1000 / vi) + 1; out.late = +s(late).toFixed(2); out.mid = +s(mid).toFixed(2);
      // the cell text of that cast in the As you stop tab
      const btn = [...document.querySelectorAll('#rfBody .rfcast')].find(b => +b.dataset.t === late);
      out.cell = btn ? btn.closest('td').textContent.replace(/\s+/g, ' ').slice(0, 260) : null;
      const at = async (t, sec) => { R.setTarget(t, '', null); R.timer.t0 = performance.now() - sec * 1000; await sleep(80); return $('rfTarget').textContent; };
      out.idle = await (async () => { R.setTarget(late, '', null); R.timer.t0 = null; await sleep(50); return $('rfTarget').textContent; })();
      out.at33 = await at(late, 33.2); out.at50 = await at(late, 50); out.at67 = await at(late, 66.8); out.mid67 = await at(mid, 66.8);
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, 1500);
})();
