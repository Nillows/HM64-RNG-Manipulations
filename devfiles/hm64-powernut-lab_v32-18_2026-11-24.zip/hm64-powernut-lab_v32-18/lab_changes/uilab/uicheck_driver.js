/* HM64 UI lab - CONSISTENCY CHECK driver (2026-11-21, app v31.25; 2026-11-23 for v31.27+: freestyle and the start are set
   explicitly, since v31.27 starts with Freestyle on and a one-tap start at the dock end; both starts are played).
   One page = one scenario: a seeded random walk of real user actions (key events, clicks on the page's own controls)
   through one or two attempts and the practice drills, with the app's own frame code run every 50 ms. After every
   action a list of invariants is checked: things that must hold whatever the player does. Nothing is simulated about
   the game; this tests the app against itself and against the lab data it carries.
   window.__SC = { seed, kind, route }.  Result: a pre element with id testout holding JSON: seed, kind, set, cov, viol, errors, steps. */
(function () {
  const SC = window.__UILAB_SC || window.__SC || { seed: 1, kind: 'mixed' };
  let s32 = (SC.seed * 2654435761) >>> 0;
  const rnd = () => { s32 ^= s32 << 13; s32 >>>= 0; s32 ^= s32 >>> 17; s32 ^= s32 << 5; s32 >>>= 0; return s32 / 4294967296; };
  const ri = (a, b) => a + Math.floor(rnd() * (b - a + 1)), pick = a => a[Math.floor(rnd() * a.length)], chance = p => rnd() < p;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const out = { seed: SC.seed, kind: SC.kind, set: {}, cov: {}, viol: [], errors: [], steps: 0, log: [] };
  const cov = k => { out.cov[k] = (out.cov[k] || 0) + 1; };
  const seenV = {};
  let lastAct = 'load';
  const bad = (id, msg) => { if (seenV[id]) { seenV[id].n++; return; } const v = { id, msg: String(msg).slice(0, 240), step: out.steps, after: lastAct, n: 1 }; seenV[id] = v; out.viol.push(v); };
  window.addEventListener('error', e => { out.errors.push(String(e.message).slice(0, 200) + ' @' + lastAct); });
  window.addEventListener('unhandledrejection', e => { out.errors.push('promise: ' + String(e.reason).slice(0, 200) + ' @' + lastAct); });
  const finish = () => { window.__UILAB_DONE = 1; const p = document.createElement('pre'); p.id = 'testout'; p.textContent = JSON.stringify(out); document.body.appendChild(p); document.title = 'DONE'; };
  setTimeout(async () => {
    const A = window.HM64LuckyApp, C = window.HM64Lucky, DW = window.HM64DogWatch, $ = id => document.getElementById(id);
    try {
      if (!A || !A.frameOnce || !A.fsTargetAt) { out.errors.push('no v31.25 hooks'); return finish(); }
      const vi = 33.430 / 2, P = (window.HM64Core && window.HM64Core.data && window.HM64Core.data.dogcast) || null;
      if (!P) out.errors.push('no dog-after-the-cast data in the page');
      const key = (code, k, o) => { const e = new KeyboardEvent('keydown', Object.assign({ code, key: k, bubbles: true, cancelable: true }, o || {})); document.dispatchEvent(e); const u = new KeyboardEvent('keyup', Object.assign({ code, key: k, bubbles: true, cancelable: true }, o || {})); if (!(o && o.hold)) document.dispatchEvent(u); return e.defaultPrevented; };
      const keyUp = (code, k) => document.dispatchEvent(new KeyboardEvent('keyup', { code, key: k, bubbles: true, cancelable: true }));
      const live = () => A.run.wall0 !== null && !A.run.preview && !A.run.practice && !A.run.bite;
      const tNow = () => (performance.now() - A.run.wall0) / vi + 1;
      const frame = () => { try { A.frameOnce(); } catch (e) { out.errors.push('frame: ' + String(e && e.message).slice(0, 160) + ' @' + lastAct); } };
      const ticker = window.__UILAB_RAF ? 0 : setInterval(frame, 50);        // the lab puts the app's own frame loop on the timer clock; without it, tick here
      const host = () => $('lkCompCards'), cards = () => [...host().querySelectorAll('.lkdog')];
      const txt = id => ($(id) ? $(id).textContent : '');
      const setSel = (id, v) => { const el = $(id); if (!el) return false; el.value = v; el.dispatchEvent(new Event('change', { bubbles: true })); if (el.onchange) { try { el.onchange({ target: el }); } catch (e) { out.errors.push('onchange ' + id + ': ' + e.message); } } return true; };
      const setBox = (id, on) => { const el = $(id); if (!el || el.disabled) return false; if (el.checked !== on) el.click(); return el.checked === on; };
      /* ---- an independent walk of the lab pack: the first bite that gives `tg` for a cast at label k of a line */
      const walk = (lineKey, k, tg) => { const ln = P && P.lines[lineKey]; if (!ln) return null; const j = (k - ln.k0) / 2; if (j < 0 || j >= ln.idx.length || j % 1 || ln.idx[j] < 0) return null;
        let st = P.S[ln.idx[j]], lab = k + P.F[ln.idx[j]], n = 1; while (st >= 0 && n <= 16) { if (P.O[st] === tg) return { n, lab }; if (P.N[st] < 0) break; lab += P.N[st]; st = P.X[st]; n++; } return { n: 0, lab: 0 }; };

      /* ---- settings for this scenario (through the page's controls) */
      localStorage.clear(); $('arLucky').click(); A.L.audio = false;
      const route = SC.route || 'lineup-lineup2';
      setSel('lkRoute', route); setBox('lkDwOn', true);
      let R = C.routeOf(route);
      const S = out.set = { free: SC.kind === 'free' ? true : SC.kind === 'normal' ? false : chance(0.6), tgt: chance(0.75) ? 'N' : pick(['l', 'm', 's']), cards: pick(['3', '5', '7']), fill: pick(['ltr', 'mid', 'rtl']),
        rel: chance(0.7), glow: chance(0.7), peek: chance(0.3), strict: chance(0.25), spar: chance(0.15), second: chance(0.5), drill: pick(['none', 'cast', 'combo', 'bite']), end: pick(['H', 'M', 'E', 'Esc', 'Esc', 'run']) };
      setSel('lkDwCards', S.cards); setSel('lkDwFill', S.fill); setSel('lkFreeTgt', S.tgt); setBox('lkDwPeekOn', S.peek); setBox('lkRelLine', S.rel); setBox('lkCueGlow', S.glow); setBox('lkDwStrict', S.strict);
      if (S.spar) setBox('lkSparrows', true);
      S.start = SC.start || pick(['fadein', 'pier']);                     // v31.27+: dock-end one-tap start (the default) or the fade-in taps
      if ($('lkAnchor') && [...$('lkAnchor').options].some(o => o.value === S.start)) setSel('lkAnchor', S.start); else S.start = 'fadein';
      const curR = () => { const r = A.dwRoute && A.dwRoute(); if (r) R = r; return R; };
      if (!!A.L.free !== S.free) { key('ControlLeft', 'Control', { ctrlKey: true }); if (!!A.L.free !== S.free) bad('F2', 'Ctrl idle did not switch freestyle ' + (S.free ? 'on' : 'off')); }
      await sleep(80); frame();

      /* ---- the invariants */
      const BADTXT = /undefined|NaN|\[object|Infinity s/;
      const check = () => {
        curR(); const run = A.run, w = run.dw, t = run.wall0 !== null ? tNow() : 0, big = txt('lkCueBig'), sub = txt('lkCueSub'), h = host(), cs = cards(), cal = h.classList.contains('cal');
        const car = $('lkCar'), carOn = !!(car && !car.hidden && car.offsetParent !== null), peek = $('lkPeek'), peekOn = !!(peek && !peek.hidden && peek.offsetParent !== null);
        for (const [id, tx] of [['lamp', big + ' | ' + sub], ['status', txt('lkStatus')], ['fsTxt', txt('lkFreeTxt')], ['head', txt('lkCompHead')], ['cards', cs.map(c => c.textContent).join(' | ')], ['car', carOn ? car.textContent : ''], ['last', txt('lkLast')]])
          if (BADTXT.test(tx)) bad('T1.' + id, 'bad text: ' + (tx.match(/.{0,40}(undefined|NaN|\[object|Infinity s).{0,40}/) || [tx])[0]);
        if (run.practice || run.bite) {                                    // P1: a drill shows nothing of an attempt
          cov('chk.drill');
          if (cs.length) bad('P1.cards', 'dog cards during a practice drill: ' + cs.length);
          if (cal || carOn) bad('P1.cal', 'calibration view / carousel during a practice drill');
          if (run.known) bad('P1.known', 'known-line histogram during a practice drill: ' + run.known);
          if (/FREESTYLE|DOUBLE|THREAD|WAKE JACK|LOCKED|your dog/i.test(big)) bad('P1.lamp', 'attempt lamp during a practice drill: ' + big);
          if (A.fsOn()) bad('P1.fs', 'freestyle counted as on during a practice drill');
        } else if (run.wall0 === null) {                                   // I1: idle is clean
          cov('chk.idle');
          if (cal || $('lkDw').classList.contains('cal')) bad('I1.cal', 'calibration view left on while idle');
          if (carOn) bad('I1.car', 'carousel left on while idle');
          if (peekOn) bad('I1.peek', 'forecast popup left on while idle');
          if (cs.length) bad('I1.cards', cs.length + ' dog cards while idle');
          if ($('lkFree') && !$('lkFree').disabled && $('lkFree').checked !== !!A.L.free) bad('F2.idle', 'freestyle box ' + $('lkFree').checked + ' but setting ' + A.L.free);
        } else if (!run.preview && w) {                                    // a live attempt
          cov('chk.live');
          const post = t >= A.dwT();
          if (cal) { if (cs.length !== 1) bad('C1.one', 'calibration view with ' + cs.length + ' cards');
            if (!(w.pick || w.exact != null || w.tune != null)) bad('C1.sel', 'calibration view with no dog selected');
            if (cs.length === 1) { const r = cs[0].getBoundingClientRect(), hb = h.getBoundingClientRect(), l = r.left - hb.left, rr = hb.right - r.right, f = A.L.dwFill || 'ltr';
              if (hb.width > r.width + 20 && ((f === 'ltr' && l > 4) || (f === 'rtl' && rr > 4) || (f === 'mid' && Math.abs(l - rr) > 6))) bad('C2.pos', `selected dog not ${f}: left ${Math.round(l)} right ${Math.round(rr)}`); } }
          else { if (w.pick && !post && cs.length) bad('C1.pick', 'a dog is picked but the row shows ' + cs.length + ' cards');
            if (cs.length > +(A.L.dwCards || 3)) bad('C1.max', cs.length + ' cards, setting ' + A.L.dwCards); }
          if (peekOn && !A.L.dwPeekOn) bad('M1.peek', 'forecast popup shown with the setting off');
          if ($('lkFree') && $('lkFree').checked !== A.fsOn()) bad('F2.live', 'freestyle box ' + $('lkFree').checked + ' but mode ' + A.fsOn());
          if (A.fsOn()) { cov('chk.fs');
            if (/^CAST IN|^CAST →|HANDS ON B/.test(big) && !/^CAST · |^CAST MARKED/.test(big)) bad('F1.lamp', 'cast cue on the lamp in freestyle: ' + big);
            if (A.fsWait() && w.frozen) bad('F1.frozen', 'the watch froze (HANDS ON B) in freestyle with no cast made');
            const f = run.fs;
            if (f.cast != null && run.castTap !== f.cast) bad('F3.tap', 'marked cast ' + f.cast + ' but cast tap ' + run.castTap);
            const c = A.fsComb();
            if (c && f.raw != null) { cov('chk.target');
              const tg = A.fsTargetAt(R, c.dwi, c.a, f.raw);
              if (!!tg !== !!c.tg || (tg && (tg.k0 !== c.tg.k0 || tg.k1 !== c.tg.k1))) bad('F4.rule', 'stored target differs from the rule');
              if (c.tg && P) { const key2 = R.dw.lines[c.dwi].key, T = A.fsTarget();
                for (let k = c.tg.k0; k <= c.tg.k1; k += 2) { const q = walk(key2, k, T); if (c.tg.dbl && (!q || !q.n)) bad('F4.bar', 'a frame of the target double carries no ' + T + ' in the lab data: label ' + k); }
                const q0 = walk(key2, Math.round(c.kc), T); if (q0 && q0.n && Math.abs((q0.lab - c.a) - c.rel) > 16.5) bad('F4.rel', 'release window ' + c.rel.toFixed(0) + ' vs lab bite ' + (q0.lab - c.a).toFixed(0)); }
              const fr = A.fsRel();
              if (run.known === 'pre' && c.cl) { if (!A.L.relLine === false && !fr) {} if (A.L.relLine === false && fr) bad('F5.off', 'release line drawn with the setting off'); if (fr && (fr.mid < c.rel - 0.5 || fr.mid > c.relEnd + 0.5)) bad('F5.in', 'release line outside the release window'); } }
            if (/LAST DOUBLE/.test(big) && w.pick) { const nd = A.fsNextDouble(t); if (nd && !nd.none && !nd.last) bad('F7.last', 'LAST DOUBLE on the lamp but a later double exists'); cov('seen.lastDouble'); }
          } else if (/FREESTYLE|NEXT DOUBLE|LAST DOUBLE|THREAD ·/.test(big) && !/FREESTYLE OFF/.test(big)) bad('F1.off', 'freestyle lamp while freestyle is off: ' + big);
          const wl = A.wakeList(), r0 = A.wakeReady();
          for (const v of wl) if (Math.abs(((v - r0) / 2000) - Math.round((v - r0) / 2000)) > 1e-6 || v > A.wakeEnd() + 1e-6) bad('W1.list', 'wake line off the 33.4 s grid or past the last cast');
          if (/^WAKE JACK/.test(big)) { cov('seen.wake'); if (!A.wakeNow(t)) bad('W1.lamp', 'WAKE JACK on the lamp outside a wake window'); if (run.fs && run.fs.cast != null) bad('W1.cast', 'WAKE JACK after the cast was marked'); }
          if (run.known === 'post' && w.exact == null) bad('K1.post', 'locked-frame histogram without a locked dog');
          if (run.known && !A.L.dwOn && false) bad('K1', '');
          if (w.exact != null && post && P) { const x = A.exactCue(t); if (x && /LET GO NOW/.test(x.big)) cov('seen.exactNow'); }
          if (w.pick && P && !post) { cov('chk.data'); const a = w.pick.a0 + w.adj, key2 = R.dw.lines[w.pick.dwi].key, T = A.fsTarget();        // D1: the app's bars = the lab data
            for (let i = 0; i < 4; i++) { let kc = Math.round(t + a) + 2 * ri(0, 400); kc -= ((kc % 2) + 2) % 2; const q = walk(key2, kc, T), v = A.dcNutAt(R, w.pick.dwi, kc); if (q ? v !== q.n : v !== -1) bad('D1.bar', `bar at label ${kc}: app ${v}, lab data ${q ? q.n : 'none'}`); } }
        }
        if (!A.L.cueGlow) { const g = $('cueGlow'); if (g && g.style.boxShadow && g.style.boxShadow !== 'none') bad('G1.glow', 'edge glow shown with the setting off'); if ($('lkCue') && $('lkCue').style.opacity) bad('G1.pulse', 'lamp pulses with the glow setting off'); }
      };
      const act = async (name, fn, wait) => { lastAct = name; out.steps++; cov('act.' + name.split(':')[0]); try { await fn(); } catch (e) { out.errors.push(name + ': ' + String(e && e.message).slice(0, 160)); } await sleep(wait == null ? 60 : wait); frame(); check(); if (out.log.length < 60) out.log.push(name); };

      /* ---- one attempt */
      const ARROWS = [['ArrowUp', 'ArrowUp'], ['ArrowDown', 'ArrowDown'], ['ArrowLeft', 'ArrowLeft'], ['ArrowRight', 'ArrowRight']];
      const attempt = async (n) => {
        curR(); let cand = []; try { cand = DW.candidates(R, A.plans[0], 'all', 'fadein').filter(x => x.pv >= 0).sort((a, b) => b.w - a.w); } catch (e) { cand = []; }
        const c = cand[Math.min(cand.length - 1, Math.floor(rnd() * rnd() * 12))] || { mt: 348 }; if (!cand.length) cov('note.noCandidates');
        const taps = pick([3, 3, 2, 1]), late = ri(150, 240);
        const t0 = performance.now();
        await act('start:space', async () => { const pd = key('Space', ' '); if (!pd) bad('S1.start', 'Space at the start was not cancelled (the page would scroll)'); }, 30);
        if (A.run.wall0 === null) { bad('N0.start', 'Space did not start an attempt'); return; }
        { const w = A.run.dw || {}; if (w.pick || w.exact != null || (w.out && w.out.length) || A.run.castTap != null || A.run.tapInfo || (A.run.fs && A.run.fs.cast != null)) bad('N1.fresh', 'a new attempt starts with state of the last one'); }
        if (S.free !== A.fsOn() && n === 0) bad('F2.start', 'attempt started with freestyle ' + A.fsOn() + ', asked ' + S.free);
        if (S.start === 'fadein' && taps >= 2) { await sleep(136 * vi); await act('tap:beach', async () => { key('Space', ' '); }, 20); }
        if (S.start === 'fadein') await sleep(Math.max(0, (70 + c.mt) * vi - (performance.now() - t0)));   // pier start: the start tap is READY
        if (S.start === 'fadein' && taps >= 3) await act('tap:dock', async () => { key('Space', ' '); }, 20);
        await sleep(700);
        const until = performance.now() + ri(12, S.end === 'run' ? 30 : 46) * 1000; let marked = false, picked = false, ended = false;
        while (performance.now() < until && live()) {
          const fs = A.fsOn(), t = tNow(), post = t >= A.dwT(), r = rnd(), cs = cards(), w = A.run.dw;
          if (r < 0.14 && !post) await act('arrow', async () => { const k = pick(ARROWS); const pd = key(k[0], k[1]); if (!pd) bad('S1.arrow', 'an arrow key was not cancelled during an attempt'); });
          else if (r < 0.18 && !post) await act('numpad', async () => { key('Numpad' + ri(0, 9), String(ri(0, 9))); });
          else if (r < 0.32 && cs.length) await act(post ? 'click:post' : 'click:pick', async () => { const el = pick(cs); el.click(); picked = true; }, 120);
          else if (r < 0.46 && w && (w.pick || post)) await act('nudge', async () => { const n2 = ri(1, 4); for (let i = 0; i < n2; i++) key(chance(0.5) ? 'BracketLeft' : 'BracketRight', chance(0.5) ? '[' : ']', { shiftKey: chance(0.12) }); });
          else if (r < 0.52) await act('backspace', async () => { const had = !!(w && w.pick) && !post; key('Backspace', 'Backspace'); await sleep(30); if (had && A.run.dw && A.run.dw.pick) bad('B1.undo', 'Backspace did not undo the selection'); });
          else if (r < 0.56 && cs.length > 1) await act('remove:x', async () => { const x = pick(cs).querySelector('.lkx'); if (x) x.click(); });
          else if (r < 0.59) await act('delete', async () => { key('Delete', 'Delete'); });
          else if (r < 0.64 && cs.length) await act('hover', async () => { pick(cs).dispatchEvent(new MouseEvent('mouseover', { bubbles: true })); });
          else if (r < 0.70) await act('ctrl', async () => { const b = A.fsOn(); key('ControlLeft', 'Control', { ctrlKey: true }); await sleep(20); if (A.fsOn() === b && $('lkFree') && !$('lkFree').disabled) bad('F2.ctrl', 'Ctrl did not switch freestyle (was ' + b + ')'); marked = false; });
          else if (r < 0.76) await act('setting', async () => { const k = pick(['cards', 'fill', 'tgt', 'rel', 'glow', 'peek']);
            if (k === 'cards') setSel('lkDwCards', pick(['3', '5', '7'])); else if (k === 'fill') setSel('lkDwFill', pick(['ltr', 'mid', 'rtl'])); else if (k === 'tgt') setSel('lkFreeTgt', pick(['N', 'N', 'l', 'm', 's']));
            else if (k === 'rel') setBox('lkRelLine', chance(0.5)); else if (k === 'glow') setBox('lkCueGlow', chance(0.5)); else setBox('lkDwPeekOn', chance(0.5)); }, 150);
          else if (r < 0.90 && fs && !marked && w && w.pick && t > A.wakeReady() + 140) await act('space:cast', async () => {            // freestyle: cast on (or near) a double / a bar, or anywhere
            const a = w.pick.a0 + w.adj, d = A.fsDoubles(R, w.pick.dwi).find(x => x.k0 - a > t + 20 && x.k0 - a < t + 600), mode = d ? pick(['in', 'in', 'near', 'now']) : 'now';
            if (mode !== 'now') await sleep(Math.max(0, (d.k0 - a + (mode === 'in' ? 1 : ri(-25, 25)) - tNow()) * vi));
            const tt = tNow(); key('Space', ' '); await sleep(20);
            if (A.fsOn() && A.run.fs.cast == null) bad('F6.mark', 'Space in freestyle did not mark the cast (t ' + Math.round(tt) + ', ready ' + Math.round(A.wakeReady()) + ')'); else { marked = true; cov('seen.fsMark'); if (A.fsComb() && A.fsComb().dbl) cov('seen.fsMarkDouble'); } }, 200);
          else if (r < 0.90 && !fs && !post && t > A.run.T - 60) await act('space:hold', async () => { await sleep(Math.max(0, (A.run.T - tNow()) * vi)); key('Space', ' ', { hold: true }); await sleep(900); cov('seen.hold'); }, 50);
          else if (r < 0.94 && post && (marked || !fs)) await act('space:bite', async () => { key('Space', ' '); keyUp('Space', ' '); }, 300);
          else await act('wait', async () => { await sleep(ri(200, 1500)); }, 10);
          if (!live()) ended = true;
        }
        if (A.run.known === 'post') cov('seen.locked'); if (A.run.dw && A.run.dw.pick) cov('seen.pickAtEnd');
        if (live() && S.end === 'run' && A.fsWait()) {                      // Z1: nothing cast in freestyle - the attempt ends itself at the end of the data
          lastAct = 'run:end'; const lim = A.wakeEnd() + 90 + 60; await sleep(Math.max(0, (lim - tNow()) * vi)); frame(); await sleep(200); frame();
          if (A.run.wall0 !== null) bad('Z1.end', 'freestyle attempt with no cast did not stop at the end of the cast data'); else cov('seen.autoEnd'); check(); return; }
        if (live()) {
          const n0 = JSON.parse(localStorage.getItem('hm64v29_lucky_tally') || '[]').length, b0 = JSON.parse(localStorage.getItem('hm64v29_lucky_taps') || '[]').length, wasFs = A.fsOn();
          const e = S.end === 'run' ? 'Esc' : S.end;
          await act('end:' + e, async () => { if (e === 'Esc') key('Escape', 'Escape'); else key('Key' + e, e.toLowerCase()); }, 150);
          if (A.run.wall0 !== null) bad('R0.end', e + ' did not end the attempt');
          const tl = JSON.parse(localStorage.getItem('hm64v29_lucky_tally') || '[]'), b1 = JSON.parse(localStorage.getItem('hm64v29_lucky_taps') || '[]').length;
          if (e !== 'Esc') { if (tl.length !== n0 + 1) bad('R1.log', 'H/M/E logged ' + (tl.length - n0) + ' records');
            else { const rec = tl[tl.length - 1]; cov('seen.logged');
              if (!!rec.fs !== wasFs) bad('R1.fs', 'record freestyle flag ' + !!rec.fs + ', mode was ' + wasFs);
              if (wasFs && b1 !== b0) bad('R1.learn', 'a freestyle attempt added a bite-tap learning record');
              if (rec.q) { let rd = null; try { rd = A.castRepRead(rec.q, e === 'H' ? 'Power Nut' : e === 'M' ? 'fish / missed' : 'empty line'); } catch (er) { bad('R2.read', 'report reader threw: ' + er.message); }
                if (rd) { cov('seen.report'); const tx = rd.lines.join(' ').replace(/<[^>]+>/g, ''); if (BADTXT.test(tx)) bad('R2.text', 'report text: ' + (tx.match(/.{0,50}(undefined|NaN|\[object).{0,50}/) || [''])[0]);
                  if (!['early', 'on', 'late', 'unclear', 'nofit', 'none'].includes(rd.call)) bad('R2.call', 'report call ' + rd.call);
                  if (!!rd.fs !== !!rec.q.fs) bad('R2.fs', 'freestyle report flag');
                  if (rec.q.fs && rec.q.fs.T) cov('seen.fsGraded');
                  try { const cv = document.createElement('canvas'); cv.style.cssText = 'width:600px;height:190px'; document.body.appendChild(cv); A.drawCastRep(cv, rec.q); cv.remove(); } catch (er) { bad('R2.draw', 'report close-up threw: ' + er.message); } } }
              else bad('R1.q', 'logged attempt has no report'); } }
          else if (tl.length !== n0) bad('R1.esc', 'Esc logged a record');
        }
        await sleep(120); frame(); check();
      };

      await attempt(0);
      /* ---- after the attempt: drills, the attempt list, a second attempt */
      if (S.drill !== 'none') {
        const btn = { cast: 'lkPractice', combo: 'lkCombo', bite: 'lkBite' }[S.drill];
        if (S.drill === 'cast') setBox('lkPracCombo', false);
        await act('drill:' + S.drill, async () => { $(btn).click(); }, 300);
        if (!(A.run.practice || A.run.bite)) bad('P0.start', 'the ' + S.drill + ' drill did not start'); else cov('seen.drill.' + S.drill);
        const endAt = performance.now() + ri(5, 9) * 1000;
        while (performance.now() < endAt && (A.run.practice || A.run.bite)) { await act('drill:key', async () => { key('Space', ' ', { hold: true }); await sleep(ri(150, 900)); keyUp('Space', ' '); }, ri(200, 1400)); }
        await act('drill:esc', async () => { key('Escape', 'Escape'); }, 200);
        if (A.run.practice || A.run.bite) bad('P0.esc', 'Esc did not stop the drill');
      }
      const rb = [...document.querySelectorAll('[data-rep-open]')];
      if (rb.length && chance(0.6)) { await act('report:open', async () => { rb[0].click(); }, 200); if (BADTXT.test(txt('lkAttList'))) bad('R3.list', 'attempt list text'); if (BADTXT.test(txt('lkAttRep'))) bad('R3.tot', 'report totals text'); }
      const rm = [...document.querySelectorAll('[data-att-remove]')];
      if (rm.length && chance(0.35)) { const n0 = rm.length; await act('attempt:remove', async () => { rm[0].click(); }, 200); const n1 = document.querySelectorAll('[data-att-remove]').length; if (n1 !== n0 - 1) bad('R4.rm', 'remove left ' + n1 + ' of ' + n0);
        if (chance(0.6)) { await act('attempt:undo', async () => { $('lkAttUndo').click(); }, 200); if (document.querySelectorAll('[data-att-remove]').length !== n0) bad('R4.undo', 'undo did not put the attempt back'); } }
      if (S.second) { cov('seen.second'); await attempt(1); }
      clearInterval(ticker);
    } catch (e) { out.errors.push('driver: ' + String(e && e.stack || e).slice(0, 300) + ' @' + lastAct); }
    finish();
  }, 500);
})();
