HM64 Power Nut Tool v32.18 (2026-11-24): rainy mornings are ready (no horse / horse)
======================================================================================

What you asked for (2026-11-24 20:48, with hm64-rain120-results_2026-11-24.zip)
  "integrate these results into the app. also use them to determine if future horse runs are even necesary, or we can
  just skew the offset ourselves since its a known amount for a known time"

What changed (v32.18 includes v32.7 - v32.17)
  - The hub: Rainy -> No horse and Rainy -> Horse are Ready, each with Casting tables, a Lucky Timer and Dog practice
    (lucky-timer_rainy-no-horse.html 37.5 MB, _rainy-horse 28.5 MB; casting tables 36.9 / 27.9 MB; practice 7.1 / 5.5 MB).
  - One table per rainy file over menus 0-6 frames late: no sparrows come out in the rain (decomp spawnMiscAnimals needs
    sun), so nothing tells 0-4 from 5-6. The rainy pages have no sparrow box; Not working? leaves the sparrow item out;
    the guide's 2.1 / 2.2 read by weather.
  - The rainy data: no horse 99 dog lines (8,448 plays), horse 68 (5,632); the most common line is 5% of the plays (sunny
    11-14%); the Lucky Timer's plan casts at 27.81 s after READY for 7.8% (sunny no horse: 20.07 s, 11.0%).
  - Cast pack fix for rain (tools/dogcast_pack.py): the rain draws random numbers every frame and is not part of the
    lab's state hash, so 1 bite state in 65 that two casts shared had two futures; the first rainy packs got 1.1-1.2% of
    their casts wrong after the first bite. Bite states that disagree are now kept apart: every one of the 325,948 rainy
    casts reads back exactly. The sunny packs come out byte-identical.
  - Sunny / horse texts: "If it rains, tick Rainy morning on the hub and use the rainy pages (the same file)".
  - README: rainy setup, the rainy cube corners (the rain swallows the horse's two farm numbers on most paths, like the
    Kruskal count), the in-tile dog spot (97-99% of cast moments the same), one key : value pair is not the whole state on
    rain. how-it-works / forest_10_cubes.svg: four corners filled.
  - Sunny pages: the same data; only the sparrow box / Not working? code that hides them on rain is new.
  - New lab tools: tools/cross_twins.py, tools/twin_grid_check.py, tools/bite_hash_check.py; tests/ui_rainy.js.

Horse runs: needed?
  Not as a plain offset. Sunny: 99.7% of the horse plays end on a twin of a no-horse dog line, but the shift is per line
  (0 for half the weight, then +6, +14, +22, +30 VIs), a third of the weight moves between lines, and the twins' casts
  agree on bites 1-2 for 98.7% of frames. Rainy: 85% the same lines at the same moment, 96.7%. The cast differences come
  from the dog's spot (the two files' dogs sit 2.2 units apart; 99% / 94% of them where the dog leaves the screen at a
  different moment), not from the horse. A new horse file needs at least phase 1 (~2 min); whether it can borrow the
  5-hour cast data needs one ~20-minute test with the dog on exactly the same spot. Details: claude/HM64_RAIN_2026-11-23.md.

Release
  bash ~/Documents/hm64/tools/hm64_release.sh v32-18 <lab sha256> <pages sha256> </dev/null
