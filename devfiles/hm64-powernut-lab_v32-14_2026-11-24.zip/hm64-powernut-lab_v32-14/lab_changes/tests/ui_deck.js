/* headless (v32.14): the deck page. 52 cards in new deck order; take one out, pick the goal; stacking gives 51 cards
   (no removed card, the goal in it) in a seeded order and a random grid. Start = Jack stops at the pier (a dog line by
   weight). Press = the cast at that game frame; its bites (the lab's records) each light one face-down card for 20 VIs;
   let go while lit = catch it (the goal card exactly when the bite is the Power Nut); let go otherwise = empty. One cast
   per attempt (a second press is ignored); the next attempt is never the same dog line; 40 s with no cast = Jack lies
   down. rAF does not run headless: the test moves the clock (setClock) and calls step(). */
(function () {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => {
    const $ = id => document.getElementById(id), out = { errors: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    try {
      const D = window.HM64Deck, PULL = DECK.pull, UNTIL = DECK.until;
      const down = () => $('deck').dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true }));
      const up = () => $('deck').dispatchEvent(new PointerEvent('pointerup', { bubbles: true }));
      const litCells = () => [...$('grid').querySelectorAll('.lit')].map(c => c.dataset.id);
      out.board = [...$('board').children].map(e => e.title);
      D.pick('2♥'); D.pick('A♠');
      out.pickTxt = $('pickTxt').textContent;
      down(); out.pressBeforeStack = D.state().phase;
      $('stackBtn').click();
      const s = D.state();
      out.n = s.stack.length; out.hasRemoved = s.stack.includes('2♥'); out.hasGoal = s.stack.includes('A♠');
      out.cellsSame = s.cells.slice().sort().join() === s.stack.slice().sort().join();
      out.seedTxt = $('seedTxt').textContent;
      down(); out.pressBeforeStart = D.state().phase; up();
      /* find a frame on the current line whose bite (n) is / is not the Nut */
      const find = (pred) => { for (let L = 6; L <= UNTIL; L += 2) { const b = D.bitesOf(L); if (b && pred(b)) return { L, b }; } return null; };
      const att = [];
      /* 1: cast on a frame whose 1st bite is the Nut, let go inside the first bite's 0.33 s */
      $('startBtn').click(); const li1 = D.state().li;
      let f = find(b => b[0].o === 'N');
      D.setClock(f.L + 0.6); down();
      let st = D.state(); att.push({ li: li1, lab: st.cast.lab, want: f.L, bites: st.cast.bites.length, same: JSON.stringify(st.cast.bites) === JSON.stringify(f.b) });
      D.setClock(f.b[0].e - 3); D.step(); att[0].litBefore = litCells().length;
      D.setClock(f.b[0].e + 2); D.step(); att[0].lit = litCells(); att[0].status = $('status').textContent;
      D.setClock(f.b[0].e + PULL - 1); D.step(); att[0].litLate = litCells().length;
      up(); st = D.state();
      att[0].res = { phase: st.phase, hits: st.hits, fish: st.fish, empty: st.empty, drawn: $('drawn').textContent, log: $('log').textContent.split('\n')[0] };
      down(); att[0].secondPress = { phase: D.state().phase, casts: D.state().casts };   // one cast per attempt
      /* 2: another line; a frame whose 1st bite is a fish; let go in its window */
      $('startBtn').click(); const li2 = D.state().li;
      f = find(b => b[0].o !== 'N');
      D.setClock(f.L); down(); D.setClock(f.b[0].e + 10); D.step();
      const lit2 = litCells(); up(); st = D.state();
      att.push({ li: li2, lit: lit2, res: { hits: st.hits, fish: st.fish, empty: st.empty, drawn: $('drawn').textContent }, log: $('log').textContent.split('\n')[0] });
      /* 3: let go before the first bite: empty */
      $('startBtn').click(); f = find(b => true);
      D.setClock(f.L); down(); D.setClock(f.b[0].e - 30); D.step(); up(); st = D.state();
      att.push({ li: st.li, res: { hits: st.hits, fish: st.fish, empty: st.empty }, log: $('log').textContent.split('\n')[0] });
      /* 4: let go 1 VI after the window closed: empty, "had just ended" */
      $('startBtn').click(); f = find(b => true);
      D.setClock(f.L); down(); D.setClock(f.b[0].e + PULL); D.step(); const lit4 = litCells().length; up(); st = D.state();
      att.push({ li: st.li, litAtEnd: lit4, res: { empty: st.empty }, log: $('log').textContent.split('\n')[0] });
      /* 5: hold through bite 1, let go at bite 2 (the Nut): the goal card, "bite 2" */
      $('startBtn').click(); f = find(b => b[0].o !== 'N' && b[1] && b[1].o === 'N');
      D.setClock(f.L); down(); D.setClock(f.b[0].e + 5); D.step(); const lit5a = litCells();
      D.setClock(f.b[1].e + 5); D.step(); const lit5b = litCells(); up(); st = D.state();
      att.push({ li: st.li, lit1: lit5a, lit2: lit5b, res: { hits: st.hits }, log: $('log').textContent.split('\n')[0] });
      /* 6: no cast: Jack lies down at 40 s */
      $('startBtn').click(); D.setClock(UNTIL - 2); D.step(); const ph6a = D.state().phase; D.setClock(UNTIL + 2); D.step();
      att.push({ li: D.state().li, before: ph6a, phase: D.state().phase, lamp: $('lamp').textContent, log: $('log').textContent.split('\n')[0] });
      out.att = att;
      /* the tool: lamp + strip before the cast, then the bite to let go at */
      $('startBtn').click(); $('tool').click(); D.setClock(10); D.step();
      out.tool = { lamp: $('lamp').textContent, strip: $('strip').children.length, hidden: $('strip').hidden,
                   marks: [...$('strip').children].filter(i => /\b[go]\b/.test(i.className)).length };
      f = find(b => b[0].o === 'N'); D.setClock(f.L - 0.5); D.step(); out.tool.lampAt = $('lamp').textContent;
      D.setClock(f.L); down(); D.setClock(f.b[0].e - 60); D.step(); out.tool.lampCast = $('lamp').textContent;
      D.setClock(f.b[0].e + 1); D.step(); out.tool.lampBite = $('lamp').textContent; up();
      /* 40 more attempts (Jack lies down each time): never the same dog line twice in a row; all lines turn up */
      const lis = [D.state().li];
      for (let i = 0; i < 40; i++) { $('startBtn').click(); lis.push(D.state().li); D.setClock(UNTIL + 2); D.step(); }
      out.lis = lis; out.repeats = lis.filter((x, i) => i && x === lis[i - 1]).length; out.distinct = new Set(lis).size;
      /* Space: start + cast + let go */
      window.dispatchEvent(new KeyboardEvent('keydown', { code: 'Space' })); const phS = D.state().phase;
      window.dispatchEvent(new KeyboardEvent('keydown', { code: 'Space' })); const phC = D.state().phase;
      window.dispatchEvent(new KeyboardEvent('keyup', { code: 'Space' }));
      out.space = [phS, phC, D.state().phase];
      const z = D.state(); out.totals = { tries: z.tries, casts: z.casts, hits: z.hits, fish: z.fish, empty: z.empty,
        stat: ['sCasts', 'sHits', 'sFish', 'sEmpty', 'sRate'].map(i => $(i).textContent) };
      /* a new deck: a new seed, the stats stay */
      const seed = z.seed0; await sleep(50); $('leave').click(); out.newSeed = D.state().seed0 !== seed;
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const p = document.createElement('pre'); p.id = 'testout'; p.textContent = JSON.stringify(out); document.body.appendChild(p);
  }, 300);
})();
