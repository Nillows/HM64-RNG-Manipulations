HM64 Power Nut Tool v32.13 (2026-11-24): the interception picture - only a cast grows a leaf
=============================================================================================

What you asked for (2026-11-24 15:38)
  "make the visual aid for the interception a bit more clear, show the branch growth in time as if you didnt cast vs
  what the branch looks like when you intercept a leaf ... the cast moment causes the branch to change, and in that
  changed one is where we have to catch the powernut ... there is no leaf without a cast, so the shape of the branch
  without a cast has no leaves. it is only casting that actually determines where they will be on the branch ahead."

What changed (v32.13 includes v32.7 - v32.12)
  - media/forest_7_leaves.svg redrawn: "The leaves: only a cast grows them". Three rows on one time axis (seconds after
    READY), all real data from L1 of Sunny -> No horse and the cast pack:
      no cast: the branch in base sunlight, 0-40 s, no leaves anywhere;
      cast at 16.23 s: the same branch up to the cast, then the bend - the dog after that cast (a new branch, the
        no-cast one dashed where it would have gone) - growing to bite 1 at 37.9 s: the Power Nut (a leaf);
      cast at 16.26 s (one game frame later): another bend, another branch, bite 1 at 28.4 s: a small fish, no leaf.
    Bottom strip: every cast moment on L1 that grows a leaf (green / gold / purple) = what the app's bars show.
  - README "The leaves: only a cast grows them" rewritten to match; describing-the-dog and tuner paragraphs now speak of
    the cast moments that grow leaves. The tuner picture marks those moments as dots, not leaves. Guide captions.
  - Toolkit: forest_facts.py --pack id=dogcast.json -> "interception" (a Nut-on-bite-1 cast 12-24 s after READY whose
    next frame is not one: the dog after each cast from the pack's P runs, the bites); forest_svg.py d_cast (the old
    picture kept as --only leafmap).
  - Page data unchanged (byte-equal to v32.12 apart from the version).

Release
  bash ~/Documents/hm64/tools/hm64_release.sh v32-13 <lab sha256> <pages sha256> </dev/null
