HM64 Power Nut Tool v32.14 (2026-11-24): the deck page - cast, then let go within 0.33 s at a bite; one cast per attempt
==========================================================================================================================

What you asked for (2026-11-24 15:44 and 15:47)
  "the deck of cards analogy is a bit off because you can draw a card at any time, but fishing you have 0.33 seconds to
  realease B and pull in. i was hoping players would click start, then click and hold the deck of cards to emulate the
  cast out. and as soon as they do, different face down cards get randomly highlighted for 0.33 seconds and the player
  has to release on time ... make it use the tables from jack not falling asleep. the same length of time the real
  tables would use. regardless of the route or circumstance or line of dog ... just the genuine challenge of the task"
  "they only get one cast, if they fail, they try again from a different dog line to emulate a second attempt, rather
  than guess the values of multicasting"

What changed (v32.14 includes v32.7 - v32.13)
  - deck.html rewritten. Steps 1-2 as before (52 cards in new deck order, take one out, pick the goal, stack: unix ms x
    time on the page capped at 1800 s, mod 2^32, the game's own LCG). Step 3 is now the cast:
      Start = Jack stops at the end of the pier; a dog line is drawn by its share of the route's plays.
      Press and hold the deck (or Space) = the cast, on the game frame you press (label = 2 x floor(VIs since Start / 2)).
      You get the real cast the lab recorded on that frame of that line (cast pack: F to bite 1, then N / X bite to bite).
      Each bite lights one face-down card for 20 VIs (0.334 s, Dog practice's G_PULL). Let go while it is lit = you catch
      that card: the goal card exactly when the bite is the Power Nut, another card (a fish) otherwise. Let go at any
      other time = the line comes back empty. Holding through a bite waits for the next one.
      One cast per attempt. "Try again" is a new arrival with a different dog line (never the last attempt's line). No
      cast in 40 s = Jack lies down (the attempt is over).
      Real speed only. "Use the tool": before the cast a countdown to the next frame whose 1st bite (green) or 2nd bite
      (gold, hold the 1st) is the Nut, and a strip of the next 4 s of frames; after the cast, which bite to let go at.
      Tally: attempts, goal card, other cards, empty, your rate per attempt.
  - The data (site_build.py): Sunny · No horse, the default route's dog lines making up 90% of its plays (19 lines),
    every cast frame up to 2398 VIs after READY (the tables' 40 s), bites up to 6 deep. All 22,743 frames have a record;
    the Nut is bite 1 on 648 (2.85%), bite 2 on 765. Checked: label 970 of the top line = bites 2268 N, 3330 l, 4390 m;
    972 = 1700 s; 968 = 1558 s (the facts in forest_facts / the interception picture).
  - problem.html, the README problem section and media/problem_deck.svg rewritten to the cast: "1 - press B: the frame
    picks the cast; 2 - hold B, each bite lights one card for 0.33 s; 3 - one cast per attempt". The picture uses three
    real casts of L1 a frame apart (16.20 / 16.23 / 16.26 s) and their real bites (forest_facts.py now keeps each
    interception cast's bites and the frame before).
  - Every other page byte-equal to v32.13 apart from the version.
  - Tests: tests/ui_deck.js rewritten (catch on the Nut bite, a fish, empty early, empty 1 VI late, hold to bite 2,
    Jack lying down, the tool's lamps, 41 attempts never repeating a line, Space, a new seed).

Release
  bash ~/Documents/hm64/tools/hm64_release.sh v32-14 <lab sha256> <pages sha256> </dev/null
