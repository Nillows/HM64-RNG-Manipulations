"""Independent check of a zone pack + route table made by tools/zone_build.py (v32.23, 2026-11-26).

  python3 -I tools/zone_verify.py --recorded-pack A --pack B --recorded-routes RA --routes RB --zz zz_lines.json
          --spots SP2_casts.jsonl --zones SP3_zones.jsonl --rows FD_casts_b*.jsonl ...

Reads every measurement again with its own code and checks, per zone table (base / north / middle / south):
  1. the recorded arrays are untouched (a prefix of the new ones) and the north table IS the recording;
  2. every measured cast frame: the zone table's bites are the measured bites as far as the measurement goes, and
     the table shows no Power Nut after the measured part ("contradicted" must be 0);
  3. every unmeasured cast frame of a line that stands in the zone: a Nut only on a line that was measured there and
     only inside the cast's recorded row;
  4. every Nut of the base table is a Nut on the same bite at the same moment in every zone where the frame can occur;
  5. the route table: each zone's bite 1 / bite 2 / later-bite fields, rebuilt from base + differences, equal what
     the zone's pack casts say, for every cast frame of the route table.
Prints the counts and exits 1 on any failure."""
import argparse, collections, json, sys

ap = argparse.ArgumentParser()
for a in ("recorded-pack", "pack", "recorded-routes", "routes", "zz", "spots", "zones"):
    ap.add_argument("--" + a, required=True)
ap.add_argument("--rows", nargs="+", required=True)
a = ap.parse_args()
A = json.load(open(a.recorded_pack)); B = json.load(open(a.pack)); zz = json.load(open(a.zz))
RA = json.load(open(a.recorded_routes)); RB = json.load(open(a.routes))
fail = []
n, nc = len(A["O"]), len(A["S"])
if not (B["O"][:n] == A["O"] and all(B[x][:n] == A[x] for x in "RNXLT") and all(B[x][:nc] == A[x] for x in "PFSE")):
    fail.append("recorded arrays changed")


def bites(c):
    out, t, s = [], B["F"][c], B["S"][c]
    for _ in range(60):
        if s is None or s < 0:
            break
        out.append((t, B["O"][s]))
        if B["N"][s] < 0:
            break
        t += B["N"][s]; s = B["X"][s]
    return out
TAB = {}
for z in ("all", "north", "middle", "south"):
    TAB[z] = {}
    for key, L in B["lines"].items():
        idx = list(L["idx"]); d = B["zones"]["d"].get(z, {}).get(key, [])
        for q in range(0, len(d), 2):
            idx[d[q]] = d[q + 1]
        TAB[z][key] = idx
if any(TAB["north"][k] != A["lines"][k]["idx"] for k in A["lines"]):
    fail.append("the north table is not the recording")
zone = lambda z: "north" if z < 161 else "middle" if z < 191 else "south"
stand = collections.defaultdict(set)
for key, v in zz.items():
    for m in v["members"] + [v["rep"]]:
        if "spot" in m:
            stand[zone(m["spot"][1])].add(key)
NAME = {"z164.4": "middle", "z176.4": "middle", "z194.4": "south", "middle": "middle", "south": "south"}
got = {"middle": collections.defaultdict(list), "south": collections.defaultdict(list)}
skip = {"middle": set(), "south": set()}; measured_lines = {"middle": set(), "south": set()}
for p in (a.spots, a.zones):
    for ln in open(p):
        r = json.loads(ln); z = NAME.get(r["_job"].get("zone") or r["_job"].get("spot"))
        if z is None or r.get("ok", True) is False or r["key"] not in A["lines"]:
            continue
        k0 = A["lines"][r["key"]]["k0"]; measured_lines[z].add(r["key"])
        for c in r.get("casts", []):
            if (c["k"] - k0) % 2 == 0 and 0 <= (c["k"] - k0) // 2 < len(A["lines"][r["key"]]["idx"]):
                got[z][(r["key"], (c["k"] - k0) // 2)].append([(b[0] - c["k"], b[1][:1]) for b in c["b"]])
        for k in r.get("skipped", []):
            skip[z].add((r["key"], (k - k0) // 2))
rowbites = collections.Counter()
for p in a.rows:
    for ln in open(p):
        try:
            r = json.loads(ln)
        except ValueError:
            continue
        if r.get("key") not in A["lines"]:
            continue
        L = A["lines"][r["key"]]
        for c in r.get("casts", []):
            j, rem = divmod(c["k"] - L["k0"], 2)
            if not rem and 0 <= j < len(L["idx"]) and L["idx"][j] >= 0:
                rowbites[L["idx"][j]] = max(rowbites[L["idx"][j]], len(c.get("b") or []))
# frames that share a recorded cast share its measurements (share check of v32.22: 0 differ)
by_cast = {z: collections.defaultdict(list) for z in got}
for z in got:
    for (key, j), lst in got[z].items():
        by_cast[z][A["lines"][key]["idx"][j]] += lst
out = collections.Counter()
for z in ("middle", "south"):
    for key, L in A["lines"].items():
        if key not in stand[z]:
            continue
        for j, c0 in enumerate(L["idx"]):
            if c0 < 0:
                continue
            zb = bites(TAB[z][key][j]); ms = by_cast[z].get(c0, [])
            nuts = [i for i, (_, o) in enumerate(zb) if o == "N"]
            if any(i < 6 for i in nuts):
                out[z + " frames with a Nut on bites 1-6"] += 1
            if (key, j) in skip[z]:
                if nuts: out[z + " Nut on a frame before Jack can stand there"] += 1
                continue
            if ms:
                longest = max(ms, key=len)
                for g in ms:
                    if zb[:len(g)] == g: out[z + " measurements confirmed"] += 1
                    else: out[z + " measurements CONTRADICTED"] += 1
                if any(i >= len(longest) for i in nuts): out[z + " Nut after the measured part"] += 1
                out[z + " Nut bites confirmed by a measurement"] += len(nuts)
            elif nuts:
                if key not in measured_lines[z]: out[z + " Nut on a line not measured"] += 1
                elif any(i >= rowbites[c0] for i in nuts): out[z + " copied Nut outside the recorded row"] += 1
                elif [t for t, _ in zb] != [t for t, _ in bites(c0)] or any(o != o0 and not (o0 == "N" and o == "u") for (_, o), (_, o0) in zip(zb, bites(c0))): out[z + " copied cast with other bites"] += 1
                else: out[z + " Nut bites copied (inside the recorded row)"] += len(nuts)
for key, L in A["lines"].items():
    for j, c0 in enumerate(L["idx"]):
        if c0 < 0:
            continue
        bb = bites(TAB["all"][key][j])
        if any(o == "N" for _, o in bb[:6]):
            out["all frames with a Nut on bites 1-6"] += 1
        if any(o == "N" for _, o in bites(c0)[:6]):
            out["north frames with a Nut on bites 1-6"] += 1
        for i, (t, o) in enumerate(bb):
            if o != "N":
                continue
            for z in ("north", "middle", "south"):
                if key not in stand[z] or (z != "north" and (key, j) in skip[z]):
                    continue
                zb = bites(TAB[z][key][j])
                if len(zb) <= i or zb[i] != (t, "N") or [x[0] for x in zb[:i]] != [x[0] for x in bb[:i]]:
                    out["base Nut that is NOT a Nut in " + z] += 1
                else:
                    out["base Nut bites held in " + z] += 1
BAD = ("CONTRADICTED", "after the measured part", "not measured", "outside the recorded row", "other bites", "NOT a Nut", "before Jack")
# 5. the route table
for ra, rb in zip(RA["routes"], RB["routes"]):
    hz = (ra.get("source") or {}).get("bite_horizon") or 5398
    for z in ("all", "north", "middle", "south"):
        dz = rb["zones"]["d"].get(z, {})
        for li, (la, lb) in enumerate(zip(ra["lines"], rb["lines"])):
            key = rb["line_info"][li]["key"]; k0 = B["lines"][key]["k0"]
            sep = "." if len(lb["n1"]) != len(lb["b1"]) else ""
            n1 = lb["n1"].split(sep) if sep else list(lb["n1"]); n2 = lb["n2"].split(sep) if sep else list(lb["n2"])
            b1, b2, bx = list(lb["b1"]), list(lb["b2"]), list(lb["bx"])
            for e in dz.get(li, dz.get(str(li), [])):
                i = e[0]; n1[i], b1[i], n2[i], b2[i], bx[i] = e[1], e[2], e[3], e[4], e[5]
            for i in range(len(n1)):
                if n1[i] == ".":
                    continue
                j, rem = divmod(lb["lo"] + i - 1 - k0, 2)
                if rem or j < 0 or j >= len(TAB[z][key]) or TAB[z][key][j] < 0:
                    continue
                zb = bites(TAB[z][key][j])
                if not zb:
                    out["route %s: frames %s" % (z, "without a bite, left out" if n1[i] == "." else "without a bite that DIFFER")] += 1
                    continue
                ok = (b1[i], n1[i]) == (zb[0][0], "1" if zb[0][1] == "N" else "0")
                if len(zb) > 1:
                    ok = ok and (b2[i], n2[i]) == (zb[1][0], "1" if zb[1][1] == "N" else "0")
                else:
                    ok = ok and n2[i] == "."
                if isinstance(bx[i], list):                 # later bites: a prefix of the pack's chain, cut near the bite horizon
                    want = [(-t if o == "N" else t) for t, o in zb[2:]]
                    ok = ok and bx[i] == want[:len(bx[i])] and all(lb["lo"] + i - 1 + abs(x) > hz - 30 for x in want[len(bx[i]):])
                out["route %s: frames %s" % (z, "equal to the pack" if ok else "that DIFFER from the pack")] += 1
for k in sorted(out):
    print("%8d  %s" % (out[k], k))
fail += [k for k in out if any(b in k for b in BAD) or "DIFFER" in k]
print("RESULT:", "FAIL " + "; ".join(fail) if fail else "ok - 0 contradicted")
sys.exit(1 if fail else 0)
