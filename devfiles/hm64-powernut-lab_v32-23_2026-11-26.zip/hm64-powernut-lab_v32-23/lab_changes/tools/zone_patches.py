"""The pier-zone variant of the page scripts (v32.23, 2026-11-26).

Thomas: "Sunny pages must stay identical apart from the version label." The rainy pages need changes inside
hm64_lucky_v29.js, hm64_dogref_v31.js and hm64_practice_v32.js (a preset's pier zone picks its series, caches that
follow the zone, the "not proven here" marks, the zone picker). So the source files stay as they are - every page
without zone tables is built from them byte for byte - and tools/site_build.py applies the exact-string patches below
to the copies it puts into pages whose cast pack has zones (pack["zones"], made by tools/zone_build.py). Every `old`
must occur exactly once (the project's editing habit); a source change that moves an anchor stops the build here.

  python3 -I tools/zone_patches.py            check every patch against the current sources, print the count
"""
from pathlib import Path

WEB = Path(__file__).resolve().parent.parent / "webapp"

PATCHES = {
    # ------------------------------------------------------------------------------------------ the Lucky computation
    "hm64_lucky_v29.js": [
        ("select: the pack follows the preset's zone on the Lucky Timer",
         "    plans = planSet(sel.pace, sel.anchor, sel.route);\n    return plans;\n  }\n",
         "    plans = planSet(sel.pace, sel.anchor, sel.route);\n"
         "    if (root.HM64Zone && root.HM64Zone.follow) { const Rz = routeOf(sel.route); root.HM64Zone.follow(Rz, (Rz.groups || []).find(g => g.id === sel.pace)); }   // v32.23\n"
         "    return plans;\n  }\n"),
        ("zoneSeries: a preset with a 2nd cut reads its pier zone's flags",
         "  function planSet(pace, anchor, route) {                          // cached plan list for a route + pace group + anchor\n",
         "  /* v32.23 (rain, pier zones): route.zones.d[zone][line] = [[i, n1, b1, n2, b2, bx], ...] = the cast frames whose\n"
         "     bites differ from the base table in that camera zone of the pier end (tools/zone_build.py). A preset tagged with\n"
         "     a 2nd cut plans on that zone's series (same indexes as series0, so every line lookup stays valid); a preset\n"
         "     without one plans on the base. */\n"
         "  const zoneOf = (R, g) => { const z = R.zones && g && g.ax ? g.ax[R.zones.axis || 'cut2'] : null; return z && R.zones.d && R.zones.d[z] ? z : ''; };\n"
         "  function zoneSeries(R, g) {\n"
         "    const z = zoneOf(R, g);\n"
         "    if (!z) return series0;\n"
         "    R.zser = R.zser || {};\n"
         "    if (!R.zser[z] || R.zser[z].of !== series0) {\n"
         "      const s = series0.slice(), d = R.zones.d[z];\n"
         "      R.lines.forEach((c, li) => {\n"
         "        const e = d[li];\n"
         "        if (!c || !e || !e.length) return;\n"
         "        const c2 = Object.assign({}, c, { n1: Array.from(c.n1), b1: c.b1.slice(), n2: c.n2 ? Array.from(c.n2) : c.n2, b2: c.b2 ? c.b2.slice() : c.b2, bx: c.bx ? c.bx.slice() : c.bx });\n"
         "        for (const x of e) { const i = x[0]; c2.n1[i] = x[1]; c2.b1[i] = x[2]; if (c2.n2) { c2.n2[i] = x[3]; c2.b2[i] = x[4]; } if (c2.bx) c2.bx[i] = x[5]; }\n"
         "        s[R.sidxs[li]] = fromCasts(c2);\n"
         "      });\n"
         "      s.of = series0; R.zser[z] = s;\n"
         "    }\n"
         "    return R.zser[z];\n"
         "  }\n"
         "  function planSet(pace, anchor, route) {                          // cached plan list for a route + pace group + anchor\n"),
        ("planSet: the zone's series",
         "      setCache.set(key, [{ k: 0, label: 'No whistle', series: series0, variants: var0, cover: g.cover, firstT,\n",
         "      setCache.set(key, [{ k: 0, label: 'No whistle', series: zoneSeries(R, g), zone: zoneOf(R, g), variants: var0, cover: g.cover, firstT,\n"),
        ("smoothed: one cache entry per zone",
         "    const key = plan.k + ':' + (typeof sig === 'object' ? sig.id : sig.toFixed(2));\n    if (cache.has(key)) return cache.get(key);\n",
         "    const key = plan.k + ':' + (plan.zone || '') + ':' + (typeof sig === 'object' ? sig.id : sig.toFixed(2));\n    if (cache.has(key)) return cache.get(key);\n"),
        # -------------------------------------------------------------------------------------- the Lucky Timer's UI
        ("default preset: the page's own (rainy: 2nd cut middle) until the player picks one",
         "const selPace = () => (L.route === 'carry' ? L.pace : (L.routePace || {})[L.route] || 'all');   // presets kept per route\n",
         "const selPace = () => {                                        // presets kept per route; v32.23: the page's default preset (rainy: the middle zone, Thomas 2026-11-26 10:22)\n"
         "  if (L.route === 'carry') return L.pace;\n"
         "  const p = (L.routePace || {})[L.route], d = PG && PG.luckyDefaults && (PG.luckyDefaults.routePace || {})[L.route];\n"
         "  if (!d) return p || 'all';\n"
         "  const Rp = LuckyCore.routeOf(L.route);\n"
         "  return p && (Rp.groups || []).some(g => g.id === p) ? p : d;\n"
         "};\n"),
        ("known-line bars: solid = holds from every pier zone, striped = only from the zone in use",
         "      g.fillRect(x, top + (nb === 1 ? 0 : nb === 2 ? 10 * dpr : 20 * dpr), wd, bot - top - (nb === 1 ? 0 : nb === 2 ? 10 * dpr : 20 * dpr));\n"
         "      if (nb >= 3 && nb !== pnb) { pg.push([x, nb]); }",
         "      { const y0 = top + (nb === 1 ? 0 : nb === 2 ? 10 * dpr : 20 * dpr), ZN = root.HM64Zone;\n"
         "        if (ZN && fsTarget() === 'N' && !ZN.everywhere(K.R.dw.lines[K.dwi].key, kc, nb)) { zdep++; for (let y = y0; y < bot; y += 6 * dpr) g.fillRect(x, y, wd, Math.min(3 * dpr, bot - y)); g.fillStyle = '#ff9f43'; g.fillRect(x, top - 9 * dpr, wd + 1, 5 * dpr); }   // v32.23\n"
         "        else { zall++; g.fillRect(x, y0, wd, bot - y0); if (ZN && fsTarget() === 'N' && ZN.cur !== 'all') { g.fillStyle = '#ffffff'; g.fillRect(x, top - 9 * dpr, wd + 1, 5 * dpr); } } }   // the reliability row above the bars (Thomas 10:28)\n"
         "      if (nb >= 3 && nb !== pnb) { pg.push([x, nb]); }"),
        ("known-line bars: room for the reliability row above them",
         "top = 26 * dpr, fsLane = !K.post && K.fs && L.relWin !== false,",
         "top = (root.HM64Zone ? 40 : 26) * dpr, fsLane = !K.post && K.fs && L.relWin !== false,"),
        ("known-line bars: counters",
         "    const a = K.a; let n = 0, pnb = 0; const pg = [];\n    for (let v = Math.floor(v0); v <= v0 + span; v++) {\n      const kc = Math.round(v + a); if (kc % 2) continue;\n      const nb = dcNutAt(K.R, K.dwi, kc); if (nb <= 0) continue;\n",
         "    const a = K.a; let n = 0, pnb = 0, zdep = 0, zall = 0; const pg = [];\n    K.zbars = null;\n    for (let v = Math.floor(v0); v <= v0 + span; v++) {\n      const kc = Math.round(v + a); if (kc % 2) continue;\n      const nb = dcNutAt(K.R, K.dwi, kc); if (nb <= 0) continue;\n"),
        ("known-line bars: the legend",
         "    g.globalAlpha = 1;\n    { g.font = `700 ${10 * dpr}px system-ui`; let lastX = -1e9;   // v32.19: the bite number on every group of bite 3+\n",
         "    g.globalAlpha = 1;\n"
         "    if (root.HM64Zone && fsTarget() === 'N') {                     // v32.23: which bars depend on where Jack stands\n"
         "      K.zbars = { solid: zall, striped: zdep, zone: root.HM64Zone.cur };\n"
         "      const tx = root.HM64Zone.cur === 'all' ? 'every bar holds wherever Jack stops' : `top row: white = holds wherever Jack stops · orange (striped bar) = only from the ${root.HM64Zone.cur} of the pier end`;\n"
         "      g.font = `${10 * dpr}px system-ui`; const tw = g.measureText(tx).width; g.fillStyle = 'rgba(13,26,20,.82)'; g.fillRect(W - tw - 12 * dpr, bot - 15 * dpr, tw + 10 * dpr, 14 * dpr);\n"
         "      g.fillStyle = '#c8d6cf'; g.fillText(tx, W - tw - 7 * dpr, bot - 4 * dpr); g.font = `600 ${11 * dpr}px system-ui`;\n"
         "    }\n"
         "    { g.font = `700 ${10 * dpr}px system-ui`; let lastX = -1e9;   // v32.19: the bite number on every group of bite 3+\n"),
        ("the pack's memos follow the zone",
         "const dcNutMemo = new Map();\n",
         "const dcNutMemo = new Map();\n"
         "if (root.HM64Zone) root.HM64Zone.onChange(() => { fsClMemo.clear(); fsTopMemo.clear(); fsDbMemo.clear(); dcNutMemo.clear(); dwCardKey = null; });   // v32.23: the cast pack answers for another pier zone\n"),
        ("catch names: f and u",
         "f: 'fish (a Nut only from the north end of the dock)' };",
         "f: 'fish (a Nut only elsewhere on the pier end)', u: 'fish as far as proven (a recorded Nut, not proven here)' };"),
        ("dog cards: not proven here (html)",
         "  const name = x => (x.li >= 0 ? 'L' + (x.li + 1) : 'no table') + (x.fam ?",
         "  const name = x => (x.li >= 0 ? 'L' + (x.li + 1) : 'no table') + (root.HM64Zone ? root.HM64Zone.badge(R.dw.lines[x.dwi].key) : '') + (x.fam ?"),
        ("dog cards: redraw when the zone changes",
         " + '|' + (w.exact == null ? '' : w.exact) + '|' + (car ? 'car' + car.dwi + car.post : '');\n",
         " + '|' + (w.exact == null ? '' : w.exact) + '|' + (car ? 'car' + car.dwi + car.post : '') + '|' + (root.HM64Zone ? root.HM64Zone.cur : '');\n"),
        ("preset text: which table is in use",
         "    startTxt();\n}\nconst fmtS1 = vi =>",
         "    startTxt() + (root.HM64Zone && R.zones ? `<div class=\"small mut\" style=\"margin-top:4px\">Table in use — ${root.HM64Zone.noteTxt(root.HM64Zone.ofGroup(R, cur.g))}</div>` : '');\n}\nconst fmtS1 = vi =>"),
        ("dock-end guess text: axis names instead of 'wait, then 2nd cut'",
         "    d.textContent = `Your dock-end tap says: ${gx.l1} ${Math.round(100 * gx.p1)}% (green)` +\n"
         "      (gx.sure2 ? ` · 2nd cut ${gx.l2.toLowerCase()} ${Math.round(100 * gx.p2)}%` : gx.l2 ? ` · 2nd cut: the tap can't tell (best guess ${gx.l2.toLowerCase()} ${Math.round(100 * gx.p2)}%)` : '') +\n",
         "    d.textContent = `Your dock-end tap says: ${A1.short || A1.id} ${gx.l1.toLowerCase()} ${Math.round(100 * gx.p1)}% (green; a weak guess: the tap moves little with the 2nd cut)` +\n"
         "      (gx.sure2 ? ` · ${A2.short || A2.id} ${gx.l2.toLowerCase()} ${Math.round(100 * gx.p2)}%` : gx.l2 ? ` · ${A2.short || A2.id}: the tap can't tell (best guess ${gx.l2.toLowerCase()} ${Math.round(100 * gx.p2)}%)` : '') +\n"),
    ],
    # ------------------------------------------------------------------------------------------ Casting tables
    "hm64_dogref_v31.js": [
        ("the preset of the picked pier zone",
         "  function ctx(routeId) {\n    const R = C.routeOf(routeId), plan = (C.planSet('all', 'pier', routeId) || [])[0];\n",
         "  const ZN = root.HM64Zone || null;                                 // v32.23: rainy pages, the pier zone picked on this page\n"
         "  const ZG = routeId => { const R = C.routeOf(routeId), id = ZN ? ZN.groupId(ZN.cur) : 'all'; return R && (R.groups || []).some(g => g.id === id) ? id : 'all'; };\n"
         "  function ctx(routeId) {\n    const R = C.routeOf(routeId), plan = (C.planSet(ZG(routeId), 'pier', routeId) || [])[0];\n"),
        ("candidates of that preset",
         "    const cands = DW.candidates(R, plan, 'all', 'pier');\n",
         "    const cands = DW.candidates(R, plan, ZG(routeId), 'pier');\n"),
        ("lead time of that preset",
         "    try { const pf = (C.planSet('all', 'fadein', routeId) || [])[0], v = pf ? pf.variants : [];",
         "    try { const pf = (C.planSet(ZG(routeId), 'fadein', routeId) || [])[0], v = pf ? pf.variants : [];"),
        ("line names: not proven here",
         "  const lineName = (R, dwi) => { const li = R.dw.lines[dwi].li; return li >= 0 ? 'L' + (li + 1) : 'no table'; };\n",
         "  const lineName = (R, dwi) => { const li = R.dw.lines[dwi].li; return (li >= 0 ? 'L' + (li + 1) : 'no table') + (ZN && ZN.unproven(R.dw.lines[dwi].key) ? ' (not proven here)' : ''); };\n"),
        ("flags per zone",
         "  const flagCache = new Map();\n  function flagsOf(key) {",
         "  const flagCache = new Map();\n"
         "  if (ZN) ZN.onChange(() => { flagCache.clear(); if (built) refresh(); });   // v32.23: another pier zone = other casts and other arrivals\n"
         "  function flagsOf(key) {"),
        ("analysis cache per zone",
         "    const key = routeId + '|' + sigMs + '|' + qp + '|' + DATA.generated;\n",
         "    const key = routeId + '|' + sigMs + '|' + qp + '|' + DATA.generated + '|' + (ZN ? ZN.cur : '');\n"),
        ("result tagged with its zone",
         "    const out = { routeId, sigMs, quick: qp, lead: X.lead,",
         "    const out = { routeId, zone: ZN ? ZN.cur : '', sigMs, quick: qp, lead: X.lead,"),
        ("refresh: the wanted result names the zone",
         "    want = rid + '|' + sig + '|' + S.quick;\n    const same = o => want === o.routeId + '|' + o.sigMs + '|' + o.quick;\n",
         "    want = rid + '|' + sig + '|' + S.quick + '|' + (ZN ? ZN.cur : '');\n    const same = o => want === o.routeId + '|' + o.sigMs + '|' + o.quick + '|' + (o.zone || '');\n"),
        ("the zone picker under the table settings",
         "    $('rfPrint').onclick = () => root.print();\n",
         "    $('rfPrint').onclick = () => root.print();\n"
         "    if (ZN && $('rfSpar')) ZN.mount($('rfSpar').parentNode);            // v32.23\n"),
    ],
    # ------------------------------------------------------------------------------------------ Dog practice
    "hm64_practice_v32.js": [
        ("flags, arrivals and the drill follow the zone",
         "  const flagCache = new Map();\n  function flags(key) {",
         "  const flagCache = new Map();\n"
         "  if (root.HM64Zone) root.HM64Zone.onChange(() => { flagCache.clear(); for (const r of ROUTES) r._p = null; S = null; PS.line = 'any'; build(); });   // v32.23: another pier zone\n"
         "  function flags(key) {"),
        ("line names: not proven here",
         "  const lineName = (R, dwi) => { const li = R.dw.lines[dwi].li; return li >= 0 ? 'L' + (li + 1) : 'dog ' + (dwi + 1); };\n",
         "  const lineName = (R, dwi) => { const li = R.dw.lines[dwi].li; return (li >= 0 ? 'L' + (li + 1) : 'dog ' + (dwi + 1)) + (root.HM64Zone && root.HM64Zone.unproven(R.dw.lines[dwi].key) ? ' (not proven here)' : ''); };\n"),
        ("catch names: f and u (v32.22 printed 'undefined' for f)",
         "  const FISH = { N: 'the POWER NUT', s: 'a small fish', m: 'a medium fish', l: 'a large fish' };\n",
         "  const FISH = { N: 'the POWER NUT', s: 'a small fish', m: 'a medium fish', l: 'a large fish', f: 'a fish (a Power Nut only elsewhere on the pier end)', u: 'a fish as far as proven (a recorded Power Nut, not proven here)' };\n"),
        ("the zone picker",
         "    renderKeys();\n    render();\n  }\n",
         "    renderKeys();\n    render();\n"
         "    if (root.HM64Zone && $('prHow')) root.HM64Zone.mount($('prHow'));   // v32.23\n  }\n"),
    ],
}


def apply(name, src):
    """the zone variant of one script; raises SystemExit when an anchor is missing or not unique"""
    for what, old, new in PATCHES.get(name, []):
        n = src.count(old)
        if n != 1:
            raise SystemExit(f"tools/zone_patches.py: {name}: '{what}': the anchor occurs {n} times (must be 1)")
        src = src.replace(old, new)
    return src


if __name__ == "__main__":
    tot = 0
    for name in PATCHES:
        apply(name, (WEB / name).read_text())
        tot += len(PATCHES[name])
        print(f"{name}: {len(PATCHES[name])} patches apply")
    print(f"{tot} patches, every anchor unique")
