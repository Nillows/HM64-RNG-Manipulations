"""Rainy cast pack + route table with the three camera zones of the dock end in ONE file each (v32.23, 2026-11-26).

  python3 -I tools/zone_build.py --pack RECORDED_PACK --routes RECORDED_ROUTES --zz zz_lines.json(folded)
          --spots SP2_casts.jsonl --zones SP3_zones.jsonl --rows FD_casts_b*.jsonl ...
          --pack-out P --routes-out R [--report J]

Input = the RECORDED (north) pack and route table, the pier-spot run (SP2) and the zone run (SP3).

Zones (camera visibility grids, HM64_RAIN_AUDIT_2026-11-25.md section 7): north = Jack's z < 161 (all recordings),
middle = 161 <= z < 191, south = z >= 191. By second cut: D 84: B <= 127 north, 128-137 middle, >= 138 south; D 86:
four less (checked here against every member of every line: any miss stops the build).

Per zone and cast frame (line, frame) the table holds
  * the recorded cast when the zone's measurement of it has the same bites as far as it goes, or it was not measured
    there, its line was, and it is not near a tile the zone treats differently (zone run check: 3,352 of 3,352 as
    recorded). A recorded Power Nut bite that lies after the measured part (or after the recorded row, for a copied
    cast), on a line not measured in the zone, or on a cast frame before Jack can stand there becomes 'u'
    ("not proven here": shown as a fish, out of the odds);
  * the MEASURED cast when the zone gave other bites: its own bite chain built from the zone row (bites, catches, the
    dog), ending where the measurement ends (no chaining into recorded states: a bite state's hash is position-free,
    so an equal hash in another zone does not prove an equal future). This is where the Nuts that exist only in a zone
    come from (new Nuts, and Nuts on another bite).
  "everywhere" (the base) = the recorded cast with every Nut bite that is not a Nut on the same bite at the same moment
  in the middle AND the south zone turned into 'f' (lost in a zone: a Nut only elsewhere) or 'u' (not proven in a zone).
  north = the recording.

Output pack: lines[key].idx = the BASE (everywhere) table, so code that knows nothing of zones reads the safe one;
pack.zones = {"order": [...], "d": {zone: {key: [j, cast, j, cast, ...]}}} = the frames whose cast differs from the base
in that zone. Output routes: every route's lines carry the base flags; route.zones = {"d": {zone: {line index:
[[i, n1, b1, n2, b2, bx], ...]}}, "unproven": {zone: [line keys]}, "counts": ...}; axes / groups rebuilt with the
pier zone as the first pick (2nd cut = north / middle / south) and the wait as the second.
"""
import argparse, collections, copy, json

ap = argparse.ArgumentParser()
for a in ("pack", "routes", "zz", "spots", "zones", "pack-out", "routes-out"):
    ap.add_argument("--" + a, required=True)
ap.add_argument("--report")
ap.add_argument("--rows", nargs="+", required=True, help="the recorded FD_casts_b*.jsonl files")
ap.add_argument("--no-dog", action="store_true", help="measured casts without their dog changes (size test)")
A = ap.parse_args()
pack = json.load(open(A.pack)); routes = json.load(open(A.routes)); zz = json.load(open(A.zz))
assert "f" not in pack["O"] and "u" not in pack["O"] and "zones" not in pack, "the input must be the recorded pack"
P, F, S, E = pack["P"], pack["F"], pack["S"], pack["E"]
R_, N, X, L_, T_ = pack["R"], pack["N"], pack["X"], pack["L"], pack["T"]
O = list(pack["O"]); lines = pack["lines"]
NC0, NS0 = len(S), len(O)
ZONES = ("middle", "south")
RANGE = {"north": (-1e9, 161), "middle": (161, 191), "south": (191, 1e9)}
zone_of_z = lambda z: next(n for n, (lo, hi) in RANGE.items() if lo <= z < hi)
rep = collections.Counter()


def chain(c, limit=40):
    out, t, st = [], F[c], S[c]
    while st is not None and st >= 0 and len(out) < limit:
        out.append((t, O[st], st))
        if N[st] is None or N[st] < 0:
            break
        t += N[st]; st = X[st]
    return out


# ---------------------------------------------------------------- the second-cut mapping, checked on every member
def members_of(key):
    v = zz[key]
    return [m for m in v["members"] + [v["rep"]] if "spot" in m]
miss = 0
for key in zz:
    for m in members_of(key):
        b = m["B"] + (0 if m["D"] == 84 else 4 if m["D"] == 86 else 10 ** 6)
        if ("north" if b <= 127 else "middle" if b <= 137 else "south") != zone_of_z(m["spot"][1]):
            miss += 1
assert miss == 0, "second cut -> zone mapping fails for %d members" % miss
stands = {z: {k for k in lines if k in zz and any(zone_of_z(m["spot"][1]) == z for m in members_of(k))} for z in RANGE}

# ---------------------------------------------------------------- measurements
ZN = {"z164.4": "middle", "z176.4": "middle", "z194.4": "south", "middle": "middle", "south": "south"}
meas = {z: {} for z in ZONES}            # zone -> recorded cast id -> [(bites, row cast, k)]
imposs = {z: set() for z in ZONES}; seen = {z: set() for z in ZONES}
for p in (A.spots, A.zones):
    for ln in open(p):
        r = json.loads(ln); z = ZN.get(r.get("_job", {}).get("zone") or r.get("_job", {}).get("spot"))
        if not z or r.get("ok", True) is False or r.get("key") not in lines:
            continue
        L = lines[r["key"]]; seen[z].add(r["key"])
        for c in r.get("casts", []):
            j, rem = divmod(c["k"] - L["k0"], 2)
            if rem or j < 0 or j >= len(L["idx"]) or L["idx"][j] is None or L["idx"][j] < 0:
                continue
            meas[z].setdefault(L["idx"][j], []).append((tuple((b[0] - c["k"], b[1]) for b in c["b"]), c))
        for k in r.get("skipped", []):
            j, rem = divmod(k - L["k0"], 2)
            if not rem and 0 <= j < len(L["idx"]):
                imposs[z].add((r["key"], j))
best = {z: {} for z in ZONES}            # the longest measurement; all the others must be its prefixes
for z in ZONES:
    for cid, lst in meas[z].items():
        lst.sort(key=lambda x: -len(x[0])); top = lst[0][0]
        if any(g != top[:len(g)] for g, _ in lst):
            rep["casts_measured_twice_that_disagree_" + z] += 1
        best[z][cid] = lst[0]
rowlen = {}
for p in A.rows:
    for ln in open(p):
        try:
            r = json.loads(ln)
        except ValueError:
            continue
        if r.get("key") not in lines:
            continue
        L = lines[r["key"]]
        for c in r.get("casts", []):
            j, rem = divmod(c["k"] - L["k0"], 2)
            if rem or j < 0 or j >= len(L["idx"]) or L["idx"][j] is None or L["idx"][j] < 0:
                continue
            rowlen[L["idx"][j]] = max(rowlen.get(L["idx"][j], 0), len(c.get("b") or []))


# ---------------------------------------------------------------- one frame in one zone
def verdict(z, key, j, cid, ch):
    """('rec', {bite index: 'u'}) = the recorded cast, these Nut bites not proven; ('meas', row cast) = the zone's own
    cast; plus per recorded Nut bite its status keep / lost / unproven / na (for the base table and the counts)"""
    nuts = [i for i, (_, o, _) in enumerate(ch) if o == "N"]
    if key not in stands[z]:
        return ("rec", {}), {i: "na" for i in nuts}
    if (key, j) in imposs[z]:
        return ("rec", {i: "u" for i in nuts}), {i: "na" for i in nuts}
    m = best[z].get(cid)
    if m is None:
        if key not in seen[z]:
            return ("rec", {i: "u" for i in nuts}), {i: "unproven" for i in nuts}
        st = {i: ("keep" if i < rowlen.get(cid, 0) else "unproven") for i in nuts}
        return ("rec", {i: "u" for i in nuts if st[i] != "keep"}), st
    g = m[0]; want = tuple((t, o) for t, o, _ in ch)
    n = min(len(g), len(want)); p = next((i for i in range(n) if g[i] != want[i]), n)
    if p == n and len(g) <= len(want):                       # the same bites as far as the measurement goes
        st = {i: ("keep" if i < len(g) else "unproven") for i in nuts}
        return ("rec", {i: "u" for i in nuts if st[i] != "keep"}), st
    st = {i: ("keep" if i < p else "lost") for i in nuts}    # other bites from bite p on: the zone's own cast
    return ("meas", m[1]), st


def strict_flags(z, key, j, cid, ch, nuts, strict):          # tools/zone_pack.py's rule, for the reconciliation only
    if key not in stands[z]:
        return set()
    if (key, j) in imposs[z]:
        return set(nuts) if strict else set()
    m = meas[z].get(cid)
    if m is None:
        return {i for i in nuts if i >= rowlen.get(cid, 0)} if key in seen[z] else set(nuts)
    out = set()
    for i in nuts:
        want = [(t, o) for t, o, _ in ch[:i + 1]]
        if any(len(g) <= i or list(g[:i + 1]) != want for g, _ in m):
            out.add(i)
    return out


# ---------------------------------------------------------------- new casts / states
STATE = [a for a in ("R", "N", "X", "L", "T") if a in pack]; CAST = [a for a in ("P", "F", "S", "E") if a in pack]
clone = {}
def clone_of(cid, fl, ch):                                   # the recorded cast with some Nut bites lettered f / u
    k = (cid, fl)
    if k in clone:
        return clone[k]
    fd = dict(fl); last = max(fd); ids = []
    for i in range(last + 1):
        st = ch[i][2]; nid = len(O)
        for a in STATE:
            pack[a].append(pack[a][st])
        O.append(fd.get(i, O[st])); ids.append(nid)
    for i in range(last):
        X[ids[i]] = ids[i + 1]
    nc = len(S)
    for a in CAST:
        pack[a].append(pack[a][cid])
    S[nc] = ids[0]; clone[k] = nc; rep["casts_cloned"] += 1; rep["states_cloned"] += len(ids)
    return nc


def undelta(d):
    out, k = [], 0
    for i in range(0, len(d), 2):
        k = d[i] if i == 0 else k + d[i]
        out.append((k, d[i + 1]))
    return out
zstate, zcast = {}, {}
def measured_cast(c):                                        # a zone row's cast as pack entries (tools/dogcast_pack.py's rules)
    k, bs, end = c["k"], c["b"], c["e"][0]
    runs = [] if A.no_dog else undelta(c["d"])
    nxt_sid = -1
    for i in range(len(bs) - 1, -1, -1):
        b = bs[i]; nxt = bs[i + 1][0] if i + 1 < len(bs) else None
        seg, prev = [], b[0]
        for kk, code in runs:
            if kk < b[0] or (nxt is not None and kk >= nxt) or kk > end:
                continue
            seg += [kk - prev, code]; prev = kk
        t = list(c["t"][i]) if (not A.no_dog and i < len(c.get("t") or [])) else []
        if len(t) >= 2 and t[-2] == -1:
            t = t[:-2]
        tail, prev = [], b[0]
        for kk, code in undelta(t):
            tail += [max(0, kk - prev), code]; prev = max(kk, prev)
        gap = nxt - b[0] if nxt is not None else -1
        sig = (b[1][:1], gap, nxt_sid, tuple(seg), tuple(tail), 0 if nxt is not None else end - b[0])
        if sig not in zstate:
            zstate[sig] = len(O)
            R_.append(seg); N.append(gap); X.append(nxt_sid); L_.append(sig[5]); T_.append(tail); O.append(b[1][:1] or "?")
            rep["states_measured"] += 1
        nxt_sid = zstate[sig]
    fb = bs[0][0] if bs else None
    pre, prev = [], k
    for kk, code in runs:
        if kk <= k or (fb is not None and kk >= fb) or kk > end:
            continue
        pre += [kk - prev, code]; prev = kk
    sig = (tuple(pre), fb - k if fb is not None else -1, nxt_sid, end - k)
    if sig not in zcast:
        zcast[sig] = len(S)
        P.append(pre); F.append(sig[1]); S.append(nxt_sid); E.append(end - k); rep["casts_measured"] += 1
    return zcast[sig]


# ---------------------------------------------------------------- every frame
table = {z: {} for z in ("north", "middle", "south", "all")}  # zone -> key -> idx list
for z in table:
    for key, L in lines.items():
        table[z][key] = list(L["idx"])
cnt = collections.defaultdict(collections.Counter)
nut6 = lambda c: any(o == "N" for _, o, _ in chain(c)[:6])
for key, L in lines.items():
    for j, cid in enumerate(L["idx"]):
        if cid is None or cid < 0 or S[cid] is None or S[cid] < 0:
            continue
        ch = chain(cid); nuts = [i for i, (_, o, _) in enumerate(ch) if o == "N"]
        had6 = any(i < 6 for i in nuts)
        if had6:
            cnt["north"]["frames_nut_1_6"] += 1
        status = {}
        for z in ZONES:
            v, st = verdict(z, key, j, cid, ch); status[z] = st
            if v[0] == "rec":
                nc = clone_of(cid, frozenset(v[1].items()), ch) if v[1] else cid
            else:
                nc = measured_cast(v[1])
            table[z][key][j] = nc
            if key in stands[z]:
                has6 = nut6(nc); c = cnt[z]
                c["frames_recorded_nut_1_6"] += had6; c["frames_nut_1_6"] += has6
                if had6 or has6:
                    kept = any(i < 6 and st[i] == "keep" for i in nuts)
                    if kept: c["recorded_nut_kept" + ("_measured" if best[z].get(cid) else "_copied")] += 1
                    elif has6: c["zone_only_nut" + ("_other_bite" if had6 else "_new")] += 1
                    elif (key, j) in imposs[z]: c["before_jack_can_stand_there"] += 1
                    elif key not in seen[z]: c["line_not_measured"] += 1
                    elif any(i < 6 and st[i] == "lost" for i in nuts): c["recorded_nut_lost"] += 1
                    else: c["recorded_nut_not_proven"] += 1
                    if kept and has6 and v[0] == "meas" and any(o == "N" and i >= 0 for i, (_, o, _) in enumerate(chain(nc)[:6]) if i not in nuts):
                        c["kept_plus_another_nut_bite"] += 1
                sf = strict_flags(z, key, j, cid, ch, nuts, True)
                c["strict_rule_kept_1_6"] += any(i < 6 and i not in sf for i in nuts)
            elif had6:
                cnt[z]["frames_nut_1_6_lines_never_here"] += 1
        if nuts:                                             # the base: a Nut only where it stays in both zones
            fl = {}
            for i in nuts:
                s = [status[z][i] for z in ZONES]
                if "lost" in s: fl[i] = "f"
                elif "unproven" in s: fl[i] = "u"
            if fl:
                table["all"][key][j] = clone_of(cid, frozenset(fl.items()), ch)
            c = cnt["all"]
            c["frames_nut_1_6"] += any(i < 6 and i not in fl for i in nuts)
            sfa = strict_flags("middle", key, j, cid, ch, nuts, False) | strict_flags("south", key, j, cid, ch, nuts, False)
            c["strict_rule_kept_1_6"] += any(i < 6 and i not in sfa for i in nuts)
# checks of the construction: base Nut => Nut on that bite at that time in every zone the line stands in
bad = 0
for key, L in lines.items():
    for j, cid in enumerate(L["idx"]):
        if cid is None or cid < 0:
            continue
        b = [(t, o) for t, o, _ in chain(table["all"][key][j])]
        for z in ("north",) + ZONES:
            if key not in stands[z] or (z != "north" and (key, j) in imposs[z]):
                continue
            zc = [(t, o) for t, o, _ in chain(table[z][key][j])]
            for i, (t, o) in enumerate(b):
                if o == "N" and (len(zc) <= i or zc[i] != (t, o) or zc[:i] != [(tt, "N" if oo in "fu" and zc[q][1] == "N" else oo) for q, (tt, oo) in enumerate(b[:i])] and [x[0] for x in zc[:i]] != [x[0] for x in b[:i]]):
                    bad += 1
assert bad == 0, "base Nut that is not a Nut in a zone: %d" % bad
pack["O"] = "".join(O)
lines_out = {}
zd = {z: {} for z in ("north",) + ZONES}
for key, L in lines.items():
    lines_out[key] = {"k0": L["k0"], "idx": table["all"][key]}
    for z in zd:
        d = []
        for j, c in enumerate(table[z][key]):
            if c != table["all"][key][j]:
                d += [j, c]
        if d:
            zd[z][key] = d; rep["frames_differ_from_base_" + z] += len(d) // 2
pack["lines"] = lines_out
unproven = {z: sorted(k for k in stands[z] if k not in seen[z]) for z in ZONES}
unproven["all"] = sorted(set(unproven["middle"]) | set(unproven["south"])); unproven["north"] = []
pack["zones"] = {"v": 1, "by": "tools/zone_build.py", "order": ["all", "north", "middle", "south"], "d": zd,
                 "unproven": unproven,
                 "letters": {"f": "fish here (a Power Nut only elsewhere on the pier end)", "u": "not proven here (shown as a fish)"}}

# ---------------------------------------------------------------- routes: flags per zone, the zone axis
CUT = [("north", "North", "2nd cut frames 1–3", "down-right in the first 3 game frames of the pier window: Jack stops at the north end of the dock end (z 155–158), where the tables were recorded"),
       ("middle", "Middle", "2nd cut frames 4–8", "down-right in game frames 4–8 of the pier window: Jack stops in the middle of the dock end (z 164–188)"),
       ("south", "South", "2nd cut frames 9–11", "down-right in game frames 9–11 of the pier window: Jack stops at the south end of the dock end (z 194–196)")]
WAIT = [("w0", "Clean", "0–0.13 s late", "first step on time or up to 4 game frames late (no correction): wait 0–8 VIs", lambda W: W <= 8),
        ("w1", "Small fix", "0.17–0.30 s late", "first step 5–9 game frames late (a small correction after a loose first turn): wait 10–18 VIs", lambda W: 10 <= W <= 18),
        ("w2", "Big fix", "0.33–0.50 s late", "first step 10–15 game frames late (a bigger correction): wait 20–30 VIs", lambda W: W >= 20)]
OLDCUT = [("early", lambda z: z < 179), ("mid", lambda z: 179 <= z < 191), ("late", lambda z: z >= 191)]
FADE_IN = 3


def groups_for(route, defs, check=None):
    keys = [x["key"] for x in route["line_info"]]; li = {k: i for i, k in enumerate(keys)}
    dwi = {x["key"]: i for i, x in enumerate(route["dw"]["lines"])}
    mem = [(k, m) for k, v in zz.items() for m in v["members"] if "k_off" in m]
    W_all = sum(m["w"] for _, m in mem) or 1.0
    out = []
    for gid, glabel, band, desc, ax, f in defs:
        sel = [(k, m) for k, m in mem if f(m)]; W = sum(m["w"] for _, m in sel)
        if W <= 0:
            continue
        v = {"pier": collections.defaultdict(float), "fadein": collections.defaultdict(float)}
        vu = {"pier": collections.defaultdict(float), "fadein": collections.defaultdict(float)}; cw = 0.0
        for k, m in sel:
            tgt, i = (v, li[k]) if k in li else (vu, dwi[k]) if k in dwi else (None, None)
            if tgt is None:
                continue
            if tgt is v:
                cw += m["w"]
            tgt["pier"][(i, m["k_off"], 1)] += m["w"] / W
            tgt["fadein"][(i, m["k_off"] - m["ready_rel"] + FADE_IN, m["ready_rel"] + 1 - FADE_IN)] += m["w"] / W
        pk = lambda d: [[i, round(w, 7), o, mt] for (i, o, mt), w in sorted(d.items())]
        out.append({"id": gid, "label": glabel, "band": band, "desc": desc, "ax": ax, "share": round(W / W_all, 4),
                    "cover": round(cw / W, 4), "v": {a: pk(d) for a, d in v.items()}, "vu": {a: pk(d) for a, d in vu.items() if d} if any(vu.values()) else {}})
    return out


def old_defs():
    z = lambda m: m["spot"][1]
    out = [("all", "All", "every route", "All simulated routes of this preset", {}, lambda m: True)]
    for i1, lb1, bd1, ds1, f1 in WAIT:
        out.append(("wait-" + i1, None, None, None, {"wait": i1}, lambda m, f1=f1: f1(m.get("W", 0))))
        for i2, f2 in OLDCUT:
            out.append(("wait-%s+cut2-%s" % (i1, i2), None, None, None, {"wait": i1, "cut2": i2}, lambda m, f1=f1, f2=f2: f1(m.get("W", 0)) and f2(z(m))))
    return out


def zone_defs():
    z = lambda m: zone_of_z(m["spot"][1])
    out = [("all", "All", "anywhere on the pier end", "All simulated routes; the table that holds wherever Jack stops on the pier end", {}, lambda m: True)]
    for i2, lb2, bd2, ds2 in CUT:
        out.append(("cut2-" + i2, "2nd cut " + lb2.lower(), bd2, ds2[:1].upper() + ds2[1:], {"cut2": i2}, lambda m, i2=i2: z(m) == i2))
        for i1, lb1, bd1, ds1, f1 in WAIT:
            out.append(("cut2-%s+wait-%s" % (i2, i1), "2nd cut %s · wait %s" % (lb2.lower(), lb1.lower()), bd1,
                        "%s; %s" % (ds2[:1].upper() + ds2[1:], ds1), {"cut2": i2, "wait": i1},
                        lambda m, i2=i2, f1=f1: z(m) == i2 and f1(m.get("W", 0))))
    return out


MEAS = set(zcast.values())
for route in routes["routes"]:
    # proof of the method: the recorded table's own presets come out of the same code
    old = {g["id"]: g for g in route["groups"]}
    mine = {g["id"]: g for g in groups_for(route, old_defs())}
    for gid, g in old.items():
        m = mine.get(gid)
        assert m is not None and m["share"] == g["share"] and m["cover"] == g["cover"] and m["v"] == g["v"] and (m["vu"] or {}) == (g.get("vu") or {}), "preset %s is not reproduced" % gid
    rep["old_presets_reproduced"] += len(old)
    info = route["line_info"]; hz = (route.get("source") or {}).get("bite_horizon") or 5398
    zdr = {z: {} for z in ("north",) + ZONES}; t1 = t2 = 0
    for li, ln in enumerate(route["lines"]):
        key = info[li]["key"]; L = lines[key]; lo = ln["lo"]
        n1 = list(ln["n1"].split(".")) if "." in ln["n1"] and len(ln["n1"]) != len(ln["b1"]) else list(ln["n1"])
        dotted = len(n1) != len(ln["n1"])
        n2 = (list(ln["n2"].split(".")) if dotted else list(ln["n2"])) if "n2" in ln else None
        assert len(n1) == len(ln["b1"]), "n1 format"
        def entry(i, c, orig):
            """the route fields of series index i for pack cast c; orig = the recorded fields (kept where the chain says the same)"""
            ch = chain(c); k = lo + i - 1
            e = [orig[0], orig[1], orig[2], orig[3], copy.copy(orig[4])]
            if ch:
                e[0] = "1" if ch[0][1] == "N" else "0"; e[1] = ch[0][0]
            else:                                            # a measured cast with no bite in its data: not in the odds
                e[0] = "."; e[1] = -1; rep["route_entries_without_a_bite"] += 1
            if n2 is not None and len(ch) > 1:
                e[2] = "1" if ch[1][1] == "N" else "0"; e[3] = ch[1][0]
            elif n2 is not None:                             # no second bite in the data: the hold is unknown
                e[2] = "."; e[3] = -1; rep["route_entries_without_a_2nd_bite"] += 1
            if isinstance(orig[4], list):
                # the recorded table lists the later bites up to the run's bite horizon (a prefix of the pack's chain);
                # a cast with the recorded bite times keeps that length, a measured cast lists all it measured
                cut = len(orig[4])
                later = [(-t if o == "N" else t) for t, o, _ in ch[2:]]
                e[4] = later if c in MEAS else later[:cut]
            return e
        d1 = d2 = 0
        for i in range(len(n1)):
            if n1[i] == ".":
                continue
            k = lo + i - 1; j, rem = divmod(k - L["k0"], 2)
            if rem or j < 0 or j >= len(L["idx"]) or L["idx"][j] is None or L["idx"][j] < 0:
                continue
            orig = [n1[i], ln["b1"][i], n2[i] if n2 is not None else None, ln["b2"][i] if n2 is not None else None, ln["bx"][i] if "bx" in ln else None]
            rec_c = L["idx"][j]
            assert entry(i, rec_c, orig)[:4] == orig[:4], "the route table and the pack disagree on a recorded cast (%s frame %d)" % (key, j)
            base = entry(i, table["all"][key][j], orig) if table["all"][key][j] != rec_c else orig
            for z in zdr:
                zc = table[z][key][j]
                e = orig if zc == rec_c else entry(i, zc, orig)
                if e != base:
                    zdr[z].setdefault(li, []).append([i] + e)
            if base is not orig:
                d1 += n1[i] == "1" and base[0] != "1"; d2 += n2 is not None and n2[i] == "1" and base[2] != "1"
                n1[i] = base[0]; ln["b1"][i] = base[1]
                if n2 is not None:
                    n2[i] = base[2]; ln["b2"][i] = base[3]
                if "bx" in ln:
                    ln["bx"][i] = base[4]
        ln["n1"] = (".".join(n1) if dotted else "".join(n1))
        if n2 is not None:
            ln["n2"] = (".".join(n2) if dotted else "".join(n2))
        if "wins1" in ln: ln["wins1"] -= d1
        if "wins2" in ln: ln["wins2"] -= d2
        if "nut1" in info[li]: info[li]["nut1"] -= d1
        if "nut2" in info[li]: info[li]["nut2"] -= d2
        t1 += d1; t2 += d2
    src = route.get("source")
    if isinstance(src, dict) and "nut1" in src:
        src["nut1"] -= t1; src["nut2"] -= t2
        src["zone_build"] = "base = Nut flags that hold in every camera zone of the dock end; route.zones holds each zone's own flags (tools/zone_build.py)"
    keys = {x["key"] for x in info}
    route["zones"] = {"v": 1, "order": ["all", "north", "middle", "south"], "axis": "cut2", "d": zdr,
                      "unproven": {z: [k for k in unproven[z] if k in keys or any(x["key"] == k for x in route["dw"]["lines"])] for z in unproven},
                      "labels": {"all": "anywhere on the pier end", "north": "north end", "middle": "middle", "south": "south end"}}
    route["axes"] = [{"id": "cut2", "short": "2nd cut", "label": "2nd cut: down-right onto the pier (where Jack stops on the pier end)",
                      "opts": [{"id": i, "label": lb, "band": bd, "desc": ds} for i, lb, bd, ds in CUT]},
                     {"id": "wait", "short": "wait", "needs": "cut2", "label": "Your first step on the beach: how late (tight first turn, then hug the wall)",
                      "opts": [{"id": i, "label": lb, "band": bd, "desc": ds} for i, lb, bd, ds, _ in WAIT]}]
    route["groups"] = groups_for(route, zone_defs())
    route["axes_head"] = ("Rain: where Jack stops on the pier end decides which casts hold (the camera decides when the dog "
                          "leaves the screen's grid). Pick your 2nd cut onto the pier: North = down-right in the first 3 game "
                          "frames of the pier window, Middle = frames 4–8, South = frames 9–11. Any = the casts that hold from "
                          "all three. Then, if you know it, how late your first step was. Each pick has its own best cast.")
    rep["route_n1_cleared_in_base"] += t1; rep["route_n2_cleared_in_base"] += t2
    for z in zdr:
        rep["route_entries_differ_from_base_" + z] += sum(len(v) for v in zdr[z].values())
rep["casts_recorded"] = NC0; rep["states_recorded"] = NS0; rep["casts_total"] = len(S); rep["states_total"] = len(O)
out = {"build": dict(rep), "zones": {z: dict(c) for z, c in cnt.items()},
       "lines_standing": {z: len(stands[z]) for z in stands}, "lines_not_measured": {z: len(unproven[z]) for z in unproven}}
pack["zones"]["report"] = out["zones"]
json.dump(pack, open(getattr(A, "pack_out"), "w"), separators=(",", ":"))
json.dump(routes, open(getattr(A, "routes_out"), "w"), separators=(",", ":"))
if A.report:
    json.dump(out, open(A.report, "w"), indent=1)
print(json.dumps(out, indent=1))
