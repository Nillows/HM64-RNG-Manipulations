HM64 Power Nut Tool v32.23 (2026-11-26) - rainy pages by pier zone

WHAT CHANGED
- Every rainy page (Lucky Timer, Casting tables, Dog practice; both rainy files) now has one table per camera zone of
  the pier end, in ONE cast pack with per-zone frame indexes:
    North  = 2nd cut in pier-window game frames 1-3  (D 84: B up to 127; D 86: four less)  = the full recorded table
    Middle = frames 4-8  (B 128-137)   <- the pages open on this one (the biggest zone, 45% of the plays)
    South  = frames 9-11 (B 138 and later)
    Not sure / Any = the base table: a Nut only where it comes on the same bite at the same moment from all three
  Lucky Timer: the Lucky plan's first row is now "2nd cut: Any / North / Middle / South", the second row the wait
  (your first step), which needs a 2nd cut. Casting tables and Dog practice: four buttons "where Jack stops on the
  pier end". The pick is remembered per game file.
- Middle and South hold the recorded casts that were measured the same there, plus the Nuts that exist only in that
  zone (new Nuts and Nuts on another bite), with bite chains built from the zone measurements.
- A recorded Nut not proven in the zone in use is a fish and out of the odds: 'f' = measured, no Nut there;
  'u' = "fish as far as proven" (the measurement ended before the Nut's bite, or the cast was copied and the Nut lies
  after its recorded row). Dog lines never cast in a zone carry "not proven here".
- Lucky Timer, a picked dog's bars: white cap + solid = the Nut holds wherever Jack stops; orange cap + striped = a
  Nut only from the zone in use.
- Guide 3.3, Not working? "It is raining", the rainy "needs" text, the How-it-works dialog and the README's rainy
  section (zone tables, cue list, line table, wide windows) are rewritten from the new tables.

NUMBERS (cast frames with a Nut on bites 1-6; no horse / horse)
  north 16,823 / 11,036   everywhere 12,620 / 8,703 (v32.22's base was 11,444 / 8,653)
  middle 12,630 / 8,660 (11,796 / 8,010 as recorded + 834 / 650 only there)
  south  12,202 / 8,381 (11,303 / 7,681 as recorded + 899 / 700 only there)
  Under last session's rule (recorded Nuts only, lines that never stand in the zone left as recorded) the same build
  gives 13,102 / 9,024, 12,609 / 8,695 and 12,620 / 8,703: the figures of HM64_V3223_STATE_2026-11-26.md.

FOUND ON THE WAY
- The "11 / 8 lines never measured away from their spot" are 3 / 1: 7 no-horse lines (+ the folded copy) and 6 horse
  lines (+ the copy) have members only at D 86, B 118-120 = north, so they cannot occur elsewhere. Lines that stand
  in the middle / south and were never cast there: no horse d90aba3d, db2a37fa, 8d172153 (6.33% of the plays), horse
  e9a28366 (2.26%).
- v32.22 corrected the route table's Nut flags for bites 1 and 2 only; its later-bite field (bx) kept north-only
  Nuts, so the v32.22 odds lane still counted some bite-3+ Nuts the pack showed as fish. Fixed (all bites, every zone).
- v32.22's Dog practice page printed "undefined" for a catch of kind 'f'. Fixed on the rainy pages.
- The old rainy "Early" 2nd-cut preset (frames 1-6) straddled the north and middle zones; hence the new presets.

CHECKS
- tools/zone_build.py reproduces the recorded tables' own 13 presets from the dog-watch members before it replaces
  them, and stops if any line member breaks the second-cut -> zone mapping (8,547 + 5,700 members, 0 misses).
- tools/zone_verify.py (independent re-read of every measurement): recorded arrays untouched, north = the recording,
  every measured frame's zone bites = its measurements (no horse 128,679 + 103,670, horse 84,310 + 65,822 confirmed,
  0 contradicted), no Nut after a measured part / outside a recorded row / on an unmeasured line, every base Nut a
  Nut in each zone, and the route table's fields = the pack in every zone (88,577 / 71,604 frames x 4 tables).
- In the page (tests/ui_zones.js): each preset's series = the zone's pack table on every route frame, 0 mismatches;
  Nut frames per zone = the build report; the cards / buttons switch tables; back to the first = the first tables.
- Sunny pages: byte-identical to v32.22 apart from the version label and the build date inside the page data. The
  zone code is not in them: tools/zone_patches.py patches the scripts only for pages whose pack has zones.
- Headless Chrome round on old (v32.22) and new pages, mock-Mac release: see claude/HM64_V3223_STATE_2026-11-26.md.

SIZE
  rainy no horse: Lucky Timer 47.3 MB, Casting tables 46.7 MB, Dog practice 9.1 MB (v32.22: 39.7 / 39.1 / 7.3)
  rainy horse:    35.3 / 34.6 / 6.8 MB (29.8 / 29.2 / 5.6)
  One pack with zone indexes: 40.0 / 29.0 MB. Three embedded packs would have been about 97 / 71 MB.

NOT TESTED
- Firefox (every UI test ran in headless Chrome). The console. bash 3.2 (the release script is unchanged, rev g).
- Still not known: Nuts later than the measured part of a cast, the 3 / 1 unmeasured lines, why casts differ
  (the gap campaign). After a release at a bite of a zone-measured cast the dog card has no 4-second tail data.
