# Pier spots: rain-lineup2-horse-287c11a6

Times are seconds after the representative's READY. A row 'split' = the first cast hash that is not the recorded one.

## No cast: the line from each pier spot against the recorded line

| Jack's z at the dock end | lines | weight of those lines | same to 170 s | split by 20 s | 40 s | 60 s | 90 s | 120 s | 170 s | earliest split |
|---|---|---|---|---|---|---|---|---|---|---|
| 154.8 | 1 | 1.6% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 156.2 | 4 | 0.7% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 156.6 | 4 | 2.4% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 158.0 | 6 | 9.4% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 158.4 | 54 | 87.5% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 164.0 | 6 | 9.4% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 164.4 | 54 | 87.5% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 170.0 | 6 | 9.4% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 170.4 | 54 | 87.5% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 176.0 | 6 | 9.4% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 176.4 | 54 | 87.5% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 182.0 | 6 | 9.4% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 182.4 | 54 | 87.5% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 188.0 | 6 | 9.4% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 188.4 | 54 | 87.5% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 194.0 | 6 | 9.4% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 194.4 | 54 | 87.5% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 195.4 | 6 | 9.4% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 195.8 | 60 | 96.9% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 196.1 | 54 | 87.5% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |

(shares are of the route weight of the lines that reach that spot)

## Casts: the recorded casts repeated from other spots

| spot | Jack's z | casts | every bite and catch as recorded | recorded Nut casts | Nut on the same bite at the same moment | recorded no-Nut casts | of those, a Nut now | not possible (before READY at that spot) |
|---|---|---|---|---|---|---|---|---|
| rep | 156.2, 156.6, 158.0, 158.4 | 0 | - | 0 | - | 0 | - | 0 |
| z164.4 | 164.0, 164.4 | 0 | - | 0 | - | 0 | - | 2 |
| z176.4 | 176.0, 176.4 | 0 | - | 0 | - | 0 | - | 7 |
| z194.4 | 194.0, 194.4 | 0 | - | 0 | - | 0 | - | 17 |

Control (the representative's own spot): 0 of 0 casts as recorded; cast-state hash 0 equal / 0 different. Anything but all equal means this lab does not reproduce the recorded run.

## Zone casts: the recorded casts whose dog comes near a tile the zone's grid treats differently

| zone | set | casts | as recorded, every bite | same last bite (moment + catch) | Nut kept but other bites | Nut lost | new Nut | not possible there |
|---|---|---|---|---|---|---|---|---|
| middle | near a differing tile | 30968 | 19512 (63.0%) | 20010 (64.6%) | 0 | 0 | 334 | 17 |
| middle | check sample of the copied casts | 770 | 770 (100.0%) | 770 (100.0%) | 0 | 0 | 0 |  |
| south | near a differing tile | 31176 | 15232 (48.9%) | 15580 (50.0%) | 0 | 0 | 406 | 36 |
| south | check sample of the copied casts | 770 | 770 (100.0%) | 770 (100.0%) | 0 | 0 | 0 |  |

(the check sample should be as recorded on nearly every cast: it measures how safe copying the other casts is)

