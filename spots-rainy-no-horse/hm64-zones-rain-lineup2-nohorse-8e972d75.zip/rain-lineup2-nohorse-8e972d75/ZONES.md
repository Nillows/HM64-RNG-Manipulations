# Pier spots: rain-lineup2-nohorse-8e972d75

Times are seconds after the representative's READY. A row 'split' = the first cast hash that is not the recorded one.

## No cast: the line from each pier spot against the recorded line

| Jack's z at the dock end | lines | weight of those lines | same to 170 s | split by 20 s | 40 s | 60 s | 90 s | 120 s | 170 s | earliest split |
|---|---|---|---|---|---|---|---|---|---|---|
| 154.8 | 1 | 1.5% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 156.2 | 6 | 2.4% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 156.6 | 5 | 4.5% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 158.0 | 10 | 12.3% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 158.4 | 78 | 80.8% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 164.0 | 10 | 12.3% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 164.4 | 78 | 80.8% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 170.0 | 10 | 12.3% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 170.4 | 78 | 80.8% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 176.0 | 10 | 12.3% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 176.4 | 78 | 80.8% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 182.0 | 10 | 12.3% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 182.4 | 78 | 80.8% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 188.0 | 10 | 12.3% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 188.4 | 78 | 80.8% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 194.0 | 10 | 12.3% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 194.4 | 77 | 77.2% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 195.4 | 10 | 12.3% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 195.8 | 87 | 93.1% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |
| 196.1 | 78 | 80.8% | 100.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | 0.0% | - |

(shares are of the route weight of the lines that reach that spot)

## Casts: the recorded casts repeated from other spots

| spot | Jack's z | casts | every bite and catch as recorded | recorded Nut casts | Nut on the same bite at the same moment | recorded no-Nut casts | of those, a Nut now | not possible (before READY at that spot) |
|---|---|---|---|---|---|---|---|---|
| rep | 156.2, 156.6, 158.0, 158.4 | 0 | - | 0 | - | 0 | - | 0 |
| z164.4 | 164.0, 164.4 | 0 | - | 0 | - | 0 | - | 3 |
| z176.4 | 176.0, 176.4 | 0 | - | 0 | - | 0 | - | 12 |
| z194.4 | 194.0, 194.4, 195.8 | 0 | - | 0 | - | 0 | - | 24 |

Control (the representative's own spot): 0 of 0 casts as recorded; cast-state hash 0 equal / 0 different. Anything but all equal means this lab does not reproduce the recorded run.

## Zone casts: the recorded casts whose dog comes near a tile the zone's grid treats differently

| zone | set | casts | as recorded, every bite | same last bite (moment + catch) | Nut kept but other bites | Nut lost | new Nut | not possible there |
|---|---|---|---|---|---|---|---|---|
| middle | near a differing tile | 47697 | 30839 (64.7%) | 31290 (65.6%) | 0 | 0 | 380 | 67 |
| middle | check sample of the copied casts | 907 | 907 (100.0%) | 907 (100.0%) | 0 | 0 | 0 |  |
| south | near a differing tile | 47962 | 25617 (53.4%) | 26160 (54.5%) | 0 | 0 | 473 | 121 |
| south | check sample of the copied casts | 905 | 905 (100.0%) | 905 (100.0%) | 0 | 0 | 0 |  |

(the check sample should be as recorded on nearly every cast: it measures how safe copying the other casts is)

