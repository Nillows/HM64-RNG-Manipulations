# HM64 full-day lab — the cast table and the dog to the end of the game day

## 1. The day without a cast (every dog line, stay-awake push every 33 s)

- 68 lines ran of 68; dog at READY: [-197.27, 222.24]
- Clock at READY: 06:48 – 06:51. Followed to 5398 VIs = 90 s after READY (the limit).
- Same paths as the dog-watch run? cast hashes of the first 33 s: **67660 equal, 0 different**.
- Ended by something else than the limit / the end of the day: 0
- The dog's visible changes over that time: 89 per line.
- **The dog leaves its spot** (moved 4 units or more) on 37 of 68 lines; earliest 3 s after READY, median 39 s.
- Its tile leaves the visibility grid (not on screen, not animating) on 7 lines.

## 2. Cast blocks (every cast held to the limit, or the end of the day)

| block | cast frames (s after READY) | lines | casts planned | done | job errors | hash check ok / failed / none | ended: as planned / beach check / other | bites per cast | casts with a Nut on some bite |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 0.1 – 40.1 · heavy | 50 | 44898 | 44898 | 0 | 43848 / 0 / 1050 | 44898 / 0 / 0 | 6.6 | 2207 (4.9%) |
| 1 | 0.1 – 40.1 · other | 18 | 8669 | 8669 | 0 | 8291 / 0 / 378 | 8669 / 0 / 0 | 6.9 | 381 (4.4%) |

Blocks not started: 0 (0 casts). Data so far: 58.6 MB.

## 3. The beach check

- 53567 casts: **53567 ran to the limit / the end of the day on the beach at the dock end**, 0 were stopped by the beach check, 0 ended another way.
- Cast hash = the dog-watch run's state at that frame: 52139 equal, **0 different**, 1428 not compared (cast frames inside a stay-awake push).

## 4. Bites and Nuts by game hour (on the held casts)

- 356676 bites; released 4 polls after the bite: m 123075, l 119463, s 111495, N 2643 (N Nut, s / m / l fish size, d the day ended before the catch, x miss, h held through, o other; a / b = the two release probes differ).
- The two release probes of bites 1-2 gave different catches on 0 bites.
- Nut by bite number: bite 1: 1179, bite 2: 719, bite 3: 283, bite 4: 240, bite 5+: 222.

| game hour | bites | Nut bites | Nut share |
|---|---|---|---|
| 07:00 | 9462 | 191 | 2.02% |
| 08:00 | 30909 | 642 | 2.08% |
| 09:00 | 44366 | 1117 | 2.52% |
| 10:00 | 41230 | 24 | 0.06% |
| 11:00 | 51025 | 669 | 1.31% |
| 12:00 | 96344 | 0 | 0.00% |
| 13:00 | 79977 | 0 | 0.00% |
| 14:00 | 3090 | 0 | 0.00% |
| 15:00 | 76 | 0 | 0.00% |
| 16:00 | 176 | 0 | 0.00% |
| 18:00 | 21 | 0 | 0.00% |

These are bites of casts HELD since the cast frame, not fresh casts at that hour: a later hour is
reached only by holding through every earlier bite.

## 5. Do the held casts run into each other?

- 356676 bite states, 25393 distinct (92.9% shared): a shared state has the same future, so its later bites need not be simulated twice.

## 6. The dog after the cast

- Visible changes recorded from the cast to the end of its run: 68 per cast; on the released paths (the 4 s after each bite): 5.0 per bite.
- The dog leaves its spot at some point of the run in 33007 of 53567 casts (62%).

## 7. Against the dog-watch run's cast table (same state hash)

- 43896 casts are in both: bite times and Nut flags **equal in 43895, different in 1**.
  - ('e33c1537', 216, [(376, False), (648, False)], [(372, False), (1908, False)])

