# HM64 full-day lab — the cast table and the dog to the end of the game day

## 1. The day without a cast (every dog line, stay-awake push every 33 s)

- 68 lines ran of 68; dog at READY: [-197.27, 222.24]
- Clock at READY: 06:48 – 06:51. Followed to 8398 VIs = 140 s after READY (the limit).
- Same paths as the dog-watch run? cast hashes of the first 33 s: **67660 equal, 0 different**.
- Ended by something else than the limit / the end of the day: 0
- The dog's visible changes over that time: 140 per line.
- **The dog leaves its spot** (moved 4 units or more) on 62 of 68 lines; earliest 3 s after READY, median 53 s.
- Its tile leaves the visibility grid (not on screen, not animating) on 13 lines.

## 2. Cast blocks (every cast held to the limit, or the end of the day)

| block | cast frames (s after READY) | lines | casts planned | done | job errors | hash check ok / failed / none | ended: as planned / beach check / other | bites per cast | casts with a Nut on some bite |
|---|---|---|---|---|---|---|---|---|---|
| 2 | 40.1 – 80.2 · heavy | 50 | 36005 | 9746 | 0 | 9368 / 0 / 378 | 9746 / 0 / 0 | 6.3 | 333 (3.4%) |
| 3 | 40.1 – 80.2 · other | 18 | 5201 | 2707 | 0 | 2515 / 0 / 192 | 2707 / 0 / 0 | 5.8 | 78 (2.9%) |
| 4 | 80.2 – 90.3 · heavy | 41 | 8401 | 3938 | 0 | 3938 / 0 / 0 | 3938 / 0 / 0 | 3.7 | 146 (3.7%) |
| 5 | 80.2 – 90.3 · other | 8 | 1216 | 604 | 0 | 604 / 0 / 0 | 604 / 0 / 0 | 3.6 | 48 (7.9%) |

Blocks not started: 2 (53567 casts). Data so far: 18.0 MB.

## 3. The beach check

- 16995 casts: **16995 ran to the limit / the end of the day on the beach at the dock end**, 0 were stopped by the beach check, 0 ended another way.
- Cast hash = the dog-watch run's state at that frame: 16425 equal, **0 different**, 570 not compared (cast frames inside a stay-awake push).

## 4. Bites and Nuts by game hour (on the held casts)

- 93463 bites; released 4 polls after the bite: m 32784, s 31457, l 28616, N 606 (N Nut, s / m / l fish size, d the day ended before the catch, x miss, h held through, o other; a / b = the two release probes differ).
- The two release probes of bites 1-2 gave different catches on 0 bites.
- Nut by bite number: bite 1: 159, bite 2: 131, bite 3: 118, bite 4: 77, bite 5+: 121.

| game hour | bites | Nut bites | Nut share |
|---|---|---|---|
| 10:00 | 1088 | 16 | 1.47% |
| 11:00 | 3903 | 184 | 4.71% |
| 12:00 | 11287 | 0 | 0.00% |
| 13:00 | 16327 | 1 | 0.01% |
| 14:00 | 16835 | 86 | 0.51% |
| 15:00 | 13578 | 233 | 1.72% |
| 16:00 | 13745 | 81 | 0.59% |
| 17:00 | 11726 | 2 | 0.02% |
| 18:00 | 4446 | 0 | 0.00% |
| 19:00 | 497 | 3 | 0.60% |
| 20:00 | 19 | 0 | 0.00% |
| 21:00 | 2 | 0 | 0.00% |
| 22:00 | 10 | 0 | 0.00% |

These are bites of casts HELD since the cast frame, not fresh casts at that hour: a later hour is
reached only by holding through every earlier bite.

## 5. Do the held casts run into each other?

- 93463 bite states, 17126 distinct (81.7% shared): a shared state has the same future, so its later bites need not be simulated twice.

## 6. The dog after the cast

- Visible changes recorded from the cast to the end of its run: 68 per cast; on the released paths (the 4 s after each bite): 4.9 per bite.
- The dog leaves its spot at some point of the run in 15012 of 16995 casts (88%).

## 7. Against the dog-watch run's cast table (same state hash)

- 0 casts are in both: bite times and Nut flags **equal in 0, different in 0**.

