# HM64 full-day lab — the cast table and the dog to the end of the game day

## 1. The day without a cast (every dog line, stay-awake push every 33 s)

- 68 lines ran of 68; dog at READY: [-197.27, 222.24]
- Clock at READY: 06:48 – 06:51. Followed to 8398 VIs = 140 s after READY (the limit).
- Same paths as the dog-watch run? cast hashes of the first 33 s: **67660 equal, 0 different**.
- Ended by something else than the limit / the end of the day: 0
- The dog's visible changes over that time: 140 per line.
- **The dog leaves its spot** (moved 4 units or more) on 62 of 68 lines; earliest 3 s after READY, median 53 s.
- Its tile leaves the visibility grid (not on screen, not animating) on 13 lines.

## 2. Cast blocks (every cast held to the limit, or the end of the day)

| block | cast frames (s after READY) | lines | casts planned | done | job errors | hash check ok / failed / none | ended: as planned / beach check / other | bites per cast | casts with a Nut on some bite |
|---|---|---|---|---|---|---|---|---|---|
| 2 | 40.1 – 80.2 · heavy | 50 | 36005 | 6420 | 0 | 6159 / 0 / 261 | 6420 / 0 / 0 | 6.0 | 285 (4.4%) |
| 3 | 40.1 – 80.2 · other | 18 | 5201 | 2494 | 0 | 2308 / 0 / 186 | 2494 / 0 / 0 | 5.3 | 62 (2.5%) |
| 4 | 80.2 – 90.3 · heavy | 41 | 8401 | 4463 | 0 | 4463 / 0 / 0 | 4463 / 0 / 0 | 3.7 | 170 (3.8%) |
| 5 | 80.2 – 90.3 · other | 8 | 1216 | 660 | 0 | 660 / 0 / 0 | 660 / 0 / 0 | 3.5 | 24 (3.6%) |

Blocks not started: 2 (53567 casts). Data so far: 13.7 MB.

## 3. The beach check

- 14037 casts: **14037 ran to the limit / the end of the day on the beach at the dock end**, 0 were stopped by the beach check, 0 ended another way.
- Cast hash = the dog-watch run's state at that frame: 13590 equal, **0 different**, 447 not compared (cast frames inside a stay-awake push).

## 4. Bites and Nuts by game hour (on the held casts)

- 70675 bites; released 4 polls after the bite: m 24082, s 24031, l 22019, N 543 (N Nut, s / m / l fish size, d the day ended before the catch, x miss, h held through, o other; a / b = the two release probes differ).
- The two release probes of bites 1-2 gave different catches on 0 bites.
- Nut by bite number: bite 1: 130, bite 2: 126, bite 3: 102, bite 4: 59, bite 5+: 126.

| game hour | bites | Nut bites | Nut share |
|---|---|---|---|
| 10:00 | 527 | 13 | 2.47% |
| 11:00 | 2243 | 118 | 5.26% |
| 12:00 | 7417 | 0 | 0.00% |
| 13:00 | 11206 | 2 | 0.02% |
| 14:00 | 13662 | 48 | 0.35% |
| 15:00 | 12189 | 245 | 2.01% |
| 16:00 | 10387 | 100 | 0.96% |
| 17:00 | 9277 | 8 | 0.09% |
| 18:00 | 3071 | 0 | 0.00% |
| 19:00 | 641 | 9 | 1.40% |
| 20:00 | 27 | 0 | 0.00% |
| 21:00 | 16 | 0 | 0.00% |
| 22:00 | 12 | 0 | 0.00% |

These are bites of casts HELD since the cast frame, not fresh casts at that hour: a later hour is
reached only by holding through every earlier bite.

## 5. Do the held casts run into each other?

- 70675 bite states, 13501 distinct (80.9% shared): a shared state has the same future, so its later bites need not be simulated twice.

## 6. The dog after the cast

- Visible changes recorded from the cast to the end of its run: 62 per cast; on the released paths (the 4 s after each bite): 4.8 per bite.
- The dog leaves its spot at some point of the run in 11507 of 14037 casts (82%).

## 7. Against the dog-watch run's cast table (same state hash)

- 0 casts are in both: bite times and Nut flags **equal in 0, different in 0**.

