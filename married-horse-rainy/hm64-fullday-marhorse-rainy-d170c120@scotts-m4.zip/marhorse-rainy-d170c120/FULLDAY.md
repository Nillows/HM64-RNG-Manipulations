# HM64 full-day lab — the cast table and the dog to the end of the game day

## 1. The day without a cast (every dog line, stay-awake push every 33 s)

- 68 lines ran of 68; dog at READY: [-197.27, 222.24]
- Clock at READY: 06:48 – 06:51. Followed to 10198 VIs = 170 s after READY (the limit).
- Same paths as the dog-watch run? cast hashes of the first 33 s: **67660 equal, 0 different**.
- Ended by something else than the limit / the end of the day: 0
- The dog's visible changes over that time: 166 per line.
- **The dog leaves its spot** (moved 4 units or more) on 62 of 68 lines; earliest 3 s after READY, median 53 s.
- Its tile leaves the visibility grid (not on screen, not animating) on 21 lines.

## 2. Cast blocks (every cast held to the limit, or the end of the day)

| block | cast frames (s after READY) | lines | casts planned | done | job errors | hash check ok / failed / none | ended: as planned / beach check / other | bites per cast | casts with a Nut on some bite |
|---|---|---|---|---|---|---|---|---|---|
| 4 | 80.2 – 120.3 · heavy | 50 | 33268 | 20852 | 0 | 20089 / 0 / 763 | 20852 / 0 / 0 | 4.7 | 1050 (5.0%) |
| 5 | 80.2 – 120.3 · other | 18 | 5189 | 3179 | 0 | 2969 / 0 / 210 | 3179 / 0 / 0 | 4.8 | 162 (5.1%) |

Blocks not started: 4 (94773 casts). Data so far: 21.8 MB.

## 3. The beach check

- 24031 casts: **24031 ran to the limit / the end of the day on the beach at the dock end**, 0 were stopped by the beach check, 0 ended another way.
- Cast hash = the dog-watch run's state at that frame: 23058 equal, **0 different**, 973 not compared (cast frames inside a stay-awake push).

## 4. Bites and Nuts by game hour (on the held casts)

- 112322 bites; released 4 polls after the bite: s 44431, m 34823, l 31853, N 1215 (N Nut, s / m / l fish size, d the day ended before the catch, x miss, h held through, o other; a / b = the two release probes differ).
- The two release probes of bites 1-2 gave different catches on 0 bites.
- Nut by bite number: bite 1: 170, bite 2: 301, bite 3: 356, bite 4: 172, bite 5+: 216.

| game hour | bites | Nut bites | Nut share |
|---|---|---|---|
| 13:00 | 425 | 1 | 0.24% |
| 14:00 | 5919 | 27 | 0.46% |
| 15:00 | 15243 | 226 | 1.48% |
| 16:00 | 13978 | 162 | 1.16% |
| 17:00 | 23432 | 221 | 0.94% |
| 18:00 | 7012 | 0 | 0.00% |
| 19:00 | 27699 | 577 | 2.08% |
| 20:00 | 17230 | 1 | 0.01% |
| 21:00 | 917 | 0 | 0.00% |
| 22:00 | 368 | 0 | 0.00% |
| 23:00 | 82 | 0 | 0.00% |
| 00:00 | 17 | 0 | 0.00% |

These are bites of casts HELD since the cast frame, not fresh casts at that hour: a later hour is
reached only by holding through every earlier bite.

## 5. Do the held casts run into each other?

- 112322 bite states, 22227 distinct (80.2% shared): a shared state has the same future, so its later bites need not be simulated twice.

## 6. The dog after the cast

- Visible changes recorded from the cast to the end of its run: 59 per cast; on the released paths (the 4 s after each bite): 4.2 per bite.
- The dog leaves its spot at some point of the run in 21423 of 24031 casts (89%).

## 7. Against the dog-watch run's cast table (same state hash)

- 0 casts are in both: bite times and Nut flags **equal in 0, different in 0**.

