# HM64 full-day lab — the cast table and the dog to the end of the game day

## 1. The day without a cast (every dog line, stay-awake push every 33 s)

- 68 lines ran of 68; dog at READY: [-197.27, 222.24]
- Clock at READY: 06:48 – 06:51. Followed to 10198 VIs = 170 s after READY (the limit).
- Same paths as the dog-watch run? cast hashes of the first 33 s: **67660 equal, 0 different**.
- Ended by something else than the limit / the end of the day: 0
- The dog's visible changes over that time: 166 per line.
- **The dog leaves its spot** (moved 4 units or more) on 62 of 68 lines; earliest 3 s after READY, median 53 s.
- Its tile leaves the visibility grid (not on screen, not animating) on 21 lines.

## 2. Cast blocks (every cast held to the limit, or the end of the day)

| block | cast frames (s after READY) | lines | casts planned | done | job errors | hash check ok / failed / none | ended: as planned / beach check / other | bites per cast | casts with a Nut on some bite |
|---|---|---|---|---|---|---|---|---|---|
| 4 | 80.2 – 120.3 · heavy | 50 | 33268 | 13256 | 0 | 12948 / 0 / 308 | 13256 / 0 / 0 | 4.7 | 708 (5.3%) |
| 5 | 80.2 – 120.3 · other | 18 | 5189 | 2394 | 0 | 2226 / 0 / 168 | 2394 / 0 / 0 | 4.6 | 100 (4.2%) |

Blocks not started: 4 (94773 casts). Data so far: 13.8 MB.

## 3. The beach check

- 15650 casts: **15650 ran to the limit / the end of the day on the beach at the dock end**, 0 were stopped by the beach check, 0 ended another way.
- Cast hash = the dog-watch run's state at that frame: 15174 equal, **0 different**, 476 not compared (cast frames inside a stay-awake push).

## 4. Bites and Nuts by game hour (on the held casts)

- 73988 bites; released 4 polls after the bite: s 30410, m 22212, l 20551, N 815 (N Nut, s / m / l fish size, d the day ended before the catch, x miss, h held through, o other; a / b = the two release probes differ).
- The two release probes of bites 1-2 gave different catches on 0 bites.
- Nut by bite number: bite 1: 135, bite 2: 207, bite 3: 188, bite 4: 135, bite 5+: 150.

| game hour | bites | Nut bites | Nut share |
|---|---|---|---|
| 13:00 | 244 | 1 | 0.41% |
| 14:00 | 4182 | 25 | 0.60% |
| 15:00 | 10646 | 116 | 1.09% |
| 16:00 | 9046 | 94 | 1.04% |
| 17:00 | 14180 | 123 | 0.87% |
| 18:00 | 4157 | 0 | 0.00% |
| 19:00 | 19031 | 455 | 2.39% |
| 20:00 | 11729 | 1 | 0.01% |
| 21:00 | 465 | 0 | 0.00% |
| 22:00 | 257 | 0 | 0.00% |
| 23:00 | 50 | 0 | 0.00% |
| 00:00 | 1 | 0 | 0.00% |

These are bites of casts HELD since the cast frame, not fresh casts at that hour: a later hour is
reached only by holding through every earlier bite.

## 5. Do the held casts run into each other?

- 73988 bite states, 14117 distinct (80.9% shared): a shared state has the same future, so its later bites need not be simulated twice.

## 6. The dog after the cast

- Visible changes recorded from the cast to the end of its run: 56 per cast; on the released paths (the 4 s after each bite): 3.9 per bite.
- The dog leaves its spot at some point of the run in 13610 of 15650 casts (87%).

## 7. Against the dog-watch run's cast table (same state hash)

- 0 casts are in both: bite times and Nut flags **equal in 0, different in 0**.

