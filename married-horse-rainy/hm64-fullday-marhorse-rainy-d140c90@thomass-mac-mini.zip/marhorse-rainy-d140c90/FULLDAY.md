# HM64 full-day lab — the cast table and the dog to the end of the game day

## 1. The day without a cast (every dog line, stay-awake push every 33 s)

- 68 lines ran of 68; dog at READY: [-197.27, 222.24]
- Clock at READY: 06:48 – 06:51. Followed to 8398 VIs = 140 s after READY (the limit).
- Same paths as the dog-watch run? cast hashes of the first 33 s: **67660 equal, 0 different**.
- Ended by something else than the limit / the end of the day: 0
- The dog's visible changes over that time: 140 per line.
- **The dog leaves its spot** (moved 4 units or more) on 62 of 68 lines; earliest 3 s after READY, median 53 s.
- Its tile leaves the visibility grid (not on screen, not animating) on 13 lines.

## 2. Cast blocks (every cast held to the limit, or the end of the day)

| block | cast frames (s after READY) | lines | casts planned | done | job errors | hash check ok / failed / none | ended: as planned / beach check / other | bites per cast | casts with a Nut on some bite |
|---|---|---|---|---|---|---|---|---|---|
| 2 | 40.1 – 80.2 · heavy | 50 | 36005 | 19839 | 0 | 19428 / 0 / 411 | 19839 / 0 / 0 | 5.9 | 701 (3.5%) |

Blocks not started: 5 (68385 casts). Data so far: 21.6 MB.

## 3. The beach check

- 19839 casts: **19839 ran to the limit / the end of the day on the beach at the dock end**, 0 were stopped by the beach check, 0 ended another way.
- Cast hash = the dog-watch run's state at that frame: 19428 equal, **0 different**, 411 not compared (cast frames inside a stay-awake push).

## 4. Bites and Nuts by game hour (on the held casts)

- 116843 bites; released 4 polls after the bite: m 42002, s 39738, l 34398, N 705 (N Nut, s / m / l fish size, d the day ended before the catch, x miss, h held through, o other; a / b = the two release probes differ).
- The two release probes of bites 1-2 gave different catches on 0 bites.
- Nut by bite number: bite 1: 295, bite 2: 86, bite 3: 50, bite 4: 89, bite 5+: 185.

| game hour | bites | Nut bites | Nut share |
|---|---|---|---|
| 10:00 | 1644 | 28 | 1.70% |
| 11:00 | 7226 | 334 | 4.62% |
| 12:00 | 18372 | 0 | 0.00% |
| 13:00 | 23581 | 0 | 0.00% |
| 14:00 | 19041 | 101 | 0.53% |
| 15:00 | 13740 | 211 | 1.54% |
| 16:00 | 15823 | 31 | 0.20% |
| 17:00 | 10861 | 0 | 0.00% |
| 18:00 | 5679 | 0 | 0.00% |
| 19:00 | 876 | 0 | 0.00% |

These are bites of casts HELD since the cast frame, not fresh casts at that hour: a later hour is
reached only by holding through every earlier bite.

## 5. Do the held casts run into each other?

- 116843 bite states, 16773 distinct (85.6% shared): a shared state has the same future, so its later bites need not be simulated twice.

## 6. The dog after the cast

- Visible changes recorded from the cast to the end of its run: 67 per cast; on the released paths (the 4 s after each bite): 4.7 per bite.
- The dog leaves its spot at some point of the run in 15402 of 19839 casts (78%).

## 7. Against the dog-watch run's cast table (same state hash)

- 0 casts are in both: bite times and Nut flags **equal in 0, different in 0**.

