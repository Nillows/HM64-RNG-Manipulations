# Dog-spot lab (dogwatch): married-horse-lineup2-rainy-8cbe43a5.SaveRAM

Zig-zag route with the zigzag-fast recipe of route delays, dog-neutral (no dog-wake rule or key: every first / second cut is walked and kept, lines are anchored at the beach load and matched by game state at READY).

## The save

- file `married-horse-lineup2-rainy-8cbe43a5.SaveRAM` (sha256 8cbe43a540e30d5b)
- spring 12, year 1; weather 2; 6:00 at the house load; rod in hand: True
- dog at the house load: **beach** (map 9) x -197.27, z 222.24, facing 0, flags ACTIVE
- dog on screen at the load of: beach
- repeatable (two cold boots give the same record): **yes**
- reference route (mash 10/s START→A, house U276 V52, crossroads C80, beach D86 B134), map loads: house VI 1036, farm +412, crossroads +350, ranch +236, beach +230; READY 339 VIs after the beach load at x -92.0, z 194.0

## Failure map: where the recipe never reaches READY

Mass = uniform choices over this preset's grids (mash phase per rate, rates pooled; house U, V; crossroads C; first cut D; any second cut B). Each stage starts from the mass kept by the stage before.

| stage | runs | never reached | mass kept | outside the band (slower; or faster for a 5-9-frame preset) | never reached (mass) | where Jack stopped (most common) |
|---|---|---|---|---|---|---|
| menus | 144 | 0 | 0.6675 | 0.3325 | 0.0000 | - |
| house | 2548 | 462 | 0.2879 | 0.2586 | 0.1210 | 364× map 87 x≈96 z≈80; 28× map 87 x≈-24 z≈120; 28× map 87 x≈-32 z≈128 |
| crossroads | 324 | 9 | 0.2639 | 0.0160 | 0.0080 | 9× map 78 x≈120 z≈0 |
| ranch | 8 | 0 | 0.2639 | 0.0000 | 0.0000 | - |
| beach | 256 | 0 | 0.2639 | 0.0000 | 0.0000 | - |

- **mass of the recipe that reaches the dock end: 0.2639** (the D grid includes 82–83, which never clear the small wall on the dog-beach save)

| first cut D | P(some B reaches the dock end) | B in the window (VIs: count of beach states) | why the other B stop (D without a window) |
|---|---|---|---|
| 84 | 1.000 | 22: 128 | - |
| 86 | 1.000 | 22: 128 | - |

Second cut B by first cut D (share of the beach-state mass that reaches the dock end; else why Jack stopped, and where):

- D 84: 112–121 no READY (map 9 x≈-208 z≈120) · 122–143 READY · 144–151 no READY (map 9 x≈-224 z≈224)
- D 86: 112–117 no READY (map 9 x≈-208 z≈128) · 118–139 READY · 140–151 no READY (map 9 x≈-224 z≈224)

| 1st cut (web app bands) | share of the D grid | P(a 2nd cut reaches the dock end) |
|---|---|---|
| tight | 1.000 | 1.000 |

## Lines (dog-neutral: anchored at the beach load, matched by game state at READY)

- 68 lines from 128 beach states; lines per beach state (count of states): 3: 5, 4: 123; **0 of 128 beach states collapse to one line** (every first and second cut of that state shares one RNG trajectory, offset in time only)
- largest READY offset inside a line: 44 VIs; members not matched to any path: 0

## Cut timing, split as the web app does (cast spread 150 ms)

| preset | share of routes | release bite 1 | hold to bite 2 | either (upper bound) |
|---|---|---|---|---|
| All | 1.000 | 6.07% at 21.07 s | 4.63% at 7.53 s | 8.98% at 27.7 s |
| 1st cut tight | 1.000 | 6.07% at 21.07 s | 4.63% at 7.53 s | 8.98% at 27.7 s |
| 1st cut tight · 2nd cut early | 0.545 | 6.47% at 21.17 s | 4.93% at 7.6 s | 9.26% at 27.8 s |
| 1st cut tight · 2nd cut middle | 0.182 | 6.48% at 21.07 s | 4.98% at 7.53 s | 9.43% at 27.7 s |
| 1st cut tight · 2nd cut late | 0.273 | 6.31% at 20.93 s | 4.81% at 7.4 s | 9.30% at 27.53 s |
| 1st cut mid | 0.000 | - | - | - |
| 1st cut mid · 2nd cut early | 0.000 | - | - | - |
| 1st cut mid · 2nd cut middle | 0.000 | - | - | - |
| 1st cut mid · 2nd cut late | 0.000 | - | - | - |
| 1st cut loose | 0.000 | - | - | - |
| 1st cut loose · 2nd cut early | 0.000 | - | - | - |
| 1st cut loose · 2nd cut middle | 0.000 | - | - | - |
| 1st cut loose · 2nd cut late | 0.000 | - | - | - |

## Lineup: stability

- 68 lines; the heaviest holds 5.0% of the routes; 20 lines hold 50% and 50 hold 90% (fewer = steadier dog)
- one beach start (beach state + wait) across the full pier width: lines (count of starts) 3: 5, 4: 123; how the second cuts split: B 118-119 + B 120-123 + B 122-139 + B 126-143 (121 starts); B 118-143 + B 120-123 + B 122-139 (3 starts); B 118-119 + B 120-121 + B 122-139 + B 122-143 (2 starts); B 118-139 + B 120-123 + B 126-143 (2 starts)
- one wait + second cut across the beach states (the route before the beach): lines (count) 5: 160, 9: 48, 10: 208

## Lineup: does the dog keep drawing after READY (standing at the pier, no cast)?

- routes whose line has the dog drawing after READY: **100.0%**; extra draws over 39 s (above the 1-per-game-frame clock), route-weighted mean 20653; dog's tile visible 99% of the time

## Lineup: where the dog activates (its tile enters the camera's view; until then it draws nothing)

First VI after the beach load (share of routes): 205: 0.3%, 207: 0.9%, 209: 3.7%, 211: 6.3%, 213: 6.2%, 215: 6.3%, 217: 6.3%, 219: 6.3%, 221: 6.3%, 223: 6.3%, 225: 6.3%, 227: 6.3%, 229: 6.3%, 231: 6.3%, 233: 6.3%, 235: 6.3%, 237: 6.0%, 239: 5.4%, 241: 2.6%

| Jack at the activation (x, z; 8-unit cells) | share of routes | lines | release bite 1 | hold to bite 2 |
|---|---|---|---|---|
| x -456…-448, z 160…168 | 0.727 | 61 | 6.11% at 21.03 s (cover 0.97) | 4.64% at 7.5 s (cover 0.95) |
| x -448…-440, z 152…160 | 0.182 | 65 | 6.48% at 21.2 s (cover 0.96) | 4.91% at 7.67 s (cover 0.95) |
| x -448…-440, z 144…152 | 0.091 | 61 | 6.68% at 21.13 s (cover 0.96) | 5.11% at 7.57 s (cover 0.92) |

## Lineup: beach wait W (VIs Jack stands still at the beach load before his first step)

| W (VIs) | share of routes | lines | release bite 1 | hold to bite 2 |
|---|---|---|---|---|
| 0 | 0.062 | 18 | 10.06% at 20.2 s (cover 0.81) | 5.75% at 20.93 s (cover 0.81) |
| 2 | 0.062 | 16 | 9.79% at 21.23 s (cover 0.90) | 9.74% at 7.57 s (cover 0.88) |
| 4 | 0.062 | 17 | 11.28% at 11.7 s (cover 0.98) | 7.94% at 17.3 s (cover 0.98) |
| 6 | 0.062 | 17 | 7.75% at 20.07 s (cover 0.99) | 5.41% at 3.67 s (cover 0.93) |
| 8 | 0.062 | 17 | 8.50% at 24.63 s (cover 1.00) | 7.49% at 9.8 s (cover 1.00) |
| 10 | 0.062 | 17 | 9.72% at 24.53 s (cover 1.00) | 16.78% at 9.8 s (cover 1.00) |
| 12 | 0.062 | 17 | 9.86% at 9.43 s (cover 1.00) | 11.06% at 9.83 s (cover 1.00) |
| 14 | 0.062 | 17 | 11.15% at 8.17 s (cover 1.00) | 5.88% at 27.0 s (cover 1.00) |
| 16 | 0.062 | 18 | 8.84% at 8.2 s (cover 1.00) | 6.11% at 7.23 s (cover 1.00) |
| 18 | 0.062 | 18 | 6.47% at 21.07 s (cover 1.00) | 9.09% at 7.23 s (cover 1.00) |
| 20 | 0.062 | 17 | 8.32% at 31.03 s (cover 1.00) | 9.82% at 7.2 s (cover 1.00) |
| 22 | 0.062 | 17 | 12.12% at 4.03 s (cover 1.00) | 8.25% at 20.6 s (cover 1.00) |
| 24 | 0.062 | 17 | 9.49% at 20.97 s (cover 1.00) | 6.80% at 27.57 s (cover 1.00) |
| 26 | 0.062 | 18 | 11.21% at 21.83 s (cover 0.94) | 10.04% at 20.03 s (cover 0.94) |
| 28 | 0.062 | 18 | 9.39% at 24.37 s (cover 0.93) | 6.50% at 23.1 s (cover 0.93) |
| 30 | 0.062 | 18 | 9.87% at 21.93 s (cover 0.90) | 9.90% at 23.2 s (cover 0.93) |

## Lineup: first cut D (VIs of down-right after the beach load, before the cut down-left)

D 84 = the earliest cut that clears the small wall (scrapes its corner: Jack pushed to x -451.6); D 86 = one game frame later (clears the corner: x -452.0, still the wall column of the dog's view grid).

| first cut | share of routes | lines | of them shared with the other cut | dog wakes, VI after the beach load - W (share) | release bite 1 | hold to bite 2 |
|---|---|---|---|---|---|---|
| D 84 | 0.500 | 64 | 61 | 211 (82%), 209 (9%), 207 (9%) | 5.97% at 21.07 s (cover 0.97) | 4.66% at 7.53 s (cover 0.94) |
| D 86 | 0.500 | 65 | 61 | 209 (82%), 207 (9%), 205 (9%) | 6.19% at 21.1 s (cover 0.96) | 4.61% at 7.53 s (cover 0.96) |

## Lineup: wait band x second cut (full pier width; early / middle / late = dock-end spot z ≤178 / ≤190 / >190)

| wait | 2nd cut | share of routes | lines | release bite 1 | hold to bite 2 |
|---|---|---|---|---|---|
| wait 0-9 | any | 0.312 | 32 | 7.03% at 11.7 s (cover 0.92) | 5.82% at 7.53 s (cover 0.92) |
| wait 0-9 | Early | 0.170 | 32 | 7.87% at 20.2 s (cover 0.93) | 6.42% at 7.6 s (cover 0.90) |
| wait 0-9 | Middle | 0.057 | 24 | 7.95% at 20.1 s (cover 0.95) | 6.46% at 7.5 s (cover 0.95) |
| wait 0-9 | Late | 0.085 | 24 | 7.55% at 19.97 s (cover 0.95) | 6.13% at 7.4 s (cover 0.95) |
| wait 10-19 | any | 0.312 | 33 | 7.34% at 8.17 s (cover 1.00) | 6.47% at 9.83 s (cover 1.00) |
| wait 10-19 | Early | 0.170 | 33 | 7.85% at 8.27 s (cover 1.00) | 7.23% at 9.87 s (cover 1.00) |
| wait 10-19 | Middle | 0.057 | 25 | 8.07% at 8.17 s (cover 1.00) | 6.64% at 9.8 s (cover 1.00) |
| wait 10-19 | Late | 0.085 | 25 | 7.73% at 8.03 s (cover 1.00) | 6.35% at 9.67 s (cover 1.00) |
| wait 20-30 | any | 0.375 | 36 | 8.10% at 21.9 s (cover 0.97) | 6.15% at 20.13 s (cover 0.97) |
| wait 20-30 | Early | 0.205 | 36 | 8.53% at 22.0 s (cover 0.97) | 6.52% at 20.17 s (cover 0.97) |
| wait 20-30 | Middle | 0.068 | 29 | 8.96% at 21.9 s (cover 0.96) | 6.53% at 20.07 s (cover 0.96) |
| wait 20-30 | Late | 0.102 | 29 | 8.64% at 21.77 s (cover 0.96) | 6.24% at 19.97 s (cover 0.96) |
| any wait | any | 1.000 | 68 | 6.07% at 21.07 s (cover 0.97) | 4.63% at 7.53 s (cover 0.95) |
| any wait | Early | 0.545 | 68 | 6.47% at 21.17 s (cover 0.97) | 4.93% at 7.6 s (cover 0.95) |
| any wait | Middle | 0.182 | 61 | 6.48% at 21.07 s (cover 0.97) | 4.98% at 7.53 s (cover 0.95) |
| any wait | Late | 0.273 | 61 | 6.31% at 20.93 s (cover 0.97) | 4.81% at 7.4 s (cover 0.95) |

## Menus (mash until the house loads)

| style | presses/s | held VIs | house arrival VI (count of phases) |
|---|---|---|---|
| START+A | 15.0 | 2 | 1038×2, 1040×2 |
| START+A | 12.0 | 2 | 1042×2, 1044×2, 1046×1 |
| START+A | 10.0 | 3 | 1042×2, 1044×2, 1046×2 |
| START+A | 8.6 | 3 | 1042×1, 1044×1, 1046×1, 1048×1, 1050×1, 1052×1, 1054×1 |
| START+A | 7.5 | 4 | 1038×2, 1040×2, 1042×2, 1044×2 |
| START+A | 6.7 | 4 | 1038×1, 1040×2, 1042×2, 1044×2, 1046×1, 1056×1 |
| START+A | 6.0 | 5 | 1052×2, 1054×2, 1056×2, 1058×2, 1060×2 |
| START+A | 5.5 | 5 | 1050×2, 1052×2, 1054×2, 1056×2, 1058×2, 1060×1 |
| START+A | 5.0 | 6 | 1054×2, 1056×2, 1058×2, 1060×2, 1064×2, 1074×2 |
| START>A | 15.0 | 2 | 1038×2, 1040×2 |
| START>A | 12.0 | 2 | 1042×2, 1044×2, 1046×1 |
| START>A | 10.0 | 3 | 1036×1, 1038×1, 1040×1, 1042×1, 1044×1, 1046×1 |
| START>A | 8.6 | 3 | 1042×1, 1044×2, 1046×2, 1048×2 |
| START>A | 7.5 | 4 | 1038×2, 1040×2, 1042×2, 1044×2 |
| START>A | 6.7 | 4 | 1038×1, 1040×2, 1042×2, 1044×2, 1046×1, 1056×1 |
| START>A | 6.0 | 5 | 1052×2, 1054×2, 1056×2, 1058×2, 1060×2 |
| START>A | 5.5 | 5 | 1050×2, 1052×2, 1054×2, 1056×2, 1058×2, 1060×1 |
| START>A | 5.0 | 6 | 1042×2, 1044×2, 1046×2, 1048×2, 1052×2, 1062×2 |

## House (up-left U, down-left V, down) — farm arrival, VIs after the house load: count of (U, V) runs

412:28, 414:112, 416:336, 418:357, 420:266, 422:189, 424:196, 426:147, 428:70, 430:84, 432:84, 434:63, 436:56, 438:56, 440:35, 442:7, None:462

## Crossroads (left, cut down-left at C) — ranch arrival, VIs after the farm load: count of runs

586:90, 588:72, 590:90, 592:45, 594:18, None:9

## Beach (first cut D, second cut B; VIs after the beach load)

| D | dog first moved, VIs after the beach load (count) | B reaching the dock end (total) | READY windows (B) |
|---|---|---|---|
| 84 | None×128 | 2816 | 122–143 |
| 86 | None×128 | 2816 | 118–139 |

## Dog lines: 68 (members = beach state × D × B that reach the dock end)

- casts evaluated: 44503 distinct states; repeat checks agree 203, disagree 1

| line | weight | members | beach draw | READY spread (VIs) | casts | Nut casts b1 / b2 |
|---|---|---|---|---|---|---|
| a7be2c60a7ba5a73 | 0.050 | 298 | 7883 | 44 | 1197 | 23 / 22 |
| e86f0212ec7844c7 | 0.039 | 226 | 7825 | 28 | 1197 | 35 / 12 |
| 603ee45fc655a4c4 | 0.039 | 220 | 7792 | 30 | 1197 | 18 / 18 |
| e41baaf2de19b479 | 0.039 | 220 | 7792 | 44 | 1197 | 22 / 25 |
| bb8aea2393ebefff | 0.038 | 216 | 7792 | 44 | 1197 | 24 / 25 |
| d26636742ee8364b | 0.026 | 132 | 7777 | 30 | 1197 | 24 / 8 |
| 7a521646982adab3 | 0.023 | 136 | 7792 | 38 | 1197 | 28 / 7 |
| 8208e33cc778fbd2 | 0.022 | 132 | 7825 | 22 | 1197 | 11 / 26 |
| a35a8903be66d5cb | 0.022 | 132 | 7825 | 22 | 1197 | 33 / 16 |
| c903ac2c9d124d2c | 0.022 | 132 | 7825 | 22 | 1197 | 26 / 20 |
| d239f0999986f613 | 0.022 | 132 | 7825 | 22 | 1197 | 25 / 13 |
| d24a6d33adb0edf4 | 0.022 | 132 | 7825 | 22 | 1197 | 22 / 18 |
| f886d65f3eeb899c | 0.022 | 132 | 7825 | 22 | 1197 | 24 / 18 |
| 9eb82719fe48d53f | 0.021 | 126 | 7792 | 44 | 1197 | 26 / 23 |
| fe3e083a02ec32cf | 0.020 | 114 | 7825 | 22 | 1197 | 18 / 11 |
| fd5cca9ca6f00761 | 0.019 | 120 | 7883 | 22 | 1197 | 21 / 23 |
| a8a142b344568bce | 0.019 | 106 | 7792 | 44 | 1197 | 23 / 33 |
| 3756a386facef46b | 0.017 | 88 | 7792 | 22 | 1197 | 26 / 18 |
| 6f3d4943f09c1c67 | 0.017 | 88 | 7792 | 22 | 1197 | 26 / 12 |
| bd678ac4335aa691 | 0.017 | 88 | 7792 | 22 | 1197 | 44 / 13 |
| c97e6b4569fd67bc | 0.017 | 88 | 7792 | 22 | 1197 | 25 / 20 |
| eb3ca5c9a71f7a4b | 0.017 | 88 | 7792 | 22 | 1197 | 48 / 13 |
| ec5f2f82133124e8 | 0.017 | 88 | 7792 | 22 | 1197 | 29 / 9 |
| a85d9b5491f92ab8 | 0.016 | 84 | 7792 | 22 | 1197 | 29 / 8 |
| 84c149a6ae3609c5 | 0.016 | 96 | 7858 | 22 | 1197 | 19 / 14 |
| c79a21e1ac160480 | 0.015 | 76 | 7792 | 22 | 1197 | 26 / 18 |
| 63371f3f38fee585 | 0.014 | 88 | 7858 | 22 | 1197 | 29 / 4 |
| a1582afcd029f533 | 0.014 | 88 | 7858 | 22 | 1197 | 32 / 17 |
| b91fdf67f71b2f79 | 0.014 | 88 | 7858 | 22 | 1197 | 33 / 20 |
| d17cf202b07218d4 | 0.014 | 88 | 7858 | 22 | 1197 | 17 / 14 |
| d76797e0381c5b50 | 0.014 | 88 | 7858 | 22 | 1197 | 28 / 18 |
| 789a1749292c0f73 | 0.014 | 88 | 7858 | 22 | 1197 | 35 / 16 |
| a156e53f0e4dcd0b | 0.014 | 88 | 7858 | 22 | 1197 | 27 / 18 |
| a7804eba78a64a48 | 0.014 | 88 | 7858 | 22 | 1197 | 26 / 16 |
| bdbe5d5b1bc63e98 | 0.014 | 88 | 7858 | 22 | 1197 | 11 / 26 |
| e0c59092e2f67dc9 | 0.014 | 88 | 7858 | 22 | 1197 | 28 / 17 |
| e33c153700b91d36 | 0.014 | 88 | 7858 | 22 | 1197 | 35 / 25 |
| e9c21afc237b298e | 0.014 | 88 | 7858 | 22 | 1197 | 24 / 11 |
| 4ea39f2278c0dca6 | 0.014 | 84 | 7858 | 22 | 1197 | 17 / 17 |
| a49a313415ca852a | 0.012 | 76 | 7858 | 22 | 1197 | 31 / 15 |

## Lucky Timer, whole pool (aim = time after READY at the dock end; cast spread 1 s.d.)

| spread | release bite 1 | hold to bite 2 | either (smart, upper bound) | coverage at best |
|---|---|---|---|---|
| 0 ms | 7.0% at 21.13 s | 6.3% at 7.57 s | 10.0% at 27.63 s | 0.967 |
| 100 ms | 6.4% at 21.1 s | 5.0% at 7.57 s | 9.3% at 27.67 s | 0.967 |
| 150 ms | 6.1% at 21.07 s | 4.6% at 7.53 s | 9.0% at 27.7 s | 0.967 |
| 250 ms | 5.6% at 21.07 s | 4.5% at 7.43 s | 8.4% at 27.7 s | 0.967 |

- **Member recast check** (casts from members' own routes vs the shared line table): agree 593, disagree 17, no table entry 0

  - ['e86f0212ec7844c7', '50a211c74266a0a3@w2', 84, 141, 894, [1668, False, 1748, False], [1672, False, 1752, False]]
  - ['e86f0212ec7844c7', 'b7fad837697959ef@w8', 86, 125, 438, [1056, False, 1628, False], [1628, False, 1708, False]]
  - ['603ee45fc655a4c4', 'f0d08f01d42d02d7@w20', 86, 131, 1102, [1406, False, 2346, False], [1406, False, 2652, False]]
  - ['9eb82719fe48d53f', 'e1f3d7880c14305a@w14', 86, 134, 224, [860, False, 1332, False], [324, False, 1670, False]]
  - ['fd5cca9ca6f00761', '50a211c74266a0a3@w26', 86, 136, 944, [1648, False, 1728, False], [1644, False, 1724, False]]
  - ['fd5cca9ca6f00761', '50a211c74266a0a3@w26', 86, 131, 518, [1680, False, 2286, False], [2286, False, 3098, False]]
  - ['fd5cca9ca6f00761', 'b7fad837697959ef@w28', 84, 138, 398, [752, False, 2276, False], [752, False, 3224, False]]
  - ['fd5cca9ca6f00761', 'b7fad837697959ef@w28', 84, 138, 1054, [1660, False, 1740, False], [1394, False, 1656, False]]
  - ['fd5cca9ca6f00761', 'b7fad837697959ef@w28', 84, 138, 1078, [1660, False, 1740, False], [1394, False, 2000, False]]
  - ['603ee45fc655a4c4', '50a211c74266a0a3@w20', 84, 130, 2236, [3262, False, 3406, False], [3258, False, 4434, False]]
  - ['603ee45fc655a4c4', 'f0d08f01d42d02d7@w18', 84, 132, 1770, [3210, False, 3354, False], [3368, False, 3788, False]]
  - ['603ee45fc655a4c4', 'e1f3d7880c14305a@w20', 86, 138, 1714, [1864, False, 2420, False], [1864, False, 2450, False]]
  - ['603ee45fc655a4c4', 'e1f3d7880c14305a@w20', 86, 138, 2352, [4534, False, 4688, False], [3852, False, 5968, False]]
  - ['e86f0212ec7844c7', 'b7fad837697959ef@w0', 84, 132, 2232, [2688, False, 2776, False], [2780, False, 3286, False]]
  - ['63371f3f38fee585', 'bbafeb6b9c3b737d@w16', 86, 137, 1414, [3186, False, 3330, False], [2536, False, 3190, False]]
  - ['63371f3f38fee585', 'bbafeb6b9c3b737d@w14', 84, 136, 1274, [1824, False, 4346, False], [1824, False, 4102, False]]
  - ['a156e53f0e4dcd0b', '275dd83687282c0d@w8', 86, 130, 2082, [3208, False, 5682, False], [3208, False, 7006, False]]
## Repeat-cast disagreements (shared states gave different results)

- ['db29fd26073262c8', (372, False, 1908, False), (376, False, 648, False), 'v0:8cb7de3eb45242d4:216']

