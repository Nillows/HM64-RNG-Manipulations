# Dog-watch report: married-horse-lineup2-rainy-8cbe43a5

68 dog lines with traces (40 s after READY), 613 (line, READY offset) variants; route-weighted. Clock = the dock-end tap ±3 VI; logs from 1.0 s after READY; runner: changes >= 12 VI, reaction 10-25 VI, 15% missed. Odds: cast >= 2 s after the window, ±150 ms.

## What the dog does while you wait (after READY, route-weighted)

- dog's tile on the visibility grid (it animates only then): 99% of the time
- visible changes per minute: 61; changes lasting >= 12 VI: 88%
- facing on screen (share of the wait): SW 40%, NE 17%, SE 14%, W 9%, NW 9%, E 6%, N 5%; animations readable (dog faces S / N / NE / E / SE): 42%
- the dog moves (units, max over the trace): median 0.0
- decision (actionState change) -> next visible change: median 0 VI (p10 0, p90 30); animation set -> displayed: median 0 VI

## Telling the lines apart (simulated runners)

| logging | window | right line on top | posterior on it | >= 90% sure | lines left | logs | Nut (no logs -> logs) | known line |
|---|---|---|---|---|---|---|---|---|
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 3 s | 33% | 28% | 18% | 34.5 | 0.3 | 4.9% -> 14.6% | 40.1% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 5 s | 50% | 45% | 40% | 29.8 | 0.8 | 6.4% -> 20.6% | 41.0% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 10 s | 52% | 48% | 43% | 28.6 | 1.5 | 7.0% -> 20.8% | 38.0% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 15 s | 68% | 63% | 56% | 19.6 | 2.5 | 6.2% -> 25.3% | 37.6% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 20 s | 74% | 68% | 61% | 17.6 | 3.4 | 4.7% -> 21.8% | 31.3% |
| gear, arrows only (no arrow = same facing) | 3 s | 20% | 15% | 4% | 35.9 | 0.1 | 6.1% -> 11.0% | 40.8% |
| gear, arrows only (no arrow = same facing) | 5 s | 32% | 28% | 18% | 31.5 | 0.2 | 6.2% -> 15.7% | 42.1% |
| gear, arrows only (no arrow = same facing) | 10 s | 36% | 30% | 18% | 29.2 | 0.3 | 6.9% -> 16.1% | 37.4% |
| gear, arrows only (no arrow = same facing) | 15 s | 47% | 44% | 31% | 22.0 | 0.5 | 4.7% -> 17.9% | 36.0% |
| gear, arrows only (no arrow = same facing) | 20 s | 68% | 63% | 50% | 15.5 | 1.1 | 4.3% -> 20.0% | 29.4% |
| your logging (arrows always, letters for long animations facing S/N/E) | 3 s | 38% | 32% | 20% | 41.8 | 0.5 | 5.6% -> 16.3% | 41.6% |
| your logging (arrows always, letters for long animations facing S/N/E) | 5 s | 46% | 43% | 38% | 38.1 | 0.8 | 4.9% -> 19.1% | 40.3% |
| your logging (arrows always, letters for long animations facing S/N/E) | 10 s | 53% | 48% | 42% | 34.7 | 1.6 | 5.5% -> 20.0% | 37.2% |
| your logging (arrows always, letters for long animations facing S/N/E) | 15 s | 63% | 58% | 51% | 25.8 | 2.3 | 5.9% -> 23.0% | 36.0% |
| your logging (arrows always, letters for long animations facing S/N/E) | 20 s | 73% | 67% | 58% | 19.9 | 3.8 | 5.1% -> 21.1% | 30.6% |
| arrows only (facing track + durations) | 3 s | 17% | 12% | 7% | 59.0 | 0.1 | 4.9% -> 8.9% | 41.3% |
| arrows only (facing track + durations) | 5 s | 22% | 17% | 13% | 55.8 | 0.2 | 6.8% -> 11.8% | 40.7% |
| arrows only (facing track + durations) | 10 s | 26% | 21% | 14% | 52.7 | 0.2 | 5.0% -> 11.6% | 37.4% |
| arrows only (facing track + durations) | 15 s | 44% | 38% | 28% | 39.4 | 0.5 | 4.8% -> 15.3% | 35.5% |
| arrows only (facing track + durations) | 20 s | 56% | 50% | 41% | 30.3 | 0.9 | 4.4% -> 18.0% | 31.9% |
| every change, letter + arrow | 3 s | 65% | 62% | 44% | 11.2 | 1.4 | 6.0% -> 29.9% | 41.1% |
| every change, letter + arrow | 5 s | 90% | 89% | 80% | 1.8 | 3.1 | 5.3% -> 37.1% | 40.5% |
| every change, letter + arrow | 10 s | 94% | 94% | 88% | 1.1 | 6.6 | 6.2% -> 36.0% | 37.6% |
| every change, letter + arrow | 15 s | 94% | 94% | 86% | 1.5 | 10.4 | 7.2% -> 35.9% | 37.4% |
| every change, letter + arrow | 20 s | 97% | 95% | 88% | 1.3 | 14.5 | 4.2% -> 30.3% | 31.4% |
| every animation change, letter only | 3 s | 68% | 66% | 50% | 9.2 | 1.4 | 5.3% -> 30.5% | 41.0% |
| every animation change, letter only | 5 s | 89% | 89% | 80% | 1.6 | 3.1 | 4.4% -> 36.2% | 39.9% |
| every animation change, letter only | 10 s | 96% | 95% | 89% | 1.1 | 6.6 | 5.6% -> 35.1% | 36.8% |
| every animation change, letter only | 15 s | 96% | 95% | 89% | 1.3 | 10.3 | 5.9% -> 34.2% | 35.4% |
| every animation change, letter only | 20 s | 95% | 94% | 89% | 1.3 | 14.1 | 4.2% -> 29.9% | 31.1% |
| Space at every change | 3 s | 16% | 9% | 0% | 34.1 | 1.4 | 5.1% -> 8.4% | 41.5% |
| Space at every change | 5 s | 40% | 28% | 6% | 13.8 | 3.1 | 5.6% -> 19.3% | 40.7% |
| Space at every change | 10 s | 87% | 81% | 61% | 2.1 | 6.7 | 7.1% -> 34.6% | 39.1% |
| Space at every change | 15 s | 94% | 92% | 82% | 1.2 | 10.5 | 7.0% -> 34.7% | 36.3% |
| Space at every change | 20 s | 95% | 94% | 88% | 1.1 | 14.3 | 4.7% -> 30.2% | 31.4% |

Readability: *your logging* follows Thomas's TV check (facing always readable; animations only while the dog
faces S, N, NE, E or SE, and only animations lasting >= 1 s are logged). The other rows are for comparison.

## Duds before the cast (reset early)

Dud = the best cast for what your logs leave is under the threshold; you reset instead of casting. Odds per attempt; 'kept' = attempts you cast.

| logging | window | threshold | attempts called dud | Nut on kept attempts | Nut the resets threw away | all-cast Nut |
|---|---|---|---|---|---|---|
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 3 s | 5% | 0% | 14.6% | 0.00 pts | 14.6% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 3 s | 8% | 60% | 29.3% | 3.09 pts | 14.6% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 5 s | 5% | 0% | 20.6% | 0.00 pts | 20.6% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 5 s | 8% | 53% | 35.9% | 3.82 pts | 20.6% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 10 s | 5% | 0% | 20.8% | 0.00 pts | 20.8% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 10 s | 8% | 51% | 37.3% | 2.49 pts | 20.8% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 15 s | 5% | 1% | 25.5% | 0.00 pts | 25.3% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 15 s | 8% | 35% | 35.6% | 2.29 pts | 25.3% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 20 s | 5% | 3% | 22.5% | 0.00 pts | 21.8% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 20 s | 8% | 33% | 29.7% | 2.04 pts | 21.8% |
| gear, arrows only (no arrow = same facing) | 3 s | 5% | 0% | 11.0% | 0.00 pts | 11.0% |
| gear, arrows only (no arrow = same facing) | 3 s | 8% | 61% | 20.3% | 3.15 pts | 11.0% |
| gear, arrows only (no arrow = same facing) | 5 s | 5% | 0% | 15.7% | 0.00 pts | 15.7% |
| gear, arrows only (no arrow = same facing) | 5 s | 8% | 54% | 26.5% | 3.45 pts | 15.7% |
| gear, arrows only (no arrow = same facing) | 10 s | 5% | 0% | 16.1% | 0.00 pts | 16.1% |
| gear, arrows only (no arrow = same facing) | 10 s | 8% | 49% | 26.9% | 2.45 pts | 16.1% |
| gear, arrows only (no arrow = same facing) | 15 s | 5% | 0% | 18.0% | 0.00 pts | 17.9% |
| gear, arrows only (no arrow = same facing) | 15 s | 8% | 38% | 25.9% | 1.72 pts | 17.9% |
| gear, arrows only (no arrow = same facing) | 20 s | 5% | 4% | 20.7% | 0.00 pts | 20.0% |
| gear, arrows only (no arrow = same facing) | 20 s | 8% | 28% | 26.0% | 1.35 pts | 20.0% |

### Early dud signs, your logging, 10 s window, dud = best cast under 5%

2% of attempts are duds at this threshold (if the line were known). A sign = what you log in a 1-s slot after READY; seen = share of attempts showing it; dud share = how many of those are duds.

| you log | seconds after READY | seen | dud share |
|---|---|---|---|
| numpad 2 stand | 4-5 | 8.8% | 0% |
| numpad 2 stand | 7-8 | 7.0% | 0% |
| numpad 9 shoulder | 4-5 | 6.8% | 0% |
| numpad 7 sniff | 1-2 | 5.6% | 0% |
| numpad 3 rollover | 6-7 | 5.6% | 0% |
| numpad 0 idle | 3-4 | 5.5% | 0% |
| numpad 2 stand | 5-6 | 4.9% | 0% |
| numpad 3 rollover | 7-8 | 4.6% | 0% |
| numpad 8 bark | 1-2 | 4.5% | 0% |
| numpad 2 stand | 6-7 | 4.3% | 0% |
| numpad 2 stand | 9-10 | 4.3% | 0% |
| numpad 2 stand | 3-4 | 4.2% | 0% |
| numpad 0 idle | 9-10 | 3.9% | 0% |
| numpad 0 idle | 1-2 | 3.9% | 0% |
| numpad 8 bark | 3-4 | 3.9% | 0% |
| numpad 3 rollover | 9-10 | 3.9% | 0% |
| numpad 7 sniff | 3-4 | 3.9% | 0% |
| numpad 1 sit | 9-10 | 3.7% | 0% |
| faces NW | 1-2 | 3.6% | 0% |
| faces SW | 7-8 | 3.6% | 0% |

### Early dud signs, your logging, 10 s window, dud = best cast under 8%

2% of attempts are duds at this threshold (if the line were known). A sign = what you log in a 1-s slot after READY; seen = share of attempts showing it; dud share = how many of those are duds.

| you log | seconds after READY | seen | dud share |
|---|---|---|---|
| numpad 2 stand | 4-5 | 8.8% | 0% |
| numpad 2 stand | 7-8 | 7.0% | 0% |
| numpad 9 shoulder | 4-5 | 6.8% | 0% |
| numpad 7 sniff | 1-2 | 5.6% | 0% |
| numpad 3 rollover | 6-7 | 5.6% | 0% |
| numpad 0 idle | 3-4 | 5.5% | 0% |
| numpad 2 stand | 5-6 | 4.9% | 0% |
| numpad 3 rollover | 7-8 | 4.6% | 0% |
| numpad 8 bark | 1-2 | 4.5% | 0% |
| numpad 2 stand | 6-7 | 4.3% | 0% |
| numpad 2 stand | 9-10 | 4.3% | 0% |
| numpad 2 stand | 3-4 | 4.2% | 0% |
| numpad 0 idle | 9-10 | 3.9% | 0% |
| numpad 0 idle | 1-2 | 3.9% | 0% |
| numpad 8 bark | 3-4 | 3.9% | 0% |
| numpad 3 rollover | 9-10 | 3.9% | 0% |
| numpad 7 sniff | 3-4 | 3.9% | 0% |
| numpad 1 sit | 9-10 | 3.7% | 0% |
| faces NW | 1-2 | 3.6% | 0% |
| faces SW | 7-8 | 3.6% | 0% |
