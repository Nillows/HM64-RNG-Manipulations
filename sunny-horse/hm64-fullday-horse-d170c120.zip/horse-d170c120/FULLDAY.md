# HM64 full-day lab — the cast table and the dog to the end of the game day

## 1. The day without a cast (every dog line, stay-awake push every 33 s)

- 156 lines ran of 156; dog at READY: [-196.91, 222.09]
- Clock at READY: 06:48 – 06:52. Followed to 10198 VIs = 170 s after READY (the limit).
- Same paths as the dog-watch run? cast hashes of the first 33 s: **155220 equal, 0 different**.
- Ended by something else than the limit / the end of the day: 0
- The dog's visible changes over that time: 171 per line.
- **The dog leaves its spot** (moved 4 units or more) on 125 of 156 lines; earliest 1 s after READY, median 101 s.
- Its tile leaves the visibility grid (not on screen, not animating) on 13 lines.

## 2. Cast blocks (every cast held to the limit, or the end of the day)

| block | cast frames (s after READY) | lines | casts planned | done | job errors | hash check ok / failed / none | ended: as planned / beach check / other | bites per cast | casts with a Nut on some bite |
|---|---|---|---|---|---|---|---|---|---|
| 4 | 80.2 – 120.3 · heavy | 69 | 12870 | 12870 | 0 | 11421 / 0 / 1449 | 12870 / 0 / 0 | 4.8 | 4 (0.0%) |
| 5 | 80.2 – 120.3 · other | 87 | 5607 | 5607 | 0 | 3780 / 0 / 1827 | 5607 / 0 / 0 | 4.9 | 2 (0.0%) |

Blocks not started: 4 (69032 casts). Data so far: 17.4 MB.

## 3. The beach check

- 18477 casts: **18477 ran to the limit / the end of the day on the beach at the dock end**, 0 were stopped by the beach check, 0 ended another way.
- Cast hash = the dog-watch run's state at that frame: 15201 equal, **0 different**, 3276 not compared (cast frames inside a stay-awake push).

## 4. Bites and Nuts by game hour (on the held casts)

- 88989 bites; released 4 polls after the bite: l 35387, s 33220, m 20376, N 6 (N Nut, s / m / l fish size, d the day ended before the catch, x miss, h held through, o other; a / b = the two release probes differ).
- The two release probes of bites 1-2 gave different catches on 0 bites.
- Nut by bite number: bite 4: 2, bite 5+: 4.

| game hour | bites | Nut bites | Nut share |
|---|---|---|---|
| 13:00 | 263 | 0 | 0.00% |
| 14:00 | 2515 | 0 | 0.00% |
| 15:00 | 5194 | 0 | 0.00% |
| 16:00 | 8768 | 0 | 0.00% |
| 17:00 | 19986 | 0 | 0.00% |
| 18:00 | 21819 | 0 | 0.00% |
| 19:00 | 16229 | 4 | 0.02% |
| 20:00 | 13962 | 2 | 0.01% |
| 21:00 | 95 | 0 | 0.00% |
| 22:00 | 106 | 0 | 0.00% |
| 23:00 | 52 | 0 | 0.00% |

These are bites of casts HELD since the cast frame, not fresh casts at that hour: a later hour is
reached only by holding through every earlier bite.

## 5. Do the held casts run into each other?

- 88989 bite states, 6428 distinct (92.8% shared): a shared state has the same future, so its later bites need not be simulated twice.

## 6. The dog after the cast

- Visible changes recorded from the cast to the end of its run: 68 per cast; on the released paths (the 4 s after each bite): 4.8 per bite.
- The dog leaves its spot at some point of the run in 15573 of 18477 casts (84%).

## 7. Against the dog-watch run's cast table (same state hash)

- 0 casts are in both: bite times and Nut flags **equal in 0, different in 0**.

