# HM64 full-day lab — the cast table and the dog to the end of the game day

## 1. The day without a cast (every dog line, stay-awake push every 33 s)

- 156 lines ran of 156; dog at READY: [-196.91, 222.09]
- Clock at READY: 06:48 – 06:52. Followed to 5398 VIs = 90 s after READY (the limit).
- Same paths as the dog-watch run? cast hashes of the first 33 s: **155220 equal, 0 different**.
- Ended by something else than the limit / the end of the day: 0
- The dog's visible changes over that time: 92 per line.
- **The dog leaves its spot** (moved 4 units or more) on 29 of 156 lines; earliest 1 s after READY, median 11 s.
- Its tile leaves the visibility grid (not on screen, not animating) on 6 lines.

## 2. Cast blocks (every cast held to the limit, or the end of the day)

| block | cast frames (s after READY) | lines | casts planned | done | job errors | hash check ok / failed / none | ended: as planned / beach check / other | bites per cast | casts with a Nut on some bite |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 0.1 – 40.1 · heavy | 69 | 32059 | 32059 | 0 | 30610 / 0 / 1449 | 32059 / 0 / 0 | 4.7 | 2079 (6.5%) |
| 1 | 0.1 – 40.1 · other | 87 | 14695 | 14695 | 0 | 12868 / 0 / 1827 | 14695 / 0 / 0 | 4.8 | 864 (5.9%) |

Blocks not started: 0 (0 casts). Data so far: 46.9 MB.

## 3. The beach check

- 46754 casts: **46754 ran to the limit / the end of the day on the beach at the dock end**, 0 were stopped by the beach check, 0 ended another way.
- Cast hash = the dog-watch run's state at that frame: 43478 equal, **0 different**, 3276 not compared (cast frames inside a stay-awake push).

## 4. Bites and Nuts by game hour (on the held casts)

- 220743 bites; released 4 polls after the bite: s 96571, l 75115, m 46114, N 2943 (N Nut, s / m / l fish size, d the day ended before the catch, x miss, h held through, o other; a / b = the two release probes differ).
- The two release probes of bites 1-2 gave different catches on 0 bites.
- Nut by bite number: bite 1: 1579, bite 2: 1149, bite 3: 215.

| game hour | bites | Nut bites | Nut share |
|---|---|---|---|
| 08:00 | 23033 | 0 | 0.00% |
| 09:00 | 31518 | 1550 | 4.92% |
| 10:00 | 28485 | 1258 | 4.42% |
| 11:00 | 20199 | 135 | 0.67% |
| 12:00 | 38404 | 0 | 0.00% |
| 13:00 | 57998 | 0 | 0.00% |
| 14:00 | 20833 | 0 | 0.00% |
| 15:00 | 270 | 0 | 0.00% |
| 16:00 | 3 | 0 | 0.00% |

These are bites of casts HELD since the cast frame, not fresh casts at that hour: a later hour is
reached only by holding through every earlier bite.

## 5. Do the held casts run into each other?

- 220743 bite states, 6231 distinct (97.2% shared): a shared state has the same future, so its later bites need not be simulated twice.

## 6. The dog after the cast

- Visible changes recorded from the cast to the end of its run: 77 per cast; on the released paths (the 4 s after each bite): 5.3 per bite.
- The dog leaves its spot at some point of the run in 32838 of 46754 casts (70%).

## 7. Against the dog-watch run's cast table (same state hash)

- 30656 casts are in both: bite times and Nut flags **equal in 30649, different in 7**.
  - ('2462315b', 2058, [(928, False), (1306, False), (1986, False)], [(928, False), (1306, False), (1986, False)])
  - ('63f73cf6', 2050, [(208, False), (644, False), (1308, False)], [(208, False), (644, False), (1308, False)])
  - ('8a889937', 2044, [(934, False), (1682, False), (2522, False)], [(934, False), (1682, False), (2522, False)])
  - ('8a889937', 2048, [(910, False), (1646, False), (2502, False)], [(910, False), (1646, False), (2502, False)])
  - ('8a889937', 2050, [(368, False), (1672, False), (2512, False)], [(368, False), (1672, False), (2512, False)])

