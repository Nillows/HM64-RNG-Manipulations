# HM64 full-day lab — the cast table and the dog to the end of the game day

## 1. The day without a cast (every dog line, stay-awake push every 33 s)

- 156 lines ran of 156; dog at READY: [-196.91, 222.09]
- Clock at READY: 06:48 – 06:52. Followed to 8398 VIs = 140 s after READY (the limit).
- Same paths as the dog-watch run? cast hashes of the first 33 s: **155220 equal, 0 different**.
- Ended by something else than the limit / the end of the day: 0
- The dog's visible changes over that time: 144 per line.
- **The dog leaves its spot** (moved 4 units or more) on 125 of 156 lines; earliest 1 s after READY, median 101 s.
- Its tile leaves the visibility grid (not on screen, not animating) on 13 lines.

## 2. Cast blocks (every cast held to the limit, or the end of the day)

| block | cast frames (s after READY) | lines | casts planned | done | job errors | hash check ok / failed / none | ended: as planned / beach check / other | bites per cast | casts with a Nut on some bite |
|---|---|---|---|---|---|---|---|---|---|
| 2 | 40.1 – 80.2 · heavy | 69 | 15756 | 15756 | 0 | 14307 / 0 / 1449 | 15756 / 0 / 0 | 5.3 | 626 (4.0%) |
| 3 | 40.1 – 80.2 · other | 87 | 6522 | 6522 | 0 | 4695 / 0 / 1827 | 6522 / 0 / 0 | 5.2 | 168 (2.6%) |
| 4 | 80.2 – 90.3 · heavy | 21 | 2920 | 2920 | 0 | 2920 / 0 / 0 | 2920 / 0 / 0 | 3.9 | 0 (0.0%) |
| 5 | 80.2 – 90.3 · other | 10 | 980 | 980 | 0 | 980 / 0 / 0 | 980 / 0 / 0 | 3.9 | 0 (0.0%) |

Blocks not started: 2 (46754 casts). Data so far: 25.9 MB.

## 3. The beach check

- 26178 casts: **26178 ran to the limit / the end of the day on the beach at the dock end**, 0 were stopped by the beach check, 0 ended another way.
- Cast hash = the dog-watch run's state at that frame: 22902 equal, **0 different**, 3276 not compared (cast frames inside a stay-awake push).

## 4. Bites and Nuts by game hour (on the held casts)

- 133090 bites; released 4 polls after the bite: s 53539, l 46431, m 32326, N 794 (N Nut, s / m / l fish size, d the day ended before the catch, x miss, h held through, o other; a / b = the two release probes differ).
- The two release probes of bites 1-2 gave different catches on 0 bites.
- Nut by bite number: bite 1: 655, bite 2: 128, bite 3: 11.

| game hour | bites | Nut bites | Nut share |
|---|---|---|---|
| 10:00 | 1807 | 0 | 0.00% |
| 11:00 | 5323 | 315 | 5.92% |
| 12:00 | 9246 | 476 | 5.15% |
| 13:00 | 10087 | 3 | 0.03% |
| 14:00 | 15453 | 0 | 0.00% |
| 15:00 | 25020 | 0 | 0.00% |
| 16:00 | 32988 | 0 | 0.00% |
| 17:00 | 24143 | 0 | 0.00% |
| 18:00 | 8944 | 0 | 0.00% |
| 19:00 | 78 | 0 | 0.00% |
| 22:00 | 1 | 0 | 0.00% |

These are bites of casts HELD since the cast frame, not fresh casts at that hour: a later hour is
reached only by holding through every earlier bite.

## 5. Do the held casts run into each other?

- 133090 bite states, 7503 distinct (94.4% shared): a shared state has the same future, so its later bites need not be simulated twice.

## 6. The dog after the cast

- Visible changes recorded from the cast to the end of its run: 73 per cast; on the released paths (the 4 s after each bite): 4.9 per bite.
- The dog leaves its spot at some point of the run in 21144 of 26178 casts (81%).

## 7. Against the dog-watch run's cast table (same state hash)

- 0 casts are in both: bite times and Nut flags **equal in 0, different in 0**.

