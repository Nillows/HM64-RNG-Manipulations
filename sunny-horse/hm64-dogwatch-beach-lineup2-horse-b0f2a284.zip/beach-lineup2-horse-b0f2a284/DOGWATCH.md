# Dog-watch report: beach-lineup2-horse-b0f2a284

156 dog lines with traces (40 s after READY), 1952 (line, READY offset) variants; route-weighted. Clock = the dock-end tap ±3 VI; logs from 1.0 s after READY; runner: changes >= 12 VI, reaction 10-25 VI, 15% missed. Odds: cast >= 2 s after the window, ±150 ms.

## What the dog does while you wait (after READY, route-weighted)

- dog's tile on the visibility grid (it animates only then): 100% of the time
- visible changes per minute: 60; changes lasting >= 12 VI: 90%
- facing on screen (share of the wait): SW 37%, NE 15%, SE 15%, E 14%, N 10%, NW 7%, W 2%; animations readable (dog faces S / N / NE / E / SE): 54%
- the dog moves (units, max over the trace): median 0.0
- decision (actionState change) -> next visible change: median 0 VI (p10 0, p90 30); animation set -> displayed: median 0 VI

## Telling the lines apart (simulated runners)

| logging | window | right line on top | posterior on it | >= 90% sure | lines left | logs | Nut (no logs -> logs) | known line |
|---|---|---|---|---|---|---|---|---|
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 3 s | 32% | 25% | 12% | 57.5 | 0.2 | 6.9% -> 11.2% | 22.8% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 5 s | 35% | 27% | 13% | 57.0 | 0.4 | 6.3% -> 10.9% | 21.7% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 10 s | 52% | 44% | 25% | 38.7 | 1.6 | 6.5% -> 14.7% | 21.4% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 15 s | 65% | 54% | 30% | 30.6 | 2.7 | 6.5% -> 16.3% | 20.6% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 20 s | 71% | 60% | 33% | 25.7 | 4.3 | 7.0% -> 17.4% | 20.4% |
| gear, arrows only (no arrow = same facing) | 3 s | 27% | 18% | 6% | 60.9 | 0.0 | 6.4% -> 10.3% | 22.8% |
| gear, arrows only (no arrow = same facing) | 5 s | 27% | 18% | 7% | 62.0 | 0.0 | 6.6% -> 10.3% | 22.7% |
| gear, arrows only (no arrow = same facing) | 10 s | 48% | 38% | 14% | 42.4 | 0.3 | 7.0% -> 13.6% | 21.3% |
| gear, arrows only (no arrow = same facing) | 15 s | 62% | 50% | 28% | 32.6 | 0.8 | 6.7% -> 16.5% | 21.6% |
| gear, arrows only (no arrow = same facing) | 20 s | 63% | 53% | 29% | 29.3 | 1.3 | 6.5% -> 16.0% | 20.3% |
| your logging (arrows always, letters for long animations facing S/N/E) | 3 s | 24% | 13% | 2% | 128.1 | 0.2 | 6.4% -> 8.3% | 22.6% |
| your logging (arrows always, letters for long animations facing S/N/E) | 5 s | 32% | 22% | 9% | 113.6 | 0.5 | 6.8% -> 10.1% | 22.4% |
| your logging (arrows always, letters for long animations facing S/N/E) | 10 s | 46% | 33% | 10% | 83.5 | 1.5 | 6.2% -> 11.4% | 21.6% |
| your logging (arrows always, letters for long animations facing S/N/E) | 15 s | 54% | 41% | 22% | 67.3 | 2.9 | 6.1% -> 12.5% | 20.7% |
| your logging (arrows always, letters for long animations facing S/N/E) | 20 s | 59% | 47% | 24% | 50.3 | 4.7 | 6.6% -> 16.4% | 20.1% |
| arrows only (facing track + durations) | 3 s | 10% | 6% | 1% | 151.4 | 0.0 | 6.6% -> 6.9% | 22.5% |
| arrows only (facing track + durations) | 5 s | 11% | 6% | 0% | 149.9 | 0.0 | 6.6% -> 6.9% | 22.2% |
| arrows only (facing track + durations) | 10 s | 22% | 17% | 5% | 114.0 | 0.3 | 6.2% -> 9.1% | 22.0% |
| arrows only (facing track + durations) | 15 s | 36% | 25% | 8% | 90.8 | 0.7 | 6.4% -> 11.2% | 19.8% |
| arrows only (facing track + durations) | 20 s | 44% | 32% | 13% | 76.8 | 1.1 | 7.0% -> 14.3% | 20.1% |
| every change, letter + arrow | 3 s | 69% | 56% | 31% | 33.5 | 1.2 | 6.2% -> 16.7% | 22.6% |
| every change, letter + arrow | 5 s | 86% | 81% | 66% | 6.5 | 2.5 | 6.6% -> 21.0% | 22.7% |
| every change, letter + arrow | 10 s | 90% | 88% | 76% | 1.8 | 6.4 | 6.0% -> 20.6% | 21.3% |
| every change, letter + arrow | 15 s | 92% | 88% | 77% | 1.8 | 10.6 | 6.7% -> 20.1% | 20.9% |
| every change, letter + arrow | 20 s | 89% | 87% | 76% | 1.9 | 14.1 | 5.5% -> 19.2% | 19.9% |
| every animation change, letter only | 3 s | 67% | 56% | 36% | 37.6 | 1.2 | 6.4% -> 16.4% | 22.7% |
| every animation change, letter only | 5 s | 87% | 84% | 70% | 5.4 | 2.4 | 6.8% -> 20.7% | 22.3% |
| every animation change, letter only | 10 s | 91% | 88% | 77% | 2.6 | 6.2 | 6.8% -> 21.3% | 22.1% |
| every animation change, letter only | 15 s | 90% | 87% | 74% | 1.8 | 10.0 | 6.7% -> 20.0% | 20.5% |
| every animation change, letter only | 20 s | 92% | 89% | 75% | 1.6 | 13.6 | 6.2% -> 19.9% | 20.5% |
| Space at every change | 3 s | 30% | 9% | 0% | 91.0 | 1.2 | 5.8% -> 9.6% | 22.7% |
| Space at every change | 5 s | 48% | 23% | 2% | 45.4 | 2.5 | 6.6% -> 13.8% | 22.4% |
| Space at every change | 10 s | 78% | 64% | 34% | 8.0 | 6.4 | 6.9% -> 19.9% | 21.9% |
| Space at every change | 15 s | 85% | 78% | 58% | 3.4 | 10.5 | 6.5% -> 20.1% | 20.8% |
| Space at every change | 20 s | 86% | 78% | 56% | 3.3 | 14.1 | 7.1% -> 19.6% | 20.3% |

Readability: *your logging* follows Thomas's TV check (facing always readable; animations only while the dog
faces S, N, NE, E or SE, and only animations lasting >= 1 s are logged). The other rows are for comparison.

## Duds before the cast (reset early)

Dud = the best cast for what your logs leave is under the threshold; you reset instead of casting. Odds per attempt; 'kept' = attempts you cast.

| logging | window | threshold | attempts called dud | Nut on kept attempts | Nut the resets threw away | all-cast Nut |
|---|---|---|---|---|---|---|
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 3 s | 5% | 0% | 11.3% | 0.00 pts | 11.2% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 3 s | 8% | 0% | 11.3% | 0.00 pts | 11.2% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 5 s | 5% | 1% | 11.0% | 0.00 pts | 10.9% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 5 s | 8% | 1% | 11.0% | 0.00 pts | 10.9% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 10 s | 5% | 2% | 15.0% | 0.00 pts | 14.7% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 10 s | 8% | 2% | 15.0% | 0.00 pts | 14.7% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 15 s | 5% | 1% | 16.4% | 0.00 pts | 16.3% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 15 s | 8% | 1% | 16.4% | 0.00 pts | 16.3% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 20 s | 5% | 1% | 17.6% | 0.00 pts | 17.4% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 20 s | 8% | 4% | 17.9% | 0.29 pts | 17.4% |
| gear, arrows only (no arrow = same facing) | 3 s | 5% | 0% | 10.3% | 0.00 pts | 10.3% |
| gear, arrows only (no arrow = same facing) | 3 s | 8% | 0% | 10.3% | 0.00 pts | 10.3% |
| gear, arrows only (no arrow = same facing) | 5 s | 5% | 0% | 10.3% | 0.00 pts | 10.3% |
| gear, arrows only (no arrow = same facing) | 5 s | 8% | 0% | 10.3% | 0.00 pts | 10.3% |
| gear, arrows only (no arrow = same facing) | 10 s | 5% | 1% | 13.8% | 0.00 pts | 13.6% |
| gear, arrows only (no arrow = same facing) | 10 s | 8% | 1% | 13.8% | 0.00 pts | 13.6% |
| gear, arrows only (no arrow = same facing) | 15 s | 5% | 0% | 16.6% | 0.00 pts | 16.5% |
| gear, arrows only (no arrow = same facing) | 15 s | 8% | 10% | 17.5% | 0.69 pts | 16.5% |
| gear, arrows only (no arrow = same facing) | 20 s | 5% | 1% | 16.1% | 0.00 pts | 16.0% |
| gear, arrows only (no arrow = same facing) | 20 s | 8% | 12% | 17.3% | 0.82 pts | 16.0% |

### Early dud signs, your logging, 10 s window, dud = best cast under 5%

0% of attempts are duds at this threshold (if the line were known). A sign = what you log in a 1-s slot after READY; seen = share of attempts showing it; dud share = how many of those are duds.

| you log | seconds after READY | seen | dud share |
|---|---|---|---|
| numpad 1 sit | 8-9 | 20.0% | 0% |
| numpad 2 stand | 9-10 | 14.0% | 0% |
| numpad 2 stand | 5-6 | 9.5% | 0% |
| faces NE | 5-6 | 9.2% | 0% |
| numpad 0 idle | 5-6 | 8.0% | 0% |
| numpad 0 idle | 2-3 | 7.2% | 0% |
| numpad 6 sleep | 9-10 | 7.0% | 0% |
| numpad 0 idle | 1-2 | 6.8% | 0% |
| numpad 1 sit | 9-10 | 5.2% | 0% |
| numpad 5 run | 3-4 | 4.9% | 0% |
| numpad 4 walk | 5-6 | 4.9% | 0% |
| faces SE | 8-9 | 4.9% | 0% |
| faces NW | 5-6 | 4.6% | 0% |
| numpad 4 walk | 6-7 | 4.4% | 0% |
| numpad 5 run | 4-5 | 4.3% | 0% |
| numpad 2 stand | 8-9 | 4.2% | 0% |
| numpad 9 shoulder | 4-5 | 4.1% | 0% |
| numpad 9 shoulder | 6-7 | 4.0% | 0% |
| numpad 0 idle | 9-10 | 4.0% | 0% |
| numpad 0 idle | 8-9 | 3.9% | 0% |

### Early dud signs, your logging, 10 s window, dud = best cast under 8%

0% of attempts are duds at this threshold (if the line were known). A sign = what you log in a 1-s slot after READY; seen = share of attempts showing it; dud share = how many of those are duds.

| you log | seconds after READY | seen | dud share |
|---|---|---|---|
| numpad 1 sit | 8-9 | 20.0% | 0% |
| numpad 2 stand | 9-10 | 14.0% | 0% |
| numpad 2 stand | 5-6 | 9.5% | 0% |
| faces NE | 5-6 | 9.2% | 0% |
| numpad 0 idle | 5-6 | 8.0% | 0% |
| numpad 0 idle | 2-3 | 7.2% | 0% |
| numpad 6 sleep | 9-10 | 7.0% | 0% |
| numpad 0 idle | 1-2 | 6.8% | 0% |
| numpad 1 sit | 9-10 | 5.2% | 0% |
| numpad 5 run | 3-4 | 4.9% | 0% |
| numpad 4 walk | 5-6 | 4.9% | 0% |
| faces SE | 8-9 | 4.9% | 0% |
| faces NW | 5-6 | 4.6% | 0% |
| numpad 4 walk | 6-7 | 4.4% | 0% |
| numpad 5 run | 4-5 | 4.3% | 0% |
| numpad 2 stand | 8-9 | 4.2% | 0% |
| numpad 9 shoulder | 4-5 | 4.1% | 0% |
| numpad 9 shoulder | 6-7 | 4.0% | 0% |
| numpad 0 idle | 9-10 | 4.0% | 0% |
| numpad 0 idle | 8-9 | 3.9% | 0% |
