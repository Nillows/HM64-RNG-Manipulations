# Dog-spot lab (dogwatch): beach-lineup2-horse-b0f2a284.SaveRAM

Zig-zag route with the zigzag-fast recipe of route delays, dog-neutral (no dog-wake rule or key: every first / second cut is walked and kept, lines are anchored at the beach load and matched by game state at READY).

## The save

- file `beach-lineup2-horse-b0f2a284.SaveRAM` (sha256 b0f2a28471fd9951)
- spring 4, year 1; weather 1; 6:00 at the house load; rod in hand: True
- dog at the house load: **beach** (map 9) x -196.91, z 222.09, facing 0, flags ACTIVE
- dog on screen at the load of: beach
- repeatable (two cold boots give the same record): **yes**
- reference route (mash 10/s START→A, house U276 V52, crossroads C80, beach D86 B134), map loads: house VI 1036, farm +412, crossroads +350, ranch +236, beach +230; READY 339 VIs after the beach load at x -92.0, z 194.0

## Failure map: where the recipe never reaches READY

Mass = uniform choices over this preset's grids (mash phase per rate, rates pooled; house U, V; crossroads C; first cut D; any second cut B). Each stage starts from the mass kept by the stage before.

| stage | runs | never reached | mass kept | outside the band (slower; or faster for a 5-9-frame preset) | never reached (mass) | where Jack stopped (most common) |
|---|---|---|---|---|---|---|
| menus | 144 | 0 | 0.6675 | 0.3325 | 0.0000 | - |
| house | 2548 | 462 | 0.2733 | 0.2733 | 0.1210 | 364× map 87 x≈96 z≈80; 28× map 87 x≈-24 z≈120; 28× map 87 x≈-32 z≈128 |
| crossroads | 684 | 19 | 0.2505 | 0.0152 | 0.0076 | 19× map 78 x≈120 z≈0 |
| ranch | 54 | 0 | 0.2505 | 0.0000 | 0.0000 | - |
| beach | 1600 | 0 | 0.2505 | 0.0000 | 0.0000 | - |

- **mass of the recipe that reaches the dock end: 0.2505** (the D grid includes 82–83, which never clear the small wall on the dog-beach save)

| first cut D | P(some B reaches the dock end) | B in the window (VIs: count of beach states) | why the other B stop (D without a window) |
|---|---|---|---|
| 84 | 1.000 | 22: 800 | - |
| 86 | 1.000 | 22: 800 | - |

Second cut B by first cut D (share of the beach-state mass that reaches the dock end; else why Jack stopped, and where):

- D 84: 112–121 no READY (map 9 x≈-208 z≈120) · 122–143 READY · 144–151 no READY (map 9 x≈-224 z≈224)
- D 86: 112–117 no READY (map 9 x≈-208 z≈128) · 118–139 READY · 140–151 no READY (map 9 x≈-224 z≈224)

| 1st cut (web app bands) | share of the D grid | P(a 2nd cut reaches the dock end) |
|---|---|---|
| tight | 1.000 | 1.000 |

## Lines (dog-neutral: anchored at the beach load, matched by game state at READY)

- 156 lines from 800 beach states; lines per beach state (count of states): 3: 47, 4: 690, 5: 56, 6: 7; **0 of 800 beach states collapse to one line** (every first and second cut of that state shares one RNG trajectory, offset in time only)
- largest READY offset inside a line: 104 VIs; members not matched to any path: 0

## Cut timing, split as the web app does (cast spread 150 ms)

| preset | share of routes | release bite 1 | hold to bite 2 | either (upper bound) |
|---|---|---|---|---|
| All | 1.000 | 5.60% at 5.47 s | 6.65% at 19.6 s | 11.06% at 21.93 s |
| 1st cut tight | 1.000 | 5.60% at 5.47 s | 6.65% at 19.6 s | 11.06% at 21.93 s |
| 1st cut tight · 2nd cut early | 0.545 | 5.65% at 5.47 s | 6.81% at 19.7 s | 11.33% at 22.0 s |
| 1st cut tight · 2nd cut middle | 0.182 | 6.20% at 0.1 s | 6.83% at 19.6 s | 11.46% at 21.93 s |
| 1st cut tight · 2nd cut late | 0.273 | 5.63% at 5.27 s | 6.76% at 19.47 s | 11.29% at 21.8 s |
| 1st cut mid | 0.000 | - | - | - |
| 1st cut mid · 2nd cut early | 0.000 | - | - | - |
| 1st cut mid · 2nd cut middle | 0.000 | - | - | - |
| 1st cut mid · 2nd cut late | 0.000 | - | - | - |
| 1st cut loose | 0.000 | - | - | - |
| 1st cut loose · 2nd cut early | 0.000 | - | - | - |
| 1st cut loose · 2nd cut middle | 0.000 | - | - | - |
| 1st cut loose · 2nd cut late | 0.000 | - | - | - |

## Lineup: stability

- 156 lines; the heaviest holds 9.5% of the routes; 9 lines hold 50% and 69 hold 90% (fewer = steadier dog)
- one beach start (beach state + wait) across the full pier width: lines (count of starts) 3: 47, 4: 690, 5: 56, 6: 7; how the second cuts split: B 118-119 + B 120-123 + B 122-139 + B 126-143 (683 starts); B 118-119 + B 120-123 + B 122-123 + B 124-139 + B 126-143 (27 starts); B 118-143 + B 120-123 + B 122-139 (23 starts); B 118-139 + B 120-123 + B 126-143 (12 starts)
- one wait + second cut across the beach states (the route before the beach): lines (count) 19: 8, 21: 24, 22: 46, 23: 54, 24: 14, 25: 12, 26: 2, 32: 14, 33: 4, 34: 30, 35: 68, 36: 54, 37: 44, 38: 40, 39: 2

## Lineup: does the dog keep drawing after READY (standing at the pier, no cast)?

- routes whose line has the dog drawing after READY: **100.0%**; extra draws over 39 s (above the 1-per-game-frame clock), route-weighted mean 176; dog's tile visible 100% of the time

## Lineup: where the dog activates (its tile enters the camera's view; until then it draws nothing)

First VI after the beach load (share of routes): 205: 0.3%, 207: 0.9%, 209: 3.7%, 211: 6.3%, 213: 6.2%, 215: 6.2%, 217: 6.3%, 219: 6.2%, 221: 6.2%, 223: 6.3%, 225: 6.2%, 227: 6.3%, 229: 6.2%, 231: 6.3%, 233: 6.3%, 235: 6.2%, 237: 6.0%, 239: 5.4%, 241: 2.6%

| Jack at the activation (x, z; 8-unit cells) | share of routes | lines | release bite 1 | hold to bite 2 |
|---|---|---|---|---|
| x -456…-448, z 160…168 | 0.727 | 148 | 5.60% at 5.4 s (cover 0.98) | 6.67% at 19.53 s (cover 1.00) |
| x -448…-440, z 152…160 | 0.182 | 152 | 5.67% at 7.63 s (cover 0.99) | 6.85% at 36.5 s (cover 1.00) |
| x -448…-440, z 144…152 | 0.091 | 141 | 5.78% at 7.57 s (cover 0.98) | 6.86% at 19.67 s (cover 1.00) |

## Lineup: beach wait W (VIs Jack stands still at the beach load before his first step)

| W (VIs) | share of routes | lines | release bite 1 | hold to bite 2 |
|---|---|---|---|---|
| 0 | 0.062 | 56 | 6.08% at 0.1 s (cover 0.83) | 7.90% at 36.77 s (cover 1.00) |
| 2 | 0.062 | 54 | 6.04% at 0.1 s (cover 0.90) | 8.01% at 36.7 s (cover 1.00) |
| 4 | 0.062 | 56 | 6.14% at 0.1 s (cover 0.91) | 8.15% at 36.63 s (cover 1.00) |
| 6 | 0.062 | 54 | 6.44% at 5.67 s (cover 0.96) | 7.59% at 21.47 s (cover 0.99) |
| 8 | 0.062 | 55 | 7.26% at 0.17 s (cover 0.94) | 7.47% at 19.47 s (cover 1.00) |
| 10 | 0.062 | 59 | 7.35% at 0.2 s (cover 0.94) | 8.19% at 36.4 s (cover 1.00) |
| 12 | 0.062 | 58 | 6.90% at 2.57 s (cover 0.96) | 7.61% at 36.4 s (cover 1.00) |
| 14 | 0.062 | 58 | 7.00% at 2.5 s (cover 0.96) | 7.92% at 36.4 s (cover 1.00) |
| 16 | 0.062 | 55 | 7.08% at 7.53 s (cover 1.00) | 8.33% at 36.4 s (cover 1.00) |
| 18 | 0.062 | 53 | 7.57% at 5.8 s (cover 0.99) | 8.20% at 21.73 s (cover 0.99) |
| 20 | 0.062 | 53 | 7.42% at 5.87 s (cover 0.99) | 7.51% at 19.63 s (cover 1.00) |
| 22 | 0.062 | 52 | 7.32% at 2.7 s (cover 0.98) | 7.13% at 19.67 s (cover 1.00) |
| 24 | 0.062 | 54 | 6.95% at 2.67 s (cover 0.98) | 7.15% at 22.87 s (cover 1.00) |
| 26 | 0.062 | 58 | 7.19% at 6.03 s (cover 0.98) | 7.40% at 22.93 s (cover 0.99) |
| 28 | 0.062 | 54 | 6.95% at 6.1 s (cover 0.98) | 7.46% at 22.97 s (cover 0.99) |
| 30 | 0.062 | 59 | 6.12% at 6.13 s (cover 1.00) | 7.64% at 22.93 s (cover 1.00) |

## Lineup: first cut D (VIs of down-right after the beach load, before the cut down-left)

D 84 = the earliest cut that clears the small wall (scrapes its corner: Jack pushed to x -451.6); D 86 = one game frame later (clears the corner: x -452.0, still the wall column of the dog's view grid).

| first cut | share of routes | lines | of them shared with the other cut | dog wakes, VI after the beach load - W (share) | release bite 1 | hold to bite 2 |
|---|---|---|---|---|---|---|
| D 84 | 0.500 | 152 | 147 | 211 (82%), 209 (9%), 207 (9%) | 5.69% at 5.43 s (cover 0.98) | 6.71% at 19.6 s (cover 1.00) |
| D 86 | 0.500 | 151 | 147 | 209 (82%), 205 (9%), 207 (9%) | 5.56% at 5.83 s (cover 0.98) | 6.66% at 36.43 s (cover 1.00) |

## Lineup: wait band x second cut (full pier width; early / middle / late = dock-end spot z ≤178 / ≤190 / >190)

| wait | 2nd cut | share of routes | lines | release bite 1 | hold to bite 2 |
|---|---|---|---|---|---|
| wait 0-9 | any | 0.312 | 86 | 6.36% at 0.1 s (cover 0.90) | 7.34% at 36.6 s (cover 1.00) |
| wait 0-9 | Early | 0.170 | 84 | 6.62% at 0.17 s (cover 0.89) | 7.59% at 36.7 s (cover 1.00) |
| wait 0-9 | Middle | 0.057 | 72 | 7.71% at 0.1 s (cover 0.91) | 7.64% at 36.57 s (cover 1.00) |
| wait 0-9 | Late | 0.085 | 74 | 5.56% at 22.2 s (cover 0.98) | 7.56% at 36.43 s (cover 1.00) |
| wait 10-19 | any | 0.312 | 91 | 6.62% at 2.57 s (cover 0.97) | 7.72% at 36.4 s (cover 1.00) |
| wait 10-19 | Early | 0.170 | 90 | 6.91% at 7.6 s (cover 0.99) | 8.05% at 36.47 s (cover 1.00) |
| wait 10-19 | Middle | 0.057 | 70 | 7.21% at 7.5 s (cover 0.99) | 8.02% at 36.37 s (cover 1.00) |
| wait 10-19 | Late | 0.085 | 71 | 6.91% at 7.37 s (cover 0.99) | 7.86% at 36.23 s (cover 1.00) |
| wait 20-30 | any | 0.375 | 94 | 6.74% at 6.03 s (cover 0.99) | 7.11% at 22.93 s (cover 0.99) |
| wait 20-30 | Early | 0.205 | 93 | 7.01% at 6.13 s (cover 0.99) | 7.42% at 22.97 s (cover 0.99) |
| wait 20-30 | Middle | 0.068 | 80 | 6.96% at 6.03 s (cover 0.99) | 7.58% at 22.9 s (cover 0.99) |
| wait 20-30 | Late | 0.102 | 83 | 6.83% at 5.9 s (cover 0.99) | 7.33% at 22.77 s (cover 0.99) |
| any wait | any | 1.000 | 156 | 5.60% at 5.47 s (cover 0.98) | 6.65% at 19.6 s (cover 1.00) |
| any wait | Early | 0.545 | 156 | 5.65% at 5.47 s (cover 0.98) | 6.81% at 19.7 s (cover 1.00) |
| any wait | Middle | 0.182 | 148 | 6.20% at 0.1 s (cover 0.92) | 6.83% at 19.6 s (cover 1.00) |
| any wait | Late | 0.273 | 148 | 5.63% at 5.27 s (cover 0.98) | 6.76% at 19.47 s (cover 1.00) |

## Menus (mash until the house loads)

| style | presses/s | held VIs | house arrival VI (count of phases) |
|---|---|---|---|
| START+A | 15.0 | 2 | 1038×2, 1040×2 |
| START+A | 12.0 | 2 | 1042×2, 1044×2, 1046×1 |
| START+A | 10.0 | 3 | 1042×2, 1044×2, 1046×2 |
| START+A | 8.6 | 3 | 1042×1, 1044×1, 1046×1, 1048×1, 1050×1, 1052×1, 1054×1 |
| START+A | 7.5 | 4 | 1038×2, 1040×2, 1042×2, 1044×2 |
| START+A | 6.7 | 4 | 1038×1, 1040×2, 1042×2, 1044×2, 1046×1, 1056×1 |
| START+A | 6.0 | 5 | 1052×2, 1054×2, 1056×2, 1058×2, 1060×2 |
| START+A | 5.5 | 5 | 1050×2, 1052×2, 1054×2, 1056×2, 1058×2, 1060×1 |
| START+A | 5.0 | 6 | 1054×2, 1056×2, 1058×2, 1060×2, 1064×2, 1074×2 |
| START>A | 15.0 | 2 | 1038×2, 1040×2 |
| START>A | 12.0 | 2 | 1042×2, 1044×2, 1046×1 |
| START>A | 10.0 | 3 | 1036×1, 1038×1, 1040×1, 1042×1, 1044×1, 1046×1 |
| START>A | 8.6 | 3 | 1042×1, 1044×2, 1046×2, 1048×2 |
| START>A | 7.5 | 4 | 1038×2, 1040×2, 1042×2, 1044×2 |
| START>A | 6.7 | 4 | 1038×1, 1040×2, 1042×2, 1044×2, 1046×1, 1056×1 |
| START>A | 6.0 | 5 | 1052×2, 1054×2, 1056×2, 1058×2, 1060×2 |
| START>A | 5.5 | 5 | 1050×2, 1052×2, 1054×2, 1056×2, 1058×2, 1060×1 |
| START>A | 5.0 | 6 | 1042×2, 1044×2, 1046×2, 1048×2, 1052×2, 1062×2 |

## House (up-left U, down-left V, down) — farm arrival, VIs after the house load: count of (U, V) runs

412:28, 414:112, 416:336, 418:357, 420:210, 422:217, 424:224, 426:91, 428:70, 430:112, 432:56, 434:63, 436:56, 438:56, 440:35, 442:28, 444:28, 446:7, None:462

## Crossroads (left, cut down-left at C) — ranch arrival, VIs after the farm load: count of runs

586:190, 588:152, 590:190, 592:95, 594:38, None:19

## Beach (first cut D, second cut B; VIs after the beach load)

| D | dog first moved, VIs after the beach load (count) | B reaching the dock end (total) | READY windows (B) |
|---|---|---|---|
| 84 | None×800 | 17600 | 122–143 |
| 86 | None×800 | 17600 | 118–139 |

## Dog lines: 156 (members = beach state × D × B that reach the dock end)

- casts evaluated: 30800 distinct states; repeat checks agree 768, disagree 0

| line | weight | members | beach draw | READY spread (VIs) | casts | Nut casts b1 / b2 |
|---|---|---|---|---|---|---|
| 36fb1ef8efb948aa | 0.095 | 2860 | 1098 | 104 | 1197 | 22 / 43 |
| 6885cfce3bd71180 | 0.066 | 2152 | 1098 | 104 | 1197 | 55 / 38 |
| 4e6d73e71ca0e9a7 | 0.060 | 1768 | 1098 | 98 | 1197 | 31 / 27 |
| 63c3fbe3d15d59f8 | 0.059 | 1874 | 1098 | 94 | 1197 | 28 / 31 |
| 6c8387f7d595ac9e | 0.052 | 1752 | 1115 | 70 | 1197 | 18 / 35 |
| fb5849e13b784a3a | 0.049 | 1398 | 1104 | 44 | 1197 | 73 / 71 |
| be70b79e89c51186 | 0.043 | 1212 | 1098 | 80 | 1197 | 42 / 62 |
| f2dd86ad77cd37b6 | 0.043 | 1230 | 1104 | 64 | 1197 | 66 / 39 |
| 0ba59ba5355ef574 | 0.038 | 994 | 1099 | 98 | 1197 | 61 / 48 |
| eb956aff150b1a57 | 0.037 | 972 | 1104 | 74 | 1197 | 16 / 35 |
| fc8ef6710d54dee2 | 0.036 | 924 | 1104 | 22 | 1197 | 48 / 53 |
| f6a25cf87fec6e27 | 0.032 | 836 | 1104 | 22 | 1197 | 8 / 44 |
| 9d188a2b3a677c3f | 0.026 | 992 | 1098 | 82 | 1197 | 3 / 19 |
| f99cf0542e05147e | 0.023 | 578 | 1101 | 44 | 1197 | 17 / 43 |
| f3324315cce61cb4 | 0.019 | 488 | 1098 | 28 | 1197 | 20 / 35 |
| e8509350c6dd514f | 0.016 | 700 | 1098 | 82 | 1197 | 52 / 53 |
| ca88f8f579060df5 | 0.011 | 548 | 1098 | 82 | 1197 | 4 / 25 |
| b9a11e9edbf52b52 | 0.010 | 502 | 1118 | 64 | 1197 | 17 / 35 |
| 492c0f5f7dbe44cd | 0.009 | 368 | 1113 | 92 | 1197 | 47 / 43 |
| d757d7589b73c416 | 0.008 | 400 | 1098 | 82 | 1197 | 4 / 19 |
| db0042babd221c9a | 0.008 | 388 | 1116 | 40 | 1197 | 63 / 66 |
| d84d0ba015765542 | 0.006 | 316 | 1098 | 82 | 1197 | 61 / 48 |
| f4503ef3207941d7 | 0.006 | 346 | 1115 | 56 | 1197 | 63 / 65 |
| cc24584b5e863e42 | 0.006 | 440 | 1121 | 34 | 1197 | 63 / 40 |
| da31aadd50aa078e | 0.005 | 224 | 1101 | 44 | 1197 | 54 / 63 |
| 8a7d19fbf1cb2fd6 | 0.005 | 252 | 1101 | 62 | 1197 | 63 / 39 |
| c0d85bcc6a420088 | 0.005 | 254 | 1098 | 66 | 1197 | 49 / 63 |
| 7e0e057974a38a3f | 0.005 | 268 | 1101 | 86 | 1197 | 24 / 35 |
| 9e94347a40dc4daf | 0.005 | 342 | 1124 | 42 | 1197 | 53 / 64 |
| 78c74f2c850dc54c | 0.004 | 270 | 1098 | 88 | 1197 | 16 / 35 |
| 8a896393159af324 | 0.004 | 186 | 1130 | 34 | 1197 | 49 / 65 |
| 6f75e1b65abeb673 | 0.004 | 220 | 1115 | 56 | 1197 | 54 / 54 |
| deaffe38c5d7f0dd | 0.003 | 46 | 1102 | 36 | 1197 | 49 / 63 |
| 1f05842ef0e6ca64 | 0.003 | 44 | 1102 | 22 | 1197 | 13 / 20 |
| 2462315bf1eac835 | 0.003 | 44 | 1102 | 22 | 1197 | 3 / 26 |
| 38e62fecb88917c7 | 0.003 | 44 | 1102 | 22 | 1197 | 35 / 34 |
| 63f73cf676184aed | 0.003 | 44 | 1102 | 22 | 1197 | 27 / 31 |
| 811afccc75d6e5e3 | 0.003 | 44 | 1102 | 22 | 1197 | 4 / 26 |
| 8a889937c7486f4d | 0.003 | 44 | 1102 | 22 | 1197 | 17 / 35 |
| 95f17adbcd5ad93e | 0.003 | 44 | 1102 | 22 | 1197 | 47 / 26 |

## Lucky Timer, whole pool (aim = time after READY at the dock end; cast spread 1 s.d.)

| spread | release bite 1 | hold to bite 2 | either (smart, upper bound) | coverage at best |
|---|---|---|---|---|
| 0 ms | 7.6% at 4.5 s | 8.4% at 21.67 s | 13.4% at 22.0 s | 0.986 |
| 100 ms | 5.7% at 7.57 s | 6.9% at 36.4 s | 11.5% at 21.97 s | 0.987 |
| 150 ms | 5.6% at 5.47 s | 6.7% at 19.6 s | 11.1% at 21.93 s | 0.987 |
| 250 ms | 5.6% at 5.63 s | 6.5% at 19.57 s | 10.7% at 21.9 s | 0.988 |

- **Member recast check** (casts from members' own routes vs the shared line table): agree 1772, disagree 6, no table entry 0

  - ['0ba59ba5355ef574', 'cedb999a79d32b07@w6', 86, 138, 636, [1502, False, 2058, False], [1526, False, 2126, False]]
  - ['fc8ef6710d54dee2', 'de4addf75f552eef@w10', 84, 142, 856, [1466, False, 2586, False], [1466, False, 2920, False]]
  - ['fc8ef6710d54dee2', 'de4addf75f552eef@w10', 84, 142, 1020, [4678, False, 5060, False], [4318, False, 5748, False]]
  - ['fc8ef6710d54dee2', 'e2ace26b15675633@w22', 86, 138, 1106, [2046, False, 3904, False], [2046, False, 4462, False]]
  - ['1f124ebe7de684d6', 'fbaa5055257ec472@w26', 86, 129, 1508, [1870, False, 3312, False], [1870, False, 3686, False]]
  - ['1f124ebe7de684d6', 'fbaa5055257ec472@w26', 86, 129, 1546, [1894, False, 3336, False], [1894, False, 3710, False]]
