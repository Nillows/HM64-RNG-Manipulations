/* HM64 UI lab driver (2026-11-16). Injected into the real app page (headless browser, one attempt per page load).
   It plays one attempt of a simulated runner against the real UI on ONE absolute clock: abs ms = performance.now() - A0,
   abs 0 = the first light of the beach fade-in of the console run it stands for (console VI n starts at (n-1) x viMs).
   Taps / arrows are real KeyboardEvents at their scheduled abs times (the times actually achieved are recorded); the
   CAST cue is read back from the app (its own clock + aim); after the cast the lamp decides at every bite.
   SC (scenario) = { id, pass, viMs, lead, taps: [{cue, ms}], dog: [{ms, f | g}], sparrows, pressErr, react, lags: [ms],
                     truth: {li, o, mt, dwi}, bites: null | {tau, list: [[ms, nut], ...]}, tR } */
(function () {
  const SC = window.__UILAB_SC, out = { id: SC.id, pass: SC.pass, errors: [], taps: [], dog: { sent: 0, closed: 0 }, bites: [] };
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const $ = id => document.getElementById(id);
  window.addEventListener('error', e => out.errors.push(String(e.message)));
  const finish = () => {
    window.__UILAB_DONE = true;
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  };
  const key = (k, code, type) => document.body.dispatchEvent(new KeyboardEvent(type || 'keydown', { key: k, code: code || k, bubbles: true, cancelable: true }));
  const lamp = () => ({ big: $('lkCueBig').textContent, sub: $('lkCueSub').textContent.slice(0, 120), kind: ($('lkCue').className.match(/k-(\w+)/) || [])[1] || '' });
  setTimeout(async () => {
    try {
      const A = window.HM64LuckyApp, C = window.HM64Lucky, vi = SC.viMs;
      $('arLucky').click();
      out.version = document.title; out.sel = C.selection;
      if (SC.sparrows && $('lkSparrows') && !$('lkSparrows').checked) $('lkSparrows').click();
      out.route = C.selection.route; out.T0 = A.run.T; out.P0 = $('lkP').textContent;
      const A0 = performance.now() + SC.lead, abs = () => performance.now() - A0;
      const at = async ms => { const d = A0 + ms - performance.now(); if (d > 0) await sleep(d); };
      const R = C.routeOf(C.selection.route), sidx = R.sidxs ? R.sidxs[SC.truth.li] : null;
      const shares = () => {                                     // the app's current weight on the true line / member
        const v = A.run.plan.variants; let W = 0, wl = 0, wm = 0;
        for (const x of v) { W += x.w; if (sidx != null && x.s === sidx) { wl += x.w; if (x.o === SC.truth.o && (x.minT || 1) === SC.truth.mt) wm += x.w; } }
        return { line: W ? wl / W : null, member: W ? wm / W : null, n: v.length };
      };
      out.prior = shares();
      // ---- the clock taps and the dog logs, in time order
      const ev = SC.taps.map(t => ({ ms: t.ms, tap: t.cue })).concat((SC.dog || []).map(d => ({ ms: d.ms, dog: d }))).sort((a, b) => a.ms - b.ms);
      const DIRS = { 0: ['ArrowDown'], 4: ['ArrowUp'], 2: ['ArrowLeft'], 6: ['ArrowRight'], 1: ['ArrowDown', 'ArrowLeft'], 3: ['ArrowUp', 'ArrowLeft'], 5: ['ArrowUp', 'ArrowRight'], 7: ['ArrowDown', 'ArrowRight'] };
      const cueAbs = () => A.run.wall0 - A0 + (A.run.T - 1) * vi + (A.cueCorr ? A.cueCorr() : (A.L.biasMs || 0));
      let i = 0, finalCue = null;
      while (true) {                                             // events until 400 ms before the (possibly moving) cue
        const live = A.run.wall0 !== null, cue = live ? cueAbs() : Infinity, next = i < ev.length ? ev[i].ms : Infinity;
        if (live && abs() >= cue - 400) { finalCue = cue; break; }
        if (next === Infinity && !live) { out.errors.push('no clock tap started the stopwatch'); break; }
        const until = Math.min(next, live ? cue - 400 : Infinity);
        if (until - abs() > 50) { await sleep(Math.min(until - abs() - 1, 250)); continue; }
        if (next <= until + 1e-9) {
          await at(next);
          const e = ev[i++];
          if (e.tap) {
            key(' ', 'Space');
            out.taps.push({ cue: e.tap, want: +e.ms.toFixed(1), got: +abs().toFixed(1) });
          } else {
            const w = A.run.dw;
            if (!w || !w.open) { out.dog.closed++; continue; }
            if (e.dog.f != null) { const ks = DIRS[e.dog.f]; for (const k of ks) key(k, k); await sleep(40); for (const k of ks) key(k, k, 'keyup'); }
            else { key(String(e.dog.g), 'Numpad' + e.dog.g); await sleep(40); key(String(e.dog.g), 'Numpad' + e.dog.g, 'keyup'); }
            out.dog.sent++;
          }
        } else await at(until);
      }
      if (finalCue === null) { finish(); return; }
      await sleep(30);
      const g = A.run.gp, z = A.run.zone, bs = A.biteSplit2 ? A.biteSplit2() : null, w = A.run.dw;
      out.cue = { abs: +finalCue.toFixed(2), T: A.run.T, pol: A.run.pol, P: $('lkP').textContent, pNum: A.run.pol === 'zone' && z ? z.value : null,
                  zones: z ? z.zones : [], split: bs ? bs.by : null, corr: A.cueCorr ? A.cueCorr() : null, sig: A.sigEffMs ? A.sigEffMs() : null };
      out.clock = { wall0: +(A.run.wall0 - A0).toFixed(2), cues: g && g.cue ? Object.keys(g.cue) : [], strays: g && g.asg ? g.asg.a.filter(k => k < 0).length : 0,
                    dock: g && g.g3 ? { off: !!g.g3.off, moved: !!g.g3.moved, fit: g.g3.fit } : null };
      out.post = shares();
      if (w) { const s = w.sum; out.dw = { logs: w.logs.length, frozen: !!w.frozen, moved: Math.round((w.moved || 0) * vi), top: s && s.top ? s.top.dwi : null, pTop: s && s.top ? +s.top.p.toFixed(4) : null,
                                           pTrue: s && SC.truth.dwi != null ? +((s.lines.find(l => l.dwi === SC.truth.dwi) || { p: 0 }).p).toFixed(4) : null, left: s ? s.left : null, strict: !!A.L.dwStrict }; }
      // ---- the cast: B on the controller (not a keyboard event): the press lands pressErr ms from the cue
      let shown = null;
      const pressAbs = finalCue + SC.pressErr;
      const seen = [];
      for (let n = 0; n < 400 && abs() < Math.max(finalCue, pressAbs) + 120; n++) { const lb = lamp().big; if (seen[seen.length - 1] !== lb) seen.push(lb); if (shown === null && lb === 'CAST') shown = abs(); await sleep(4); }
      out.cue.lamps = seen.slice(-6);
      out.cue.shown = shown === null ? null : +shown.toFixed(1);
      if (Math.abs(cueAbs() - finalCue) > 0.5) out.cue.movedLate = +(cueAbs() - finalCue).toFixed(1);   // the cue moved inside the last 400 ms
      const tc = pressAbs / vi + 1;                               // continuous stopwatch time of the press on the console clock
      out.press = { abs: +pressAbs.toFixed(2), t: +tc.toFixed(3), tau: Math.round(tc) - SC.tR, aimTau: Math.round(finalCue / vi + 1) - SC.tR };
      if (!SC.bites) { finish(); return; }
      if (SC.bites.tau !== out.press.tau) { out.resync = { had: SC.bites.tau, now: out.press.tau }; finish(); return; }
      // ---- after the cast: the lamp decides at every bite
      let outcome = 'none', nb = 0;
      for (const [bms, nut] of SC.bites.list) {
        nb++;
        await at(bms + SC.react);
        const L0 = lamp(), heldNow = A.held ? A.held() : null, tNow = (performance.now() - A.run.wall0) / vi + 1;
        const lag = SC.lags[(nb - 1) % SC.lags.length];
        let act;
        if (/^DUD/.test(L0.big)) act = 'dud';
        else if (!A.run.tapInfo) act = (L0.kind === 'go' || L0.kind === 'nut') ? 'release' : 'hold';
        else act = /KEEP HOLDING/.test(L0.big) ? 'hold' : 'release';
        const rec = { n: nb, ms: +bms.toFixed(1), nut: !!nut, lamp: L0.big, kind: L0.kind, act, lag: Math.round(lag),
                      app: A.inRelease ? { rel: !!A.inRelease(tNow), hold: !!A.inHold(tNow), held: heldNow } : null };
        out.bites.push(rec);
        if (act === 'dud') { outcome = 'dud'; break; }
        await at(bms + lag);
        key(' ', 'Space');                                       // the bite tap (also when releasing)
        await sleep(60);
        const ti = A.run.tapInfo;
        if (ti) { rec.fit = !!ti.fit; rec.pNut = ti.pNut != null ? +(+ti.pNut).toFixed(4) : null; rec.pAny = ti.pAny != null ? +(+ti.pAny).toFixed(4) : null; rec.dud = !!ti.dud; rec.taus = ti.taus ? ti.taus.length : 1; }
        if (act === 'release') { outcome = lag > 20 * vi ? 'late' : nut ? 'nut' : 'fish'; break; }
        if (ti && ti.dud) { rec.dudAfter = true; outcome = 'dud'; break; }
      }
      out.outcome = outcome; out.bitesSeen = nb;
      out.laterNut = SC.bites.list.slice(nb).some(b => b[1]);
      key(outcome === 'nut' ? 'h' : outcome === 'late' ? 'e' : 'm', outcome === 'nut' ? 'KeyH' : outcome === 'late' ? 'KeyE' : 'KeyM');
      await sleep(80);
      const tl = A.tally[A.tally.length - 1];
      out.tally = tl ? { hit: tl.hit, T: tl.T, pol: tl.pol, start: tl.start, fit: tl.fit, tapNut: tl.tapNut } : null;
      out.last = $('lkLast') ? $('lkLast').textContent.slice(0, 300) : '';
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    finish();
  }, 400);
})();
