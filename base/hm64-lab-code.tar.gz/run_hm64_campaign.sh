#!/usr/bin/env bash
# One command: deploy the HM64 lab from its tar.gz, verify it, run the Power Nut
# campaign in Docker, and collect the results into one zip.
#
# Thomas's layout (no arguments needed):
#   /Users/thomwollin/Documents/hm64/run_hm64_campaign.sh
#   /Users/thomwollin/Documents/hm64/hm64-lab.tar.gz
#   /Users/thomwollin/Documents/hm64/sourcefiles/        <- your files / zips
#   cd /Users/thomwollin/Documents/hm64 && bash run_hm64_campaign.sh oracle     (oracle data, see below)
#   bash run_hm64_campaign.sh smoke                                             (few-minute test)
#
# General form:
#   bash run_hm64_campaign.sh [tarball] [inputs_dir] [preset] [workers]
#   bash run_hm64_campaign.sh <preset> [workers]
# Defaults: tarball = hm64-lab.tar.gz next to this script, inputs = sourcefiles/
# next to this script, preset = quick, workers = Docker CPUs - 1.
# Presets: smoke (minutes) | quick (121 routes) | oracle (quick's 121 routes, casts over the first
# 20 s + ladder + oracle simulation + Layer 1 link) | observe (every Layer 1 anchor, 60 s of what the
# runner sees -> how many keyboard logs until the dog is known) | pulse (C-right on every frame of
# each dog path + press pairs -> how much one whistle pulse tells) | casttables (Nut cast table for
# every dog path, every game frame 0-75 s after READY; feeds the v28 web app) | awake (casts 40-75 s
# again with Thomas's SE stay-awake push at 38 s; the farmer naps at 40 s otherwise) | whistle (one
# whistle in the 74-98 s barren zone) | lucky (Lucky Timer: mash C-right at READY until 1/2/3 whistles,
# then blind casts 0.8-46 s; one cast per distinct game state; LUCKY.md) | standard | full.
# Reuse: finished rows from the newest earlier run (any preset) are copied in first, so work
# already done (routes, casts, ladders) is not repeated. HM64_REUSE=0 starts clean.
# Layer 1: HM64_LAYER1=<folder with layer1_spring9_full.sqlite and/or layer1_shards/>; default
# <script dir>/HM64_Layer1_Mac_Generator/output. Mounted read-only; skipped if absent.
#
# Files looked for in inputs (recursively, any names; also INSIDE any .zip there):
#   *.z64 ROM (required) · *.SaveRAM/*.sra/*.sav Spring 9 save (required)
#   ROUTE_TO_CHECKPOINT_LINKS.csv (required except for smoke) · *QuickSave2(1)*.State (optional)
#   *50156*TIMING*RECIPES*.csv (optional) · *decomp*.zip (optional)
# Output: <script dir>/runs/<timestamp>/ (work) and runs/hm64-campaign-<preset>-<timestamp>.zip (upload this)
# Env: HM64_RUN_ROOT, INSTALL_CLAUDE=0 (skip Claude Code in the image), HM64_DOCKER_BUILD_EXTRA,
#      HM64_DRY_RUN=1 (only find + list your input files, then stop).
# Works with macOS's bash 3.2. Needs Docker Desktop running (Rosetta enabled on Apple silicon).
set -euo pipefail

die() { echo "ERROR: $*" >&2; exit 1; }
say() { printf '\n==> %s\n' "$*"; }

HERE=$(cd "$(dirname "$0")" && pwd)
case "${1:-}" in
  smoke|quick|oracle|observe|pulse|casttables|awake|whistle|lucky|standard|full) TARBALL="$HERE/hm64-lab.tar.gz"; INPUTS="$HERE/sourcefiles"; PRESET=$1; WORKERS=${2:-} ;;
  -h|--help) sed -n '2,30p' "$0"; exit 0 ;;
  *) TARBALL=${1:-$HERE/hm64-lab.tar.gz}; INPUTS=${2:-$HERE/sourcefiles}; PRESET=${3:-quick}; WORKERS=${4:-} ;;
esac
case "$PRESET" in smoke|quick|oracle|observe|pulse|casttables|awake|whistle|lucky|standard|full) ;; *) die "preset must be smoke|quick|oracle|observe|pulse|casttables|awake|whistle|lucky|standard|full";; esac
[ -f "$TARBALL" ] || die "tarball not found: $TARBALL"
[ -d "$INPUTS" ] || die "inputs folder not found: $INPUTS"
if [ "${HM64_DRY_RUN:-0}" != 1 ]; then
  command -v docker >/dev/null || die "docker not found"
  docker info >/dev/null 2>&1 || die "Docker is not running (start Docker Desktop)"
fi

STAMP=$(date +%Y%m%d-%H%M%S)
RUN_ROOT=${HM64_RUN_ROOT:-$HERE/runs}
WORK="$RUN_ROOT/$STAMP"
mkdir -p "$WORK"
LOG="$WORK/run.log"
exec > >(tee -a "$LOG") 2>&1
say "run folder: $WORK  (preset $PRESET)"

say "1/6 extracting lab"
tar -xzf "$TARBALL" -C "$WORK"
LAB="$WORK/hm64-lab"
[ -f "$LAB/docker-compose.yml" ] || die "tarball does not contain hm64-lab/"

say "2/6 collecting your inputs from $INPUTS"
XTR="$WORK/extracted-inputs"; mkdir -p "$XTR"
first() { find -L "$INPUTS" -type f -iname "$1" ! -path "*/runs/*" 2>/dev/null | head -n 1; }
# search inside zips under INPUTS for a member matching an extended regex; extract it, print its path
from_zips() {
  while IFS= read -r z; do
    m=$(unzip -Z1 "$z" 2>/dev/null | grep -i -E "$1" | grep -v '/$' | head -n 1 || true)
    if [ -n "$m" ]; then
      unzip -q -o -j "$z" "$m" -d "$XTR" >/dev/null 2>&1 && { echo "$XTR/$(basename "$m")"; return 0; }
    fi
  done < <(find -L "$INPUTS" -type f -iname '*.zip' ! -path "*/runs/*" 2>/dev/null)
  return 0
}
ROM=$(first '*.z64'); [ -n "$ROM" ] || ROM=$(from_zips '\.z64$')
SAVE=$(first '*.SaveRAM'); [ -n "$SAVE" ] || SAVE=$(first '*.sra'); [ -n "$SAVE" ] || SAVE=$(first '*.sav')
[ -n "$SAVE" ] || SAVE=$(from_zips '\.(SaveRAM|sra)$')
LINKS=$(first '*ROUTE_TO_CHECKPOINT_LINKS*.csv'); [ -n "$LINKS" ] || LINKS=$(from_zips 'ROUTE_TO_CHECKPOINT_LINKS.*\.csv$')
RECIPES=$(first '*50156*TIMING*RECIPES*.csv'); [ -n "$RECIPES" ] || RECIPES=$(from_zips '50156.*TIMING.*RECIPES.*\.csv$')
QS2=$(find -L "$INPUTS" -type f \( -name '*QuickSave2(1)*.State' -o -name '*QuickSave2_281_29*.State' \) ! -path "*/runs/*" 2>/dev/null | head -n 1)
[ -n "$QS2" ] || QS2=$(from_zips 'QuickSave2(\(1\)|_281_29)\.State$')
DECOMP=$(first '*decomp*.zip')
[ -n "$ROM" ] || die "no *.z64 ROM under $INPUTS"
[ -n "$SAVE" ] || die "no SaveRAM/.sra/.sav under $INPUTS"
[ -n "$LINKS" ] || [ "$PRESET" = smoke ] || die "no ROUTE_TO_CHECKPOINT_LINKS csv under $INPUTS (needed for routes)"
cp "$ROM" "$LAB/data/rom/Harvest_Moon_64_USA.z64"
cp "$SAVE" "$LAB/data/saves/"
[ -n "$LINKS" ] && cp "$LINKS" "$LAB/data/routes/ROUTE_TO_CHECKPOINT_LINKS.csv"
[ -n "$RECIPES" ] && cp "$RECIPES" "$LAB/data/routes/50156_TIMING_RECIPES_UNCLASSIFIED.csv"
[ -n "$QS2" ] && cp "$QS2" "$LAB/data/states_bizhawk/Harvest Moon 64 (USA).Mupen64Plus.QuickSave2(1).State"
if [ -n "$DECOMP" ]; then (cd "$LAB/data/decomp" && unzip -q -o "$DECOMP") || true; fi
echo "  ROM      $ROM"; echo "  save     $SAVE"; echo "  routes   ${LINKS:-none}"; echo "  recipes  ${RECIPES:-none}"
echo "  QS2      ${QS2:-none}"; echo "  decomp   ${DECOMP:-none}"
if command -v shasum >/dev/null; then
  RS=$(shasum -a 256 "$ROM" | cut -d' ' -f1); SS=$(shasum -a 256 "$SAVE" | cut -d' ' -f1)
  [ "$RS" = 15c570120bfaa97b4580762f5ee5939a56ba054e696925ea81ccfa55a022d2a6 ] && echo "  ROM sha256 OK (NYWE rev00)" \
    || echo "  WARNING: ROM sha256 $RS is not the known NYWE rev00 dump"
  [ "$SS" = db2c29ace807ab980ebbc7eccad11e30e37ea3dad53113c3fb1bdc073b759d63 ] && echo "  SaveRAM sha256 OK (Spring 9)" \
    || echo "  note: SaveRAM sha256 $SS is not the Spring 9 file the route recipes were measured with"
fi
L1=${HM64_LAYER1:-$HERE/HM64_Layer1_Mac_Generator/output}
if [ -f "$L1/layer1_spring9_full.sqlite" ] || [ -f "$L1/layer1_shards/manifest.sqlite" ] || [ -f "$L1/manifest.sqlite" ]; then
  echo "  layer1   $L1"
  L1_ARGS=(-v "$L1:/layer1:ro")
else
  echo "  layer1   none (looked in $L1; set HM64_LAYER1 to link the Layer 1 index)"
  L1_ARGS=()
fi
# earlier run with the most finished rows, to reuse them
PREV=""; BEST=0
if [ "${HM64_REUSE:-1}" != 0 ]; then
  for d in "$RUN_ROOT"/*/hm64-lab; do
    [ -d "$d" ] && [ "$d" != "$LAB" ] || continue
    n=0
    if [ "$PRESET" = whistle ] && [ ! -f "$d/results/campaign-awake/K2_ladder.jsonl" ]; then
      continue                                   # whistle tests start from the awake run's rungs
    fi
    if { [ "$PRESET" = casttables ] || [ "$PRESET" = awake ]; } && ! ls "$d"/results/campaign-*/O_observe.jsonl >/dev/null 2>&1; then
      continue                                   # cast tables need the observe/pulse run's dog paths
    fi
    if [ "$PRESET" = awake ] && [ ! -f "$d/results/campaign-casttables/K_casts.jsonl" ]; then
      continue                                   # awake continues the casttables run: only that run qualifies
    fi
    if [ "$PRESET" = lucky ] && { ! ls "$d"/results/campaign-*/O_observe.jsonl >/dev/null 2>&1 \
         || ! ls "$d"/results/campaign-*/K_casts.jsonl >/dev/null 2>&1; }; then
      continue                                   # lucky needs the dog paths (observe) and the no-whistle cast tables
    fi
    if ls "$d"/results/campaign-*/*.jsonl >/dev/null 2>&1; then
      n=$(cat "$d"/results/campaign-*/*.jsonl | wc -l | tr -d ' ')
    fi
    if { [ "$PRESET" = awake ] || [ "$PRESET" = whistle ] || [ "$PRESET" = lucky ]; } && [ "${n:-0}" -gt 0 ]; then BEST=$n; PREV=$d; continue; fi   # newest qualifying run wins
    if [ "${n:-0}" -gt "$BEST" ]; then BEST=$n; PREV=$d; fi
  done
fi
if [ -n "${HM64_REUSE_FROM:-}" ]; then           # explicit choice: a run folder (…/runs/<timestamp>) or its hm64-lab
  PREV="${HM64_REUSE_FROM%/}"; [ -d "$PREV/hm64-lab" ] && PREV="$PREV/hm64-lab"
  [ -d "$PREV/results" ] || die "HM64_REUSE_FROM=$HM64_REUSE_FROM has no results folder"
  BEST=$(cat "$PREV"/results/campaign-*/*.jsonl 2>/dev/null | wc -l | tr -d ' ')
fi
if [ "$PRESET" = awake ]; then
  [ -n "$PREV" ] && [ -f "$PREV/results/campaign-casttables/K_casts.jsonl" ] \
    || die "awake needs your casttables run (runs/<timestamp>/hm64-lab/results/campaign-casttables/K_casts.jsonl) under $RUN_ROOT"
  KC=$(wc -l < "$PREV/results/campaign-casttables/K_casts.jsonl" | tr -d ' ')
  echo "  reuse    $PREV ($BEST rows; casttables run: $KC K casts)"
elif [ "$PRESET" = whistle ]; then
  [ -n "$PREV" ] && [ -f "$PREV/results/campaign-awake/K2_ladder.jsonl" ] \
    || die "whistle needs your awake run (runs/<timestamp>/hm64-lab/results/campaign-awake/K2_ladder.jsonl) under $RUN_ROOT"
  KC=$(wc -l < "$PREV/results/campaign-awake/K2_casts.jsonl" | tr -d ' ')
  echo "  reuse    $PREV ($BEST rows; awake run: $KC K2 casts)"
elif [ "$PRESET" = lucky ]; then
  [ -n "$PREV" ] && ls "$PREV"/results/campaign-*/O_observe.jsonl >/dev/null 2>&1 \
    && ls "$PREV"/results/campaign-*/K_casts.jsonl >/dev/null 2>&1 \
    || die "lucky needs a run with O_observe.jsonl and K_casts.jsonl (your casttables/awake run) under $RUN_ROOT"
  OC=$(cat "$PREV"/results/campaign-*/O_observe.jsonl | awk '!seen[$0]++' | wc -l | tr -d ' ')
  KC=$(cat "$PREV"/results/campaign-*/K_casts.jsonl | awk '!seen[$0]++' | wc -l | tr -d ' ')
  echo "  reuse    $PREV ($BEST rows; lucky inputs: $OC observe rows, $KC no-whistle K casts)"
else
  echo "  reuse    ${PREV:-none}${PREV:+ ($BEST rows)}"
fi
if [ "${HM64_DRY_RUN:-0}" = 1 ]; then echo; echo "DRY RUN: inputs found as above; stopping before Docker."; exit 0; fi
mkdir -p "$LAB/states" "$LAB/results"
OUTDIR="$LAB/results/campaign-$PRESET"
if [ -n "$PREV" ]; then
  mkdir -p "$OUTDIR" "$LAB/states/campaign"
  # READY savestates + ladder rungs the old rows point to, then the rows themselves (merged, de-duplicated)
  cp -R "$PREV/states/campaign/." "$LAB/states/campaign/" 2>/dev/null || true
  for f in A_routes.jsonl L_ladder.jsonl B_natural.jsonl P_parity.jsonl C_whistle.jsonl O_observe.jsonl \
           W_ladder.jsonl W_single.jsonl W_double.jsonl K_ladder.jsonl K_casts.jsonl K_parity.jsonl K2_ladder.jsonl K2_casts.jsonl K2_parity.jsonl K3_casts.jsonl \
           M_mash.jsonl M_casts.jsonl; do
    if ls "$PREV"/results/campaign-*/"$f" >/dev/null 2>&1; then
      cat "$PREV"/results/campaign-*/"$f" | awk '!seen[$0]++' > "$OUTDIR/$f"
      echo "  reused $(wc -l < "$OUTDIR/$f" | tr -d ' ') rows of $f"
    fi
  done
  src=$(ls -t "$PREV"/results/campaign-*/W_lines.json 2>/dev/null | head -1 || true)
  if [ -n "$src" ]; then cp "$src" "$OUTDIR/W_lines.json"; echo "  reused W_lines.json"; fi
fi
if { [ "$PRESET" = casttables ] || [ "$PRESET" = awake ] || [ "$PRESET" = lucky ]; } && [ ! -f "$OUTDIR/O_observe.jsonl" ]; then
  die "$PRESET needs an earlier observe or pulse run (O_observe.jsonl) under $RUN_ROOT"
fi
chmod -R a+rwX "$LAB/states" "$LAB/results" "$LAB/experiments" 2>/dev/null || true

say "3/6 building the Docker image (first time: several minutes)"
cd "$LAB"
# shellcheck disable=SC2086
docker build --platform linux/amd64 -t hm64-lab:latest --build-arg INSTALL_CLAUDE="${INSTALL_CLAUDE:-1}" \
  ${HM64_DOCKER_BUILD_EXTRA:-} .

if [ -z "$WORKERS" ]; then
  NCPU=$(docker run --rm --platform linux/amd64 hm64-lab:latest nproc 2>/dev/null || echo 2)
  WORKERS=$(( NCPU > 1 ? NCPU - 1 : 1 ))
fi
say "4/6 health check inside the container (workers for the campaign: $WORKERS)"
docker compose run --rm -T lab bash -lc 'if ls data/states_bizhawk/*.State >/dev/null 2>&1; then make qs2; fi; python3 tools/smoke_test.py' \
  || die "smoke test failed - see $LOG (results would not be trustworthy)"

say "5/6 campaign ($PRESET). Resumable: if interrupted, continue from $LAB with:"
echo "     docker compose run --rm -T ${L1_ARGS[@]+"${L1_ARGS[@]}"} lab python3 tools/campaign.py --preset $PRESET --workers $WORKERS --out results/campaign-$PRESET --layer1 /layer1"
docker compose run --rm -T ${L1_ARGS[@]+"${L1_ARGS[@]}"} lab python3 tools/campaign.py --preset "$PRESET" --workers "$WORKERS" \
  --out "results/campaign-$PRESET" --layer1 /layer1 ${HM64_CAST_PATHS:+--cast-paths "$HM64_CAST_PATHS"}

say "6/6 collecting results"
OUTZIP="$RUN_ROOT/hm64-campaign-$PRESET-$STAMP.zip"
( cd "$LAB/results" && zip -q -r "$OUTZIP" "campaign-$PRESET" ) || die "zip failed"
cp "$LOG" "$LAB/results/campaign-$PRESET/run.log" 2>/dev/null || true
( cd "$LAB/results" && zip -q "$OUTZIP" "campaign-$PRESET/run.log" ) || true
echo
echo "DONE."
echo "  report : $LAB/results/campaign-$PRESET/REPORT.md"
echo "  zip    : $OUTZIP   (no ROM/save/savestates inside; upload this one)"
echo "  states : $LAB/states/campaign/  (one READY savestate per scenario - private, keep local)"
