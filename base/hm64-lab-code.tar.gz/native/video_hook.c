/*
 * m64h video hook plugin for mupen64plus (gfx API 2.2.0).
 *
 * Purpose: give the harness a callback on EVERY vertical interrupt (VI),
 * i.e. the same "frame" unit BizHawk uses. The core calls
 * gfx.updateScreen() once per VI (vi_controller.c), so we hook that.
 *
 * Two modes, chosen when PluginStartup runs:
 *   - env M64H_REAL_VIDEO unset  -> acts as a null renderer (fast, headless)
 *   - env M64H_REAL_VIDEO=/path/to/mupen64plus-video-xxx.so
 *                                -> forwards every call to that plugin,
 *                                   so you get real pixels/screenshots
 *
 * Exports for the harness:
 *   hook_set_vi_callback(fn)  fn(unsigned int vi_count) called after each VI
 *   hook_vi_count             number of VIs seen since load
 *   hook_has_real_video       1 if forwarding to a real renderer
 */
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "api/m64p_types.h"
#include "api/m64p_plugin.h"

#define EXPORT_SYM __attribute__((visibility("default")))

typedef void (*vi_cb_t)(unsigned int);

EXPORT_SYM volatile unsigned int hook_vi_count = 0;
EXPORT_SYM volatile int hook_has_real_video = 0;
static vi_cb_t g_vi_cb = NULL;

EXPORT_SYM void hook_set_vi_callback(vi_cb_t cb) { g_vi_cb = cb; }

/* real plugin function pointers */
typedef m64p_error (*ptr_Startup)(m64p_dynlib_handle, void *, void (*)(void *, int, const char *));
typedef m64p_error (*ptr_Shutdown)(void);

static void *g_real = NULL;
static ptr_Startup r_Startup;
static ptr_Shutdown r_Shutdown;
static ptr_ChangeWindow r_ChangeWindow;
static ptr_InitiateGFX r_InitiateGFX;
static ptr_MoveScreen r_MoveScreen;
static ptr_ProcessDList r_ProcessDList;
static ptr_ProcessRDPList r_ProcessRDPList;
static ptr_RomClosed r_RomClosed;
static ptr_RomOpen r_RomOpen;
static ptr_ShowCFB r_ShowCFB;
static ptr_UpdateScreen r_UpdateScreen;
static ptr_ViStatusChanged r_ViStatusChanged;
static ptr_ViWidthChanged r_ViWidthChanged;
static ptr_ReadScreen2 r_ReadScreen2;
static ptr_SetRenderingCallback r_SetRenderingCallback;
static ptr_ResizeVideoOutput r_ResizeVideoOutput;
static ptr_FBRead r_FBRead;
static ptr_FBWrite r_FBWrite;
static ptr_FBGetFrameBufferInfo r_FBGetFrameBufferInfo;

#define LOAD(name) r_##name = (void *)dlsym(g_real, #name)

static int load_real(const char *path)
{
    g_real = dlopen(path, RTLD_NOW | RTLD_LOCAL);
    if (!g_real) {
        fprintf(stderr, "[video_hook] dlopen(%s) failed: %s\n", path, dlerror());
        return 0;
    }
    r_Startup = (ptr_Startup)dlsym(g_real, "PluginStartup");
    r_Shutdown = (ptr_Shutdown)dlsym(g_real, "PluginShutdown");
    LOAD(ChangeWindow); LOAD(InitiateGFX); LOAD(MoveScreen); LOAD(ProcessDList);
    LOAD(ProcessRDPList); LOAD(RomClosed); LOAD(RomOpen); LOAD(ShowCFB);
    LOAD(UpdateScreen); LOAD(ViStatusChanged); LOAD(ViWidthChanged); LOAD(ReadScreen2);
    LOAD(SetRenderingCallback); LOAD(ResizeVideoOutput); LOAD(FBRead); LOAD(FBWrite);
    LOAD(FBGetFrameBufferInfo);
    if (!r_Startup || !r_InitiateGFX || !r_UpdateScreen || !r_ProcessDList) {
        fprintf(stderr, "[video_hook] %s is not a complete video plugin\n", path);
        dlclose(g_real);
        g_real = NULL;
        return 0;
    }
    return 1;
}

EXPORT m64p_error CALL PluginStartup(m64p_dynlib_handle CoreLibHandle, void *Context,
                                     void (*DebugCallback)(void *, int, const char *))
{
    const char *path = getenv("M64H_REAL_VIDEO");
    hook_vi_count = 0;
    hook_has_real_video = 0;
    if (path && *path && load_real(path)) {
        m64p_error err = r_Startup(CoreLibHandle, Context, DebugCallback);
        if (err != M64ERR_SUCCESS) return err;
        hook_has_real_video = 1;
    }
    return M64ERR_SUCCESS;
}

EXPORT m64p_error CALL PluginShutdown(void)
{
    if (g_real) {
        if (r_Shutdown) r_Shutdown();
        dlclose(g_real);
        g_real = NULL;
    }
    hook_has_real_video = 0;
    return M64ERR_SUCCESS;
}

EXPORT m64p_error CALL PluginGetVersion(m64p_plugin_type *PluginType, int *PluginVersion,
                                        int *APIVersion, const char **PluginNamePtr,
                                        int *Capabilities)
{
    if (PluginType) *PluginType = M64PLUGIN_GFX;
    if (PluginVersion) *PluginVersion = 0x010000;
    if (APIVersion) *APIVersion = 0x020200;
    if (PluginNamePtr) *PluginNamePtr = "m64h video hook";
    if (Capabilities) *Capabilities = 0;
    return M64ERR_SUCCESS;
}

static GFX_INFO g_gfx_info;
static int g_have_gfx_info = 0;
#define MI_INTR_DP 0x20

EXPORT void CALL ChangeWindow(void) { if (g_real && r_ChangeWindow) r_ChangeWindow(); }

EXPORT int CALL InitiateGFX(GFX_INFO Gfx_Info)
{
    g_gfx_info = Gfx_Info;
    g_have_gfx_info = 1;
    return g_real ? r_InitiateGFX(Gfx_Info) : 1;
}

EXPORT void CALL MoveScreen(int x, int y) { if (g_real && r_MoveScreen) r_MoveScreen(x, y); }

/* A real renderer raises the DP ("RDP full sync done") interrupt when it
 * finishes a display list; games such as HM64 block waiting for it. In
 * headless mode we raise it ourselves so the game keeps running. The core
 * then schedules DP_INT exactly as it would for a real plugin
 * (rsp_core.c), so CPU-side timing is unchanged. */
EXPORT void CALL ProcessDList(void)
{
    if (g_real) { r_ProcessDList(); return; }
    if (g_have_gfx_info && g_gfx_info.MI_INTR_REG)
        *g_gfx_info.MI_INTR_REG |= MI_INTR_DP;
}
EXPORT void CALL ProcessRDPList(void) { if (g_real && r_ProcessRDPList) r_ProcessRDPList(); }
EXPORT void CALL RomClosed(void) { if (g_real && r_RomClosed) r_RomClosed(); }
EXPORT int  CALL RomOpen(void) { hook_vi_count = 0; return (g_real && r_RomOpen) ? r_RomOpen() : 1; }
EXPORT void CALL ShowCFB(void) { if (g_real && r_ShowCFB) r_ShowCFB(); }

EXPORT void CALL UpdateScreen(void)
{
    if (g_real) r_UpdateScreen();
    hook_vi_count++;
    if (g_vi_cb) g_vi_cb(hook_vi_count);
}

EXPORT void CALL ViStatusChanged(void) { if (g_real && r_ViStatusChanged) r_ViStatusChanged(); }
EXPORT void CALL ViWidthChanged(void) { if (g_real && r_ViWidthChanged) r_ViWidthChanged(); }

EXPORT void CALL ReadScreen2(void *dest, int *width, int *height, int front)
{
    if (g_real && r_ReadScreen2) { r_ReadScreen2(dest, width, height, front); return; }
    if (width) *width = 0;
    if (height) *height = 0;
}

EXPORT void CALL SetRenderingCallback(void (*callback)(int))
{
    if (g_real && r_SetRenderingCallback) r_SetRenderingCallback(callback);
}

EXPORT void CALL ResizeVideoOutput(int width, int height)
{
    if (g_real && r_ResizeVideoOutput) r_ResizeVideoOutput(width, height);
}

EXPORT void CALL FBRead(unsigned int addr) { if (g_real && r_FBRead) r_FBRead(addr); }
EXPORT void CALL FBWrite(unsigned int addr, unsigned int size) { if (g_real && r_FBWrite) r_FBWrite(addr, size); }
EXPORT void CALL FBGetFrameBufferInfo(void *p) { if (g_real && r_FBGetFrameBufferInfo) r_FBGetFrameBufferInfo(p); }
