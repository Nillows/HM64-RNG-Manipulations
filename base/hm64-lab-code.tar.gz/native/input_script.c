/*
 * m64h scripted input plugin for mupen64plus (input API 2.1.1).
 *
 * No SDL, no keyboard. The controller state lives in exported globals that
 * the Python harness writes directly (it dlopens this same .so, so both the
 * core and Python see the same memory):
 *
 *   script_buttons[i]     raw BUTTONS.Value for controller i (bit layout below)
 *   script_poll_count[i]  incremented every time the game reads controller i
 *   script_present[i]     1 = controller plugged in (set before ROM start)
 *
 * BUTTONS.Value bits (little-endian bitfield order, see m64p_plugin.h):
 *   0 DR  1 DL  2 DD  3 DU  4 START  5 Z  6 B  7 A
 *   8 CR  9 CL 10 CD 11 CU 12 R 13 L
 *   bits 16..23 = X axis (int8), bits 24..31 = Y axis (int8)
 */
#include <string.h>
#include "api/m64p_types.h"
#include "api/m64p_plugin.h"

#define EXPORT_SYM __attribute__((visibility("default")))

EXPORT_SYM volatile unsigned int script_buttons[4] = {0, 0, 0, 0};
EXPORT_SYM volatile unsigned int script_poll_count[4] = {0, 0, 0, 0};
EXPORT_SYM volatile int script_present[4] = {1, 0, 0, 0};

/* Poll-exact schedule for controller 0: when the game makes its n-th read
 * (0-based, counted from the last reset of script_poll_count[0]), every entry
 * with script_sched_poll[i] <= n is applied in order, replacing
 * script_buttons[0]. Only active while script_sched_armed != 0. The harness
 * re-arms and zeroes the counter at the exact moment a savestate finishes
 * loading, so "poll 424" means the 425th read after the load. */
#define SCHED_MAX 8192
EXPORT_SYM volatile unsigned int script_sched_poll[SCHED_MAX];
EXPORT_SYM volatile unsigned int script_sched_value[SCHED_MAX];
EXPORT_SYM volatile int script_sched_len = 0;
EXPORT_SYM volatile int script_sched_pos = 0;
EXPORT_SYM volatile int script_sched_armed = 0;

static CONTROL *g_controls = NULL;

/* Optional per-poll callback for controller 0: if set, the game's n-th read
 * returns cb(0, n) and nothing else (buttons/schedule) is consulted. Lets the
 * harness run stateful route logic at exact controller-poll granularity. */
typedef unsigned int (*script_poll_cb_t)(int control, unsigned int poll_index);
static script_poll_cb_t g_poll_cb = NULL;
EXPORT_SYM void script_set_poll_callback(script_poll_cb_t cb) { g_poll_cb = cb; }

EXPORT m64p_error CALL PluginStartup(m64p_dynlib_handle CoreLibHandle, void *Context,
                                     void (*DebugCallback)(void *, int, const char *))
{
    (void)CoreLibHandle; (void)Context; (void)DebugCallback;
    return M64ERR_SUCCESS;
}

EXPORT m64p_error CALL PluginShutdown(void) { return M64ERR_SUCCESS; }

EXPORT m64p_error CALL PluginGetVersion(m64p_plugin_type *PluginType, int *PluginVersion,
                                        int *APIVersion, const char **PluginNamePtr,
                                        int *Capabilities)
{
    if (PluginType) *PluginType = M64PLUGIN_INPUT;
    if (PluginVersion) *PluginVersion = 0x010000;
    if (APIVersion) *APIVersion = 0x020101;
    if (PluginNamePtr) *PluginNamePtr = "m64h scripted input";
    if (Capabilities) *Capabilities = 0;
    return M64ERR_SUCCESS;
}

EXPORT void CALL InitiateControllers(CONTROL_INFO ControlInfo)
{
    int i;
    g_controls = ControlInfo.Controls;
    for (i = 0; i < 4; i++) {
        g_controls[i].Present = script_present[i];
        g_controls[i].RawData = 0;
        g_controls[i].Plugin = PLUGIN_NONE;   /* no controller pak: HM64 saves to cart SRAM */
        g_controls[i].Type = CONT_TYPE_STANDARD;
    }
}

EXPORT void CALL GetKeys(int Control, BUTTONS *Keys)
{
    if (Control < 0 || Control > 3) return;
    if (Control == 0 && g_poll_cb) {
        Keys->Value = g_poll_cb(0, script_poll_count[0]);
        script_poll_count[0]++;
        return;
    }
    if (Control == 0 && script_sched_armed) {
        unsigned int n = script_poll_count[0];
        while (script_sched_pos < script_sched_len && script_sched_poll[script_sched_pos] <= n) {
            script_buttons[0] = script_sched_value[script_sched_pos];
            script_sched_pos++;
        }
    }
    Keys->Value = script_buttons[Control];
    script_poll_count[Control]++;
}

EXPORT void CALL ControllerCommand(int Control, unsigned char *Command) { (void)Control; (void)Command; }
EXPORT void CALL ReadController(int Control, unsigned char *Command) { (void)Control; (void)Command; }
EXPORT int  CALL RomOpen(void) { return 1; }
EXPORT void CALL RomClosed(void) {}
EXPORT void CALL SDL_KeyDown(int keymod, int keysym) { (void)keymod; (void)keysym; }
EXPORT void CALL SDL_KeyUp(int keymod, int keysym) { (void)keymod; (void)keysym; }
