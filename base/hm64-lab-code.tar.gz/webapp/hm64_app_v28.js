/* HM64 Dog Oracle v28 app: observation UI, potential dogs, line-up, cast/hold/release cues. */
(function () {
'use strict';
const Core = window.HM64Core, D = window.HM64_DATA || HM64_DATA;
const $ = id => document.getElementById(id);
const DIRS = D.dirs, DIRNAME = ['S', 'SW', 'W', 'NW', 'N', 'NE', 'E', 'SE'];
const ALL_BASES = [...new Set(Object.keys(D.class_of).map(k => +k.split('_')[0]))].sort((a, b) => a - b);
const BASES = ALL_BASES.filter(b => b in D.names).concat(ALL_BASES.filter(b => !(b in D.names)));   // named poses first
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* storage unavailable */ } },
};
let names = Object.assign({}, D.names, store.get('hm64v28_names', {}));
let keys = Object.assign({}, D.keys, store.get('hm64v28_keys', {}));
const S = Core.settings;
Object.assign(S, store.get('hm64v28_settings', {}));
Core.prepare(D, S);

const st = { logs: [], wall0: null, facing: 0, groups: [], sel: null, auto: false, adj: 0,
             hist: null, armed: null, practice: null, taps: [], clk: new Map() };
const now = () => performance.now();
const nowDVI = () => st.wall0 === null ? 0 : (now() - st.wall0) / Core.viMs();
const sprite = (b, d) => D.sprites[b + '_' + d] || '';
const nm = b => names[b] || ('transition ' + b);
const fmtS = vi => (vi * Core.viMs() / 1000).toFixed(2) + ' s';

/* ------------------------------------------------------------------ audio */
let actx = null;
function audio() { if (!S.audio) return null; try { actx = actx || new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { actx = null; } return actx; }
let pending = [];
function cancelBeeps() { pending.forEach(g => { try { g.disconnect(); } catch (e) { /* already gone */ } }); pending = []; }
function beepAt(wall, f, dur) {
  const a = audio(); if (!a) return;
  const t = a.currentTime + Math.max(0, (wall - now()) / 1000);
  const o = a.createOscillator(), g = a.createGain();
  o.frequency.value = f; o.connect(g); g.connect(a.destination);
  g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.25, t + 0.005); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.start(t); o.stop(t + dur + 0.02); pending.push(g);
}
function beatTo(wall, hi) { [-1500, -1000, -500].forEach(d => beepAt(wall + d, hi / 2, 0.06)); beepAt(wall, hi, 0.12); }

/* ------------------------------------------------------------------ observation */
function buildDirpad() {
  const order = [3, 4, 5, 2, -1, 6, 1, 0, 7];
  $('dirpad').innerHTML = order.map(d => d < 0 ? '<span></span>' : `<button data-dir="${d}">${DIRNAME[d]}</button>`).join('');
  $('dirpad').onclick = e => { const d = e.target.dataset.dir; if (d !== undefined) setFacing(+d); };
}
function setFacing(d) { st.facing = d; [...$('dirpad').querySelectorAll('button')].forEach(b => b.classList.toggle('on', +b.dataset.dir === d)); buildPalette(); }
/* palette: animations + groups; right-click any tile to edit it as name:key (groups: name:key=member+member) */
let groups = store.get('hm64v28_groups', [{ name: 'shoulder (either)', key: '', bases: [128, 136] }]);
const RESERVED = new Set(['[', ']', '{', '}']);
function saveLabels() { store.set('hm64v28_names', names); store.set('hm64v28_keys', keys); store.set('hm64v28_groups', groups); }
const STATS = D.anim_stats || {};
const isHidden = b => S.hideFlickers && STATS[b] && STATS[b].class !== 'ok';
const statTxt = b => { const x = STATS[b]; if (!x) return '';
  return x.class === 'never' ? 'never seen at the dock' : `usually ${(x.medianVI * Core.viMs() / 1000).toFixed(2)} s on screen · ${x.perMin}/min` +
    (x.class === 'flicker' ? ' · flicker (too short to log)' : ''); };
function buildPalette() {
  const shown = BASES.filter(b => !isHidden(b)), nHidden = BASES.length - shown.length;
  $('palette').innerHTML = shown.map(b => `<div class="anim" data-base="${b}" title="${nm(b)} — ${statTxt(b)} — right-click to rename / set key">` +
    `<span class="key">${keys[b] || ''}</span><img src="${sprite(b, st.facing)}" alt=""><span class="nm">${nm(b)}</span></div>`).join('') +
    groups.map((g, i) => `<div class="anim grp" data-group="${i}" title="either: ${g.bases.map(nm).join(' / ')} — right-click to edit">` +
      `<span class="key">${g.key || ''}</span><span class="gimgs">${g.bases.slice(0, 3).map(b => `<img src="${sprite(b, st.facing)}" alt="">`).join('')}</span>` +
      `<span class="nm">${g.name}</span></div>`).join('') +
    '<div class="anim addgrp" data-add="1" title="Make a button that means: either of these animations"><span class="nm">＋ group</span></div>' +
    (nHidden || !S.hideFlickers ? `<div class="anim addgrp" data-flick="1" title="Flickers last under ~0.35 s (too short to log); some animations never appear at the dock"><span class="nm">${S.hideFlickers ? `show ${nHidden} hidden` : 'hide flickers'}</span></div>` : '');
}
$('palette').onclick = e => {
  const el = e.target.closest('.anim'); if (!el) return;
  if (el.dataset.flick) { S.hideFlickers = !S.hideFlickers; store.set('hm64v28_settings', S); buildPalette(); return; }
  if (el.dataset.add) { openKV(el, e.clientX, e.clientY); return; }
  if (el.dataset.group !== undefined) logGroup(+el.dataset.group); else logAD(+el.dataset.base);
};
$('palette').oncontextmenu = e => { const el = e.target.closest('.anim'); if (!el || el.dataset.flick) return; e.preventDefault(); openKV(el, e.clientX, e.clientY); };
function baseByName(s) {
  s = s.trim().toLowerCase(); if (s === '') return null;
  if (/^\d+$/.test(s) && ALL_BASES.includes(+s)) return +s;
  const b = ALL_BASES.find(x => nm(x).toLowerCase() === s);
  return b === undefined ? null : b;
}
function takeKey(k, owner) {                       // a key belongs to one animation or group
  for (const b of Object.keys(keys)) if (keys[b] === k && 'b' + b !== owner) keys[b] = '';
  groups.forEach((g, i) => { if (g.key === k && 'g' + i !== owner) g.key = ''; });
}
let kvTarget = null;
function openKV(el, x, y) {
  kvTarget = el;
  let text, hint;
  if (el.dataset.add) { text = 'new group:=' + nm(128) + '+' + nm(136); hint = 'name:key=animation+animation (names or numbers) · Enter saves · Esc cancels'; }
  else if (el.dataset.group !== undefined) { const g = groups[+el.dataset.group]; text = `${g.name}:${g.key || ''}=${g.bases.map(nm).join('+')}`; hint = 'name:key=animation+animation · empty = delete the group · Enter saves · Esc cancels'; }
  else { const b = +el.dataset.base; text = `${nm(b)}:${keys[b] || ''}`; hint = 'name:key · empty key = no key · empty name = default name · Enter saves · Esc cancels'; }
  $('kvInput').value = text; $('kvHint').textContent = hint; $('kvErr').textContent = '';
  const box = $('kv'); box.hidden = false;
  box.style.left = Math.min(x, window.innerWidth - 340) + 'px'; box.style.top = Math.min(y + 8, window.innerHeight - 110) + 'px';
  $('kvInput').focus(); $('kvInput').select();
}
function closeKV() { $('kv').hidden = true; kvTarget = null; }
function saveKV() {
  const el = kvTarget; if (!el) return;
  const raw = $('kvInput').value.trim(), err = m => { $('kvErr').textContent = m; };
  if (el.dataset.add || el.dataset.group !== undefined) {
    const gi = el.dataset.add ? -1 : +el.dataset.group;
    if (raw === '' && gi >= 0) { groups.splice(gi, 1); saveLabels(); buildPalette(); closeKV(); return; }
    const eq = raw.indexOf('='); if (eq < 0) return err('Use name:key=animation+animation');
    const left = raw.slice(0, eq), c = left.lastIndexOf(':');
    const name = (c < 0 ? left : left.slice(0, c)).trim(), key = (c < 0 ? '' : left.slice(c + 1)).trim().toLowerCase();
    const parts = raw.slice(eq + 1).split(/[+,]/).filter(s => s.trim());
    const bases = [...new Set(parts.map(baseByName))];
    if (bases.includes(null)) return err('Unknown animation: ' + parts.filter(p => baseByName(p) === null).join(', '));
    if (bases.length < 2) return err('A group needs at least two animations');
    if (key.length > 1 || RESERVED.has(key)) return err('Key: one character, not [ or ]');
    if (key && (key === S.tapKey || key === S.faceKey)) return err(`"${key}" is your ${key === S.tapKey ? 'tap' : 'facing-only'} key (Settings)`);
    const g = { name: name || bases.map(nm).join('/'), key, bases };
    if (gi >= 0) groups[gi] = g; else groups.push(g);
    if (key) takeKey(key, 'g' + (gi >= 0 ? gi : groups.length - 1));
  } else {
    const b = +el.dataset.base, c = raw.lastIndexOf(':');
    const name = (c < 0 ? raw : raw.slice(0, c)).trim(), key = (c < 0 ? (keys[b] || '') : raw.slice(c + 1)).trim().toLowerCase();
    if (key.length > 1 || RESERVED.has(key)) return err('Key: one character, not [ or ]');
    if (key && (key === S.tapKey || key === S.faceKey)) return err(`"${key}" is your ${key === S.tapKey ? 'tap' : 'facing-only'} key (Settings)`);
    if (name) names[b] = name; else if (D.names[b]) names[b] = D.names[b]; else delete names[b];
    keys[b] = key;
    if (key) takeKey(key, 'b' + b);
  }
  saveLabels(); buildPalette(); renderLog(); closeKV();
}
$('kvInput').addEventListener('keydown', e => {
  if (e.key === 'Enter') { saveKV(); e.preventDefault(); } else if (e.key === 'Escape') { closeKV(); e.preventDefault(); }
  e.stopPropagation();
});
$('kvSave').onclick = saveKV; $('kvCancel').onclick = closeKV;
document.addEventListener('mousedown', e => { if (!$('kv').hidden && !$('kv').contains(e.target)) closeKV(); });

function logAD(base) { logItem({ bases: [base] }); }
function logGroup(i) { const g = groups[i]; if (g) logItem({ bases: g.bases.slice(), group: g.name, gi: i }); }
function logItem(it) {
  const t = now();
  if (st.wall0 === null) st.wall0 = t;
  const base = it.bases[0];
  st.logs.push({ kind: 'AD', base, bases: it.bases.length > 1 ? it.bases : undefined, group: it.group, dir: st.facing,
                 value: Core.valueOf(base, st.facing), wall: t });
  const el = $('palette').querySelector(it.gi !== undefined ? `[data-group="${it.gi}"]` : `[data-base="${base}"]`);
  if (el) { el.classList.add('flash'); setTimeout(() => el.classList.remove('flash'), 150); }
  update();
}
function logD() {
  if (st.wall0 === null) { flashHint(`Start with an animation key${S.tapSearch ? ' or a tap' : ''}: a facing-only log cannot start the clock.`); return; }
  st.logs.push({ kind: 'D', base: -1, dir: st.facing, value: st.facing, wall: now() });
  update();
}
function undo() {
  const l = st.logs.pop();
  if (l && l.kind === 'T') { const i = st.taps.lastIndexOf(l.wall); if (i >= 0) st.taps.splice(i, 1); }
  if (!st.logs.length) { st.wall0 = null; st.taps = []; }
  update();
}
function resetSession() {
  st.logs = []; st.wall0 = null; st.sel = null; st.auto = false; st.adj = 0; st.hist = null; st.armed = null; st.taps = []; st.clk = new Map();
  $('targets').innerHTML = ''; $('planBox').innerHTML = ''; $('count').textContent = ''; $('castMsg').textContent = '';
  $('histPop').hidden = true; $('histShow').hidden = true; cancelBeeps();
  update();
}
function flashHint(msg) { $('obsHint').textContent = msg; $('obsHint').className = 'banner small warn'; }

function coreLogs() {
  return st.logs.map((l, n) => ({ kind: l.kind, base: l.base, bases: l.bases, dir: l.dir, value: l.value, dVI: (l.wall - st.wall0) / Core.viMs(), first: n === 0 }));
}
function update() {
  Core.recompute(coreLogs());
  st.groups = st.logs.length ? Core.groups(12) : [];
  // keep the selection on the same path near the same time; auto-select when one dog is left
  if (st.sel) {
    const g = st.groups.filter(x => x.k === st.sel.k && Math.abs(x.mean - st.sel.mean) < 30).sort((a, b) => b.mass - a.mass)[0];
    if (g && g.mass > 0.01) st.sel = { k: g.k, mean: g.mean, id: g.id }; else { st.sel = null; st.auto = false; }
  }
  const top = st.groups[0];
  if (top && st.logs.length >= 2 && top.mass >= 0.95 && (!st.sel || st.auto)) { st.sel = { k: top.k, mean: top.mean, id: top.id }; st.auto = true; }
  refreshClocks();
  renderLog(); renderCards();
}
const keyName = k => k === ' ' ? 'Space' : k === 'Enter' ? 'Enter' : (k || '—');
function renderKeysHelp() {
  $('keysHelp').innerHTML = `<kbd>←↑→↓</kbd>/numpad facing · <kbd>${keyName(S.faceKey)}</kbd> facing only<br>` +
    `<kbd>Backspace</kbd> undo · <kbd>${keyName(S.tapKey)}</kbd> tap "changed now"${S.tapSearch ? ' (finds the dog too)' : ' (clock only)'}<br>` +
    `<kbd>[</kbd> <kbd>]</kbd> nudge (<kbd>Shift</kbd> ×5)<br>right-click a tile: <code>name:key</code>`;
}
function renderLog() {
  $('logCount').textContent = st.logs.length + ' log' + (st.logs.length === 1 ? '' : 's');
  $('log').innerHTML = st.logs.map((l, n) => {
    const t = ((l.wall - st.wall0) / 1000).toFixed(2);
    return `<div><span class="mut">${String(n + 1).padStart(2)}</span><span>+${t}s</span>` +
      (l.kind === 'AD' ? `<img src="${sprite(l.base, l.dir)}"><span>${l.bases ? (l.group || 'group') + ' (' + l.bases.map(nm).join('/') + ')' : nm(l.base)} ${DIRNAME[l.dir]}</span>` :
       l.kind === 'T' ? `<span>● tap${l.dir >= 0 ? ' ' + DIRNAME[l.dir] : ''}</span>` : `<span>facing ${DIRNAME[l.dir]}</span>`) + '</div>';
  }).reverse().join('');
  if (st.logs.length) { $('obsHint').className = 'banner small'; $('obsHint').innerHTML = 'Log every <b>new</b> animation or turn the moment you see it. A few clean logs beat many late ones.'; }
}

/* ------------------------------------------------------------------ potential dogs */
function renderCards() {
  const gs = st.groups;
  const fitOf = g => g.bestJ === undefined ? null : Core.fitReport(g.bestJ);
  const fits = new Map(gs.map(g => [g.id, fitOf(g)]));
  const tf = gs.length ? fits.get(gs[0].id) : null, fw = $('fitWarn');
  if (tf && tf.n >= 4 && (tf.miss >= 2 || tf.miss / tf.n >= 0.2)) {
    fw.hidden = false; fw.className = 'banner small bad';
    fw.innerHTML = `<b>No measured dog fits your logs well</b> — ${tf.miss} of ${tf.n} logs match nothing on the best dog. ` +
      'Possible causes: a wrong key (Backspace undoes the last one), a different save / route / horse position, or this dog is not one of the 16 measured paths. Treat any histogram as unreliable.';
  } else if (tf && tf.n >= 4 && tf.weak / tf.n > 0.4) {
    fw.hidden = false; fw.className = 'banner small warn';
    fw.innerHTML = `<b>Timing fits loosely</b> — ${tf.weak} of ${tf.n} logs only fit as late or with a neighbouring facing. ` +
      'Measure your logging delay (Settings), or the console speed may differ from the setting (03: "Logs + speed fit").';
  } else fw.hidden = true;
  $('candSummary').textContent = gs.length ? `${gs.length} shown · ${new Set(gs.map(g => g.k)).size} dog paths` : '';
  const ban = $('convBanner');
  if (!st.logs.length) { ban.className = 'banner small'; ban.textContent = 'Waiting for the first log.'; }
  else if (st.sel) {
    const g = gs.find(x => x.id === st.sel.id) || gs.find(x => x.k === st.sel.k);
    ban.className = 'banner small ok';
    ban.innerHTML = (st.auto ? '<b>One dog left — selected automatically.</b> ' : '<b>Dog selected.</b> ') +
      `Path L${D.paths[st.sel.k].line}, ${(100 * (g ? g.mass : 0)).toFixed(1)}% of the evidence. Line it up below (03), then generate the histogram. Keep logging if you like — it keeps refining the clock.`;
  } else {
    ban.className = 'banner small';
    ban.innerHTML = `${gs.length} potential dogs. Keep logging changes; a single remaining dog is selected automatically. You can also click the dog that matches your TV.`;
  }
  $('cards').innerHTML = gs.map(g => `<div class="card${st.sel && st.sel.id === g.id ? ' sel' : ''}" data-id="${g.id}">` +
    `<div class="row between"><span class="share">${(100 * g.mass).toFixed(g.mass > 0.995 ? 1 : 0)}%</span><span class="small mut">L${g.path.line}</span></div>` +
    `<img class="big" data-id="${g.id}" alt=""><div class="small mono cardtxt"></div>` +
    `<div class="bar"><i style="width:${(100 * g.mass).toFixed(1)}%"></i></div>` +
    `<div class="small mut">±${(g.sd * Core.viMs() / 1000).toFixed(2)} s${D.casts[g.k] ? '' : ' · no cast data'}` +
    (fits.get(g.id) ? ` · fit ${fits.get(g.id).good}/${fits.get(g.id).n}${fits.get(g.id).miss ? `, ${fits.get(g.id).miss} miss` : ''}` : '') + '</div></div>').join('');
}
$('cards').onclick = e => {
  const el = e.target.closest('.card'); if (!el) return;
  const g = st.groups.find(x => x.id === el.dataset.id); if (!g) return;
  st.sel = (st.sel && st.sel.id === g.id) ? null : { k: g.k, mean: g.mean, id: g.id }; st.auto = false; renderCards();
};
/* ------------------------------------------------------------------ clocks: alternative line-up methods */
const METHODS = [
  ['logs', 'Search clock', 'Clock from everything you logged (and tapped, with tap search on); console speed as set.'],
  ['logsSpeed', 'Logs + speed fit', 'Also fits the console speed from your logs (needs 6+ timed logs over 30 s+).'],
  ['nudge', 'Nudge by eye', 'Logs, then you move the dogs with [ ] until the tool matches the TV.'],
  ['taps', 'Tap on changes', 'Press Enter each time the TV dog changes (no animation key). Speed fitted once taps span 20 s+.'],
  ['tapsLogsSpeed', 'Taps + logs speed', 'Offset from your taps, console speed from your logs.'],
];
const tapsVI = () => st.taps.map(w => (w - st.wall0) / Core.viMs());
function clocksFor(g) {
  const x = nowDVI(), out = {};
  out.logs = { A: g.mean, B: 1, sd: g.sd, note: `${st.logs.length} logs` };
  out.nudge = st.adj ? { A: g.mean + st.adj, B: 1, sd: g.sd, note: `${st.adj > 0 ? '+' : ''}${st.adj / 2} updates` } : null;
  const lr = g.bestJ === undefined ? null : Core.fitLogsClock(g.bestJ, true);
  out.logsSpeed = lr && lr.rateFitted ? { A: lr.A, B: lr.B, sd: lr.seAt(x), seB: lr.seB, note: `${lr.n} timed logs` } : null;
  const taps = tapsVI();
  if (taps.length) {
    const tf = Core.fitTapsClock(g.k, g.mean, 1, taps);
    if (tf && tf.matched) out.taps = { A: tf.A, B: tf.B, sd: Math.max(tf.sd, S.tapSdVI) / Math.sqrt(tf.matched), seB: tf.seB,
      note: `${tf.matched} taps${tf.ignored ? `, ${tf.ignored} unmatched` : ''}${tf.rateFitted ? '' : ', offset only'}` };
    if (lr && lr.rateFitted) {
      const th = Core.fitTapsClock(g.k, lr.A, lr.B, taps, 1e9, lr.B);
      if (th && th.matched) out.tapsLogsSpeed = { A: th.A, B: lr.B, sd: Math.max(th.sd, S.tapSdVI) / Math.sqrt(th.matched), seB: lr.seB,
        note: `${th.matched} taps + ${lr.n} logs` };
    }
  }
  return out;
}
function refreshClocks() { st.clk = new Map(st.groups.map(g => [g.id, clocksFor(g)])); }
function methodClock(g) {
  const c = st.clk.get(g.id) || clocksFor(g), m = c[S.method];
  return m ? Object.assign({ used: S.method }, m) : Object.assign({ used: 'logs' }, c.logs);
}
function groupNow(g) { const c = methodClock(g); return c.A + c.B * nowDVI(); }
function selGroup() { return st.sel ? (st.groups.find(x => x.id === st.sel.id) || st.groups.find(x => x.k === st.sel.k)) : null; }

/* ------------------------------------------------------------------ line up */
function nudge(dv) { st.adj += dv; if (S.method !== 'nudge') setMethod('nudge'); refreshClocks(); }
document.querySelectorAll('[data-nudge]').forEach(b => b.onclick = () => nudge(+b.dataset.nudge));
$('zeroNudge').onclick = () => { st.adj = 0; refreshClocks(); };
$('clearTaps').onclick = () => { st.taps = []; refreshClocks(); };
function tap() {
  const t = now();
  if (!S.tapSearch) {                                   // taps only feed the clock methods
    if (st.wall0 === null) return;
    st.taps.push(t); refreshClocks();
  } else {                                              // taps are search inputs too; a first tap starts the clock
    if (st.wall0 === null) st.wall0 = t;
    st.taps.push(t);
    st.logs.push({ kind: 'T', base: -1, dir: S.tapFacing ? st.facing : -1, value: -1, wall: t });
    update();
  }
  $('tapFlash').textContent = `tap ${st.taps.length}`; setTimeout(() => { $('tapFlash').textContent = ''; }, 300);
}
function setMethod(m) { S.method = m; store.set('hm64v28_settings', S); renderMethods(true); }
$('methods').onclick = e => { const tr = e.target.closest('tr[data-m]'); if (tr) setMethod(tr.dataset.m); };
$('saveSpeed').onclick = () => {
  const g = selGroup() || st.groups[0]; if (!g) return;
  const c = st.clk.get(g.id) || clocksFor(g), m = c.logsSpeed || (c.taps && c.taps.seB ? c.taps : null);
  if (!m || !m.seB) { $('speedTxt').textContent = 'No speed fit yet (log 30 s+, or tap over 20 s+).'; return; }
  const hist = store.get('hm64v28_speed', []);
  hist.push({ period: S.updateMs / m.B, se: S.updateMs * m.seB, date: new Date().toISOString(), method: c.logsSpeed ? 'logs' : 'taps' });
  store.set('hm64v28_speed', hist.slice(-50)); speedSummary();
};
$('useSpeed').onclick = () => {
  const h = store.get('hm64v28_speed', []); if (!h.length) return;
  const w = h.map(x => 1 / Math.max(1e-6, x.se) ** 2), W = w.reduce((a, b) => a + b, 0);
  S.updateMs = +(h.reduce((a, x, i) => a + w[i] * x.period, 0) / W).toFixed(4);
  store.set('hm64v28_settings', S); Core.buildCandidates(); update(); speedSummary();
};
function speedSummary() {
  const h = store.get('hm64v28_speed', []);
  if (!h.length) { $('speedTxt').textContent = `console update ${S.updateMs} ms (no measurements saved)`; return; }
  const w = h.map(x => 1 / Math.max(1e-6, x.se) ** 2), W = w.reduce((a, b) => a + b, 0);
  const m = h.reduce((a, x, i) => a + w[i] * x.period, 0) / W;
  $('speedTxt').textContent = `in use ${S.updateMs} ms · ${h.length} saved measurement${h.length > 1 ? 's' : ''}: ${m.toFixed(4)} ± ${(1 / Math.sqrt(W)).toFixed(4)} ms`;
}
let lastMethods = 0;
function renderMethods(force) {
  if (!force && now() - lastMethods < 250) return;
  lastMethods = now();
  const g = selGroup() || st.groups[0];
  if (!g || st.wall0 === null) { $('methods').innerHTML = '<tr><td class="mut">Methods appear after the first logs.</td></tr>'; return; }
  const c = st.clk.get(g.id) || clocksFor(g), x = nowDVI();
  const base = c.logs.A + c.logs.B * x;
  const truth = st.practice && now() > st.practice.ready ? practiceVI(now()) : null;
  const sg = v => (v >= 0 ? '+' : '') + v.toFixed(1);
  $('methods').innerHTML = '<tr><th>method</th><th>vs logs</th><th>console update</th><th>±</th><th>basis</th>' +
    (truth !== null ? '<th>error (practice)</th>' : '') + '</tr>' +
    METHODS.map(([id, name, tip]) => {
      const m = c[id], t = m ? m.A + m.B * x : null;
      return `<tr data-m="${id}" class="${S.method === id ? 'on' : ''}" title="${tip}"><td><input type="radio" ${S.method === id ? 'checked' : ''}> ${name}</td>` +
        `<td>${m ? sg(t - base) + ' VI' : '—'}</td><td>${m && m.B !== 1 ? (S.updateMs / m.B).toFixed(3) + ' ms' : 'as set'}</td>` +
        `<td>${m ? m.sd.toFixed(1) + ' VI' : ''}</td><td class="mut">${m ? m.note : 'waiting'}</td>` +
        (truth !== null ? `<td>${m ? sg(t - truth) + ' VI' : ''}</td>` : '') + '</tr>';
    }).join('');
  const used = methodClock(g).used;
  $('methodNote').textContent = used !== S.method ? `"${METHODS.find(m => m[0] === S.method)[1]}" has no estimate yet — using logs only.` : '';
}
/* scrub bar: offset of the tool's dog in VI, -R..+R, live while dragging; markers = upcoming changes */
const scrubR = () => Math.max(30, Math.round((S.scrubS || 3) * 1000 / Core.viMs()));
let scrubbing = false;
const scrubEl = $('scrub');
scrubEl.addEventListener('input', () => {
  scrubbing = true; st.adj = +scrubEl.value;
  if (S.method !== 'nudge') setMethod('nudge');
  refreshClocks();
});
['change', 'pointerup', 'pointercancel', 'blur'].forEach(ev => scrubEl.addEventListener(ev, () => { scrubbing = false; }));
scrubEl.addEventListener('pointerup', () => scrubEl.blur());              // keys go back to logging at once
scrubEl.addEventListener('dblclick', () => { st.adj = 0; refreshClocks(); });
scrubEl.addEventListener('keydown', e => {                                  // arrows = facing, not slider steps
  if (e.key.startsWith('Arrow') || ['Home', 'End', 'PageUp', 'PageDown'].includes(e.key)) e.preventDefault();
});
const marks = new Map();
function renderScrub(g) {
  const R = scrubR();
  if (+scrubEl.min !== -R) { scrubEl.min = -R; scrubEl.max = R; }
  if (!scrubbing) scrubEl.value = Math.max(-R, Math.min(R, st.adj));
  const sec = R * Core.viMs() / 1000;
  $('scrubMin').textContent = `−${sec.toFixed(1)} s`; $('scrubMax').textContent = `+${sec.toFixed(1)} s`;
  const sg = st.adj >= 0 ? '+' : '−', a = Math.abs(st.adj);
  $('scrubVal').textContent = `${sg}${(a * Core.viMs() / 1000).toFixed(2)} s · ${sg}${a} VI · ${sg}${a / 2} upd` + (a > R ? ' (beyond the bar)' : '');
  const track = $('scrubTrack');
  if (!g || st.wall0 === null) { marks.forEach(el => el.remove()); marks.clear(); return; }
  const c = st.clk.get(g.id) || clocksFor(g), t0 = c.logs.A + c.logs.B * nowDVI();     // the search clock, no nudge
  const keep = new Set();
  for (const ch of Core.changesIn(g.k, t0 - R, t0 + R)) {
    const s = Core.showAt(g.k, ch, -1), key = g.k + ':' + ch;
    const flick = !STATS[s.base] || STATS[s.base].class !== 'ok';
    keep.add(key);
    let el = marks.get(key);
    if (!el) {
      el = document.createElement('div'); el.className = 'mk' + (flick ? ' fl' : '');
      if (!flick) el.innerHTML = `<img src="${sprite(s.base, s.dir)}" alt="">`;
      el.title = `${nm(s.base)} ${DIRNAME[s.dir] || ''}`;
      track.appendChild(el); marks.set(key, el);
    }
    el.style.left = (100 * (ch - t0 + R) / (2 * R)).toFixed(2) + '%';
  }
  for (const [k, el] of marks) if (!keep.has(k)) { el.remove(); marks.delete(k); }
}
function renderSync() {
  const g = selGroup() || st.groups[0];
  $('syncLabel').textContent = `nudge ${st.adj >= 0 ? '+' : ''}${st.adj / 2} upd · ${st.taps.length} taps`;
  $('histBtn').disabled = !st.sel;
  $('histBtn').title = st.sel ? 'Open the cast / hold / release plan for the selected dog' : 'Identify the dog first (one dog left, or click its card)';
  renderMethods();
  renderScrub(g);
  if (!g || st.wall0 === null) { $('heroImg').removeAttribute('src'); $('heroTxt').textContent = ''; $('strip').innerHTML = ''; return; }
  const c = methodClock(g), t = c.A + c.B * nowDVI(), s = Core.showAt(g.k, t, -1);
  setSrc($('heroImg'), sprite(s.base, s.dir));
  $('heroTxt').textContent = s.base >= 0 ? `${nm(s.base)} ${DIRNAME[s.dir]}` : '?';
  const nx = Core.nextChanges(g.k, t, 7, 900);
  const key = nx.map(q => q.t).join(',');
  if ($('strip').dataset.key !== key) {
    $('strip').dataset.key = key;
    $('strip').innerHTML = nx.map(q => `<div class="st"><img src="${sprite(q.base, q.dir)}"><div class="nt" data-t="${q.t}"></div><div>${DIRNAME[q.dir] || '?'}</div></div>`).join('');
  }
  $('strip').querySelectorAll('.nt').forEach(el => { el.textContent = 'in ' + fmtS((+el.dataset.t - t) / c.B); });
  if (s.start > -1e5 && nx.length) $('runBar').style.width = (100 * (t - s.start) / Math.max(1, nx[0].t - s.start)).toFixed(1) + '%';
}
function setSrc(img, src) { if (img.dataset.src !== src) { img.dataset.src = src; if (src) img.src = src; else img.removeAttribute('src'); } }

/* ------------------------------------------------------------------ histogram */
$('histBtn').onclick = generate;
function generate() {
  if (!st.groups.length) return;
  refreshClocks();
  const sel = selGroup();
  const use = sel ? [sel] : st.groups;
  const wallGen = now(), x = nowDVI();
  const gs = use.map(g => { const c = methodClock(g); return { k: g.k, mass: g.mass, sd: c.sd, nowVI: c.A + c.B * x, rate: c.B, method: c.used }; });
  const hold = gs.some(g => D.casts[g.k] && D.casts[g.k].n2);
  const bins = Core.histogram(gs, { hold });
  const targets = Core.pickTargets(bins, 3);
  const g0 = sel || st.groups[0], c0 = st.clk.get(g0.id) || clocksFor(g0);
  st.hist = { wallGen, gs, bins, targets, hold, single: !!sel, method: gs[0].method,
              methods: Object.fromEntries(METHODS.map(([id]) => [id, c0[id] ? c0[id].A + c0[id].B * x : null])),
              practiceTruth: st.practice && wallGen > st.practice.ready ? practiceVI(wallGen) : null };
  st.armed = null; $('planBox').innerHTML = ''; $('castMsg').textContent = ''; $('pracResult').textContent = '';
  $('histPop').hidden = false; $('histShow').hidden = true;
  const unk = bins.reduce((a, b) => a + b.unk, 0) / bins.length;
  $('histInfo').textContent = (sel ? `selected dog L${D.paths[sel.k].line}` : `${gs.length} potential dogs combined`) +
    ` · clock: ${METHODS.find(m => m[0] === gs[0].method)[1]}` +
    ` · spread ${fmtS(Math.sqrt(S.pressSdVI ** 2 + S.syncSdVI ** 2 + (gs[0].sd || 0) ** 2))}` + (unk > 0.2 ? ` · ${(100 * unk).toFixed(0)}% of the window has no cast table` : '');
  $('targets').innerHTML = targets.length ? targets.map((b, i) =>
    `<button data-i="${i}">Cast in ${fmtS(b.dVI)} · ${(100 * b.p).toFixed(0)}%</button>`).join('') +
    '<span class="small mut">click another target to re-arm</span>' :
    '<span class="banner warn small">No winning cast in this window' + (unk > 0.5 ? ' — the cast tables do not reach this far yet (run the casttables preset on the Mac).' : '.') + '</span>';
  $('targets').onclick = e => { const i = e.target.dataset.i; if (i !== undefined) arm(+i); };
  if (targets.length) {                       // earliest target within 85% of the best: time matters in a run
    const best = Math.max(...targets.map(b => b.p));
    arm(targets.findIndex(b => b.p >= 0.85 * best));
  }
}
const MID = () => (D.release.first + D.release.last) / 2;
function arm(i) {
  const h = st.hist, b = h.targets[i];
  const wall = h.wallGen + b.dVI * Core.viMs();
  const g = h.gs.slice().sort((x, y) => y.mass - x.mass)[0];
  const rate = g.rate || 1;
  const s = Math.sqrt(g.sd ** 2 + S.pressSdVI ** 2 + S.syncSdVI ** 2);
  const xT = g.nowVI + b.dVI * rate;
  const rows = Core.plan(g.k, xT, s);
  cancelBeeps();
  st.armed = { i, wall, b, g, xT, rows, rate };
  if (st.practice) st.practice.done = false;
  [...$('targets').querySelectorAll('button')].forEach(x => x.classList.toggle('primary', +x.dataset.i === i));
  beatTo(wall, 1320);
  const main = nutRow(rows);
  if (main) beatTo(wall + (nutBite(main) - main.v + MID()) / rate * Core.viMs(), 1760);
  renderPlan();
}
/* the most likely landing frame that gives the Nut, and the bite to release on (1st, or 2nd after holding) */
function nutRow(rows) { return rows.filter(r => r.action === 'release' || r.action === 'hold').sort((x, y) => y.p - x.p)[0]; }
function nutBite(r) { return r.action === 'release' ? r.bite1VI : r.bite2VI; }
const ACT = { release: 'RELEASE at the bite (Nut)', hold: 'HOLD through it, release at the 2nd bite (Nut)', none: 'no Nut on this line (fish)',
              'fish?': 'fish on bite 1 (2nd bite not recorded)', unknown: 'no table' };
function renderPlan() {
  const a = st.armed; if (!a) return;
  const rows = a.rows.filter(r => r.p >= 0.01).sort((x, y) => x.v - y.v);
  const main = nutRow(rows);
  const onT = a.rows.find(r => r.vis.includes(Math.floor(a.xT)));
  $('planBox').innerHTML = '<table id="planTable" class="plan"><tr><th>if your B press is read</th><th>chance</th><th>bite shows after the press</th><th>then</th><th>2nd bite (holding)</th></tr>' +
    rows.map(r => {
      const fr = Math.round((r.v + r.vis.length / 2 - a.xT) / 2);
      const lab = r === onT ? '<b>on target</b>' : (fr === 0 ? (r.v > a.xT ? '1 VI late' : '1 VI early') :
        `${Math.abs(fr)} frame${Math.abs(fr) > 1 ? 's' : ''} ${fr > 0 ? 'late' : 'early'}`) + ` <span class="mut">(${fmtS(r.v - a.xT)})</span>`;
      const at = r.c ? r.bite1VI - r.v : null;
      const b2 = r.c && r.bite2VI ? `${fmtS((r.bite2VI - r.v) / a.rate)} ${r.c.n2 ? '→ RELEASE (Nut)' : '(fish)'}` : (r.c && D.casts[a.g.k].n2 ? '—' : 'not recorded');
      return `<tr data-at="${at === null ? '' : at}"><td>${lab}</td><td>${(100 * r.p).toFixed(0)}%</td><td>${at === null ? '—' : fmtS(at / a.rate)}</td>` +
        `<td class="act-${r.action}">${ACT[r.action]}</td><td>${b2}</td></tr>`;
    }).join('') + '</table>' +
    `<div class="small mut" style="margin-top:6px">Fishing is all on the controller: press and hold B on the last beep, release B when the bite shows ` +
    `(any release in the bite's first ${D.release.last + 1} polls gives the same catch). ` +
    (main ? (main.action === 'hold' ? `This plan HOLDS through the first bite; the release beeps are timed for the second bite (${fmtS((main.bite2VI - main.v) / a.rate)} after the press). `
                                    : `Release beeps are timed for the on-target bite (${fmtS((main.bite1VI - main.v) / a.rate)} after the press). `) : '') +
    'If the bite comes at another time, your press landed on another frame: the highlighted row says what to do.</div>';
}
function closeHist() { $('histPop').hidden = true; cancelBeeps(); st.armed = null; $('histShow').hidden = !st.hist; }
$('histClose').onclick = closeHist;
$('histShow').onclick = () => { if (st.hist) generate(); };
function drawHist() {
  if ($('histPop').hidden) return;
  const cv = $('hist'), h = st.hist, dpr = Math.min(2, window.devicePixelRatio || 1);
  const w = cv.clientWidth || 600, H = 120;
  cv.width = w * dpr; cv.height = H * dpr;
  const c = cv.getContext('2d'); c.scale(dpr, dpr); c.clearRect(0, 0, w, H);
  const L = 34, B = H - 22, top = 10;
  c.strokeStyle = '#3a4d5c'; c.beginPath(); c.moveTo(L, top); c.lineTo(L, B); c.lineTo(w - 6, B); c.stroke();
  c.fillStyle = '#8ea3b2'; c.font = '11px ui-monospace,monospace';
  if (!h) { c.fillText('Generate the histogram after lining up the dog.', L + 10, 40); return; }
  const n = h.bins.length, xs = (w - L - 10) / n;
  for (let s = 0; s <= S.horizonS; s += 2) { const x = L + s * 1000 / Core.viMs() * xs; c.fillText('+' + s + 's', x - 8, B + 15); }
  [0.5, 1].forEach(p => { const y = B - p * (B - top); c.fillText((p * 100) + '%', 2, y + 4); c.strokeStyle = '#22323f'; c.beginPath(); c.moveTo(L, y); c.lineTo(w - 6, y); c.stroke(); });
  h.bins.forEach((b, i) => {
    const x = L + i * xs;
    if (b.unk > 0.01) { c.fillStyle = 'rgba(240,179,90,0.12)'; c.fillRect(x, B - b.unk * (B - top), Math.max(1, xs), b.unk * (B - top)); }
    if (b.p > b.p1 + 0.005) { c.fillStyle = '#e7c14a'; c.fillRect(x, B - b.p * (B - top), Math.max(1, xs), (b.p - b.p1) * (B - top)); }
    if (b.p1 > 0.005) { c.fillStyle = '#5fd38d'; c.fillRect(x, B - b.p1 * (B - top), Math.max(1, xs), b.p1 * (B - top)); }
  });
  const g0 = h.gs[0], cst = D.casts[g0.k];
  if (cst && cst.nap_vi) {                              // tables recorded without the push end at the nap
    const covEnd = cst.lo + cst.n1.length, xi = (cst.nap_vi - g0.nowVI) / (g0.rate || 1);
    if (xi > 0 && xi < n) {
      const x = L + xi * xs; c.strokeStyle = '#ef6f6f'; c.setLineDash([4, 3]); c.beginPath(); c.moveTo(x, top); c.lineTo(x, B); c.stroke(); c.setLineDash([]);
      c.fillStyle = '#ef6f6f'; c.fillText(covEnd > cst.nap_vi + 4 ? '40 s: push SE before here' : '40 s nap: push SE (no tables after)', Math.min(x + 4, w - 230), top + 24);
    }
  }
  const lead = S.leadMinS * 1000 / Core.viMs();
  c.fillStyle = 'rgba(13,23,32,0.6)'; c.fillRect(L, top, lead * xs, B - top);
  const cur = (now() - h.wallGen) / Core.viMs();
  if (cur >= 0 && cur <= n) { c.strokeStyle = '#6fb7ff'; c.beginPath(); c.moveTo(L + cur * xs, top); c.lineTo(L + cur * xs, B); c.stroke(); }
  if (st.armed) { const x = L + st.armed.b.dVI * xs; c.strokeStyle = '#fff'; c.setLineDash([3, 3]); c.beginPath(); c.moveTo(x, top); c.lineTo(x, B); c.stroke(); c.setLineDash([]); }
  c.fillStyle = '#5fd38d'; c.fillText('■ Nut, release at bite 1', w - 330, 12);
  c.fillStyle = '#e7c14a'; c.fillText('■ Nut after holding', w - 165, 12);
}
function tickCountdown() {
  const a = st.armed, el = $('count'); if (!a) { el.textContent = ''; return; }
  const t = now(), dt = (a.wall - t) / 1000;
  if (dt > -0.4) {
    el.className = 'count' + (dt <= 0 ? ' go' : ''); el.textContent = dt > 0 ? dt.toFixed(2) : 'B!';
    $('castMsg').textContent = dt > 0 ? 'Press and hold B on the last beep.' : ''; return;
  }
  if (st.practice && !st.practice.done && dt < -0.8) practiceCast(a.wall, true);
  // hands-free bite guide: path VIs since the cast beat
  const since = (t - a.wall) / Core.viMs() * a.rate;
  const rows = a.rows.filter(r => r.c && r.p >= 0.01);
  const main = nutRow(rows);
  el.className = 'count rel';
  if (main) {
    const rel = (nutBite(main) - main.v + MID() - since) / a.rate * Core.viMs() / 1000;
    const b1 = (main.bite1VI - main.v + MID() - since) / a.rate * Core.viMs() / 1000;
    el.textContent = main.action === 'hold' && b1 > -0.6 ? (b1 > 0 ? 'HOLD through bite 1 in ' + b1.toFixed(1) : 'HOLD — keep B') :
      (rel > 0 ? 'release in ' + rel.toFixed(1) : (rel > -0.6 ? 'RELEASE' : ''));
  } else el.textContent = '';
  const nx = rows.map(r => ({ r, at: r.bite1VI - r.v })).filter(o => o.at > since - 25).sort((x, y) => x.at - y.at)[0];
  $('castMsg').textContent = nx ? `Holding B. Next possible bite ${fmtS((nx.at - since) / a.rate)} from now → ${ACT[nx.r.action]}` :
    'Holding B. No more bites expected from the likely frames — release when you see one.';
  document.querySelectorAll('#planTable tr[data-at]').forEach(tr => {
    const at = tr.dataset.at === '' ? null : +tr.dataset.at;
    tr.classList.toggle('now', at !== null && since >= at - 15 && since <= at + D.release.last + 2);
  });
}

/* ------------------------------------------------------------------ practice: a hidden dog on a virtual N64 */
$('practiceBtn').onclick = () => {
  const tot = D.arrivals.reduce((s, a) => s + a[2], 0);
  let r = Math.random() * tot, i = 0;
  while (r > D.arrivals[i][2]) { r -= D.arrivals[i][2]; i++; }
  resetSession();
  st.practice = { i, k: D.arrivals[i][0], o: D.arrivals[i][1], ready: now() + 2000, rf: 1 + (S.practiceSpeedPct || 0) / 100 };
  $('tvPanel').hidden = false; $('tvNote').hidden = false; $('tvTxt').textContent = 'READY in 2 s…';
};
$('stopPractice').onclick = () => { st.practice = null; $('tvPanel').hidden = true; $('tvNote').hidden = true; };
function practiceVI(t) { const p = st.practice; return (t - p.ready) / Core.viMs() * p.rf + p.o; }
function renderTV() {
  const p = st.practice; if (!p) return;
  const t = now();
  if (t < p.ready) { $('tvTxt').textContent = 'READY in ' + ((p.ready - t) / 1000).toFixed(1) + ' s'; return; }
  const s = Core.showAt(p.k, practiceVI(t), D.arrivals[p.i][3] && D.arrivals[p.i][3].length ? p.i : -1);
  setSrc($('tvImg'), sprite(s.base, s.dir));
  if (!p.done) $('tvTxt').textContent = `${((t - p.ready) / 1000).toFixed(1)} s after READY`;
}
/* virtual B press: the B key on the beat, or automatically on the beat (perfect press) */
function practiceCast(t, auto) {
  const p = st.practice, a = st.armed; if (!p || p.done || !a) return;
  p.done = true;
  const v = Math.floor(practiceVI(t)), c = Core.castAt(p.k, v), h = st.hist;
  const err = h.practiceTruth === null ? NaN : a.g.nowVI - h.practiceTruth;
  const sg = x => (x >= 0 ? '+' : '') + x.toFixed(1);
  const per = Object.entries(h.methods).filter(([, x]) => x !== null).map(([m, x]) => `${METHODS.find(q => q[0] === m)[1]} ${sg(x - h.practiceTruth)}`).join(' · ');
  const outcome = c ? (c.n1 ? '<b style="color:#5fd38d">POWER NUT!</b>' : (c.n2 ? 'fish on bite 1 — Nut if you HOLD' : 'fish')) : 'outside the cast table';
  $('tvTxt').innerHTML = outcome;
  $('pracResult').innerHTML = 'Practice: ' + outcome +
    `${auto ? ' (perfect press on the beat)' : ` (your press ${sg((t - a.wall) / Core.viMs())} VI from the beat)`}` +
    ` · true dog L${D.paths[p.k].line}${a.g.k === p.k ? ' (tool agreed)' : ` — tool used L${D.paths[a.g.k].line}`}; ` +
    `clock error ${isNaN(err) ? '?' : sg(err) + ' VI'} with ${METHODS.find(q => q[0] === h.method)[1]}<br><span class="mut">all methods at generate: ${per}</span>`;
  const log = store.get('hm64v28_practice', []);
  log.push({ date: new Date().toISOString(), path: p.k, line: D.paths[p.k].line, speedPct: S.practiceSpeedPct || 0, method: h.method,
             errors: Object.fromEntries(Object.entries(h.methods).map(([m, x]) => [m, x === null ? null : +(x - h.practiceTruth).toFixed(2)])),
             outcome: c ? (c.n1 ? 'nut' : c.n2 ? 'hold-nut' : 'fish') : 'unknown', auto });
  store.set('hm64v28_practice', log.slice(-200)); practiceSummary();
}
function practiceSummary() {
  const log = store.get('hm64v28_practice', []); if (!log.length) { $('pracStats').textContent = ''; return; }
  const rows = METHODS.map(([id, name]) => {
    const e = log.map(r => r.errors && r.errors[id]).filter(x => typeof x === 'number');
    return e.length ? `${name}: RMS ${Math.sqrt(e.reduce((a, b) => a + b * b, 0) / e.length).toFixed(2)} VI (${e.length})` : null;
  }).filter(Boolean);
  const nut = log.filter(r => r.outcome === 'nut').length;
  $('pracStats').textContent = `${log.length} practice casts, ${nut} Nut. Clock error by method — ${rows.join(' · ')}`;
}

/* ------------------------------------------------------------------ keyboard */
const held = new Set();
function arrowDir() {
  const u = held.has('ArrowUp'), d = held.has('ArrowDown'), l = held.has('ArrowLeft'), r = held.has('ArrowRight');
  if (u && l) return 3; if (u && r) return 5; if (d && l) return 1; if (d && r) return 7;
  if (u) return 4; if (d) return 0; if (l) return 2; if (r) return 6; return null;
}
const NUMPAD = { Numpad8: 4, Numpad2: 0, Numpad4: 2, Numpad6: 6, Numpad7: 3, Numpad9: 5, Numpad1: 1, Numpad3: 7 };
document.addEventListener('keydown', e => {
  if (window.HM64Arena === 'lucky') return;                    // the Lucky Timer has its own keys
  if ((e.target.tagName === 'INPUT' && e.target.type !== 'range') || document.querySelector('dialog[open]')) return;
  if (e.code in NUMPAD) { setFacing(NUMPAD[e.code]); e.preventDefault(); return; }
  if (e.key.startsWith('Arrow')) { if (!e.repeat) { held.add(e.key); const d = arrowDir(); if (d !== null) setFacing(d); } e.preventDefault(); return; }
  if (e.repeat) return;
  if (e.key === S.tapKey) { tap(); e.preventDefault(); return; }
  if (e.key === S.faceKey) { logD(); e.preventDefault(); return; }
  if (e.key === 'Backspace') { undo(); e.preventDefault(); return; }
  if (e.key === 'Escape' && !$('histPop').hidden) { closeHist(); e.preventDefault(); return; }
  if (st.practice && st.armed && !st.practice.done && e.key.toLowerCase() === 'b') { practiceCast(now(), false); e.preventDefault(); return; }
  if (e.key === '[' || e.key === '{') { nudge(e.shiftKey || e.key === '{' ? -10 : -2); return; }
  if (e.key === ']' || e.key === '}') { nudge(e.shiftKey || e.key === '}' ? 10 : 2); return; }
  const k = e.key.length === 1 ? e.key.toLowerCase() : null;
  if (!k) return;
  const b = Object.keys(keys).find(x => keys[x] === k);
  if (b !== undefined && BASES.includes(+b) && !isHidden(+b)) { logAD(+b); e.preventDefault(); return; }
  const gi = groups.findIndex(g => g.key === k);
  if (gi >= 0) { logGroup(gi); e.preventDefault(); }
});
document.addEventListener('keyup', e => { held.delete(e.key); });

/* ------------------------------------------------------------------ settings, calibration, export */
const SET = [['s_updateMs', 'updateMs', 1], ['s_reactMu', 'reactMuVI', 'vi'], ['s_reactSd', 'reactSdVI', 'vi'], ['s_firstLog', 'firstLogMaxVI', 'svi'],
             ['s_pressSd', 'pressSdVI', 'vi'], ['s_syncSd', 'syncSdVI', 'vi'], ['s_lead', 'leadMinS', 1], ['s_horizon', 'horizonS', 1],
             ['s_tapMu', 'tapMuVI', 'vi'], ['s_pracSpeed', 'practiceSpeedPct', 1], ['s_scrubS', 'scrubS', 1]];
function fillSettings() {
  for (const [id, k, u] of SET) $(id).value = u === 'vi' ? Math.round(S[k] * Core.viMs()) : u === 'svi' ? (S[k] * Core.viMs() / 1000).toFixed(1) : S[k];
  $('s_dirTol').checked = S.dirTolerance; $('s_audio').checked = S.audio;
  $('s_tapSearch').checked = S.tapSearch; $('s_tapFacing').checked = S.tapFacing;
  $('capTap').textContent = keyName(S.tapKey); $('capFace').textContent = keyName(S.faceKey);
  const ck = D.checks;
  $('dataInfo').innerHTML = `Data ${D.version} (${D.generated}): ${ck.paths} dog paths, ${ck.arrivals} arrivals = ${ck.routes_weighted} routes; ` +
    `cast tables on ${D.casts.filter(Boolean).length} paths (${ck.arrivals_with_casts} arrivals measured, ${ck.cast_conflicts} conflicts); ` +
    `bite-2 (hold) tables on ${D.casts.filter(c => c && c.n2).length} paths. Cast coverage (path time): ` +
    D.casts.map((c, k) => c ? `L${D.paths[k].line} ${(c.lo * Core.viMs() / 1000).toFixed(0)}–${((c.lo + c.n1.length) * Core.viMs() / 1000).toFixed(0)} s` : '').filter(Boolean).join(', ');
}
function readSettings() {
  S.updateMs = +$('s_updateMs').value || Core.DEFAULTS.updateMs;
  for (const [id, k, u] of SET.slice(1)) {
    const v = +$(id).value;
    if (!isFinite(v)) continue;
    S[k] = u === 'vi' ? v / Core.viMs() : u === 'svi' ? v * 1000 / Core.viMs() : v;
  }
  S.lagMaxVI = Math.max(30, S.reactMuVI + 4 * S.reactSdVI);
  S.dirTolerance = $('s_dirTol').checked; S.audio = $('s_audio').checked;
  S.tapSearch = $('s_tapSearch').checked; S.tapFacing = $('s_tapFacing').checked; renderKeysHelp();
  store.set('hm64v28_settings', S); Core.buildCandidates(); update();
}
function settingsTab(t) {                                     // v29.9: Lucky Timer / Dog Oracle / Calibration & data
  document.querySelectorAll('#settingsDlg [data-pane]').forEach(p => { p.hidden = p.dataset.pane !== t; });
  document.querySelectorAll('#settingsDlg [data-tab]').forEach(b => b.classList.toggle('on', b.dataset.tab === t));
}
document.querySelectorAll('#settingsDlg [data-tab]').forEach(b => { b.onclick = () => settingsTab(b.dataset.tab); });
$('settingsBtn').onclick = () => { fillSettings(); settingsTab(window.HM64Arena === 'lucky' ? 'lucky' : 'oracle'); $('settingsDlg').showModal(); };
let capturing = null;
['capTap', 'capFace'].forEach(id => { $(id).onclick = () => { capturing = id; $(id).textContent = 'press a key…'; }; });
$('settingsDlg').addEventListener('keydown', e => {
  if (!capturing) return;
  e.preventDefault(); e.stopPropagation();
  if (e.key === 'Escape') { capturing = null; fillSettings(); return; }
  const k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
  if (['[', ']', '{', '}', 'Backspace', 'Tab'].includes(k) || k.startsWith('Arrow')) { $(capturing).textContent = 'not that key'; return; }
  const field = capturing === 'capTap' ? 'tapKey' : 'faceKey', other = field === 'tapKey' ? 'faceKey' : 'tapKey';
  if (S[other] === k) S[other] = '';                     // one key, one job
  S[field] = k;
  $(capturing).blur();                                   // so Space/Enter do not click the button again
  takeKey(k, 'settings');                                // an animation or group using it loses it
  saveLabels(); buildPalette();
  capturing = null; fillSettings(); renderKeysHelp(); store.set('hm64v28_settings', S);
}, true);
$('settingsDlg').addEventListener('close', readSettings);
$('resetSettings').onclick = () => { Object.assign(S, Core.DEFAULTS); fillSettings(); };
$('importNames').onclick = () => $('namesFile').click();
$('namesFile').onchange = async e => {
  try { const j = JSON.parse(await e.target.files[0].text()); names = Object.assign({}, D.names, j.names || {}); keys = Object.assign({}, D.keys, j.keys || {});
        if (Array.isArray(j.groups)) groups = j.groups.filter(g => Array.isArray(g.bases) && g.bases.length > 1);
        saveLabels(); buildPalette(); }
  catch (err) { alert('Not a names/keys file: ' + err.message); }
};
$('exportNames').onclick = () => {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([JSON.stringify({ schema: 'hm64-dog-v20-labels', names, keys, groups }, null, 1)], { type: 'application/json' }));
  a.download = 'user_names_keys.json'; a.click();
};
$('exportBtn').onclick = () => {
  const out = { schema: 'hm64-v28-session', version: D.version, settings: S, logs: st.logs.map(l => ({ ...l, t_ms: l.wall - st.wall0 })),
    selected: st.sel, nudgeVI: st.adj, groups: st.groups.map(g => ({ path: g.k, line: g.path.line, mass: g.mass, mean: g.mean, sd: g.sd })),
    taps_ms: st.taps.map(w => w - st.wall0), method: S.method, labels: { names, keys, groups },
    fit: st.groups[0] && st.groups[0].bestJ !== undefined ? Core.fitReport(st.groups[0].bestJ) : null,
    histogram: st.hist && { targets: st.hist.targets, gs: st.hist.gs, method: st.hist.method, methodsNowVI: st.hist.methods, practiceTruthVI: st.hist.practiceTruth },
    armed: st.armed && { xT: st.armed.xT, path: st.armed.g.k, rate: st.armed.rate },
    practice: st.practice, practiceLog: store.get('hm64v28_practice', []), speedLog: store.get('hm64v28_speed', []) };
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([JSON.stringify(out, null, 1)], { type: 'application/json' }));
  a.download = 'hm64_v28_session_' + new Date().toISOString().replace(/[:.]/g, '-') + '.json'; a.click();
};
$('calibBtn').onclick = () => {
  const lat = [], dlg = $('calibDlg'); dlg.showModal();
  const poses = BASES.filter(b => sprite(b, 0)); let changeAt = null, n = 0, timer = null;
  const next = () => {
    if (n >= 8) {
      const m = lat.reduce((a, b) => a + b, 0) / lat.length, sd = Math.sqrt(lat.reduce((a, b) => a + (b - m) ** 2, 0) / lat.length);
      $('calibMsg').textContent = `Mean ${m.toFixed(0)} ms, spread ${sd.toFixed(0)} ms (applied).`;
      $('calibTxt').textContent = `${m.toFixed(0)} ± ${sd.toFixed(0)} ms`;
      $('s_reactMu').value = Math.round(m + 50); $('s_reactSd').value = Math.round(Math.max(40, sd));   // +50 ms to pick a key and facing
      $('s_tapMu').value = Math.round(m);                                                               // a bare tap: no key choice
      document.removeEventListener('keydown', kd, true); return;
    }
    changeAt = null; setSrc($('calibImg'), sprite(poses[n % poses.length], 0));
    timer = setTimeout(() => { setSrc($('calibImg'), sprite(poses[(n + 3) % poses.length], (n * 3) % 8)); changeAt = now(); }, 1000 + Math.random() * 2000);
  };
  const kd = e => { if (e.key !== ' ') return; e.preventDefault(); e.stopPropagation(); if (changeAt === null) { clearTimeout(timer); $('calibMsg').textContent = 'Too early — wait for the change.'; setTimeout(next, 600); return; } lat.push(now() - changeAt); n++; next(); };
  document.addEventListener('keydown', kd, true);
  $('calibClose').onclick = () => { clearTimeout(timer); document.removeEventListener('keydown', kd, true); dlg.close(); };
  next();
};
$('helpBtn').onclick = () => { $('helpBody').innerHTML = HELP; $('helpDlg').showModal(); };
$('undoBtn').onclick = undo; $('resetBtn').onclick = resetSession;

const HELP = `<h2>How ${D.version} works</h2>
<p><b>Two arenas</b> (footer): <i>Dog Oracle</i> watches the dog and lines the tool up with your N64; <i>Lucky Timer</i> needs no observation — start a stopwatch when the dog lands (or at READY), cast on the CAST flash of the cue lamp, follow the release zones, and if it is not the Nut just reset and try again.</p>
<p><b>Lucky Timer: pace and start.</b> Your <i>pace</i> is the total hesitation before the dog lands: the four menu presses plus the walking waits (house, crossroads, pickup), in frames of 1/60 s. The measured routes split into Fast (≤ 21 frames, 28% of routes), Medium (22–27, 37%) and Slow (28+, 35%); each lands on a different mix of dog paths, so each has its own best cast. Pick the card that fits you; the line under the cards shows what that plan gives if you are really another pace. The routes only reach 30 frames of menu hesitation (+ up to 1 s on one walking wait), so a pace far slower than that is outside the lab's measurements. <i>Start when the dog lands</i>: press the start key together with A as you put the dog down (the dog lands 8 frames after the A press; delay −130 ms) or when you see it land (+150 ms). The lab shows that routes which differ only in how long you wait on the beach reach the same dog path shifted by exactly that wait, so from the landing your beach wait changes nothing — with a READY start it shifts every timing. Press the start key again when the first bite shows (any policy): it is logged and fits the plan to you.</p>
<p><b>Lucky Timer: cast tap and what went wrong.</b> Tap the start key together with B when you cast: the tool logs your real cast (and how far it was from the CAST cue), and with the bite tap it knows the bite's delay after the cast — the fingerprint of the frame you landed on. It then says whether that bite was a Power Nut bite or a fish bite (simulated: a clear call on ~85% of attempts, right ~97–100% of the time). Then press H (Nut), M (fish) or E (the line came back empty). Game rule (player.c handleFishingAction): letting go of B during the bite's 20 frames (0.33 s) lands the catch; letting go at any other moment reels in nothing. So an empty line means your release missed the window; a fish from a Nut bite means you were just past it (lab: +20/+21 frames give a fish); a fish from a fish bite means the cast, not the release. Over attempts the profile learns how long after the bite starts your taps come — compare with the 333 ms window. With <i>1st bite</i>, the cue lamp marks the moments a Nut bite can come after your cast (amber with two blinks just before, green while it lasts), so you can anticipate instead of react.</p>
<p><b>Smart zones = release windows + bite-2 fallback.</b> Release bite 1 only inside a release window. If it comes before a window, or a window passes with no bite, hold through it and tap it: with your cast tap, the bite's delay after the cast tells the tool which frame and dog path you are on, and it forecasts bite 2 — DUD (reset now) or the Nut chance and the moment(s) bite 2 can be the Nut, with two ticks before each. Tap bite 2 too: both bites pin the frame and teach the profile. Simulated (Fast, cast tap): cast 5.77 s → 28% per attempt (17% bite 1 + 11% bite 2); DUD on 57% of the holds, no Nut lost to it, ~16 s saved each; every bite-2 Nut came inside the forecast moment. With the 1st-bite cast time (2.20 s) the same plan gives 18% because bite 2 rarely saves you there.</p>
<p><b>Lucky Timer: cast practice.</b> L3 · Your timing → <i>Cast practice</i> runs the cast of the current plan with the same cues as an attempt: the timeline scrolling to the CAST line, the "Cast in" countdown, the angler and the cue lamp (bar + 3-2-1 pulses, then CAST). Press the start key (or any button of a USB controller) on CAST; each press is logged against the cue in ms (+ = late) and shown on the timeline. Quick mode starts each cast 4 s before the cue; <i>full wait</i> starts on your start press and waits the whole plan, like an attempt. Untick <i>moving cast line</i> for pulses only (no bar) — closest to a real attempt, where your eyes are on the TV; the two modes keep separate profiles, and presses made with sound on are kept apart from presses to the visual cue. The profile shows your median (how late or early you press), your spread (1 SD, outliers beyond 3 MAD left out), how often you land on the right game frame now and after correction, and the best odds of this plan with that spread. L5 · <i>Your timing</i> uses these presses automatically, together with your real casts (the cast tap): the cast-cue correction = minus their median, the timing spread = their spread combined with 60 ms for the start tap and how well your clock offset is known (±60 ms until auto-tune has learned it from 8 attempts with the cast tap). <i>Copy to my hand-set values</i> is only for rows you set by hand. Your real casts (start key tapped with B) are shown alongside in yellow. Practise with the same screen (and sound setting) as for attempts: their delay is part of what the correction removes.</p>
<p><b>Lucky Timer: routes.</b> The Route menu switches the tables; attempts, taps, start and preset are kept per route. <i>Spring 9 dog carry</i> is the lab's arrival pool (pace presets, dog-landing start). <i>nodog-nohorse-no-pickup · zig-zag fast zone</i> is Thomas's no-horse save with the dog asleep under the pier (save 0d78b95b) walked the zig-zag way: menus mashed, house up-left/down-left/down, crossroads left then down-left, beach down-right, down-left as soon as Jack clears the small wall, down-right into the pier to the dock end. It mixes 42 dog lines (lab preset zigzag-fast: menus within 4 frames of frame-perfect, house and farm within 4, crossroads within 3, first beach cut up to 5 frames late, every pier cut that reaches the dock end), each weighted by how many simulated routes reach it. Presets, in two steps: pick your 1st cut (tight / mid / loose), then your 2nd cut (early = near edge by the dog, middle, late = far edge); the 2nd-cut odds count only routes with that 1st cut, and ★ marks the best 2nd cut for it. The 2nd cut comes after the dog has woken, so it never changes the dog's line: it only moves when Jack reaches the dock end. With the dock-end start it matters (it moves the stopwatch); with the beach-load start it changes nothing and the 1st cut alone decides. Start: Space when Jack stops at the dock end (recommended), or at the beach load. If Jack stops dead on the pier you touched the sleeping dog: restart. The bite-1 tap narrows down your dog line and the tool calls release or hold; with ±100 ms casts the pool gives ~13%; tight 1st cut ~15%, tight + early or middle 2nd cut ~17% (the beach-load start gives ~17% with the tight 1st cut alone). <i>old single line</i> is the earlier table: one dog line reached with the legacy menu timing and beach walk (not the zig-zag); it is ~40% only <i>if</i> you are on that exact line, and the line check shows how often you are.</p>
<p><b>Lucky Timer.</b> Every number there is the route-weighted share of all measured arrivals that would get the Power Nut with that plan, with your timing spread (start key + B press) as a Gaussian. <i>Release at 1st bite</i> and <i>Hold → 2nd bite</i> are fixed rules. <i>Smart zones</i> uses when the first bite comes as a clue: inside a green zone the first bite is more often the Nut than the second, so release; outside, hold through it and release the second bite. Zones are judged with the same spread. Whistle plans (mash C-right from READY, stop when whistle #k starts) appear once the lucky lab run is in; they cover the arrivals that make up ~93% of routes. Facing SE or E gives identical results (lab: same bite frame, same catch). The angler is Jack from your own frame catalog (tools/build_jack_assets.py), played on the game's fishing timeline: cast 0.53 s, plop 0.6 s after B, bite = 20-tick rod pull (your release window), reel 34 ticks, catch at bite + 0.9 s, Power Nut held up, then eaten. L3 switches to a stick figure.</p>
<p><b>2nd bite + tap.</b> Hold B through the first bite and tap Space the moment it bites. The tool works out which dog paths fit that bite time: if none of them gives a Nut on bite 2 it says DUD (reset now; ~40% of attempts, ~20 s saved each), otherwise it gives the Nut chance and when bite 2 should come. Every tap is kept (in this browser) and builds your personal profile: which arrivals you really land on and whether your casts land early or late. With "fit the plan to me" the cast time is re-aimed for you after each attempt. Simulated: a runner who always lands on dog path 2 goes from 1.8% to ~22% after 3 taps.</p>
<p><b>Dog paths.</b> All 36,014 measured carry routes reach the dock in one of 16 dog paths (the same dog + RNG sequence, entered at slightly different moments). Your logs pick the path and the moment; nothing is emulated in the browser.</p>
<p><b>Your keys and names.</b> Right-click any animation to edit it as <code>name:key</code> (e.g. <code>sniff-sitting:8</code>). <b>＋ group</b> makes a button meaning "either of these": <code>shoulder:j=shoulder-sitting+shoulder-standing</code>. A group log matches any member, and a switch between members is not counted as a change. Lumping look-alike pairs costs almost nothing (simulated: no measurable loss for the shoulder pair or sit/squat or bark/bork); lumping everything into a few coarse groups needs more logs. Saved in this browser; Settings exports/imports the file.</p>
<p><b>Stay awake.</b> The farmer naps 40 s after READY if nothing is pressed (player.c: 1200 idle updates), and a B press then only wakes him. Your south-east stick push resets that and changes nothing else (lab: RNG, dog and position identical for pushes from 0.07 s to 2 s, gentle or full tilt). The app cues it every 33 s (33–38.5 s, 66–71.5 s, …) until you cast; pushing anywhere in each window keeps every gap under 40 s. Never push after casting.</p>
<p><b>Holding.</b> For many frames the first bite is a fish but the second is the Nut. The plan table says which: hold B through the first bite and release at the second. Simulated with the 0–40 s tables: ~75–83% Nut with holding vs ~51–58% releasing at bite 1 (10–30 s observations).</p>
<p><b>Scrub bar (03).</b> Drag it to move the tool's dog through time like scrubbing a movie: left = into the past, right = ahead; the dog keeps playing at that offset. Sprites on the bar are the coming changes, so you can drag to just before one and let go as the TV gets there. Then fine-tune with <kbd>[</kbd> <kbd>]</kbd> (1 update = 2 VI) — they move the bar too. Double-click = back to 0. Settings → scrub bar range: smaller = finer.</p>
<p><b>Tap search.</b> The tap key (Settings; Enter by default, Space works too) means "the dog changed now" — any new pose or turn, no animation key. With tap search on, taps identify the dog as well as set the clock; a first tap at READY starts the clock. Simulated: 20 s of taps alone found the right dog 100% (auto-selected 97%) with a 1.0 VI clock; with "taps carry the facing" the dog is found by ~10 s. Animation keys find the dog faster, taps give the better clock — mix them freely.</p>
<p><b>Flickers.</b> Animations that usually last under ~0.35 s (sprint, squat, good-boy, sniff-sitting, flapper, transitions 56/64) and ones the dog never shows at the dock are hidden from the palette and their keys do nothing; the last tile shows them again. Hover a tile to see how long that animation usually stays on screen.</p>
<p><b>Logging.</b> The first log (animation + facing at READY) starts the clock. After that, log each new animation or turn as soon as it <i>starts on screen</i> — the tool assumes your usual delay (Settings → measure it). Late or wrong logs are not fatal: they only weigh less. Backspace undoes.</p>
<p><b>Potential dogs.</b> Each card is a path at a moment, with its share of the evidence. When one dog holds ≥95% it is selected automatically; you can click one yourself. Its time already includes your average logging delay; the nudge keys fix what is left by matching the tool's dog to the TV.</p>
<p><b>Cast · hold · release — what each phase does to the RNG</b> (src/game/player.c):</p>
<ul>
<li><b>Cast</b> (B pressed): the cast animation plays; the main loop's one rand() per game frame and the dog's own decisions keep drawing. Which game frame reads your B press decides everything after it — that is the sharp part.</li>
<li><b>Hold</b> (waiting, actionPhase 2): <i>handleFishingAction</i> adds one getRandomNumberInRange(0,400) per game frame; 0 = bite. The dog keeps drawing in between, which is why the tables come from the emulator, not from RNG arithmetic.</li>
<li><b>Bite / release</b> (phases 3–5): no fishing rolls. Releasing B in phases 3–5 sets phase 6; the catch (fish type, then the Nut roll !getRandomNumberInRange(0,50)) runs at the next animation boundaries, so every release in the first ${D.release.last + 1} polls of the bite gives the same catch. Later releases land one animation segment later (fish); holding through goes back to waiting and a new bite.</li>
</ul>
<p><b>Histogram.</b> Green bars: P(Nut) for a press at that moment, from your press spread and the clock spread. Yellow: extra chance by holding through the first bite (only where bite-2 tables exist). Orange shading: no cast table there yet.</p>
<p><b>Line-up methods (03).</b> Five ways to set the clock, shown side by side so you can compare them: <i>Logs only</i>; <i>Logs + speed fit</i> (also measures the console's speed from 30 s+ of logs); <i>Nudge by eye</i> (<kbd>[</kbd> <kbd>]</kbd>); <i>Tap on changes</i> (<kbd>Enter</kbd> each time the TV dog changes, no animation key — faster and steadier than a log); <i>Taps + logs speed</i>. A wrong console speed matters more the longer you observe (0.3% = ~5 VI after 60 s). "Save measured speed" stores each session's fit; "Use average" puts it into Settings. In practice mode the table also shows each method's true error, and every practice cast is kept for the running comparison.</p>
<p><b>After the cast</b> everything is on the controller: hold B, release when the bite shows. The release beeps are timed for the on-target bite. If the bite comes at another time, your press landed on another frame; the table row that lights up says whether to release or hold through to the second bite (where measured).</p>`;

/* ------------------------------------------------------------------ main loop */
/* stay awake: the farmer naps 40 s (1200 idle game updates) after READY; a south-east stick push resets that.
   Cue from 33 s after the first log unless a cast before 39 s is armed (fishing farmers do not nap). */
let awakeBeeped = -1;
/* windows every 33 s: [33, 38.5], [66, 71.5], ... after the first log. Pushing anywhere inside each window keeps
   every gap under 40 s; a cast before a window's end makes that push (and all later ones) unnecessary. */
function renderAwake() {
  const el = $('awakeCue');
  if (st.wall0 === null) { el.hidden = true; awakeBeeped = -1; return; }
  const s = (now() - st.wall0) / 1000, k = Math.floor(s / 33), w0 = 33 * k, w1 = w0 + 5.5;
  const castAt = st.armed ? (st.armed.wall - st.wall0) / 1000 : Infinity;
  const show = k >= 1 && s >= w0 && s < w1 && castAt >= w1 && !(st.armed && now() > st.armed.wall);
  el.hidden = !show;
  if (show) {
    el.textContent = `Push the stick SOUTH-EAST now (stay awake) — ${(w1 - s).toFixed(1)} s left`;
    if (awakeBeeped !== k) { awakeBeeped = k; [0, 150, 300].forEach(d => beepAt(now() + d, 520, 0.08)); }
  }
}
function frame() {
  const t = nowDVI();
  renderAwake();
  $('clock').textContent = st.wall0 === null ? 'clock not started' : `t+${(t * Core.viMs() / 1000).toFixed(2)} s · ${st.logs.length} logs`;
  document.querySelectorAll('#cards img.big').forEach(img => {
    const g = st.groups.find(x => x.id === img.dataset.id); if (!g) return;
    const s = Core.showAt(g.k, groupNow(g), -1);
    setSrc(img, sprite(s.base, s.dir));
    img.nextElementSibling.textContent = s.base >= 0 ? `${nm(s.base)} ${DIRNAME[s.dir]}` : '?';
  });
  renderSync(); renderTV(); tickCountdown(); drawHist();
  requestAnimationFrame(frame);
}
$('dataChip').textContent = `${D.checks.paths} dog paths · ${D.checks.arrivals} arrivals · data ${D.generated}`;
buildDirpad(); setFacing(0); renderKeysHelp(); update(); requestAnimationFrame(frame);
speedSummary(); practiceSummary();
window.HM64App = { st, update, logAD, logGroup, logD, get groups() { return groups; }, generate, arm, tap, setFacing, setMethod, practiceCast, clocksFor, METHODS };
})();
