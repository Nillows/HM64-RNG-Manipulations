# Lucky Timer route sources

Raw cast tables of extra Lucky Timer routes (lab data, no ROM/save content). `tools/route_tables.py` packs them into
`webapp/assets/lucky_routes.json`, which `tools/export_webapp.py` puts into the app (`D.lroutes`).

- `HM64_dogbeach_0d78b95b_casttable.json/.csv` — route **nodog-nohorse-no-pickup** (Thomas's name): save
  `nohorse-dogbeach-nopickup_0d78b95b` (no horse, dog waiting on the beach, rod in hand), frame-perfect base route,
  one dog line (wake draw 1184); every game frame 0–40 s after READY (pier end), bites 1 and 2. See
  `project_docs/HM64_DOGBEACH_SAVE.md`. Rebuild:

      python3 -I tools/route_tables.py webapp/assets/route_sources/HM64_dogbeach_0d78b95b_casttable.json \
        --id nodog-nohorse-no-pickup --label nodog-nohorse-no-pickup \
        --note "Save nohorse-dogbeach-nopickup_0d78b95b (Spring 4, no horse, dog waiting on the beach, rod in hand). One dog line: the frame-perfect base route (wake draw 1184). Off that line this table does not apply." \
        --anchor 'beach:beach entry:328' --anchor 'pier:READY (pier end):0'
