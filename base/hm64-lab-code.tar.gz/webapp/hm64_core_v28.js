/* HM64 Dog Oracle v28 core: dog-path search, clock estimate, cast/hold/release plans.
   No DOM. Loaded by the web app and by the node tests.  Units: VI = 1/60 of a game "update pair";
   one game update = 2 VI.  Path VI = the VI timeline of a dog path (see tools/export_webapp.py). */
(function (root) {
'use strict';
const OPEN = -1000000, NEG = -1e9;
const DEFAULTS = {
  updateMs: 33.053,        // one game update on the console (Thomas's measured value); 1 VI = half of it
  reactMuVI: 18,           // how long after an animation starts you press its key (VI)
  reactSdVI: 6,
  lagMinVI: 4, lagMaxVI: 45,
  tapMuVI: 13, tapSdVI: 3,  // a bare tap on "the TV dog changed now" (no key choice): ~215 ms
  firstLogMaxVI: 60,       // the first log is made within this many VI after READY
  dirTolerance: true,      // a neighbouring facing counts (with a penalty)
  pressSdVI: 1.0,          // how precisely you press B on the beat
  syncSdVI: 0.0,           // extra uncertainty you want to add after lining up
  leadMinS: 2.0, horizonS: 20,
  audio: true,
  method: 'logs',          // line-up method (see the app's section 03)
  practiceSpeedPct: 0,     // practice only: the virtual console runs this much faster than the setting
  hideFlickers: true,      // hide animations too short to log (< ~0.35 s) or never seen at the dock
  tapSearch: true,         // taps ("the dog changed now") also identify the dog, not only set the clock
  tapFacing: false,        // a tap also says the dog's facing (as set with the arrows / numpad)
  tapKey: 'Enter', faceKey: ' ',
  scrubS: 3,               // the line-up scrub bar spans -scrubS .. +scrubS seconds (smaller = finer)
};
const LL = { ADJ: -2.5, LATE: -3.0, MISS: -5.8 };
const ANY = { get: v => (v >= 0 ? 0 : undefined), has: v => v >= 0 };   // a bare tap accepts any visible pose

let D = null, P = [], H = [], C = null, S = Object.assign({}, DEFAULTS);

function viMs() { return S.updateMs / 2; }
function valueOf(base, dir) {
  const c = D.class_of[base + '_' + dir];
  return c === undefined ? -1 : dir * 1000 + c;
}
function adjDirs(d) { return [(d + 1) % 8, (d + 7) % 8]; }

function buildArrays(runs, lo, hi, openAt) {
  const n = hi - lo;
  const a = { lo, end: hi, val: new Int32Array(n).fill(-1), dir: new Int8Array(n).fill(-1),
              base: new Int16Array(n).fill(-1), rs: new Int32Array(n).fill(OPEN), fs: new Int32Array(n).fill(OPEN) };
  for (const [t0, t1, scr, cls, base] of runs) {
    const st = t0 <= openAt ? OPEN : t0;
    for (let t = Math.max(t0, lo); t < Math.min(t1, hi); t++) {
      const i = t - lo;
      a.val[i] = scr < 0 || cls < 0 ? -1 : scr * 1000 + cls;
      a.dir[i] = scr; a.base[i] = base; a.rs[i] = st;
    }
  }
  let cur = OPEN;
  for (let i = 0; i < n; i++) {
    if (i > 0 && a.dir[i] !== a.dir[i - 1]) cur = lo + i;
    a.fs[i] = cur;
  }
  return a;
}

function prepare(data, settings) {
  D = data; if (settings) Object.assign(S, settings);
  P = D.paths.map(p => buildArrays(p.runs, 0, p.hi, p.lo));
  H = [];
  D.arrivals.forEach(([k, o, w, head], i) => {
    if (head && head.length) {
      const runs = head.map(([t0, t1, s, c, b]) => [t0 + o, t1 + o, s, c, b]);
      const end = Math.max(...runs.map(r => r[1]));
      H[i] = buildArrays(runs, o + 1, end, o + 1);
    }
  });
  buildCandidates();
}

function buildCandidates() {
  const U = Math.max(1, Math.round(S.firstLogMaxVI));
  const map = new Map(), list = [];
  D.arrivals.forEach(([k, o, w], i) => {
    for (let u = 1; u <= U; u++) {
      const tau0 = o + u, hd = H[i] ? i : -1;
      const key = hd >= 0 ? 'h' + i + ':' + u : k + ':' + tau0;
      let c = map.get(key);
      if (!c) { c = { k, tau0, prior: 0, head: hd }; map.set(key, c); list.push(c); }
      c.prior += w / U;
    }
  });
  const n = list.length;
  C = { n, k: new Int16Array(n), tau0: new Int32Array(n), head: new Int16Array(n),
        lp: new Float64Array(n), ll: new Float64Array(n) };
  list.forEach((c, j) => { C.k[j] = c.k; C.tau0[j] = c.tau0; C.head[j] = c.head; C.lp[j] = Math.log(c.prior); });
}

function arraysAt(j, t) {
  const h = C.head[j];
  if (h >= 0) { const a = H[h]; if (t >= a.lo && t < a.end) return a; }
  return P[C.k[j]];
}
function at(a, t, f) { const i = t - a.lo; return i >= 0 && i < a.val.length ? a[f][i] : (f === 'rs' || f === 'fs' ? OPEN : -1); }

/* a log: {kind:'AD'|'D', dir, base, value, dVI (VI since the first log), first:bool} */
function prepLog(lg) {
  const acc = new Map();
  if (lg.kind === 'AD') {
    const bases = lg.bases && lg.bases.length ? lg.bases : [lg.base];     // a group log: any of its animations
    for (const b of bases) { const v = valueOf(b, lg.dir); if (v >= 0) acc.set(v, 0); }
    if (S.dirTolerance) for (const b of bases) for (const d of adjDirs(lg.dir)) { const v = valueOf(b, d); if (v >= 0 && !acc.has(v)) acc.set(v, LL.ADJ); }
    lg._group = bases.length > 1;
  } else if (lg.kind === 'T') {                         // a tap: "the dog changed now" (optionally: and now faces dir)
    if (lg.dir === undefined || lg.dir === null || lg.dir < 0) lg._any = true;
    else { acc.set(lg.dir, 0); if (S.dirTolerance) for (const d of adjDirs(lg.dir)) acc.set(d, LL.ADJ); }
  } else {
    acc.set(lg.dir, 0);
    if (S.dirTolerance) for (const d of adjDirs(lg.dir)) acc.set(d, LL.ADJ);
  }
  lg._acc = acc;
  return lg;
}

function logLik(j, lg, want) {
  const T = lg.kind === 'T';
  const tau = C.tau0[j] + lg.dVI, f = lg.kind === 'AD' ? 'val' : 'dir', sf = lg.kind === 'D' ? 'fs' : 'rs';
  const acc = lg._any ? ANY : lg._acc;
  const mu = T ? S.tapMuVI : S.reactMuVI, sd = Math.max(1, T ? S.tapSdVI : S.reactSdVI);
  const lagMax = T ? Math.max(S.tapMuVI + 5 * S.tapSdVI, 20) : S.lagMaxVI;
  if (lg.first) {
    let best = LL.MISS;
    for (let t = Math.floor(tau - lagMax); t <= Math.floor(tau); t++) {
      const m = acc.get(at(arraysAt(j, t), t, f));
      if (m !== undefined && m > best) best = m;
    }
    return best;
  }
  let best = LL.MISS, onset = null;
  let t = Math.floor(tau - S.lagMinVI + 2);
  const stop = Math.floor(tau - lagMax - 2);
  while (t >= stop) {
    const a = arraysAt(j, t);
    const m = acc.get(at(a, t, f));
    let st = at(a, t, sf);
    if (m !== undefined && lg._group) {               // a change inside the group is not a visible change for the runner
      while (st !== OPEN && st - 1 >= 0) {
        const ap = arraysAt(j, st - 1);
        if (!acc.has(at(ap, st - 1, f))) break;
        const prev = at(ap, st - 1, sf);
        if (prev === OPEN || prev >= st) { st = prev === OPEN ? OPEN : st; break; }
        st = prev;
      }
    }
    if (m !== undefined) {
      const lag = tau - st;
      let l;
      if (st === OPEN || lag > lagMax + 2) l = LL.LATE;               // seen, but its start is not a fresh change
      else { const z = (lag - mu) / sd; l = Math.max(-0.5 * z * z, LL.LATE); }
      if (m + l > best) { best = m + l; onset = l > LL.LATE ? st : null; }
    }
    t = (st === OPEN || st > t) ? t - 1 : st - 1;                       // jump to the run before
  }
  return want ? { l: best, onset } : best;
}

function addLog(lg) { prepLog(lg); for (let j = 0; j < C.n; j++) C.ll[j] += logLik(j, lg); }
let lastLogs = [];
function recompute(logs) { C.ll.fill(0); lastLogs = logs; for (const lg of logs) addLog(lg); }

/* how well one candidate explains every log: good / weak (late or neighbouring facing) / miss */
function fitReport(j) {
  const r = { n: 0, good: 0, weak: 0, miss: 0, perLog: [] };
  for (const lg of lastLogs) {
    const l = logLik(j, lg);
    r.n++; r.perLog.push(l);
    if (l <= LL.MISS + 1e-9) r.miss++; else if (l <= LL.LATE + 1e-9) r.weak++; else r.good++;
  }
  return r;
}

/* least squares y = A + B x (B fixed to 1 when !freeRate) */
function lineFit(xs, ys, freeRate, fixB) {
  const n = xs.length;
  if (n === 0) return null;
  let A, B = fixB || 1;
  if (fixB) freeRate = false;
  const mx = xs.reduce((a, b) => a + b, 0) / n, my = ys.reduce((a, b) => a + b, 0) / n;
  if (freeRate && n >= 3) {
    let sxx = 0, sxy = 0;
    for (let i = 0; i < n; i++) { sxx += (xs[i] - mx) ** 2; sxy += (xs[i] - mx) * (ys[i] - my); }
    if (sxx > 0) B = sxy / sxx;
  }
  A = my - B * mx;
  let rss = 0;
  for (let i = 0; i < n; i++) rss += (ys[i] - A - B * xs[i]) ** 2;
  const dof = Math.max(1, n - (freeRate ? 2 : 1)), sd = Math.sqrt(rss / dof);
  let sxx = 0; for (let i = 0; i < n; i++) sxx += (xs[i] - mx) ** 2;
  return { A, B, sd, n, mx, sxx, span: n ? Math.max(...xs) - Math.min(...xs) : 0,
           seAt: x => sd * Math.sqrt(1 / n + (freeRate && sxx > 0 ? (x - mx) ** 2 / sxx : 0)),
           seB: freeRate && sxx > 0 ? sd / Math.sqrt(sxx) : null };
}

/* clock from the logs of candidate j: each log = its animation's start + your delay.
   path VI = A + B * (tool VI since the first log).  Speed is fitted only over >= minSpanVI. */
function fitLogsClock(j, freeRate, minSpanVI = 1800) {
  const xs = [], ys = [];
  for (const lg of lastLogs) {
    if (lg.first) continue;
    const r = logLik(j, lg, true);
    if (r.onset !== null) { xs.push(lg.dVI); ys.push(r.onset + (lg.kind === 'T' ? S.tapMuVI : S.reactMuVI)); }
  }
  if (xs.length < 2) return null;
  const span = Math.max(...xs) - Math.min(...xs);
  const free = freeRate && xs.length >= 6 && span >= minSpanVI;
  let f = lineFit(xs, ys, free);
  const keep = xs.map((x, i) => Math.abs(ys[i] - f.A - f.B * x) <= Math.max(3 * f.sd, 6));
  if (keep.some(k => !k) && keep.filter(Boolean).length >= 3)
    f = lineFit(xs.filter((_, i) => keep[i]), ys.filter((_, i) => keep[i]), free);
  f.rateFitted = free;
  return f;
}

/* visible changes of path k (any new sprite class or facing) */
function changesIn(k, t0, t1) {
  const a = P[k], out = [];
  for (let t = Math.max(1, Math.floor(t0)); t <= Math.min(a.val.length - 1, Math.ceil(t1)); t++)
    if (a.val[t] !== a.val[t - 1]) out.push(t);
  return out;
}
/* clock from bare taps ("the TV dog changed now"): each tap is matched to the nearest predicted change
   of path k, given a starting clock (a0, b0).  Speed fitted once the taps span >= minSpanVI. */
function fitTapsClock(k, a0, b0, taps, minSpanVI = 1200, fixB) {
  let a = a0, b = b0, f = null;
  for (let it = 0; it < 3; it++) {
    const xs = [], ys = [], used = [];
    for (const x of taps) {
      const guess = a + b * x - S.tapMuVI;
      const ch = changesIn(k, guess - 30, guess + 30);
      if (!ch.length) continue;
      const c = ch.reduce((p, q) => Math.abs(q - guess) < Math.abs(p - guess) ? q : p);
      xs.push(x); ys.push(c + S.tapMuVI); used.push(c);
    }
    if (!xs.length) return null;
    const span = Math.max(...xs) - Math.min(...xs);
    const free = !fixB && xs.length >= 3 && span >= minSpanVI;
    f = lineFit(xs, ys, free, fixB);
    f.rateFitted = free; f.matched = xs.length; f.ignored = taps.length - xs.length;
    a = f.A; b = f.B;
  }
  return f;
}

/* posterior grouped into "potential dogs": same path, start times within 4 VI of each other */
function groups(maxGroups = 12) {
  let mx = NEG;
  for (let j = 0; j < C.n; j++) { const v = C.lp[j] + C.ll[j]; if (v > mx) mx = v; }
  const w = new Float64Array(C.n); let Z = 0;
  for (let j = 0; j < C.n; j++) { w[j] = Math.exp(C.lp[j] + C.ll[j] - mx); Z += w[j]; }
  const idx = [];
  for (let j = 0; j < C.n; j++) if (w[j] / Z > 1e-5) idx.push(j);
  idx.sort((a, b) => C.k[a] - C.k[b] || C.tau0[a] - C.tau0[b]);
  const out = [];
  let g = null;
  for (const j of idx) {
    if (!g || C.k[j] !== g.k || C.tau0[j] - g.last > 4) {
      g = { k: C.k[j], mass: 0, s1: 0, s2: 0, first: C.tau0[j], last: C.tau0[j], members: [], bestLL: NEG };
      out.push(g);
    }
    const p = w[j] / Z;
    g.mass += p; g.s1 += p * C.tau0[j]; g.s2 += p * C.tau0[j] * C.tau0[j]; g.last = C.tau0[j]; g.members.push(j);
    if (g.bestJ === undefined || w[j] > w[g.bestJ]) g.bestJ = j;
    g.bestLL = Math.max(g.bestLL, C.ll[j]);
  }
  for (const x of out) {
    x.mean = x.s1 / x.mass; x.sd = Math.sqrt(Math.max(0, x.s2 / x.mass - x.mean * x.mean));
    x.path = D.paths[x.k]; x.id = x.k + ':' + Math.round(x.first);
  }
  out.sort((a, b) => b.mass - a.mass);
  return out.slice(0, maxGroups);
}

/* what the dog of path k shows at path VI t (for display) */
function showAt(k, t, head) {
  const a = (head >= 0 && H[head] && t >= H[head].lo && t < H[head].end) ? H[head] : P[k];
  const ti = Math.floor(t);
  return { base: at(a, ti, 'base'), dir: at(a, ti, 'dir'), val: at(a, ti, 'val'), start: at(a, ti, 'rs') };
}
function nextChanges(k, t, n, maxVI) {
  const a = P[k], out = [];
  let ti = Math.floor(t), cur = at(a, ti, 'val');
  for (let x = ti + 1; x < Math.min(a.val.length, ti + maxVI) && out.length < n; x++) {
    const v = a.val[x];
    if (v !== cur) { out.push({ t: x, base: a.base[x], dir: a.dir[x], val: v }); cur = v; }
  }
  return out;
}

/* ---------------------------------------------------------- cast / hold / release */
function phi(z) { // standard normal CDF
  const t = 1 / (1 + 0.2316419 * Math.abs(z)), d = 0.3989423 * Math.exp(-z * z / 2);
  const p = d * t * (0.3193815 + t * (-0.3565638 + t * (1.781478 + t * (-1.821256 + t * 1.330274))));
  return z > 0 ? 1 - p : p;
}
function castAt(k, v) {
  const c = D.casts[k];
  if (!c || v < c.lo || v >= c.lo + c.n1.length) return null;
  const i = v - c.lo, n1 = c.n1[i];
  if (n1 === '.') return null;
  return { n1: n1 === '1', b1: c.b1[i], n2: c.n2 ? (c.n2[i] === '.' ? null : c.n2[i] === '1') : null,
           b2: c.b2 && c.b2.length ? c.b2[i] : -1 };
}
/* P(press lands in VI v) for an aimed press at continuous path time x with sd s */
function pressDist(x, s) {
  s = Math.max(0.3, s);
  const out = [];
  for (let v = Math.floor(x - 4 * s) - 1; v <= Math.ceil(x + 4 * s) + 1; v++) {
    const p = phi((v + 1 - x) / s) - phi((v - x) / s);
    if (p > 1e-4) out.push([v, p]);
  }
  return out;
}
/* P(Nut) for a press aimed at path time x on path k: bite-1 release, plus bite-2 (hold) where known */
function nutChance(k, x, s, allowHold) {
  let p1 = 0, p12 = 0, unk = 0;
  for (const [v, p] of pressDist(x, s)) {
    const c = castAt(k, v);
    if (!c) { unk += p; continue; }
    if (c.n1) { p1 += p; p12 += p; } else if (allowHold && c.n2) p12 += p;
  }
  return { p1, p: allowHold ? p12 : p1, unk };
}
/* histogram over press times for a set of weighted groups.
   gs: [{k, mass, nowVI (path VI now), sd}], returns bins every 1 VI from leadMin to horizon */
function histogram(gs, opt) {
  const dt = 1, n = Math.round(S.horizonS * 1000 / viMs());
  const bins = [];
  const mt = gs.reduce((a, g) => a + g.mass, 0) || 1;
  for (let i = 0; i <= n; i++) {
    let p = 0, p1 = 0, unk = 0;
    for (const g of gs) {
      const s = Math.sqrt(g.sd * g.sd + S.pressSdVI * S.pressSdVI + S.syncSdVI * S.syncSdVI);
      const r = nutChance(g.k, g.nowVI + i * dt * (g.rate || 1), s, opt && opt.hold);
      p += g.mass / mt * r.p; p1 += g.mass / mt * r.p1; unk += g.mass / mt * r.unk;
    }
    bins.push({ dVI: i * dt, p, p1, unk });
  }
  return bins;
}
function pickTargets(bins, n = 3) {
  const lead = Math.round(S.leadMinS * 1000 / viMs());
  const cand = bins.filter(b => b.dVI >= lead).slice().sort((a, b) => b.p - a.p);
  const out = [];
  for (const b of cand) {
    if (b.p <= 0.02) break;
    if (out.every(o => Math.abs(o.dVI - b.dVI) > 30)) out.push(b);
    if (out.length >= n) break;
  }
  return out.sort((a, b) => a.dVI - b.dVI);
}
/* per-frame table for an aimed press: where it may land, what each landing does (cast/hold/release) */
function plan(k, x, s) {
  const rows = [];
  for (const [v, p] of pressDist(x, s)) {
    const c = castAt(k, v);
    const last = rows[rows.length - 1];
    if (last && c && last.c && last.c.b1 + last.v === c.b1 + v && last.c.n1 === c.n1) { last.p += p; last.vis.push(v); continue; }
    rows.push({ v, vis: [v], p, c });
  }
  for (const r of rows) {
    if (!r.c) { r.action = 'unknown'; continue; }
    r.bite1VI = r.c.b1 + r.v;                                        // path VI the first bite shows
    r.bite2VI = r.c.b2 >= 0 ? r.c.b2 + r.v : null;
    r.action = r.c.n1 ? 'release' : (r.c.n2 ? 'hold' : (r.c.n2 === false ? 'none' : 'fish?'));
  }
  return rows;
}

const api = { DEFAULTS, LL, OPEN, prepare, buildCandidates, settings: S, viMs, valueOf, prepLog, addLog, recompute,
  logLik, fitReport, lineFit, fitLogsClock, fitTapsClock, changesIn,
  groups, showAt, nextChanges, castAt, pressDist, nutChance, histogram, pickTargets, plan, phi,
  get data() { return D; }, get cands() { return C; } };
if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.HM64Core = api;
})(typeof window !== 'undefined' ? window : globalThis);
