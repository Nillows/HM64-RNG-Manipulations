/* HM64 Lucky Timer (v29): blind attempts. Start a stopwatch at READY, optionally mash C-right until k whistles,
   cast on the beep, release at the first bite only inside the release zones (else hold for the second bite),
   reset and try again. No observation. Data: the no-whistle cast tables (casts + arrivals) and, when the lucky
   lab run is in, the mash-whistle tables (D.lucky). */
(function (root) {
'use strict';

/* ================================================================== computation (also runs in node) */
const LuckyCore = (function () {
  const TMAX = 2700;                 // 45 s of stopwatch time (VI)
  const VMAX = 2900;                 // path VI kept (45 s + arrival offsets + kernel)
  let D = null, viMs = 16.5265, plans = [], cache = new Map();

  function denseSeries(v0, n) {
    return { v0, n1: new Int8Array(n).fill(-1), b1: new Int16Array(n).fill(-1), n2: new Int8Array(n).fill(-1),
             b2: new Int16Array(n).fill(-1), len: n };
  }
  function fromCasts(c) {                                          // no-whistle table of one dog path (path VI)
    const n = Math.max(0, Math.min(c.n1.length, VMAX - c.lo));
    const s = denseSeries(c.lo, n);
    for (let i = 0; i < n; i++) {
      const a = c.n1[i];
      if (a === '.') continue;
      s.n1[i] = a === '1' ? 1 : 0; s.b1[i] = c.b1[i];
      if (c.n2 && c.n2[i] !== undefined && c.n2[i] !== '.') { s.n2[i] = c.n2[i] === '1' ? 1 : 0; s.b2[i] = c.b2[i]; }
    }
    return s;
  }
  function fromLucky(G, x) {                                       // mash table on the cast grid (rep polls -> path VI)
    const vEnd = Math.min(VMAX, G[Math.min(G.length - 1, x.i0 + x.n1.length - 1)] + 2);
    const v0 = G[x.i0] + 1, s = denseSeries(v0, Math.max(0, vEnd - v0));
    for (let i = 0; i < x.n1.length; i++) {
      const v = G[x.i0 + i] + 1 - v0;
      if (v >= s.len || x.n1[i] === '.') continue;
      s.n1[v] = x.n1[i] === '1' ? 1 : 0; s.b1[v] = x.b1[i];
      if (x.n2[i] !== undefined && x.n2[i] !== '.') { s.n2[v] = x.n2[i] === '1' ? 1 : 0; s.b2[v] = x.b2[i]; }
    }
    return s;
  }
  /* Plans for a pace group (D.pace: route weights split by the runner's slack before the dog lands) and a
     start anchor: 'ready' (t = 1 at READY) or 'dog' (t = 1 when the dog is put down; READY of a route with beach
     wait D is then t = 17 + 2*(D//2), its first possible cast). The whistle plans exist for 'ready' + all routes. */
  /* Routes: 'carry' = the Spring 9 dog-carry route (the lab's arrival pool, pace presets, dog-landing / READY start);
     D.lroutes = extra routes with their own cast table (one dog line each, tools/route_tables.py) and their own start
     anchors ({id, label, r0}: READY sits r0 VI after the start event, so path VI = t - r0). All no-whistle plans share
     one series list (dog paths, then the route tables), so the smoothing cache stays valid across routes. */
  let series0 = null, wplans = [], sel = { route: 'carry', pace: 'all', anchor: 'ready' };
  const setCache = new Map();
  const CARRY = { id: 'carry', label: 'Spring 9 dog carry (lab arrival pool)', anchors: [{ id: 'dog', label: 'when the dog lands' }, { id: 'ready', label: 'at READY' }] };
  function routes() { return [CARRY].concat(D && D.lroutes ? D.lroutes : []); }
  function routeOf(id) { return routes().find(r => r.id === id) || CARRY; }
  function prepare(data, vims, selection) {
    D = data; viMs = vims || viMs; cache = new Map(); setCache.clear();
    series0 = D.casts.map(c => c ? fromCasts(c) : null);
    for (const r of D.lroutes || []) {
      if (r.lines) { r.sidxs = r.lines.map(c => { series0.push(c ? fromCasts(c) : null); return series0.length - 1; }); r.sidx = r.sidxs[0]; }
      else { r.sidx = series0.length; series0.push(fromCasts(r.casts)); }
    }
    wplans = [];
    const L = D.lucky;
    if (L && L.plans) {
      const tot = D.arrivals.reduce((a, x) => a + x[2], 0) || 1;
      for (const p of L.plans) {
        const series = p.series.map(x => fromLucky(L.G, x));
        const variants = p.scen.map(([sid, o, w, period, starts]) => ({ w, o, s: sid, period, starts, minT: 1 }));
        const W = variants.reduce((a, x) => a + x.w, 0);
        // stopwatch time of the last whistle's end (typical) and the earliest cast with data
        const ends = variants.map(x => ({ w: x.w, t: (x.starts.length ? x.starts[x.starts.length - 1] + 41 : 0) - x.o + 1 }))
          .sort((a, b) => a.t - b.t);
        let acc = 0, med = 0;
        for (const e of ends) { acc += e.w; if (acc >= W / 2) { med = e.t; break; } }
        const firstT = Math.min(...variants.map(x => series[x.s].v0 - x.o));
        wplans.push({ k: p.k, label: `${p.k} whistle${p.k > 1 ? 's' : ''}`, series, variants, cover: W / tot,
                      firstT: Math.max(1, firstT), whistleEnd: med, pace: 'all', anchor: 'ready' });
      }
    }
    return select(selection || sel);
  }
  /* v29.9: routes with `members` (tools/zigzag_routes.py) build any combination of their `axes` on demand.
     id = 'all' or axis-option pairs in axis order joined by '+', e.g. 'house-fast+cut1-tight+cut2-early'. */
  function axId(R, ax) {
    const parts = (R.axes || []).filter(A => ax[A.id]).map(A => A.id + '-' + ax[A.id]);
    return parts.length ? parts.join('+') : 'all';
  }
  function parseAx(R, id) {
    if (id === 'all') return {};
    const ax = {};
    for (const part of String(id).split('+')) {
      const i = part.indexOf('-'), A = (R.axes || []).find(a => a.id === part.slice(0, i));
      if (i < 0 || !A || !A.opts.some(o => o.id === part.slice(i + 1))) return null;
      ax[A.id] = part.slice(i + 1);
    }
    for (const A of R.axes) if (A.needs && ax[A.id] && !ax[A.needs]) return null;
    return ax;
  }
  function groupOf(R, id) {
    if (!R.members) return (R.groups || []).find(g => g.id === id) || null;
    R.groupCache = R.groupCache || new Map();
    if (R.groupCache.has(id)) return R.groupCache.get(id);
    const ax = parseAx(R, id);
    if (!ax) return null;
    const cols = R.members_cols, ci = name => cols.indexOf(name), iw = ci('w'), il = ci('line'), io = ci('k_off'), ir = ci('ready_rel');
    const tests = Object.entries(ax).map(([a, o]) => { const A = R.axes.find(x => x.id === a); return [ci(a), A.opts.findIndex(x => x.id === o)]; });
    let W = 0, Wc = 0;
    const v = { pier: new Map(), beach: new Map() }, sel = [];
    for (const m of R.members) if (tests.every(([c, k]) => m[c] === k)) { sel.push(m); W += m[iw]; if (m[il] >= 0) Wc += m[iw]; }
    if (!(W > 0)) { R.groupCache.set(id, null); return null; }
    const add = (map, key, w) => map.set(key, (map.get(key) || 0) + w);
    for (const m of sel) {
      if (m[il] < 0) continue;
      add(v.pier, m[il] + ':' + m[io] + ':1', m[iw] / W);
      add(v.beach, m[il] + ':' + (m[io] - m[ir]) + ':' + (m[ir] + 1), m[iw] / W);
    }
    const lst = map => [...map].map(([k, w]) => { const [li, o, mt] = k.split(':').map(Number); return [li, w, o, mt]; });
    const names = Object.entries(ax).map(([a, o]) => { const A = R.axes.find(x => x.id === a); return (A.short || A.id) + ' ' + A.opts.find(x => x.id === o).label.toLowerCase(); });
    const last = R.axes.filter(A => ax[A.id]).pop();
    const g = { id, ax, label: names.length ? names.join(' · ') : 'All', band: last ? last.opts.find(x => x.id === ax[last.id]).band : 'every route',
                desc: names.length ? names.join('; ') : 'All simulated routes of this preset', share: W, cover: Wc / W,
                v: { pier: lst(v.pier), beach: lst(v.beach) } };
    R.groupCache.set(id, g);
    (R.groups = R.groups || []).filter(x => x.id === id).length || R.groups.push(g);
    return g;
  }
  const groupFor = (R, ax) => groupOf(R, axId(R, ax));
  function groups() {
    const R = routeOf(sel.route);
    if (R.groups) return R.groups;                                 // multi-line route tables: their own presets
    return D && D.pace ? D.pace.groups : [{ id: 'all', label: 'All' }];
  }
  function norm(selection) {
    const x = { route: (selection && selection.route) || 'carry', pace: (selection && selection.pace) || 'all',
                anchor: (selection && selection.anchor) || 'ready' };
    const R = routeOf(x.route);
    x.route = R.id;
    if (R.id !== 'carry') {                                        // one dog line: no pace groups; line mixes: their presets
      if (!(R.members ? groupOf(R, x.pace) : R.groups && R.groups.some(g => g.id === x.pace))) x.pace = 'all';
      if (!R.anchors.some(a => a.id === x.anchor)) x.anchor = R.anchors[0].id;
      return x;
    }
    if (!(D && D.pace)) x.anchor = 'ready';
    if (x.anchor !== 'dog' && x.anchor !== 'ready') x.anchor = D && D.pace ? 'dog' : 'ready';
    if (!(D && D.pace && D.pace.groups.some(g => g.id === x.pace))) x.pace = 'all';   // carry presets (not the current route's)
    return x;
  }
  function select(selection) {
    sel = norm(selection);
    plans = planSet(sel.pace, sel.anchor, sel.route);
    return plans;
  }
  function planSet(pace, anchor, route) {                          // cached plan list for a route + pace group + anchor
    const x = norm({ pace, anchor, route }), key = x.route + '/' + x.pace + '/' + x.anchor;
    if (!setCache.has(key) && x.route !== 'carry' && (routeOf(x.route).groups || routeOf(x.route).members)) {
      const R = routeOf(x.route), A0 = R.anchors.find(a => a.id === x.anchor);
      const g = groupOf(R, x.pace) || groupOf(R, 'all') || R.groups[0];
      const var0 = (g.v[A0.id] || []).filter(([li]) => series0[R.sidxs[li]])
        .map(([li, w, o, mt]) => ({ w, o, s: R.sidxs[li], period: 0, starts: [], minT: mt }));
      const firstT = var0.length ? Math.min(...var0.map(v => v.minT)) : 1;
      setCache.set(key, [{ k: 0, label: 'No whistle', series: series0, variants: var0, cover: g.cover, firstT,
                           whistleEnd: 0, pace: g.id, anchor: x.anchor, route: R.id, r0: A0.r0 }]);
    }
    if (!setCache.has(key) && x.route !== 'carry') {
      const R = routeOf(x.route), A0 = R.anchors.find(a => a.id === x.anchor);
      const var0 = [{ w: 1, o: -A0.r0, s: R.sidx, period: 0, starts: [], minT: A0.r0 + 1 }];
      setCache.set(key, [{ k: 0, label: 'No whistle', series: series0, variants: var0, cover: 1, firstT: A0.r0 + 1,
                           whistleEnd: 0, pace: 'all', anchor: x.anchor, route: R.id, r0: A0.r0 }]);
    }
    if (!setCache.has(key)) {
      const g = D.pace ? D.pace.groups.find(y => y.id === x.pace) : null, dog = x.anchor === 'dog';
      const src = g ? g[x.anchor] : D.arrivals;
      const var0 = src.filter(a => series0[a[0]]).map(a => ({ w: a[2], o: a[1], s: a[0], period: 0, starts: [],
                                                              minT: dog ? (D.pace.lag0 || 16) + 1 + (a[3] || 0) : 1 }));
      const p0 = { k: 0, label: 'No whistle', series: series0, variants: var0, cover: 1,
                   firstT: dog ? (D.pace.lag0 || 16) + 1 : 1, whistleEnd: 0, pace: x.pace, anchor: x.anchor, route: 'carry',
                   r0: dog ? (D.pace.lag0 || 16) : 0 };
      setCache.set(key, [p0].concat(x.pace === 'all' && !dog ? wplans : []));
    }
    return setCache.get(key);
  }
  /* the cast-landing spread: a number (Gaussian SD in VIs) or, for personalized suggestions (v29.10), a measured kernel
     {id, k, r, sd}: k[d + r] = P(the cast lands d VIs after the aim), any shape (lopsided for a late or early habit) */
  const sigKey = s => (typeof s === 'object' ? s.id : s.toFixed(3));
  const sdOf = s => (typeof s === 'object' ? s.sd : s);
  function kernel(sig) {
    if (sig && typeof sig === 'object') return { k: sig.k, r: sig.r };
    sig = Math.max(0.5, sig);
    const r = Math.ceil(3 * sig), k = new Float32Array(2 * r + 1);
    let z = 0;
    for (let d = -r; d <= r; d++) { k[d + r] = Math.exp(-0.5 * (d / sig) ** 2); z += k[d + r]; }
    for (let i = 0; i < k.length; i++) k[i] /= z;
    return { k, r };
  }
  /* per series: Gaussian-weighted mean of the known outcomes around every path VI (bite1 and hold) */
  function smoothed(plan, sig) {
    const key = plan.k + ':' + (typeof sig === 'object' ? sig.id : sig.toFixed(2));
    if (cache.has(key)) return cache.get(key);
    const { k, r } = kernel(sig);
    const out = plan.series.map(s => {
      if (!s) return null;
      const n = s.len, a1 = new Float32Array(n), d1 = new Float32Array(n), a2 = new Float32Array(n), d2 = new Float32Array(n);
      for (let i = 0; i < n; i++) {
        const x1 = s.n1[i], x2 = s.n2[i];
        if (x1 < 0 && x2 < 0) continue;
        const lo = Math.max(0, i - r), hi = Math.min(n - 1, i + r);
        for (let j = lo; j <= hi; j++) {
          const kw = k[i - j + r];                               // aim j, landing i: offset i - j
          if (x1 >= 0) { a1[j] += kw * x1; d1[j] += kw; }
          if (x2 >= 0) { a2[j] += kw * x2; d2[j] += kw; }
        }
      }
      return { a1, d1, a2, d2 };
    });
    cache.set(key, out);
    return out;
  }
  /* route-weighted P(Nut) for a cast at stopwatch VI t (t = 1 is READY): pol 'bite1' | 'hold' */
  const memos = new WeakMap();
  function memo(plan, key, fn) {          // per variant list: copies of a plan with other weights get their own cache
    let m = memos.get(plan.variants);
    if (!m) { m = new Map(); memos.set(plan.variants, m); }
    if (!m.has(key)) { if (m.size > 24) m.clear(); m.set(key, fn()); }
    return m.get(key);
  }
  function curve(plan, sig, pol) { return memo(plan, 'c:' + pol + ':' + sigKey(sig), () => curveRaw(plan, sig, pol)); }
  function curveRaw(plan, sig, pol) {
    const sm = smoothed(plan, sig), P = new Float32Array(TMAX + 1).fill(NaN), C = new Float32Array(TMAX + 1);
    const W = plan.variants.reduce((a, x) => a + x.w, 0) || 1;
    const num = new Float64Array(TMAX + 1), den = new Float64Array(TMAX + 1);
    for (const x of plan.variants) {
      const s = plan.series[x.s], m = sm[x.s];
      if (!s) continue;
      const a = pol === 'hold' ? m.a2 : m.a1, d = pol === 'hold' ? m.d2 : m.d1;
      for (let t = Math.max(1, x.minT || 1); t <= TMAX; t++) {
        const i = t + x.o - s.v0;
        if (i < 0 || i >= s.len || d[i] < 0.05) continue;
        num[t] += x.w * a[i] / d[i]; den[t] += x.w;
      }
    }
    for (let t = 1; t <= TMAX; t++) if (den[t] > 0) { P[t] = num[t] / den[t]; C[t] = den[t] / W * plan.cover; }
    return { P, C };
  }
  /* zone policy at cast time T: release at bite 1 only in zones where bite-1 Nuts outweigh bite-2 Nuts
     (bite times seen with spread sigB). Returns value (+ zones, bite densities in bins of binVI after READY,
     and the weighted scenarios when full). Typed arrays only: it runs a few hundred times per plan. */
  const ZB = 6;
  let zbuf = null;
  function zoneAt(plan, T, sig, sigB, full) {
    const binVI = ZB; sigB = sdOf(sigB || sig);
    const { k, r } = kernel(sig);
    if (!plan.maxBite) {
      let m = 0;
      for (const s of plan.series) if (s) for (let i = 0; i < s.len; i++) { if (s.b1[i] > m) m = s.b1[i]; if (s.b2[i] > m) m = s.b2[i]; }
      plan.maxBite = m;
    }
    const nb = Math.ceil((TMAX + 3 * r + plan.maxBite + 400) / binVI) + 4;
    if (!zbuf || zbuf.nb < nb) zbuf = { nb, d1n: new Float64Array(nb), d1f: new Float64Array(nb), d2n: new Float64Array(nb), s1: new Float64Array(nb), s2: new Float64Array(nb), pin: new Float64Array(nb) };
    const { d1n, d1f, d2n, s1, s2, pin } = zbuf;
    d1n.fill(0, 0, nb); d1f.fill(0, 0, nb); d2n.fill(0, 0, nb); s1.fill(0, 0, nb); s2.fill(0, 0, nb);
    let W = 0, hiBin = 0;
    const each = fn => {
      for (const x of plan.variants) {
        const s = plan.series[x.s];
        if (!s) continue;
        const c0 = T + x.o - s.v0, dmin = Math.max(-r, (x.minT || 1) - T);
        let z = 0;
        for (let d = dmin; d <= r; d++) { const i = c0 + d; if (i >= 0 && i < s.len && s.n1[i] >= 0 && s.n2[i] >= 0) z += k[d + r]; }
        if (!z) continue;
        for (let d = dmin; d <= r; d++) {
          const i = c0 + d;
          if (i < 0 || i >= s.len || s.n1[i] < 0 || s.n2[i] < 0) continue;
          const base = s.v0 + i - x.o;
          fn(x.w * k[d + r] / z, base + s.b1[i], s.n1[i], base + s.b2[i], s.n2[i], base);
        }
      }
    };
    each((w, t1, n1, t2, n2) => {
      const b = Math.max(0, Math.floor(t1 / binVI));
      if (n1) d1n[b] += w; else d1f[b] += w;
      d2n[b] += n2 * w; W += w; if (b > hiBin) hiBin = b;
    });
    if (!W) return null;
    const kb = kernel(Math.max(sigB / binVI, 0.3)), top = Math.min(nb, hiBin + kb.r + 2);
    for (let i = 0; i < top; i++) {
      if (!d1n[i] && !d2n[i]) continue;
      for (let d = -kb.r; d <= kb.r; d++) { const j = i + d; if (j >= 0 && j < top) { s1[j] += d1n[i] * kb.k[d + kb.r]; s2[j] += d2n[i] * kb.k[d + kb.r]; } }
    }
    const kp = kernel(Math.max(sigB / binVI, 0.3));            // chance a bite in bin i is judged inside a zone
    for (let i = 0; i < top; i++) {
      let a = 0, zz = 0;
      for (let d = -kp.r; d <= kp.r; d++) { const j = i + d; if (j < 0 || j >= top) continue; zz += kp.k[d + kp.r]; if (s1[j] > s2[j] + 1e-12) a += kp.k[d + kp.r]; }
      pin[i] = zz ? a / zz : 0;
    }
    let val = 0, v1 = 0, v2 = 0;
    for (let i = 0; i < top; i++) { val += pin[i] * d1n[i] + (1 - pin[i]) * d2n[i]; v1 += d1n[i]; v2 += d2n[i]; }
    const out = { value: val / W, bite1: v1 / W, hold: v2 / W, binVI };
    if (!full) return out;
    const zones = [];
    let cur = null;
    for (let i = 0; i < top; i++) {
      const zin = s1[i] > s2[i] + 1e-12;
      if (zin && !cur) cur = [i * binVI, (i + 1) * binVI];
      else if (zin) cur[1] = (i + 1) * binVI;
      else if (cur) { zones.push(cur); cur = null; }
    }
    if (cur) zones.push(cur);
    const D1n = new Float64Array(top), D1f = new Float64Array(top), D2n = new Float64Array(top), D2all = new Float64Array(top), sc = [];
    each((w, t1, n1, t2, n2, cast) => {
      const b = Math.max(0, Math.floor(t1 / binVI)), p = pin[Math.min(b, top - 1)];
      if (n1) D1n[b] += w / W; else D1f[b] += w / W;
      const b2 = Math.floor(t2 / binVI);
      if (b2 >= 0 && b2 < top) { D2n[b2] += (1 - p) * n2 * w / W; D2all[b2] += n2 * w / W; }
      sc.push({ w, t1, n1, t2, n2, cast });
    });
    return Object.assign(out, { zones, d1n: D1n, d1f: D1f, d2n: D2n, d2all: D2all, sc, W });
  }
  /* value of a fixed choice (cast at T, policy, release zones) on a plan's arrivals: used to show what one pace
     group's plan gives the other groups. Bite judgement into zones with spread sig, as in zoneAt. */
  function valueWith(plan, T, sig, pol, zones) {
    const z = zoneAt(plan, T, sig, sig, true);
    if (!z) return NaN;
    const Phi = v => { const t = 1 / (1 + 0.3275911 * Math.abs(v / Math.SQRT2)), y = 1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-v * v / 2); return 0.5 * (1 + (v >= 0 ? y : -y)); };
    let v = 0;
    for (const e of z.sc) {
      let pin = pol === 'bite1' ? 1 : 0;
      if (pol === 'zone') for (const [a, b] of zones || []) pin += Phi((b - e.t1) / sdOf(sig)) - Phi((a - e.t1) / sdOf(sig));
      v += e.w * (pin * e.n1 + (1 - pin) * e.n2);
    }
    return v / z.W;
  }
  function zoneCurve(plan, sig, step) {
    step = step || 6;
    return memo(plan, 'z:' + step + ':' + sigKey(sig), () => zoneCurveRaw(plan, sig, step));
  }
  function zoneCurveRaw(plan, sig, step) {
    const P = new Float32Array(TMAX + 1).fill(NaN);
    for (let t = 1; t <= TMAX; t += step) {                       // grid at 1 + k*step (the fill below assumes it)
      if (t < plan.firstT) continue;
      const z = zoneAt(plan, t, sig, sig, false);
      if (z) P[t] = z.value;
    }
    for (let t = 1; t <= TMAX; t++) {                             // fill between the steps for drawing
      if (!isNaN(P[t])) continue;
      const a = t - ((t - 1) % step), b = a + step;
      if (!isNaN(P[a]) && b <= TMAX && !isNaN(P[b])) P[t] = P[a] + (P[b] - P[a]) * (t - a) / step;
      else if (!isNaN(P[a])) P[t] = P[a];
    }
    return P;
  }
  function argmax(P, lo, mask) {
    let bt = -1, bp = -1;
    for (let t = Math.max(1, lo); t < P.length; t++) if (!isNaN(P[t]) && P[t] > bp && (!mask || mask[t])) { bp = P[t]; bt = t; }
    return { t: bt, p: bp };
  }
  /* v29.9: aims only where >= 80% of the plan's routes have a cast table (near a table's end only the members that
     reach READY earliest are left, and their share alone gave fake highs) */
  const COVER_MIN = 0.8;
  function okMask(plan, sig) {
    return memo(plan, 'm:' + sigKey(sig), () => {
      const C = curve(plan, sig, 'bite1').C, cv = plan.cover || 1, m = new Uint8Array(TMAX + 1);
      for (let t = 1; t <= TMAX; t++) m[t] = C[t] / cv >= COVER_MIN ? 1 : 0;
      return m;
    });
  }
  /* best cast time per policy (t >= tMin), the zone policy refined around the coarse optimum */
  function best(plan, sig, tMin) {
    tMin = Math.max(tMin || 30, plan.firstT);
    const out = {}, mask = okMask(plan, sig);
    for (const pol of ['bite1', 'hold']) out[pol] = argmax(curve(plan, sig, pol).P, tMin, mask);
    // zone policy: local maxima of a 6-VI grid (peaks are only ~2 sigma wide), the best few refined per VI
    const zc = zoneCurve(plan, sig, 6), cands = [];
    for (let t = 1; t <= TMAX; t += 6) {
      if (t < tMin || isNaN(zc[t]) || !mask[t]) continue;
      if (!(zc[t - 6] > zc[t]) && !(zc[t + 6] > zc[t])) cands.push([t, zc[t]]);
    }
    cands.sort((a, b) => b[1] - a[1]);
    let z = { t: -1, p: -1 };
    for (const [t0] of cands.slice(0, 6)) {
      for (let t = Math.max(tMin, t0 - 6); t <= Math.min(TMAX, t0 + 6); t++) {
        if (!mask[t]) continue;
        const r = zoneAt(plan, t, sig);
        if (r && r.value > z.p) z = { t, p: r.value };
      }
    }
    out.zone = z;
    return out;
  }
  /* Bite-1 tap: the runner taps a key when the first bite shows. Posterior over (variant, cast offset d) given the tap
     at stopwatch VI tau: prior weight x kernel(d) x N(tau; t1 + tapMu, tapSd). Without a cast tap the cast lands at
     T + bias + d, d ~ N(0, sig) (aim spread) and the bite at T + bias + d + b1. With a cast tap (key pressed together
     with B at stopwatch VI cast.c) the landed path VI is c + bias + d + o, d ~ N(0, cast.sd) (tap + start-key spread;
     bias = the stopwatch's offset to the console) and the bite shows at c + b1 on the same stopwatch, so the bite delay
     after the cast is the fingerprint. Returns the evidence Z (relative), P(Nut on bite 1) p1, P(Nut on bite 2) pNut
     and the weighted scenarios. */
  function tapPosterior(plan, T, sig, bias, tau, tapMu, tapSd, weightOf, cast, tau2) {
    const ct = cast && cast.c != null ? cast : null;
    /* T rounded (2026-11-16): stored taps keep the CAST cue's sub-VI time (aim + cast-cue correction / VI); a fractional
       centre made every index fractional -> Z NaN -> the profile (auto-tune, personal weights) learned nothing */
    const center = ct ? Math.round(ct.c) : Math.round(T), { k, r } = kernel(ct ? ct.sd : sig), sc = [];
    const sd = ct ? Math.hypot(tapSd, ct.tapSd || 0) : tapSd;
    let Z = 0, nut = 0, nut1 = 0, prior = 0;
    const b = Math.round(bias || 0);
    for (const x of plan.variants) {
      const s = plan.series[x.s];
      if (!s) continue;
      const wx = weightOf ? weightOf(x) : x.w, c0 = center + x.o - s.v0 + b;
      for (let d = Math.max(-r, (x.minT || 1) - center - b); d <= r; d++) {
        const i = c0 + d;
        if (i < 0 || i >= s.len || s.n1[i] < 0 || s.n2[i] < 0) continue;
        prior += wx * k[d + r];
        const base = ct ? ct.c : s.v0 + i - x.o, t1 = base + s.b1[i], t2 = base + s.b2[i], z = (tau - (t1 + tapMu)) / sd;
        if (Math.abs(z) > 5) continue;
        const z2 = tau2 != null ? (tau2 - (t2 + tapMu)) / sd : 0;     // second bite tapped too (held through bite 1)
        if (Math.abs(z2) > 5) continue;
        const w = wx * k[d + r] * Math.exp(-0.5 * (z * z + z2 * z2)) / (sd * 2.5066);
        sc.push({ w, pair: x.s + ':' + x.o, path: x.s, pv: i + s.v0, n1: s.n1[i], n2: s.n2[i], t1, t2, d: d + b, mt: x.minT || 1 });
        Z += w; nut += w * s.n2[i]; nut1 += w * s.n1[i];
      }
    }
    return { Z: prior ? Z / prior : 0, pNut: Z ? nut / Z : NaN, p1: Z ? nut1 / Z : NaN, sc };
  }
  /* stopwatch spans holding most of the Nut-bite mass: bins of 6 VI with >= frac of the peak, merged when < gap apart */
  function nutSpans(items, frac, gap) {
    const bins = new Map();
    let m = 0;
    for (const [t, w] of items) { const b = Math.floor(t / 6); const v = (bins.get(b) || 0) + w; bins.set(b, v); if (v > m) m = v; }
    const out = [];
    for (const b of [...bins.keys()].sort((a, c) => a - c)) {
      if (!(bins.get(b) >= (frac || 0.25) * m && m > 0)) continue;
      const a = b * 6, e = (b + 1) * 6;
      if (out.length && a - out[out.length - 1][1] <= (gap || 30)) out[out.length - 1][1] = e; else out.push([a, e]);
    }
    return out;
  }
  /* summary of a posterior: most likely dog path (+ share), most likely landed path VI on it, expected bite time and
     the tap lag it implies (tau - bite onset) */
  function tapSummary(post, tau) {
    if (!post || !post.sc.length) return null;
    const Z = post.sc.reduce((a, e) => a + e.w, 0), byPath = {}, byFrame = {};
    let t1 = 0, t1sq = 0;
    for (const e of post.sc) {
      byPath[e.path] = (byPath[e.path] || 0) + e.w / Z;
      const fk = e.path + ':' + (e.pv >> 1); byFrame[fk] = (byFrame[fk] || 0) + e.w / Z;
      t1 += e.w * e.t1 / Z; t1sq += e.w * e.t1 * e.t1 / Z;
    }
    const top = Object.entries(byPath).sort((a, b) => b[1] - a[1])[0], frame = Object.entries(byFrame).sort((a, b) => b[1] - a[1])[0];
    const sdT1 = Math.sqrt(Math.max(0, t1sq - t1 * t1));
    return { path: +top[0], pathShare: top[1], frameShare: frame[1], t1, sdT1, lag: tau - t1 };
  }
  /* Personal profile from stored taps [{k, T, tau, c?}]: stopwatch offsets by maximum evidence with a weak N(0, 9 VI)
     prior (bias: casts vs the aim, for taps without a cast tap; bias0: stopwatch vs console, for taps with one), the
     bite-tap lag (EM over the taps, starting at tapMu), then pair (dog path:offset) masses, shrunk to the route weights
     with alpha. */
  function profile(taps, sig, tapMu, tapSd, alpha, castCfg, tie) {
    alpha = alpha || 3;
    const use = taps.slice(-60).filter(t => plans.find(p => p.k === t.k));
    if (!use.length) return null;
    const planOf = t => plans.find(p => p.k === t.k);
    const cc = castCfg || { sd: 3.4, tapSd: 2.4 }, castOf = t => (t.c != null ? { c: t.c, sd: cc.sd, tapSd: cc.tapSd } : null);
    const fitSd = Math.max(tapSd, 4);
    const post = (t, b, mu, sd) => tapPosterior(planOf(t), t.T, sig, b, t.tau, mu, sd, null, castOf(t), t.tau2);
    const LL = (sub, b, mu) => { let L = 0; for (const t of sub) L += Math.log(post(t, b, mu, fitSd).Z + 1e-12); return L; };
    const pb = b => -0.5 * (b / 9) ** 2, pm = mu => -0.5 * ((mu - 16) / 8) ** 2;   // weak priors (VI)
    const noCast = use.filter(t => t.c == null), withCast = use.filter(t => t.c != null);
    // the stopwatch offset and the bite-tap lag trade off (a late tap can look like a shifted cast), so they are fitted
    // jointly on the larger subset: coarse grid, then a per-VI refinement; the other subset's offset at that lag
    const main = withCast.length >= noCast.length ? withCast : noCast, other = main === withCast ? noCast : withCast;
    let best = { b: 0, mu: tapMu, L: -Infinity };
    const tryAt = (b, mu) => { const L = LL(main, b, mu) + pb(b) + pm(mu); if (L > best.L) best = { b, mu, L }; };
    /* tie (v29.10, taps without the cast tap): ONE reaction for screen events. The start tap comes k VIs later than the
       start-tap delay tie.d assumes, so the stopwatch runs k VIs behind the console (k = the clock's offset); the B press
       lands tie.p VIs after the CAST cue (measured by practice / real casts) -> b = tie.p + k. The bite tap comes the same
       tie.d + k after the bite, but the bite is read on the k-late stopwatch, so its lag in stopwatch terms is tie.d:
       mu = tie.d, whatever k is (first build had mu = d + k: the fit then sat at k = 0). One unknown, the bite taps pin it. */
    let kTied = null;
    if (tie && main === noCast) {
      let bk = { k: 0, L: -Infinity };
      for (let k = -18; k <= 18; k++) {
        const b = Math.round(tie.p + k), mu = Math.max(3, Math.round(tie.d));
        const L = LL(main, b, mu) - 0.5 * (k / 9) ** 2;
        if (L > bk.L) bk = { k, L };
      }
      kTied = bk.k;
      best = { b: Math.round(tie.p + kTied), mu: Math.max(3, Math.round(tie.d)), L: bk.L };
    } else {
      for (let b = -18; b <= 18; b += 2) for (let mu = 6; mu <= 36; mu += 3) tryAt(b, mu);
      const c0 = best;
      for (let b = c0.b - 2; b <= c0.b + 2; b++) for (let mu = c0.mu - 2; mu <= c0.mu + 2; mu++) tryAt(b, mu);
    }
    const fit1 = sub => { let bb = 0, bl = -Infinity; for (let b = -18; b <= 18; b++) { const L = LL(sub, b, best.mu) + pb(b); if (L > bl) { bl = L; bb = b; } } return bb; };
    const bMain = best.b, bOther = other.length ? fit1(other) : 0;
    const bias = main === noCast ? bMain : bOther, bias0 = main === withCast ? bMain : bOther;
    const bOf = t => (t.c != null ? bias0 : bias);
    const lags = [];
    for (const t of use) { const r = post(t, bOf(t), best.mu, fitSd); const sm = tapSummary(r, t.tau); if (sm && r.Z > 1e-4 && sm.sdT1 < 8) lags.push(sm.lag); }
    const enough = lags.length >= 3, mu = best.mu;
    const lagSd = enough ? Math.sqrt(lags.reduce((a, x) => a + (x - mu) ** 2, 0) / (lags.length - 1)) : NaN;
    const muUse = enough ? mu : tapMu, sdUse = enough ? Math.max(tapSd, Math.min(8, lagSd)) : tapSd;
    const mass = {};
    let n = 0, nofit = 0;
    for (const t of use) {
      const r = post(t, bOf(t), muUse, sdUse);
      if (!r.sc.length || r.Z < 1e-4) { nofit++; continue; }
      const Z = r.sc.reduce((a, e) => a + e.w, 0);
      for (const e of r.sc) mass[e.pair] = (mass[e.pair] || 0) + e.w / Z;
      n++;
    }
    const p0 = {}, P = plans[0], W = P.variants.reduce((a, x) => a + x.w, 0);
    for (const x of P.variants) p0[x.s + ':' + x.o] = (p0[x.s + ':' + x.o] || 0) + x.w / W;
    const factor = pair => p0[pair] ? (alpha * p0[pair] + (mass[pair] || 0)) / (alpha + n) / p0[pair] : 1;
    const byPath = {};
    for (const [pair, m] of Object.entries(mass)) { const pth = +pair.split(':')[0]; byPath[pth] = (byPath[pth] || 0) + m / Math.max(1, n); }
    return { n, nofit, bias, bias0, nCast: withCast.length, lag: enough ? { mu, sd: lagSd, n: lags.length } : null,
             tapMu: muUse, tapSd: sdUse, factor, byPath, kTied, nNoCast: noCast.length };
  }
  function personal(plan, prof) {                                   // same tables, variants re-weighted by the profile
    if (!prof || !prof.n) return plan;
    return Object.assign(Object.create(Object.getPrototypeOf(plan)), plan,
      { variants: plan.variants.map(x => Object.assign({}, x, { w: x.w * prof.factor(x.s + ':' + x.o) })), personal: true });
  }
  return { prepare, select, planSet, groups, groupOf, groupFor, axId, routes, routeOf, curve, zoneAt, zoneCurve, valueWith, best, kernel, tapPosterior, tapSummary, nutSpans, profile, personal,
           get plans() { return plans; }, get selection() { return Object.assign({}, sel); }, TMAX };
})();

if (typeof module !== 'undefined' && module.exports) { module.exports = LuckyCore; return; }
root.HM64Lucky = LuckyCore;
if (typeof document === 'undefined') return;

/* ================================================================== UI */
const Core = root.HM64Core, D = Core.data;
const $ = id => document.getElementById(id);
if (!$('luckyArena')) return;
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* storage unavailable */ } },
};
const viMs = () => Core.viMs();
const LDEF = { sigmaMs: 150, startDelayMs: 120, biasMs: 0, policy: 'auto', plan: 'auto', facing: 'SE', startKey: ' ',
               zoneBeeps: true, audio: false, castT: null, figure: 'jack', personal: true, dudPct: 1,
               pace: 'all', anchor: 'dog', dogDelayMs: -130, castTap: false, tapPrecMs: 40,
               route: 'carry', routeAnchor: {}, routePace: {}, anchorDelayMs: { beach: 150, pier: 150 },
               pracLine: true, pracFull: false, pracAuto: false, autoTune: true,
               tapStrategy: 'ebd', beachCue: 'ctrl', tapSdAuto: true, tapSdMs: 60, tapDataOpen: false, sparrows: false, cueGlow: true, personalCast: false, biasAuto: true, sigmaAuto: true, startTapMs: null, tieReaction: true };
const L = Object.assign({}, LDEF, store.get('hm64v29_lucky', {}));
{ /* settings saved by earlier v29.9 builds (double tap on/off, a list of cues) -> a tap strategy + one beach cue */
  const sv = store.get('hm64v29_lucky', {});
  if (!sv.tapStrategy && (sv.tapCues || sv.fadeDouble === false)) {
    const c = sv.fadeDouble === false && !sv.tapCues ? ['fade'] : sv.tapCues;
    L.tapStrategy = c.includes('exit') ? (c.includes('dock') ? 'ebd' : 'eb') : c.includes('dock') ? 'bd' : 'b';
    L.beachCue = c.includes('ctrl') ? 'ctrl' : 'fade';
  }
  delete L.tapCues; delete L.fadeDouble;
}
const save = () => store.set('hm64v29_lucky', L);
if (!L.cueV) { L.audio = false; L.cueV = 1; save(); }          // v29.10: visual cues; sound only if switched back on
if (!L.castTapV) { L.castTap = false; L.castTapV = 1; save(); } // v29.10: no Space-with-B cast tap by default (one reaction instead)
if (L.startTapMs == null) {                                    // v29.10: one start-tap delay for every start (the dog landing aside)
  const a = L.anchorDelayMs || {};
  L.startTapMs = a.fadein !== undefined ? a.fadein : a.pier !== undefined ? a.pier : 150; save();
}
let tally = store.get('hm64v29_lucky_tally', []);
let taps = store.get('hm64v29_lucky_taps', []);                // bite-1 taps [{k, T (effective aim VI), tau, hit}]
let fade2 = store.get('hm64v29_lucky_fade2', []);              // double taps [{d: ms (tap 2 - tap 1 - gap), at, route}]
const OS = store.get('hm64v28_settings', {});
const tapMu = () => (OS.tapMuVI || 13), tapSd = () => Math.max(2.5, OS.tapSdVI || 3.5);
/* cast tap (key together with B): index spread = tap + start-key precision; the tap error also blurs the bite time */
const castCfg = () => { const v = L.tapPrecMs / viMs(); return { sd: Math.max(1.5, Math.hypot(v, v)), tapSd: v }; };
const lagMu = () => (prof && prof.lag ? prof.tapMu : tapMu());                    // the runner's bite-tap lag (VI)
const lagSd = () => (prof && prof.lag ? prof.tapSd : Math.max(tapSd(), 5));
const WINDOW_VI = 20;                                                            // release window after the bite shows
let prof = null, profVer = 0;
const prof_ = () => prof;
const persCache = new Map();
const anchorOf = t => t.anchor || 'ready';                     // taps before v29.2 were all READY-started
const routeOfTap = t => t.route || 'carry';                     // taps before v29.5 were all on the dog-carry route
function updateProfile() {
  const mine = taps.filter(t => anchorOf(t) === anchor() && routeOfTap(t) === route() &&
                              (anchor() !== 'fadein' || (t.ref || 'fade') === L.beachCue));   // one clock reference per profile
  const ps = L.tieReaction !== false ? pressReady() : null, dly = anchor() === 'dog' ? null : startDelay();
  const tie = ps && dly != null ? { p: ps.med / viMs(), d: dly / viMs() } : null;   // needs >= 5 B presses to the cue
  prof = mine.length ? LuckyCore.profile(mine, sigStd(), tapMu(), tapSd(), 3, castCfg(), tie) : null;
  profVer++; persCache.clear(); bestCache = null; ccache.clear();
}
function P(plan) {                                              // the plan as seen by this runner (profile weights)
  if (plan._final || !(L.personal && prof && prof.n)) return plan;   // _final: already re-weighted (dock-end tap)
  const key = selKey() + ':' + plan.k;
  if (!persCache.has(key)) persCache.set(key, LuckyCore.personal(plan, prof));
  return persCache.get(key);
}
let customSprites = store.get('hm64v29_angler', {});
const selAnchor = () => (L.route === 'carry' ? L.anchor : L.routeAnchor[L.route]);
const selPace = () => (L.route === 'carry' ? L.pace : (L.routePace || {})[L.route] || 'all');   // presets kept per route
LuckyCore.prepare(D, viMs(), { route: L.route, pace: selPace(), anchor: selAnchor() });
let plans = LuckyCore.plans;
const anchor = () => LuckyCore.selection.anchor;   // carry: 'dog' | 'ready'; route tables: their anchors (beach, pier)
const route = () => LuckyCore.selection.route;
const routeDef = () => LuckyCore.routeOf(route());
/* route variants (v29.10): a table that belongs to another route (variant_of), e.g. dog-beach's sparrow mornings,
   is not listed as a route; the base route shows a checkbox for it */
const baseOf = id => { const R = LuckyCore.routes().find(r => r.id === id); return (R && R.variant_of) || id; };
const variantOf = (base, v) => LuckyCore.routes().find(r => r.variant_of === base && r.variant === v) || null;
const sparrowTable = () => variantOf(baseOf(route()), 'sparrows');
const selKey = () => route() + '/' + LuckyCore.selection.pace + '/' + LuckyCore.selection.anchor;
const R0 = () => (plans[0] && plans[0].r0) || 0;               // READY on this stopwatch (no beach wait), VI
const ANAME = { dog: 'the dog lands', ready: 'READY', beach: 'beach entry', pier: 'READY (pier end)', fadein: 'the beach fade-in starts' };
const startName = () => ANAME[anchor()] || ((routeDef().anchors || []).find(a => a.id === anchor()) || {}).label || 'the start';
const keyName = () => (L.startKey === ' ' ? 'Space' : L.startKey);
const startDelay = () => (anchor() === 'dog' ? L.dogDelayMs : L.startTapMs);   // v29.10: one start-tap delay
function setSelection(pace, anch, rt) {                        // route / pace group / start anchor changed
  if (rt) L.route = rt;
  if (pace) { if (L.route === 'carry') L.pace = pace; else (L.routePace = L.routePace || {})[L.route] = pace; }
  if (anch) { if (L.route === 'carry') L.anchor = anch; else L.routeAnchor[L.route] = anch; }
  plans = LuckyCore.select({ route: L.route, pace: selPace(), anchor: selAnchor() });
  L.route = route();
  if (L.plan !== 'auto' && !plans.some(x => String(x.k) === String(L.plan))) L.plan = 'auto';
  L.castT = null; save();
  bestCache = null; ccache.clear(); persCache.clear();
  updateProfile(); fillLSettings(); refresh();
}
/* ---------------------------------------------------------------- your timing, harmonized (v29.10)
   One place (L5 · Your timing), four numbers about the same person, each learned from ALL of its data (auto) or set by
   hand - and each used once:
   - start taps: how late your start / clock taps come after their cue = the start-tap delay (one value for every start,
     the carry route's dog landing aside) + what auto-tune learns from your bite taps on this start;
   - B press on CAST: how late you press B vs the CAST cue = cast practice + real casts (the cast tap), same cue type
     (visual / sound); the CAST cue moves by minus their median (the cast-cue correction);
   - bite taps: how late you tap after a bite shows (the bite-tap profile);
   - how much you vary: your B presses' SD with the start tap's 60 ms = the timing spread.
   Two kinds of timing, on purpose kept apart: REACTING to something you could not time (start cue, bite: ~150-300 ms
   late) and pressing ON a countdown you saw coming (CAST: near 0, often a little early). They are the same person but
   not the same number.
   Auto-tune (the clock): from attempts with the cast tap, no assumption needed; without it (the default since the
   4th build of 2026-11-16) a bite tap mixes clock, B press and bite-tap lag, so it assumes ONE reaction for screen
   events (your start taps and your bite taps come equally late) and takes the B press from your presses: then the
   bite taps pin the clock (LuckyCore.profile tie). The B press belongs to the cast-cue correction alone. */
let pressCache = { key: null, v: null };
function pressData() {                                          // practice presses (current mode, cue type) + real casts
  const last = a => (a.length ? a[a.length - 1].at || 0 : 0);
  const key = [pracLog.length, last(pracLog), tally.length, last(tally), L.audio, L.pracLine].join(':');
  if (pressCache.key !== key) {
    const pr = pracErrs(pracMode()).slice(-80), at = attemptErrs().slice(-40), es = pr.concat(at);
    pressCache = { key, v: { pr, at, es, s: castStats(es) } };
  }
  return pressCache.v;
}
const pressReady = () => { const d = pressData(); return d.s && d.s.n >= 5 ? d.s : null; };
const cueCorr = () => { if (L.biasAuto !== false) { const s = pressReady(); if (s) return -Math.round(s.med); } return L.biasMs; };
/* how well the clock's offset is known: learned from cast-tap attempts (auto-tune), else +-60 ms assumed */
const offsetSdMs = () => (L.autoTune && prof && (prof.nCast || 0) >= 8 ? Math.hypot(castCfg().sd, castCfg().tapSd) * viMs() / Math.sqrt(prof.nCast) : 60);
/* the one timing spread (standard plan): your B presses' spread, one start tap (+-60 ms; the clock taps replace it on the
   fade-in start) and how well the clock offset is known - the same parts as the personalized kernel, as a bell curve */
const sigmaFrom = sd => Math.max(40, Math.min(400, Math.round(Math.sqrt(sd ** 2 + PRAC.startSd ** 2 + offsetSdMs() ** 2) / 10) * 10));
const sigmaMs = () => {
  if (L.sigmaAuto !== false) { const s = pressReady(); if (s && isFinite(s.sd)) return sigmaFrom(s.sd); }
  return L.sigmaMs;
};
const sigStd = aid => Math.max(1, sigEffMs(aid) / viMs());   // the standard Gaussian spread (VIs)
const sigVI = aid => (L.personalCast ? personalKernel(aid) : null) || sigStd(aid);
const sigTag = aid => (L.personalCast ? (personalKernel(aid) || {}).id : null) || String(sigEffMs(aid));   // cache keys
/* ---------------------------------------------------------------- personalized cast suggestions (v29.10, experimental)
   Off (default): the cast lands Gaussian around the aim with the timing spread (slider + the tap cascade), so the
   suggestion goes for the highest peak that spread can hit. On: the landing kernel is YOUR measured timing - every B
   press you made to the cast cue (cast practice with the same cue type, real casts logged with the cast tap; beyond
   3 MAD left out), after the current cast-cue correction, each smeared by the clock's error (clock-tap spread /
   sqrt(clock taps)) and by how well your console offset is known (auto-tune: one bite tap's spread / sqrt(bite taps);
   not learned yet: +-60 ms). A late, loose or lopsided habit gives a wide, lopsided kernel and the best aim moves off
   narrow peaks onto wide plateaus by itself (best expected odds under your own timing); a tight one keeps the peaks.
   Under 8 presses it falls back to the slider's B-press part, Gaussian, plus the same clock and offset terms. */
const PK_MIN = 8, PK_OFFSET_UNKNOWN_MS = 60, PK_RMAX = 60;
const pkCache = new Map();
function trimmed(es) {                                          // the presses castStats keeps (within 3 MAD of the median)
  const v = es.filter(Number.isFinite).slice().sort((a, b) => a - b), n = v.length;
  if (!n) return [];
  const q = (a, f) => a[Math.min(a.length - 1, Math.max(0, Math.round(f * (a.length - 1))))];
  const md = q(v, 0.5), mad = 1.4826 * q(v.map(x => Math.abs(x - md)).sort((a, b) => a - b), 0.5);
  return v.filter(x => Math.abs(x - md) <= Math.max(3 * mad, 40));
}
function pkParts(aid) {
  aid = aid || anchor();
  const vi = viMs(), pr = pracErrs(pracMode()).slice(-80), at = attemptErrs().slice(-40);
  const es = trimmed(pr.concat(at)).map(e => e + cueCorr());    // landing vs the aim (ms): the cue sits at aim + correction
  const nC = aid === 'fadein' ? Math.max(1, clockCues().length) : 1;
  const sc = aid === 'fadein' && route() !== 'carry' ? clockSd() / Math.sqrt(nC) : START1_MS;
  const sb = offsetSdMs(), sbSrc = L.autoTune && prof && (prof.nCast || 0) >= 8 ? `auto-tune, ${prof.nCast} cast-tap attempts` : 'not learned yet';
  const mean = es.length ? es.reduce((a, x) => a + x, 0) / es.length : 0;
  const sd = es.length > 1 ? Math.sqrt(es.reduce((a, x) => a + (x - mean) ** 2, 0) / (es.length - 1)) : NaN;
  const skew = es.length > 2 && sd > 0 ? es.reduce((a, x) => a + ((x - mean) / sd) ** 3, 0) / es.length : 0;
  return { aid, es, nPr: pr.length, nAt: at.length, sc, sb, sbSrc, mean, sd, skew, enough: es.length >= PK_MIN };
}
let pkFast = { key: null, map: new Map() };
function personalKernel(aid) {                                  // cheap key first: it is asked for on every cache lookup
  aid = aid || anchor();
  let h = 0;                                                    // checksum of the presses it would use (contents, not just counts)
  for (const e of pracErrs(pracMode()).slice(-80).concat(attemptErrs().slice(-40))) h = (h * 31 + Math.round(e * 10)) % 1000000007;
  const fk = [h, cueCorr(), Math.round(clockSd()), profVer, sigmaMs(), L.audio, L.pracLine, L.autoTune, route(), clockCues().length, viMs()].join(':');
  if (pkFast.key !== fk) pkFast = { key: fk, map: new Map() };
  if (!pkFast.map.has(aid)) pkFast.map.set(aid, personalKernelRaw(aid));
  return pkFast.map.get(aid);
}
function personalKernelRaw(aid) {
  const P_ = pkParts(aid), vi = viMs();
  const xs = P_.enough ? P_.es : [0];
  const h = P_.enough ? Math.max(10, 1.06 * (P_.sd || 30) * Math.pow(xs.length, -0.2)) : Math.sqrt(Math.max(sigmaMs() ** 2 - START1_MS ** 2, 30 ** 2));
  const w = Math.sqrt(h * h + P_.sc ** 2 + P_.sb ** 2);
  const key = [P_.aid, xs.map(x => Math.round(x)).join(','), Math.round(w)].join('|');
  if (pkCache.has(key)) return pkCache.get(key);
  const lo = Math.floor((Math.min(...xs) - 4 * w) / vi), hi = Math.ceil((Math.max(...xs) + 4 * w) / vi);
  const r = Math.min(PK_RMAX, Math.max(Math.abs(lo), Math.abs(hi), 1)), k = new Float32Array(2 * r + 1);
  let z = 0;
  for (let d = -r; d <= r; d++) { let a = 0; for (const x of xs) a += Math.exp(-0.5 * ((d * vi - x) / w) ** 2); k[d + r] = a; z += a; }
  let m1 = 0, m2 = 0, sum = 0;
  for (let d = -r; d <= r; d++) { k[d + r] /= z; m1 += d * k[d + r]; m2 += d * d * k[d + r]; }
  let hsh = 7;
  for (let i = 0; i < k.length; i++) hsh = (hsh * 31 + Math.round(k[i] * 1e4)) % 1000000007;
  const out = { id: `pk${r}:${hsh}`, k, r, sd: Math.max(1, Math.sqrt(Math.max(0, m2 - m1 * m1))), mean: m1, wMs: w, parts: P_ };
  if (pkCache.size > 40) pkCache.clear();
  pkCache.set(key, out);
  return out;
}
function personalTxt() {                                       // what the personalized suggestion uses, and what it changes
  if (!L.personalCast) return '';
  const pk = personalKernel(), P_ = pk.parts, vi = viMs(), plan = run.plan, pol = run.pol === 'tap' ? 'hold' : run.pol;
  if (!plan) return '';
  const sg = v => (v >= 0 ? '+' : '−') + Math.abs(Math.round(v));
  let h = '<b>Personalized:</b> ' + (P_.enough
    ? `your ${P_.es.length} B presses (${P_.nPr} practice, ${P_.nAt} real casts) land ${sg(P_.mean)} ms vs the aim with the current correction, spread ±${Math.round(P_.sd)} ms` +
      (Math.abs(P_.skew) >= 0.4 ? `, lopsided ${P_.skew > 0 ? 'late' : 'early'}` : '')
    : `only ${P_.es.length} B presses to the ${L.audio ? 'beep' : 'visual cue'} (8 needed): your ${sigmaMs()} ms timing spread stands in for the B press`) +
    `; clock ±${Math.round(P_.sc)} ms; console offset known ±${Math.round(P_.sb)} ms (${P_.sbSrc}) → landing spread ±${Math.round(pk.sd * vi)} ms` +
    (Math.abs(pk.mean * vi) >= 10 ? `, centred ${sg(pk.mean * vi)} ms` : '') + '. ';
  try {                                                         // the standard aim, played with your timing
    const pp = P(plan), bs = LuckyCore.best(pp, sigStd(), 30 + R0()), Ts = bs[pol] ? bs[pol].t : -1;
    if (Ts > 0) {
      const val = T => (pol === 'zone' ? (LuckyCore.zoneAt(pp, T, pk) || {}).value : LuckyCore.curve(pp, pk, pol).P[T]);
      const vMine = val(run.T), vStd = val(Ts);
      h += Ts === run.T ? `Same aim as the standard suggestion (${fmtS(Ts)}).`
        : `Aim ${fmtS(run.T)}: <b>${pct(vMine)}</b> with your timing; the standard aim ${fmtS(Ts)} (±${sigEffMs()} ms Gaussian) would give ${pct(vStd)} with your timing.`;
    }
  } catch (e) { /* plan not ready */ }
  return h;
}
const now = () => performance.now();
/* v29.9 double tap on the fade-in start. Goalpost 1 = the first frame Jack stands still at the ranch exit, which is also
   the first dimmer frame (main loop EXIT_LEVEL, game.c handleExitLevel: map + entities fade at rate 8/frame);
   goalpost 2 = the first non-black beach frame (LEVEL_LOAD + 2 VIs). Lab (rendered + 30/30 ranch states): 70 VIs apart
   every time. Both taps estimate the fade-in moment (tap 2 directly, tap 1 + gap + your learned difference m), so the
   start uses their average: a steadier start, and a missed or fumbled tap is caught. The pair cannot give the absolute
   reaction (both taps carry one); that offset still comes from the bite taps. */
const GP_GAP_VI = 70;
const gapMs = () => GP_GAP_VI * viMs();
function fadeStats() {
  const ds = fade2.slice(-30).map(x => x.d).sort((a, b) => a - b), n = ds.length;
  if (!n) return { n: 0, m: 0, med: NaN, sd: NaN };
  const med = n % 2 ? ds[(n - 1) / 2] : (ds[n / 2 - 1] + ds[n / 2]) / 2, mean = ds.reduce((a, v) => a + v, 0) / n;
  let sd = n > 1 ? Math.sqrt(ds.reduce((a, v) => a + (v - mean) ** 2, 0) / (n - 1)) : NaN;
  if (n >= 5) {                                                 // robust (MAD) once there are a few: one fumble can't inflate it
    const dev = ds.map(v => Math.abs(v - med)).sort((a, b) => a - b), mad = n % 2 ? dev[(n - 1) / 2] : (dev[n / 2 - 1] + dev[n / 2]) / 2;
    sd = Math.max(1.4826 * mad, 5);
  }
  return { n, m: med * n / (n + 2), med, sd };                  // m shrunk toward 0 (same reaction to both) while pairs are few
}
const run = { wall0: null, T: null, plan: null, pol: null, zone: null, beeped: new Set(), result: null, resultAt: 0,
              preview: null, practice: null };
let bestCache = null;

/* ---------------------------------------------------------------- audio */
let actx = null;
function audio() { if (!L.audio) return null; try { actx = actx || new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { actx = null; } return actx; }
let pending = [];
function cancelBeeps() { pending.forEach(g => { try { g.disconnect(); } catch (e) { /* gone */ } }); pending = []; }
function beepAt(wall, f, dur, vol) {
  const a = audio(); if (!a) return;
  const t = a.currentTime + Math.max(0, (wall - now()) / 1000);
  const o = a.createOscillator(), g = a.createGain();
  o.frequency.value = f; o.connect(g); g.connect(a.destination);
  g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol || 0.25, t + 0.005); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.start(t); o.stop(t + dur + 0.02); pending.push(g);
}

/* ---------------------------------------------------------------- plan choice */
function planObj() {
  if (L.plan !== 'auto') { const p = plans.find(x => String(x.k) === String(L.plan)); if (p) return p; }
  return bestOverall().plan;
}
function bests() {
  const key = sigTag() + ':' + selKey() + ':' + plans.length + ':' + profVer + ':' + L.personal;
  if (bestCache && bestCache.key === key) return bestCache.list;
  const list = plans.map(p => { const b = LuckyCore.best(P(p), sigVI(), 30 + R0()); b.tap = b.hold; return { plan: p, b }; });
  bestCache = { key, list };
  return list;
}
function bestOverall() {
  let top = null;
  for (const x of bests()) for (const pol of ['zone', 'bite1', 'hold']) {
    const b = x.b[pol];
    const score = b.p * (x.plan.cover >= 0.8 ? 1 : x.plan.cover);      // partly covered plans only if nearly complete
    if (b.t > 0 && (!top || score > top.score)) top = { plan: x.plan, pol, t: b.t, p: b.p, score };
  }
  return top || { plan: plans[0], pol: 'bite1', t: 150, p: 0 };
}
function polOf(plan) {
  if (L.policy !== 'auto') return L.policy;                    // 'tap' = hold-only + bite-1 tap
  const b = bests().find(x => x.plan === plan).b;
  return ['zone', 'bite1', 'hold'].reduce((a, p) => (b[p].p > b[a].p ? p : a), 'zone');
}
function castT(plan, pol) {
  if (L.castT !== null && L.castT >= plan.firstT) return L.castT;
  return bests().find(x => x.plan === plan).b[pol].t;
}
function valueAt(plan, pol, T) {
  if (pol === 'zone') { const z = LuckyCore.zoneAt(P(plan), T, sigVI()); return z ? z.value : NaN; }
  return curveC(plan, pol)[T];
}
const ccache = new Map();
function curveC(plan, pol) {                                   // cached per plan, policy, spread and profile
  if (pol === 'tap') pol = 'hold';
  const key = selKey() + ':' + plan.k + ':' + pol + ':' + sigTag() + ':' + profVer + ':' + L.personal;
  if (!ccache.has(key)) ccache.set(key, pol === 'zone' ? LuckyCore.zoneCurve(P(plan), sigVI(), 6) : LuckyCore.curve(P(plan), sigVI(), pol).P);
  return ccache.get(key);
}
const fmtS = vi => ((vi - 1) * viMs() / 1000).toFixed(2) + ' s';
const pct = p => isNaN(p) ? '—' : (100 * p).toFixed(1) + '%';
const POLNAME = { zone: 'Smart zones', bite1: 'Release at 1st bite', hold: 'Hold → release 2nd bite', tap: '2nd bite + tap bite 1' };

/* ---------------------------------------------------------------- plan panel */
function renderPlans() {
  const cur = planObj(), list = bests();
  $('lkPlans').innerHTML = '';
  for (const { plan, b } of list) {
    const pol = ['zone', 'bite1', 'hold'].reduce((a, p) => (b[p].p > b[a].p ? p : a), 'zone');
    const el = document.createElement('div');
    el.className = 'lkcard' + (plan === cur ? ' sel' : '');
    el.innerHTML = `<div class="small mut">${plan.label}</div><div class="share">${pct(b[pol].p)}</div>` +
      `<div class="small mono">cast ${b[pol].t > 0 ? fmtS(b[pol].t) : '—'}</div><div class="small mut">${POLNAME[pol]}</div>` +
      (plan.cover < 0.999 ? `<div class="small mut">${(100 * plan.cover).toFixed(0)}% of routes</div>` : '');
    el.onclick = () => { L.plan = String(plan.k); L.castT = null; save(); refresh(); };
    $('lkPlans').appendChild(el);
  }
  if (plans.length === 1 && route() === 'carry' && (anchor() === 'ready' ? !D.lucky : D.lucky)) {
    const el = document.createElement('div');
    el.className = 'lkcard dim';
    el.innerHTML = '<div class="small mut">1–3 whistles</div><div class="small">' +
      (anchor() === 'ready' ? (LuckyCore.selection.pace === 'all' ? 'needs the <b>lucky</b> lab run' : 'pace <b>All</b> only') : 'READY start only') + '</div>';
    $('lkPlans').appendChild(el);
  }
  $('lkPlans').hidden = !$('lkPlans').children.length || (plans.length === 1 && (!!D.pace || route() !== 'carry') && $('lkPlans').children.length === 1);
  document.querySelectorAll('#lkPol button').forEach(b => b.classList.toggle('on', b.dataset.pol === L.policy));
  $('lkAutoPlan').classList.toggle('on', L.plan === 'auto');
}
/* ---------------------------------------------------------------- pace presets (D.pace) */
const POLSHORT = { zone: 'smart zones', bite1: '1st bite', hold: '2nd bite' };
const paceCache = new Map();
function paceRow(g) {                                          // best plan for one pace group (no profile), cached
  const key = sigTag() + ':' + anchor() + ':' + route() + ':' + g.id;
  if (paceCache.has(key)) return paceCache.get(key);
  const sig = sigVI(), plan = LuckyCore.planSet(g.id, anchor(), route())[0], b = LuckyCore.best(plan, sig, 30 + R0());
  const pol = ['zone', 'bite1', 'hold'].reduce((a, q) => (b[q].p > b[a].p ? q : a), 'zone');
  const z = pol === 'zone' ? LuckyCore.zoneAt(plan, b.zone.t, sig, sig, true) : null;
  const r = { g, plan, b, pol, t: b[pol].t, p: b[pol].p, zones: z ? z.zones : null, cross: {} };
  paceCache.set(key, r);
  return r;
}
const startCache = new Map();
function startRow(g, aid) {                                    // v29.9: best plan for one preset on a given start (no profile)
  const key = sigTag(aid) + ':' + aid + ':' + route() + ':' + g.id;
  if (startCache.has(key)) return startCache.get(key);
  const plan = (LuckyCore.planSet(g.id, aid, route()) || [])[0];
  if (!plan) return null;
  const sig = sigVI(aid), b = LuckyCore.best(plan, sig, 30 + (plan.r0 || 0));
  const pol = ['zone', 'bite1', 'hold'].reduce((a, q) => (b[q].p > b[a].p ? q : a), 'zone');
  const r = { aid, t: b[pol].t, p: b[pol].p, pol, r0: plan.r0 || 0 };
  startCache.set(key, r);
  return r;
}
function startCompare() {                                      // every start of a multi-line route for the selected preset
  const R = routeDef();
  if (!R.groups || !R.anchors || R.anchors.length < 2) return null;
  const g = R.groups.find(x => x.id === LuckyCore.selection.pace) || R.groups[0];
  const rows = R.anchors.map(a => ({ a, r: startRow(g, a.id) })).filter(x => x.r && x.r.p >= 0);
  if (rows.length < 2) return null;
  return { rows, best: rows.reduce((a, x) => (x.r.p > a.r.p ? x : a), rows[0]) };
}
const startShort = a => ANAME[a.id] || a.label;
function startTxt() {                                          // "Start: fade-in 13.3% · dock end 13.4% -> best ..."
  const c = startCompare();
  if (!c) return '';
  const cur = c.rows.find(x => x.a.id === anchor()), tie = cur && pct(cur.r.p) === pct(c.best.r.p);
  return ` <span class="small">Start: ${c.rows.map(x => (x.a.id === anchor() ? '<b>' : '') + startShort(x.a) + ' ' + pct(x.r.p) + ' (cast ' + fmtS(x.r.t) + ' after it)' + (x.a.id === anchor() ? '</b>' : '')).join(' · ')}` +
    (tie ? ' → this start is the best for this preset.' : ` → best for this preset: <b>${startShort(c.best.a)}</b> <a href="#" data-start="${c.best.a.id}">use it</a> (or change it under Start).`) + '</span>';
}
function labelStarts() {                                       // the Start menu shows each start's best odds for this preset
  let c = null;
  const sel = $('lkAnchor');
  try { c = startCompare(); } catch (e) { return; }
  if (!c || !sel) return;
  for (const o of sel.options) {
    const x = c.rows.find(y => y.a.id === o.value);
    if (x) o.textContent = `${x.a.label} — ${pct(x.r.p)}${pct(x.r.p) === pct(c.best.r.p) ? ' (best for this preset)' : ''}`;
  }
}
const crossOf = (r, o) => {                                    // r's cast plan if the runner really is in group o
  if (!(o.g.id in r.cross)) r.cross[o.g.id] = LuckyCore.valueWith(o.plan, r.t, sigVI(), r.pol, r.zones);
  return r.cross[o.g.id];
};
const sameAx = (a, b) => Object.keys(a).length === Object.keys(b).length && Object.keys(a).every(k => a[k] === b[k]);
const axGroup = (R, ax) => R.groups.find(g => sameAx(g.ax || {}, ax));
function axSel() {                                             // axes route: the selected group's tags ({} = all routes)
  const R = routeDef(), g = R.groups.find(y => y.id === LuckyCore.selection.pace);
  return (g && g.ax) || {};
}
function paceRows() {                                          // best plan per visible pace group (no profile)
  const R = routeDef();
  if (!(R.groups || (D.pace && route() === 'carry'))) return [];
  if (R.axes) {                                                // two cuts: all + every 1st cut; 2nd cuts once a 1st cut is picked
    const [A1, A2] = R.axes, gx = guessAx(), ax = gx ? Object.assign({}, axSel(), gx.ax) : axSel(), gs = [axGroup(R, {})].concat(A1.opts.map(o => axGroup(R, { [A1.id]: o.id })));
    if (ax[A1.id]) for (const o of A2.opts) gs.push(axGroup(R, { [A1.id]: ax[A1.id], [A2.id]: o.id }));
    return gs.filter(Boolean).map(paceRow);
  }
  const rows = LuckyCore.groups().map(paceRow);
  for (const r of rows) for (const o of rows) if (o !== r) crossOf(r, o);
  return rows;
}
const bandTxt = g => (g.band ? g.band : g.id === 'all' ? 'everyone' : g.hi >= 999 ? `${g.lo}+ frames` : g.lo === 0 ? `≤ ${g.hi} frames` : `${g.lo}–${g.hi} frames`);
function renderPace() {
  const rows = paceRows(), box = $('lkPace');
  if (!box) return;
  box.innerHTML = '';
  $('lkPaceHead').hidden = !rows.length;
  $('lkPaceHead').textContent = routeDef().axes_head ? routeDef().axes_head : routeDef().axes
    ? 'Presets by how you cut on the beach. Pick your 1st cut (down-left after the small wall), then your 2nd cut (down-right onto the pier): the 2nd-cut odds count only routes with that 1st cut. Each pick has its own best cast; ★ = best 2nd cut for that 1st cut.'
    : routeDef().groups
    ? 'Presets by how you cut on the beach: first cut (down-left after the small wall) and pier cut (down-right onto the pier). Pick the one that fits how you play; each has its own best cast.'
    : 'Your pace = total hesitation before the dog lands (4 menu presses + walking). Pick the one you think fits you; each has its own best cast.';
  if (!rows.length) {
    box.hidden = true;
    const R = routeDef();
    $('lkPaceTxt').innerHTML = R.id === 'carry' ? '' : `<b>${R.label}</b>: one dog line (${R.source ? R.source.casts + ' cast frames, ' + R.source.nut1 + ' Nut on bite 1, ' + R.source.nut2 + ' on bite 2' : ''}). ` +
      `${R.note || ''} Your bite taps check it: a bite that fits no cast frame on this line means you were on another line.`;
    return;
  }
  box.hidden = false;
  if (routeDef().axes) return renderAxes(rows);
  const tot = rows[0].g.routes || 1;
  for (const r of rows) {
    const el = paceCard(r, r.g.id === LuckyCore.selection.pace, r.g.label, bandTxt(r.g));
    el.title = r.g.desc ? `${r.g.desc}: ${Math.round(100 * r.g.share)}% of the simulated routes` + (r.g.cover < 0.999 ? ` (casts cover ${Math.round(100 * r.g.cover)}%)` : '')
      : r.g.id === 'all' ? 'All measured routes, as before' : `Routes whose menus + walking hesitate ${bandTxt(r.g)} (1/60 s) in total before the dog lands: ${Math.round(100 * r.g.routes / tot)}% of the measured routes`;
    el.onclick = () => setSelection(r.g.id, null);
    box.appendChild(el);
  }
  const cur = rows.find(r => r.g.id === LuckyCore.selection.pace) || rows[0];
  const others = rows.filter(r => r !== cur).map(r => `${r.g.label} ${pct(crossOf(cur, r))}`).join(' · ');
  $('lkPaceTxt').innerHTML = `<b>${cur.g.label}</b>: cast <b>${fmtS(cur.t)}</b> after ${startName()}, ${POLSHORT[cur.pol]}` +
    (cur.zones && cur.zones.length ? ` (release zones ${cur.zones.map(([a, b]) => `${fmtS1(a)}–${fmtS1(b)}`).join(', ')})` : '') +
    ` → <b>${pct(cur.p)}</b>. The same plan if you are really another pace: ${others}.` + startTxt();
}
function paceCard(r, selected, label, band, star) {             // one preset card: label, band, best odds, cast time, policy
  const el = document.createElement('div');
  el.className = 'lkcard' + (selected ? ' sel' : '');
  el.innerHTML = `<div class="small"><b>${label}</b>${star ? ' ★' : ''}</div><div class="band">${band}</div><div class="share">${pct(r.p)}</div>` +
    `<div class="small mono">${r.t > 0 ? fmtS(r.t) : '—'}</div><div class="band">${POLSHORT[r.pol]}</div>`;
  return el;
}
function renderAxes(rows) {                                    // two cuts: pick the 1st, then the 2nd (odds for that 1st cut only)
  const R = routeDef(), [A1, A2] = R.axes, own = axSel(), gx = guessAx(), box = $('lkPace');
  const ax = gx ? Object.assign({}, gx.ax, !gx.ax[A2.id] && own[A2.id] && axGroup(R, { [A1.id]: gx.ax[A1.id], [A2.id]: own[A2.id] }) ? { [A2.id]: own[A2.id] } : {}) : own;
  const ownMark = (el, id, axId) => { if (gx && (own[axId] || null) === id && (ax[axId] || null) !== id) el.classList.add('own'); };
  if (gx) {
    const d = document.createElement('div'); d.className = 'small'; d.style.cssText = 'flex:1 1 100%;color:var(--ok);font-weight:600';
    d.textContent = `Your dock-end tap says: ${gx.l1} ${Math.round(100 * gx.p1)}% (green)` +
      (gx.sure2 ? ` · 2nd cut ${gx.l2.toLowerCase()} ${Math.round(100 * gx.p2)}%` : gx.l2 ? ` · 2nd cut: the tap can't tell (best guess ${gx.l2.toLowerCase()} ${Math.round(100 * gx.p2)}%)` : '') +
      '. Dashed = your own pick, back after this attempt. The cast already uses every timing weighted by the tap.';
    box.appendChild(d);
  }
  const rowOf = g => rows.find(r => r.g === g), tip = (g, d) => `${d}: ${Math.round(100 * g.share)}% of the simulated routes` +
    (g.cover < 0.999 ? ` (casts cover ${Math.round(100 * g.cover)}%)` : '');
  const label = t => { const d = document.createElement('div'); d.className = 'small mut'; d.style.cssText = 'flex:1 1 100%;margin-top:2px'; d.textContent = t; box.appendChild(d); };
  const pick = a => { const g = axGroup(R, a); if (g) setSelection(g.id, null); };
  label(A1.label);
  const c1 = [{ o: { id: null, label: 'Any', band: 'not sure' }, g: axGroup(R, {}) }].concat(A1.opts.map(o => ({ o, g: axGroup(R, { [A1.id]: o.id }) })));
  for (const { o, g } of c1) {
    const r = g && rowOf(g); if (!r) continue;
    const el = paceCard(r, (ax[A1.id] || null) === o.id, o.label, o.band);
    ownMark(el, o.id, A1.id);
    el.title = o.id ? tip(g, (A1.short || A1.id) + ' ' + o.label.toLowerCase() + ' (' + o.desc + '), any ' + (A2.short || A2.id)) : tip(g, 'All simulated routes');
    el.onclick = () => pick(o.id ? (ax[A2.id] && axGroup(R, { [A1.id]: o.id, [A2.id]: ax[A2.id] }) ? { [A1.id]: o.id, [A2.id]: ax[A2.id] } : { [A1.id]: o.id }) : {});
    box.appendChild(el);
  }
  label(A2.label);
  let best = null, flat2 = false, c2best = [];
  if (!ax[A1.id]) {
    for (const o of A2.opts) {
      const el = document.createElement('div'); el.className = 'lkcard dim';
      el.innerHTML = `<div class="small"><b>${o.label}</b></div><div class="band">${o.band}</div><div class="share">—</div><div class="band">pick a ${A1.short || A1.id}</div>`;
      el.title = o.desc; box.appendChild(el);
    }
  } else {
    const o1 = A1.opts.find(o => o.id === ax[A1.id]);
    const c2 = A2.opts.map(o => ({ o, g: axGroup(R, { [A1.id]: ax[A1.id], [A2.id]: o.id }) })).filter(x => x.g && rowOf(x.g));
    best = c2.reduce((a, x) => (!a || rowOf(x.g).p > rowOf(a.g).p ? x : a), null);
    const any = { o: { id: null, label: 'Any', band: 'not sure' }, g: axGroup(R, { [A1.id]: ax[A1.id] }) };
    flat2 = c2.length > 0 && c2.every(x => pct(rowOf(x.g).p) === pct(rowOf(any.g).p));   // 2nd cut changes nothing on this start
    const stars = flat2 || !best ? [] : c2.filter(x => pct(rowOf(x.g).p) === pct(rowOf(best.g).p)).map(x => x.o.id);
    c2best = c2.filter(x => stars.includes(x.o.id)).map(x => x.o.label.toLowerCase());
    for (const { o, g } of [any].concat(c2)) {
      const r = rowOf(g), el = paceCard(r, (ax[A2.id] || null) === o.id, o.label, o.band, o.id && stars.includes(o.id));
      ownMark(el, o.id, A2.id);
      el.title = o.id ? tip(g, `${A1.short || A1.id} ${o1.label.toLowerCase()} + ${A2.short || A2.id} ${o.label.toLowerCase()} (${o.desc})`) : tip(g, `${A1.short || A1.id} ${o1.label.toLowerCase()}, any ${A2.short || A2.id}`);
      el.onclick = () => pick(o.id ? { [A1.id]: ax[A1.id], [A2.id]: o.id } : { [A1.id]: ax[A1.id] });
      box.appendChild(el);
    }
  }
  const cur = rows.find(r => r.g.id === LuckyCore.selection.pace) || rows[0];
  const sibs = ax[A2.id] ? A2.opts.filter(o => o.id !== ax[A2.id]).map(o => [o, axGroup(R, { [A1.id]: ax[A1.id], [A2.id]: o.id })])
    : ax[A1.id] ? A1.opts.filter(o => o.id !== ax[A1.id]).map(o => [o, axGroup(R, { [A1.id]: o.id })]) : [];
  const others = sibs.filter(([, g]) => g && rowOf(g)).map(([o, g]) => `${o.label.toLowerCase()} ${pct(crossOf(cur, rowOf(g)))}`).join(' · ');
  $('lkPaceTxt').innerHTML = `<b>${cur.g.id === 'all' ? 'Any cuts' : cur.g.label}</b>: cast <b>${fmtS(cur.t)}</b> after ${startName()}, ${POLSHORT[cur.pol]}` +
    (cur.zones && cur.zones.length ? ` (release zones ${cur.zones.map(([a, b]) => `${fmtS1(a)}–${fmtS1(b)}`).join(', ')})` : '') +
    ` → <b>${pct(cur.p)}</b>.` +
    (others && !(flat2 && ax[A2.id]) ? ` The same cast if your ${ax[A2.id] ? (A2.short || A2.id) : (A1.short || A1.id)} was really ${others}.` : '') +
    (!ax[A1.id] ? ` Pick your ${A1.short || A1.id} to see the ${A2.short || A2.id} odds for it.`
      : flat2 ? ` With this start the ${A2.short || A2.id} changes nothing: the dog's line is set before it (~3 s into the beach) and the stopwatch does not run from the dock end.`
      : !ax[A2.id] && best ? ` Best ${A2.short || A2.id} after ${A1.short || A1.id} ${A1.opts.find(o => o.id === ax[A1.id]).label.toLowerCase()}: <b>${c2best.join(' or ')}</b> (${pct(rowOf(best.g).p)}).` : '') +
    startTxt();
}
const fmtS1 = vi => ((vi - 1) * viMs() / 1000).toFixed(1);
const spansTxt = sp => sp.map(([a, b]) => (b - a > 12 ? `${fmtS1(a)}–${fmtS1(b)} s` : `~${fmtS1(a)} s`)).join(' or ');
function refresh() {
  const plan = planObj(), pol = polOf(plan), T = castT(plan, pol);
  run.plan = plan; run.pol = pol; run.T = T;
  run.zone = LuckyCore.zoneAt(P(plan), T, sigVI(), sigVI(), true);
  const p = pol === 'zone' && run.zone ? run.zone.value : valueAt(plan, pol, T);
  $('lkT').textContent = fmtS(T);
  $('lkP').textContent = pct(p);
  $('lkTAfter').textContent = `after ${startName()} →`;
  const pg = (route() !== 'carry' || D.pace) && LuckyCore.selection.pace !== 'all' ? LuckyCore.groups().find(g => g.id === LuckyCore.selection.pace) : null;
  $('lkPlanTxt').textContent = `${route() !== 'carry' ? routeDef().label + ' · ' : ''}${pg ? pg.label + (route() === 'carry' ? ' pace' : '') + ' · ' : ''}${plan.label} · ${POLNAME[pol]}${P(plan) !== plan ? ' · fitted to your taps' : ''}`;
  $('lkHow').innerHTML = howTo(plan, pol, T);
  if ($('lkPersonalCast')) { $('lkPersonalCast').checked = !!L.personalCast; $('lkPersonalTxt').hidden = !L.personalCast; $('lkPersonalTxt').innerHTML = personalTxt(); }
  renderPace(); labelStarts(); renderPlans(); renderTally(); renderProfile(); renderPractice(); renderFade2(); renderTimingSum(); drawOverview();
  syncTimingInputs();
}
function howTo(plan, pol, T) {
  const k = keyName(), steps = [];
  const RH = routeDef().howto;
  if (RH) steps.push(`<li>${RH}</li>`);
  if (anchor() === 'fadein' && doubleOn()) {
    const HOW = { exit: 'when Jack <b>stops at the ranch exit</b> (he stops dead under your stick, the screen starts to dim)',
                  fade: 'when the black screen <b>starts to brighten</b> (the beach fading in)',
                  ctrl: 'when Jack <b>turns down-right and walks</b> on the beach (hold down-right through the fade; 1.09 s after the first light)',
                  dock: 'when Jack <b>stops at the dock end</b>' };
    steps.push(`<li>Tap <kbd>${k}</kbd> ${tapCues().map(c => HOW[c.id]).join(', ')} (miss any one). The clock comes from the transition taps ` +
      `(start-key delay ${startDelay()} ms, then auto-tuned from your bite taps); the dock-end tap tells it your beach timing and re-aims the cast. ` +
      'Then walk the beach as above (the dog wakes about 3 s after the fade-in starts, plus your wait, while Jack is still on the wall; the 2nd cut does not move this stopwatch).</li>');
  }
  else if (anchor() === 'fadein') steps.push(`<li>Press <kbd>${k}</kbd> the moment the black screen after the ranch <b>starts to brighten</b> (the beach fading in, about a second before Jack can move; start-key delay ${startDelay()} ms, the tool learns your offset from your bite taps). ` +
    'Then walk the beach as above (the dog wakes about 3 s after the fade-in starts, plus your wait, while Jack is still on the wall; the 2nd cut does not move this stopwatch).</li>');
  else if (anchor() === 'beach') steps.push(`<li>Press <kbd>${k}</kbd> the moment the <b>beach appears</b> after the black screen (start-key delay ${startDelay()} ms; the tool learns your offset from your bite taps). ` +
    (RH ? 'Then walk the beach as above without pausing (the dog wakes ~3 s in and its line is fixed by that moment).</li>'
        : 'Then walk the route exactly: no pause in the first ~3 s on the beach (the dog wakes then and its line is fixed by that moment), then DR held to the pier end.</li>'));
  else if (anchor() === 'pier') steps.push(`<li>Hold DR to the ${RH ? 'dock' : 'pier'} end and press <kbd>${k}</kbd> the moment Jack <b>stops at the water</b> (READY, start-key delay ${startDelay()} ms).</li>`);
  else if (anchor() === 'dog') steps.push(`<li>Press <kbd>${k}</kbd> <b>together with A</b> as you put the dog down (it lands ~0.13 s after the A press; start-key delay ${L.dogDelayMs} ms). ` +
    'If you would rather press when you <i>see</i> it land, set the delay to about +150 ms. Turn SE as usual: from here, how long you take on the beach changes nothing.</li>');
  else steps.push(`<li>Press <kbd>${k}</kbd> the moment you have control after putting the dog down (READY, facing SE).</li>`);
  if (plan.k) steps.push(`<li>Mash <b>C-right</b> right away; stop as soon as you hear whistle <b>#${plan.k}</b> start (about ${fmtS(plan.whistleEnd)}).</li>`);
  if ((T - R0()) * viMs() > 37500) steps.push('<li>Push the stick <b>south-east</b> when the banner says so (33–38 s after READY) — the farmer naps at 40 s.</li>');
  steps.push(`<li>Press <b>B</b> on the green <b>CAST</b> flash (the lamp in L3 pulses 3-2-1 and a bar fills to the line): <b>${fmtS(T)}</b> after ${startName()} (the bobber plops 0.6 s later)` +
    (L.castTap ? `, and tap <kbd>${k}</kbd> together with it (the tool logs your real cast)` : '') + '. Face SE or E — the lab sees no difference.</li>');
  const tap = `tap <kbd>${k}</kbd> the moment the first bite shows`;
  if (pol === 'bite1') {
    const nb = nutBites().map(([a, b]) => b - a > 12 ? `${fmtS1(a)}–${fmtS1(b)} s` : `~${fmtS1(a)} s`).join(' or ');
    steps.push(`<li>Keep B held; <b>release at the first bite</b> (and ${tap} to log it). With this cast a Nut bite can only come at <b>${nb || '—'}</b>` +
      ' (the lamp turns amber and blinks twice just before each, green while it lasts): be ready then — B must be up within 0.33 s of the bite showing.</li>');
  }
  else if (pol === 'hold' || pol === 'tap') steps.push(`<li>Keep B held through the first bite and ${tap}. The tool tells you the Nut chance on bite 2: <b>DUD → reset now</b>, otherwise <b>release at the second bite</b>.</li>`);
  else {
    const zs = run.zone ? run.zone.zones.map(([a, b]) => `${fmtS1(a)}–${fmtS1(b)} s`).join(', ') : '';
    steps.push(`<li>Keep B held. If the first bite comes inside a <b style="color:var(--ok)">release window</b> (${zs || 'none'}; the lamp is amber just before, green while it is open), <b>release</b> and ${tap}. ` +
      `If it comes <b>before</b> a window, or a window passes with no bite, <b>hold through it</b> and ${tap}: the tool reads which frame and dog path (or line) you are on and forecasts bite 2 — ` +
      '<b>DUD → reset now</b> (red lamp), otherwise the Nut chance and the moment(s) bite 2 can be the Nut (amber just before, green then). Release bite 2 there and tap it too.</li>');
  }
  steps.push('<li>A bite = the rod-pull animation; you have its 0.33 s to let go of B. Power Nut (he eats it) → <kbd>H</kbd>; a fish → <kbd>M</kbd>; ' +
    'the line came back <b>empty</b> → <kbd>E</kbd> (that means B went up outside the bite window). Reset the console, go again. Logged taps fit the plan to you and tell you after each attempt whether the cast or the release missed (L4 · Attempts).</li>');
  return '<ol>' + steps.join('') + '</ol>';
}

/* ---------------------------------------------------------------- overview histogram (0-45 s, click = cast time) */
function drawOverview() {
  const cv = $('lkOverview'), dpr = devicePixelRatio, W = cv.width = cv.clientWidth * dpr, H = cv.height = 110 * dpr;
  const g = cv.getContext('2d'), plan = run.plan;
  g.clearRect(0, 0, W, H);
  const X = t => (t / LuckyCore.TMAX) * W;
  const curves = { bite1: curveC(plan, 'bite1'), hold: curveC(plan, 'hold'), zone: curveC(plan, 'zone') };
  const col = { bite1: '#5fd38d', hold: '#e7c14a', zone: '#ffffff' };
  let ymax = 0.05;
  for (const a of Object.values(curves)) for (let t = 30; t < a.length; t++) if (!isNaN(a[t])) ymax = Math.max(ymax, a[t]);
  ymax *= 1.1;
  const Y = p => H - 14 * dpr - (p / ymax) * (H - 24 * dpr);
  if (plan.k && plan.whistleEnd > 0) { g.fillStyle = '#b48cff33'; g.fillRect(0, 0, X(plan.whistleEnd), H); }
  const selPol = run.pol === 'tap' ? 'hold' : run.pol, sel = curves[selPol];
  g.fillStyle = col[selPol] + '66';
  for (let t = 1; t < sel.length; t += 2) if (!isNaN(sel[t])) g.fillRect(X(t), Y(sel[t]), Math.max(1, X(2) - X(0)), Y(0) - Y(sel[t]));
  for (const pol of ['bite1', 'hold', 'zone']) {
    if (pol === selPol) continue;
    const a = curves[pol];
    g.strokeStyle = col[pol] + '55'; g.lineWidth = 1 * dpr; g.beginPath();
    let on = false;
    for (let t = 1; t < a.length; t += 4) { if (isNaN(a[t])) { on = false; continue; } if (!on) g.moveTo(X(t), Y(a[t])); else g.lineTo(X(t), Y(a[t])); on = true; }
    g.stroke();
  }
  g.strokeStyle = '#ffffff44'; g.setLineDash([4 * dpr, 4 * dpr]); g.beginPath(); g.moveTo(0, Y(1 / 51)); g.lineTo(W, Y(1 / 51)); g.stroke(); g.setLineDash([]);
  g.fillStyle = '#8ea3b2'; g.font = `${10 * dpr}px ui-monospace,monospace`;
  for (let sec = 0; sec <= 45; sec += 5) g.fillText(sec + 's', X(sec * 1000 / viMs() + 1) + 2, H - 2 * dpr);
  g.fillText(`max ${(100 * ymax / 1.1).toFixed(0)}% · stopwatch from ${startName()}`, 2, 10 * dpr);
  if (run.T) { g.strokeStyle = '#6fb7ff'; g.lineWidth = 2 * dpr; g.beginPath(); g.moveTo(X(run.T), 0); g.lineTo(X(run.T), H); g.stroke(); }
}
function overviewClick(e) {
  const r = e.target.getBoundingClientRect(), t = Math.round(((e.clientX - r.left) / r.width) * LuckyCore.TMAX);
  const plan = run.plan;
  if (t < plan.firstT) return;
  L.castT = t - (t % 2); save(); refresh();
}

/* ---------------------------------------------------------------- tally */
function renderTally() {
  const mine = tally.filter(x => (x.route || 'carry') === route());
  const n = mine.length, h = mine.filter(x => x.hit).length;
  const p = run.plan ? valueAt(run.plan, run.pol, run.T) : NaN;
  const recent = mine.slice(-12).map(x => `<span class="${x.hit ? 'hit' : 'miss'}" title="${x.plan} · ${x.T}${x.outcome ? ' · ' + x.outcome : ''}">${x.hit ? '●' : x.outcome === 'empty' ? '◌' : '○'}</span>`).join('');
  const atLeast = isNaN(p) || !n ? '' : ` · with ${pct(p)} per try, ${pct(1 - Math.pow(1 - p, n))} of runners would have one by now`;
  const empties = mine.filter(x => x.outcome === 'empty').length, tapped = mine.filter(x => x.fit !== undefined && x.tap !== undefined);
  const onLine = tapped.filter(x => x.fit).length, others = tally.length - n;
  $('lkTally').innerHTML = (route() !== 'carry' ? `<div class="small mut">Route <b>${routeDef().label}</b>${others ? ` (${others} attempt${others === 1 ? '' : 's'} on other routes not counted here)` : ''}</div>` : '') +
    `<div><b>${h}</b> Power Nut${h === 1 ? '' : 's'} in <b>${n}</b> tr${n === 1 ? 'y' : 'ies'} ` +
    `(${n ? pct(h / n) : '—'})${atLeast}</div><div class="small mut">Plan: ~${isNaN(p) || p <= 0 ? '—' : (1 / p).toFixed(1)} tries per Nut on average. Blind 1/51 would be 51.</div>` +
    (empties ? `<div class="small">${empties} of the misses came back empty (B outside the bite window).</div>` : '') +
    (route() !== 'carry' && tapped.length ? `<div class="small">Line check: ${onLine} of ${tapped.length} tapped bites fit ${routeDef().lines ? "one of this route's " + routeDef().lines.length + ' dog lines' : "this route's dog line"}` +
      `${tapped.length - onLine ? ' — the others were off the simulated routes (this table does not apply to them)' : ''}.</div>` : '') +
    `<div class="lkrecent">${recent}</div>`;
  renderLast();
}
function saveTap(hit) {                                        // fold this attempt's bite-1 tap into the profile
  const ti = run.tapInfo;
  if (!ti || ti.saved) return;
  ti.saved = true;
  const cs = run.cs || 0;                                        // stored on the unshifted stopwatch (auto-tune), so the profile fits one offset
  taps.push({ k: run.plan.k, T: ti.Teff - cs, tau: +(ti.tau - cs).toFixed(1), hit, pNut: +ti.pNut.toFixed(4), at: Date.now(),
              anchor: anchor(), pace: LuckyCore.selection.pace, pol: run.pol, route: route(), ...(cs ? { cs: +cs.toFixed(2) } : {}),
              ...(anchor() === 'fadein' ? { ref: L.beachCue } : {}),
              ...(run.castTap !== null ? { c: +(run.castTap - cs).toFixed(1) } : {}), ...(ti.tau2 != null ? { tau2: +(ti.tau2 - cs).toFixed(1) } : {}) });
  taps = taps.slice(-200); store.set('hm64v29_lucky_taps', taps);
  updateProfile();
}
/* start-key presses after the start: with B (the cast, if on and near the aim), then at the first bite */
function isCastTap(t) { return L.castTap && run.castTap === null && !run.tapInfo && t > run.T - 90 && t < run.T + 45; }
function registerCast(t) {
  if (run.preview || run.castTap !== null) return false;
  run.castTap = t;
  run.castErrMs = (t - run.T) * viMs() - cueCorr();                // vs the CAST cue
  beepAt(now(), 1500, 0.03, 0.08);
  cueFlash(`CAST LOGGED ${msTxt(run.castErrMs)}`, Math.abs(run.castErrMs) <= 1000 / 60 ? 'go' : 'info', 1200);
  return true;
}
function registerTap(t) {                                       // the first bite (any policy)
  const cast0 = run.castTap !== null ? run.castTap : run.T;
  if (run.tapInfo || run.preview || t < cast0 + G_CAST) return false;
  const Teff = run.T + cueCorr() / viMs(), withCast = run.castTap !== null;
  const b0 = (prof ? (withCast ? prof.bias0 : prof.bias) : 0) - (run.cs || 0);   // this stopwatch is already shifted by cs
  const post = LuckyCore.tapPosterior(P(run.plan), Math.round(Teff), sigVI(), b0, t,
                                      lagMu(), lagSd(), null, withCast ? Object.assign({ c: run.castTap }, castCfg()) : null);
  if (run.gp && run.gp.t3 != null) {                            // dock-end record (plan before the dock-end re-weighting)
    const post0 = run.plan0 && run.plan0 !== run.plan ? LuckyCore.tapPosterior(P(run.plan0), Math.round(Teff), sigVI(), b0, t,
      lagMu(), lagSd(), null, withCast ? Object.assign({ c: run.castTap }, castCfg()) : null) : post;
    run.reflexRec = reflexFrom(post0);
  }
  const sum = LuckyCore.tapSummary(post, t);
  let nz = 0, acc = 0, med = null;
  const nuts = post.sc.filter(e => e.n2).sort((a, b) => a.t2 - b.t2);
  nuts.forEach(e => { nz += e.w; });
  for (const e of nuts) { acc += e.w; if (acc >= nz / 2) { med = e.t2; break; } }
  const fit = post.sc.length > 0 && post.Z > 1e-4;
  // bite 2 still matters when the plan holds bite 1: always for 2nd-bite policies; for smart zones (release windows)
  // when the bite came before a window or after it (the runner held through it and tapped it)
  const holdish = run.pol === 'hold' || run.pol === 'tap' || (run.pol === 'zone' && !inZone(t - lagMu()));
  const spans2 = holdish && fit ? LuckyCore.nutSpans(post.sc.filter(e => e.n2).map(e => [e.t2, e.w]), 0.25, 30) : [];
  run.tapInfo = { tau: t, Teff, pNut: fit ? post.pNut : 0, p1: fit ? post.p1 : NaN, fit, sc: post.sc, nutT2: med, holdish, sum, spans2,
                  dud: holdish && fit && 100 * post.pNut < L.dudPct, withCast, tau2: null, p2b: NaN };
  const ti = run.tapInfo;
  if (!holdish) { beepAt(now(), 1100, 0.04, 0.1); return true; }
  cancelBeeps();                                                // the bite-1 window chirps no longer apply
  if (!fit) { beepAt(now(), 300, 0.25, 0.2); }
  else if (ti.dud) { beepAt(now(), 330, 0.12, 0.25); beepAt(now() + 170, 260, 0.2, 0.25); }
  else {
    beepAt(now(), 990, 0.08, 0.2);
    for (const [a] of spans2) {                                   // get-ready ticks before each bite-2 Nut moment
      const wa = run.wall0 + (a - 1) * viMs();
      if (wa - 600 > now() + 200) { beepAt(wa - 600, 1320, 0.035, 0.12); beepAt(wa - 300, 1320, 0.035, 0.12); }
    }
  }
  return true;
}
/* optional: the start key again at bite 2 (after holding bite 1) - both bites now pin the frame */
function registerTap2(t) {
  const ti = run.tapInfo;
  if (!ti || !ti.holdish || ti.tau2 != null || ti.saved || run.preview || t < ti.tau + G_RECAST) return false;
  const post = LuckyCore.tapPosterior(P(run.plan), Math.round(ti.Teff), sigVI(), (prof ? (ti.withCast ? prof.bias0 : prof.bias) : 0) - (run.cs || 0), ti.tau,
                                      lagMu(), lagSd(), null, ti.withCast ? Object.assign({ c: run.castTap }, castCfg()) : null, t);
  ti.tau2 = t; ti.p2b = post.sc.length && post.Z > 0 ? post.pNut : NaN;
  beepAt(now(), 1100, 0.04, 0.1);
  return true;
}
/* outcome: 'nut' | 'fish' (caught a fish / missed) | 'empty' (the rod came back with nothing) */
function record(hit, kind) {
  if (!run.plan) return;
  kind = hit ? 'nut' : (kind || 'fish');
  const ti = run.tapInfo, pol = run.pol;
  run.last = diagnose(kind, ti, pol);
  if (run.reflexRec) { dock.push(run.reflexRec); dock = dock.slice(-80); store.set('hm64v29_lucky_dock', dock); run.reflexRec = null; }
  saveTap(hit);
  tally.push({ at: Date.now(), plan: run.plan.label, pol, T: fmtS(run.T), hit, outcome: kind, sigma: sigmaMs(), ...(L.audio ? {} : { v: 1 }),
               pace: LuckyCore.selection.pace, start: anchor(), route: route(), fit: ti ? !!ti.fit : undefined,
               cast: run.castTap !== null ? +((run.castTap - 1) * viMs() / 1000).toFixed(3) : undefined,
               castErrMs: run.castTap !== null ? Math.round(run.castErrMs) : undefined,
               tap: ti ? +((ti.tau - 1) * viMs() / 1000).toFixed(3) : undefined, tapNut: ti ? +ti.pNut.toFixed(3) : undefined,
               bite1Nut: ti && ti.fit ? +ti.p1.toFixed(3) : undefined, lagMs: ti && ti.sum ? Math.round(ti.sum.lag * viMs()) : undefined });
  store.set('hm64v29_lucky_tally', tally);
  run.result = hit ? 'nut' : 'miss'; run.resultAt = now();
  stop(false); renderTally();
}
const verdict = p1 => (isNaN(p1) ? (routeDef().lines ? "fits none of this route's dog lines (off the simulated routes)" : route() !== 'carry' ? 'off this line (fits no cast frame on it)' : 'fits no dog path') : p1 >= 0.8 ? `a Power Nut bite (${pct(p1)})` : p1 <= 0.02 ? 'a fish bite' : `maybe the Nut (${pct(p1)})`);
/* what went wrong (or right), from the taps and what came out of the water. Game facts (player.c handleFishingAction):
   B up during the bite (20 polls) -> catch; B up at any other moment -> the line comes back empty; the lab: releases
   1-2 frames after the window still catch, but a fish */
function diagnose(kind, ti, pol) {
  const parts = [];
  if (run.gp) parts.push(gpTxt());
  if (run.castTap !== null) parts.push(`cast ${run.castErrMs >= 0 ? '+' : ''}${Math.round(run.castErrMs)} ms vs the CAST cue`);
  const releasedAt1 = pol === 'bite1' || (pol === 'zone' && ti && !ti.holdish);
  if (ti) {
    parts.push(`bite ${ti.holdish ? '1 (held) ' : ''}tapped at ${fmtS(ti.tau)}: ${verdict(ti.p1)}` + (route() === 'carry' && ti.sum && ti.sum.pathShare >= 0.5 ? ` (most likely dog path ${ti.sum.path + 1}, ${pct(ti.sum.pathShare)})` : '') +
      (routeDef().lines && ti.sum && ti.sum.pathShare >= 0.3 ? ` (most likely dog line ${routeDef().sidxs.indexOf(ti.sum.path) + 1} of ${routeDef().lines.length}, ${pct(ti.sum.pathShare)})` : ''));
    if (ti.holdish && ti.fit) parts.push(ti.dud ? `bite 2 forecast: DUD (${pct(ti.pNut)})` : `bite 2 forecast: Nut ${pct(ti.pNut)}`);
    if (ti.tau2 != null) parts.push(`bite 2 tapped at ${fmtS(ti.tau2)}: ${verdict(ti.p2b)}`);
  }
  let advice = '';
  if (kind === 'nut') advice = 'Power Nut!';
  else if (ti && ti.holdish && ti.tau2 != null) {
    if (kind === 'empty') advice = 'Empty line = B went up outside bite 2’s 0.33 s window.' + (ti.p2b >= 0.8 ? ' That bite was the Nut: release sooner.' : '');
    else if (ti.p2b >= 0.8) advice = 'A fish from a Nut bite 2: B most likely went up 1–2 frames after the window. Release sooner.';
    else if (ti.p2b <= 0.02) advice = 'Bite 2 was a fish however you released: not a release problem.';
  }
  else if (ti && ti.holdish && ti.dud) advice = 'Bite 2 could not be the Nut (the tool said reset).';
  else if (kind === 'empty') advice = 'Empty line = B went up outside the bite’s 0.33 s window (too late, or before the bite).' +
    (ti && ti.p1 >= 0.8 ? ' And that bite was the Nut: release sooner.' : '');
  else if (ti && releasedAt1 && ti.p1 >= 0.8) advice = 'A fish from a Nut bite: B most likely went up 1–2 frames after the window (lab: releases at +20/+21 polls give a fish). Release sooner.';
  else if (ti && releasedAt1 && ti.p1 <= 0.02) advice = 'That bite was a fish however you released: the cast landed on a fish frame (cast timing / dog path), not a release problem.';
  else if (ti && releasedAt1) advice = 'Not sure which frame you landed on.';
  return { text: parts.join(' · '), advice, kind };
}
function renderLast() {
  const el = $('lkLast');
  if (!el) return;
  const d = run.last;
  el.innerHTML = d ? `<b>Last attempt</b> (${d.kind === 'nut' ? 'Power Nut' : d.kind === 'empty' ? 'empty line' : 'fish'}): ${d.text || 'no taps'}.` +
    (d.advice ? ` <span style="color:${d.kind === 'nut' ? 'var(--ok)' : '#ffd28a'}">${d.advice}</span>` : '') : '';
}

function renderProfile() {
  const el = $('lkProfile');
  if (!el) return;
  if (!prof || !prof.n) {
    el.innerHTML = `<span class="mut">Personal profile: no bite taps yet${taps.length ? ' with this start (' + startName() + ')' : ''}. Press the start key again when the first bite shows, every attempt; the plan then fits your own arrivals and timing.</span>`;
    return;
  }
  const top = Object.entries(prof.byPath).sort((a, b) => b[1] - a[1]).slice(0, 4).map(([k, m]) => `path ${+k + 1} ${Math.round(100 * m)}%`).join(', ');
  el.innerHTML = `<b>Bite taps</b>: ${prof.n} on this start${prof.nofit ? ` (${prof.nofit} fit no dog path)` : ''}, mostly ${top}. ` +
    `<label><input type="checkbox" id="lkPersonal" ${L.personal ? 'checked' : ''}> fit the plan to me</label> ` +
    '<button id="lkForget">Forget taps</button>';
  $('lkPersonal').onchange = e => { L.personal = e.target.checked; save(); persCache.clear(); bestCache = null; ccache.clear(); L.castT = null; refresh(); };
  $('lkForget').onclick = () => { if (confirm('Forget all bite taps (personal profile)?')) { taps = []; store.set('hm64v29_lucky_taps', taps); updateProfile(); refresh(); } };
}

/* ---------------------------------------------------------------- run control */
/* v29.9 tap assignment on the fade-in start. The runner picks the cues to tap; any one can be missed. Times on the
   fade-in clock, VIs after the first light (lab, rendered + 30/30 ranch states): ranch exit -70 (the first frame Jack
   stands still = the first dimmer frame, main loop EXIT_LEVEL), first light 0, first control +66 (down-right held
   through the load: MAIN_GAME at VI 65 after the map change, Jack moves 6 units at 67 - a hair of scroll - and turns to
   face down-right at 69, the visible cue; rendered 2026-11-15), dock end = READY of the route
   (no fixed time: it depends on the beach walk, so it tells the timer which beach timing it was). */
const CTRL_VI = 66;
const CUES = [
  { id: 'exit', vi: -GP_GAP_VI, short: 'ranch exit', label: 'Last control at the green ranch exit (Jack stops dead, the screen starts to dim)' },
  { id: 'fade', vi: 0, short: 'fade-in', label: 'First light of the beach fade-in (the black screen starts to brighten)' },
  { id: 'ctrl', vi: CTRL_VI, short: 'first control', label: 'First control on the beach: Jack turns down-right and walks (hold down-right through the fade)' },
  { id: 'dock', vi: null, short: 'dock end', label: 'Jack stops at the dock end (READY)' }];
/* tap strategies: which cues a runner taps. 'B' = the beach cue (first light OR first control: they are 1.09 s
   apart, too close to tap both and still play). In two-tap sets the 2nd may be missed; in the three-tap set any one. */
const STRATS = [
  { id: 'b', cues: ['B'], label: '1 tap: the beach cue', note: 'the clock from one tap' },
  { id: 'eb', cues: ['exit', 'B'], label: '2 taps: ranch exit + beach cue', note: 'a sharper clock; the 2nd may be missed' },
  { id: 'bd', cues: ['B', 'dock'], label: '2 taps: beach cue + dock end', note: 'clock + your beach timing (re-aims the cast); the 2nd may be missed' },
  { id: 'ebd', cues: ['exit', 'B', 'dock'], label: '3 taps: ranch exit + beach cue + dock end', note: 'sharper clock + beach timing; any one may be missed' },
  { id: 'd', cues: [], label: '1 tap: dock end only', note: 'the dock-end start (READY), no transition taps' }];
const strat = () => (anchor() === 'pier' ? STRATS[4] : STRATS.find(x => x.id === L.tapStrategy) || STRATS[3]);
const tapCues = () => { const ids = strat().cues.map(x => (x === 'B' ? L.beachCue : x)); return CUES.filter(c => ids.includes(c.id)); };
const clockCues = () => tapCues().filter(c => c.vi != null);
const doubleOn = () => anchor() === 'fadein';
/* auto-tune: shift the stopwatch by the console offset the bite-tap profile has learned (n >= 8), so the beeps, zones
   and countdown land on the console's time. Taps are stored on the unshifted stopwatch (saveTap) and the profile fits
   those, so it never chases its own correction. */
const TEST = { autoB: null, prof: null };
/* the one-reaction tie is an assumption: bite taps that come later than your start taps push its clock estimate too far
   (lab sim, 24 attempts: bite taps as late as the start taps -> k 4 for a true 3.3 VI; 100 ms later -> k 7, about half
   the difference). Shrunk toward 0 by start-tap error sd 50 ms (3 VI) vs that half of a +-60 ms bite-vs-start
   difference (1.8 VI): 9 / (9 + 3.2) = 0.7. Equal taps lose ~1 VI; 100 ms slower bite taps land ~20 ms early, not ~55. */
const TIE_SHRINK = 0.7;
function autoB() {
  if (TEST.autoB != null) return TEST.autoB;
  const prof = TEST.prof || prof_();
  if (!L.autoTune || !prof || prof.n < 8) return 0;
  /* the clock is tuned from attempts WITH the cast tap only (bias0: the bite's delay after your own cast moment pins the
     frame, so clock, B press and bite-tap lag come apart). Without it a bite tap mixes all three: in the lab sim (start
     tap 50 ms late, B 100 ms late, bite taps 215 ms) the fit put the shift into the bite lag (bias ~0), and neither
     "bias" nor "bias + correction" tunes the clock right. The B press is the cast-cue correction's job. */
  let b;
  if ((prof.nCast || 0) >= 8) b = prof.bias0;                   // cast taps: no assumption needed
  else if (L.tieReaction !== false && prof.kTied != null && (prof.nNoCast || 0) >= 8) b = Math.round(TIE_SHRINK * prof.kTied);   // one reaction
  else return 0;
  return Math.max(-18, Math.min(18, b || 0));
}
/* per attempt, the clock taps' times minus their cue times (ms), centred on the attempt's mean: the per-cue offsets
   (vs your beach-cue tap) and one tap's spread come from these (no bite needed). One tap set per route + tap strategy
   + beach cue, each in its own localStorage key (hm64v29_lucky_tapset/<route>/<strategy>/<cue>): [{at, y: {cue: ms},
   d?: dock tapped, s?: strays, x?: culled by the player, m?: carried over from the old shared list (strategy unknown)}].
   Stats use the last 40 kept (not culled) records of the set. */
const TS_PRE = 'hm64v29_lucky_tapset/', TS_KEEP = 120, TS_USE = 40;
const tsKey = (rt, st, cue) => TS_PRE + rt + '/' + st + '/' + cue;
const curTs = () => tsKey(baseOf(route()), strat().id, L.beachCue);   // tap timing does not depend on the variant
const tsCache = new Map();
function tsGet(k) {
  if (!tsCache.has(k)) { const v = store.get(k, []); tsCache.set(k, Array.isArray(v) ? v : []); }
  return tsCache.get(k);
}
function tsPut(k, a) {
  tsCache.set(k, a);
  if (a.length) store.set(k, a); else { try { localStorage.removeItem(k); } catch (e) { /* storage unavailable */ } }
}
function tsKeys() {                                            // every stored set (localStorage + this session's cache)
  const out = new Set();
  try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k && k.startsWith(TS_PRE)) out.add(k); } } catch (e) { /* none */ }
  for (const [k, a] of tsCache) if (a.length) out.add(k);
  return [...out];
}
function migrateTapRec() {                                     // the old shared list (and older exit/fade-in pairs) -> sets
  if (store.get('hm64v29_lucky_tapset_v', 0)) return;
  const old = store.get('hm64v29_lucky_taprec', null);
  const src = Array.isArray(old) ? old : fade2.map(p => ({ at: p.at, route: p.route, y: { exit: -p.d / 2, fade: p.d / 2 } }));
  const touched = new Set();
  for (const r of src) {
    const cue = r.y && (r.y.ctrl != null ? 'ctrl' : r.y.fade != null ? 'fade' : null);
    if (!cue || r.y.exit == null) continue;
    const k = tsKey(r.route || 'lineup-dogbeach', 'ebd', cue);  // the old list did not record the strategy
    tsGet(k).push({ at: r.at, y: r.y, m: 1 }); touched.add(k);
  }
  for (const k of touched) tsPut(k, tsGet(k).sort((a, b) => a.at - b.at).slice(-TS_KEEP));
  try { localStorage.removeItem('hm64v29_lucky_taprec'); } catch (e) { /* none */ }
  store.set('hm64v29_lucky_tapset_v', 1);
}
migrateTapRec();
const med = a => { const v = a.slice().sort((x, y) => x - y), n = v.length; return n ? (n % 2 ? v[(n - 1) / 2] : (v[n / 2 - 1] + v[n / 2]) / 2) : NaN; };
function tapStats(keys) {
  keys = keys || [curTs()];
  const rs = [].concat(...keys.map(k => tsGet(k).filter(r => !r.x).slice(-TS_USE))), ref = L.beachCue, off = { [ref]: { n: 0, m: 0 } };
  for (const c of CUES) {
    if (c.vi == null || c.id === ref) continue;
    const v = rs.filter(r => r.y[c.id] != null && r.y[ref] != null).map(r => r.y[c.id] - r.y[ref]);
    off[c.id] = { n: v.length, m: v.length ? med(v) * v.length / (v.length + 2) : 0, raw: med(v) };   // shrunk while few
  }
  let ss = 0, df = 0, nrec = 0;
  for (const r of rs) {
    const ys = Object.entries(r.y).map(([k, v]) => v - (off[k] ? off[k].m : 0));
    if (ys.length < 2) continue;
    const mu = ys.reduce((a, v) => a + v, 0) / ys.length;
    ss += ys.reduce((a, v) => a + (v - mu) ** 2, 0); df += ys.length - 1; nrec++;
  }
  return { off, nrec, sdAuto: nrec >= 5 && df ? Math.max(15, Math.sqrt(ss / df)) : NaN };
}
/* one clock tap's spread: manual, or auto from this set (strategies with 2 clock taps); strategies with ONE clock tap
   cannot show a spread, so they borrow it from the 2-clock-tap sets (ranch exit + beach cue) of this route + beach cue */
const TWO_CLOCK = ['eb', 'ebd'];
function precision() {
  if (!L.tapSdAuto) return { sd: L.tapSdMs, src: 'manual' };
  const own = clockCues().length >= 2;
  const st = tapStats(own ? [curTs()] : TWO_CLOCK.map(x => tsKey(baseOf(route()), x, L.beachCue)));
  return isFinite(st.sdAuto) ? { sd: st.sdAuto, src: own ? 'own' : 'borrowed', n: st.nrec } : { sd: 60, src: 'default', n: st.nrec, own };
}
const clockSd = () => precision().sd;
/* the cascade: the timing-spread slider assumes ONE start tap of +-60 ms (as cast practice sets it: hypot(SD, 60));
   on the fade-in start the clock comes from n clock taps of spread s each, so that part becomes s / sqrt(n) */
const START1_MS = 60;
function sigEffMs(aid) {
  if ((aid || anchor()) !== 'fadein') return sigmaMs();
  const sc = clockSd() / Math.sqrt(Math.max(1, clockCues().length));
  return Math.round(Math.sqrt(Math.max(sigmaMs() ** 2 - START1_MS ** 2, 30 ** 2) + sc ** 2));
}
function start(ts) {
  if (run.wall0 !== null || run.practice) return;
  cancelBeeps();
  refresh();
  ts = ts == null ? now() : ts;
  run.gp = null; run.plan0 = run.plan; run.cs = autoB(); run.reflexRec = null;
  if (doubleOn()) {
    run.gp = { taps: [ts], last: ts, asg: null, g3: null, rdy: readySpread(run.plan) };
    assign(run.gp, false);
  } else run.wall0 = ts - startDelay() - run.cs * viMs();       // the start event, from the key press
  run.beeped = new Set(); run.result = null; run.preview = null; run.tapInfo = null; run.castTap = null; run.castErrMs = null;
  scheduleBeeps();
  if (run.gp && routeDef().axes) {                              // warm the preset rows (one per tick) for the dock-end highlight
    const gs = routeDef().groups.slice(), id = run.wall0;
    const step = () => { if (run.wall0 === null || run.wall0 !== id && !run.gp || !gs.length) return; paceRow(gs.shift()); setTimeout(step, 40); };
    setTimeout(step, 60);
  }
}
let dock = store.get('hm64v29_lucky_dock', []);                // [{at, route, ms: dock-end tap - READY (bite posterior), sd}]
function dockStat() {
  const v = dock.slice(-40).map(x => x.ms).filter(x => isFinite(x)), n = v.length;
  return n ? { n, med: med(v) } : { n: 0 };
}
const r2abs = () => startDelay() + (run.cs || 0) * viMs();     // your clock taps' delay (start-key delay + auto-tune)
const r3abs = () => r2abs();                                   // the dock-end tap: taken as late as the clock taps
function readySpread(plan) {                                   // READY (dock end) on this plan's routes, VIs after the first light
  const v = plan.variants, W = v.reduce((a, x) => a + x.w, 0) || 1;
  const mean = v.reduce((a, x) => a + x.w * x.minT, 0) / W, sd = Math.sqrt(v.reduce((a, x) => a + x.w * (x.minT - mean) ** 2, 0) / W);
  return { mean: mean - 1, sd };                               // minT counts from 1 at the first light
}
/* which cue each tap was: every assignment of the taps (in time order) to the chosen cues (in time order) or to
   "stray", scored by how well the clock taps agree on one first light (spread s each), the dock tap's fit to READY on
   this plan's routes, a 1-in-10 prior per skipped cue and 1-in-20 per stray. Then the clock = the mean of the clock
   taps (minus each cue's learned offset vs your fade-in tap), aligned by the start-key delay, plus auto-tune. */
function assign(g, beeps) {
  const cues = tapCues(), vi = viMs(), s = clockSd(), off = tapStats().off, ws = g.taps, n = ws.length;
  const yOf = (w, c) => w - c.vi * vi - (off[c.id] ? off[c.id].m : 0);
  let best = null;
  const rec = (i, ci, a) => {
    if (i === n) { score(a.slice()); return; }
    a.push(-1); rec(i + 1, ci, a); a.pop();                    // stray
    for (let k = ci; k < cues.length; k++) { a.push(k); rec(i + 1, k + 1, a); a.pop(); }
  };
  const score = a => {
    const ys = [], dk = [];
    a.forEach((k, i) => { if (k < 0) return; if (cues[k].vi == null) dk.push(ws[i]); else ys.push(yOf(ws[i], cues[k])); });
    if (!ys.length) return;                                    // a clock tap is needed for this start
    const F = ys.reduce((x, v) => x + v, 0) / ys.length;
    let L = 0;
    for (const y of ys) L += -0.5 * ((y - F) / s) ** 2 - Math.log(s);
    L += Math.log(s);                                          // n - 1 free deviations
    const sdF = s / Math.sqrt(ys.length);
    for (const w of dk) {
      const sd = Math.hypot(g.rdy.sd * vi, Math.max(50, s), sdF), z = (w - (F - startDelay() + g.rdy.mean * vi + r3abs())) / sd;
      L += -0.5 * z * z - Math.log(sd);
    }
    const used = a.filter(k => k >= 0), last = used.length ? used[used.length - 1] : -1;
    const skips = cues.slice(0, last + 1).filter((c, k) => !used.includes(k)).length;
    const strays = a.filter(k => k < 0).length;
    L += skips * Math.log(0.1) + strays * (Math.log(0.05) + Math.log(1 / 8000));
    if (!best || L > best.L) best = { L, a, F, sdF, nClock: ys.length };
  };
  rec(0, 0, []);
  if (!best) best = { a: [0], F: yOf(ws[0], cues.find(c => c.vi != null) || CUES[1]), sdF: s, nClock: 1 };
  g.asg = best;
  g.cue = {};
  best.a.forEach((k, i) => { if (k >= 0) g.cue[cues[k].id] = ws[i]; });
  g.F = best.F - startDelay(); g.sdF = best.sdF;
  run.wall0 = g.F - (run.cs || 0) * vi;
  if (beeps !== false) { cancelBeeps(); scheduleBeeps(); }
}
function seqPress(w) {
  const g = run.gp;
  if (w - g.last < 300) return 'bounce';
  g.last = w;
  const had = g.cue && g.cue.dock;
  g.taps.push(w);
  assign(g);
  const idx = g.asg.a[g.taps.length - 1];
  const what = idx < 0 ? 'stray' : tapCues()[idx].id;
  cueFlash(what === 'stray' ? 'EXTRA TAP IGNORED' : CUES.find(c => c.id === what).short.toUpperCase() + ' ✓', what === 'stray' ? 'hold' : 'info', 700);
  if (g.cue.dock && g.cue.dock !== had) setTimeout(goal3, 20);
  renderFade2();
  return what;
}
/* the dock-end tap: re-weight this plan's routes by how well their READY time fits the tap (one tap's spread and the
   clock's), then re-aim the cast (if it still is 3+ s away and gains 0.2+ points) and the release zones on those
   routes. Bite forecasts then use them too. */
function goal3() {
  const g = run.gp;
  if (!g || !g.cue.dock || run.wall0 === null || run.castTap !== null || run.tapInfo) return;
  const tau3 = (g.cue.dock - run.wall0) / viMs() + 1, base = P(run.plan0);
  const r3 = r3abs() / viMs(), sd = Math.hypot(Math.max(50, clockSd()), g.sdF || 60) / viMs();   // >= 50: its delay is assumed, not learned
  const lik = v => Math.exp(-0.5 * ((tau3 - v.minT - r3) / sd) ** 2);
  const W0 = base.variants.reduce((a, v) => a + v.w, 0) || 1;
  const vars = base.variants.map(v => Object.assign({}, v, { w: v.w * lik(v) }));
  const Wt = vars.reduce((a, v) => a + v.w, 0);
  g.g3 = { tau3, fit: Wt / W0, sdMs: Math.round(sd * viMs()) };
  if (!(Wt / W0 > 1e-3)) { g.g3.off = true; renderFade2(); return; }
  const Q = Object.assign({}, base, { variants: vars.filter(v => v.w > Wt * 1e-6), _final: true });
  const R = routeDef(), A1 = R.axes && R.axes[0], A2 = R.axes && R.axes[1];
  if (A1) {                                                     // which beach timing (wait x 2nd cut) the tap points to
    const mass = ax => {
      const gr = axGroup(R, ax), pl = gr ? LuckyCore.planSet(gr.id, anchor(), route())[0] : null;
      if (!pl || !pl.variants.length) return 0;
      const Wg = pl.variants.reduce((a, v) => a + v.w, 0) || 1;
      return (gr.share || 0) * pl.variants.reduce((a, v) => a + v.w * lik(v), 0) / Wg;
    };
    const combos = [];
    for (const o1 of A1.opts) {
      if (A2 && A2.opts.some(o2 => axGroup(R, { [A1.id]: o1.id, [A2.id]: o2.id })))
        for (const o2 of A2.opts) combos.push({ o1, o2, m: mass({ [A1.id]: o1.id, [A2.id]: o2.id }) });
      else combos.push({ o1, o2: null, m: mass({ [A1.id]: o1.id }) });
    }
    const tot = combos.reduce((a, x) => a + x.m, 0) || 1;
    combos.forEach(x => { x.p = x.m / tot; });
    g.g3.bands = A1.opts.map(o => ({ id: o.id, label: o.label, p: combos.filter(x => x.o1 === o).reduce((a, x) => a + x.p, 0) }));
    if (A2) g.g3.bands2 = A2.opts.map(o => ({ id: o.id, label: o.label, p: combos.filter(x => x.o2 === o).reduce((a, x) => a + x.p, 0) }));
    const top = combos.reduce((a, x) => (x.p > a.p ? x : a), combos[0]);
    if (top && top.p > 0) {                                     // the guess: the likeliest wait, then its likeliest 2nd cut
      const b1 = g.g3.bands.reduce((a, x) => (x.p > a.p ? x : a)), o1 = A1.opts.find(o => o.id === b1.id);
      const row = combos.filter(x => x.o1 === o1 && x.o2), b2 = row.length ? row.reduce((a, x) => (x.p > a.p ? x : a)) : null;
      /* lab check (tests/sim: 1,200 dock taps per route): the wait is right 67-70% (chance 37%); the 2nd cut only 45%
         on dog-beach (chance 43%), 62% on lineup2 (55%) - READY moves with the wait far more than with the 2nd cut. So
         the 2nd cut is shown only when the tap is decisive (>= 70%); on the fade-in start it changes nothing anyway. */
      const p2 = b2 ? b2.p / (b1.p || 1) : null, sure2 = p2 != null && p2 >= 0.7;
      g.g3.guess = { ax: Object.assign({ [A1.id]: b1.id }, sure2 ? { [A2.id]: b2.o2.id } : {}), p1: b1.p, l1: o1.label,
                     p2, l2: b2 ? b2.o2.label : null, sure2 };
    }
  }
  const sig = sigVI(), valOn = (pl, pol, T) => (pol === 'zone' ? (LuckyCore.zoneAt(pl, T, sig) || {}).value : LuckyCore.curve(pl, sig, pol === 'tap' ? 'hold' : pol).P[T]);
  const T0 = run.T, v0 = valOn(Q, run.pol, T0);
  let T = T0, pol = run.pol, p = v0;
  if (L.castT === null) {
    const tMin = Math.max(base.firstT + 29, Math.ceil(tau3) + 180), b = LuckyCore.best(Q, sig, tMin);
    const pols = L.policy !== 'auto' ? [L.policy === 'tap' ? 'hold' : L.policy] : ['zone', 'bite1', 'hold'];
    const bp = pols.reduce((a, q) => (b[q] && b[q].p > b[a].p ? q : a), pols[0]);
    if (b[bp] && b[bp].t >= tMin && b[bp].p > (v0 || 0) + 0.002) { T = b[bp].t; pol = L.policy === 'tap' ? 'tap' : bp; p = b[bp].p; }
  }
  Object.assign(g.g3, { T0, T, moved: T !== T0, p0: v0, p });
  run.plan = Q; run.T = T; run.pol = pol;
  run.zone = LuckyCore.zoneAt(Q, T, sig, sig, true);
  if (pol === 'zone' && run.zone) g.g3.p = run.zone.value;
  $('lkT').textContent = fmtS(T); $('lkP').textContent = pct(g.g3.p);
  cancelBeeps(); scheduleBeeps(); renderFade2(); renderPace();
  if (L.personalCast && $('lkPersonalTxt')) $('lkPersonalTxt').innerHTML = personalTxt();
  if (g.g3.guess) cueFlash(`${g.g3.guess.l1.toUpperCase()} ${Math.round(100 * g.g3.guess.p1)}%${g.g3.guess.sure2 ? ' · ' + g.g3.guess.l2.toUpperCase() : ''} ✓`, 'go', 1600);
}
/* the dock-end tap's guess, shown on the L1 preset cards during the attempt (green); your own pick is dashed */
const guessAx = () => (run.wall0 !== null && !run.preview && run.gp && run.gp.g3 && run.gp.g3.guess && !run.gp.g3.off ? run.gp.g3.guess : null);
/* after the bite tap: the dock-end tap vs the READY the bite posterior points to (plan before the dock-end
   re-weighting, so the tap does not grade itself); kept for a later check of the same-delay assumption */
function reflexFrom(post) {
  const g = run.gp;
  if (!g || !g.cue.dock || !post || !post.sc.length || !(post.Z > 1e-4)) return null;
  const Z = post.sc.reduce((a, e) => a + e.w, 0), dl = post.sc.reduce((a, e) => a + e.w * e.d, 0) / Z;
  const mt = post.sc.reduce((a, e) => a + e.w * e.mt, 0) / Z, sdm = Math.sqrt(post.sc.reduce((a, e) => a + e.w * (e.mt - mt) ** 2, 0) / Z);
  const tau3 = (g.cue.dock - run.wall0) / viMs() + 1;
  return { at: Date.now(), route: route(), ms: Math.round((tau3 + dl - mt) * viMs()), sd: Math.round(sdm * viMs()) };
}
function keepTapRec() {                                         // at the end of an attempt: its clock taps vs their cues
  const g = run.gp;
  if (!g || !g.cue) return;
  const ys = {};
  for (const c of CUES) if (c.vi != null && g.cue[c.id] != null) ys[c.id] = g.cue[c.id] - c.vi * viMs();
  const ks = Object.keys(ys);
  if (ks.length < 2) return;
  const mu = ks.reduce((a, k) => a + ys[k], 0) / ks.length;
  for (const k of ks) ys[k] = Math.round(ys[k] - mu);
  const rec = { at: Date.now(), y: ys }, strays = g.asg ? g.asg.a.filter(k => k < 0).length : 0;
  if (g.cue.dock != null) rec.d = 1;
  if (strays) rec.s = strays;
  const k = curTs();
  tsPut(k, tsGet(k).concat([rec]).slice(-TS_KEEP));
  g.kept = true;
  setTimeout(() => { if (run.wall0 === null) refresh(); else renderFade2(); }, 0);   // the new spread for the next attempt
}
const seqOpen = t => run.gp && run.castTap === null && !run.tapInfo && t < run.T - 90;
function gpTxt() {                                              // this attempt's taps, for the last-attempt line
  const g = run.gp;
  if (!g || !g.cue) return '';
  const sg = v => (v >= 0 ? '+' : '') + Math.round(v);
  let s = 'taps: ' + tapCues().map(c => `${c.short} ${g.cue[c.id] != null ? '✓' : '✗'}`).join(' · ');
  const strays = g.asg ? g.asg.a.filter(k => k < 0).length : 0;
  if (strays) s += ` (${strays} extra ignored)`;
  if (g.asg && g.asg.nClock > 1) s += `; clock from ${g.asg.nClock} taps (±${Math.round(g.sdF)} ms)`;
  if (g.g3 && g.g3.off) s += '; the dock-end tap fit none of the route timings (ignored)';
  else if (g.g3 && g.g3.bands) s += `; dock end: ${g.g3.bands.filter(b => b.p >= 0.05).map(b => b.label + ' ' + Math.round(100 * b.p) + '%').join(', ')}` +
    (g.g3.guess && g.g3.guess.sure2 ? ` (2nd cut ${g.g3.guess.l2.toLowerCase()} ${Math.round(100 * g.g3.guess.p2)}%)` : '') +
    (g.g3.moved ? `, cast moved ${sg((g.g3.T - g.g3.T0) * viMs())} ms` : '');
  return s;
}
function renderFade2() {
  const box = $('lkTapBox');
  if (!box) return;
  if ($('lkAutoTune')) $('lkAutoTune').checked = !!L.autoTune;
  const R = routeDef(), has = (R.anchors || []).some(a => a.id === 'fadein') && (R.anchors || []).some(a => a.id === 'pier' || a.id === 'fadein');
  box.hidden = !has;
  if (!has) return;
  const st = tapStats(), pr = precision(), sd = pr.sd, sg = v => (v >= 0 ? '+' : '') + Math.round(v);
  const nC = clockCues().length, sc = sd / Math.sqrt(Math.max(1, nC));
  const ms = c => (c.vi === 0 ? 'the clock\'s 0' : sg(c.vi * viMs()) + ' ms from the first light'), C_ = id => CUES.find(c => c.id === id);
  const cur = strat().id;
  const st0 = STRATS.find(x => x.id === cur);
  let h = `<label class="lkset"><span>Tap strategy</span> <select id="lkStrat">${STRATS.map(x => `<option value="${x.id}" ${cur === x.id ? 'selected' : ''}>${x.label}</option>`).join('')}</select></label>` +
    `<div class="small mut" style="margin:-2px 0 3px">${st0.note}. Tap ${keyName()} at each cue; the plan above is computed for this strategy.</div>` +
    (cur === 'd' ? '' : `<label class="lkset"><span>Beach cue</span> <select id="lkBeach">${['ctrl', 'fade'].map(id => `<option value="${id}" ${L.beachCue === id ? 'selected' : ''}>${id === 'ctrl' ? 'first control: Jack turns down-right (+1.09 s)' : 'first light of the fade-in (0 s)'}</option>`).join('')}</select></label>` +
      `<div class="small mut" style="margin:-2px 0 3px">${L.beachCue === 'ctrl' ? 'Hold down-right through the fade; tap when Jack turns and walks.' : 'Tap when the black screen starts to brighten.'}${tapCues().some(c => c.id === 'exit') ? ' Ranch exit: tap when Jack stops dead at the exit (−1.16 s).' : ''}${tapCues().some(c => c.id === 'dock') ? ' Dock end: tap when Jack stops at the water.' : ''}</div>`) +
    `<label class="lkset small"><span>Clock-tap precision (one tap's spread): <b>${Math.round(sd)} ms</b>${precTxt(pr)}</span> ` +
      `<span><input type="range" id="lkTapSd" min="15" max="150" step="5" value="${Math.round(L.tapSdAuto ? sd : L.tapSdMs)}" ${L.tapSdAuto ? 'disabled' : ''}> <label><input type="checkbox" id="lkTapSdAuto" ${L.tapSdAuto ? 'checked' : ''}> auto</label></span></label>`;
  const dockOn = tapCues().some(c => c.id === 'dock');
  h += cur === 'd' ? '<div class="small mut">Dock-end start: one tap at READY; the plan uses your timing spread as set. '
    : `<div class="small mut">This strategy: ${nC} clock tap${nC === 1 ? '' : 's'} → clock ±${Math.round(sc)} ms → timing spread used <b>${sigEffMs('fadein')} ms</b> (your ${sigmaMs()} ms timing spread assumes one start tap of ±${START1_MS}). ` +
      (dockOn ? `The dock-end tap re-aims live, read with ±${Math.round(Math.hypot(Math.max(50, sd), sc))} ms (lab simulation on this route: about +1.6 points per attempt). ` : 'No dock-end tap: no live re-aim. ');
  const offs = CUES.filter(c => c.vi != null && c.id !== L.beachCue && st.off[c.id] && st.off[c.id].n).map(c => `${c.short} ${sg(st.off[c.id].raw)} ms (${st.off[c.id].n})`);
  h += `<br><b>Your tap profile</b> (saved in this browser, refined every attempt): ${st.nrec} attempt${st.nrec === 1 ? '' : 's'} with 2+ clock taps` +
    (offs.length ? `; vs your ${C_(L.beachCue).short} tap: ${offs.join(', ')}` : '') + '. ';
  const ds = dockStat();
  if (ds.n >= 5) h += `Dock-end tap vs the READY your bites point to: ${sg(ds.med - r2abs())} ms vs your clock taps (median of ${ds.n}, rough). `;
  h += '</div>' + (cur === 'd' ? '' : tapDataHtml(st, pr));
  box.innerHTML = h;
  wireTapData();
  $('lkStrat').onchange = e => setStrategy(e.target.value);
  if ($('lkBeach')) $('lkBeach').onchange = e => setBeachCue(e.target.value);
  $('lkTapSdAuto').onchange = e => { L.tapSdAuto = e.target.checked; if (!L.tapSdAuto) L.tapSdMs = Math.round(sd / 5) * 5; save(); refreshSig(); };
  $('lkTapSd').onchange = e => { L.tapSdMs = +e.target.value; save(); refreshSig(); };
}
function precTxt(pr) {
  if (pr.src === 'manual') return ' (set by hand)';
  if (pr.src === 'own') return ` (auto, from your last ${pr.n} attempts of this strategy)`;
  if (pr.src === 'borrowed') return ` (auto, borrowed from ${pr.n} attempts of the ranch exit + beach cue strategies on this route: one clock tap cannot show its own spread)`;
  return pr.own ? ` (auto: 60 until 5 attempts of this strategy with both clock taps; ${pr.n} so far)`
    : ' (auto: 60; one clock tap cannot show its spread: 5 attempts with the ranch exit + beach cue strategies on this route measure it)';
}
/* the tap data behind the auto precision: this set's attempts, newest first; cull / restore one, clear the set */
const esc = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
const TSTRAT_SHORT = { b: '1 tap: beach cue', eb: '2 taps: ranch exit + beach cue', bd: '2 taps: beach cue + dock end', ebd: '3 taps: ranch exit + beach cue + dock end', d: 'dock end only' };
function tapDataHtml(st, pr) {
  const k = curTs(), all = tsGet(k), ref = L.beachCue, C_ = id => CUES.find(c => c.id === id), sg = v => (v > 0 ? '+' : v < 0 ? '−' : '±') + Math.abs(Math.round(v));
  const own = clockCues().length >= 2, kept = all.filter(r => !r.x), used = new Set(kept.slice(-TS_USE));
  const gapMs0 = (C_(ref).vi - C_('exit').vi) * viMs(), usual = st.off.exit && isFinite(st.off.exit.raw) ? st.off.exit.raw : 0;
  const devs = [...used].filter(r => r.y.exit != null && r.y[ref] != null).map(r => Math.abs(r.y.exit - r.y[ref] - usual));
  const lim = Math.max(100, 3 * 1.4826 * (devs.length >= 3 ? med(devs) : 40));   // 3 robust SDs of the gap (median |deviation|)
  const when = at => { const d = new Date(at), t = d.toTimeString().slice(0, 5); return d.toDateString() === new Date().toDateString() ? t : d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) + ' ' + t; };
  const btns = () => `<div style="margin-top:4px">${all.length ? `<button type="button" id="lkTapSetClear">Clear this set (${all.length})</button> ` : ''}` +
    `${tsKeys().length || dock.length || fade2.length ? '<button type="button" id="lkFade2Forget">Forget all tap data</button>' : ''}</div>`;
  const sum = own ? `${kept.length} attempt${kept.length === 1 ? '' : 's'}${all.length > kept.length ? `, ${all.length - kept.length} culled` : ''}` +
    (isFinite(st.sdAuto) ? ` → ±${Math.round(st.sdAuto)} ms` : '') : 'one clock tap: nothing to measure here';
  let h = `<details class="lkfold" id="lkTapData"${L.tapDataOpen ? ' open' : ''}><summary>Tap data for this strategy (${sum})</summary>` +
    `<div class="small mut">Set: <b>${TSTRAT_SHORT[strat().id]}</b> · beach cue <b>${C_(ref).short}</b> · route <b>${esc(routeDef().label || route())}</b>. ` +
    'Saved in this browser per route, tap strategy and beach cue. ';
  if (!own) {
    h += `This strategy has one clock tap per attempt, so its spread cannot be measured on its own; auto precision ` +
      (pr.src === 'borrowed' ? `borrows ±${Math.round(pr.sd)} ms from your ${pr.n} attempts of the ranch exit + beach cue strategies (same route and beach cue).` : 'uses 60 ms until you have 5 attempts with the ranch exit + beach cue strategies on this route.') + '</div>' + btns() + '</details>';
    return h;
  }
  h += `Each row = one attempt with both clock taps: the gap from your ranch exit tap to your ${C_(ref).short} tap ` +
    `(the game's: ${(gapMs0 / 1000).toFixed(3)} s). Your usual difference (${sg(-usual)} ms, median) is calibrated away; one tap's ` +
    `spread = the rms of "vs usual" ÷ √2 over your last ${TS_USE} kept attempts${isFinite(st.sdAuto) ? '' : ' (auto from 5)'}. ` +
    'A tap far off both cues is already dropped as an extra tap (that attempt is not stored); cull a fumble that got ' +
    `through (it stays listed: restore it any time). ⚠ = more than ${Math.round(lim)} ms off your usual.</div>`;
  if (!all.length) return h + '<div class="small mut">No attempts yet: tap the ranch exit and the beach cue in an attempt.</div>' + btns() + '</details>';
  h += '<div style="max-height:220px;overflow:auto;margin-top:4px"><table class="plan small" id="lkTapDataTbl"><tr><th>#</th><th>when</th><th>gap</th><th>vs game</th><th>vs usual</th><th></th><th></th></tr>';
  all.map((r, i) => [r, i]).reverse().forEach(([r, i]) => {
    const e = r.y.exit != null && r.y[ref] != null ? r.y.exit - r.y[ref] : null;
    const dev = e == null ? null : e - usual, far = dev != null && Math.abs(dev) > lim;
    const note = r.x ? 'culled' : !used.has(r) ? 'older: not used' : far ? '⚠ far off' : r.m ? 'carried over' : r.s ? `${r.s} extra tap${r.s > 1 ? 's' : ''} ignored` : '';
    h += `<tr style="${r.x || !used.has(r) ? 'opacity:.5' : ''}"><td>${i + 1}</td><td>${when(r.at)}</td>` +
      (e == null ? '<td colspan="3">—</td>' : `<td>${((gapMs0 - e) / 1000).toFixed(3)} s</td><td>${sg(-e)} ms</td><td>${sg(-dev)} ms</td>`) +
      `<td>${note}</td><td><button type="button" data-tsat="${r.at}" data-tsi="${i}">${r.x ? 'restore' : 'cull'}</button></td></tr>`;
  });
  h += '</table></div>';
  return h + btns() + '</details>';
}
function tapDataChanged() { if (run.wall0 !== null) renderFade2(); else refresh(); }   // plan caches are keyed by the spread
function cullRec(i, on) {                                      // on: true = cull, false = restore, undefined = toggle
  const k = curTs(), a = tsGet(k).slice(), r = a[i];
  if (!r) return;
  a[i] = Object.assign({}, r);
  if (on === undefined ? !r.x : on) a[i].x = 1; else delete a[i].x;
  tsPut(k, a); tapDataChanged();
}
function clearSet() { tsPut(curTs(), []); tapDataChanged(); }
function wireTapData() {
  const d = $('lkTapData');
  if (!d) return;
  d.addEventListener('toggle', () => { if (L.tapDataOpen !== d.open) { L.tapDataOpen = d.open; save(); } });
  d.querySelectorAll('button[data-tsi]').forEach(b => { b.onclick = () => cullRec(+b.dataset.tsi); });
  if ($('lkTapSetClear')) $('lkTapSetClear').onclick = () => {
    if (confirm(`Clear the tap data of this set (${TSTRAT_SHORT[strat().id]}, beach cue ${CUES.find(c => c.id === L.beachCue).short}, ${routeDef().label || route()})? Other sets are kept.`)) clearSet();
  };
  if ($('lkFade2Forget')) $('lkFade2Forget').onclick = () => {
    if (confirm('Forget ALL tap data (every route, strategy and beach cue; exit/fade-in pairs; dock-end records)?')) {
      for (const k of tsKeys()) tsPut(k, []);
      fade2 = []; dock = [];
      store.set('hm64v29_lucky_fade2', fade2); store.set('hm64v29_lucky_dock', dock); tapDataChanged();
    }
  };
}
/* the strategy picks the start: dock end only = the dock-end start, any other = the fade-in start */
function setStrategy(id) {
  if (id === 'd') { setSelection(null, 'pier'); return; }
  L.tapStrategy = id; save();
  if (anchor() !== 'fadein') { setSelection(null, 'fadein'); return; }
  refreshSig();
}
function setBeachCue(id) {
  L.beachCue = id; save(); updateProfile();
  if (anchor() !== 'fadein') { setSelection(null, 'fadein'); return; }
  refreshSig();
}
function refreshSig() { bestCache = null; ccache.clear(); paceCache.clear(); startCache.clear(); L.castT = null; refresh(); }
function scheduleBeeps() {
  const castWall = run.wall0 + (run.T - 1) * viMs() + cueCorr();
  [-1500, -1000, -500].forEach(d => beepAt(castWall + d, 440, 0.06));
  beepAt(castWall, 880, 0.14);
  if (run.plan.k) beepAt(run.wall0 + 30, 660, 0.05, 0.12);
  if (L.zoneBeeps && run.pol === 'bite1') for (const [a] of nutBites()) {     // get-ready ticks before each Nut-bite cluster
    const wa = run.wall0 + (a - 1) * viMs();
    if (wa > castWall + 500) { beepAt(wa - 600, 1000, 0.035, 0.1); beepAt(wa - 300, 1000, 0.035, 0.1); }
  }
  if (L.zoneBeeps && run.pol === 'zone' && run.zone) {
    for (const [a, b] of run.zone.zones) {
      const wa = run.wall0 + (a - 1) * viMs(), wb = run.wall0 + (b - 1) * viMs();
      if (wa < castWall) continue;
      beepAt(wa, 1200, 0.05, 0.15); beepAt(wa + 70, 1500, 0.05, 0.15); beepAt(wb, 700, 0.06, 0.1);
    }
  }
}
function stop(clearResult) {
  const hadGuess = !!guessAx();
  if (run.gp && !run.gp.kept) keepTapRec(); saveTap(null); run.wall0 = null; cancelBeeps(); if (clearResult) run.result = null;
  if (hadGuess) renderPace();                                   // the cards go back to your own pick
}
run.castTap = null; run.castErrMs = null; run.last = null;
function preview() {
  stop(true); run.tapInfo = null;
  refresh();
  const z = run.zone;
  if (!z) return;
  // a lucky attempt: draw a winning scenario under the current plan and policy
  const wins = z.sc.filter(x => (run.pol === 'hold' ? x.n2 : run.pol === 'bite1' ? x.n1 : (inZone(x.t1) ? x.n1 : x.n2)));
  if (!wins.length) { run.preview = null; return; }
  let r = Math.random() * wins.reduce((a, x) => a + x.w, 0), pick = wins[0];
  for (const x of wins) { r -= x.w; if (r <= 0) { pick = x; break; } }
  const release = run.pol === 'bite1' || (run.pol === 'zone' && inZone(pick.t1));
  run.preview = { cast: pick.cast, bite1: pick.t1, bite2: pick.t2, release1: release };
  run.wall0 = now() - Math.max(0, (Math.min(run.T, pick.cast) - 90) * viMs());
}
const inZone = t => run.zone && run.zone.zones.some(([a, b]) => t >= a && t < b);
const held = () => !!(run.tapInfo && run.tapInfo.holdish);
/* where to release now: bite-1 windows, or once bite 1 was held, the bite-2 Nut moments (+ the 20-VI window) */
const inRelease = t => (held() ? !run.tapInfo.dud && run.tapInfo.spans2.some(([a, b]) => t >= a && t < b + WINDOW_VI) : inZone(t));
/* stopwatch spans where a bite-1 Nut can come after this cast (bins with >= 25% of the peak bite-1 Nut density) */
/* ---------------------------------------------------------------- visual cues (v29.10, they replace the beeps)
   One lamp at the top of L3 (+ a glow around the screen edge, for the corner of your eye while you watch the TV), at the
   moments the beeps had. Countdown: GET READY and a bar filling to the target line from 2 s out, amber pulses 3 / 2 / 1 at
   1.5 / 1.0 / 0.5 s (the old lead beeps: press on the rhythm, not as a reaction), green CAST at the cue. After the
   cast: green = release on a bite now (release window, Nut-bite moment, bite-2 Nut moment; bar = time left), amber =
   one opens within 1.5 s (bar fills to it, two blinks 0.6 / 0.3 s before, like the old ticks), yellow = hold, red =
   DUD. Short flashes confirm taps. Sound is optional (Settings). */
const PULSE_MS = 110, CAST_HOLD_MS = 350, COUNT_MS = 2000, LEAD_MS = 1500, WIN_TAIL = 10;
const CUECOL = { pulse: '#ffd28a', cast: '#5fd38d', nut: '#5fd38d', go: '#5fd38d', ready: '#f0b35a', hold: '#e7c14a', bad: '#ef6f6f', wh: '#b48cff', info: '#6fb7ff', count: '#f0b35a', idle: '#8ea3b2' };
function cueFlash(text, kind, ms) { run.flash = { text, kind: kind || 'info', until: now() + (ms || 800) }; }
function countdown(dt, bar, sub, num) {                         // dt: ms to the CAST cue
  if (dt <= 0) return { kind: 'cast', big: 'CAST', sub, bar: bar ? 1 : null, glow: 1 };
  if (dt > COUNT_MS) return { kind: 'info', big: num ? `CAST IN ${(dt / 1000).toFixed(dt < 10000 ? 1 : 0)} s` : 'GET READY', sub };
  const pulse = [1500, 1000, 500].some(d => dt <= d && dt > d - PULSE_MS);
  return { kind: pulse ? 'pulse' : 'count', big: dt > 1500 ? 'GET READY' : dt > 1000 ? '3' : dt > 500 ? '2' : '1', sub,
           bar: bar ? Math.max(0, 1 - dt / COUNT_MS) : null, glow: pulse ? 0.9 : 0 };
}
function windowsCue(t, spans, tail, inC, out) {                 // release moments: inside = green, within 1.5 s = amber lead
  const vi = viMs(), cur = spans.find(([a, b]) => t >= a && t < b + tail);
  if (cur) {
    const left = Math.max(0, (cur[1] + tail - t) * vi), len = (cur[1] + tail - cur[0]) * vi;
    return { kind: inC.kind, big: inC.big, sub: `${inC.sub} · ${(left / 1000).toFixed(1)} s left`, bar: left / len, glow: (t - cur[0]) * vi < 200 ? 1 : inC.glow };
  }
  const nx = spans.find(([a]) => a > t);
  if (nx && (nx[0] - t) * vi <= LEAD_MS) {
    const dt = (nx[0] - t) * vi, blink = [600, 300].some(d => dt <= d && dt > d - PULSE_MS);
    return { kind: blink ? 'pulse' : 'ready', big: `${inC.short} IN ${(dt / 1000).toFixed(1)} s`, sub: out.sub, bar: 1 - dt / LEAD_MS, glow: blink ? 0.8 : 0 };
  }
  return Object.assign({}, out, nx ? { sub: `${out.sub} · next ${inC.short.toLowerCase()} in ${((nx[0] - t) * vi / 1000).toFixed(1)} s` } : {});
}
function cueAt(t, idleMsg) {
  const live = run.wall0 !== null, vi = viMs(), fl = run.flash && run.flash.until > now() ? run.flash : null;
  const pr = run.practice;
  if (pr) {
    if (pr.state === 'armed') return countdown(pr.cue - now(), L.pracLine, `press ${keyName()} on CAST`, L.pracLine);
    const r = pr.last;
    if (r && pr.state === 'done') return r.e === null ? { kind: 'bad', big: 'MISSED', sub: 'no press within 0.6 s of CAST' }
      : { kind: Math.abs(r.e) <= 1000 / 60 ? 'go' : Math.abs(r.e) <= 50 ? 'ready' : 'hold', big: msTxt(r.e), sub: practiceMsg(t)[0] };
    return { kind: 'idle', big: 'PRACTICE', sub: practiceMsg(t)[0] };
  }
  if (!live) {
    if (fl) return { kind: fl.kind, big: fl.text, sub: idleMsg };
    if (run.result === 'nut') return { kind: 'nut', big: 'POWER NUT!', sub: 'logged' };
    return { kind: 'idle', big: run.result === 'miss' ? 'LOGGED' : 'READY', sub: idleMsg };
  }
  if (run.preview) return { kind: 'info', big: 'PREVIEW', sub: idleMsg };
  const dt = (run.T + cueCorr() / vi - t) * vi;                 // ms to the CAST cue (cast-cue correction included)
  if (dt > -CAST_HOLD_MS && dt <= COUNT_MS) return countdown(dt, true, (dt > 0 ? 'press B on CAST' : 'B now') + (L.castTap ? ` · tap ${keyName()} with it` : ''), true);
  if (fl) return { kind: fl.kind, big: fl.text, sub: '' };
  if (dt > 0) {
    if (run.plan.k && t < run.plan.whistleEnd + 6) return { kind: 'wh', big: 'MASH C-RIGHT', sub: `stop at whistle #${run.plan.k}` };
    const tr = t - R0();
    if ((run.T - R0()) * vi > 37500 && tr * vi > 33000 && tr * vi < 38500) return { kind: 'wh', big: 'PUSH SOUTH-EAST', sub: 'stay awake: the farmer naps at 40 s', glow: 0.5 };
    const sq = seqMsg(t);
    return countdown(dt, false, sq ? sq[0] : `cast ${fmtS(run.T)} after ${startName()}`, true);
  }
  const ti = run.tapInfo;
  if (ti && ti.holdish) {
    if (ti.tau2 != null) return { kind: ti.p2b >= 0.8 ? 'go' : 'info', big: 'BITE 2 LOGGED', sub: `${verdict(ti.p2b)} · H Nut · M fish · E empty` };
    if (!ti.fit) return { kind: 'hold', big: 'RELEASE AT BITE 2', sub: 'bite 1 fits no dog path' };
    if (ti.dud) return { kind: 'bad', big: 'DUD — RESET', sub: `bite 2 cannot be the Nut (${pct(ti.pNut)}) · M`, glow: Math.floor(now() / 300) % 2 ? 0.6 : 0.2 };
    return windowsCue(t, ti.spans2, WINDOW_VI, { kind: 'nut', big: 'BITE 2 = NUT: RELEASE', sub: `Nut ${pct(ti.pNut)}`, short: 'NUT MOMENT', glow: 0.6 },
                      { kind: 'hold', big: 'HOLD → BITE 2', sub: `Nut ${pct(ti.pNut)} on bite 2 · tap ${keyName()} at it` });
  }
  if (ti) return { kind: 'info', big: 'BITE LOGGED', sub: `${verdict(ti.p1)} · H Nut · M fish · E empty` };
  if (run.pol === 'zone') return windowsCue(t, run.zone ? run.zone.zones : [], 0, { kind: 'go', big: 'RELEASE ON A BITE', sub: 'release window', short: 'WINDOW', glow: 0.45 },
                                            { kind: 'hold', big: 'HOLD · TAP THE BITE', sub: `a bite now: keep holding B, tap ${keyName()}` });
  if (run.pol === 'bite1') return windowsCue(t, nutBites(), WIN_TAIL, { kind: 'nut', big: 'NUT BITE: RELEASE', sub: 'a Nut bite can come now', short: 'NUT MOMENT', glow: 0.6 },
                                             { kind: 'go', big: 'RELEASE AT THE BITE', sub: `tap ${keyName()} at it` });
  return { kind: 'hold', big: 'HOLD BITE 1', sub: `tap ${keyName()} at the bite · release bite 2` };
}
let cueLast = '';
function renderCue(t, idleMsg) {
  const el = $('lkCue');
  if (!el) return;
  const c = cueAt(t, idleMsg) || { kind: 'idle', big: '—', sub: '' }, key = c.kind + '|' + c.big + '|' + (c.sub || '');
  if (key !== cueLast) { el.className = 'lkcue k-' + c.kind; $('lkCueBig').textContent = c.big; $('lkCueSub').textContent = c.sub || ''; cueLast = key; }
  const bb = $('lkCueBarBox'), on = c.bar != null;
  if (bb.hidden === on) bb.hidden = !on;
  if (on) $('lkCueBar').style.width = (100 * Math.max(0, Math.min(1, c.bar))).toFixed(1) + '%';
  glowSet(L.cueGlow ? c.glow || 0 : 0, CUECOL[c.kind] || '#ffffff');
  run.cueNow = c;
}
let glowLast = '';
function glowSet(g, col) {
  const gl = $('cueGlow');
  if (!gl) return;
  const v = g > 0 ? `inset 0 0 0 ${Math.round(16 * g)}px ${col}, inset 0 0 ${Math.round(150 * g)}px ${col}` : 'none';
  if (v !== glowLast) { gl.style.boxShadow = v; glowLast = v; }
}
function nutBites() {
  const z = run.zone; if (!z) return [];
  let m = 0; for (const v of z.d1n) m = Math.max(m, v);
  const out = [];
  for (let i = 0; i < z.d1n.length; i++) {
    if (!(z.d1n[i] >= 0.25 * m && m > 0)) continue;
    const a = i * z.binVI, b = (i + 1) * z.binVI;
    if (out.length && a - out[out.length - 1][1] <= 30) out[out.length - 1][1] = b; else out.push([a, b]);   // < 0.5 s apart: one
  }
  return out;
}

/* ---------------------------------------------------------------- angler (original stick figure; own frames optional) */
const DIRV = { E: [1, 0], SE: [0.82, 0.57] };
function drawAngler(g, W, H, pose, u, dir, info) {
  const s = W / 180, [dx, dy] = DIRV[dir] || DIRV.SE;
  g.clearRect(0, 0, W, H);
  // water and dock
  g.fillStyle = '#0e3550'; g.fillRect(0, 0, W, H);
  g.strokeStyle = '#2b6f9a'; g.lineWidth = 1.5 * s;
  for (let i = 0; i < 7; i++) { const y = (20 + i * 24) * s, ph = (now() / 600 + i) % 1; g.beginPath(); for (let x = 0; x <= W; x += 6 * s) g.lineTo(x, y + Math.sin(x / (14 * s) + ph * 6.28) * 2 * s); g.stroke(); }
  g.fillStyle = '#7a5532';
  if (dir === 'E') g.fillRect(0, 110 * s, 70 * s, 70 * s); else { g.beginPath(); g.moveTo(0, 60 * s); g.lineTo(70 * s, 95 * s); g.lineTo(55 * s, 180 * s); g.lineTo(0, 180 * s); g.closePath(); g.fill(); }
  g.strokeStyle = '#5c3e22'; g.lineWidth = 1 * s;
  for (let i = 0; i < 6; i++) { g.beginPath(); g.moveTo(0, (115 + i * 12) * s); g.lineTo(65 * s, (115 + i * 12) * s); g.stroke(); }
  const img = customSprites[pose + '_' + dir];
  const fx = 42 * s, fy = 118 * s;                              // feet
  const bob = [fx + dx * 95 * s, fy + dy * 50 * s - 6 * s];      // bobber rest point
  if (img) {
    const im = drawAngler.cache[img] || (drawAngler.cache[img] = Object.assign(new Image(), { src: img }));
    if (im.complete) { g.imageSmoothingEnabled = false; g.drawImage(im, fx - 40 * s, fy - 80 * s, 80 * s, 80 * s); }
  } else {
    g.strokeStyle = '#f2e6d0'; g.fillStyle = '#f2e6d0'; g.lineWidth = 3 * s; g.lineCap = 'round';
    const hip = [fx, fy - 30 * s], neck = [fx + dx * 2 * s, fy - 58 * s], head = [neck[0] + dx * 2 * s, neck[1] - 10 * s];
    const L2 = (a, b) => { g.beginPath(); g.moveTo(a[0], a[1]); g.lineTo(b[0], b[1]); g.stroke(); };
    L2([fx - 7 * s, fy], hip); L2([fx + 7 * s, fy], hip); L2(hip, neck);
    g.beginPath(); g.arc(head[0], head[1], 8 * s, 0, 6.283); g.fill();
    g.fillStyle = '#3d8fd0'; g.beginPath(); g.arc(head[0], head[1] - 4 * s, 8.5 * s, Math.PI, 0); g.fill();   // generic bucket hat
    const sh = [neck[0], neck[1] + 6 * s];
    // rod angle (radians above the facing direction); hands at the shoulder front
    let ang = 0.9, hand = [sh[0] + dx * 12 * s, sh[1] + 10 * s], line = null, note = false, nut = false, bang = false;
    if (pose === 'whistle') { hand = [head[0] + dx * 7 * s, head[1] + 3 * s]; note = true; ang = 1.35; }
    else if (pose === 'cast') { ang = 2.2 - 1.9 * u; if (u > 0.55) line = 'fly'; }
    else if (pose === 'wait') { ang = 0.35; line = 'water'; }
    else if (pose === 'zone') { ang = 0.45; line = 'water'; }
    else if (pose === 'bite') { ang = 0.25 + 0.5 * u; line = 'bite'; bang = true; }
    else if (pose === 'reel') { ang = 0.8 + 0.6 * u; line = u < 0.7 ? 'tight' : null; }
    else if (pose === 'catch') { ang = 1.25; nut = true; }
    else if (pose === 'eat') { ang = 1.25; nut = u < 1; }
    L2(sh, hand);
    const toMouth = pose === 'eat' ? Math.min(1, u * 2) : 0;
    const hand2 = nut ? [sh[0] + dx * (18 - 10 * toMouth) * s, sh[1] - (4 + 10 * toMouth) * s] : [hand[0] - dx * 3 * s, hand[1] + 6 * s];
    L2(sh, hand2);
    const rl = 62 * s, tip = [hand[0] + dx * Math.cos(ang) * rl, hand[1] + dy * Math.cos(ang) * rl * 0.6 - Math.sin(ang) * rl];
    g.strokeStyle = '#c9a36b'; g.lineWidth = 2 * s; L2(hand, tip);
    g.strokeStyle = '#dce6ec99'; g.lineWidth = 1 * s;
    if (line) {
      let b = bob.slice();
      if (line === 'fly') b = [tip[0] + (bob[0] - tip[0]) * (u - 0.55) / 0.45, tip[1] + (bob[1] - tip[1]) * (u - 0.55) / 0.45 - 20 * s * Math.sin(Math.PI * (u - 0.55) / 0.45)];
      if (line === 'water' || line === 'zone') b[1] += Math.sin(now() / 260) * 1.5 * s;
      if (line === 'bite') b[1] += 5 * s;
      g.beginPath(); g.moveTo(tip[0], tip[1]);
      if (line === 'tight') g.lineTo(b[0], b[1]); else g.quadraticCurveTo((tip[0] + b[0]) / 2, Math.max(tip[1], b[1]) + 10 * s, b[0], b[1]);
      g.stroke();
      if (line !== 'bite') { g.fillStyle = '#ef6f6f'; g.beginPath(); g.arc(b[0], b[1], 3.5 * s, 0, 6.283); g.fill(); }
      if (line === 'bite' || line === 'tight') { g.strokeStyle = '#ffffffaa'; g.beginPath(); g.arc(b[0], b[1] + 2 * s, 7 * s, 0, 6.283); g.stroke(); }
    }
    if (pose === 'zone') { g.fillStyle = '#5fd38d'; g.font = `bold ${12 * s}px system-ui`; g.fillText('release on a bite', 60 * s, 18 * s); }
    if (bang) { g.fillStyle = '#ffd28a'; g.font = `bold ${22 * s}px system-ui`; g.fillText('!', head[0] - 3 * s, head[1] - 16 * s); }
    if (note) { g.fillStyle = '#b48cff'; g.font = `${16 * s}px system-ui`; const ph = (now() / 400) % 1; g.fillText('♪', head[0] + dx * 14 * s + 6 * s, head[1] - 8 * s - ph * 14 * s); g.fillText('♫', head[0] + dx * 22 * s + 10 * s, head[1] - 2 * s - ((ph + 0.5) % 1) * 14 * s); }
    if (nut) drawNut(g, hand2[0] + dx * 6 * s, hand2[1] - 6 * s, (pose === 'eat' ? 9 * (1 - 0.6 * u) : 9) * s, pose !== 'eat');
    if (pose === 'eat' && u >= 1) { g.fillStyle = '#ffd28a'; g.font = `bold ${13 * s}px system-ui`; g.fillText('+ stamina', head[0] + 10 * s, head[1] - 14 * s); }
  }
  if (info) { g.fillStyle = '#dce6ec'; g.font = `${11 * s}px ui-monospace,monospace`; g.fillText(info, 6 * s, H - 6 * s); }
}
drawAngler.cache = {};
function drawNut(g, x, y, r, sparkle) {
  const gr = g.createRadialGradient(x - r * 0.3, y - r * 0.3, r * 0.2, x, y, r);
  gr.addColorStop(0, '#ffe39a'); gr.addColorStop(1, '#b0701c');
  g.fillStyle = gr; g.beginPath(); g.ellipse(x, y, r * 0.85, r, 0, 0, 6.283); g.fill();
  g.strokeStyle = '#7a4a10'; g.lineWidth = Math.max(1, r / 6); g.beginPath(); g.moveTo(x, y - r); g.lineTo(x, y + r); g.stroke();
  if (sparkle) { const ph = (now() / 300) % 1; g.fillStyle = `rgba(255,255,255,${0.4 + 0.6 * Math.abs(Math.sin(ph * 3.14))})`; star(g, x + r, y - r, r * 0.6); }
}
function star(g, x, y, r) { g.beginPath(); for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4, rr = i % 2 ? r * 0.35 : r; g.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr); } g.closePath(); g.fill(); }

/* Fishing timeline from the game (player.c handleFishingRodAnimation; measured in the lab, same for SE and E):
   B press -> cast animation -> bobber spawns with the PLOP sound 36 VI later (phase 2, waiting).
   Bite -> rod-pull animation for 20 VI (the release window). Held through -> re-cast, plop again 24 VI after the bite.
   Released -> lose-fish/reel animation from bite+20 to bite+54 -> catch at bite+54: the Power Nut is held up for 60 VI,
   then eaten (startAction(EATING); item gone at bite+138, done at bite+250). A fish is simply held at bite+54. */
const G_CAST = 36, G_PULL = 20, G_RECAST = 24, G_CATCH = 54, G_SHOW = 60, G_EATEN = 138, G_DONE = 250;
/* ---------------------------------------------------------------- Jack (Thomas's catalog frames, D.jack) */
const JACK = (Core.data && Core.data.jack && Core.data.jack.facings) ? Core.data.jack : null;
const jackImgs = new Map();
function jimg(src) { let im = jackImgs.get(src); if (!im) { im = new Image(); im.src = src; jackImgs.set(src, im); } return im; }
function frameOf(a, e) {                                         // frame index after e ticks (1 tick = 1 VI at the dock)
  const tot = a.ticks.reduce((x, y) => x + y, 0) || 1;
  let k = Math.max(0, Math.floor(e || 0));
  if (a.loop) k %= tot; else if (k >= tot) return a.frames.length - 1;
  for (let i = 0; i < a.ticks.length; i++) { if (k < a.ticks[i]) return i; k -= a.ticks[i]; }
  return a.frames.length - 1;
}
/* what the console shows at stopwatch VI t, on the game's fishing timeline (see G_* above) */
function jackState(t) {
  const T = run.T, plan = run.plan;
  if (run.result === 'nut' && now() - run.resultAt < 4800) {
    const e = (now() - run.resultAt) / viMs();
    return e < 62 ? { anim: 'hold', nut: true, info: 'Power Nut!' } : e < 196 ? { anim: 'eat', e: e - 62, info: 'eats the Power Nut' } : { anim: 'idle', info: '+15 max stamina' };
  }
  if (run.wall0 === null) return { anim: 'idle', info: run.result === 'miss' ? 'reset and go again' : 'waiting for the start' };
  if (plan.k && t < plan.whistleEnd + 6) return { anim: 'idle', notes: true, info: 'mash C-right' };
  if (t < T + 4) return { anim: 'idle', info: t < T ? `cast in ${((T - t) * viMs() / 1000).toFixed(1)} s` : 'cast!' };
  if (t < T + G_CAST) return { anim: 'cast', e: t - T - 4, info: 'cast!' };
  const pv = run.preview;
  if (pv) {
    const b1 = pv.bite1, rel = pv.release1 ? pv.bite1 : pv.bite2;
    if (!pv.release1) {
      if (t >= b1 && t < b1 + G_PULL) return { anim: 'bite', e: t - b1, float: 'floatBite', ft: t - b1, info: 'bite 1: HOLD B' };
      if (t >= b1 + G_PULL && t < b1 + G_RECAST) return { anim: 'wait', info: 're-cast' };
      if (t >= b1 + G_RECAST && t < rel) return { anim: 'wait', float: 'float', ft: t - b1 - G_RECAST, info: 'waiting for bite 2' };
    }
    if (t >= rel && t < rel + G_PULL) return { anim: 'bite', e: t - rel, float: 'floatBite', ft: t - rel, info: 'bite: RELEASE B' };
    if (t >= rel + G_PULL && t < rel + G_CATCH + 2) return { anim: 'land', e: t - rel - G_PULL, info: 'reeling in…' };
    if (t >= rel + G_CATCH + 2 && t < rel + 118) return { anim: 'hold', nut: true, info: 'Power Nut!' };
    if (t >= rel + 118 && t < rel + 252) return { anim: 'eat', e: t - rel - 118, info: 'eats the Power Nut' };
    if (t >= rel + 252) { if (t > rel + 372) { run.wall0 = null; run.preview = null; } return { anim: 'idle', info: '+15 max stamina' }; }
    return { anim: 'wait', float: 'float', ft: t - T - G_CAST, info: 'waiting…' };
  }
  const zone = (run.pol === 'zone' || held()) && inRelease(t);
  return { anim: 'wait', float: 'float', ft: t - T - G_CAST, zone,
           info: held() ? (run.tapInfo.dud ? 'dud → reset' : zone ? 'bite 2 now → RELEASE' : 'held · waiting for bite 2')
             : zone ? 'bite now → RELEASE' : run.pol === 'bite1' ? 'release at the bite' : run.pol === 'hold' ? 'hold bite 1, release bite 2'
             : run.pol === 'tap' ? (!run.tapInfo ? 'hold B · tap the first bite' : run.tapInfo.dud ? 'dud → reset' : 'hold → release bite 2') : 'bite now → HOLD' };
}
const BEACH = (Core.data && Core.data.beach && Core.data.beach.img) ? Core.data.beach : null;
function drawJackScene(g, W, H, st, dir) {
  const J = JACK, F = J.facings[dir] || J.facings.SE, sc = J.scene[dir] || J.scene.SE;
  let s, ax, ay;
  g.imageSmoothingEnabled = false;
  if (BEACH) {                                   // Thomas's screenshot, cropped; k = canvas px per screenshot px
    const k = W / BEACH.w, bim = jimg(BEACH.img), jp = BEACH.jack[dir] || BEACH.jack.SE;
    g.fillStyle = '#4c6584'; g.fillRect(0, 0, W, H);
    if (bim.complete && bim.naturalWidth) { g.imageSmoothingEnabled = true; g.drawImage(bim, 0, 0, BEACH.w * k, BEACH.h * k); g.imageSmoothingEnabled = false; }
    s = k * BEACH.pxPerNative; ax = (jp[0] - BEACH.x0) * k; ay = (jp[1] - BEACH.y0) * k;
    g.fillStyle = '#0b162466'; g.beginPath(); g.ellipse(ax, ay + 2 * s, 9 * s, 3.5 * s, 0, 0, 6.283); g.fill();    // Jack's shadow
  } else {
    s = W / 160; ax = (dir === 'E' ? 40 : 54) * s; ay = (dir === 'E' ? 62 : 52) * s;
    g.fillStyle = '#28486a'; g.fillRect(0, 0, W, H);                                 // drawn water
    g.strokeStyle = '#3b6690'; g.lineWidth = Math.max(1, s * 0.8);
    for (let i = 0; i < 9; i++) { const y = (8 + i * 19) * s, ph = (now() / 900 + i * 0.37) % 1; g.beginPath(); for (let x = -10; x <= W + 10; x += 5 * s) g.lineTo(x, y + Math.sin(x / (11 * s) + ph * 6.283) * 1.4 * s + x * 0.25); g.stroke(); }
    const ux = 0.85, uy = 0.53, vx = -0.53, vy = 0.85, hw = 22 * s;               // drawn pier ending at Jack
    const e0 = [ax - 260 * s * ux, ay - 260 * s * uy], e1 = [ax + 20 * s * ux, ay + 20 * s * uy];
    const c = (p, k) => [p[0] + vx * hw * k, p[1] + vy * hw * k];
    g.fillStyle = '#7d6a55'; g.beginPath(); [c(e0, -1), c(e1, -1), c(e1, 1), c(e0, 1)].forEach(p => g.lineTo(p[0], p[1])); g.closePath(); g.fill();
    g.strokeStyle = '#5d4c3b'; g.lineWidth = Math.max(1, s);
    for (let k = 0; k < 20; k++) { const d = 20 * s - k * 14 * s, p = [ax + d * ux, ay + d * uy]; const a = c(p, -1), b = c(p, 1); g.beginPath(); g.moveTo(a[0], a[1]); g.lineTo(b[0], b[1]); g.stroke(); }
  }
  const draw = (a, idx, x, y) => { const im = jimg(a.frames[idx]); if (im.complete && im.naturalWidth) g.drawImage(im, Math.round(x - a.ax * s), Math.round(y - a.ay * s), a.w * s, a.h * s); };
  const anim = st.anim === 'eat' ? J.extras.eat : F[st.anim] || F.idle;
  draw(anim, frameOf(anim, st.e), ax, ay);
  if (st.nut && J.extras.nut) draw(J.extras.nut, 0, ax + sc.held[0] * s, ay + sc.held[1] * s);
  if (st.float && J.extras[st.float]) {
    const fx = ax + sc.float[0] * s, fy = ay + sc.float[1] * s;
    g.fillStyle = '#10223388'; g.beginPath(); g.ellipse(fx + 1 * s, fy + 13 * s, 6 * s, 2.5 * s, 0, 0, 6.283); g.fill();
    draw(J.extras[st.float], frameOf(J.extras[st.float], st.ft), fx, fy);
  }
  if (st.notes) { g.fillStyle = '#efe2ff'; g.font = `bold ${10 * s}px system-ui`; const ph = (now() / 400) % 1; g.fillText('♪', ax + 12 * s, ay - (44 + ph * 10) * s); g.fillText('♫', ax + 20 * s, ay - (38 + ((ph + 0.5) % 1) * 10) * s); }
  const u = W / 160;                                              // text size independent of the sprite scale
  if (st.zone) { g.fillStyle = '#000a'; g.fillRect(W - 92 * u, 3 * u, 89 * u, 14 * u); g.fillStyle = '#5fd38d'; g.font = `bold ${9 * u}px system-ui`; g.fillText('release on a bite', W - 88 * u, 13 * u); }
  if (st.info) { g.fillStyle = '#000a'; g.fillRect(0, H - 15 * u, W, 15 * u); g.fillStyle = '#dce6ec'; g.font = `${8.5 * u}px ui-monospace,monospace`; g.fillText(st.info, 5 * u, H - 5 * u); }
}
/* current pose from the stopwatch (live: no knowledge of the actual bite; preview: a drawn winning scenario) */
function poseAt(t) {
  const T = run.T, plan = run.plan, castLen = G_CAST;
  if (run.result === 'nut' && now() - run.resultAt < 4000) return now() - run.resultAt < 1000 ? ['catch', 0, 'Power Nut!'] : ['eat', Math.min(1, (now() - run.resultAt - 1000) / 1300), 'Power Nut!'];
  if (run.wall0 === null) return ['idle', 0, run.result === 'miss' ? 'reset and go again' : 'waiting for the start'];
  if (plan.k && t < plan.whistleEnd + 6) return ['whistle', 0, 'mash C-right'];
  if (t < T) return ['idle', 0, `cast in ${((T - t) * viMs() / 1000).toFixed(1)} s`];
  if (t < T + castLen) return ['cast', (t - T) / castLen, 'cast!'];
  const pv = run.preview;
  if (pv) {
    const rel = pv.release1 ? pv.bite1 : pv.bite2;
    if (!pv.release1 && t >= pv.bite1 && t < pv.bite1 + G_PULL) return ['bite', (t - pv.bite1) / G_PULL, 'bite 1: HOLD B'];
    if (!pv.release1 && t >= pv.bite1 + G_PULL && t < pv.bite1 + G_RECAST) return ['cast', 0.9, 're-cast (plop)'];
    if (t >= rel && t < rel + G_PULL) return ['bite', (t - rel) / G_PULL, 'bite: RELEASE B'];
    if (t >= rel + G_PULL && t < rel + G_CATCH) return ['reel', (t - rel - G_PULL) / (G_CATCH - G_PULL), 'reeling in…'];
    if (t >= rel + G_CATCH && t < rel + G_CATCH + G_SHOW) return ['catch', 0, 'Power Nut!'];
    if (t >= rel + G_CATCH + G_SHOW && t < rel + G_DONE) return ['eat', (t - rel - G_CATCH - G_SHOW) / (G_EATEN - G_CATCH - G_SHOW), 'eats the Power Nut'];
    if (t >= rel + G_DONE) { if (t > rel + G_DONE + 120) { run.wall0 = null; run.preview = null; } return ['catch', 0, 'max stamina up!']; }
    return ['wait', 0, 'waiting…'];
  }
  if ((run.pol === 'zone' || held()) && inRelease(t)) return ['zone', 0, 'bite now → RELEASE'];
  return ['wait', 0, run.pol === 'bite1' ? 'release at the bite' : run.pol === 'hold' ? 'hold bite 1, release bite 2' : 'bite now → HOLD'];
}

/* ---------------------------------------------------------------- scrolling timeline */
function drawTimeline(t) {
  const cv = $('lkTimeline'), dpr = devicePixelRatio, W = cv.width = cv.clientWidth * dpr, H = cv.height = 230 * dpr;
  const g = cv.getContext('2d'), plan = run.plan, T = run.T, z = run.zone, sec = 1000 / viMs();
  g.clearRect(0, 0, W, H);
  if (!plan) return;
  const live = run.wall0 !== null;
  const lastZ = z && run.pol === 'zone' && z.zones.length ? z.zones[z.zones.length - 1][1] : T + 8 * sec;
  const v0 = live ? t - 2.5 * sec : Math.max(1, T - 3 * sec);
  const span = live ? 16 * sec : Math.max(14 * sec, Math.min(45 * sec, lastZ + 3 * sec - v0));
  const X = v => (v - v0) / span * W;
  const lane1 = [8 * dpr, 64 * dpr], lane2 = [84 * dpr, 186 * dpr];
  g.font = `${10 * dpr}px system-ui`;
  if (plan.k) { g.fillStyle = '#b48cff2a'; g.fillRect(X(1), 0, X(plan.whistleEnd) - X(1), H); g.fillStyle = '#b48cff'; g.fillText(`♪ mash C-right ×${plan.k}`, X(1) + 3 * dpr, H - 30 * dpr); }
  if (T - R0() > 37500 / viMs()) { const a = 33000 / viMs() + 1 + R0(), b = 38000 / viMs() + 1 + R0(); g.fillStyle = '#f0b35a22'; g.fillRect(X(a), 0, X(b) - X(a), lane1[1]); g.fillStyle = '#f0b35a'; g.fillText('push SE', X(a) + 3 * dpr, lane1[1] - 4 * dpr); }
  // lane 1: P(Nut) for a cast at each moment (selected policy)
  const P = curveC(plan, run.pol);
  let ym = 0.05;
  for (let v = Math.max(1, Math.floor(v0)); v < Math.min(P.length, v0 + span); v++) if (!isNaN(P[v])) ym = Math.max(ym, P[v]);
  g.fillStyle = '#5fd38d66';
  const step = Math.max(1, Math.floor(span / W * 2));
  for (let v = Math.max(1, Math.floor(v0)); v < Math.min(P.length, v0 + span); v += step) {
    if (isNaN(P[v])) continue;
    const h = P[v] / ym * (lane1[1] - lane1[0]);
    g.fillRect(X(v), lane1[1] - h, Math.max(1, X(v + step) - X(v)), h);
  }
  g.fillStyle = '#8ea3b2'; g.fillText(`P(Nut) if you cast here (${POLNAME[run.pol]})`, 4 * dpr, lane1[0] + 8 * dpr);
  g.strokeStyle = '#6fb7ff'; g.lineWidth = 2 * dpr; g.beginPath(); g.moveTo(X(T), lane1[0]); g.lineTo(X(T), lane2[1]); g.stroke();
  g.fillStyle = '#6fb7ff'; g.font = `bold ${11 * dpr}px system-ui`; g.fillText('CAST ' + fmtS(T), X(T) + 3 * dpr, lane1[0] + 22 * dpr);
  g.fillStyle = '#6fb7ffaa'; g.fillRect(X(T + G_CAST) - 1, lane2[0] - 6 * dpr, 2, 10 * dpr);
  g.font = `${9 * dpr}px system-ui`; g.fillText('plop', X(T + G_CAST) + 2 * dpr, lane2[0] - 1 * dpr);
  // lane 2: bites after this cast. Zones (release), first-bite Nuts (green), first bites overall (grey), second-bite Nuts when holding (yellow)
  if (z) {
    g.font = `${10 * dpr}px system-ui`;
    const bands = held() ? (run.tapInfo.dud ? [] : run.tapInfo.spans2.map(([a, b]) => [a, b + WINDOW_VI])) : run.pol === 'zone' ? z.zones : [];
    for (const [a, b] of bands) {
      g.fillStyle = held() ? '#e7c14a33' : '#5fd38d33'; g.fillRect(X(a), lane2[0], Math.max(2, X(b) - X(a)), lane2[1] - lane2[0]);
      g.fillStyle = held() ? '#ffd54a' : '#5fd38d'; g.fillText(held() ? 'bite 2: release' : 'release', X(a) + 2 * dpr, lane2[0] + 22 * dpr);
    }
    let mf = 1e-9, mn = 1e-9, m2 = 1e-9;
    const holdish = run.pol === 'hold' || run.pol === 'tap', d2 = holdish ? z.d2all : z.d2n;
    for (let i = 0; i < z.d1n.length; i++) { mf = Math.max(mf, z.d1f[i] + z.d1n[i]); mn = Math.max(mn, z.d1n[i]); m2 = Math.max(m2, d2[i]); }
    const bw = z.binVI, base = lane2[1], hh = lane2[1] - lane2[0] - 28 * dpr;
    for (let i = 0; i < z.d1n.length; i++) {
      const x = X(i * bw), w = Math.max(1.5 * dpr, X((i + 1) * bw) - x - 1);
      if (x > W || x + w < 0) continue;
      const hf = (z.d1f[i] + z.d1n[i]) / mf * hh * 0.45;
      g.fillStyle = '#5b6f7f88'; g.fillRect(x, base - hf, w, hf);
      if (!holdish && z.d1n[i] > 0) { const hn = z.d1n[i] / mn * hh; g.fillStyle = '#5fd38d'; g.fillRect(x, base - hn, w, hn); }
      if (run.pol !== 'bite1' && d2[i] > 0) { const h2 = d2[i] / m2 * hh * 0.8; g.fillStyle = run.tapInfo ? '#e7c14a55' : '#e7c14a'; g.fillRect(x + w * 0.25, base - h2, Math.max(1, w * 0.5), h2); }
    }
    g.fillStyle = '#8ea3b2';
    g.fillText(run.pol === 'zone' ? 'grey: first bites · green: Nut if you release that first bite · yellow: Nut on the second bite when you held · band: release zone'
      : run.pol === 'bite1' ? 'grey: first bites · green: Nut when you release at that first bite'
      : run.pol === 'tap' ? 'grey: first bites (hold through, tap the key) · yellow: Nut on the second bite · after your tap: bright yellow = where the Nut bite 2 can still come'
      : 'grey: first bites (hold through) · yellow: Nut on the second bite', 4 * dpr, lane2[0] + 8 * dpr);
    const ti = run.tapInfo;
    if (ti && ti.holdish) {
      g.setLineDash([4 * dpr, 3 * dpr]); g.strokeStyle = '#ffffff'; g.lineWidth = 1.5 * dpr;
      g.beginPath(); g.moveTo(X(ti.tau), lane2[0]); g.lineTo(X(ti.tau), lane2[1]); g.stroke(); g.setLineDash([]);
      g.fillStyle = '#ffffff'; g.fillText('your tap', X(ti.tau) + 3 * dpr, lane2[0] + 20 * dpr);
      const bins = {}; let mx = 1e-9;
      for (const e of ti.sc) if (e.n2) { const b = Math.floor(e.t2 / 6); bins[b] = (bins[b] || 0) + e.w; mx = Math.max(mx, bins[b]); }
      for (const [b, v] of Object.entries(bins)) { const x = X(+b * 6), w = Math.max(2 * dpr, X(+b * 6 + 6) - x - 1), h = v / mx * hh; g.fillStyle = '#ffd54a'; g.fillRect(x, base - h, w, h); }
    }
    const nutIm = JACK && L.figure !== 'stick' && JACK.extras.nut ? jimg(JACK.extras.nut.frames[0]) : null;
    for (let i = 0; i < z.d1n.length; i++) if ((!holdish && z.d1n[i] > 0.35 * mn) || (holdish && d2[i] > 0.35 * m2)) {
      const x = X((i + 0.5) * bw + G_CATCH), y = lane2[1] + 12 * dpr;
      if (nutIm && nutIm.complete && nutIm.naturalWidth) { g.imageSmoothingEnabled = false; g.drawImage(nutIm, x - 8 * dpr, y - 8 * dpr, 16 * dpr, 16 * dpr); }
      else drawNut(g, x, y, 5 * dpr, false);
    }
  }
  g.fillStyle = '#8ea3b2'; g.font = `${10 * dpr}px ui-monospace,monospace`;
  const s0 = Math.ceil((v0 - 1) / sec), s1 = (v0 + span - 1) / sec, every = span / sec > 24 ? 2 : 1;
  for (let k = s0; k <= s1; k++) { if (k % every) continue; const x = X(k * sec + 1); g.fillRect(x, H - 14 * dpr, 1, 4 * dpr); g.fillText(k + 's', x + 2, H - 3 * dpr); }
  if (live) { g.strokeStyle = '#ffffff'; g.lineWidth = 2 * dpr; g.beginPath(); g.moveTo(X(t), 0); g.lineTo(X(t), H); g.stroke(); }
  const pr = run.practice;
  if (pr && pr.last && Number.isFinite(pr.last.e) && pr.state !== 'armed') {   // your last practice press vs the CAST line
    const xp = X(T + pr.last.e / viMs());
    g.strokeStyle = '#ff9a50'; g.lineWidth = 3 * dpr; g.beginPath(); g.moveTo(xp, lane1[0]); g.lineTo(xp, lane2[1]); g.stroke();
    g.fillStyle = '#ff9a50'; g.font = `bold ${12 * dpr}px system-ui`; g.fillText('you ' + msTxt(pr.last.e), xp + 4 * dpr, lane1[0] + 40 * dpr);
  }
  if (pr && !L.pracLine && pr.state === 'armed') {             // beeps only: nothing to watch
    g.fillStyle = '#0b1219'; g.fillRect(0, 0, W, H);
    g.fillStyle = '#8ea3b2'; g.font = `${13 * dpr}px system-ui`; g.fillText(L.audio ? 'beeps only — eyes on the TV, press on the last beep' : 'pulses only — the lamp pulses 3-2-1: press on CAST', 12 * dpr, H / 2);
  }
}

/* ---------------------------------------------------------------- cast practice (v29.8)
   The same cues as an attempt with the current plan: the scrolling timeline with the CAST line, the "Cast in" countdown,
   the angler and the four countdown beeps. Press the start key (or any button of a connected controller) on the last
   beep. Each press is logged vs the cue (event time, ms; + = late). Quick mode starts each cast 4 s before the cue;
   full mode waits for a start-key press and runs the whole plan (start → cast) like an attempt. "Moving cast line" off
   = beeps only, as in a real attempt with your eyes on the TV. The profile (median = bias, MAD-trimmed SD = spread)
   sets the beep correction and the timing spread: spread = hypot(press SD, start-key SD 60 ms). */
const PRAC = { lead: 4000, win: 600, gap: [1100, 2300], keep: 300, startSd: 60 };
let pracLog = store.get('hm64v29_lucky_castprac', null);
if (!Array.isArray(pracLog)) pracLog = (store.get('hm64v29_lucky_prac', []) || []).filter(Number.isFinite)
  .map(e => ({ at: 0, e: Math.round(e), m: 'beeps', src: 'B key' }));   // the old beep drill's presses
const pracMode = () => (L.pracLine ? 'line' : 'beeps');      // 'beeps' = cues without the moving line (pulses / beeps)
const PRAC_MODE_A = { line: 'moving line + beeps', beeps: 'beeps only' }, PRAC_MODE_V = { line: 'moving line + bar + pulses', beeps: 'pulses only' };
const PRAC_MODE = new Proxy({}, { get: (o, k) => (L.audio ? PRAC_MODE_A : PRAC_MODE_V)[k] });
const cueKind = r => (r.v ? 'v' : 'a');                       // v29.10: presses to the visual cue (v) vs to beeps (a): kept apart
const evTime = e => (e && e.timeStamp > 0 && e.timeStamp < 1e11 ? e.timeStamp : now());
function castStats(es) {                                       // robust: median, then mean / SD of the presses within 3 MAD
  const v = es.filter(Number.isFinite).slice().sort((a, b) => a - b), n = v.length;
  if (!n) return null;
  const q = (a, f) => a[Math.min(a.length - 1, Math.max(0, Math.round(f * (a.length - 1))))];
  const med = q(v, 0.5), mad = 1.4826 * q(v.map(x => Math.abs(x - med)).sort((a, b) => a - b), 0.5);
  const keep = v.filter(x => Math.abs(x - med) <= Math.max(3 * mad, 40));
  const mean = keep.reduce((a, x) => a + x, 0) / keep.length;
  const sd = keep.length > 1 ? Math.sqrt(keep.reduce((a, x) => a + (x - mean) ** 2, 0) / (keep.length - 1)) : NaN;
  const GF = 2000 / 60, within = (c, w) => v.filter(x => Math.abs(x - c) <= w).length / n;
  return { n, out: n - keep.length, med, mean, sd, raw1: within(0, GF / 2), cor1: within(med, GF / 2), cor2: within(med, GF * 1.5) };
}
const pracErrs = mode => pracLog.filter(r => r.m === mode && Number.isFinite(r.e) && cueKind(r) === (L.audio ? 'a' : 'v')).map(r => r.e);
const attemptErrs = () => tally.filter(x => Number.isFinite(x.castErrMs) && (x.v ? 'v' : 'a') === (L.audio ? 'a' : 'v')).map(x => x.castErrMs);
function practiceStart() {
  stop(true);
  run.practice = { rep: 0, cue: null, state: 'idle', last: null, timer: null, session: [], pads: {} };
  refresh();
  if (!L.pracFull) practiceSchedule(700);
}
function practiceStop() {
  const p = run.practice; if (!p) return;
  clearTimeout(p.timer); run.practice = null; cancelBeeps(); run.wall0 = null;
  refresh();
}
function practiceSchedule(ms) {
  const p = run.practice; if (!p) return;
  clearTimeout(p.timer); p.state = 'gap'; p.timer = setTimeout(() => practiceRep(null), ms);
}
function practiceRep(startAt) {                                 // one cast: quick (4 s lead-in) or full (from a start press)
  const p = run.practice; if (!p) return;
  cancelBeeps(); run.tapInfo = null; run.castTap = null; run.result = null; run.preview = null;
  const T = run.T;
  run.wall0 = startAt != null ? startAt : now() - Math.max(0, (T - 1) * viMs() - PRAC.lead);
  p.cue = run.wall0 + (T - 1) * viMs();                         // practice cue = the CAST line (no beep correction)
  [-1500, -1000, -500].forEach(d => { if (p.cue + d > now() + 30) beepAt(p.cue + d, 440, 0.06); });
  beepAt(p.cue, 880, 0.14);
  p.state = 'armed'; p.rep++; p.early = false;
  clearTimeout(p.timer); p.timer = setTimeout(() => practicePress(null), p.cue - now() + PRAC.win);
}
function practiceInput(ts, src) {                               // start key / controller button while practising
  const p = run.practice; if (!p) return false;
  if (p.state === 'idle' || (p.state === 'done' && L.pracFull && run.wall0 === null)) { if (L.pracFull) practiceRep(ts); return true; }
  return practicePress(ts, src);
}
function practicePress(ts, src) {                               // ts: press time (performance.now base); null = no press
  const p = run.practice; if (!p || p.state !== 'armed') return false;
  if (ts !== null && ts < p.cue - PRAC.win) { p.early = true; return true; }   // far too early: ignored, still armed
  clearTimeout(p.timer);
  const rec = { at: Date.now(), e: ts === null ? null : Math.round((ts - p.cue) * 10) / 10, m: pracMode(), src: src || keyName(), ...(L.audio ? {} : { v: 1 }) };
  pracLog.push(rec); pracLog = pracLog.slice(-PRAC.keep); store.set('hm64v29_lucky_castprac', pracLog);
  setTimeout(updateProfile, 0);                                  // the one-reaction fit uses your B presses
  p.session.push(rec); p.last = rec; p.state = 'done';
  renderPractice();
  p.timer = setTimeout(() => {
    if (run.practice !== p) return;
    run.wall0 = null;
    if (!L.pracFull) practiceSchedule(PRAC.gap[0] + Math.random() * (PRAC.gap[1] - PRAC.gap[0]));
  }, Math.max(0, p.cue + 900 - now()));
  return true;
}
function applyCastProfile(quiet) {                              // beep correction = -median, spread = hypot(SD, start-key SD)
  const s = castStats(pracErrs(pracMode()));
  if (!s || s.n < 5 || !isFinite(s.sd)) { if (!quiet) $('lkPracTxt').insertAdjacentHTML('beforeend', ' <b>Need 5 presses in this mode first.</b>'); return false; }
  L.biasMs = -Math.round(s.med);                                // the manual values (used when "auto" is off in L5)
  L.sigmaMs = sigmaFrom(s.sd);
  save(); fillLSettings(); bestCache = null; ccache.clear(); persCache.clear();
  if (!(run.practice && run.practice.state === 'armed')) refresh();
  return true;
}
const msTxt = x => `${x >= 0 ? '+' : ''}${Math.round(x)} ms`;
function practiceMsg(t) {
  const p = run.practice, k = keyName();
  if (p.state === 'idle') return [`Cast practice (full wait): press ${k} as if ${startName()} — then press ${k} again on CAST (cast ${fmtS(run.T)}). Esc stops.`, ''];
  if (p.state === 'armed') {
    if (p.early && t < run.T - PRAC.win / viMs()) return ['Too early — wait for the 3-2-1', 'hold'];
    return L.pracLine ? [`Cast in ${Math.max(0, (run.T - t) * viMs() / 1000).toFixed(1)} s — press ${k} on CAST`, run.T - t < 90 ? 'go' : '']
      : [L.audio ? `Listen — press ${k} on the last (high) beep` : `Watch the lamp — press ${k} on CAST (after 3-2-1)`, ''];
  }
  const r = p.last;
  if (!r) return ['Get ready…', ''];
  if (r.e === null) return ['Missed — no press within 0.6 s of CAST', 'hold'];
  const gf = r.e / (2000 / 60);
  const verdictTxt = Math.abs(r.e) <= 1000 / 60 ? 'on the frame' : `${Math.abs(gf).toFixed(1)} game frames ${r.e > 0 ? 'late' : 'early'}`;
  return [`${msTxt(r.e)} — ${verdictTxt}${L.pracFull && p.state === 'done' && run.wall0 === null ? ` · ${k} for the next one` : ''}`, Math.abs(r.e) <= 1000 / 60 ? 'go' : Math.abs(r.e) <= 50 ? '' : 'hold'];
}
const pbCache = new Map();
function bestAt(sigMs) {                                        // best odds of the current plan at a timing spread
  const key = selKey() + ':' + sigMs + ':' + L.personal + ':' + profVer;
  if (!pbCache.has(key)) {
    const b = LuckyCore.best(P(planObj()), Math.max(1, sigMs / viMs()), 30 + R0());
    pbCache.set(key, Math.max(b.zone.p, b.bite1.p, b.hold.p));
  }
  return pbCache.get(key);
}
function renderPractice() {
  const btn = $('lkPractice'); if (!btn) return;
  btn.textContent = run.practice ? 'Stop practice (Esc)' : 'Cast practice';
  $('lkPracLine').checked = L.pracLine; $('lkPracFull').checked = L.pracFull;
  if ($('lkPracApply')) $('lkPracApply').hidden = L.biasAuto !== false && L.sigmaAuto !== false;
  const mode = pracMode(), es = pracErrs(mode), s = castStats(es), sa = castStats(attemptErrs());
  const miss = pracLog.filter(r => r.m === mode && r.e === null && cueKind(r) === (L.audio ? 'a' : 'v')).length;
  const ses = run.practice ? castStats(run.practice.session.filter(r => Number.isFinite(r.e)).map(r => r.e)) : null;
  const parts = [];
  if (!s) parts.push(`No presses yet in <b>${PRAC_MODE[mode]}</b> mode${L.audio ? '' : ' (presses made with sound are kept apart)'}. Start practice and press ${keyName()} on CAST.`);
  else {
    parts.push(`<b>${PRAC_MODE[mode]}</b>: ${s.n} press${s.n === 1 ? '' : 'es'}${miss ? ` (+${miss} missed)` : ''} · you press <b>${msTxt(s.med)}</b> vs CAST (median) · spread <b>${isFinite(s.sd) ? Math.round(s.sd) + ' ms' : '—'}</b> (1 SD${s.out ? `, ${s.out} outlier${s.out === 1 ? '' : 's'} left out` : ''})`);
    parts.push(`on the right game frame: ${Math.round(100 * s.raw1)}% as you press now, ${Math.round(100 * s.cor1)}% once the cue is shifted by ${msTxt(-s.med)} (within ±1 frame: ${Math.round(100 * s.cor2)}%)`);
    if (ses && run.practice.session.length >= 3) parts.push(`this session: ${ses.n} · ${msTxt(ses.med)} · spread ${isFinite(ses.sd) ? Math.round(ses.sd) + ' ms' : '—'}`);
    if (s.n >= 5 && isFinite(s.sd)) {
      const sig = sigmaFrom(s.sd);
      parts.push(`with this profile: cast-cue correction ${msTxt(-s.med)}, timing spread ${sig} ms (your ${Math.round(s.sd)} ms + start tap ${PRAC.startSd} + clock offset ±${Math.round(offsetSdMs())} ms) → best cast <b>${pct(bestAt(sig))}</b>` +
                 ` (in use: ${msTxt(cueCorr())}, ${sigmaMs()} ms → ${pct(bestAt(sigmaMs()))})`);
    }
  }
  if (sa) parts.push(`in real attempts (${keyName()} tapped with B): ${sa.n} casts · ${msTxt(sa.med)} vs the CAST cue · spread ${isFinite(sa.sd) ? Math.round(sa.sd) + ' ms' : '—'}`);
  $('lkPracTxt').innerHTML = parts.join('<br>');
  drawPracHist(es, s, attemptErrs());
}
function drawPracHist(es, s, ea) {                              // presses per 1/60 s vs the beep; range zooms to your spread
  const cv = $('lkPracHist'); if (!cv) return;
  const dpr = devicePixelRatio, W = cv.width = Math.max(10, cv.clientWidth * dpr), H = cv.height = 64 * dpr, g = cv.getContext('2d'), top = 13 * dpr;
  g.clearRect(0, 0, W, H);
  const R = s && isFinite(s.sd) ? Math.max(100, Math.min(300, Math.ceil((Math.abs(s.med) + 4 * s.sd) / 50) * 50)) : 300;
  const bw = 1000 / 60, nb = Math.round(2 * R / bw), lo = -nb / 2 * bw, hi = nb / 2 * bw, X = ms => (ms - lo) / (hi - lo) * W;
  const bins = new Array(nb).fill(0), binA = new Array(nb).fill(0);
  const put = (arr, e) => { arr[Math.floor((Math.max(lo, Math.min(hi - 1e-6, e)) - lo) / bw)]++; };
  es.forEach(e => put(bins, e)); ea.forEach(e => put(binA, e));
  const mx = Math.max(1, ...bins, ...binA), base = H - 12 * dpr;
  g.fillStyle = '#6fb7ff'; bins.forEach((v, i) => { if (v) { const h = v / mx * (base - top); g.fillRect(X(lo + i * bw) + 1, base - h, Math.max(1, X(lo + (i + 1) * bw) - X(lo + i * bw) - 2), h); } });
  g.fillStyle = '#ffd54a'; binA.forEach((v, i) => { if (v) { const h = v / mx * (base - top); g.fillRect(X(lo + (i + 0.5) * bw) - 1.5 * dpr, base - h, 3 * dpr, h); } });
  g.strokeStyle = '#ffffff'; g.lineWidth = 1.5 * dpr; g.beginPath(); g.moveTo(X(0), top); g.lineTo(X(0), base); g.stroke();
  if (s) { g.strokeStyle = '#ff9a50'; g.setLineDash([3 * dpr, 3 * dpr]); g.beginPath(); g.moveTo(X(s.med), top); g.lineTo(X(s.med), base); g.stroke(); g.setLineDash([]); }
  g.fillStyle = '#8ea3b2'; g.font = `${9 * dpr}px ui-monospace,monospace`;
  const step = R > 150 ? 100 : 50;
  for (let ms = -Math.floor(R / step) * step; ms <= R; ms += step) {
    const tx = (ms > 0 ? '+' : '') + ms + (ms + step > R ? ' ms' : ''), w = g.measureText(tx).width;
    g.fillText(tx, Math.max(0, Math.min(W - w, X(ms) - w / 2)), H - 2 * dpr);
  }
  g.fillText('blue practice · yellow real casts · white CAST cue · orange median', 2 * dpr, 9 * dpr);
}

/* ---------------------------------------------------------------- settings */
function fillLSettings() {
  syncTimingInputs();
  const dog = anchor() === 'dog', R = routeDef();
  const rs = $('lkRoute');
  if (rs) {
    const bases = LuckyCore.routes().filter(r => !r.variant_of);
    rs.innerHTML = bases.map(r => `<option value="${r.id}">${r.label}</option>`).join('');
    rs.value = baseOf(route()); rs.disabled = bases.length < 2;
  }
  $('lkAnchor').innerHTML = (R.anchors || []).map(a => `<option value="${a.id}">${a.id === 'dog' ? 'when the dog lands (recommended)' : R.groups ? a.label + (a.id === R.anchors[0].id ? ' (recommended)' : '') : a.id === 'beach' ? 'at beach entry (recommended)' : a.label}</option>`).join('');
  $('lkAnchor').value = anchor(); $('lkAnchor').disabled = R.id === 'carry' && !D.pace;
  labelStarts();
  $('lkStartDelayLbl').textContent = dog ? 'Dog-landing key delay (ms)' : 'Start-tap delay, every start (ms)';
  $('lkStartDelay').value = startDelay();
  $('lkStartDelayHint').textContent = dog ? '−130 = key together with your A press (the dog lands 8 frames after A) · about +150 = key when you see it land'
    : 'how late your start / clock taps come after their cue (ranch exit, beach cue, dock end, READY): one value for every start; ticked, your bite taps add what they measure on this start';
  $('lkFacing').value = L.facing; $('lkZoneBeeps').checked = L.zoneBeeps; $('lkAudio').checked = L.audio;
  if ($('lkCueGlow')) $('lkCueGlow').checked = L.cueGlow;
  $('lkCastTap').checked = L.castTap; $('lkTapPrec').value = L.tapPrecMs;
  $('lkStartKey').textContent = L.startKey === ' ' ? 'Space' : L.startKey;
  renderTimingSum(); renderRouteBox();
}
/* L1: the route (chosen in Settings) + the sparrows checkbox for routes with a sparrow table */
function renderRouteBox() {
  if (!$('lkRouteName')) return;
  const base = baseOf(route()), B = LuckyCore.routeOf(base) || routeDef(), sp = sparrowTable();
  $('lkRouteName').textContent = B.label;
  const cb = $('lkSparrows'), lbl = $('lkSparLbl'), on = !!sp && route() === sp.id;
  cb.checked = on; cb.disabled = !sp;
  lbl.className = 'lkspar' + (!sp ? ' off' : on ? ' on' : '');
  lbl.title = sp ? 'Tick when the two sparrows sit by the doghouse as Jack walks out of the house (menus 5-6 game frames late)' : 'No sparrow table for this route';
  $('lkSparTxt').innerHTML = !sp ? '' : on ? `Using the sparrow table (${esc(sp.label)}). Untick (<kbd>S</kbd>) on a morning without them.`
    : 'Tick (or press <kbd>S</kbd>) when the two sparrows sit by the doghouse as you leave the house.';
}
/* the sparrows checkbox: switch to / from the variant table, keeping the preset and the start; during an attempt (before
   the cast) the same clock and taps carry on with the other table */
function setSparrows(on) {
  const base = baseOf(route()), sp = variantOf(base, 'sparrows'), target = on && sp ? sp.id : base;
  if (sp) { L.sparrows = !!on; save(); }
  if (target === route()) { renderRouteBox(); return false; }
  if (run.wall0 !== null && (run.preview || run.castTap !== null || run.tapInfo || (now() - run.wall0) / viMs() + 1 >= run.T - 90)) {
    if (sp) { L.sparrows = !on; save(); }
    cueFlash('too late to switch: the cast is due', 'warn', 1500); renderRouteBox(); return false;
  }
  const pace = LuckyCore.selection.pace, anch = anchor(), R2 = LuckyCore.routeOf(target);
  setSelection((R2.groups || []).some(g => g.id === pace) ? pace : 'all', (R2.anchors || []).some(a => a.id === anch) ? anch : null, target);
  if (run.wall0 !== null) {
    run.plan0 = run.plan;
    if (run.gp) { run.gp.rdy = readySpread(run.plan); run.gp.g3 = null; if (run.gp.cue && run.gp.cue.dock) goal3(); }
    cancelBeeps(); scheduleBeeps();
  }
  cueFlash(on ? 'sparrow table' : 'no-sparrow table', 'info', 900);
  return true;
}
/* L4's first line: how the clock and the beep are set, all offsets in one sentence (v29.9 settings reorganisation) */
function renderTimingSum() {
  const el = $('lkTimingSum');
  if (!el) return;
  const vi = viMs(), sg = v => (v >= 0 ? '+' : '−') + Math.abs(Math.round(v)), b = autoB(), dly = startDelay(), dog = anchor() === 'dog';
  const d = pressData(), ps = pressReady(), lag = prof && prof.lag && prof.lag.n >= 3 ? prof.lag : null;
  const row = (what, val, src) => `<tr><td>${what}</td><td><b>${val}</b></td><td class="mut">${src}</td></tr>`;
  const tuned = L.autoTune && prof && prof.n >= 8;
  const startVal = dog ? `${sg(dly)} ms (key with A)` : `${Math.round(dly + b * vi)} ms after the cue`;
  const nC = prof ? prof.nCast || 0 : 0, nN = prof ? prof.nNoCast || 0 : 0;
  const startSrc = dog ? 'set by hand' : !L.autoTune ? 'set by hand' : nC >= 8 ? `${dly} set + ${sg(b * vi)} learned from ${nC} attempts with the cast tap`
    : prof && prof.kTied != null && nN >= 8 ? `${dly} set + ${sg(b * vi)} learned from ${nN} bite taps (one reaction for start and bite taps, 70% applied)`
    : !ps ? `${dly} assumed; learns after 5 B presses (cast practice) + 8 bite taps (${nN}/8)`
    : `${dly} assumed; learns from your bite taps after 8 (${nN}/8)`;
  const pressVal = ps ? `${msTxt(ps.med)} vs CAST` : '—', corr = cueCorr();
  const pressSrc = L.biasAuto === false ? `set by hand: CAST cue ${sg(corr)} ms` : ps ? `${ps.n} presses (${d.pr.length} practice + ${d.at.length} real casts) → CAST cue ${sg(corr)} ms`
    : `no presses yet (${d.es.length}/5): cast practice (L5)${L.castTap ? ', or the cast tap in attempts' : ''}`;
  const lagVal = lag ? `${Math.round(lag.mu * vi)} ms after the bite` : '—';
  const lagSrc = lag ? `±${Math.round((lag.sd || 0) * vi)}, from ${lag.n} bite taps${lag.mu + (lag.sd || 0) > WINDOW_VI - 2 ? ' · <b style="color:#ffd28a">close to the 333 ms window: anticipate the bite</b>' : ''}` : 'learned after 3 bite taps';
  const eff = sigEffMs(), pk = L.personalCast ? personalKernel() : null;
  const varyVal = `±${pk ? Math.round(pk.sd * vi) : eff} ms`;
  const varySrc = (L.sigmaAuto === false ? `set by hand ±${sigmaMs()}` : ps && isFinite(ps.sd) ? `B presses ±${Math.round(ps.sd)} + start tap ±${START1_MS} + clock offset known ±${Math.round(offsetSdMs())}` : `assumed ±${sigmaMs()} (no presses yet)`) +
    (anchor() === 'fadein' && route() !== 'carry' && eff !== sigmaMs() ? `, clock from ${clockCues().length} tap${clockCues().length > 1 ? 's' : ''}` : '') + (pk ? ', personalized kernel' : '');
  el.innerHTML = '<table class="plan small lktime">' +
    row('Start taps', startVal, startSrc) + row('B press on CAST', pressVal, pressSrc) + row('Bite taps', lagVal, lagSrc) + row('How much you vary', varyVal, varySrc) + '</table>' +
    `<div class="small mut" style="margin-top:3px">Each number learns by itself from every attempt and practice press (auto); "Set by hand" below overrides one. ` +
    `Reacting to a cue you can't time (start, bite) and pressing on a countdown you see coming (CAST) are different timings, so they stay separate rows.` +
    (!L.castTap ? ` The cast tap is off (Settings): the start-tap delay learns from your bite taps, assuming they come as late as your start taps (one reaction; 70% of what that implies is applied).` : '') + '</div>';
}
$('lkSigma').oninput = e => { L.sigmaMs = +e.target.value; $('lkSigmaV').textContent = L.sigmaMs + ' ms'; };
$('lkSigma').onchange = () => { save(); bestCache = null; refresh(); };
/* the hand-set inputs show the values in use; a row's input is live only while its auto box is off (or has no data) */
function syncTimingInputs() {
  if (!$('lkSigma')) return;
  const ready = !!pressReady();
  $('lkSigma').value = sigmaMs(); $('lkSigmaV').textContent = sigmaMs() + ' ms'; $('lkSigma').disabled = L.sigmaAuto !== false && ready;
  $('lkBias').value = cueCorr(); $('lkBias').disabled = L.biasAuto !== false && ready;
  if ($('lkSigmaAuto')) $('lkSigmaAuto').checked = L.sigmaAuto !== false;
  if ($('lkBiasAuto')) $('lkBiasAuto').checked = L.biasAuto !== false;
  if ($('lkAutoTune')) $('lkAutoTune').checked = !!L.autoTune;
}
/* switching a row to manual starts from the value it had */
const cueCorr0 = () => { const s = pressReady(); return s ? -Math.round(s.med) : L.biasMs; };
const sigmaMs0 = () => { const s = pressReady(); return s && isFinite(s.sd) ? sigmaFrom(s.sd) : L.sigmaMs; };
$('lkStartDelay').onchange = e => {
  const v = +e.target.value;
  if (anchor() === 'dog') L.dogDelayMs = v; else L.startTapMs = v;
  save(); refresh();
};
$('lkAnchor').onchange = e => setSelection(null, e.target.value);
if ($('lkPracBox')) $('lkPracBox').addEventListener('toggle', () => renderPractice());
if ($('lkHowBox')) { $('lkHowBox').open = L.howOpen !== false; $('lkHowBox').addEventListener('toggle', () => { L.howOpen = $('lkHowBox').open; save(); }); }
if ($('lkAutoTune')) $('lkAutoTune').onchange = e => { L.autoTune = e.target.checked; save(); refresh(); };
$('lkPaceTxt').addEventListener('click', e => {                 // "use it": switch to the best start for this preset
  const t = e.target.closest && e.target.closest('[data-start]');
  if (t) { e.preventDefault(); setSelection(null, t.dataset.start); }
});
if ($('lkRoute')) $('lkRoute').onchange = e => {
  const sp = L.sparrows && variantOf(e.target.value, 'sparrows');
  setSelection(null, null, sp ? sp.id : e.target.value);
};
if ($('lkSparrows')) $('lkSparrows').onchange = e => setSparrows(e.target.checked);
if ($('lkRouteChange')) $('lkRouteChange').onclick = e => { e.preventDefault(); $('settingsBtn').click(); };
$('lkBias').onchange = e => { L.biasMs = +e.target.value; save(); refresh(); };
if ($('lkBiasAuto')) $('lkBiasAuto').onchange = e => { L.biasAuto = e.target.checked; if (!L.biasAuto) L.biasMs = cueCorr0(); save(); fillLSettings(); refreshSig(); };
if ($('lkSigmaAuto')) $('lkSigmaAuto').onchange = e => { L.sigmaAuto = e.target.checked; if (!L.sigmaAuto) L.sigmaMs = sigmaMs0(); save(); fillLSettings(); refreshSig(); };
$('lkFacing').onchange = e => { L.facing = e.target.value; save(); };
$('lkZoneBeeps').onchange = e => { L.zoneBeeps = e.target.checked; save(); };
$('lkAudio').onchange = e => { L.audio = e.target.checked; save(); renderPractice(); };
if ($('lkCueGlow')) $('lkCueGlow').onchange = e => { L.cueGlow = e.target.checked; save(); };
if ($('lkPersonalCast')) $('lkPersonalCast').onchange = e => { L.personalCast = e.target.checked; save(); refreshSig(); };
$('lkCastTap').onchange = e => { L.castTap = e.target.checked; save(); refresh(); };
$('lkTapPrec').onchange = e => { L.tapPrecMs = Math.max(10, +e.target.value || 40); save(); updateProfile(); refresh(); };
let capturing = false;
$('lkStartKey').onclick = () => { capturing = true; $('lkStartKey').textContent = 'press a key…'; };
document.querySelectorAll('#lkPol button').forEach(b => { b.onclick = () => { L.policy = b.dataset.pol; L.castT = null; save(); refresh(); }; });
$('lkAutoPlan').onclick = () => { L.plan = 'auto'; L.policy = 'auto'; L.castT = null; save(); refresh(); };
$('lkMinus').onclick = () => { L.castT = Math.max(run.plan.firstT, run.T - 2); save(); refresh(); };
$('lkPlus').onclick = () => { L.castT = Math.min(LuckyCore.TMAX, run.T + 2); save(); refresh(); };
$('lkBest').onclick = () => { L.castT = null; save(); refresh(); };
$('lkOverview').onclick = overviewClick;
$('lkStart').onclick = () => (run.practice ? practiceStop() : run.wall0 === null ? start() : stop(true));
$('lkHit').onclick = () => record(true); $('lkMiss').onclick = () => record(false, 'fish'); $('lkEmpty').onclick = () => record(false, 'empty');
$('lkPreview').onclick = preview;
$('lkPractice').onclick = () => (run.practice ? practiceStop() : practiceStart());
$('lkPracLine').onchange = e => { L.pracLine = e.target.checked; save(); renderPractice(); };
$('lkPracFull').onchange = e => { L.pracFull = e.target.checked; save(); if (run.practice) { practiceStop(); practiceStart(); } else renderPractice(); };

$('lkPracApply').onclick = () => { if (applyCastProfile(false)) renderPractice(); };
$('lkPracForget').onclick = () => { if (confirm(`Forget your ${PRAC_MODE[pracMode()]} practice presses?`)) { pracLog = pracLog.filter(r => r.m !== pracMode() || cueKind(r) !== (L.audio ? 'a' : 'v')); store.set('hm64v29_lucky_castprac', pracLog); renderPractice(); } };
$('lkResetTally').onclick = () => { if (confirm('Clear the attempt log?')) { tally = []; store.set('hm64v29_lucky_tally', tally); renderTally(); } };
$('lkExport').onclick = () => {
  const blob = new Blob([JSON.stringify({ schema: 'hm64-v29-lucky', version: D.version, settings: L, tally }, null, 1)], { type: 'application/json' });
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `hm64_lucky_${new Date().toISOString().slice(0, 10)}.json`; a.click();
};
$('lkSprites').onclick = () => $('lkSpriteFile').click();
$('lkSpriteFile').onchange = e => {
  const f = e.target.files[0]; if (!f) return;
  f.text().then(t => { try { customSprites = JSON.parse(t); store.set('hm64v29_angler', customSprites); $('lkSpriteTxt').textContent = Object.keys(customSprites).length + ' frames loaded'; } catch (err) { $('lkSpriteTxt').textContent = 'not a JSON file'; } });
};
$('lkSpriteClear').onclick = () => {
  customSprites = {}; store.set('hm64v29_angler', {});
  L.figure = JACK && L.figure === 'stick' ? 'jack' : 'stick'; save(); figureTxt();
};
function figureTxt() {
  $('lkSpriteClear').textContent = JACK && L.figure !== 'stick' ? 'Use stick figure' : JACK ? 'Use Jack frames' : 'Stick figure';
  $('lkSpriteTxt').textContent = Object.keys(customSprites).length ? Object.keys(customSprites).length + ' own frames loaded'
    : JACK && L.figure !== 'stick' ? "Jack: your catalog's frames, game timing" : 'stick figure';
}
figureTxt();

/* ---------------------------------------------------------------- keyboard (only while this arena is shown) */
document.addEventListener('keydown', e => {
  if (root.HM64Arena !== 'lucky') return;
  if (capturing) { e.preventDefault(); L.startKey = e.key; capturing = false; save(); fillLSettings(); refresh(); return; }
  if ((e.target.tagName === 'INPUT' && e.target.type !== 'range') || document.querySelector('dialog[open]') || e.repeat) return;
  const k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
  if (run.practice) {                                           // practice owns the keys: start key = press, Esc = stop
    if (e.key === L.startKey) { practiceInput(evTime(e), keyName()); e.preventDefault(); return; }
    if (e.key === 'Escape') { practiceStop(); e.preventDefault(); return; }
    if (['h', 'm', 'e', 'p', '[', ']'].includes(k)) e.preventDefault();
    return;
  }
  if (e.key === L.startKey) {
    if (run.wall0 !== null && !run.preview && seqOpen((now() - run.wall0) / viMs() + 1)) {   // tap sequence (fade-in start)
      seqPress(evTime(e)); e.preventDefault(); return;
    }
    if (run.wall0 !== null && !run.preview) {
      const t = (now() - run.wall0) / viMs() + 1;
      if (isCastTap(t)) registerCast(t); else if (run.tapInfo) registerTap2(t); else registerTap(t);
      e.preventDefault(); return;
    }
    start(evTime(e)); e.preventDefault(); return;
  }
  if (e.key === 'Backspace' && run.tapInfo && run.tapInfo.tau2 != null && !run.tapInfo.saved) { run.tapInfo.tau2 = null; run.tapInfo.p2b = NaN; e.preventDefault(); return; }
  if (e.key === 'Backspace' && run.tapInfo && !run.tapInfo.saved) { run.tapInfo = null; e.preventDefault(); return; }
  if (e.key === 'Backspace' && run.castTap !== null && !run.tapInfo) { run.castTap = null; run.castErrMs = null; e.preventDefault(); return; }
  if (e.key === 'Escape') { stop(true); e.preventDefault(); return; }
  if (k === 's' && sparrowTable()) { setSparrows(route() !== sparrowTable().id); e.preventDefault(); return; }
  if (k === 'h') { record(true); e.preventDefault(); return; }
  if (k === 'm') { record(false, 'fish'); e.preventDefault(); return; }
  if (k === 'e') { record(false, 'empty'); e.preventDefault(); return; }
  if (k === 'p') { preview(); e.preventDefault(); return; }
  if (e.key === '[' || e.key === ']') { L.castT = Math.max(run.plan.firstT, Math.min(LuckyCore.TMAX, run.T + (e.key === '[' ? -2 : 2))); save(); refresh(); e.preventDefault(); }
}, true);

/* status line while the tap sequence is open */
function seqMsg(t) {
  const g = run.gp;
  if (!g || !g.cue || !(t < run.T - 90) || run.castTap !== null || run.tapInfo) return null;
  const sg = v => (v >= 0 ? '+' : '') + Math.round(v), cues = tapCues();
  if (g.cue.dock) {
    if (now() - g.cue.dock > 6000) return null;
    if (!g.g3) return ['Dock end ✓ — fitting your beach timing…', 'go'];
    if (g.g3.off) return ['Dock end tap fits none of the route timings: ignored', 'hold'];
    const gu = g.g3.guess, bands = gu ? `${gu.l1} ${Math.round(100 * gu.p1)}%${gu.sure2 ? ', 2nd cut ' + gu.l2.toLowerCase() + ' ' + Math.round(100 * gu.p2) + '%' : ''}`
      : (g.g3.bands || []).filter(x => x.p >= 0.05).map(x => `${x.label} ${Math.round(100 * x.p)}%`).join(' · ');
    return [`Dock end ✓ ${bands ? '— beach timing: ' + bands : ''}${g.g3.moved ? ` · cast moved ${sg((g.g3.T - g.g3.T0) * viMs())} ms (${pct(g.g3.p)})` : ` · cast stays (${pct(g.g3.p)})`}`, 'go'];
  }
  const last = Math.max(-1, ...cues.map((c, i) => (g.cue[c.id] != null ? i : -1))), next = cues[last + 1];
  const done = cues.filter(c => g.cue[c.id] != null).map(c => c.short + ' ✓').join(' · ') || 'tap ✓';
  return [next ? `${done} — next: ${next.short}` : done, 'go'];
}
/* ---------------------------------------------------------------- frame */
function frame() {
  if (root.HM64Arena === 'lucky') {
    const t = run.wall0 === null ? 0 : (now() - run.wall0) / viMs() + 1;
    const live = run.wall0 !== null;
    $('lkClock').textContent = live ? ((t - 1) * viMs() / 1000).toFixed(2) + ' s' : '0.00 s';
    $('lkStart').textContent = run.practice ? 'Stop practice (Esc)' : live ? 'Stop (Esc)' : `Start when ${doubleOn() ? 'the first tap cue (' + (clockCues()[0] || CUES[1]).short + ')' : startName()} (${keyName()})`;
    const [pose, u, info] = poseAt(t);
    const cv = $('lkAngler'), W = cv.width = cv.clientWidth * devicePixelRatio, H = cv.height = cv.clientHeight * devicePixelRatio;
    if (JACK && L.figure !== 'stick' && !Object.keys(customSprites).length) drawJackScene(cv.getContext('2d'), W, H, jackState(t), L.facing);
    else drawAngler(cv.getContext('2d'), W, H, pose, u, L.facing, info);
    const T = run.T;
    let msg = '', cls = '';
    if (!live) msg = run.result === 'nut' ? 'Power Nut! Logged.' : run.result === 'miss' ? 'Logged. Reset the console and go again.'
      : anchor() === 'dog' ? `Put the dog down: press ${keyName()} together with A.`
      : anchor() === 'fadein' ? `Tap ${keyName()} at: ${tapCues().map(c => c.short).join(', ')} (miss any one).`
      : anchor() === 'beach' ? `Press ${keyName()} when the beach appears.`
      : anchor() === 'pier' ? `Press ${keyName()} when Jack stops at the pier end.` : 'Get to READY, then press the start key.';
    else if (seqMsg(t)) { [msg, cls] = seqMsg(t); }
    else if (run.plan.k && t < run.plan.whistleEnd + 6) { msg = `Mash C-right — stop at whistle #${run.plan.k}`; cls = 'wh'; }
    else if (t < T) { msg = `Cast in ${((T - t) * viMs() / 1000).toFixed(1)} s`; cls = T - t < 90 ? 'go' : ''; }
    else if (t < T + G_CAST + 30) { msg = run.castTap !== null ? `Cast logged ${run.castErrMs >= 0 ? '+' : ''}${Math.round(run.castErrMs)} ms vs the CAST cue — listen for the plop` : `Cast! ${L.castTap ? 'Tap ' + keyName() + ' with B · ' : ''}listen for the plop (0.6 s)`; cls = 'go'; }
    else if (run.tapInfo && run.tapInfo.holdish) {                 // bite 1 held and tapped: the bite-2 forecast
      const ti = run.tapInfo, sp = spansTxt(ti.spans2), inSp = ti.spans2.some(([a, b]) => t >= a - 40 && t < b + 10);
      if (ti.tau2 != null) { msg = `Bite 2 at ${fmtS(ti.tau2)} was ${verdict(ti.p2b)} — H Nut · M fish · E empty line`; cls = ti.p2b >= 0.8 ? 'go' : 'hold'; }
      else if (!ti.fit) { msg = `Bite 1 at ${fmtS(ti.tau)} fits no dog path — release bite 2 anyway`; cls = 'hold'; }
      else if (ti.dud) { msg = `DUD: bite 2 can't be the Nut (${pct(ti.pNut)}) — reset now (M)`; cls = 'hold'; }
      else { msg = inSp ? `Nut-bite moment — release the instant bite 2 shows (Nut ${pct(ti.pNut)})` : `Bite 2 → Nut ${pct(ti.pNut)} if it bites at ${sp || '?'} · tap ${keyName()} at bite 2`; cls = 'go'; }
    }
    else if (run.pol === 'zone') { const zn = inZone(t); msg = run.tapInfo ? `Bite at ${fmtS(run.tapInfo.tau)} was ${verdict(run.tapInfo.p1)}` : (zn ? 'Bite now → RELEASE (tap it)' : `Bite now → HOLD and tap ${keyName()}`); cls = zn ? 'go' : 'hold'; }
    else if (run.pol === 'bite1') {
      const nb = nutBites().find(([a, b]) => t >= a - 40 && t < b + 10);
      msg = run.tapInfo ? `Bite at ${fmtS(run.tapInfo.tau)} was ${verdict(run.tapInfo.p1)} — H Nut · M fish · E empty line`
        : nb ? 'Nut-bite moment — release the instant it bites' : 'Release at the bite';
      cls = 'go';
    }
    else if (run.pol === 'tap' || run.pol === 'hold') {
      const ti = run.tapInfo;
      if (!ti) { msg = `Keep holding B · tap ${keyName()} when bite 1 shows · let go of B at bite 2`; cls = 'hold'; }
      else if (!ti.fit) { msg = `Bite at ${fmtS(ti.tau)} fits no dog path — release bite 2 anyway`; cls = 'hold'; }
      else if (ti.dud) { msg = `DUD (${pct(ti.pNut)}) — reset now (M)`; cls = 'hold'; }
      else { msg = `Bite 2 → Nut ${pct(ti.pNut)} · release at bite 2${ti.nutT2 ? ' (~' + fmtS(ti.nutT2) + ')' : ''}`; cls = 'go'; }
    }
    else { msg = 'Hold bite 1 · release bite 2'; cls = 'hold'; }   // (no policy left here)
    const tr = t - R0();
    if (live && (T - R0()) * viMs() > 37500 && tr * viMs() > 33000 && tr * viMs() < 38500 && t < T) { msg = 'Push the stick SOUTH-EAST now (stay awake)'; cls = 'wh'; }
    if (run.preview && live) {
      const pv = run.preview;
      msg = `Preview: ${info}`;
      cls = pose === 'catch' ? 'go' : pose === 'bite' ? (info.includes('HOLD') ? 'hold' : 'go') : '';
      if (pose === 'wait' || pose === 'zone') msg = `Preview: bite 1 at ${fmtS(pv.bite1)} → ${pv.release1 ? 'release' : 'hold, release bite 2 at ' + fmtS(pv.bite2)}`;
    }
    renderCue(t, msg);
    if (run.practice) {
      [msg, cls] = practiceMsg(t);
      if (!L.pracLine && run.practice.state === 'armed') $('lkClock').textContent = '·';
      if (navigator.getGamepads) for (const gp of navigator.getGamepads()) {   // any controller button = a press
        if (!gp) continue;
        const prev = run.practice.pads[gp.index] || [];
        gp.buttons.forEach((b, i) => { if (b.pressed && !prev[i]) practiceInput(gp.timestamp > 0 && gp.timestamp < 1e11 ? gp.timestamp : now(), 'controller'); });
        if (run.practice) run.practice.pads[gp.index] = gp.buttons.map(b => b.pressed);
      }
    }
    const el = $('lkStatus'); el.textContent = msg; el.className = 'lkstatus ' + cls;
    if (live && t > LuckyCore.TMAX + 600 && !run.preview && !run.practice) stop(false);
    drawTimeline(t);
  } else glowSet(0);
  requestAnimationFrame(frame);
}
/* ---------------------------------------------------------------- arena switch (footer) */
function setArena(a) {
  root.HM64Arena = a; store.set('hm64v29_arena', a);
  $('oracleArena').hidden = a === 'lucky'; $('luckyArena').hidden = a !== 'lucky';
  if (a === 'lucky') { const hp = $('histPop'); if (hp) hp.hidden = true; refresh(); } else { stop(true); glowSet(0); }
  $('arOracle').classList.toggle('on', a !== 'lucky'); $('arLucky').classList.toggle('on', a === 'lucky');
}
$('arOracle').onclick = () => setArena('oracle'); $('arLucky').onclick = () => setArena('lucky');
fillLSettings();
updateProfile();
setArena(store.get('hm64v29_arena', 'oracle'));
refresh();
requestAnimationFrame(frame);
root.HM64LuckyApp = { run, refresh, start, stop, record, preview, registerTap, registerCast, nutBites, L, get plans() { return plans; }, setSelection, paceRows,
                      seqPress, goal3, fadeStats, gapMs, dockStat, autoB, TEST, tapStats, clockSd, sigEffMs, setStrategy, setBeachCue, CUES, STRATS, tapCues, get fade2() { return fade2; }, get dock() { return dock; }, get taprec() { return tsGet(curTs()); }, precision, curTs, tsKeys, cullRec, clearSet, migrateTapRec, tsGet, setSparrows, baseOf, variantOf, cueAt, cueFlash, personalKernel, pkParts, personalTxt, sigStd, renderCue, cueCorr, sigmaMs, pressData, startDelay, get cueNow() { return run.cueNow; },
  practiceStart, practiceStop, practiceInput, practicePress, applyCastProfile, castStats, practiceMsg, get pracLog() { return pracLog; },
                      get tally() { return tally; }, routeDef,
                      drawAngler, drawJackScene, jackState,
                      get JACK() { return JACK; }, get prof() { return prof; }, get taps() { return taps; } };
})(typeof window !== 'undefined' ? window : globalThis);
