#!/usr/bin/env python3
"""
Stage I - how many keyboard logs, of which kind, until the runner's dog is known?

Data (stage O, emulator ground truth): for every arrival, what the runner can
see each VI for 80 s after READY (screen facing + ROM sprite class, i.e. the
same classes as Layer 1), and the hidden state behind it (absolute rand() draw
index, dog actionState / direction / stateTimer).

Simulated runner (Thomas's keyboard model):
- starts the clock with one animation+direction (AD) log of whatever the dog
  shows 0.5-3 s after READY;
- then logs later animations while they are on screen: a reaction delay after
  the change (U[10, 25] VIs, ~170-420 ms), never after the animation ended;
  animations shorter than MIN_RUN VIs are missed (too short to log);
- keypress/display jitter +-JITTER VIs on top; constant lag is unknown and
  absorbed by the unknown clock offset.
Strategies (what each later log carries):
  AD        animation + direction at every visible change
  D-turns   direction only (Space), only when the facing changes
  D-all     direction only (Space), at every visible change
  AD-every2 animation + direction at every second change (sparser logging)
Search (what the tool can assume): a candidate is (arrival, u) where u is the
arrival-time of the first log. Unanchored: u anywhere in 0-15 s (the tool does
not know when READY was). Anchored: the runner also tapped a key at READY, so u
is known to +-ANCHOR VIs. A candidate survives a log if, within +-JITTER VIs of
the log time, its dog shows that animation+direction (or direction).
Between logs anything may happen (unlogged animations are allowed).

"Known" levels after each log:
  path     every surviving candidate is on ONE world line (same dog + RNG path;
           copies entered at different times count as one)
  half_s / tenth_s / frame
           path known and the survivors' current RNG positions span at most
           30 / 6 / 2 draws (~1 draw per game frame): what is left for the
           clock-alignment step to close
  arrival  one arrival left (stricter than needed: copies need no telling apart)
Value of a log = bits of uncertainty about the PATH it removes (candidates
weighted by how many of the 36,014 measured routes reach each arrival).

  python3 tools/ident_sim.py results/campaign-observe
"""
from __future__ import annotations

import csv
import json
import math
import random
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

LINKS = ROOT / "data" / "routes" / "ROUTE_TO_CHECKPOINT_LINKS.csv"
OBS_WINDOW = 3600          # logs only during the first 60 s after READY
U_MAX = 900                # unanchored: first log anywhere 0-15 s after READY
ANCHOR = 10                # anchored: READY key known to +-10 VIs
JITTER = 2                 # keypress/display jitter (VIs)
MIN_RUN = 12               # animations shorter than 200 ms are not logged
REACT = (10, 25)           # reaction delay after a change (VIs)
START = (30, 180)          # first log 0.5-3 s after READY
# path known, and the survivors' current RNG positions span at most this many draws
# (~1 draw per game frame, 30 per second): "path" any, then +-0.5 s, +-0.1 s, +-1 frame
LEVELS = {"path": 10 ** 9, "half_s": 30, "tenth_s": 6, "frame": 2}
REPLICATES = 4
STRATEGIES = ("AD", "D-turns", "D-all", "AD-every2")
VI_S = 60.0


def load_jsonl(p):
    if not p.exists():
        return []
    return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]


# ---------------------------------------------------------------- data
def build(out):
    obs = {r["signature"]: r for r in load_jsonl(out / "O_observe.jsonl") if "_error" not in r}
    routes = [r for r in load_jsonl(out / "A_routes.jsonl") if "_error" not in r and r.get("outcome") == "ready"]
    anchor_of, count = {}, defaultdict(int)
    if LINKS.exists():
        with LINKS.open() as f:
            for r in csv.DictReader(f):
                anchor_of[r["label"]] = r["anchor_id"]
                count[r["anchor_id"]] += 1
    sig_anchors = defaultdict(set)
    for r in routes:
        sig_anchors[r["signature"]].add(anchor_of.get(r["label"], "label:" + r["label"]))
    share = defaultdict(int)
    for sig, an in sig_anchors.items():
        for a in an:
            share[a] += 1
    sigs = sorted(s for s in obs if s in sig_anchors)
    T = min(obs[s]["horizon"] for s in sigs)
    N = len(sigs)
    AD = np.full((N, T + 2), -1, np.int32)
    D = np.full((N, T + 2), -1, np.int16)
    DRAW = np.zeros((N, T + 2), np.int64)
    KEY = np.zeros((N, T + 2), np.int64)
    runs = []
    for i, s in enumerate(sigs):
        o = obs[s]
        for t0, t1, scr, cls, base in o["vis"]:
            a, b = max(t0, 1), min(t1, T + 1)
            if a < b:
                D[i, a:b] = scr
                AD[i, a:b] = -1 if cls is None else scr * 1000 + cls
        AD[i, 0], D[i, 0] = AD[i, 1], D[i, 1]
        DRAW[i, :] = o["draw0"]
        for t, d in o["draw"]:
            if t <= T + 1:
                DRAW[i, t:] = d
        dog = np.zeros((T + 2,), np.int64)
        for t, act, dr, tm in o["dog"]:
            if t <= T + 1:
                dog[t:] = act * 65536 + dr * 256 + tm
        KEY[i, :] = DRAW[i, :] * 16777216 + dog
        runs.append([r for r in o["vis"] if r[0] <= T])
    w = np.array([sum(count.get(a, 1) / share[a] for a in sig_anchors[s]) for s in sigs], float)
    wl = worldlines(sigs, obs)
    sigs_of_anchor = defaultdict(set)
    for sg in sigs:
        for a in sig_anchors[sg]:
            sigs_of_anchor[a].add(sg)
    split = sum(1 for a, ss in sigs_of_anchor.items() if len(ss) > 1)
    return {"sigs": sigs, "T": T, "AD": AD, "D": D, "DRAW": DRAW, "KEY": KEY, "w": w, "wl": np.array(wl),
            "anchors_total": len(sigs_of_anchor), "anchors_split": split,
            "runs": runs, "anchors": {s: sorted(sig_anchors[s]) for s in sigs}}


def worldlines(sigs, obs):
    """Union arrivals whose dog decisions agree at the same absolute RNG positions
    (= the same dog+RNG path entered at different times)."""
    ev = []
    for s in sigs:
        o = obs[s]
        draws = o["draw"]
        e, last = [], None
        j, d = 0, o["draw0"]
        for t, act, dr, tm in o["dog"]:
            while j < len(draws) and draws[j][0] <= t:
                d = draws[j][1]
                j += 1
            if (act, dr) != last:
                e.append((d, act, dr))
                last = (act, dr)
        ev.append(e)
    parent = list(range(len(sigs)))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    for i in range(len(sigs)):
        for k in range(i + 1, len(sigs)):
            if find(i) == find(k):
                continue
            a, b = ev[i], ev[k]
            if not a or not b:
                continue
            lo, hi = max(a[0][0], b[0][0]), min(a[-1][0], b[-1][0])
            ea = [x for x in a[1:] if lo <= x[0] <= hi]      # a[0] is the state at READY, not a decision
            eb = [x for x in b[1:] if lo <= x[0] <= hi]
            if len(ea) >= 3 and ea == eb:
                parent[find(k)] = find(i)
    return [find(i) for i in range(len(sigs))]


# ---------------------------------------------------------------- runner
READY_LOG = (10, 40)       # "ready_log" search: the first AD log is made right at READY (0.17-0.67 s later)
READY_LOG_U = 45           # ... so the tool knows the first log was within 0.75 s of READY
MODES = ("unanchored", "anchored", "ready_log")


def make_logs(runs, strategy, rnd, start=START):
    """[(t, kind, value)] in the true arrival's VIs; kind 'AD' (value scr*1000+cls) or 'D' (value scr)."""
    t_start = rnd.randint(*start)
    first = next((r for r in runs if r[0] <= t_start < r[1] and r[3] is not None), None)
    if first is None:
        first = next((r for r in runs if r[0] >= t_start and r[3] is not None and r[1] - r[0] >= MIN_RUN), None)
        if first is None:
            return []
        t_start = first[0] + min(rnd.randint(*REACT), first[1] - first[0] - 1)
    logs = [(t_start, "AD", first[2] * 1000 + first[3])]
    prev_scr, n_change = first[2], 0
    for t0, t1, scr, cls, base in runs:
        if t0 <= t_start:
            continue
        if t0 > OBS_WINDOW:
            break
        turned = scr != prev_scr
        prev_scr = scr
        n_change += 1
        if t1 - t0 < MIN_RUN or cls is None:
            continue
        t = t0 + min(rnd.randint(*REACT), t1 - t0 - 1)
        if strategy == "AD":
            logs.append((t, "AD", scr * 1000 + cls))
        elif strategy == "AD-every2":
            if n_change % 2 == 0:
                logs.append((t, "AD", scr * 1000 + cls))
        elif strategy == "D-all":
            logs.append((t, "D", scr))
        elif strategy == "D-turns":
            if turned:
                logs.append((t, "D", scr))
    return logs


class Indicator:
    """Cached 'arrival shows this value within +-JITTER VIs of t' matrices."""

    def __init__(self, data):
        self.d, self.cache = data, {}

    def get(self, kind, value):
        k = (kind, value)
        m = self.cache.get(k)
        if m is None:
            src = self.d["AD"] if kind == "AD" else self.d["D"]
            hit = (src == value).astype(np.int32)
            c = np.concatenate([np.zeros((hit.shape[0], JITTER + 1), np.int32),
                                np.cumsum(hit, axis=1, dtype=np.int32),
                                np.repeat(np.cumsum(hit, axis=1, dtype=np.int32)[:, -1:], JITTER, axis=1)], axis=1)
            n = hit.shape[1]
            m = (c[:, 2 * JITTER + 1:2 * JITTER + 1 + n] - c[:, 0:n]) > 0
            if len(self.cache) > 400:
                self.cache.clear()
            self.cache[k] = m
        return m


def simulate(data, ind, true_i, strategy, anchored, rnd):
    mode = anchored if isinstance(anchored, str) else ("anchored" if anchored else "unanchored")
    logs = make_logs(data["runs"][true_i], strategy, rnd, READY_LOG if mode == "ready_log" else START)
    if not logs:
        return None
    t1 = logs[0][0]
    T = data["T"]
    if mode == "anchored":
        lo, hi = max(1, t1 - ANCHOR), t1 + ANCHOR
    elif mode == "ready_log":
        lo, hi = 1, READY_LOG_U
    else:
        lo, hi = 1, U_MAX
    hi = min(hi, T + 1 - (logs[-1][0] - t1))
    if hi < lo or not (lo <= t1 <= hi):
        return None
    us = np.arange(lo, hi + 1)
    V = np.ones((len(data["sigs"]), len(us)), bool)
    w = data["w"]
    res = {"logs": [], "arrival": None, **{lvl: None for lvl in LEVELS}}
    for k, (t, kind, value) in enumerate(logs):
        dlt = t - t1
        V &= ind.get(kind, value)[:, us + dlt]
        ai, ui = np.nonzero(V)
        tc = us[ui] + dlt
        mass = w[ai]
        p = mass / mass.sum()
        H = float(-(p * np.log2(p)).sum())                      # bits over (arrival, u) candidates
        wl_ids, inv = np.unique(data["wl"][ai], return_inverse=True)
        pw = np.bincount(inv, weights=p)
        Hp = float(-(pw[pw > 0] * np.log2(pw[pw > 0])).sum())   # bits over dog paths only
        draws = data["DRAW"][ai, tc]
        n_arr = len(np.unique(ai))
        width = int(draws.max() - draws.min())
        step = {"k": k + 1, "t": int(t), "kind": kind, "cands": int(len(ai)), "arrivals": n_arr,
                "paths": int(len(wl_ids)), "width": width, "bits": round(H, 3), "path_bits": round(Hp, 3)}
        res["logs"].append(step)
        for lvl, lim in LEVELS.items():
            if res[lvl] is None and len(wl_ids) == 1 and width <= lim:
                res[lvl] = step
        if res["arrival"] is None and n_arr == 1:
            res["arrival"] = step
        if all(res[lvl] is not None for lvl in LEVELS):
            break
    return res


def pct(xs, q):
    xs = sorted(xs)
    return xs[min(len(xs) - 1, int(q * (len(xs) - 1) + 0.5))] if xs else None


def run(out: Path):
    out = Path(out)
    data = build(out)
    n = len(data["sigs"])
    if n < 2:
        print("[I ident] needs O_observe.jsonl with 2+ arrivals; skipped", flush=True)
        return
    ind = Indicator(data)
    rnd = random.Random(2026)
    w = data["w"]
    rows, curves = [], defaultdict(list)
    for anchored in MODES:
        for strat in STRATEGIES:
            for i in range(n):
                for rep in range(REPLICATES):
                    r = simulate(data, ind, i, strat, anchored, rnd)
                    if r is None:
                        continue
                    row = {"signature": data["sigs"][i], "weight": float(w[i]), "search": anchored,
                           "strategy": strat, "rep": rep, "logs_made": len(r["logs"])}
                    for lvl in (*LEVELS, "arrival"):
                        st = r[lvl]
                        row[f"{lvl}_logs"] = st and st["k"]
                        row[f"{lvl}_s"] = st and round(st["t"] / VI_S, 2)
                    row["bits_start"] = r["logs"][0]["bits"]
                    row["path_bits_start"] = r["logs"][0]["path_bits"]
                    row["width_when_path_s"] = r["path"] and round(r["path"]["width"] / 30.0, 2)
                    rows.append(row)
                    for st in r["logs"]:
                        curves[(anchored, strat, st["k"])].append((float(w[i]), st["bits"], st["paths"], st["cands"],
                                                                  st["kind"], st["path_bits"]))
    with (out / "ident_runs.csv").open("w", newline="") as f:
        wr = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        wr.writeheader()
        wr.writerows(rows)
    # curves: weighted mean bits left and fraction with one path, per log number
    cv = []
    for (anch, strat, k), xs in sorted(curves.items()):
        W = sum(x[0] for x in xs)
        cv.append({"anchored": anch, "strategy": strat, "log": k, "runs": len(xs),
                   "bits_left": round(sum(x[0] * x[1] for x in xs) / W, 3),
                   "path_bits_left": round(sum(x[0] * x[5] for x in xs) / W, 3),
                   "one_path": round(sum(x[0] for x in xs if x[2] == 1) / W, 3),
                   "candidates_median": pct([x[3] for x in xs], 0.5)})
    with (out / "ident_curves.csv").open("w", newline="") as f:
        wr = csv.DictWriter(f, fieldnames=list(cv[0].keys()))
        wr.writeheader()
        wr.writerows(cv)

    def summary(anch, strat):
        rs = [r for r in rows if r["search"] == anch and r["strategy"] == strat]
        W = sum(r["weight"] for r in rs)
        out_ = {"runs": len(rs)}
        for lvl in (*LEVELS, "arrival"):
            ok = [r for r in rs if r[f"{lvl}_logs"]]
            out_[lvl] = {"share": round(sum(r["weight"] for r in ok) / W, 3) if W else 0,
                         "logs_med": pct([r[f"{lvl}_logs"] for r in ok], 0.5),
                         "logs_p90": pct([r[f"{lvl}_logs"] for r in ok], 0.9),
                         "s_med": pct([r[f"{lvl}_s"] for r in ok], 0.5),
                         "s_p90": pct([r[f"{lvl}_s"] for r in ok], 0.9)}
        # bits removed per later log of each kind (first 8 logs after the start log)
        c = {x["log"]: x for x in cv if x["anchored"] == anch and x["strategy"] == strat}
        pb = [c[k]["path_bits_left"] if k in c else 0.0 for k in range(1, 6)]
        out_["path_bits_after_start_log"] = pb[0]
        out_["path_bits_removed_per_log_2to5"] = round((pb[0] - pb[4]) / 4, 2)
        out_["path_bits_removed_by_log_2"] = round(pb[0] - pb[1], 2)
        wp = [r["width_when_path_s"] for r in rs if r["width_when_path_s"] is not None]
        out_["time_width_when_path_known_s_med"] = pct(wp, 0.5)
        return out_

    summ = {"arrivals": n, "paths": int(len(np.unique(data["wl"]))), "routes_weighted": float(w.sum()),
            "anchors": data["anchors_total"], "anchors_with_more_than_one_arrival": data["anchors_split"],
            "settings": {"window_s": OBS_WINDOW / VI_S, "u_max_s": U_MAX / VI_S, "anchor_vi": ANCHOR,
                         "jitter_vi": JITTER, "min_run_vi": MIN_RUN, "react_vi": REACT, "levels_draws": LEVELS,
                         "replicates": REPLICATES},
            "table": {f"{a}/{s}": summary(a, s) for a in MODES for s in STRATEGIES}}
    (out / "ident_summary.json").write_text(json.dumps(summ, indent=1))
    L = ["## Observation study (stage I)\n",
         f"{n} arrivals from {summ['anchors']} Layer 1 anchors ({summ['anchors_with_more_than_one_arrival']} anchors "
         f"reached more than one arrival), {summ['paths']} distinct dog paths, weighted by the 36,014 measured "
         "routes. Runner logs "
         f"what is on screen during the first {OBS_WINDOW / VI_S:.0f} s (reaction {REACT[0]}-{REACT[1]} VIs after "
         f"each change, +-{JITTER} VI jitter, animations < {MIN_RUN} VIs missed), {REPLICATES} simulated runners "
         "per arrival; the first log is 0.5-3 s after READY. Logs counted include the start log. Each cell: share of runners (route-weighted) reaching "
         "it within 60 s / logs needed median (p90) / seconds after READY median (p90).\n",
         "- *path*: one dog/RNG path left (arrivals that are the same path entered at different times count once)",
         "- *+-0.5 s*, *+-0.1 s*, *+-1 frame*: path known and the RNG position pinned that tightly (~1 draw per game "
         "frame) - the remainder is what the clock alignment step has to close",
         "- *path bits*: uncertainty about WHICH path (log2 of the effective number of paths); removed per later log "
         "is the selectivity of that kind of log\n",
         "| search | strategy | path | +-0.5 s | +-0.1 s | +-1 frame | path bits after start log | path bits removed "
         "by log 2 / per log (2-5) | time spread when path known (s) |",
         "|---|---|---|---|---|---|---|---|---|"]

    def cell(x):
        if not x["logs_med"]:
            return f"{x['share']:.0%} / - / -"
        return f"{x['share']:.0%} / {x['logs_med']} ({x['logs_p90']}) / {x['s_med']} ({x['s_p90']})"
    for key, v in summ["table"].items():
        a, s = key.split("/")
        L.append(f"| {a} | {s} | {cell(v['path'])} | {cell(v['half_s'])} | {cell(v['tenth_s'])} | "
                 f"{cell(v['frame'])} | {v['path_bits_after_start_log']} | {v['path_bits_removed_by_log_2']} / "
                 f"{v['path_bits_removed_per_log_2to5']} | {v['time_width_when_path_known_s_med']} |")
    L.append("\nFiles: `ident_runs.csv` (one row per simulated runner), `ident_curves.csv` (bits left and "
             "share with one path after each log), `ident_summary.json`.")
    text = "\n".join(L) + "\n"
    (out / "IDENT.md").write_text(text)
    rep = out / "REPORT.md"
    body = rep.read_text() if rep.exists() else "# HM64 observation study\n\n"
    cut = body.find("## Observation study (stage I)")
    if cut >= 0:
        body = body[:cut].rstrip() + "\n\n"
    rep.write_text(body + text)
    print(text, flush=True)


if __name__ == "__main__":
    run(Path(sys.argv[1]))
