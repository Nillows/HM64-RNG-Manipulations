"""
Extra Lucky Timer routes: a cast table recorded on another route/save, packed for the web app.

  python3 -I tools/route_tables.py CASTTABLE.json --id nodog-nohorse-no-pickup --label "..." \
      [--anchor beach:"beach entry":328] [--anchor pier:"READY (pier end)":0] --out webapp/assets/lucky_routes.json

CASTTABLE.json = {"save", "route", "time_basis", "casts": [eval_cast rows, K_casts shape: cast (poll after READY),
status, bite_poll, bites [{bite_poll, nut}, ...]]} - one dog line, times in polls after that route's READY.
The table is packed exactly like the main dog paths (tools/export_webapp.path_casts: poll c is read during VI c+1;
odd polls stay unknown unless the game-frame pairing was measured). An anchor "id:label:r0" says where READY sits on
that anchor's stopwatch (VI after the start event): path VI = t - r0, first possible cast t = r0 + 1.
The output file holds a list of routes; an existing entry with the same id is replaced.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from tools.export_webapp import path_casts  # noqa: E402


def records(rows):
    """{cast_poll: (n1, b1_poll, n2, b2_poll)} like export_webapp.cast_records (no whistles, status ok)."""
    out = {}
    for r in rows:
        if "_error" in r or r.get("whistles") or r.get("status") != "ok" or r.get("bite_poll") is None:
            continue
        bites = r.get("bites") or [{"bite_poll": r["bite_poll"],
                                    "nut": bool(r.get("nut_releases")) or "nut" in (r.get("probes") or {}).values()}]
        b1 = bites[0]
        b2 = bites[1] if len(bites) > 1 and bites[1].get("bite_poll") is not None else None
        out[int(r["cast"])] = (int(bool(b1["nut"])), int(b1["bite_poll"]),
                               None if b2 is None else int(bool(b2["nut"])), None if b2 is None else int(b2["bite_poll"]))
    return out


def build(path, rid, label, anchors, note=""):
    raw = Path(path).read_bytes()
    d = json.loads(raw)
    rec = records(d["casts"])
    sig = "route:" + rid
    casts, conflicts, _ = path_casts([{"id": 0}], [[0, 0, 1.0, sig]], {sig: rec})
    c = casts[0]
    if c is None:
        raise SystemExit("no usable casts in " + str(path))
    polls = sorted(rec)
    return {
        "id": rid, "label": label, "note": note,
        "save": d.get("save"), "route": d.get("route"), "basis": d.get("time_basis"),
        "source": {"file": Path(path).name, "sha256": hashlib.sha256(raw).hexdigest(), "casts": len(rec),
                   "polls": [polls[0], polls[-1]], "nut1": sum(v[0] for v in rec.values()),
                   "nut2": sum(1 for v in rec.values() if v[2])},
        "casts": c,
        "anchors": [{"id": a, "label": lab, "r0": int(r0)} for a, lab, r0 in anchors],
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("table")
    ap.add_argument("--id", required=True)
    ap.add_argument("--label", required=True)
    ap.add_argument("--note", default="")
    ap.add_argument("--anchor", action="append", default=[], help='id:label:r0 (VI from the start event to READY)')
    ap.add_argument("--out", default=str(ROOT / "webapp" / "assets" / "lucky_routes.json"))
    a = ap.parse_args()
    anchors = []
    for s in a.anchor or ["ready:READY:0"]:
        aid, lab, r0 = s.split(":")
        anchors.append((aid, lab, r0))
    entry = build(a.table, a.id, a.label, anchors, a.note)
    out = Path(a.out)
    routes = json.loads(out.read_text())["routes"] if out.exists() else []
    routes = [r for r in routes if r["id"] != entry["id"]] + [entry]
    out.write_text(json.dumps({"routes": routes}, separators=(",", ":")))
    s, c = entry["source"], entry["casts"]
    print(f"{entry['id']}: {s['casts']} casts (polls {s['polls'][0]}..{s['polls'][1]}), Nut bite 1 {s['nut1']}, "
          f"bite 2 {s['nut2']}; packed VI {c['lo']}..{c['lo'] + len(c['n1'])} parity {c['parity']} "
          f"wins {c['wins1']}/{c['wins2']} -> {out} ({out.stat().st_size // 1024} KB)")


if __name__ == "__main__":
    main()
