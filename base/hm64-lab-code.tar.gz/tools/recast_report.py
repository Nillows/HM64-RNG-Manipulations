"""
Recast pilot report: results/recast/<tag>/RC_rel.jsonl + RC_src.jsonl -> RECAST.md + rc_summary.json.

  python3 tools/recast_report.py --out results/recast/<tag> [--fd results/fullday/d90]

Questions answered (experiments/recast_jobs.py has the game facts):
  1  after a CATCH: do the dog and the random numbers depend on what is done with the fish, and when?
  2  after an EMPTY release: is every release frame its own path? how long do neighbours look alike?
  3  second casts: how often is a Nut there, by source and by time; what a known state is worth
  4  what a full lab would cost
"""
from __future__ import annotations

import argparse
import json
import math
import statistics as S
import sys
from collections import Counter, defaultdict
from pathlib import Path

VI = 16.715 / 1000
SIG = 150 / 16.715            # the app's standard B spread, in VIs


def load(p):
    out = []
    if Path(p).exists():
        for line in open(p):
            try:
                out.append(json.loads(line))
            except ValueError:
                pass
    return out


def codes(d):
    """delta list [k0, code, dk, code, ...] -> [(k, code)] absolute."""
    out, k = [], 0
    for i in range(0, len(d), 2):
        k = d[i] if i == 0 else k + d[i]
        out.append((k, d[i + 1]))
    return out


def at(seq, k):
    cur = None
    for kk, c in seq:
        if kk > k:
            break
        cur = c
    return cur


def first_diff(a, b, lo, hi):
    """First label in [lo, hi) where the two dogs show different things; None = the same throughout."""
    ks = sorted({k for k, _ in a + b if lo <= k < hi} | {lo})
    for k in ks:
        if at(a, k) != at(b, k):
            return k
    return None


def pct(x, n):
    return f"{100 * x / n:.1f}%" if n else "-"


def q(v, p):
    v = sorted(v)
    return v[min(len(v) - 1, int(p * len(v)))] if v else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--fd", default=None, help="full-day results (FD1_lines.jsonl) to check the cast states against")
    args = ap.parse_args()
    out = Path(args.out)
    setup = json.load(open(out / "rc_setup.json")) if (out / "rc_setup.json").exists() else {}
    rel_all, src_all = load(out / "RC_rel.jsonl"), load(out / "RC_src.jsonl")
    bad = [r for r in rel_all + src_all if "_error" in r or "error" in r]
    rel = [r for r in rel_all if "empty" in r]
    src = [r for r in src_all if "rc" in r or "skip" in r]
    L = []
    P = L.append
    summ = {"code": setup.get("code"), "rel_jobs": len(rel), "src_jobs": len(src), "errors": len(bad)}
    P(f"# Recast pilot — {setup.get('code', '?')}\n")
    P(f"{len(setup.get('lines', []))} dog lines ({sum(w for _, w in setup.get('lines', [])):.0%} of the route weight) × cast frames "
      f"{setup.get('casts')} (VIs after READY); {len(rel)} hold jobs, {len(src)} second-cast jobs, **{len(bad)} errors**.")
    for r in bad[:6]:
        P(f"- error: `{str(r.get('_error') or r.get('error'))[-200:]}` ({(r.get('_job') or r).get('tag')})")
    # same paths as the full-day run?
    if args.fd and (Path(args.fd) / "FD1_lines.jsonl").exists():
        fd = {r["key"]: r for r in load(Path(args.fd) / "FD1_lines.jsonl") if r.get("ok")}
        same = diff = 0
        for r in rel:
            f = fd.get(r["key"])
            if not f:
                continue
            i, rem = divmod(r["k"] - f["h0"], f["step"])
            if rem or not 0 <= i < len(f["hs"]):
                continue
            if f["hs"][i] == r.get("cast_hash"):
                same += 1
            else:
                diff += 1
        P(f"\nCast states against the full-day run ({args.fd}): **{same} equal, {diff} different**.")
        summ["fd_same"], summ["fd_diff"] = same, diff

    # ------------------------------------------------------------------ 1 catches
    P("\n## 1 · After a catch: does it matter what is done with the fish?\n")
    nb = 0
    var = defaultdict(lambda: {"n": 0, "same": 0, "free": [], "first": []})
    got = Counter()
    for r in rel:
        for b in r.get("bite", []):
            nb += 1
            ref = b["v"][0]
            got[ref["got"]] += 1
            for v in b["v"]:
                name = f"B up {v['off']} polls in" + (f", {v['btn']} at +{v['at'] * VI:.1f} s" if v["btn"] else ", fish kept in hand")
                a = var[name]
                a["n"] += 1
                m = min(len(v["hs"]), len(ref["hs"]))
                d = next((i for i in range(m) if v["hs"][i] != ref["hs"][i]), None)
                if d is None and m:
                    a["same"] += 1
                elif d is not None:
                    a["first"].append((d + 1) * 30)
                if v["free"] is not None:
                    a["free"].append(v["free"])
    P(f"{nb} bites caught ({dict(got)}; N = Nut, s / m / l = fish). Each replayed with the fish handled six ways and "
      f"followed {setup.get('post', 1200) * VI:.0f} s; \"same\" = the dog-line hash (random number + the dog's whole record) "
      f"equal to the first row's at every 0.5 s.\n")
    P("| what was done | bites | dog + RNG the same all the way | hands free after (median) |")
    P("|---|---|---|---|")
    s1 = {}
    for name, a in var.items():
        fr = f"{S.median(a['free']) * VI:.2f} s" if a["free"] else "never (fish still in hand)"
        extra = f" (first difference {min(a['first']) * VI:.1f} s after the bite)" if a["first"] else ""
        P(f"| {name} | {a['n']} | {a['same']} of {a['n']}{extra} | {fr} |")
        s1[name] = [a["same"], a["n"]]
    summ["catch_variants"] = s1
    allsame = all(a["same"] == a["n"] for a in var.values()) and nb > 0
    P("\n" + ("**Yes on every bite: after a catch the dog and the random numbers do not depend on the fish or on the time "
              "taken with it.** A catch at a known bite is one known state, however long the player takes."
              if allsame else "**Not the same on every bite — see the rows above before building on catches.**"))

    # ------------------------------------------------------------------ 2 empty releases
    P("\n## 2 · After an empty release (B let go between bites)\n")
    free, ph = [], Counter()
    blocks = distinct = 0
    nd, merged = [], 0
    odd_same = odd_n = 0
    allh = defaultdict(set)
    for r in rel:
        byg = defaultdict(list)
        for e in r["empty"]:
            ph[e["ph"]] += 1
            if e["free"] is not None and e["got"] is None:
                free.append(e["free"])
            byg[e["g"]].append(e)
            if e["got"] is None and e["hs"] and e["g"] != "odd":
                allh[(e["hs"][-1])].add((r["key"], r["k"], e["r"]))
        for g in ("d1", "d2"):
            es = [e for e in sorted(byg[g], key=lambda e: e["r"]) if e["got"] is None and e["ph"] == 2]
            if len(es) < 2:
                continue
            blocks += 1
            ends = Counter(e["hs"][-1] for e in es if e["hs"])
            distinct += len(ends) / len(es)
            for a, b in zip(es, es[1:]):
                if b["r"] - a["r"] != 2:
                    continue
                lo = b["r"] + 36
                d = first_diff(codes(a["d"]), codes(b["d"]), lo, b["r"] + setup.get("post", 1200))
                nd.append(None if d is None else d - b["r"])
                if a["hs"] and a["hs"][-1] == b["hs"][-1]:
                    merged += 1
        if byg["odd"] and byg["d1"]:
            d1 = {e["r"]: e for e in byg["d1"]}
            for e in byg["odd"]:
                odd_n += 1
                if any(n in d1 and d1[n]["hs"] == e["hs"] for n in (e["r"] - 1, e["r"] + 1)):
                    odd_same += 1
    coll = sum(1 for v in allh.values() if len(v) > 1)
    seen = [d for d in nd if d is not None]
    P(f"{sum(ph.values())} releases; fishing phase when B came up: {dict(ph)} (2 = float out; 3-5 = inside a bite: that one "
      f"is a catch). Jack can act again {S.median(free) * VI:.2f} s after an empty release (median).\n" if free else "no data\n")
    if blocks:
        P(f"- Blocks of consecutive game frames ({blocks} blocks): on average **{distinct / blocks:.0%} of the release frames "
          f"end on their own path** (dog-line hash {setup.get('post', 1200) * VI:.0f} s later); neighbours ending on the same "
          f"path: {merged} of {len(nd)} pairs.")
        if seen:
            P(f"- Two releases one game frame apart: the dogs look the same for {q(seen, .1) * VI:.1f} / {q(seen, .5) * VI:.1f} / "
              f"{q(seen, .9) * VI:.1f} s after the release (10% / median / 90%), then differ; "
              f"{len(nd) - len(seen)} of {len(nd)} pairs never differed on screen in the time followed.")
        P(f"- A release on an odd VI label is the same as one of its even neighbours: {odd_same} of {odd_n}.")
        P(f"- Different releases (any line, cast or frame) that ended in the same state: {coll} states shared, of {len(allh)}.")
    summ["empty"] = {"blocks": blocks, "own_path": distinct / blocks if blocks else None, "pairs": len(nd),
                     "pairs_merged": merged, "shared_states": coll, "states": len(allh)}

    # ------------------------------------------------------------------ 3 second casts
    P("\n## 3 · Second casts\n")
    by = defaultdict(list)
    skips = Counter()
    alt_same = alt_n = 0
    tot_rc = tot_secs = 0
    for r in src:
        name = "after a catch at bite %d" % (r["src"]["i"] + 1) if r["src"]["t"] == "bite" else \
            "after an empty release %.0f s after the float landed" % (r["src"]["dr"] * VI)
        if "skip" in r:
            skips[(name, r["skip"].split(" at ")[0].split(" (")[0])] += 1
            continue
        by[name].append(r)
        tot_rc += len(r["rc"])
        tot_secs += r.get("rc_secs", 0)
        main = {c: b for c, b, _ in r["rc"]}
        for c, b in r.get("alt", []):
            if c in main:
                alt_n += 1
                alt_same += main[c] == b
    P("From each source one second cast per game frame, from the first frame Jack can cast, each held to its 2nd bite with "
      "a release at every bite. \"Best cast\" = the best second cast of a source when its state is known and B is pressed "
      "with the app's ±150 ms spread (Nut on bite 1 or 2).\n")
    P("| source | sources | second casts | Nut on bite 1 | Nut on bite 2 | Nut on either | best cast: median source | best cast: mean | sources with no Nut at all |")
    P("|---|---|---|---|---|---|---|---|---|")
    bins = defaultdict(lambda: [0, 0])
    s3 = {}
    for name, rs in by.items():
        n = n1 = n2 = 0
        best, none = [], 0
        for r in rs:
            hit = []
            for c, b, _ in r["rc"]:
                o = [x[1] for x in b[:2]]
                h1, h2 = (len(o) > 0 and o[0] == "N"), (len(o) > 1 and o[1] == "N")
                n += 1
                n1 += h1
                n2 += h2
                hit.append((c, 1.0 if (h1 or h2) else 0.0))
                bn = int(c * VI // 15) * 15
                bins[bn][0] += 1
                bins[bn][1] += (h1 or h2)
            if not any(h for _, h in hit):
                none += 1
                best.append(0.0)
                continue
            m = 0.0
            for c, _ in hit:                                # P(Nut) aiming at frame c with a Gaussian B spread
                wsum = psum = 0.0
                for c2, h in hit:
                    wgt = math.exp(-0.5 * ((c2 - c) / SIG) ** 2)
                    wsum += wgt
                    psum += wgt * h
                # frames outside the tested window count as no Nut
                full = SIG * math.sqrt(2 * math.pi) / setup.get("step", 2)
                m = max(m, psum / max(wsum, full))
            best.append(m)
        P(f"| {name} | {len(rs)} | {n} | {pct(n1, n)} | {pct(n2, n)} | {pct(n1 + n2, n)} | {100 * S.median(best):.1f}% | "
          f"{100 * S.mean(best):.1f}% | {none} of {len(rs)} |")
        s3[name] = {"sources": len(rs), "casts": n, "nut1": n1, "nut2": n2, "best_median": S.median(best), "best_mean": S.mean(best), "none": none}
    summ["recast"] = s3
    for (name, why), c in sorted(skips.items()):
        P(f"- not used: {c} × {name}: {why}" + (" (that bite was the Nut)" if why == "nut" else ""))
    if alt_n:
        P(f"\nSecond casts after STORING the fish (C-up) instead of throwing it, same cast frame: **{alt_same} of {alt_n} gave the "
          f"same bites and catches.**")
        summ["alt"] = [alt_same, alt_n]
    if bins:
        P("\nBy when the second cast is made (seconds after READY):\n")
        P("| second cast at | second casts | Nut on bite 1 or 2 |")
        P("|---|---|---|")
        for bn in sorted(bins):
            P(f"| {bn}-{bn + 15} s | {bins[bn][0]} | {pct(bins[bn][1], bins[bn][0])} |")
        summ["by_time"] = {str(k): v for k, v in sorted(bins.items())}

    # ------------------------------------------------------------------ 4 cost
    P("\n## 4 · What a full lab would cost\n")
    tm = load(out / "rc_times.jsonl")
    w = setup.get("workers") or 1
    if tot_rc and tot_secs:
        per = tot_secs / tot_rc
        P(f"{tot_rc} second casts took {tot_secs / 3600:.2f} worker-hours: **{per:.2f} s per second cast per worker** "
          f"({w} workers here).")
        for label, states in (("every bite state of the 90-s data (6,019)", 6019), ("the 1,000 heaviest bite states", 1000)):
            for nfr, txt in ((360, "12 s of cast frames"), (180, "6 s")):
                P(f"- {label} × {txt}: {states * nfr:,} second casts ≈ {states * nfr * per / w / 3600:.1f} h with {w} workers")
        summ["secs_per_recast"] = per
    if tm:
        P(f"\nWall time of this pilot: holds {sum(t['rel_wall'] for t in tm) / 60:.0f} min, second casts {sum(t['src_wall'] for t in tm) / 60:.0f} min.")
    (out / "RECAST.md").write_text("\n".join(L) + "\n")
    json.dump(summ, open(out / "rc_summary.json", "w"), indent=1)
    print("\n".join(L))
    return 0


if __name__ == "__main__":
    sys.exit(main())
