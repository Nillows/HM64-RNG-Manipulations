#!/usr/bin/env python3
"""
Run HM64 from a savestate and log one row per VI.

  python3 tools/trace.py --state states/anchor.st --vis 3000 --out results/idle.csv
  python3 tools/trace.py --state states/anchor.st --vis 1200 \
      --inputs '[{"at":30,"press":["CR"],"hold":2}]' --out results/whistle1.csv
  python3 tools/trace.py --state states/anchor.st --poke-index 1500 --vis 900 --out r.csv

--inputs: JSON list (or @file.json). Each item: {"at": VI offset from start,
  "press": [buttons], "hold": VIs held (default 2), "x": stick, "y": stick}.
--poke-index N: overwrite the RNG seed with step^N(0) right after loading.
Columns: see hm64.state.snapshot; plus `calls` = rand() calls during that VI.
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from m64h import Emulator                     # noqa: E402
from hm64 import addresses as A               # noqa: E402
from hm64.lcg import seed_at                  # noqa: E402
from hm64.state import snapshot               # noqa: E402
from tools.common import default_rom, default_sram  # noqa: E402


def parse_inputs(spec: str | None):
    if not spec:
        return []
    if spec.startswith("@"):
        spec = Path(spec[1:]).read_text()
    return sorted(json.loads(spec), key=lambda e: e["at"])


def run_trace(emu, vis: int, inputs=(), every: int = 1):
    """Advance `vis` VIs applying `inputs`; return list of snapshot dicts."""
    rows = []
    start = emu.vi
    prev_idx = snapshot(emu)["idx"]
    events = list(inputs)
    release_at = None
    for k in range(vis):
        off = emu.vi - start
        if release_at is not None and off >= release_at:
            emu.release(); release_at = None
        while events and events[0]["at"] <= off:
            e = events.pop(0)
            emu.set_input(*e.get("press", []), x=e.get("x", 0), y=e.get("y", 0))
            release_at = off + e.get("hold", 2)
        emu.advance(1)
        snap = snapshot(emu)
        snap["calls"] = snap["idx"] - prev_idx
        prev_idx = snap["idx"]
        if k % every == 0:
            rows.append(snap)
    emu.release()
    return rows


def write_csv(rows, out: Path):
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--rom", default=default_rom())
    ap.add_argument("--sram", default=default_sram())
    ap.add_argument("--state", required=True)
    ap.add_argument("--vis", type=int, default=600)
    ap.add_argument("--inputs")
    ap.add_argument("--poke-index", type=int)
    ap.add_argument("--every", type=int, default=1)
    ap.add_argument("--mode", choices=["fast", "visual"], default="fast",
                    help="visual needs a display: run under xvfb-run")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    with Emulator(a.rom, sram=a.sram, mode=a.mode) as emu:
        emu.load_state(a.state)
        if a.poke_index is not None:
            emu.w32(A.RAND_SEED, seed_at(a.poke_index))
        rows = run_trace(emu, a.vis, parse_inputs(a.inputs), a.every)
    write_csv(rows, Path(a.out))
    print(f"wrote {len(rows)} rows -> {a.out}  (idx {rows[0]['idx']} -> {rows[-1]['idx']})")


if __name__ == "__main__":
    main()
