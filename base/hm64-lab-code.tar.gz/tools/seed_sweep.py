#!/usr/bin/env python3
"""
Sweep RNG stream positions from a load anchor, in parallel.

An experiment is a Python module in experiments/ that defines job(emu, j) and
either takes stream indices from --start/--count, or defines jobs() returning
its own list of JSON-serialisable job specs (e.g. a whistle/cast/release grid).
Set FRESH_BOOT = True in the module when each job must start from power-on
(cold-boot routes); EMU_KWARGS = {...} passes extra Emulator options.
Seed-sweep form:

    STATE = "states/load_diary0.st"      # a LOAD anchor (see tools/boot.py)
    def run(emu, n):                      # emu is loaded + seed already poked to step^n(0)
        ...                               # drive inputs, observe, measure
        return {...}                      # JSON-serialisable

Why the load anchor: poking the seed there is bit-identical to a human
pressing the diary button at a different time (verified over 3600 VIs for
several delays; re-check with tools/smoke_test.py). Poking any later is NOT
equivalent - the dog has already started rolling.

  python3 tools/seed_sweep.py experiments/dog_observation.py --start 480 --count 64 \
      --out results/dog_obs.jsonl
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from m64h.pool import run_jobs                 # noqa: E402
from tools.common import default_rom, default_sram  # noqa: E402


def load_experiment(path: str):
    path = Path(path).resolve()
    sys.path.insert(0, str(path.parent))
    spec = importlib.util.spec_from_file_location(path.stem, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[path.stem] = mod
    spec.loader.exec_module(mod)
    return mod


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("experiment")
    ap.add_argument("--start", type=int, help="first stream index n (omit if the experiment defines jobs())")
    ap.add_argument("--count", type=int, default=1)
    ap.add_argument("--stride", type=int, default=1)
    ap.add_argument("--workers", type=int)
    ap.add_argument("--rom", default=default_rom())
    ap.add_argument("--sram", default=default_sram())
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    exp = load_experiment(a.experiment)
    if a.start is not None:
        ns = [a.start + i * a.stride for i in range(a.count)]
    elif hasattr(exp, "jobs"):
        ns = list(exp.jobs())
    else:
        raise SystemExit("give --start/--count, or define jobs() in the experiment")
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    done = errors = 0
    with out.open("w") as f:
        for res in run_jobs(exp.job, ns, rom=a.rom, sram=a.sram, workers=a.workers,
                            fresh=getattr(exp, "FRESH_BOOT", False),
                            emu_kwargs=getattr(exp, "EMU_KWARGS", None)):
            if "_error" in res:
                errors += 1
                print(f"n={res['_job']} ERROR\n{res['_error']}", file=sys.stderr)
            f.write(json.dumps(res) + "\n")
            f.flush()
            done += 1
            if done % 10 == 0 or done == len(ns):
                rate = done / (time.time() - t0)
                print(f"{done}/{len(ns)}  {rate:.2f} seeds/s  errors={errors}", flush=True)
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
