"""UI lab report (tools/uilab.py report): UILAB.md + uilab_summary.json in the run folder."""
from __future__ import annotations

import json
import math
import statistics as st
from pathlib import Path

from uilab import VI_MS, app_data, load_jsonl, casts_of, latest_ui


def wilson(k, n, z=1.96):
    if not n:
        return (float("nan"),) * 3
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return p, max(0.0, c - h), min(1.0, c + h)


def pc(k, n):
    p, lo, hi = wilson(k, n)
    return f"{100 * p:.1f}% ({k}/{n}; 95% {100 * lo:.1f}–{100 * hi:.1f}%)" if n else "—"


def report(d):
    d = Path(d)
    plan = json.load(open(d / "plan.json"))
    D = app_data(d / "app.html")
    R = next(r for r in D["lroutes"] if r["id"] == plan["route"])
    ui1 = {r["id"]: r for r in load_jsonl(d / "ui1.jsonl")}
    ui2 = {}
    for r in load_jsonl(d / "ui2.jsonl"):
        ui2[r["id"]] = r
    casts = casts_of(d)
    A = {x["id"]: x for x in plan["attempts"]}
    done = [i for i in A if ui2.get(i, {}).get("outcome") and not ui2[i].get("resync")]
    L = []
    w = L.append
    n = len(done)
    nut = sum(ui2[i]["outcome"] == "nut" for i in done)
    shown = [ui2[i]["cue"]["pNum"] if ui2[i]["cue"].get("pNum") is not None else float(ui2[i]["cue"]["P"].rstrip("%")) / 100 for i in done]
    w(f"# UI lab — {plan['route']}, runner `{plan['runner']}`" + (", dog-watch" + (" strict" if plan["dog"].get("strict") else "") if plan["dog"]["on"] else ""))
    rn = plan["rn"]
    w(f"\n{plan['n']} attempts planned (seed {plan['seed']}), {len(ui1)} played in the app, {n} complete (app → emulator → app). App `{plan['app']}`"
      f"{' with the player’s own stored settings' if plan.get('storage_own') else ' told the runner’s own numbers'}.")
    w(f"Runner: clock taps {rn['tap_delay']} ms after their cue ± {rn['tap_sd']} ms, B press {rn['press_bias']:+d} ± {rn['press_sd']} ms from the CAST cue, "
      f"bite taps {rn['lag_mu']} ± {rn['lag_sd']} ms after the bite shows. Members sampled by the app's own route weights "
      f"({100 * plan['cover'] / (plan['cover'] + plan['unmatched']):.1f}% of the weight has a member route in this state store).")
    w("\n## 1. Does the suggestion pay? Nut rate vs the odds the app showed")
    w(f"- **Power Nut: {pc(nut, n)}**")
    if n:
        w(f"- the app showed on average **{100 * st.mean(shown):.1f}%** at the cast (its \"Cast at … → x%\")")
        w(f"- blind fishing: 1 in 51 = 2.0%; so the lift measured here is ×{nut / n * 51:.1f}" if nut else "- blind fishing: 1 in 51 = 2.0%")
        over = 40                                                 # s from the reset to the beach fade-in (beach load ~VI 2,270 after reset)
        ends = [max([ui2[i]["press"]["abs"]] + [b["ms"] + b.get("lag", 0) for b in ui2[i]["bites"]]) / 1000 for i in done]
        w(f"- time: the cast came {st.mean(ui2[i]['press']['abs'] for i in done) / 1000:.1f} s after the fade-in on average, the attempt ended at {st.mean(ends):.1f} s; "
          f"with {over} s from the reset to the fade-in that is **{(over * n + sum(ends)) / max(1, nut) / 60:.1f} min per Nut**"
          + (" (app set to the fastest-Nut aim)" if plan.get("goal") else ""))
        se = math.sqrt(st.mean(shown) * (1 - st.mean(shown)) / n)
        z = (nut / n - st.mean(shown)) / se if se else 0
        w(f"- measured minus shown: {100 * (nut / n - st.mean(shown)):+.1f} points = {z:+.1f} standard errors "
          f"({'consistent with the app' if abs(z) < 2 else 'the app is OFF: more than 2 standard errors'}); "
          f"to tell a 2-point gap from chance takes about {int(4 * st.mean(shown) * (1 - st.mean(shown)) / 0.02 ** 2 / 4) * 4} attempts")
        order = sorted(range(n), key=lambda q: shown[q])
        w("\n| odds shown (thirds of the attempts) | attempts | shown (mean) | Power Nut |\n|---|---|---|---|")
        for a_, b_ in ((0, n // 3), (n // 3, 2 * n // 3), (2 * n // 3, n)):
            ix = order[a_:b_]
            if ix:
                k = sum(ui2[done[q]]["outcome"] == "nut" for q in ix)
                w(f"| {100 * shown[ix[0]]:.1f}–{100 * shown[ix[-1]]:.1f}% | {len(ix)} | {100 * st.mean(shown[q] for q in ix):.1f}% | {pc(k, len(ix))} |")
    oc = {}
    for i in done:
        r = ui2[i]
        key = r["outcome"] if r["outcome"] != "nut" else f"nut on bite {r['bites'][-1]['n']}"
        oc[key] = oc.get(key, 0) + 1
    w("\n## 2. What happened after the cast")
    NAME = {"fish": "a fish (released a bite that was no Nut)", "late": "empty line (B up after the 0.33 s window)", "dud": "the lamp said DUD: reset",
            "none": "no bite the lamp released by 90 s after READY"}
    for k in sorted(oc, key=lambda q: -oc[q]):
        w(f"- {NAME.get(k, k)}: {oc[k]} ({100 * oc[k] / n:.1f}%)")
    duds = [i for i in done if ui2[i]["outcome"] == "dud"]
    if duds:
        w(f"- DUD calls with a Nut still to come on a later bite of that cast: {sum(bool(ui2[i].get('laterNut')) for i in duds)} of {len(duds)}")
    fish = [i for i in done if ui2[i]["outcome"] == "fish"]
    if fish:
        w(f"- fish with a Nut on a later bite of the same cast (the lamp released too early): {sum(bool(ui2[i].get('laterNut')) for i in fish)} of {len(fish)}")
    dis = sum(1 for i in done for b in ui2[i]["bites"] if b.get("app") and b["app"].get("held") is not None and
              ((b["act"] == "release") != (b["app"]["rel"] or (b["app"]["held"] and not b["app"]["hold"]))))
    w(f"- lamp text vs the app's own release rule at the bite: {dis} disagreements over {sum(len(ui2[i]['bites']) for i in done)} bites")

    w("\n## 3. The clock: app vs console (absolute clock, 0 = first light)")
    u = [ui2[i] for i in done] or list(ui1.values())
    if u:
        w0 = [x["clock"]["wall0"] for x in u if x.get("clock")]
        w(f"- the app's first-light estimate: {st.mean(w0):+.1f} ms ± {st.pstdev(w0):.1f} ms from the truth "
          f"(the runner's taps have ± {rn['tap_sd']} ms each; expected ± {rn['tap_sd'] / math.sqrt(2):.1f} from two clock taps)")
        tg = [t["got"] - t["want"] for x in u for t in x["taps"]]
        w(f"- test harness: a key lands {st.mean(tg):+.1f} ms (max {max(tg):+.1f}) from its scheduled time; the lamp shows CAST "
          f"{st.mean([x['cue']['shown'] - x['cue']['abs'] for x in u if x['cue'].get('shown') is not None]):+.1f} ms after the app's own cue time (one frame)")
        dv = [x["press"]["tau"] - x["press"]["aimTau"] for x in u]
        w(f"- the press landed {st.mean(dv):+.2f} ± {st.pstdev(dv):.2f} VIs from the aim (runner ± {rn['press_sd']} ms = ± {rn['press_sd'] / VI_MS:.1f} VIs)")
        ok3 = sum(1 for x in u if set(x["clock"]["cues"]) == {"exit", "ctrl", "dock"} and not x["clock"]["strays"])
        w(f"- taps classified as ranch exit / first control / dock end with no stray: {ok3} of {len(u)}; dock-end tap rejected: {sum(1 for x in u if x['clock'].get('dock') and x['clock']['dock']['off'])}")
        if any(x["cue"].get("movedLate") for x in u):
            w(f"- the cue moved inside the last 0.4 s before the cast: {sum(1 for x in u if x['cue'].get('movedLate'))} attempts")
    w(f"- second UI pass reproduced the first (same press VI): {sum(1 for i in ui2 if not ui2[i].get('resync'))} of {len(ui2)}; READY on the emulator replay = the member's recorded READY: "
      f"{sum(1 for r in load_jsonl(d / 'casts.jsonl') if 'casts' in r and r['ready_rel'] == A[r['_job']['att']]['ready_rel'])} of {sum(1 for r in load_jsonl(d / 'casts.jsonl') if 'casts' in r)} cast jobs")

    w("\n## 4. Was the aim on the Nut frames? Casts the emulator evaluated around each aim")
    W = plan["window"]
    w("If the app's clock and tables are right, the best column sits at offset 0 and falls away on both sides; a peak at another offset = a timing bias.\n")
    w("| cast lands (VIs from the aim's game frame) | ms | attempts | Nut if bite 1 is released | Nut if held to bite 2 | Nut with the app's release zones |\n|---|---|---|---|---|---|")
    prof = {}
    for off in range(-W, W + 1, 2):
        k1 = k2 = kz = m = 0
        for i in done:
            at = ui2[i]["press"]["aimTau"]
            c = casts.get(i, {}).get(at - ((at + A[i]["k_off"]) % 2) + off)   # game frames: the aim's frame + off
            if not c or not c["bites"] or c["bites"][0][0] is None:
                continue
            b = c["bites"]
            n1, n2 = b[0][1], (len(b) > 1 and b[1][1])
            t1 = A[i]["mt"] + b[0][0]
            inz = any(z0 <= t1 < z1 for z0, z1 in ui2[i]["cue"].get("zones") or [])
            pol = ui2[i]["cue"]["pol"]
            rel1 = pol == "bite1" or (pol == "zone" and inz)
            m += 1
            k1 += n1
            k2 += n2
            kz += n1 if rel1 else n2
        prof[off] = [m, k1, k2, kz]
        if m:
            w(f"| {off:+d} | {off * VI_MS:+.0f} | {m} | {100 * k1 / m:.1f}% | {100 * k2 / m:.1f}% | **{100 * kz / m:.1f}%** |")
    if n and prof.get(0, [0])[0]:
        best = max(prof, key=lambda q: prof[q][3] / max(1, prof[q][0]))
        w(f"\nA press exactly on the aim would have given {pc(prof[0][3], prof[0][0])}; best offset in this sample: {best:+d} VIs "
          f"({100 * prof[best][3] / max(1, prof[best][0]):.1f}%). Read the shape, not one column: each column has the same ± as section 1.")

    w("\n## 5. Does the app know which dog line it is on?")
    if u:
        pl0 = [x["prior"]["line"] for x in u if x.get("prior") and x["prior"]["line"] is not None]
        pl1 = [x["post"]["line"] for x in u if x.get("post") and x["post"]["line"] is not None]
        if pl0 and pl1:
            w(f"- weight on the true dog line: {100 * st.mean(pl0):.1f}% before the taps → **{100 * st.mean(pl1):.1f}%** at the cast (mean); on the true member route: "
              f"{100 * st.mean(x['post']['member'] for x in u if x.get('post') and x['post']['member'] is not None):.1f}%")
        dw = [x["dw"] for x in u if x.get("dw")]
        if dw:
            w(f"- dog-watch: {st.mean(q['logs'] for q in dw):.1f} logs per attempt; true line on top {pc(sum(1 for x in u if x.get('dw') and x['dw']['top'] == A[x['id']]['dwi']), len(dw))}; "
              f"weight on it {100 * st.mean(q['pTrue'] or 0 for q in dw):.1f}%; lines ≥ 1% left {st.mean(q['left'] or 0 for q in dw):.1f}; cast moved in {sum(1 for q in dw if q['moved'])} attempts")
    unc = sum(1 for i in done if A[i]["kind"] == "uncast")
    if unc:
        w(f"- attempts on dog lines that have no cast table: {unc} ({sum(ui2[i]['outcome'] == 'nut' for i in done if A[i]['kind'] == 'uncast')} Nuts)")

    w("\n## 6. The app's cast tables vs the emulator (same member, same cast)")
    eq = dict(n=0, n1=0, b1=0, n2=0, b2=0, unk=0)
    bad = []
    for i, cs in casts.items():
        x = A[i]
        if x["kind"] != "line":
            continue
        c = R["lines"][x["li"]]
        for tau, r in cs.items():
            v = tau + x["k_off"] + 1 - c["lo"]
            if v < 0 or v >= len(c["n1"]) or c["n1"][v] == "." or not r["bites"] or r["bites"][0][0] is None:
                eq["unk"] += 1
                continue
            eq["n"] += 1
            b = r["bites"]
            e = [int(b[0][1]), b[0][0] - tau, int(len(b) > 1 and b[1][1]), (b[1][0] - tau) if len(b) > 1 and b[1][0] is not None else None]
            t = [int(c["n1"][v] == "1"), c["b1"][v], int(c["n2"][v] == "1") if c.get("n2") and c["n2"][v] != "." else None, c["b2"][v] if c.get("b2") else None]
            ok = [e[0] == t[0], e[1] == t[1], t[2] is None or e[2] == t[2], t[3] is None or e[3] is None or e[3] == t[3]]
            for kk, o_ in zip(("n1", "b1", "n2", "b2"), ok):
                eq[kk] += o_
            if not all(ok) and len(bad) < 5:
                bad.append(f"attempt {i} tau {tau}: emulator {e} vs table {t}")
    w(f"- {eq['n']} casts compared (first-bite Nut / first-bite time / second-bite Nut / second-bite time equal): "
      f"{eq['n1']} / {eq['b1']} / {eq['n2']} / {eq['b2']}; {eq['unk']} casts on a frame the table has no entry for")
    for b_ in bad:
        w(f"  - differs: {b_}")
    errs = [(r["id"], r["errors"][0][:160]) for r in list(ui1.values()) + list(ui2.values()) if r.get("errors")]
    if errs:
        w(f"\n## Errors\n{len(errs)} UI rows reported an error; first: attempt {errs[0][0]}: {errs[0][1]}")
    (d / "UILAB.md").write_text("\n".join(L) + "\n", encoding="utf8")
    json.dump({"route": plan["route"], "runner": plan["runner"], "n": n, "nut": nut, "shown_mean": st.mean(shown) if n else None, "outcomes": oc,
               "profile": prof, "tables": eq, "errors": len(errs)}, open(d / "uilab_summary.json", "w"))
    print("\n".join(L))
