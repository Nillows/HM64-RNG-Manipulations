#!/usr/bin/env python3
"""
Gate-0 regression: replay the eight QuickSave2(1) fishing cases recorded in
the v24/v25 handoff (B press poll / B release poll -> outcome) with real
controller input - no RAM edits - and compare with the recorded outcomes.

  python3 tools/convert_bizhawk_state.py --state "data/states_bizhawk/...QuickSave2(1).State" --out states/qs2.st
  python3 tools/regress_qs2.py --state states/qs2.st

--poll-base: 0 (default) = "poll N" is the N-th controller read counting from
0 at the instant the state finishes loading. Verified: base 0 reproduces 8/8
recorded outcomes (incl. the 83-fails/84-wins boundary); base 1 gives 2/8.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from m64h import Emulator                      # noqa: E402
from hm64 import addresses as A                # noqa: E402
from hm64.lcg import index                     # noqa: E402
from tools.common import default_rom           # noqa: E402

NUT_BITS = 0x80215EB8        # u32 acquiredPowerNutBits; FISHING_POWER_NUT = 4
POWER_NUT_ITEM = 87
FISH_ITEMS = {37: "small fish", 38: "medium fish", 39: "large fish"}   # see items.h

# (name, B press poll, B release poll, recorded outcome) - handoff v25 section 3.1
CASES = [
    ("win84", 84, 1414, "nut"), ("win85", 85, 1414, "nut"),
    ("win424", 424, 1634, "nut"), ("win470", 470, 1666, "nut"),
    ("fail40", 40, 668, "fish"), ("fail82", 82, 1434, "fish"),
    ("fail83", 83, 1414, "no catch"), ("fail86", 86, 716, "fish"),
]


def run_case(emu, state, press, release, tail_polls=600):
    emu.schedule_polls([(press, ["B"]), (release, [])])
    emu.load_state(state)
    seen = {"bite_poll": None, "items": [], "phases": []}
    last_phase = None
    while emu.polls() < release + tail_polls:
        emu.advance(1)
        ph = emu.u8(A.PLAYER + 0x6A)
        act = emu.u16(A.PLAYER + 0x64)
        if (act, ph) != last_phase:
            seen["phases"].append((emu.polls(), act, ph))
            last_phase = (act, ph)
            # fishing (actionHandler 22): 1 cast, 2 waiting, bite shows as 3/4, 6 reel, 7 catch, 8 miss
            if act == 22 and ph >= 3 and seen["bite_poll"] is None:
                seen["bite_poll"] = emu.polls()
        item = emu.u8(A.PLAYER + 0x2C)
        if item and (not seen["items"] or seen["items"][-1] != item):
            seen["items"].append(item)
        if emu.u32(NUT_BITS) & 4:
            break
    emu.clear_schedule()
    nut = bool(emu.u32(NUT_BITS) & 4)
    if nut:
        outcome = "nut"
    elif any(i in FISH_ITEMS for i in seen["items"]):
        outcome = "fish"
    else:
        outcome = "no catch"
    return {"outcome": outcome, "nut": nut, "bite_poll": seen["bite_poll"],
            "items": seen["items"], "end_idx": index(emu.u32(A.RAND_SEED))}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--rom", default=default_rom())
    ap.add_argument("--state", default="states/qs2.st")
    ap.add_argument("--poll-base", type=int, choices=[0, 1])
    ap.add_argument("--case", default="all")
    ap.add_argument("--json", help="write results here")
    a = ap.parse_args()
    bases = [a.poll_base] if a.poll_base is not None else [0]
    cases = CASES if a.case == "all" else [c for c in CASES if c[0] == a.case]
    results = []
    with Emulator(a.rom) as emu:
        for base in bases:
            ok = 0
            for name, p, r, expected in cases:
                res = run_case(emu, a.state, p - base, r - base)
                match = res["outcome"] == expected
                ok += match
                results.append({"case": name, "poll_base": base, "press": p, "release": r,
                                "expected": expected, **res, "match": match})
                print(f"base={base} {name:7s} press {p:4d} release {r:4d}: {res['outcome']:9s} "
                      f"(expected {expected:9s}) {'OK' if match else 'MISMATCH'}  bite@poll {res['bite_poll']}")
            print(f"poll base {base}: {ok}/{len(cases)} match the recorded outcomes\n")
    if a.json:
        Path(a.json).write_text(json.dumps(results, indent=1))


if __name__ == "__main__":
    main()
