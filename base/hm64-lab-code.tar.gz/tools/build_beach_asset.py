"""
Pack Thomas's beach screenshot (empty pier at READY, 640x480 = 2x the N64's 320x240) into
webapp/assets/beach_ready.json: the Lucky Timer draws Jack's catalog frames on it at the game's scale.

  python3 -I tools/build_beach_asset.py HM64_Beach_Ready_Empty_Pier.png [--out webapp/assets/beach_ready.json]

Alignment (measured 2026-11-13): the screenshot's background equals the lab's rice render shifted by (-38, +12) image
pixels (masked SAD over the pier and sand); Jack's anchor is at (321, 240) in both renders (camera centred on him), so
the lab's READY spot (player (-101.993, 178.257), which every cast table uses) is at (283, 252) in the screenshot.
Thomas's own READY screenshot shows Jack at (321, 240) instead, ~2/3 tile further along the pier.
Facing E: the stick tap moves Jack (+8.5, 0, -8.5) world units = +12 native px on screen -> (307, 252).
"""
from __future__ import annotations

import argparse
import base64
import io
import json
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
CROP = (150, 128, 590, 480)                  # x0, y0, x1, y1 in the 640x480 screenshot (5:4)
JACK = {"SE": [283, 252], "E": [307, 252]}   # Jack's anchor (lab READY) in screenshot pixels


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("screenshot")
    ap.add_argument("--out", default=str(ROOT / "webapp" / "assets" / "beach_ready.json"))
    ap.add_argument("--quality", type=int, default=88)
    a = ap.parse_args()
    im = Image.open(a.screenshot).convert("RGB")
    if im.size != (640, 480):
        raise SystemExit(f"expected a 640x480 screenshot (2x native), got {im.size}")
    buf = io.BytesIO()
    im.crop(CROP).save(buf, "JPEG", quality=a.quality, optimize=True)
    out = {"schema": "hm64-lucky-beach-v1", "img": "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode(),
           "x0": CROP[0], "y0": CROP[1], "w": CROP[2] - CROP[0], "h": CROP[3] - CROP[1], "pxPerNative": 2,
           "jack": JACK, "note": "Thomas's own screenshot (private research); Jack at the lab READY spot"}
    Path(a.out).write_text(json.dumps(out, separators=(",", ":")))
    print(f"{a.out}: {out['w']}x{out['h']} crop, {len(buf.getvalue()) // 1024} KB")


if __name__ == "__main__":
    main()
