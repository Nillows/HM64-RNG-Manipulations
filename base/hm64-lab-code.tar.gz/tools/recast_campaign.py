"""
Recast pilot (2026-11-20): jobs of experiments/recast_jobs.py on the heaviest dog lines of a finished dog-watch run
(its results folder `--src`, its state store in HM64_ZZ_STORE). Nothing of that run or of the full-day run is changed.

  python3 tools/recast_campaign.py --src results/dogwatch/<label> --out results/recast/<tag> run

Per (line, cast frame): one job "rel" (the hold, 38 empty releases, catches at bites 1-3 with the fish handled six ways,
each followed 20 s) and four jobs "src" (second casts, one per game frame for 10 s, from: bite 1 caught, bite 2 caught,
an empty release 2 s and one 10 s after the float landed). Resumable; Ctrl-C any time.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "experiments"))
from common import default_rom, default_sram   # noqa: E402
from m64h.pool import run_jobs                 # noqa: E402
import fullday_campaign as FC                  # noqa: E402

RC_CODE = "recast-1 (2026-11-20: pilot)"
SOURCES = [{"t": "bite", "i": 0}, {"t": "bite", "i": 1}, {"t": "empty", "dr": 120}, {"t": "empty", "dr": 600}]


def cast_frames(n):
    """n cast frames (even VI labels after READY) spread over the dog-watch window 2 .. 38 s."""
    lo, hi = 120, 2280
    return [lo] if n <= 1 else [int(lo + (hi - lo) * i / (n - 1)) // 2 * 2 for i in range(n)]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--src", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--workers", type=int, default=max(1, (os.cpu_count() or 2) - 1))
    ap.add_argument("--lines", type=int, default=int(os.environ.get("HM64_RC_LINES", "8")))
    ap.add_argument("--casts", type=int, default=int(os.environ.get("HM64_RC_CASTS", "6")))
    ap.add_argument("--n", type=int, default=int(os.environ.get("HM64_RC_N", "300")), help="second casts per source")
    ap.add_argument("--step", type=int, default=int(os.environ.get("HM64_RC_STEP", "2")))
    ap.add_argument("--dense", type=int, default=int(os.environ.get("HM64_RC_DENSE", "16")))
    ap.add_argument("--post", type=int, default=int(os.environ.get("HM64_RC_POST", "1200")))
    ap.add_argument("--any-dog", action="store_true", default=os.environ.get("HM64_FD_ANY_DOG") == "1")
    ap.add_argument("stage", choices=["run"])
    args = ap.parse_args()
    src, out = Path(args.src), Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    for f in ("zz_lines.json", "Z6_lines.jsonl", "Z0_record.json"):
        if not (src / f).exists():
            sys.exit(f"STOP: {src / f} is missing - --src must be the results folder of a finished dog-watch run")
    order, _ = FC.src_lines(src)
    order = order[:args.lines]
    at, poke = FC.dog_spot(src, args.any_dog)
    rom, sram = default_rom(), default_sram()
    import recast_jobs as RJ
    ks = cast_frames(args.casts)
    tot = sum(w for _, w, _ in FC.src_lines(src)[0]) or 1.0
    print(f"{RC_CODE}  {len(order)} lines ({sum(w for _, w, _ in order) / tot:.0%} of the route weight) x cast frames {ks} "
          f"of {src}  save {sram}  workers {args.workers}  dog at {at}" + (f"  (dog written by the test knob: {poke})" if poke else ""),
          flush=True)
    base = lambda key, rep, k: {"key": key, "b": rep["b"], "D": rep["D"], "B": rep["B"], "dog_at": at, "k": k}
    rel = [dict(base(key, rep, k), dense=args.dense, post=args.post, tag=f"rel:{key}:{k}") for key, _, rep in order for k in ks]
    srcj = [dict(base(key, rep, k), src=s, n=args.n, step=args.step,
                 tag=f"src:{key}:{k}:{s['t']}{s.get('i', s.get('dr'))}")
            for s in SOURCES for key, _, rep in order for k in ks]
    json.dump({"code": RC_CODE, "lines": [[k, w / tot] for k, w, _ in order], "casts": ks, "n": args.n, "step": args.step,
               "dense": args.dense, "post": args.post, "workers": args.workers, "dog_at": at, "test_dog_poke": poke,
               "sources": SOURCES, "started": time.strftime("%Y-%m-%d %H:%M")}, open(out / "rc_setup.json", "w"), indent=1)
    t0 = time.time()
    bad = FC.run_stage("RC rel", RJ.rc_rel_job, rel, out / "RC_rel.jsonl", args.workers, rom, sram, lambda j: j["tag"])
    t1 = time.time()
    bad += FC.run_stage("RC src", RJ.rc_src_job, srcj, out / "RC_src.jsonl", args.workers, rom, sram, lambda j: j["tag"])
    with open(out / "rc_times.jsonl", "a") as f:
        f.write(json.dumps({"rel_wall": round(t1 - t0), "src_wall": round(time.time() - t1), "workers": args.workers}) + "\n")
    return 4 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
