"""
Pace presets for the Lucky Timer.

Route weights (the same as the Oracle's: every measured route counts once, spread over the arrivals its Layer 1
anchor links to) split by the runner's slack before the dog is put down:

  slack = d0 + d1 + d2 + d3 + P + H + C      (polls, ~1/60 s each; the beach wait D comes after the dog lands)

and the arrival offsets re-anchored to the moment the dog is put down (dog_placed = first VI on the beach with
the dog's held flag clear). Measured: READY - dog_placed = 16 + 2*(D//2) VI, and routes that differ only in D
reach the same dog path at offset o + 2*(D//2) (51 route families in A_routes, all consistent), so from the
dog landing the beach wait does not matter at all.

Stopwatch conventions (t = 1 is the start event, as everywhere in the tool):
  ready anchor  path VI = t + o                         variants [path, o, w]
  dog anchor    path VI = u + o - 16 - 2*(D//2)         variants [path, o - 16 - 2*(D//2), w, 2*(D//2)]
                (u = 1 at dog_placed; that route's READY, its first possible cast, is u = 17 + 2*(D//2))
"""
from __future__ import annotations

import csv
import json
import re
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LINKS = ROOT / "data" / "routes" / "ROUTE_TO_CHECKPOINT_LINKS.csv"
LAG0 = 16
LABEL = re.compile(r"m(\d\d)(\d\d)(\d\d)(\d\d)_h(\d\d)c(\d\d)_p(\d\d)d(\d\d)$")
# slack bands (polls) - terciles of the measured route set, see LAB_STATUS
GROUPS = [("fast", "Fast", 0, 21), ("medium", "Medium", 22, 27), ("slow", "Slow", 28, 999)]


def parse(label):
    m = LABEL.match(label)
    if not m:
        return None
    d0, d1, d2, d3, H, C, P, D = map(int, m.groups())
    return {"slack": d0 + d1 + d2 + d3 + H + C + P, "D": D, "menu": d0 + d1 + d2 + d3, "walk": H + C + P}


def load_jsonl(p):
    with open(p) as f:
        return [json.loads(x) for x in f if x.strip()]


def build(truth_dir, by_sig, groups=GROUPS, links=LINKS):
    """by_sig: {signature: (path, o)} of the tool's arrivals. Returns the pace block for the web app."""
    routes = [r for r in load_jsonl(Path(truth_dir) / "A_routes.jsonl")
              if "_error" not in r and r.get("outcome") == "ready"]
    anchor_of, units = {}, []
    if Path(links).exists():
        with open(links) as f:
            for r in csv.DictReader(f):
                anchor_of[r["label"]] = r["anchor_id"]
                units.append((r["label"], r["anchor_id"]))
    sig_anchors = defaultdict(set)
    for r in routes:
        a = anchor_of.get(r["label"], "label:" + r["label"])
        sig_anchors[r["signature"]].add(a)
        if a.startswith("label:"):
            units.append((r["label"], a))
    share = defaultdict(int)
    anchor_sigs = defaultdict(list)
    for s, an in sig_anchors.items():
        for a in an:
            share[a] += 1
            anchor_sigs[a].append(s)
    acc = {g[0]: {"ready": defaultdict(float), "dog": defaultdict(float), "routes": 0, "covered": 0,
                  "slack": defaultdict(float)} for g in groups}
    acc["all"] = {"ready": defaultdict(float), "dog": defaultdict(float), "routes": 0, "covered": 0,
                  "slack": defaultdict(float)}
    for label, a in units:
        x = parse(label)
        if x is None:
            continue
        gs = ["all"] + [g[0] for g in groups if g[2] <= x["slack"] <= g[3]]
        d2 = 2 * (x["D"] // 2)
        sigs = [s for s in anchor_sigs.get(a, []) if s in by_sig]
        for g in gs:
            acc[g]["routes"] += 1
            acc[g]["covered"] += bool(sigs)
            acc[g]["slack"][x["slack"]] += 1
        for s in sigs:
            path, o = by_sig[s]
            w = 1.0 / share[a]
            for g in gs:
                acc[g]["ready"][(path, o)] += w
                acc[g]["dog"][(path, o - LAG0 - d2, d2)] += w
    out = {"lag0": LAG0, "slackDef": "d0+d1+d2+d3+P+H+C polls before the dog is put down", "groups": []}
    for gid, name, lo, hi in [("all", "All", 0, 999)] + list(groups):
        g = acc[gid]
        out["groups"].append({
            "id": gid, "label": name, "lo": lo, "hi": hi, "routes": g["routes"], "covered": g["covered"],
            "ready": [[p, o, round(w, 4)] for (p, o), w in sorted(g["ready"].items())],
            "dog": [[p, o, round(w, 4), d2] for (p, o, d2), w in sorted(g["dog"].items())],
            "slack": sorted([k, int(v)] for k, v in g["slack"].items()),
        })
    return out
