"""Shared paths/defaults for the tools. Everything is overridable by env vars."""
from __future__ import annotations

import glob
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = Path(os.environ.get("HM64_DATA", ROOT / "data"))
STATES = Path(os.environ.get("HM64_STATES", ROOT / "states"))
RESULTS = Path(os.environ.get("HM64_RESULTS", ROOT / "results"))


def _first(pattern: str) -> str | None:
    hits = sorted(glob.glob(str(DATA / pattern)))
    return hits[0] if hits else None


def default_rom() -> str | None:
    return os.environ.get("HM64_ROM") or _first("rom/*.z64")


def default_sram() -> str | None:
    if "HM64_SRAM" in os.environ:
        return os.environ["HM64_SRAM"] or None
    for pat in ("saves/*.SaveRAM", "saves/*.sra", "saves/*.sav", "saves/*.srm"):
        hit = _first(pat)
        if hit:
            return hit
    return None
