"""
Full-day lab report (2026-11-20): FULLDAY.md + fullday_summary.json from what tools/fullday_campaign.py has written so
far. Safe to run at any time (also while a block is running; it reads finished rows only).
  python3 tools/fullday_report.py --src results/dogwatch/<label> --out results/fullday/<tag>
"""
from __future__ import annotations

import argparse
import collections
import glob
import json
import os
import sys
from pathlib import Path

VI_S = 16.715 / 1000


def rows_of(p):
    out = []
    if os.path.exists(p):
        with open(p) as f:
            for line in f:
                try:
                    out.append(json.loads(line))
                except ValueError:
                    pass
    return out


def hour_of(clock, k0, k):
    """Game hour at VI label k: 10 game seconds per game update (2 VIs) [DECOMP time.c updateClock]."""
    s = clock[0] * 3600 + clock[1] * 60 + clock[2] + (k - k0) * 5
    return (s // 3600) % 24


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    out, src = Path(a.out), Path(a.src)
    L = [r for r in rows_of(out / "FD1_lines.jsonl") if r.get("ok")]
    Lk = {r["key"]: r for r in L}
    summ = json.load(open(out / "fd_lines_summary.json")) if (out / "fd_lines_summary.json").exists() else {}
    plan = json.load(open(out / "fd_plan.json")) if (out / "fd_plan.json").exists() else {"blocks": []}
    md = ["# HM64 full-day lab — the cast table and the dog to the end of the game day", ""]
    S = {"lines": len(L)}
    if L:
        ends = [r["end"][0] for r in L]
        clocks = sorted({"%02d:%02d" % (r["clock"][0], r["clock"][1]) for r in L})
        moved = [(r["key"], r["p"][0]) for r in L if r.get("p")]
        offg = [r["key"] for r in L if r.get("g")]
        notday = [(r["key"], r["end"]) for r in L if r["end"][1] not in ("day", "limit")]
        lim = all(r["end"][1] == "limit" for r in L)
        md += ["## 1. The day without a cast (every dog line, stay-awake push every 33 s)", "",
               f"- {len(L)} lines ran" + (f" of {summ.get('lines')}" if summ else "") + f"; dog at READY: {summ.get('dog_at')}"
               + (f" (**written by the test knob {summ.get('test_dog_poke')}: a stand-in, not the real save**)" if summ.get("test_dog_poke") else ""),
               f"- Clock at READY: {clocks[0]} – {clocks[-1]}. " + (f"Followed to {max(ends)} VIs = {max(ends) * VI_S:.0f} s after READY (the limit)." if lim else
               f"The day ends (06:00, the game takes the controls) {min(ends)} – {max(ends)} VIs = {min(ends) * VI_S:.0f} – {max(ends) * VI_S:.0f} s after READY."),
               f"- Same paths as the dog-watch run? cast hashes of the first 33 s: **{summ.get('z6_same')} equal, "
               f"{summ.get('z6_diff')} different**.",
               f"- Ended by something else than the limit / the end of the day: {len(notday)}" + (f" — {notday[:6]}" if notday else ""),
               f"- The dog's visible changes over that time: {sum(len(r['d']) // 2 for r in L) / len(L):.0f} per line.",
               f"- **The dog leaves its spot** (moved 4 units or more) on {len(moved)} of {len(L)} lines"
               + (f"; earliest {min(m[1] for m in moved) * VI_S:.0f} s after READY, median "
                  f"{sorted(m[1] for m in moved)[len(moved) // 2] * VI_S:.0f} s" if moved else "") + ".",
               f"- Its tile leaves the visibility grid (not on screen, not animating) on {len(offg)} lines.", ""]
        S.update(day_end=[min(ends), max(ends)], dog_moves=len(moved), off_grid=len(offg), not_day=len(notday))
    # ------------------------------------------------------------------------------------------- blocks
    md += ["## 2. Cast blocks (every cast held to the limit, or the end of the day)", "",
           "| block | cast frames (s after READY) | lines | casts planned | done | job errors | hash check ok / failed / none | ended: as planned / beach check / other | bites per cast | casts with a Nut on some bite |",
           "|---|---|---|---|---|---|---|---|---|---|"]
    by_hour = collections.Counter()
    nut_hour = collections.Counter()
    nut_bite = collections.Counter()
    kinds = collections.Counter()
    fails, others = [], []
    bite_hashes, n_bites, probe_diff = set(), 0, 0
    all_casts = {}
    tot = collections.Counter()
    dogruns, tails, moved_c = 0, 0, 0
    size = 0
    files = sorted(glob.glob(str(out / "FD_casts_b*.jsonl")))
    P = {b["i"]: b for b in plan.get("blocks", [])}
    for fp in files:
        bi = int(Path(fp).stem.split("_b")[1])
        size += os.path.getsize(fp)
        rs = rows_of(fp)
        err = sum(1 for r in rs if "_error" in r or "error" in r)
        c = collections.Counter()
        nb = 0
        for r in rs:
            ln = Lk.get(r.get("key"))
            for x in r.get("casts", []):
                c["n"] += 1
                c["ok" if x["ok"] else "bad" if x["ok"] is False else "none"] += 1
                why = (x.get("e") or [0, "?"])[1]
                if why in ("day", "limit"):
                    c["day"] += 1
                elif why.startswith("beach check"):
                    c["beach"] += 1
                    fails.append((r["key"], x["k"], x["e"]))
                else:
                    c["other"] += 1
                    others.append((r["key"], x["k"], x["e"]))
                nb += len(x["b"])
                anynut = False
                for i, b in enumerate(x["b"]):
                    n_bites += 1
                    bite_hashes.add(b[2])
                    if "/" in b[1]:
                        probe_diff += 1
                    kinds[b[1]] += 1
                    h = hour_of(ln["clock"], ln["k0"], b[0]) if ln else -1
                    by_hour[h] += 1
                    if "N" in b[1]:
                        nut_hour[h] += 1
                        nut_bite[min(i + 1, 5)] += 1
                        anynut = True
                c["nut"] += anynut
                dogruns += len(x["d"]) // 2
                tails += sum(len(t) // 2 for t in x["t"])
                moved_c += 1 if x.get("p") else 0
                all_casts[(r["key"], x["k"])] = x
        tot.update(c)
        b = P.get(bi, {})
        md.append(f"| {bi} | {b.get('lo', 0) * VI_S:.1f} – {(b.get('hi', 0) + 2) * VI_S:.1f} · {b.get('part', '?')} | {b.get('lines', '?')} | "
                  f"{b.get('casts', '?')} | {c['n']} | {err} | {c['ok']} / {c['bad']} / {c['none']} | {c['day']} / {c['beach']} / {c['other']} | "
                  f"{nb / c['n']:.1f} | {c['nut']} ({100 * c['nut'] / c['n']:.1f}%) |" if c["n"] else f"| {bi} | | | {b.get('casts', '?')} | 0 | {err} | | | | |")
    todo = [b for b in plan.get("blocks", []) if not os.path.exists(out / f"FD_casts_b{b['i']:02d}.jsonl") and b["casts"]]
    md += ["", f"Blocks not started: {len(todo)} ({sum(b['casts'] for b in todo)} casts). Data so far: {size / 1e6:.1f} MB.", ""]
    n = tot["n"]
    S.update(casts=n, hash_bad=tot["bad"], beach_fail=tot["beach"], other_end=tot["other"], nut_casts=tot["nut"], bites=n_bites)
    if n:
        md += ["## 3. The beach check", "",
               f"- {n} casts: **{tot['day']} ran to the limit / the end of the day on the beach at the dock end**, {tot['beach']} were "
               f"stopped by the beach check, {tot['other']} ended another way.",
               f"- Cast hash = the dog-watch run's state at that frame: {tot['ok']} equal, **{tot['bad']} different**, "
               f"{tot['none']} not compared (cast frames inside a stay-awake push)."]
        for k, kk, e in fails[:10]:
            md.append(f"  - beach check: line {k[:8]} cast {kk}: {e}")
        for k, kk, e in others[:10]:
            md.append(f"  - other end: line {k[:8]} cast {kk}: {e}")
        md += ["", "## 4. Bites and Nuts by game hour (on the held casts)", "",
               f"- {n_bites} bites; released 4 polls after the bite: " + ", ".join(f"{k} {v}" for k, v in kinds.most_common())
               + " (N Nut, s / m / l fish size, d the day ended before the catch, x miss, h held through, o other; a / b = the two release probes differ).",
               f"- The two release probes of bites 1-2 gave different catches on {probe_diff} bites.",
               f"- Nut by bite number: " + ", ".join(f"bite {k if k < 5 else '5+'}: {v}" for k, v in sorted(nut_bite.items())) + ".",
               "", "| game hour | bites | Nut bites | Nut share |", "|---|---|---|---|"]
        for h in list(range(6, 24)) + list(range(0, 6)):
            if by_hour[h]:
                md.append(f"| {h:02d}:00 | {by_hour[h]} | {nut_hour[h]} | {100 * nut_hour[h] / by_hour[h]:.2f}% |")
        md += ["", "These are bites of casts HELD since the cast frame, not fresh casts at that hour: a later hour is",
               "reached only by holding through every earlier bite.", "",
               "## 5. Do the held casts run into each other?", "",
               f"- {n_bites} bite states, {len(bite_hashes)} distinct ({100 * (1 - len(bite_hashes) / max(1, n_bites)):.1f}% "
               f"shared): a shared state has the same future, so its later bites need not be simulated twice.", "",
               "## 6. The dog after the cast", "",
               f"- Visible changes recorded from the cast to the end of its run: {dogruns / n:.0f} per cast; on the released "
               f"paths (the 4 s after each bite): {tails / max(1, n_bites):.1f} per bite.",
               f"- The dog leaves its spot at some point of the run in {moved_c} of {n} casts ({100 * moved_c / n:.0f}%).", ""]
        S.update(bite_states=len(bite_hashes), probe_diff=probe_diff, nut_by_bite=dict(nut_bite))
        # against the dog-watch run's own cast table
        z7 = {}
        for r in rows_of(src / "Z7_casts.jsonl"):
            for cst in r.get("casts", []):
                if cst.get("status") == "ok" and cst.get("hash_ok") is not False:
                    z7[cst["hash"]] = cst
        if z7:
            same = diff = 0
            ex = []
            for fp in files:
                for r in rows_of(fp):
                    hs = {int(k): h for k, h in r["_job"]["casts"]}
                    for x in r.get("casts", []):
                        z = z7.get(hs.get(x["k"]))
                        if not z:
                            continue
                        zb = [(b["bite"] - z["k"], bool(b["nut"])) for b in z["bites"] if b.get("bite") is not None]
                        mb = [(b[0] - x["k"], "N" in b[1]) for b in x["b"][:len(zb)]]
                        if zb == mb:
                            same += 1
                        else:
                            diff += 1
                            if len(ex) < 5:
                                ex.append((r["key"][:8], x["k"], zb[:3], mb[:3]))
            md += ["## 7. Against the dog-watch run's cast table (same state hash)", "",
                   f"- {same + diff} casts are in both: bite times and Nut flags **equal in {same}, different in {diff}**."]
            md += [f"  - {e}" for e in ex]
            md.append("")
            S.update(z7_same=same, z7_diff=diff)
    (out / "FULLDAY.md").write_text("\n".join(md) + "\n")
    json.dump(S, open(out / "fullday_summary.json", "w"), indent=1)
    print("\n".join(md[:60]))
    print(f"-> {out / 'FULLDAY.md'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
