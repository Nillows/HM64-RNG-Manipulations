"""Report for preset zigzag (tools/zigzag_campaign.py): ZIGZAG.md, zigzag_tables.json, zigzag_casttable.csv.

Time base: every member route (beach state, first cut D, second cut B) has its READY (Jack stops at the dock end;
Thomas presses Space) `k_off` VIs after its line representative's READY. A cast `tau` VIs after the member's READY is
the representative's cast k = tau + k_off. Casts exist on even k (one per game frame); odd k are left unknown.
"""
from __future__ import annotations

import csv
import json
import math
import sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tools"))

VI_S = 1 / 60.0


def _rows(p):
    out = []
    if p.exists():
        for line in p.read_text().splitlines():
            if line.strip():
                try:
                    r = json.loads(line)
                except ValueError:
                    continue
                if "_error" not in r and "error" not in r:
                    out.append(r)
    return out


def cast_results(out):
    """hash -> (d1, nut1, d2, nut2) with bite offsets relative to the cast (VIs); checks -> (agree, disagree)."""
    res, agree, disagree = {}, 0, []
    for r in _rows(out / "Z7_casts.jsonl"):
        for c in r.get("casts", []):
            if c["status"] != "ok" or c.get("hash_ok") is False:
                continue
            b = c.get("bites", [])
            v = (None if len(b) < 1 or b[0]["bite"] is None else b[0]["bite"] - c["k"], bool(b and b[0]["nut"]),
                 None if len(b) < 2 or b[1]["bite"] is None else b[1]["bite"] - c["k"],
                 bool(len(b) > 1 and b[1]["nut"]))
            if c["hash"] in res:
                if res[c["hash"]] == v:
                    agree += 1
                else:
                    disagree.append([c["hash"], res[c["hash"]], v, r.get("tag")])
            else:
                res[c["hash"]] = v
    return res, agree, disagree


def line_tables(out, lines, res):
    nat = {r["key"]: r for r in _rows(out / "Z6_lines.jsonl") if r.get("ok")}
    tab = {}
    for key, L in lines.items():
        n = nat.get(key)
        if not n:
            continue
        rows = {}
        for k, h in n["hashes"]:
            if k % 2 or h not in res:
                continue
            d1, n1, d2, n2 = res[h]
            rows[k] = [None if d1 is None else k + d1, n1, None if d2 is None else k + d2, n2]
        tab[key] = rows
    return tab, nat


def lucky(lines, tab, sig_vi=6.0, members_filter=None, tau_max=2390):
    """P(Nut) by aim tau (VIs after the member's READY), cast landing Gaussian (sd sig_vi) around the aim.
    Returns per tau: p_release (release bite 1), p_hold (hold bite 1, release bite 2), p_either (oracle), coverage."""
    W = 0.0
    acc = defaultdict(lambda: [0.0, 0.0, 0.0, 0.0])
    for key, L in lines.items():
        t = tab.get(key)
        if not t:
            continue
        for m in L["members"]:
            if members_filter and not members_filter(m):
                continue
            if "k_off" not in m:
                continue
            W += m["w"]
            for tau in range(6, tau_max + 1, 2):
                k = tau + m["k_off"]
                r = t.get(k) if k % 2 == 0 else (t.get(k - 1) or t.get(k + 1))
                a = acc[tau]
                if r is None:
                    continue
                a[3] += m["w"]
                a[0] += m["w"] * r[1]
                a[1] += m["w"] * r[3]
                a[2] += m["w"] * (r[1] or r[3])
    taus = sorted(acc)
    if not W or not taus:
        return {"W": 0, "rows": []}
    # gaussian smoothing over tau (cast spread)
    def smooth(i):
        if sig_vi <= 0:
            return [acc[taus[i]][j] / max(acc[taus[i]][3], 1e-12) for j in range(3)] + [acc[taus[i]][3] / W]
        num = [0.0, 0.0, 0.0]
        den = 0.0
        for j in range(max(0, i - 12), min(len(taus), i + 13)):
            g = math.exp(-0.5 * ((taus[j] - taus[i]) / sig_vi) ** 2)
            a = acc[taus[j]]
            if a[3] <= 0:
                continue
            for q in range(3):
                num[q] += g * a[q] / a[3]
            den += g
        return [x / den if den else 0.0 for x in num] + [acc[taus[i]][3] / W]
    rows = [[taus[i]] + smooth(i) for i in range(len(taus))]
    return {"W": W, "rows": rows}


def best(rows, col, min_cov=0.0):
    """best aim; min_cov: only aims where at least that share of the (filtered) pool has a cast table (partial runs:
    a thinly covered moment can show a meaningless 100%)."""
    rows = [x for x in rows if x[4] >= min_cov] if rows else rows
    if not rows:
        return None
    r = max(rows, key=lambda x: x[col])
    return {"tau": r[0], "s": round(r[0] * VI_S, 2), "p": round(r[col], 4), "coverage": round(r[4], 3)}


# ------------------------------------------------------------------------------------------------ dog-spot lab
STAGE_SHORT = {1: "house", 2: "farm", 3: "crossroads", 4: "ranch", 5: "beach"}


def _cluster(pts, q=8):
    """[(x, z, map), ...] -> [(count, "map M x~X z~Z"), ...] (positions rounded to q units), most common first."""
    c = Counter()
    for x, z, mp in pts:
        c[(mp, int(round(x / q) * q), int(round(z / q) * q))] += 1
    return [(n, f"map {mp} x≈{x} z≈{z}") for (mp, x, z), n in c.most_common()]


def failure_map(out, cfg):
    """Where the recipe of route delays never reaches READY, stage by stage. Mass = uniform human choices over this
    preset's grids (mash phase per rate, rates pooled; (U, V); C; D; B): at every stage the mass of the states kept
    (within the preset's slack band) flows on; the rest ends there as 'slower than the band' or 'never reached'."""
    from zigzag_campaign import menu_rows, mine, ok_rows, beach_rows
    from zigzag_routes import CUT1, D_FIRST
    fm = {"stages": {}}
    # menus -> house states (mass per mash rate T, pooled over T)
    perT = defaultdict(Counter)
    hvi, mfail, mtot, mpos = {}, 0, 0, []
    for r in menu_rows(out, cfg):
        for x in r["rows"]:
            mtot += 1
            if x.get("house"):
                perT[r["T"]][x["house"]] += 1
                hvi[x["house"]] = x["house_vi"]
            else:
                mfail += 1
                perT[r["T"]][None] += 1
    if not hvi:
        fm["stages"]["menus"] = {"runs": mtot, "never": mfail}
        return fm
    h0 = cfg.get("house_ref") or min(hvi.values())
    massH, mass_slow, mass_never = Counter(), 0.0, 0.0
    for T, c in perT.items():
        n = sum(c.values())
        for h, k in c.items():
            w = k / n / len(perT)
            if h is None:
                mass_never += w
            elif cfg.get("house_lo", 0) <= hvi[h] - h0 <= cfg["house_slack"]:
                massH[h] += w
            else:
                mass_slow += w
    fm["stages"]["menus"] = {"runs": mtot, "never": mfail, "mass_kept": sum(massH.values()), "mass_slow": mass_slow,
                             "mass_never": mass_never, "where": []}
    # house (U, V) -> farm states
    z2 = {r["h"]: r for r in mine(ok_rows(out / "Z2_house.jsonl"), cfg, Us="Us", Vs="Vs")}
    rels = [row[2] for h in massH for row in z2.get(h, {}).get("rows", []) if row[2] is not None]
    fmin = min(rels) if rels else 0

    def flow(parent_mass, rows_of, rel_of, child_of, slack, fail_pts):
        kept, slow, never, runs, nev = Counter(), 0.0, 0.0, 0, 0
        for p, w in parent_mass.items():
            rows = rows_of(p)
            if rows is None:                             # job not run yet (partial report)
                continue
            if not rows:
                never += w
                continue
            for row in rows:
                runs += 1
                rel = rel_of(row)
                if rel is None:
                    never += w / len(rows)
                    nev += 1
                elif rel <= slack:
                    kept[child_of(row)] += w / len(rows)
                else:
                    slow += w / len(rows)
        return kept, slow, never, runs, nev
    massF, slow, never, runs, nev = flow(massH, lambda h: z2[h]["rows"] if h in z2 else None,
                                         lambda row: None if row[2] is None else row[2] - fmin, lambda row: row[3],
                                         cfg["farm_slack"], None)
    pts = [(f[2], f[3], f[4]) for h in massH for f in z2.get(h, {}).get("fails", [])]
    fm["stages"]["house"] = {"runs": runs, "never": nev, "mass_kept": sum(massF.values()), "mass_slow": slow,
                             "mass_never": never, "where": _cluster(pts)[:6], "fastest": fmin}
    # crossroads C -> ranch states (a farm walk that never reaches the crossroads fails every C)
    z3 = {r["f"]: r for r in mine(ok_rows(out / "Z3_cross.jsonl"), cfg, Cs="Cs")}
    rels = [row[1] for f in massF for row in z3.get(f, {}).get("rows", []) if row[1] is not None]
    rmin = min(rels) if rels else 0

    def rows3(f):
        r = z3.get(f)
        if r is None:
            return None
        if r.get("farm_fail"):
            return [[c, None, None, None] for c in cfg["Cs"]]
        return r["rows"]
    massR, slow, never, runs, nev = flow(massF, rows3, lambda row: None if row[1] is None else row[1] - rmin,
                                         lambda row: row[2], cfg["ranch_slack"], None)
    pts = [(f[1], f[2], f[3]) for fk in massF for f in z3.get(fk, {}).get("fails", [])]
    farm_fails = [z3[fk]["farm_fail"] for fk in massF if z3.get(fk, {}).get("farm_fail")]
    pts += [(f[0], f[1], f[2]) for f in farm_fails]
    fm["stages"]["crossroads"] = {"runs": runs, "never": nev, "mass_kept": sum(massR.values()), "mass_slow": slow,
                                  "mass_never": never, "where": _cluster(pts)[:6], "farm_walk_fails": len(farm_fails),
                                  "fastest": rmin}
    # ranch -> beach states
    z4 = {r["r"]: r for r in ok_rows(out / "Z4_ranch.jsonl")}
    massB, never, nev, pts = Counter(), 0.0, 0, []
    for rr, w in massR.items():
        r = z4.get(rr)
        if r is None:
            continue
        if r.get("b"):
            massB[r["b"]] += w
        else:
            never += w
            nev += 1
            if r.get("fail"):
                pts.append((r["fail"][0], r["fail"][1], r["fail"][2]))
    fm["stages"]["ranch"] = {"runs": len(massR), "never": nev, "mass_kept": sum(massB.values()), "mass_slow": 0.0,
                             "mass_never": never, "where": _cluster(pts)[:6]}
    if cfg.get("Ws"):                                    # lineup lab: beach starts = beach state x wait W
        massB = Counter({f"{b}@w{w}": v / len(cfg["Ws"]) for b, v in massB.items() for w in cfg["Ws"]})
    # beach: D uniform over the D grid; a D "reaches" if some B in the grid reaches the dock end
    wantD = sorted(d for d in cfg["Ds"] if d <= cfg.get("D_max", 10 ** 6))
    z5 = beach_rows(out, cfg["Bs"])
    reach, never, why, perD, pts = 0.0, 0.0, Counter(), defaultdict(lambda: [0.0, 0.0, Counter(), []]), []
    nev, runs = 0, 0
    perDB = defaultdict(lambda: defaultdict(lambda: [0.0, 0.0, Counter(), []]))
    bands = defaultdict(lambda: [0.0, 0.0])
    band_of = lambda D: "early" if D < D_FIRST else next(i for i, *_r, f in CUT1 if f((D - D_FIRST) // 2))
    for b, w in massB.items():
        e = z5.get(b)
        if not e:
            continue
        for D in wantD:
            row = e["rows"].get(D)
            brow = [x for x in (row[6] if row else []) if x[0] in cfg["Bs"]]
            ok = [x[0] for x in brow if x[1] is not None]
            wd = w / len(wantD)
            for x in brow:
                c = perDB[D][x[0]]
                c[0] += w
                if x[1] is not None:
                    c[1] += w
                else:
                    c[2][x[-1] if isinstance(x[-1], str) else "no READY"] += w
                    c[3].append((x[2], x[3], 9))
            runs += 1
            perD[D][0] += wd
            bands[band_of(D)][0] += wd
            if ok:
                reach += wd
                perD[D][1] += wd
                bands[band_of(D)][1] += wd
                perD[D][3].append(len(ok))
            else:
                never += wd
                nev += 1
                for x in brow:
                    why[x[-1] if isinstance(x[-1], str) else "no READY"] += 1
                    perD[D][2][x[-1] if isinstance(x[-1], str) else "no READY"] += 1
                    pts.append((x[2], x[3], 9))
    tot = reach + never
    fm["stages"]["beach"] = {"runs": runs, "never": nev, "mass_kept": reach, "mass_never": never,
                             "mass_slow": 0.0, "where": _cluster(pts)[:6], "why": dict(why)}
    fm["beach_D"] = {D: {"p_reach": (v[1] / v[0]) if v[0] else None, "why": dict(v[2]),
                         "window_vis": sorted(Counter(v[3]).items())} for D, v in sorted(perD.items())}
    segs = {}
    for D, byB in sorted(perDB.items()):
        out_, cur = [], None
        for B in sorted(byB):
            tot_, rd, wc, ps = byB[B]
            share = rd / tot_ if tot_ else 0.0
            cls = "READY" if share >= 1 - 1e-9 else ("partly READY" if share > 1e-9 else
                                                    (wc.most_common(1)[0][0] if wc else "no READY"))
            if cur and cur["class"] == cls and cur["hi"] == B - 1:
                cur["hi"] = B
                cur["_s"].append(share)
                cur["_p"] += ps
            else:
                cur = {"lo": B, "hi": B, "class": cls, "_s": [share], "_p": list(ps)}
                out_.append(cur)
        for c in out_:
            c["ready_share"] = round(sum(c.pop("_s")) / (c["hi"] - c["lo"] + 1), 3)
            pts_ = c.pop("_p")
            c["where"] = _cluster(pts_)[0][1] if pts_ else None
        segs[D] = out_
    fm["beach_B"] = segs
    fm["beach_cut1"] = {k: {"p_reach": v[1] / v[0] if v[0] else None, "mass": v[0] / tot if tot else 0}
                        for k, v in bands.items()}
    fm["p_ready"] = reach                                # mass of the whole recipe that reaches the dock end
    return fm


def collapse_stats(lines):
    """How the members of each beach state spread over dog lines (1 line per beach state = everything collapsed)."""
    per_b = defaultdict(set)
    spread = []
    for lid, L in lines.items():
        offs = [m["k_off"] for m in L["members"] if "k_off" in m]
        if offs:
            spread.append(max(offs) - min(offs))
        for m in L["members"]:
            if "k_off" in m:
                per_b[m["b"]].add(lid)
    c = Counter(len(v) for v in per_b.values())
    return {"beach_states": len(per_b), "lines": len(lines), "lines_per_beach_state": sorted(c.items()),
            "collapsed_states": c.get(1, 0), "k_off_spread_max": max(spread) if spread else None,
            "unresolved": sum(1 for L in lines.values() for m in L["members"] if "k_off" not in m)}


def cut_groups(lines, tab, sig_ms=150):
    """The web app's cut presets (tools/zigzag_routes.groups_def: all, 1st cut tight/mid/loose, x 2nd cut
    early/middle/late): route share and the best aim for release / hold / either at this cast spread."""
    from zigzag_routes import groups_def
    allm = [m for L in lines.values() for m in L["members"] if "k_off" in m]
    W = sum(m["w"] for m in allm) or 1.0
    out = []
    for gid, label, band, desc, ax, f in groups_def():
        Wg = sum(m["w"] for m in allm if f(m))
        if Wg <= 0:
            out.append({"id": gid, "label": label, "share": 0.0})
            continue
        L_ = lucky(lines, tab, sig_vi=sig_ms / 1000 * 60, members_filter=f)
        out.append({"id": gid, "label": label, "band": band, "share": Wg / W, "release": best(L_["rows"], 1, 0.8),
                    "hold": best(L_["rows"], 2, 0.8), "either": best(L_["rows"], 3, 0.8)})
    return out


def _route_times(info):
    from zigzag_campaign import route_times
    return route_times(info)


def _conc(ws):
    ws = sorted(ws, reverse=True)
    tot = sum(ws) or 1.0
    c, n50, n90 = 0.0, None, None
    for i, w in enumerate(ws, 1):
        c += w / tot
        if n50 is None and c >= 0.5:
            n50 = i
        if n90 is None and c >= 0.9:
            n90 = i
    return {"lines": len(ws), "top": ws[0] / tot if ws else 0, "n50": n50, "n90": n90}


def lineup_sections(out, cfg, lines, tab, nat, sig_ms=150):
    """Lineup lab (presets lineup-*): stability, the dog's activation point (first VI its tile is on the camera's
    visibility grid, and where Jack is then), the beach wait W, the second cut over the full pier width, and whether the
    dog keeps drawing after READY. Odds = best aim at a 150 ms cast spread (release bite 1 / hold to bite 2)."""
    md, summ = [], {}
    allm = [(lid, m) for lid, L in lines.items() for m in L["members"] if "k_off" in m]
    if not allm:
        return md, summ
    W = sum(m["w"] for _, m in allm)
    f = lambda b: f"{b['p'] * 100:.2f}% at {b['s']} s (cover {b['coverage']:.2f})" if b else "- (cover < 0.8)"

    def odds(flt):
        L_ = lucky(lines, tab, sig_vi=sig_ms / 1000 * 60, members_filter=flt)
        return best(L_["rows"], 1, 0.8), best(L_["rows"], 2, 0.8)

    def lines_of(flt):
        return len({lid for lid, m in allm if flt(m)})
    cs = _conc([L["w"] for L in lines.values()])
    per_start, per_wb, segs = defaultdict(set), defaultdict(set), defaultdict(lambda: defaultdict(set))
    for lid, m in allm:
        per_start[m["b"]].add(lid)
        per_wb[(m.get("W", 0), m["B"])].add(lid)
        segs[m["b"]][lid].add(m["B"])
    cs["lines_per_start"] = sorted(Counter(len(v) for v in per_start.values()).items())
    cs["lines_per_wait_cut"] = sorted(Counter(len(v) for v in per_wb.values()).items())
    shapes = Counter()
    for b, d in segs.items():
        shapes[" + ".join(f"B {min(v)}-{max(v)}" for v in sorted(d.values(), key=min))] += 1
    cs["start_shapes"] = shapes.most_common(4)
    summ["stability"] = cs
    md += ["## Lineup: stability", "",
           f"- {cs['lines']} lines; the heaviest holds {cs['top'] * 100:.1f}% of the routes; {cs['n50']} lines hold 50% and "
           f"{cs['n90']} hold 90% (fewer = steadier dog)",
           "- one beach start (beach state + wait) across the full pier width: lines (count of starts) "
           + ", ".join(f"{k}: {n}" for k, n in cs["lines_per_start"]) + "; how the second cuts split: "
           + "; ".join(f"{sh} ({n} starts)" for sh, n in cs["start_shapes"]),
           "- one wait + second cut across the beach states (the route before the beach): lines (count) "
           + ", ".join(f"{k}: {n}" for k, n in cs["lines_per_wait_cut"]), ""]
    # dog after READY (natural path of each line)
    act = []
    for lid, L in lines.items():
        n = nat.get(lid) or {}
        d = n.get("draws") or []
        if len(d) >= 2:
            k0, d0 = d[0]
            k1, d1 = d[-1]
            span_vis = max(1, len(n.get("lhashes") or []) + 4)
            act.append((L["w"], (d1 - d0) - (k1 - k0) // 2, min(1.0, n.get("dog_visible_vis", 0) / span_vis), k1 - k0))
    if act:
        wt = sum(a[0] for a in act) or 1.0
        keep = sum(a[0] for a in act if a[1] > 0) / wt
        mean = sum(a[0] * a[1] for a in act) / wt
        span = round(max(a[3] for a in act) / 60)
        summ["after_ready"] = {"share_dog_drawing": keep, "mean_extra_draws_40s": mean, "span_s": span,
                               "mean_dog_visible": sum(a[0] * a[2] for a in act) / wt}
        md += ["## Lineup: does the dog keep drawing after READY (standing at the pier, no cast)?", "",
               f"- routes whose line has the dog drawing after READY: **{keep * 100:.1f}%**; extra draws over {span} s "
               f"(above the 1-per-game-frame clock), route-weighted mean {mean:.0f}; dog's tile visible "
               f"{summ['after_ready']['mean_dog_visible'] * 100:.0f}% of the time", ""]
    # activation point
    vm = [(lid, m) for lid, m in allm if m.get("vis") and m["vis"][0] is not None]
    if vm:
        vis_vi = Counter()
        for _, m in vm:
            vis_vi[m["vis"][0]] += m["w"]
        md += ["## Lineup: where the dog activates (its tile enters the camera's view; until then it draws nothing)", "",
               "First VI after the beach load (share of routes): " +
               ", ".join(f"{k}: {v / W * 100:.1f}%" for k, v in sorted(vis_vi.items())), ""]
        buck = defaultdict(list)
        for lid, m in vm:
            buck[(int(m["vis"][1] // 8 * 8), int(m["vis"][2] // 8 * 8))].append(m)
        md += ["| Jack at the activation (x, z; 8-unit cells) | share of routes | lines | release bite 1 | hold to bite 2 |",
               "|---|---|---|---|---|"]
        rows_ = []
        for (bx, bz), ms in sorted(buck.items(), key=lambda kv: -sum(m["w"] for m in kv[1])):
            sh = sum(m["w"] for m in ms) / W
            if sh < 0.005:
                continue
            ids = {id(m) for m in ms}
            flt = (lambda ids_: (lambda m: id(m) in ids_))(ids)
            r1, r2 = odds(flt)
            rows_.append({"x": bx, "z": bz, "share": sh, "lines": lines_of(flt), "release": r1, "hold": r2})
            md.append(f"| x {bx}…{bx + 8}, z {bz}…{bz + 8} | {sh:.3f} | {rows_[-1]['lines']} | {f(r1)} | {f(r2)} |")
        md.append("")
        summ["activation"] = rows_
    # beach wait W
    Ws = sorted({m.get("W", 0) for _, m in allm})
    md += ["## Lineup: beach wait W (VIs Jack stands still at the beach load before his first step)", "",
           "| W (VIs) | share of routes | lines | release bite 1 | hold to bite 2 |", "|---|---|---|---|---|"]
    wrows = []
    for w in Ws:
        flt = (lambda w_: (lambda m: m.get("W", 0) == w_))(w)
        sh = sum(m["w"] for _, m in allm if flt(m)) / W
        r1, r2 = odds(flt)
        wrows.append({"W": w, "share": sh, "lines": lines_of(flt), "release": r1, "hold": r2})
        md.append(f"| {w} | {sh:.3f} | {wrows[-1]['lines']} | {f(r1)} | {f(r2)} |")
    md.append("")
    summ["waits"] = wrows
    # first cut D (zigzag-4b: D 84 scrapes the small wall's corner, D 86 clears it one game frame later)
    Ds_ = sorted({m["D"] for _, m in allm})
    if len(Ds_) > 1:
        md += ["## Lineup: first cut D (VIs of down-right after the beach load, before the cut down-left)", "",
               "D 84 = the earliest cut that clears the small wall (scrapes its corner: Jack pushed to x -451.6); D 86 = one "
               "game frame later (clears the corner: x -452.0, still the wall column of the dog's view grid).", "",
               "| first cut | share of routes | lines | of them shared with the other cut | dog wakes, VI after the beach load - W "
               "(share) | release bite 1 | hold to bite 2 |", "|---|---|---|---|---|---|---|"]
        lids_by = {d: {lid for lid, m in allm if m["D"] == d} for d in Ds_}
        drows = []
        for d in Ds_:
            flt = (lambda d_: (lambda m: m["D"] == d_))(d)
            ms = [m for _, m in allm if flt(m)]
            sh = sum(m["w"] for m in ms) / W
            wake = Counter()
            for m in ms:
                if m.get("vis") and m["vis"][0] is not None:
                    wake[m["vis"][0] - m.get("W", 0)] += m["w"]
            tw = sum(wake.values()) or 1.0
            other = set().union(*(lids_by[x] for x in Ds_ if x != d))
            r1, r2 = odds(flt)
            drows.append({"D": d, "share": sh, "lines": len(lids_by[d]), "shared": len(lids_by[d] & other),
                          "wake": sorted((k, v / tw) for k, v in wake.items()), "release": r1, "hold": r2})
            md.append(f"| D {d} | {sh:.3f} | {len(lids_by[d])} | {len(lids_by[d] & other)} | "
                      + ", ".join(f"{k} ({v * 100:.0f}%)" for k, v in sorted(wake.items(), key=lambda kv: -kv[1])[:3] for v in [v / tw])
                      + f" | {f(r1)} | {f(r2)} |")
        md.append("")
        summ["first_cut"] = drows
    # W bands x second cut (full pier width; by the dock-end spot, as the web app)
    from zigzag_routes import CUT2
    bands = [("wait 0-9", lambda m: m.get("W", 0) <= 9), ("wait 10-19", lambda m: 10 <= m.get("W", 0) <= 19),
             ("wait 20-30", lambda m: m.get("W", 0) >= 20), ("any wait", lambda m: True)]
    md += ["## Lineup: wait band x second cut (full pier width; early / middle / late = dock-end spot z ≤178 / ≤190 / >190)",
           "", "| wait | 2nd cut | share of routes | lines | release bite 1 | hold to bite 2 |", "|---|---|---|---|---|---|"]
    grows = []
    for bl, bf in bands:
        for gid, label, band, desc, fz in [("any", "any", None, None, lambda z: True)] + list(CUT2):
            flt = (lambda bf_, fz_: (lambda m: bf_(m) and fz_(m["spot"][1])))(bf, fz)
            sh = sum(m["w"] for _, m in allm if flt(m)) / W
            if sh <= 0:
                continue
            r1, r2 = odds(flt)
            grows.append({"wait": bl, "cut2": gid, "share": sh, "lines": lines_of(flt), "release": r1, "hold": r2})
            md.append(f"| {bl} | {label} | {sh:.3f} | {grows[-1]['lines']} | {f(r1)} | {f(r2)} |")
    md.append("")
    summ["bands"] = grows
    return md, summ


def dogspot_sections(out, cfg, lines, tab):
    """Markdown + summary dict for one dog-spot save."""
    md, summ = [], {}
    z0 = out / "Z0_record.json"
    rec = json.loads(z0.read_text()) if z0.exists() else {}
    if rec:
        info = rec["record"]["info"]
        sv, st = info.get("save", {}), info.get("stages", {})
        d1 = st.get("1", {}).get("dog", {})
        end = info.get("end", {})
        got = rec["record"]["got"]
        md += ["## The save", "",
               f"- file `{rec.get('save')}` (sha256 {(rec.get('save_sha256') or '')[:16]})"
               + (f" — **sandbox test poke {rec['test_dog_poke']}**" if rec.get("test_dog_poke") else ""),
               f"- {sv.get('season_name')} {sv.get('day')}, year {sv.get('year')}; weather {sv.get('weather')}; "
               f"{sv.get('hour')}:{sv.get('minutes', 0):02d} at the house load; rod in hand: {sv.get('rod_in_hand')}",
               f"- dog at the house load: **{d1.get('map')}** (map {d1.get('location')}) x {d1.get('x')}, "
               f"z {d1.get('z')}, facing {d1.get('direction')}, flags {', '.join(d1.get('flag_names', [])) or '-'}",
               "- dog on screen at the load of: " + (", ".join(STAGE_SHORT[int(k)] for k, v in sorted(st.items())
                                                            if v.get("dog_here")) or "none of the route screens"),
               f"- repeatable (two cold boots give the same record): **{'yes' if rec.get('deterministic') else 'NO'}**"
               + ("; dog-beach save: zigzag check numbers reproduced" if rec.get("reference_check") else ""),
               "- reference route (mash 10/s START→A, house U276 V52, crossroads C80, beach D86 B134), map loads: "
               + _route_times(info) + "; "
               + (f"READY {got['ready'][0]} VIs after the beach load at x {got['ready'][1]}, z {got['ready'][2]}"
                  if got.get("ready") and end.get("ready_at_dock_end") else
                  f"**no READY** — {end.get('why', 'stopped')} on the "
                  f"{STAGE_SHORT.get(end.get('stage'), end.get('stage'))} at {end.get('pos')}"), ""]
        summ["save"] = {"file": rec.get("save"), "sha256": rec.get("save_sha256"), "date": sv, "dog": d1,
                        "dog_screens": [STAGE_SHORT[int(k)] for k, v in sorted(st.items()) if v.get("dog_here")],
                        "deterministic": rec.get("deterministic"), "reference_check": rec.get("reference_check"),
                        "reference_ready": got.get("ready") if end.get("ready_at_dock_end") else None,
                        "test_dog_poke": rec.get("test_dog_poke")}
    fm = failure_map(out, cfg)
    summ["failures"] = fm
    if fm["stages"]:
        md += ["## Failure map: where the recipe never reaches READY", "",
               "Mass = uniform choices over this preset's grids (mash phase per rate, rates pooled; house U, V; "
               "crossroads C; first cut D; any second cut B). Each stage starts from the mass kept by the stage before.",
               "", "| stage | runs | never reached | mass kept | outside the band (slower; or faster for a 5-9-frame preset) | never reached (mass) | where Jack "
               "stopped (most common) |", "|---|---|---|---|---|---|---|"]
        for name in ("menus", "house", "crossroads", "ranch", "beach"):
            v = fm["stages"].get(name)
            if not v:
                continue
            where = "; ".join(f"{n}× {p}" for n, p in v.get("where", [])[:3]) or "-"
            md.append(f"| {name} | {v.get('runs')} | {v.get('never', '-')} | {v.get('mass_kept', 0):.4f} | "
                      f"{v.get('mass_slow', 0):.4f} | {v.get('mass_never', 0):.4f} | {where} |")
        md += ["", f"- **mass of the recipe that reaches the dock end: {fm.get('p_ready', 0):.4f}** "
               "(the D grid includes 82–83, which never clear the small wall on the dog-beach save)", ""]
        if fm.get("beach_D"):
            md += ["| first cut D | P(some B reaches the dock end) | B in the window (VIs: count of beach states) | "
                   "why the other B stop (D without a window) |", "|---|---|---|---|"]
            for D, v in fm["beach_D"].items():
                md.append(f"| {D} | {v['p_reach']:.3f} | " + (", ".join(f"{k}: {n}" for k, n in v["window_vis"]) or "-")
                          + " | " + (", ".join(f"{k} {n}" for k, n in sorted(v["why"].items())) or "-") + " |")
            md.append("")
            md += ["Second cut B by first cut D (share of the beach-state mass that reaches the dock end; else why Jack "
                   "stopped, and where):", ""]
            for D, sg in fm.get("beach_B", {}).items():
                md.append(f"- D {D}: " + " · ".join(
                    f"{c['lo']}–{c['hi']} {c['class']}"
                    + (f" {c['ready_share'] * 100:.0f}%" if c["class"] == "partly READY" else "")
                    + (f" ({c['where']})" if c["class"] not in ("READY",) and c.get("where") else "") for c in sg))
            md.append("")
            md += ["| 1st cut (web app bands) | share of the D grid | P(a 2nd cut reaches the dock end) |", "|---|---|---|"]
            for k in ("early", "tight", "mid", "loose"):
                v = fm["beach_cut1"].get(k)
                if v:
                    md.append(f"| {k} | {v['mass']:.3f} | {v['p_reach']:.3f} |")
            md.append("")
    if lines:
        cs = collapse_stats(lines)
        summ["collapse"] = cs
        md += ["## Lines (dog-neutral: anchored at the beach load, matched by game state at READY)", "",
               f"- {cs['lines']} lines from {cs['beach_states']} beach states; lines per beach state "
               f"(count of states): {', '.join(f'{k}: {n}' for k, n in cs['lines_per_beach_state'])}; "
               f"**{cs['collapsed_states']} of {cs['beach_states']} beach states collapse to one line** "
               f"(every first and second cut of that state shares one RNG trajectory, offset in time only)",
               f"- largest READY offset inside a line: {cs['k_off_spread_max']} VIs; members not matched to any path: "
               f"{cs['unresolved']}", ""]
        groups = cut_groups(lines, tab)
        summ["groups"] = groups
        f = lambda b: f"{b['p'] * 100:.2f}% at {b['s']} s" if b else "-"
        md += ["## Cut timing, split as the web app does (cast spread 150 ms)", "",
               "| preset | share of routes | release bite 1 | hold to bite 2 | either (upper bound) |",
               "|---|---|---|---|---|"]
        for g in groups:
            md.append(f"| {g['label']} | {g['share']:.3f} | {f(g.get('release'))} | {f(g.get('hold'))} | "
                      f"{f(g.get('either'))} |")
        md.append("")
    return md, summ


def write(out, cfg, preset):
    out = Path(out)
    neutral = bool(cfg.get("neutral"))
    lp = out / "zz_lines.json"
    lines = json.loads(lp.read_text()) if lp.exists() else {}
    res, agree, disagree = cast_results(out)
    tab, nat = line_tables(out, lines, res)
    md = [f"# Preset {preset}: zig-zag route, dog-beach save", ""]
    summ, summary = {}, {}
    if neutral:
        z0 = out / "Z0_record.json"
        name = json.loads(z0.read_text()).get("save") if z0.exists() else "?"
        md = [f"# Dog-spot lab ({preset}): {name}", "",
              "Zig-zag route with the zigzag-fast recipe of route delays, dog-neutral (no dog-wake rule or key: every "
              "first / second cut is walked and kept, lines are anchored at the beach load and matched by game state "
              "at READY).", ""]
        sec, summ = dogspot_sections(out, cfg, lines, tab)
        md += sec
        if cfg.get("Ws"):
            sec2, lu = lineup_sections(out, cfg, lines, tab, nat)
            md += sec2
            summ["lineup"] = lu
    chk = out / "Z0_check.json"
    if chk.exists() and not neutral:
        c = json.loads(chk.read_text())
        md += [f"- **Check** (reference route from power-on): {'OK' if c.get('ok') else 'MISMATCH'} — got {c.get('got')}", ""]
    z1 = _rows(out / "Z1_menus.jsonl")
    if z1:
        md += ["## Menus (mash until the house loads)", "",
               "| style | presses/s | held VIs | house arrival VI (count of phases) |", "|---|---|---|---|"]
        for r in sorted(z1, key=lambda r: (r["style"], r["T"], r["h"])):
            cnt = Counter(x.get("house_vi") for x in r["rows"])
            md.append(f"| {r['style']} | {60 / r['T']:.1f} | {r['h']} | " +
                      ", ".join(f"{k}×{v}" if k else f"none×{v}" for k, v in sorted(cnt.items(), key=lambda kv: kv[0] or 0)) + " |")
        md.append("")
    z2 = [r for r in _rows(out / "Z2_house.jsonl")
          if tuple(r["_job"].get("Us", ())) == tuple(cfg["Us"]) and tuple(r["_job"].get("Vs", ())) == tuple(cfg["Vs"])]
    if z2:
        cnt = Counter(row[2] for r in z2 for row in r["rows"])
        md += ["## House (up-left U, down-left V, down) — farm arrival, VIs after the house load: count of (U, V) runs",
               "", ", ".join(f"{k}:{v}" for k, v in sorted(cnt.items(), key=lambda kv: (kv[0] is None, kv[0] or 0))), ""]
    z3 = [r for r in _rows(out / "Z3_cross.jsonl") if tuple(r["_job"].get("Cs", ())) == tuple(cfg["Cs"])]
    if z3:
        cnt = Counter(row[1] for r in z3 for row in r["rows"])
        md += ["## Crossroads (left, cut down-left at C) — ranch arrival, VIs after the farm load: count of runs", "",
               ", ".join(f"{k}:{v}" for k, v in sorted(cnt.items(), key=lambda kv: (kv[0] is None, kv[0] or 0))), ""]
    from zigzag_campaign import beach_rows                  # zigzag-3: rows merged per (beach state, D)
    wantD = {d for d in cfg["Ds"] if d <= cfg.get("D_max", 10 ** 6)}
    z5 = beach_rows(out, cfg["Bs"])
    if z5:
        perD = defaultdict(lambda: [0, Counter(), set()])
        for b, e in z5.items():
            for D, row in e["rows"].items():
                if D not in wantD:
                    continue
                D_, wake_rel, wd, ko, key, late, brow = row
                ready = [x[0] for x in brow if x[1] is not None and x[0] in cfg["Bs"]]
                perD[D][0] += len(ready)
                perD[D][1][wake_rel] += 1
                if ready:
                    perD[D][2].add((min(ready), max(ready)))
        md += ["## Beach (first cut D, second cut B; VIs after the beach load)", "",
               f"| D | {'dog first moved' if neutral else 'dog wake'}, VIs after the beach load (count) | "
               "B reaching the dock end (total) | READY windows (B) |",
               "|---|---|---|---|"]
        for D in sorted(perD):
            a, w, win = perD[D]
            md.append(f"| {D} | {', '.join(f'{k}×{v}' for k, v in sorted(w.items(), key=lambda kv: kv[0] or 0))} | {a} | "
                      f"{', '.join(f'{lo}–{hi}' for lo, hi in sorted(win))} |")
        md.append("")
    if lines:
        tot = sum(L["w"] for L in lines.values())
        md += [f"## Dog lines: {len(lines)} (members = beach state × D × B that reach the dock end)", "",
               f"- casts evaluated: {len(res)} distinct states; repeat checks agree {agree}, disagree {len(disagree)}",
               "", f"| line | weight | members | {'beach draw' if neutral else 'wake draw'} | READY spread (VIs) | casts | "
               "Nut casts b1 / b2 |",
               "|---|---|---|---|---|---|---|"]
        for key in sorted(lines, key=lambda k: -lines[k]["w"])[:40]:
            L = lines[key]
            t = tab.get(key, {})
            offs = [m.get("k_off") for m in L["members"] if "k_off" in m]
            md.append(f"| {key} | {L['w'] / tot:.3f} | {len(L['members'])} | {L['rep'].get('wake_draw')} | "
                      f"{(max(offs) - min(offs)) if offs else '-'} | {len(t)} | "
                      f"{sum(1 for v in t.values() if v[1])} / {sum(1 for v in t.values() if v[3])} |")
        md.append("")
        md += ["## Lucky Timer, whole pool (aim = time after READY at the dock end; cast spread 1 s.d.)", "",
               "| spread | release bite 1 | hold to bite 2 | either (smart, upper bound) | coverage at best |",
               "|---|---|---|---|---|"]
        summary = {}
        for sd_ms in (0, 100, 150, 250):
            L_ = lucky(lines, tab, sig_vi=sd_ms / 1000 * 60)
            b1, b2, be = best(L_["rows"], 1), best(L_["rows"], 2), best(L_["rows"], 3)
            summary[sd_ms] = {"release": b1, "hold": b2, "either": be}
            f = lambda b: f"{b['p'] * 100:.1f}% at {b['s']} s" if b else "-"
            md.append(f"| {sd_ms} ms | {f(b1)} | {f(b2)} | {f(be)} | {be['coverage'] if be else '-'} |")
        md.append("")
        tables = {"preset": preset, "lines": {}, "summary": summary}
        for key, L in lines.items():
            tables["lines"][key] = {
                "w": L["w"], "late": L.get("late"), "rep": L["rep"],
                "members": [{q: m.get(q) for q in ("b", "D", "B", "k_off", "r", "spot", "w", "slack", "wake_draw")}
                            for m in L["members"]],
                "casts": {str(k): v for k, v in sorted(tab.get(key, {}).items())}}
        (out / "zigzag_tables.json").write_text(json.dumps(tables))
        with open(out / "zigzag_casttable.csv", "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["line", "k_after_rep_ready", "bite1_k", "nut1", "bite2_k", "nut2"])
            for key, t in tab.items():
                for k, v in sorted(t.items()):
                    w.writerow([key, k] + v)
        z8 = _rows(out / "Z8_members.jsonl")
        if z8:
            agree8, dis8, nolook = 0, [], 0
            for r in z8:
                t = tab.get(r["line"], {})
                koff = r["_job"].get("k_off", 0)
                for c in r["casts"]:
                    if c.get("status") != "ok":
                        continue
                    k = c["tau"] + koff
                    v = t.get(k)
                    if v is None:
                        nolook += 1
                        continue
                    mine = [None if c["d1"] is None else k + c["d1"], c["n1"], None if c["d2"] is None else k + c["d2"], c["n2"]]
                    if mine == v:
                        agree8 += 1
                    else:
                        dis8.append([r["line"], r["b"], r["D"], r["B"], c["tau"], mine, v])
            md += [f"- **Member recast check** (casts from members' own routes vs the shared line table): "
                   f"agree {agree8}, disagree {len(dis8)}, no table entry {nolook}", ""]
            md += [f"  - {d}" for d in dis8[:20]]
        if disagree:
            md += ["## Repeat-cast disagreements (shared states gave different results)", ""] + \
                  [f"- {d}" for d in disagree[:20]] + [""]
    if neutral:
        summ["lines"] = len(lines)
        summ["members"] = sum(len(L["members"]) for L in lines.values())
        summ["casts"] = len(res)
        summ["nut_casts"] = [sum(1 for v in res.values() if v[1]), sum(1 for v in res.values() if v[3])]
        rd = [m.get("ready_draw") for L in lines.values() for m in L["members"] if m.get("ready_draw") is not None]
        summ["ready_draws"] = [min(rd), max(rd), len(set(rd))] if rd else None    # RNG draw index at READY (the nudge)
        nk = sorted(k for t in tab.values() for k, r in t.items() if r[1] or r[3])
        summ["first_nut_cast_vi"] = nk[0] if nk else None
        summ["nut_casts_in_tables"] = [sum(1 for t in tab.values() for r in t.values() if r[1]),
                                       sum(1 for t in tab.values() for r in t.values() if r[3])]
        summ["pool"] = summary
        summ["repeat_checks"] = [agree, len(disagree)]
        z8 = _rows(out / "Z8_members.jsonl")
        summ["member_checks"] = len(z8)
        (out / "dogspot_summary.json").write_text(json.dumps(summ, indent=1, default=str))
        try:
            from zigzag_routes import build
            sv = summ.get("save", {})
            label = Path(sv.get("file") or "save").stem
            rid = "dogspot-" + "".join(ch if ch.isalnum() else "-" for ch in label.lower())[:40]
            d = sv.get("dog", {})
            entry = build(out, rid, f"Dog spot: {label}", note=f"dog at the house load: {d.get('map')} x {d.get('x')} "
                          f"z {d.get('z')}", save=f"{label}_{(sv.get('sha256') or '')[:8]}",
                          howto="Same zig-zag route and cuts as the dog-beach tables; the dog starts where this save "
                                "puts it.")
            (out / "lucky_route.json").write_text(json.dumps({"routes": [entry]}, separators=(",", ":")))
        except Exception as e:                       # the route entry is optional
            md += ["", f"(Lucky Timer route entry not written: {e})"]
    (out / "ZIGZAG.md").write_text("\n".join(md) + "\n")
