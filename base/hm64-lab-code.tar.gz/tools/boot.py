#!/usr/bin/env python3
"""
Power-on -> title -> Play -> Diary -> in-game, with controllable menu timing,
then save an "anchor" savestate at the first VI the player can move.

Each menu step waits for the screen to be ready (read from RAM), waits the
extra delay you give it, then presses (re-pressing every --retry VIs until
the game reacts). Different delays = different RNG stream positions at the
anchor, which is exactly the variance a human introduces on console.

  python3 tools/boot.py --out states/anchor_d0.st
  python3 tools/boot.py --delays 0,10,0,25 --out states/anchor_d25.st

Prints JSON: anchor VI, stream index, seed, and the VI of every press.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from m64h import Emulator                      # noqa: E402
from hm64 import addresses as A                # noqa: E402
from hm64.lcg import index                     # noqa: E402
from hm64.state import control_regained        # noqa: E402
from tools.common import default_rom, default_sram  # noqa: E402

MAIN_GAME, MAP_LOAD, TITLE, SELECT_GAME = 0x01, 0x02, 0x32, 0x35


def mode(emu):
    return emu.u16(A.MAIN_LOOP_INDEX)


def title_mode(emu):
    return emu.u8(A.TITLE_MODE)


def press_until(emu, button, done, retry=8, hold=3, max_vi=3000, log=None, tag=""):
    """Press `button` (hold VIs) and re-press every `retry` VIs until done(emu)."""
    start = emu.vi
    while emu.vi - start < max_vi:
        if log is not None:
            log.append({"step": tag, "button": button, "vi": emu.vi})
        emu.set_input(button)
        emu.advance(hold)
        emu.release()
        for _ in range(retry):
            emu.advance(1)
            if done(emu):
                return emu.vi
    raise RuntimeError(f"step {tag}: game never reacted to {button}")


def wait_until(emu, cond, max_vi=3000, tag=""):
    if emu.run_until(cond, max_vi) < 0:
        raise RuntimeError(f"timed out waiting for {tag}")
    return emu.vi


def find_first_controllable(emu, coarse=16, max_vi=4000):
    """Leave emu paused at the first VI where the player responds to the stick.

    Coarse pass: checkpoint, probe, jump `coarse` VIs. When a probe succeeds,
    rewind to the checkpoint BEFORE it (still not controllable) and step one
    VI at a time. control_regained() costs exactly one VI per call, so the
    fine pass visits every VI.
    """
    import os
    import shutil
    import tempfile
    tmp = tempfile.mkdtemp(prefix="anchor-", dir="/dev/shm" if os.path.isdir("/dev/shm") else None)
    cks = [os.path.join(tmp, "a.st"), os.path.join(tmp, "b.st")]
    start = emu.vi
    k = 0
    try:
        while True:
            emu.save_state(cks[k % 2])
            if control_regained(emu):
                break
            if emu.vi - start > max_vi:
                raise RuntimeError("player never became controllable")
            emu.advance(coarse)
            k += 1
        emu.load_state(cks[(k - 1) % 2] if k > 0 else cks[0])
        while not control_regained(emu):
            pass
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def boot_to_anchor(emu, delays=(0, 0, 0, 0), intro_start=150, retry=8, load_state_out=None):
    d_intro, d_title, d_play, d_diary = delays
    presses = []
    # 1) skip the intro cutscene
    emu.advance(max(0, intro_start + d_intro - emu.vi))
    press_until(emu, "START", lambda e: mode(e) == TITLE, retry=retry, log=presses, tag="intro")
    # 2) "Push the START"
    wait_until(emu, lambda e: mode(e) == TITLE and title_mode(e) == 0, tag="title idle")
    emu.advance(d_title)
    press_until(emu, "START", lambda e: title_mode(e) != 0, retry=retry, log=presses, tag="title")
    # 3) Play / How to Play  (Play is highlighted by default)
    wait_until(emu, lambda e: title_mode(e) == 3, tag="title menu")
    emu.advance(d_play)
    press_until(emu, "A", lambda e: title_mode(e) != 3 or mode(e) != TITLE, retry=retry,
                log=presses, tag="play")
    # 4) Select a Diary (diary 1 is highlighted by default)
    wait_until(emu, lambda e: mode(e) == SELECT_GAME, tag="diary screen")
    emu.advance(d_diary)
    press_until(emu, "A", lambda e: mode(e) != SELECT_GAME, retry=retry, log=presses, tag="diary")
    # 5) LOAD ANCHOR: the VI the game is in MAP_LOAD, just before the house map
    #    (and the dog entity) initialise. initializeDogEntity() resets the dog
    #    to state 0/timer 0 and makes its first RNG decision in the very next
    #    VI, so this is the last moment where "everything except the seed" is
    #    identical across menu timings. Poke seeds HERE, not later.
    wait_until(emu, lambda e: mode(e) == MAP_LOAD, tag="map load")
    load_seed = emu.u32(A.RAND_SEED)
    load_info = {"load_vi": emu.vi, "load_idx": index(load_seed), "load_seed": f"0x{load_seed:08X}"}
    if load_state_out:
        emu.save_state(load_state_out, meta={**load_info, "delays": list(delays), "kind": "load-anchor"})
    # 6) first VI the player can move: coarse scan with checkpoints, then exact
    wait_until(emu, lambda e: mode(e) == MAIN_GAME, tag="in game")
    find_first_controllable(emu)
    seed = emu.u32(A.RAND_SEED)
    return {"delays": list(delays), **load_info, "anchor_vi": emu.vi, "idx": index(seed),
            "seed": f"0x{seed:08X}", "presses": presses}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--rom", default=default_rom())
    ap.add_argument("--sram", default=default_sram())
    ap.add_argument("--delays", default="0,0,0,0", help="extra VIs before intro,title,play,diary presses")
    ap.add_argument("--retry", type=int, default=8)
    ap.add_argument("--out", required=True, help="control anchor (first VI the player can move)")
    ap.add_argument("--load-out", help="also save the load anchor (MAP_LOAD, before the dog's first decision)")
    ap.add_argument("--visual", action="store_true", help="also save a PNG of the anchor frame")
    a = ap.parse_args()
    delays = tuple(int(x) for x in a.delays.split(","))
    with Emulator(a.rom, sram=a.sram, mode="visual" if a.visual else "fast") as emu:
        info = boot_to_anchor(emu, delays, retry=a.retry, load_state_out=a.load_out)
        emu.save_state(a.out, meta=info)       # snapshot = right after anchor VI
        if a.visual:
            emu.screenshot(Path(a.out).with_suffix(".png"))
    print(json.dumps(info))


if __name__ == "__main__":
    main()
