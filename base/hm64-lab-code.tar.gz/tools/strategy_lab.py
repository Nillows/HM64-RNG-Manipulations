#!/usr/bin/env python3
"""
Strategy lab - test observation strategies (JSON) and search algorithms against recorded ground truth,
without new emulation.

Ground truth (already recorded on the Mac):
  O_observe.jsonl   every arrival, 80 s after READY, no input: what is on screen each VI + hidden state
  W_single.jsonl    per dog path: one C-right press on every game frame 2-30 s, 20 s recorded after it
  W_lines.json, W_ladder.jsonl, A_routes.jsonl
Arrivals on the same dog path are copies shifted by a constant number of VIs (verified: 0 mismatches),
so a press on any arrival maps onto the path's recorded press atlas.

A strategy file (strategies/*.json) says what the runner does and what the tool assumes:
{
  "name": "AD every 10 s",
  "alphabet": "sprite_class" | "pose_group",        what an animation key can tell apart
  "start": {"delay_vi": [10, 40]},                    first AD log, of whatever is on screen, right at READY
  "prior_first_log_vi": [1, 45],                      what the tool assumes about that first log time
  "runner": {"reaction_vi": [10, 25], "min_run_vi": 12, "jitter_vi": 2, "hand_vi": 2, "press_sd_vi": 1,
             "logging": "prompt" | "anytime"},        prompt: a log lands reaction_vi after the change and the
                                                      tool uses that; anytime: any moment while it is on screen
  "steps": [                                          in order; times in seconds after the start log
    {"log": "AD", "trigger": "every_change", "until_s": 8},
    {"log": "AD", "trigger": "next_change", "every_s": 10, "until_s": 60},
    {"log": "D",  "trigger": "clock", "every_s": 5, "until_s": 30},
    {"pulse": true, "at_s": 15, "jitter_s": [0, 2]}
  ]
}
  trigger every_change : log each visible change (reaction after it; animations < min_run missed)
  trigger next_change  : every N s, log the next visible change
  trigger clock        : every N s, log whatever is on screen at that moment
  pulse                : C-right + its key together (at most one pulse; logs after it see the new track)

Search algorithms (scored on the same simulated runs):
  hard  keep (arrival, first-log time) candidates consistent with every log (timing bounds from the runner
        model); clock estimate = middle of the survivors
  soft  same survivors, weighted by how likely each log delay is (normal around the mean reaction);
        clock estimate = weighted mean

Scores (weighted by how many of the 36,014 routes reach each arrival): share and time with the dog path
known, the post-whistle future known (if a pulse), clock error at the end (VIs, RMS and share within
1 / 2 VIs), bits per data point, and the Nut chance this clock error implies on the oracle run's timing
curve (natural casts; press execution error press_sd_vi added).

  python3 tools/strategy_lab.py results/campaign-pulse strategies/*.json
"""
from __future__ import annotations

import csv
import json
import math
import random
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from tools.ident_sim import build as build_obs        # noqa: E402

VI_S = 60.0
POSE_GROUPS = {"movement": [8, 16, 72], "seated": [40, 48, 96, 104, 120, 128],
               "standing": [0, 88, 136, 144, 152, 160, 168, 176, 200], "ground": [80, 112],
               "transitions": [32, 56, 64, 184, 192]}          # v27.7a observer groups
GROUP_OF = {b: i for i, (g, bs) in enumerate(POSE_GROUPS.items()) for b in bs}
# oracle run, stage E2: P(Nut) when the B press lands N(0, sigma VIs) from the target
NUT_CURVE = [(0.0, 1.00), (0.5, 0.99), (1.0, 0.85), (1.5, 0.74), (2.0, 0.63), (3.0, 0.48), (4.0, 0.38),
             (6.0, 0.28), (12.0, 0.12), (30.0, 0.07)]
DEFAULT_RUNNER = {"reaction_vi": [10, 25], "min_run_vi": 12, "jitter_vi": 2, "hand_vi": 2, "press_sd_vi": 1.0,
                  "logging": "prompt"}
REPS = 4


def load_jsonl(p):
    return [json.loads(x) for x in Path(p).read_text().splitlines() if x.strip()] if Path(p).exists() else []


def nut_from_sigma(s):
    for (a, pa), (b, pb) in zip(NUT_CURVE, NUT_CURVE[1:]):
        if s <= b:
            return pa + (pb - pa) * (s - a) / (b - a)
    return NUT_CURVE[-1][1]


# ------------------------------------------------------------------ ground truth
class Truth:
    def __init__(self, out: Path):
        d = build_obs(out)
        self.d = d
        self.sigs, self.T, self.w = d["sigs"], d["T"], d["w"]
        N, T = len(self.sigs), d["T"]
        obs = {r["signature"]: r for r in load_jsonl(out / "O_observe.jsonl") if "_error" not in r}
        # values per VI for both alphabets, and where each visible run started / ends
        self.val = {"sprite_class": d["AD"], "pose_group": np.full((N, T + 2), -1, np.int32)}
        self.face = d["D"]
        self.rstart = np.zeros((N, T + 2), np.int32)
        self.rend = np.zeros((N, T + 2), np.int32)
        self.fstart = np.zeros((N, T + 2), np.int32)
        for i, s in enumerate(self.sigs):
            for t0, t1, scr, cls, base in obs[s]["vis"]:
                a, b = max(t0, 1), min(t1, T + 2)
                if a < b:
                    self.rstart[i, a:b] = t0
                    self.rend[i, a:b] = t1
                    self.val["pose_group"][i, a:b] = -1 if cls is None else scr * 1000 + GROUP_OF.get(base, 9)
            self.val["pose_group"][i, 0] = self.val["pose_group"][i, 1]
            self.rstart[i, 0], self.rend[i, 0] = self.rstart[i, 1], self.rend[i, 1]
            f = self.face[i]
            st = np.zeros(T + 2, np.int32)
            cur = 0
            for t in range(T + 2):
                if t == 0 or f[t] != f[t - 1]:
                    cur = t
                st[t] = cur
            self.fstart[i] = st
        self.runs = d["runs"]
        self.wl = d["wl"]
        # dog paths, representatives and VI offsets arrival -> representative
        lines = json.loads((out / "W_lines.json").read_text()) if (out / "W_lines.json").exists() else []
        idx = {s: i for i, s in enumerate(self.sigs)}
        self.rep_of_root = {}
        for L in lines:
            if L["signature"] in idx:
                self.rep_of_root[int(self.wl[idx[L["signature"]]])] = L["signature"]
        self.line_no = {int(self.wl[idx[L["signature"]]]): L["line"] for L in lines if L["signature"] in idx}
        DRAW = d["DRAW"]
        self.offset = np.zeros(N, np.int32)
        self.rep = [None] * N
        for i, s in enumerate(self.sigs):
            rs = self.rep_of_root.get(int(self.wl[i]))
            if rs is None:
                continue
            r = idx[rs]
            self.rep[i] = rs
            dd = max(int(DRAW[i, 1]), int(DRAW[r, 1])) + 40
            a = int(np.searchsorted(DRAW[i], dd))
            b = int(np.searchsorted(DRAW[r], dd))
            self.offset[i] = b - a                      # rep VI = arrival VI + offset
        # press atlas per representative: rep poll -> row
        self.atlas = defaultdict(dict)
        for r in load_jsonl(out / "W_single.jsonl"):
            if "_error" not in r:
                self.atlas[r["signature"]][r["presses"][-1]] = r
        self.has_pulse = bool(self.atlas)

    def press_row(self, i, t_press):
        """Atlas row for a press read in arrival-VI t_press of arrival i (None if outside the atlas)."""
        rs = self.rep[i]
        if rs is None:
            return None
        p = int(t_press + self.offset[i] - 1)            # poll read during rep VI t is t - 1
        p -= p % 2                                      # an odd poll shares the game frame of the even one before
        return self.atlas[rs].get(p)


# ------------------------------------------------------------------ runner simulation
def runs_after_pulse(row, t_press):
    return [[t0 + t_press - 1, t1 + t_press - 1, scr, cls, base] for t0, t1, scr, cls, base in row["vis"]]


def value_of(run, alphabet, kind):
    t0, t1, scr, cls, base = run
    if kind == "D":
        return scr
    if cls is None:
        return None
    return scr * 1000 + (cls if alphabet == "sprite_class" else GROUP_OF.get(base, 9))


def simulate_runner(truth, i, strat, rnd):
    """Returns (logs, pulse) in arrival VIs. logs: [(t, kind, value, trigger)]; pulse: (t_press, row) or None."""
    R = {**DEFAULT_RUNNER, **strat.get("runner", {})}
    alpha = strat.get("alphabet", "sprite_class")
    runs = [list(r) for r in truth.runs[i]]
    t_s = rnd.randint(*strat.get("start", {}).get("delay_vi", [10, 40]))
    run0 = next((r for r in runs if r[0] <= t_s < r[1]), None)
    if run0 is None or value_of(run0, alpha, "AD") is None:
        return None, None
    logs = [(t_s, "AD", value_of(run0, alpha, "AD"), "clock")]
    pulse = None
    cursor = t_s

    anytime = R.get("logging", "prompt") == "anytime"

    def react(r):
        if anytime:                                   # logged at any moment while the animation is on screen
            return rnd.randint(r[0], r[1] - 1)
        return r[0] + min(rnd.randint(*R["reaction_vi"]), r[1] - r[0] - 1)

    ctrig = "clock" if anytime else "change"          # what the tool may assume about the log's timing

    for st in strat.get("steps", []):
        if st.get("pulse"):
            t_p = t_s + int(st["at_s"] * VI_S) + rnd.randint(*[int(x * VI_S) for x in st.get("jitter_s", [0, 0])])
            row = truth.press_row(i, t_p)
            if row is None:
                return None, None
            pulse = (t_p, row)
            runs = [r for r in runs if r[1] <= t_p] + runs_after_pulse(row, t_p)
            cursor = t_p
            continue
        kind, trig = st["log"], st.get("trigger", "every_change")
        until = t_s + int(st.get("until_s", 60) * VI_S)
        every = int(st.get("every_s", 10) * VI_S)
        if trig == "every_change":
            for r in runs:
                if r[0] <= cursor or r[0] > until:
                    continue
                if r[1] - r[0] < R["min_run_vi"] or value_of(r, alpha, kind) is None:
                    continue
                if kind == "D" and r[2] == next((q[2] for q in runs if q[1] == r[0]), None):
                    continue                                    # direction-only logs only on turns
                logs.append((react(r), kind, value_of(r, alpha, kind), ctrig))
            cursor = until
        else:
            t = cursor + every
            while t <= until:
                if trig == "clock":
                    r = next((q for q in runs if q[0] <= t < q[1]), None)
                    if r is not None and value_of(r, alpha, kind) is not None:
                        logs.append((t, kind, value_of(r, alpha, kind), "clock"))
                else:                                           # next_change
                    r = next((q for k, q in enumerate(runs) if q[0] > t and q[1] - q[0] >= R["min_run_vi"]
                              and value_of(q, alpha, kind) is not None
                              and (kind != "D" or (k > 0 and runs[k - 1][2] != q[2]))), None)   # D: next turn
                    if r is not None and r[0] <= until:
                        logs.append((react(r), kind, value_of(r, alpha, kind), ctrig))
                t += every
            cursor = until
    jit = R["jitter_vi"]
    logs = sorted((t + rnd.randint(-jit, jit) if k else t, kind, v, trig)
                  for k, (t, kind, v, trig) in enumerate(logs))
    return logs, pulse


# ------------------------------------------------------------------ search
def search(truth, strat, logs, pulse, algo, rnd):
    """Returns posterior summary for one simulated run."""
    R = {**DEFAULT_RUNNER, **strat.get("runner", {})}
    alpha = strat.get("alphabet", "sprite_class")
    lo, hi = strat.get("prior_first_log_vi", [1, 45])
    t1 = logs[0][0]
    us = np.arange(lo, hi + 1)
    N = len(truth.sigs)
    T = truth.T
    J, rmin, rmax = R["jitter_vi"], R["reaction_vi"][0], R["reaction_vi"][1]
    mu, sd = (rmin + rmax) / 2.0, max((rmax - rmin) / math.sqrt(12), 1.0)
    V = np.ones((N, len(us)), bool)
    LW = np.zeros((N, len(us)))                                  # log-likelihood for "soft"
    t_press_tool = None
    if pulse is not None:
        t_press_tool = pulse[0] + rnd.randint(-R["hand_vi"], R["hand_vi"])
    pre = [lg for lg in logs if pulse is None or lg[0] < pulse[0]]
    post = [lg for lg in logs if pulse is not None and lg[0] >= pulse[0]]
    vals = truth.val[alpha]
    for t, kind, v, trig in pre:
        tc = us[None, :] + (t - t1)                              # candidate VI of this log
        tc = np.clip(tc, 0, T + 1)
        ok = np.zeros_like(V)
        best = np.full(V.shape, -1e9)
        for j in range(-J, J + 1):
            tt = np.clip(tc + j, 0, T + 1)
            src = vals if kind == "AD" else truth.face
            hit = np.take_along_axis(src, np.broadcast_to(tt, V.shape), axis=1) == v
            if trig == "change":
                start = np.take_along_axis(truth.rstart if kind == "AD" else truth.fstart,
                                           np.broadcast_to(tt, V.shape), axis=1)
                end = np.take_along_axis(truth.rend, np.broadcast_to(tt, V.shape), axis=1)
                lag = tt - start
                early = np.minimum(rmin, np.maximum(end - start - 1, 0))
                hit &= (lag >= early - J) & (lag <= rmax + J)
                ll = -0.5 * ((lag - mu) / sd) ** 2
            else:
                ll = np.zeros(V.shape)
            ok |= hit
            best = np.where(hit, np.maximum(best, ll), best)
        V &= ok
        LW += np.where(ok, best, 0.0)
    ai, ui = np.nonzero(V)
    cand = list(zip(ai.tolist(), us[ui].tolist(), LW[ai, ui].tolist()))
    # after the pulse: each candidate's own press -> its path's atlas row -> predicted stream
    future_known = None
    if pulse is not None:
        keep = []
        for a, u, lw in cand:
            tp = u + (t_press_tool - t1)
            row = truth.press_row(a, tp)
            if row is None:
                continue
            pruns = row["vis"]
            good, extra = True, 0.0
            for t, kind, v, trig in post:
                rel = t - t_press_tool + 1                          # candidate-relative VI after its press
                hit_any = False
                for q in pruns:
                    if q[1] <= rel - J - R["hand_vi"] or q[0] > rel + J + R["hand_vi"]:
                        continue
                    qv = value_of(q, alpha, kind)
                    if qv != v:
                        continue
                    if trig == "change":
                        lag = rel - q[0]
                        early = min(rmin, q[1] - q[0] - 1)
                        if not (early - J - R["hand_vi"] <= lag <= rmax + J + R["hand_vi"]):
                            continue
                        extra = max(extra, -0.5 * ((lag - mu) / sd) ** 2) if not hit_any else extra
                    hit_any = True
                    break
                if not hit_any:
                    good = False
                    break
            if good:
                keep.append((a, u, lw + extra, row["sig"]))
        cand = [(a, u, lw) for a, u, lw, _ in keep]
        future_known = len({s for *_, s in keep}) == 1 if keep else False
    if not cand:
        return None
    t_now = logs[-1][0]
    roots = {int(truth.wl[a]) for a, _, _ in cand}
    rep_now = np.array([u + (t_now - t1) + truth.offset[a] for a, u, _ in cand], float)
    wts = np.array([truth.w[a] for a, _, _ in cand], float)
    if algo == "soft":
        lw = np.array([x for *_, x in cand])
        wts = wts * np.exp(lw - lw.max())
        est = float((wts * rep_now).sum() / wts.sum())
    else:
        est = float((rep_now.min() + rep_now.max()) / 2)
    n_prior = N * len(us)
    return {"path_known": len(roots) == 1, "future_known": future_known, "est": est,
            "width": float(rep_now.max() - rep_now.min()), "cands": len(cand),
            "bits": math.log2(n_prior / len(cand))}


def evaluate(truth, strat, algos=("hard", "soft"), seed=2026):
    rnd = random.Random(seed)
    rows = []
    for i in range(len(truth.sigs)):
        if strat_needs_pulse(strat) and truth.rep[i] is None:
            continue
        for rep in range(REPS):
            logs, pulse = simulate_runner(truth, i, strat, rnd)
            if not logs:
                continue
            t1 = logs[0][0]
            # true rep-time "now" (at the last log)
            true_now = logs[-1][0] + truth.offset[i]
            n_points = len(logs) + (1 if pulse else 0)
            for algo in algos:
                res = search(truth, strat, logs, pulse, algo, random.Random(rnd.random()))
                if res is None:
                    continue
                err = res["est"] - true_now if res["path_known"] else None
                rows.append({"strategy": strat["name"], "algo": algo, "arrival": truth.sigs[i], "weight": float(truth.w[i]),
                             "points": n_points, "duration_s": round((logs[-1][0] - t1) / VI_S, 2),
                             "path_known": res["path_known"], "future_known": res["future_known"],
                             "clock_err_vi": None if err is None else round(err, 2), "width_vi": res["width"],
                             "bits": round(res["bits"], 3), "cands": res["cands"]})
    return rows


def strat_needs_pulse(strat):
    return any(st.get("pulse") for st in strat.get("steps", []))


def summarize(rows, press_sd):
    by = defaultdict(list)
    for r in rows:
        by[(r["strategy"], r["algo"])].append(r)
    out = []
    for (s, a), rs in by.items():
        W = sum(r["weight"] for r in rs)
        known = [r for r in rs if r["path_known"]]
        Wk = sum(r["weight"] for r in known) or 1
        rms = math.sqrt(sum(r["weight"] * r["clock_err_vi"] ** 2 for r in known) / Wk) if known else None
        within = lambda k: sum(r["weight"] for r in known if abs(r["clock_err_vi"]) <= k) / W
        nut = sum(r["weight"] * nut_from_sigma(math.sqrt(r["clock_err_vi"] ** 2 + press_sd ** 2)) for r in known) / W \
            if known else 0.0
        pts = sorted(r["points"] for r in rs)
        fk = [r for r in rs if r["future_known"] is not None]
        out.append({"strategy": s, "algo": a, "runs": len(rs), "data_points_med": pts[len(pts) // 2],
                    "duration_s_med": sorted(r["duration_s"] for r in rs)[len(rs) // 2],
                    "path_known": round(sum(r["weight"] for r in known) / W, 3),
                    "future_known": round(sum(r["weight"] for r in fk if r["future_known"]) / sum(r["weight"] for r in fk), 3) if fk else None,
                    "clock_rms_vi": round(rms, 2) if rms is not None else None,
                    "clock_within_1vi": round(within(1), 3), "clock_within_2vi": round(within(2), 3),
                    "bits_per_point": round(sum(r["weight"] * r["bits"] / r["points"] for r in rs) / W, 2),
                    "nut_est": round(nut, 3)})
    return out


def main():
    out = Path(sys.argv[1])
    files = [Path(p) for p in sys.argv[2:]] or sorted((ROOT / "strategies").glob("*.json"))
    truth = Truth(out)
    all_rows, summ = [], []
    for f in files:
        strat = json.loads(f.read_text())
        if strat_needs_pulse(strat) and not truth.has_pulse:
            print(f"skip {f.name}: needs W_single.jsonl", flush=True)
            continue
        rows = evaluate(truth, strat)
        all_rows += rows
        press_sd = {**DEFAULT_RUNNER, **strat.get("runner", {})}["press_sd_vi"]
        s = summarize(rows, press_sd)
        summ += s
        for x in s:
            print(json.dumps(x), flush=True)
    if all_rows:
        with (out / "strategy_runs.csv").open("w", newline="") as fh:
            wr = csv.DictWriter(fh, fieldnames=list(all_rows[0].keys()))
            wr.writeheader()
            wr.writerows(all_rows)
    (out / "strategy_summary.json").write_text(json.dumps(summ, indent=1))
    L = ["## Strategy lab\n", "Simulated runners on recorded ground truth (no new emulation); route-weighted. "
         "Clock error = tool's estimate of 'now' vs truth when the last data point is entered; Nut estimate = "
         "oracle timing curve at that error plus the press error.\n",
         "| strategy | search | data points | over (s) | path known | post-whistle future known | clock RMS (VI) | "
         "within 1 / 2 VI | bits per point | Nut estimate |", "|---|---|---|---|---|---|---|---|---|---|"]
    for x in summ:
        fk = "-" if x["future_known"] is None else f"{x['future_known']:.0%}"
        L.append(f"| {x['strategy']} | {x['algo']} | {x['data_points_med']} | {x['duration_s_med']} | {x['path_known']:.0%} | "
                 f"{fk} | {x['clock_rms_vi']} | {x['clock_within_1vi']:.0%} / {x['clock_within_2vi']:.0%} | "
                 f"{x['bits_per_point']} | {x['nut_est']:.0%} |")
    text = "\n".join(L) + "\n"
    (out / "STRATEGY.md").write_text(text)
    print(text)


if __name__ == "__main__":
    main()
