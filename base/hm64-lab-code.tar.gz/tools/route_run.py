#!/usr/bin/env python3
"""
Run the cold-boot carry route to the dock "fishing ready" state.

  python3 tools/route_run.py                              # baseline case (all delays 0), v14 beach
  python3 tools/route_run.py --case 0,0,0,0,10,20,4,0 --save states/ready/x.st
  python3 tools/route_run.py --check-v13                  # reproduce the legacy v13 baseline exactly

--case d0,d1,d2,d3,H,C,P,D (polls). Prints JSON with every stage's VI + RNG.
--randomize-interrupt imitates the legacy corpus' emulator setting (mupen
default, wall-clock seeded jitter) - for comparison only; never for science.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from m64h import Emulator                                   # noqa: E402
from hm64.lcg import index                                  # noqa: E402
from hm64.route import BEACH_V13, BEACH_V14, RouteCase, run_route  # noqa: E402
from tools.common import default_rom, default_sram          # noqa: E402

# Legacy native result for case m00000000_h00c00_p00d00 (v13 kit,
# results/case_summaries/m00000000_h00c00_p00d00.json): stage -> (vi, rng)
V13_BASELINE = {
    "cabin": (1050, 2283705492), "breakfast": (1124, 952861150), "pickup": (1322, 3974975389),
    "farm": (1502, 2608945626), "crossroads": (1852, 3397169793), "ranch": (2088, 1102257419),
    "beach_held": (2318, 399897858), "dog_placed": (2652, 3478244680),
    "fishing_ready": (2668, 933428576),
}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--rom", default=default_rom())
    ap.add_argument("--sram", default=default_sram())
    ap.add_argument("--case", default="0,0,0,0,0,0,0,0")
    ap.add_argument("--variant", choices=[BEACH_V14, BEACH_V13], default=BEACH_V14)
    ap.add_argument("--save", help="write a savestate at fishing-ready")
    ap.add_argument("--max-vi", type=int, default=3600)
    ap.add_argument("--randomize-interrupt", action="store_true")
    ap.add_argument("--check-v13", action="store_true")
    a = ap.parse_args()

    vals = [int(x) for x in a.case.split(",")]
    case = RouteCase(*vals, variant=BEACH_V13 if a.check_v13 else a.variant)
    if not case.within_budget():
        print("warning: case outside the legacy budgets (menu<=30, H+C<=60, P+D<=60)", file=sys.stderr)
    with Emulator(a.rom, sram=a.sram, randomize_interrupt=a.randomize_interrupt) as emu:
        res = run_route(emu, case, max_vi=a.max_vi, ready_state_path=a.save)
    for k, s in res["stages"].items():
        if s:
            s["draw_index"] = index(s["rng"])
    if a.check_v13:
        diffs = {k: {"legacy": V13_BASELINE[k], "lab": (s["vi"], s["rng"]) if s else None}
                 for k, s in res["stages"].items() if not s or (s["vi"], s["rng"]) != V13_BASELINE[k]}
        res["v13_check"] = "MATCH" if not diffs else diffs
    print(json.dumps(res, indent=1))


if __name__ == "__main__":
    main()
