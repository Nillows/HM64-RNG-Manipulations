"""Dog-watch report (2026-11-16, v30 groundwork): can what the runner SEES of the dog while waiting at the dock end
(before the cast) tell the dog lines apart, how fast, and what does it add to the Power Nut odds?

  python3 -I tools/dogwatch_report.py RESULTS_DIR [--runners 400] [--sigma-ms 150] [--lead 1.0] [--seed 1]

Input: a zigzag campaign folder made with an `observe` preset (Z6 rows carry `obs`, see zigzag_jobs.obs_pack),
zz_lines.json, and (optional) Z7 casts. Output: DOGWATCH.md, dogwatch.json (numbers), dogwatch_traces.json (per
line: visible runs + decisions, members (line, k_off, ready_rel, w): what a v30 app would load).

Model (stated so it can be argued with):
- Clock: the dock-end tap (READY), read with a spread of `--clock-sd` VIs (default 3 = 50 ms). Time s = VIs after
  this variant's READY; a member at offset k_off sees its line's representative trace at k = s + k_off.
- Runner: logs every visible change (new animation or facing) lasting >= 12 VIs (shorter ones are flickers), from
  `--lead` s after READY to the end of the window, r ~ U(10, 25) VIs after it starts on screen, misses 15%.
  Three alphabets: animation + facing (the Dog Oracle's keys + arrows), animation only (facing unreadable, e.g. a
  half-hidden dog), and a bare tap at each change (Space only: rhythm).
- Matching: a variant stays possible while every log has an onset of that kind in its trace within
  [log - 25 - tol, log - 10 + tol] VIs (tol = 2 x clock spread). Posterior = route weights of the variants left.
- Odds: per line, P(Nut) of a cast at k (bite-1 release, or hold to bite 2) smoothed with a Gaussian of
  `--sigma-ms`; the cast comes >= 2 s after the window ends (hands back on the controller). Best cast for the
  posterior mixture, scored on the true variant; baseline = the same rule with no logs (route weights only)."""
from __future__ import annotations

import argparse
import json
import math
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tools"))

MIN_RUN, R_LO, R_HI, MISS = 12, 10, 25, 0.15
# Thomas on his TV at the lineup2 dock end (2026-11-16): facing changes are readable in every direction; animations
# only while the dog faces S, N, NE, E or SE (screen facing +0x67: S, SW, W, NW, N, NE, E, SE = 0..7); west-ish facings
# (SW, W, NW) are unreliable. He logs arrows at every facing change and a letter only for the long animations.
READABLE = {0, 4, 5, 6, 7}
LONG_VI = 60                                     # "long" animation: the same animation lasts >= 1 s
FACING = ["S", "SW", "W", "NW", "N", "NE", "E", "SE"]
# Thomas, 2026-11-16 13:59: the dog's facing is always readable -> log every facing change on an 8-way "gear" (arrows or
# WASD, diagonals = two keys), reactive like a bite tap; no new arrow = same facing. Animation keys: numpad 0-9 only, so
# at most 10 animation groups (default below; looks-alike merged). Space stays for the clock and the bites.
NUMPAD = {0: (0,), 1: (40,), 2: (32,), 3: (80,), 4: (8,), 5: (16, 72), 6: (112,), 7: (168, 96, 160), 8: (152, 144),
          9: (128, 136)}
NUMPAD_TXT = {0: "idle", 1: "sit", 2: "stand", 3: "rollover", 4: "walk", 5: "run", 6: "sleep", 7: "sniff", 8: "bark",
              9: "shoulder"}
GROUP_OF = {b: g for g, bs in NUMPAD.items() for b in bs}
MISS_F = 0.10                                    # facing changes: easily spotted, so missed less often
NAMES = {0: "idle", 8: "walk", 16: "run", 32: "stand", 40: "sit", 48: "squat", 56: "t56", 64: "t64", 72: "sprint",
         80: "rollover", 88: "flapper", 96: "sniff-sitting", 104: "good-boy", 112: "sleep", 120: "scratch",
         128: "shoulder-sitting", 136: "shoulder-standing", 144: "bork", 152: "bark", 160: "smell",
         168: "sniff-standing", 176: "mess", 184: "b184", 192: "b192", 200: "wiggle-bum"}
VI_MS = 1000 / 60.0


def load(out):
    out = Path(out)
    lines = json.loads((out / "zz_lines.json").read_text())
    obs = {}
    for l in open(out / "Z6_lines.jsonl"):
        if not l.strip():
            continue
        r = json.loads(l)
        if r.get("ok") and r.get("obs"):
            obs[r["key"]] = r["obs"]
    return lines, obs


def variants(lines, obs):
    """(line key, k_off) aggregated over members, with route weight and READY on the fade-in clock"""
    agg = defaultdict(float)
    rr = {}
    for k, L in lines.items():
        if k not in obs:
            continue
        for m in L["members"]:
            if "k_off" not in m:
                continue
            agg[(k, int(m["k_off"]))] += m["w"]
            rr[(k, int(m["k_off"]))] = m.get("ready_rel")
    tot = sum(agg.values()) or 1.0
    return [(k, ko, w / tot, rr[(k, ko)]) for (k, ko), w in sorted(agg.items(), key=lambda x: -x[1])]


def onsets(o, alphabet):
    """[(k, run length, label)] visible changes of a line trace (k = VIs after the representative's READY), per
    alphabet = what the runner logs:
      anim+facing  every change, letter + arrow          anim   animation changes only (letter)
      tap          a bare Space at every change           facing arrows only: every facing change (the facing track
                                                                 and how long each facing lasts = the signature)
      thomas       arrows at every facing change + a letter for an animation lasting >= LONG_VI that starts while the
                   dog faces a readable direction (S, N, NE, E, SE)"""
    vis = o["vis"]
    if alphabet in ("anim+facing", "tap"):
        return [(k0, k1 - k0, (cls, scr) if alphabet == "anim+facing" else 0) for k0, k1, scr, cls, base in vis]
    if alphabet == "anim":
        return merge_labels([(k0, k1 - k0, cls) for k0, k1, scr, cls, base in vis])
    fac = merge_labels([(k0, k1 - k0, ("F", scr)) for k0, k1, scr, cls, base in vis])
    if alphabet in ("facing", "gear-arrows"):
        return fac
    if alphabet == "gear":
        an = merge_labels([(k0, k1 - k0, GROUP_OF.get(base, -1 - base)) for k0, k1, scr, cls, base in vis])
        scr_at = {}
        for k0, k1, scr, cls, base in vis:
            scr_at.setdefault(k0, scr)
        longs = [(k0, n, ("N", g)) for k0, n, g in an if g >= 0 and n >= LONG_VI and scr_at.get(k0) in READABLE]
        return sorted(fac + longs, key=lambda e: (e[0], e[2][0]))
    an = merge_labels([(k0, k1 - k0, base) for k0, k1, scr, cls, base in vis])
    scr_at = {}
    for k0, k1, scr, cls, base in vis:
        scr_at.setdefault(k0, scr)
    longs = []
    for k0, n, base in an:
        sc = scr_at.get(k0)
        if n >= LONG_VI and sc in READABLE:
            longs.append((k0, n, ("A", base)))
    return sorted(fac + longs, key=lambda e: (e[0], e[2][0]))


def label_txt(lab):
    if isinstance(lab, tuple) and lab and lab[0] == "F":
        return "faces " + FACING[lab[1]]
    if isinstance(lab, tuple) and lab and lab[0] == "A":
        return NAMES.get(lab[1], f"base {lab[1]}")
    if isinstance(lab, tuple) and lab and lab[0] == "N":
        return f"numpad {lab[1]} {NUMPAD_TXT[lab[1]]}"
    return str(lab)


def merge_labels(ons):
    """for alphabets that ignore facing / everything: consecutive runs with the same label are one run"""
    res = []
    for k, n, lab in ons:
        if res and res[-1][2] == lab:
            res[-1] = (res[-1][0], res[-1][1] + n, lab)
        else:
            res.append((k, n, lab))
    return res


def visibility(o, horizon):
    horizon = min(horizon, max((v[1] for v in o["vis"]), default=horizon))   # the trace's own length
    on = sum(min(b, horizon) - a for a, b in o["grid"] if a < horizon)
    ch = [v for v in o["vis"] if v[0] < horizon]
    runs = [v[1] - v[0] for v in ch]
    pos = o.get("pos") or []
    moved = max((abs(p[1] - pos[0][1]) + abs(p[2] - pos[0][2]) for p in pos), default=0)
    return {"horizon": horizon, "on_grid": on / horizon, "changes_per_min": len(ch) / horizon * 3600,
            "loggable_share": sum(1 for x in runs if x >= MIN_RUN) / max(1, len(runs)), "moved_units": round(moved, 1)}


def lags(o):
    """decision (actionState change) -> first visible change after it; +0x54 -> +0x56 (displayed)"""
    dec = [d[0] for a, d in zip(o["dog"], o["dog"][1:]) if d[1] != a[1] or d[2] != a[2]]
    vis = [v[0] for v in o["vis"][1:]]
    shown = [s[0] for s in o["shown"][1:]]
    out, out2 = [], []
    for t in dec:
        nxt = next((v for v in vis if v >= t), None)
        if nxt is not None and nxt - t <= 120:
            out.append(nxt - t)
    for v in vis:
        nxt = next((s for s in shown if s >= v), None)
        if nxt is not None and nxt - v <= 30:
            out2.append(nxt - v)
    return out, out2


def nut_curves(out, lines, keys, sig_vi, kmax):
    """per line: release-at-bite-1 and hold-to-bite-2 P(Nut) by cast k (VIs after the representative's READY),
    Gaussian-smoothed over the known casts (even k); NaN where nothing is known"""
    try:
        import zigzag_report as ZR
        res, _, _ = ZR.cast_results(Path(out))
        tab, _ = ZR.line_tables(Path(out), lines, res)
    except Exception as e:  # no casts yet (run stopped after Z6)
        print(f"[dogwatch] no cast tables ({e}); odds section skipped", flush=True)
        return None
    r = int(math.ceil(3 * sig_vi))
    ker = np.exp(-0.5 * (np.arange(-r, r + 1) / sig_vi) ** 2)
    cur = {}
    for key in keys:
        t = tab.get(key)
        if not t:
            continue
        n1, n2, kn = np.zeros(kmax + 1), np.zeros(kmax + 1), np.zeros(kmax + 1)
        for k, v in t.items():
            k = int(k)
            if 0 <= k <= kmax and v[1] is not None:
                n1[k] = v[1]
                n2[k] = v[3] or 0
                kn[k] = 1
        c1, c2, cn = (np.convolve(a, ker, mode="same") for a in (n1 * kn, n2 * kn, kn))
        with np.errstate(invalid="ignore", divide="ignore"):
            cur[key] = (np.where(cn > 0.3, c1 / cn, np.nan), np.where(cn > 0.3, c2 / cn, np.nan))
    return cur


def simulate(vs, obs, alphabet, window_s, lead_s, clock_sd, rng, n_runs, curves=None, kmax=2398, gap_s=2.0,
             taus=(0.05, 0.08)):
    """route-weighted simulated runners: posterior on the true line + odds with and without the logs"""
    W, lead = int(window_s * 60), int(lead_s * 60)
    tol = max(2, int(round(2 * clock_sd)))
    ons = {}
    for k, ko, w, rr in vs:
        if k not in ons:
            ons[k] = onsets(obs[k], alphabet)
    weights = np.array([v[2] for v in vs])
    idx_of_line = defaultdict(list)
    for i, v in enumerate(vs):
        idx_of_line[v[0]].append(i)
    # odds matrix: rows = variants, cols = cast time s (VIs after READY, even), both policies
    M = None
    if curves:
        S = np.arange(0, kmax + 1, 2)
        M = np.full((2, len(vs), len(S)), np.nan)
        for i, (k, ko, w, rr) in enumerate(vs):
            if k not in curves:
                continue
            kk = S + ko
            ok = kk <= kmax
            for p in range(2):
                M[p, i, ok] = curves[k][p][kk[ok]]
        s_min = W + int(gap_s * 60)
        allowed = S >= s_min
    stats = {"top1": 0.0, "p_true": 0.0, "sure90": 0.0, "left": 0.0, "logs": 0.0, "odds_obs": 0.0, "odds_base": 0.0,
             "odds_known": 0.0, "w": 0.0}
    for t in taus:                                       # dud call: reset before casting if the best cast for what the
        for f in ("called", "odds_called", "odds_kept"):   # logs leave is under tau
            stats[f"dud{t}_{f}"] = 0.0
    base_choice = None
    if M is not None:
        Mz = np.nan_to_num(M)
        mix0 = np.tensordot(weights, Mz, axes=(0, 1))          # (2, S)
        mix0[:, ~allowed] = -1
        base_choice = np.unravel_index(np.argmax(mix0), mix0.shape)
    gear = alphabet in ("gear", "gear-arrows")
    fac_at = {}
    if gear:                                             # facing per VI of each line (the gear's "no arrow = same facing")
        for k in ons:
            arr = np.full(kmax + 400, -1, dtype=np.int8)
            for k0, k1, scr, cls, base in obs[k]["vis"]:
                arr[max(0, k0):min(len(arr), k1)] = scr
            fac_at[k] = arr
    for _ in range(n_runs):
        ti = rng.choice(len(vs), p=weights)
        k, ko = vs[ti][0], vs[ti][1]
        c_err = rng.normal(0, clock_sd)
        logs = []
        for k0, n, lab in ons[k]:
            s = k0 - ko                                         # onset on this variant's READY clock
            miss = MISS_F if gear and lab[0] == "F" else MISS
            if s < lead - R_LO or n < MIN_RUN or rng.random() < miss:
                continue
            tau = s + rng.uniform(R_LO, R_HI) + c_err
            if tau > W:
                break
            if tau >= lead:
                logs.append((tau, lab))
        s0 = None
        if gear:                                          # the facing the dog has as the watch starts (one arrow)
            t0 = lead + rng.uniform(R_LO, R_HI)
            f0 = int(fac_at[k][int(lead) + ko]) if 0 <= int(lead) + ko < len(fac_at[k]) else -1
            if f0 >= 0:
                s0 = (lead, f0)
        post = np.zeros(len(vs))
        for i, (k2, ko2, w2, rr2) in enumerate(vs):
            ok = True
            for tau, lab in logs:
                lo, hi = tau - R_HI - tol + ko2, tau - R_LO + tol + ko2      # onset window in the candidate's k
                if not any(lo <= k0 <= hi and (lab2 == lab) and n2 >= MIN_RUN - 2 for k0, n2, lab2 in ons[k2] if lo - 1 <= k0 <= hi + 1):
                    ok = False
                    break
            if ok and gear and s0 is not None:
                a = fac_at[k2]
                lo, hi = int(s0[0] - tol) + ko2, int(s0[0] + tol) + ko2
                ok = any(0 <= j < len(a) and a[j] == s0[1] for j in range(lo, hi + 1))
            if ok and gear:                               # facing changes this line has but you did not log: each
                u = 0                                     # one counts as a miss
                for k0, n2, lab2 in ons[k2]:
                    if lab2[0] != "F" or n2 < MIN_RUN:
                        continue
                    s2 = k0 - ko2
                    if s2 < lead or s2 > W - R_HI - tol:
                        continue
                    if not any(lab == lab2 and s2 + R_LO - tol <= tau <= s2 + R_HI + tol for tau, lab in logs):
                        u += 1
                post[i] = w2 * MISS_F ** u
            elif ok:
                post[i] = w2
        if post.sum() <= 0:
            post = weights.copy()
        post /= post.sum()
        pl = defaultdict(float)
        for i, p in enumerate(post):
            pl[vs[i][0]] += p
        top = max(pl, key=pl.get)
        wgt = 1.0
        stats["w"] += wgt
        stats["top1"] += wgt * (top == k)
        stats["p_true"] += wgt * pl[k]
        stats["sure90"] += wgt * (pl[k] >= 0.9)
        stats["left"] += wgt * sum(1 for v in pl.values() if v > 1e-9)
        stats["logs"] += wgt * len(logs)
        if M is not None:
            Mz = np.nan_to_num(M)
            mix = np.tensordot(post, Mz, axes=(0, 1))
            mix[:, ~allowed] = -1
            p_, s_ = np.unravel_index(np.argmax(mix), mix.shape)
            stats["odds_obs"] += wgt * Mz[p_, ti, s_]
            stats["odds_base"] += wgt * Mz[base_choice[0], ti, base_choice[1]]
            own = Mz[:, ti, :].copy()
            own[:, ~allowed] = -1
            stats["odds_known"] += wgt * own.max()
            got = Mz[p_, ti, s_]
            for t in taus:
                if mix[p_, s_] < t:
                    stats[f"dud{t}_called"] += wgt
                    stats[f"dud{t}_odds_called"] += wgt * got
                else:
                    stats[f"dud{t}_odds_kept"] += wgt * got
    n = stats.pop("w") or 1
    res = {k: v / n for k, v in stats.items()}
    for t in taus:                                       # per-attempt rates -> odds among called / kept attempts
        c = res[f"dud{t}_called"]
        res[f"dud{t}_odds_called"] = res[f"dud{t}_odds_called"] / c if c > 0 else float("nan")
        res[f"dud{t}_odds_kept"] = res[f"dud{t}_odds_kept"] / (1 - c) if c < 1 else float("nan")
    return res


def dud_signs(vs, obs, curves, alphabet, window_s, lead_s, tau, kmax=2398, gap_s=2.0, bin_s=1.0, min_share=0.005):
    """which logs (label, second after READY) point to dud lines: per variant its best cast if the line were known
    (cast >= window + gap s after READY, either policy); dud = under tau. For every event of the alphabet in the watch
    window: route weight seeing it, and the share of that weight on dud variants."""
    S = np.arange(0, kmax + 1, 2)
    s_min = int((window_s + gap_s) * 60)
    best = {}
    for k, ko, w, rr in vs:
        if k not in curves:
            continue
        kk = S + ko
        ok = (kk <= kmax) & (S >= s_min)
        vals = [np.nanmax(curves[k][p][kk[ok]]) if ok.any() and np.isfinite(curves[k][p][kk[ok]]).any() else np.nan for p in range(2)]
        if np.isfinite(vals).any():
            best[(k, ko)] = float(np.nanmax(vals))
    tot_w = sum(w for k, ko, w, rr in vs if (k, ko) in best) or 1.0
    dud_w = sum(w for k, ko, w, rr in vs if (k, ko) in best and best[(k, ko)] < tau)
    cells = defaultdict(lambda: [0.0, 0.0])
    W, lead = int(window_s * 60), int(lead_s * 60)
    ons = {}
    for k, ko, w, rr in vs:
        if (k, ko) not in best:
            continue
        if k not in ons:
            ons[k] = onsets(obs[k], alphabet)
        seen = set()
        for k0, n, lab in ons[k]:
            t = k0 - ko
            if t < lead or t > W or n < MIN_RUN:
                continue
            key = (label_txt(lab), int(t / (bin_s * 60)))
            if key in seen:
                continue
            seen.add(key)
            cells[key][0] += w / tot_w
            if best[(k, ko)] < tau:
                cells[key][1] += w / tot_w
    rows = [(lab, b, sw, dw / sw) for (lab, b), (sw, dw) in cells.items() if sw >= min_share]
    rows.sort(key=lambda r: (-r[3], -r[2]))
    return {"dud_share": dud_w / tot_w, "n_best": len(best), "rows": rows,
            "best": {f"{k}|{ko}": v for (k, ko), v in best.items()}}


ALPHA_TXT = {"gear": "gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E",
             "gear-arrows": "gear, arrows only (no arrow = same facing)",
             "thomas": "your logging (arrows always, letters for long animations facing S/N/E)",
             "facing": "arrows only (facing track + durations)", "anim+facing": "every change, letter + arrow",
             "anim": "every animation change, letter only", "tap": "Space at every change"}


def facing_share(obs, lw):
    """route-weighted share of the trace time the dog spends in each screen facing"""
    acc = defaultdict(float)
    tw = 0.0
    for k, w in lw.items():
        o = obs.get(k)
        if not o:
            continue
        tot = sum(k1 - k0 for k0, k1, scr, cls, base in o["vis"]) or 1
        for k0, k1, scr, cls, base in o["vis"]:
            acc[scr] += w * (k1 - k0) / tot
        tw += w
    return sorted(((f, v / (tw or 1)) for f, v in acc.items()), key=lambda x: -x[1])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("results")
    ap.add_argument("--runners", type=int, default=400)
    ap.add_argument("--sigma-ms", type=float, default=150.0)
    ap.add_argument("--lead", type=float, default=1.0)
    ap.add_argument("--clock-sd", type=float, default=3.0)
    ap.add_argument("--windows", default="3,5,10,15,20")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--dud", default="0.05,0.08", help="dud thresholds: reset before casting when the best cast for what is left is under this")
    ap.add_argument("--dud-window", type=float, default=10.0, help="watch window (s) for the early-dud table")
    a = ap.parse_args()
    out = Path(a.results)
    lines, obs = load(out)
    if not obs:
        print("[dogwatch] no Z6 rows with dog-watch traces (preset without observe?)")
        return 1
    vs = variants(lines, obs)
    horizon = 2398
    obs = {k: o for k, o in obs.items() if k in {v[0] for v in vs}}
    vis = {k: visibility(o, horizon) for k, o in obs.items()}
    lag1, lag2 = [], []
    for o in obs.values():
        x, y = lags(o)
        lag1 += x
        lag2 += y
    lw = defaultdict(float)
    for k, ko, w, rr in vs:
        lw[k] += w
    wavg = lambda f: sum(lw[k] * f(vis[k]) for k in lw) / (sum(lw.values()) or 1)
    sig_vi = a.sigma_ms / VI_MS
    curves = nut_curves(out, lines, list(lw), sig_vi, horizon)
    rng = np.random.default_rng(a.seed)
    wins = [float(x) for x in a.windows.split(",")]
    taus = tuple(float(x) for x in a.dud.split(",") if x)
    table = {}
    for alpha in ("gear", "gear-arrows", "thomas", "facing", "anim+facing", "anim", "tap"):
        for W in wins:
            table[(alpha, W)] = simulate(vs, obs, alpha, W, a.lead, a.clock_sd, rng, a.runners, curves, taus=taus)
            r = table[(alpha, W)]
            print(f"[dogwatch] {alpha:<11s} {W:>4.0f} s: right line on top {100 * r['top1']:.0f}%, posterior on it "
                  f"{100 * r['p_true']:.0f}%, >= 90% sure {100 * r['sure90']:.0f}%, lines left {r['left']:.1f}"
                  + (f", Nut {100 * r['odds_base']:.1f}% -> {100 * r['odds_obs']:.1f}% (known line {100 * r['odds_known']:.1f}%)"
                     if curves else ""), flush=True)
    pct = lambda x: f"{100 * x:.0f}%"
    md = [f"# Dog-watch report: {out.name}", "",
          f"{len(lw)} dog lines with traces ({min(v['horizon'] for v in vis.values()) / 60:.0f} s after READY), {len(vs)} (line, READY offset) variants; route-weighted. Clock = the dock-end "
          f"tap ±{a.clock_sd:.0f} VI; logs from {a.lead:.1f} s after READY; runner: changes >= {MIN_RUN} VI, reaction "
          f"{R_LO}-{R_HI} VI, {int(MISS * 100)}% missed. Odds: cast >= 2 s after the window, ±{a.sigma_ms:.0f} ms.", "",
          "## What the dog does while you wait (after READY, route-weighted)", "",
          f"- dog's tile on the visibility grid (it animates only then): {pct(wavg(lambda v: v['on_grid']))} of the time",
          f"- visible changes per minute: {wavg(lambda v: v['changes_per_min']):.0f}; changes lasting >= {MIN_RUN} VI: "
          f"{pct(wavg(lambda v: v['loggable_share']))}",
          f"- facing on screen (share of the wait): " + ", ".join(f"{FACING[f]} {pct(x)}" for f, x in facing_share(obs, lw)) +
          f"; animations readable (dog faces S / N / NE / E / SE): {pct(sum(x for f, x in facing_share(obs, lw) if f in READABLE))}",
          f"- the dog moves (units, max over the trace): median {sorted(v['moved_units'] for v in vis.values())[len(vis) // 2]}",
          f"- decision (actionState change) -> next visible change: median {np.median(lag1) if lag1 else float('nan'):.0f} VI "
          f"(p10 {np.percentile(lag1, 10) if lag1 else float('nan'):.0f}, p90 {np.percentile(lag1, 90) if lag1 else float('nan'):.0f}); "
          f"animation set -> displayed: median {np.median(lag2) if lag2 else float('nan'):.0f} VI", "",
          "## Telling the lines apart (simulated runners)", "",
          "| logging | window | right line on top | posterior on it | >= 90% sure | lines left | logs |" +
          (" Nut (no logs -> logs) | known line |" if curves else ""),
          "|---|---|---|---|---|---|---|" + ("---|---|" if curves else "")]
    for (alpha, W), r in table.items():
        md.append(f"| {ALPHA_TXT.get(alpha, alpha)} | {W:.0f} s | {pct(r['top1'])} | {pct(r['p_true'])} | {pct(r['sure90'])} | {r['left']:.1f} | "
                  f"{r['logs']:.1f} |" + (f" {100 * r['odds_base']:.1f}% -> {100 * r['odds_obs']:.1f}% | {100 * r['odds_known']:.1f}% |"
                                          if curves else ""))
    md += ["", "Readability: *your logging* follows Thomas's TV check (facing always readable; animations only while the dog",
           "faces S, N, NE, E or SE, and only animations lasting >= 1 s are logged). The other rows are for comparison.", ""]
    duds = {}
    if curves:
        md += ["## Duds before the cast (reset early)", "",
               f"Dud = the best cast for what your logs leave is under the threshold; you reset instead of casting. "
               f"Odds per attempt; 'kept' = attempts you cast.", "",
               "| logging | window | threshold | attempts called dud | Nut on kept attempts | Nut the resets threw away | all-cast Nut |",
               "|---|---|---|---|---|---|---|"]
        for (alpha, W), r in table.items():
            if alpha not in ("gear", "gear-arrows"):
                continue
            for t in taus:
                c = r[f"dud{t}_called"]
                md.append(f"| {ALPHA_TXT[alpha]} | {W:.0f} s | {100 * t:.0f}% | {pct(c)} | {100 * r[f'dud{t}_odds_kept']:.1f}% | "
                          f"{100 * c * (r[f'dud{t}_odds_called'] if c > 0 else 0):.2f} pts | {100 * r['odds_obs']:.1f}% |")
        for t in taus:
            d = dud_signs(vs, obs, curves, "gear", a.dud_window, a.lead, t)
            duds[str(t)] = {"dud_share": d["dud_share"], "rows": d["rows"][:60]}
            md += ["", f"### Early dud signs, your logging, {a.dud_window:.0f} s window, dud = best cast under {100 * t:.0f}%", "",
                   f"{pct(d['dud_share'])} of attempts are duds at this threshold (if the line were known). A sign = what you "
                   f"log in a 1-s slot after READY; seen = share of attempts showing it; dud share = how many of those are duds.", "",
                   "| you log | seconds after READY | seen | dud share |", "|---|---|---|---|"]
            for lab, b, sw, ds in d["rows"][:20]:
                md.append(f"| {lab} | {b}-{b + 1} | {100 * sw:.1f}% | {pct(ds)} |")
        md.append("")
    (out / "DOGWATCH.md").write_text("\n".join(md))
    json.dump({"lines": len(obs), "variants": len(vs), "visibility": vis, "lag_decision_to_visible": lag1[:2000],
               "table": {f"{al}|{W}": r for (al, W), r in table.items()}, "duds": duds}, open(out / "dogwatch.json", "w"))
    traces = {"variants": [[k, ko, round(w, 7), rr] for k, ko, w, rr in vs],
              "lines": {k: {"vis": o["vis"], "dog": o["dog"], "grid": o["grid"]} for k, o in obs.items() if k in lw}}
    json.dump(traces, open(out / "dogwatch_traces.json", "w"), separators=(",", ":"))
    print(f"[dogwatch] wrote {out / 'DOGWATCH.md'}", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
