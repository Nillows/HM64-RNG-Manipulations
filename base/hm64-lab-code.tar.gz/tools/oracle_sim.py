#!/usr/bin/env python3
"""
Stage E - oracle simulation. Answers: if a player watches the dog after READY
and feeds what they see into the tool, can the tool name a cast moment that
wins the Power Nut, and how early?

Inputs (from a campaign folder): A_routes.jsonl (scenarios + route weights),
L_ladder.jsonl (what the dog visibly shows every VI + poll timing),
B_natural.jsonl and P_parity.jsonl (which cast polls win).

Model
- What the player sees: the dog's ROM sprite class + screen facing
  (hm64/sprites.py, same classes as Layer 1). A "change" is a new (facing,
  class). The player logs each change on their own clock: gaps between
  changes are known to +-g VIs; the READY frame itself is NOT known (unless
  --anchor). Silence is information too: a candidate whose next change is
  overdue by more than g is dropped.
- Candidates: every arrival scenario with the same initial pose and the same
  changes so far. The true scenario is always among them.
- A plan is "press B exactly D VIs after the k-th change" (k = latest change).
  Certain plan: it wins for EVERY remaining candidate. Width w: the press may
  land on any of w consecutive VIs. The plan must leave a lead time >= L VIs
  after the moment it becomes known.
- Pressing B at VI v is read at poll polls_after[v-1] (ladder timing). Casts
  were swept every 2 polls; the odd poll in between is filled from the parity
  probes (stage P) when the scenario's 30 Hz pairing is known, else unknown
  (counted as a loss).

  python3 tools/oracle_sim.py results/campaign-oracle
"""
from __future__ import annotations

import csv
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

VI_PER_S = 60.0
GAP_TOLS = (3, 6, 12)
LEADS = (30, 60)
WIDTHS = (1, 2)
THETA = 0.5                      # probabilistic policy: commit when >= half the candidate routes win


def load_jsonl(p):
    if not p.exists():
        return []
    out = []
    for line in p.read_text().splitlines():
        if line.strip():
            try:
                out.append(json.loads(line))
            except ValueError:
                pass
    return out


# ------------------------------------------------------------------ data
def build(out: Path):
    routes = [r for r in load_jsonl(out / "A_routes.jsonl") if "_error" not in r and r.get("outcome") == "ready"]
    weight = Counter(r["signature"] for r in routes)
    ladder = {r["signature"]: r for r in load_jsonl(out / "L_ladder.jsonl") if "_error" not in r}
    tested = defaultdict(dict)
    for f in ("B_natural.jsonl", "P_parity.jsonl"):
        for r in load_jsonl(out / f):
            if "_error" in r or r.get("whistles"):
                continue
            tested[r["signature"]][r["cast"]] = bool(r["nut_releases"]) or "nut" in r["probes"].values()
    scen = {}
    for sig, w in weight.items():
        L = ladder.get(sig)
        if not L or sig not in tested:
            continue
        T = tested[sig]
        votes = set()
        for c, won in T.items():
            if won and c % 2 == 0:
                lo, hi = T.get(c - 1), T.get(c + 1)
                if lo is None and hi is None:
                    continue
                if hi and not lo:
                    votes.add(+1)
                elif lo and not hi:
                    votes.add(-1)
                else:
                    votes.add(0 if not lo and not hi else 2)
        parity = votes.pop() if len(votes) == 1 and votes <= {+1, -1} else None
        pa = L["polls_after"]
        horizon = len(pa) - 1

        def win_poll(c, T=T, parity=parity):
            if c in T:
                return T[c]
            if parity in (+1, -1):          # pairing +1: game frame = {even, even+1}; -1: {even-1, even}
                rep = c - parity if c % 2 else c + parity
                if rep in T:
                    return T[rep]
            return None
        win_vi = [None] * (horizon + 2)           # win_vi[v]: pressing B from VI v (v >= 2) wins
        for v in range(2, horizon + 1):
            win_vi[v] = win_poll(pa[v - 1])
        ev = [(s[0], (s[2], s[3])) for s in L["segments"]]
        scen[sig] = {"sig": sig, "w": w, "ev": ev, "win_vi": win_vi, "parity": parity, "horizon": horizon,
                     "tested_polls": [min(T), max(T)], "n_tested": len(T),
                     "wins": sorted(v for v in range(len(win_vi)) if win_vi[v])}
    return scen


def worldlines(scen, min_changes=4):
    """Group arrivals that show the SAME dog path shifted in time (they joined one
    dog/RNG 'world line' at different moments). Returns {sig: (root, offset)} with
    world time = t + offset, and a consistency check of the cast outcomes."""
    sigs = sorted(scen, key=lambda x: -scen[x]["w"])
    parent = {x: (x, 0) for x in sigs}

    def find(x):
        r, o = parent[x]
        if r == x:
            return x, 0
        rr, oo = find(r)
        parent[x] = (rr, o + oo)
        return rr, o + oo

    def align(a, b):                       # b's changes 1.. equal a's changes j.. shifted
        A, B = scen[a]["ev"], scen[b]["ev"]
        ha, hb = scen[a]["horizon"] - 10, scen[b]["horizon"] - 10
        for j in range(1, len(A)):
            off = A[j][0] - B[1][0]
            n = 0
            for x, y in zip(A[j:], B[1:]):
                if x[0] > ha or y[0] > hb:
                    break
                if x[1] != y[1] or x[0] - y[0] != off:
                    n = -1
                    break
                n += 1
            if n >= min_changes:
                return off
        return None

    for i, a in enumerate(sigs):
        for b in sigs[i + 1:]:
            ra, oa = find(a)
            rb, ob = find(b)
            if ra == rb:
                continue
            off = align(a, b)
            if off is None:
                off2 = align(b, a)
                if off2 is None:
                    continue
                off = -off2
            # t_a + oa = world; t_b + off = t_a  ->  world = t_b + off + oa ; attach rb under ra
            parent[rb] = (ra, off + oa - ob)
    wl = {x: find(x) for x in sigs}
    agree = disagree = 0
    groups = defaultdict(list)
    for x, (r, o) in wl.items():
        groups[r].append((x, o))
    for r, mem in groups.items():
        for i, (a, oa) in enumerate(mem):
            for b, ob in mem[i + 1:]:
                lo = max(scen[a]["ev"][1][0] + oa if len(scen[a]["ev"]) > 1 else 10**9,
                         scen[b]["ev"][1][0] + ob if len(scen[b]["ev"]) > 1 else 10**9)
                for W in range(lo, lo + 4000):
                    va, vb = W - oa, W - ob
                    if not (2 <= va <= scen[a]["horizon"] and 2 <= vb <= scen[b]["horizon"]):
                        continue
                    x, y = scen[a]["win_vi"][va], scen[b]["win_vi"][vb]
                    if x is None or y is None:
                        continue
                    if x == y:
                        agree += x          # count agreeing WINS (agreeing losses are cheap)
                    else:
                        disagree += 1
    return wl, groups, agree, disagree


def fill_from_worldlines(scen, wl, groups):
    """Copy of scen where a scenario's unknown press outcomes (outside its own
    swept range) are taken from a copy on the same world line, after both have
    shown their first change."""
    out = {}
    for x, s in scen.items():
        r, ox = wl[x]
        wv = list(s["win_vi"])
        t1x = s["ev"][1][0] if len(s["ev"]) > 1 else None
        if t1x is not None:
            for y, oy in groups[r]:
                if y == x or len(scen[y]["ev"]) < 2:
                    continue
                t1y = scen[y]["ev"][1][0]
                for v in range(max(2, t1x), len(wv)):
                    if wv[v] is None:
                        vy = v + ox - oy
                        if vy >= t1y and 2 <= vy < len(scen[y]["win_vi"]):
                            wv[v] = scen[y]["win_vi"][vy]
        out[x] = dict(s, win_vi=wv, wins=sorted(v for v in range(len(wv)) if wv[v]))
    return out


def wide_wins(s, width):
    wv = s["win_vi"]
    return {v for v in s["wins"] if all(v + i < len(wv) and wv[v + i] for i in range(width))}


# ------------------------------------------------------------------ simulation
def simulate(scen, true_sig, g, lead, width, anchor=None, theta=None):
    """Earliest plan for the true scenario. Returns dict (go_vi None if none)."""
    S = scen[true_sig]
    ev = S["ev"]
    W = {sig: wide_wins(s, width) for sig, s in scen.items()}
    C = [sig for sig, s in scen.items() if s["ev"][0][1] == ev[0][1]]
    best = None
    ident_vi = None
    for k in range(1, len(ev)):
        tk, pose = ev[k]
        keep = []
        for c in C:
            e2 = scen[c]["ev"]
            if len(e2) <= k or e2[k][1] != pose:
                continue
            if k >= 2 and abs((tk - ev[k - 1][0]) - (e2[k][0] - e2[k - 1][0])) > g:
                continue
            if anchor is not None and abs(e2[k][0] - tk) > anchor:
                continue
            keep.append(c)
        C = keep
        assert true_sig in C
        t_next = ev[k + 1][0] if k + 1 < len(ev) else S["horizon"] + 1
        # decision moments in [tk, t_next): now, and whenever an overdue candidate drops out
        moments = {tk}
        for c in C:
            e2 = scen[c]["ev"]
            if len(e2) > k + 1:
                drop = tk + (e2[k + 1][0] - e2[k][0]) + g + 1
                if drop < t_next:
                    moments.add(drop)
        for tau in sorted(moments):
            alive = [c for c in C if c == true_sig or len(scen[c]["ev"]) <= k + 1 or
                     tk + (scen[c]["ev"][k + 1][0] - scen[c]["ev"][k][0]) + g >= tau]
            if ident_vi is None and len(alive) == 1:
                ident_vi = tau
            if best is not None and best["go_vi"] <= tau + lead:
                return best, ident_vi                  # nothing found later can beat it
            dmin = tau - tk + lead
            if theta is None:
                cands = None
                for c in alive:
                    sh = {v - scen[c]["ev"][k][0] for v in W[c]}
                    cands = sh if cands is None else cands & sh
                    if not cands:
                        break
                ok = sorted(d for d in (cands or ()) if d >= dmin)
                if ok:
                    d = ok[0]
                    plan = {"go_vi": tk + d, "decide_vi": tau, "k": k, "delta": d, "cands": len(alive),
                            "p": 1.0, "success": True}
                    if best is None or plan["go_vi"] < best["go_vi"]:
                        best = plan
            else:
                tot = sum(scen[c]["w"] for c in alive)
                cnt = Counter()
                for c in alive:
                    for v in W[c]:
                        d = v - scen[c]["ev"][k][0]
                        if d >= dmin:
                            cnt[d] += scen[c]["w"]
                ok = sorted(d for d, wsum in cnt.items() if wsum / tot >= theta)
                if ok:
                    d = ok[0]
                    plan = {"go_vi": tk + d, "decide_vi": tau, "k": k, "delta": d, "cands": len(alive),
                            "p": round(cnt[d] / tot, 3), "success": (tk + d) in W[true_sig]}
                    if best is None or plan["go_vi"] < best["go_vi"]:
                        best = plan
    return best, ident_vi


def pct(xs, q):
    xs = sorted(xs)
    return xs[min(len(xs) - 1, int(q * (len(xs) - 1) + 0.5))] if xs else None


def run(out: Path):
    out = Path(out)
    scen = build(out)
    if not scen:
        print("[E oracle] no scenarios with ladder + cast data; skipped", flush=True)
        return
    total_w = sum(s["w"] for s in scen.values())
    wl, groups, wl_agree, wl_disagree = worldlines(scen)
    scen_wl = fill_from_worldlines(scen, wl, groups) if wl_disagree == 0 else None
    rows, table = [], []
    configs = [(g, L, w, None) for g in GAP_TOLS for L in LEADS for w in WIDTHS] + \
              [(6, 30, 1, THETA), (6, 30, 2, THETA), (6, 30, 1, "anchor15")]
    if scen_wl:
        configs += [(g, 30, w, "worldline") for g in (6, 12) for w in WIDTHS]
    names = {None: "certain", "anchor15": "anchor+-15", "worldline": "certain, world-line filled"}
    for g, L, w, pol in configs:
        res = []
        for sig in scen:
            if pol == "anchor15":
                plan, ident = simulate(scen, sig, g, L, w, anchor=15)
            elif pol == "worldline":
                plan, ident = simulate(scen_wl, sig, g, L, w)
            else:
                plan, ident = simulate(scen, sig, g, L, w, theta=pol)
            r = {"signature": sig, "routes": scen[sig]["w"], "gap_tol_vi": g, "lead_vi": L, "width_vi": w,
                 "policy": names.get(pol, f"p>={pol}"),
                 "identified_vi": ident, "go_vi": plan and plan["go_vi"], "decide_vi": plan and plan["decide_vi"],
                 "changes_seen": plan and plan["k"], "delta_vi": plan and plan["delta"],
                 "candidates": plan and plan["cands"], "p": plan and plan["p"],
                 "success": bool(plan and plan["success"])}
            rows.append(r)
            res.append(r)
        go = [r for r in res if r["go_vi"] is not None]

        def wfrac(pred):
            return sum(r["routes"] for r in res if pred(r)) / total_w

        table.append({
            "policy": res[0]["policy"], "gap_tol_vi": g, "lead_vi": L, "width_vi": w,
            "scenarios_with_plan": f"{len(go)}/{len(res)}",
            "routes_nut_by_10s": round(wfrac(lambda r: r["success"] and r["go_vi"] <= 600), 3),
            "routes_nut_by_20s": round(wfrac(lambda r: r["success"] and r["go_vi"] <= 1200), 3),
            "routes_nut_any": round(wfrac(lambda r: r["success"]), 3),
            "go_s_median": round(pct([r["go_vi"] for r in go], 0.5) / VI_PER_S, 2) if go else None,
            "go_s_p90": round(pct([r["go_vi"] for r in go], 0.9) / VI_PER_S, 2) if go else None,
            "candidates_at_decision_median": pct([r["candidates"] for r in go], 0.5) if go else None,
        })
    keys = list(rows[0].keys())
    with (out / "oracle_sim.csv").open("w", newline="") as f:
        wr = csv.DictWriter(f, fieldnames=keys)
        wr.writeheader()
        wr.writerows(rows)

    # data for the player tool: what each arrival shows, and when pressing B wins
    export = {"units": {"t": "VI (60 Hz) after READY; t=1 is the READY frame",
                        "changes": "[t, screen_dir 0=S..7=SE, visual_class] - first entry is the pose at READY",
                        "win_vi": "VIs at which first pressing (and holding) B casts a Nut line; release within "
                                  "the 20 polls after the bite shows"},
              "scenarios": [{"signature": s["sig"], "routes": s["w"],
                             "world_line": wl[s["sig"]][0], "world_offset_vi": wl[s["sig"]][1],
                             "changes": [[t, p[0], p[1]] for t, p in s["ev"]],
                             "win_vi": s["wins"], "parity": s["parity"], "tested_polls": s["tested_polls"]}
                            for s in sorted(scen.values(), key=lambda s: -s["w"])]}
    (out / "oracle_scenarios.json").write_text(json.dumps(export))

    ident = [r["identified_vi"] for r in rows if r["gap_tol_vi"] == 6 and r["lead_vi"] == 30
             and r["width_vi"] == 1 and r["policy"] == "certain"]
    n_id = sum(1 for x in ident if x is not None)
    par = Counter(s["parity"] for s in scen.values())
    wins_per_s = [len(s["wins"]) for s in scen.values()]
    summ = {"scenarios": len(scen), "routes": total_w, "table": table,
            "identified_unique_g6": f"{n_id}/{len(ident)}",
            "identified_s_median_g6": round(pct([x for x in ident if x], 0.5) / VI_PER_S, 2) if n_id else None,
            "parity_known": f"{par[1] + par[-1]}/{len(scen)}", "parity_counts": {str(k): v for k, v in par.items()},
            "winning_press_vis_per_scenario_median": pct(wins_per_s, 0.5),
            "world_lines": len(groups), "world_line_sizes": sorted((len(m) for m in groups.values()), reverse=True),
            "world_line_wins_agree": wl_agree, "world_line_outcome_disagreements": wl_disagree}
    (out / "oracle_summary.json").write_text(json.dumps(summ, indent=1))

    L = ["## Oracle simulation (stage E)\n",
         f"{len(scen)} arrival scenarios ({total_w} routes) with a ladder and cast sweep. A candidate is dropped "
         "when its dog shows a different (facing, sprite class), or its next change is more than g VIs early/"
         "late. A *certain* plan wins for every remaining candidate; *p>=0.5* commits once half the candidate "
         "routes would win (success = the true arrival wins). Width = consecutive VIs the B press may land on. "
         "Lead = VIs between the plan becoming known and the press.\n",
         f"- 30 Hz poll pairing known for {summ['parity_known']} scenarios (others: odd polls count as losses).",
         f"- Winning press VIs per scenario in the tested range: median {summ['winning_press_vis_per_scenario_median']}.",
         f"- Uniquely identified (g=6 VI): {summ['identified_unique_g6']} scenarios, median "
         f"{summ['identified_s_median_g6']} s after READY.",
         f"- World lines: the {len(scen)} arrivals show only **{len(groups)}** distinct dog paths; the rest are the "
         f"same path entered earlier or later (sizes {summ['world_line_sizes'][:10]}). Where two copies' casts "
         f"overlap in world time, winning casts agree {wl_agree} times and disagree **{wl_disagree}** times. "
         + ("Plans keyed to the dog's changes therefore win on every copy, so copies never need telling apart; "
            "'world-line filled' rows also borrow a copy's swept casts for times outside a scenario's own sweep."
            if wl_disagree == 0 else "Disagreements: world-line filling is NOT used.") + "\n",
         "| policy | gap tol g | lead | width | scenarios with a plan | routes: Nut by 10 s | by 20 s | any | "
         "press time median / p90 (s) | candidates when decided |",
         "|---|---|---|---|---|---|---|---|---|---|"]
    for t in table:
        L.append(f"| {t['policy']} | {t['gap_tol_vi']} | {t['lead_vi']} | {t['width_vi']} | {t['scenarios_with_plan']} | "
                 f"{t['routes_nut_by_10s']:.0%} | {t['routes_nut_by_20s']:.0%} | {t['routes_nut_any']:.0%} | "
                 f"{t['go_s_median']} / {t['go_s_p90']} | {t['candidates_at_decision_median']} |")
    L.append("\nFiles: `oracle_sim.csv` (one row per scenario x setting), `oracle_scenarios.json` (compact data "
             "the player tool needs: each arrival's visible changes and winning press VIs), `oracle_summary.json`.")
    text = "\n".join(L) + "\n"
    (out / "ORACLE.md").write_text(text)
    rep = out / "REPORT.md"
    if rep.exists():
        body = rep.read_text()
        cut = body.find("## Oracle simulation (stage E)")
        if cut >= 0:
            body = body[:cut].rstrip() + "\n\n"
        rep.write_text(body + text)
    print(text, flush=True)


if __name__ == "__main__":
    run(Path(sys.argv[1]))
