#!/usr/bin/env python3
"""Dog-spot lab comparison (2026-11-15): one table across the saves run by run_hm64_dogspots.sh.

  python3 tools/dogspots_report.py results/dogspots        -> results/dogspots/DOGSPOTS.md (+ dogspots.json)
  python3 tools/dogspots_report.py --one results/dogspots/<label>   -> terminal summary of one save

Reads every <save>/dogspot_summary.json (tools/zigzag_report.py, preset dogspot-*). Same recipe of route delays for
every save, so the rows compare directly: where the dog starts, whether the save is repeatable, how much of the recipe
reaches READY and where it fails, how the lines collapse, and the cast odds split by the web app's cut presets.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path


def pct(b):
    return f"{b['p'] * 100:.2f}% @{b['s']}s" if b else "-"


def one(d):
    """Terminal summary of one finished save (printed by run_hm64_dogspots.sh before the next save starts)."""
    p = Path(d) / "dogspot_summary.json"
    if not p.exists():
        print(f"  (no summary for {Path(d).name}: the run stopped before the report - see its ZIGZAG.md / the log)")
        return
    s = json.loads(p.read_text())
    sv = s.get("save", {})
    dg, dt = sv.get("dog", {}), sv.get("date", {})
    fm = s.get("failures", {})
    st = fm.get("stages", {})
    ref = sv.get("reference_ready")
    print(f"  save       {Path(d).name}   ({sv.get('file')})")
    print(f"  dog        {dg.get('map')} x {dg.get('x')} z {dg.get('z')} at the house load; on screen at: "
          f"{', '.join(sv.get('dog_screens', [])) or 'none of the route screens'}")
    print(f"  day        {dt.get('season_name')} {dt.get('day')} y{dt.get('year')}, weather {dt.get('weather')}, "
          f"rod in hand {dt.get('rod_in_hand')}; repeatable: {'yes' if sv.get('deterministic') else 'NO'}; reference route: "
          f"{f'READY {ref[0]} VIs after the beach load' if ref else 'no READY'}")
    g = lambda k, q: (st.get(k, {}).get(q) or 0)
    print(f"  recipe     kept per screen: house {g('house', 'mass_kept'):.3f} · crossroads {g('crossroads', 'mass_kept'):.3f} · "
          f"ranch {g('ranch', 'mass_kept'):.3f} · beach reaches the dock end {fm.get('p_ready', 0):.3f}")
    print(f"  never      reached the next screen (runs): house {g('house', 'never')} · crossroads {g('crossroads', 'never')}"
          f" (farm walks stuck {st.get('crossroads', {}).get('farm_walk_fails', 0)}) · ranch {g('ranch', 'never')} · "
          f"beach (state, D) without a window {g('beach', 'never')}")
    bb = fm.get("beach_B", {})
    wins = []
    for D in ("84", "86", "90"):
        sg = bb.get(D)
        if sg is not None:
            wins.append(f"D{D} " + (", ".join(f"{c['lo']}-{c['hi']}" + ("" if c["class"] == "READY" else
                                                                           f" ({c['ready_share'] * 100:.0f}%)")
                                              for c in sg if c["class"] in ("READY", "partly READY")) or "none"))
    print(f"  2nd cut    windows: {' · '.join(wins) or '-'}")
    c = s.get("collapse", {})
    print(f"  lines      {c.get('lines', '-')} from {c.get('beach_states', '-')} beach states "
          f"({c.get('collapsed_states', '-')} collapse to one line); members {s.get('members', '-')}; casts "
          f"{s.get('casts', '-')}; Nut casts b1/b2 {s.get('nut_casts', '-')}")
    rd = s.get("ready_draws")
    fn = s.get("first_nut_cast_vi")
    print(f"  RNG        draw index at READY #{rd[0]}-#{rd[1]} ({rd[2]} values)" if rd else "  RNG        -",
          f"| earliest Nut cast {fn / 60:.2f} s after READY" if fn is not None else "| no Nut cast in the tables (0-40 s)")
    lu = s.get("lineup")
    if lu:
        st_, ar = lu.get("stability", {}), lu.get("after_ready", {})
        print(f"  steadiness {st_.get('lines')} lines; heaviest {st_.get('top', 0) * 100:.1f}%; {st_.get('n50')} lines hold 50%, "
              f"{st_.get('n90')} hold 90%")
        if st_.get("start_shapes"):
            print(f"  per start  lines across the pier width {st_.get('lines_per_start')}; split: "
                  + "; ".join(f"{sh} ({n})" for sh, n in st_["start_shapes"][:2]))
        if ar:
            print(f"  after READY dog drawing on {ar['share_dog_drawing'] * 100:.1f}% of routes; +{ar['mean_extra_draws_40s']:.0f} "
                  f"draws over {ar.get('span_s', 40)} s on average")
        for d in lu.get("first_cut", []):
            wk = ", ".join(f"VI {k}+W {v * 100:.0f}%" for k, v in sorted(d.get("wake", []), key=lambda kv: -kv[1])[:2])
            print(f"  first cut D {d['D']}  share {d['share']:.2f}  lines {d['lines']} ({d['shared']} shared with the other cut)  "
                  f"dog wakes {wk}  release b1 {pct(d.get('release'))}  hold b2 {pct(d.get('hold'))}")
        for g in lu.get("bands", []):
            if g["cut2"] == "any" or g["wait"] == "any wait":
                print(f"  {g['wait']:<10} 2nd cut {g['cut2']:<5} share {g['share']:.2f}  lines {g['lines']:>4}  "
                      f"release b1 {pct(g.get('release'))}  hold b2 {pct(g.get('hold'))}")
        return
    for gr in s.get("groups", []):
        if gr.get("share") and (gr["id"] == "all" or "+" not in gr["id"]):
            print(f"  {gr['label'][:24]:<24} share {gr['share']:.2f}   release b1 {pct(gr.get('release'))}   "
                  f"hold b2 {pct(gr.get('hold'))}")


def main():
    if len(sys.argv) > 2 and sys.argv[1] == "--one":
        one(sys.argv[2])
        return
    root = Path(sys.argv[1] if len(sys.argv) > 1 else "results/dogspots")
    rows = []
    for p in sorted(root.glob("*/dogspot_summary.json")):
        try:
            rows.append((p.parent.name, json.loads(p.read_text())))
        except ValueError:
            continue
    md = ["# Dog-spot lab: comparison", "",
          "Every save ran the same zig-zag recipe of route delays (zigzag-fast grids), dog-neutral. "
          "Mass = uniform choices over the grids; odds at a 150 ms cast spread (best aim after READY).", ""]
    if not rows:
        md.append("(no finished saves yet)")
    else:
        md += ["## Where the dog starts", "",
               "| save | date / weather | dog at the house load | dog on screen at | repeatable | reference route |",
               "|---|---|---|---|---|---|"]
        for name, s in rows:
            sv = s.get("save", {})
            d, dt = sv.get("dog", {}), sv.get("date", {})
            ref = sv.get("reference_ready")
            md.append(f"| {name} | {dt.get('season_name')} {dt.get('day')} y{dt.get('year')}, weather {dt.get('weather')} | "
                      f"{d.get('map')} x {d.get('x')} z {d.get('z')} | {', '.join(sv.get('dog_screens', [])) or '-'} | "
                      f"{'yes' if sv.get('deterministic') else 'NO'}"
                      f"{' (test poke)' if sv.get('test_dog_poke') else ''} | "
                      f"{f'READY {ref[0]} VIs after the beach load' if ref else 'no READY'} |")
        md += ["", "## Route recipe: how much reaches READY, and where it fails", "",
               "| save | menus kept | house kept | crossroads kept | ranch kept | beach: reaches the dock end | "
               "never reached (mass): house / crossroads / ranch / beach |", "|---|---|---|---|---|---|---|"]
        for name, s in rows:
            st = s.get("failures", {}).get("stages", {})
            g = lambda k, q: st.get(k, {}).get(q, 0) or 0
            md.append(f"| {name} | {g('menus', 'mass_kept'):.3f} | {g('house', 'mass_kept'):.3f} | "
                      f"{g('crossroads', 'mass_kept'):.3f} | {g('ranch', 'mass_kept'):.3f} | "
                      f"{s.get('failures', {}).get('p_ready', 0):.3f} | "
                      f"{g('house', 'mass_never'):.3f} / {g('crossroads', 'mass_never'):.3f} / "
                      f"{g('ranch', 'mass_never'):.3f} / {g('beach', 'mass_never'):.3f} |")
        md += ["", "| save | P(2nd cut reaches) by 1st cut: early / tight / mid / loose | where Jack stopped (beach) |",
               "|---|---|---|"]
        for name, s in rows:
            c1 = s.get("failures", {}).get("beach_cut1", {})
            f = lambda k: f"{c1[k]['p_reach']:.2f}" if c1.get(k) and c1[k]["p_reach"] is not None else "-"
            wh = s.get("failures", {}).get("stages", {}).get("beach", {}).get("where", [])[:2]
            md.append(f"| {name} | {f('early')} / {f('tight')} / {f('mid')} / {f('loose')} | "
                      + ("; ".join(f"{n}× {p}" for n, p in wh) or "-") + " |")
        md += ["", "Second-cut windows (B that reach the dock end) for the first cuts D 84 / 86 / 90 "
               "(partly = some beach states only):", "", "| save | D 84 | D 86 | D 90 |", "|---|---|---|---|"]
        for name, s in rows:
            bb = s.get("failures", {}).get("beach_B", {})
            def win(D):
                sg = bb.get(str(D)) or bb.get(D)
                if sg is None:
                    return "-"
                parts = [f"{c['lo']}–{c['hi']}" + ("" if c["class"] == "READY" else f" partly {c['ready_share'] * 100:.0f}%")
                         for c in sg if c["class"] in ("READY", "partly READY")]
                return ", ".join(parts) or "none"
            md.append(f"| {name} | {win(84)} | {win(86)} | {win(90)} |")
        md += ["", "## Lines and Nuts", "", "| save | beach states | lines | beach states collapsed to one line | members | "
               "casts | RNG draw at READY | Nut casts b1 / b2 | earliest Nut cast |", "|---|---|---|---|---|---|---|---|---|"]
        for name, s in rows:
            c = s.get("collapse", {})
            rd, fn, nc = s.get("ready_draws"), s.get("first_nut_cast_vi"), s.get("nut_casts")
            md.append(f"| {name} | {c.get('beach_states', '-')} | {c.get('lines', '-')} | {c.get('collapsed_states', '-')} | "
                      f"{s.get('members', '-')} | {s.get('casts', '-')} | {f'#{rd[0]}–#{rd[1]}' if rd else '-'} | "
                      f"{f'{nc[0]} / {nc[1]}' if nc else '-'} | {f'{fn / 60:.2f} s' if fn is not None else 'none'} |")
        md += ["", "## Cast odds by the web app's cut presets (release bite 1 / hold to bite 2)", ""]
        gids = []
        for _, s in rows:
            for g in s.get("groups", []):
                if g["id"] not in gids:
                    gids.append(g["id"])
        md += ["| preset | " + " | ".join(n for n, _ in rows) + " |", "|---|" + "---|" * len(rows)]
        for gid in gids:
            cells = []
            for _, s in rows:
                g = next((x for x in s.get("groups", []) if x["id"] == gid), None)
                cells.append("-" if not g or not g.get("share") else
                             f"{g['share']:.2f} · {pct(g.get('release'))} / {pct(g.get('hold'))}")
            label = next((x["label"] for _, s in rows for x in s.get("groups", []) if x["id"] == gid), gid)
            md.append(f"| {label} | " + " | ".join(cells) + " |")
        md += ["", "(cell = share of the save's routes · release bite 1 / hold to bite 2)", ""]
    lus = [(n, s["lineup"]) for n, s in rows if s.get("lineup")]
    if lus:
        md += ["## Lineup lab: tight first cut (D 84, + D 86 from zigzag-4b), beach wait 0-30 VIs, full pier width", "",
               "| save | lines | heaviest line | lines for 50% / 90% | dog drawing after READY | extra draws after READY |",
               "|---|---|---|---|---|---|"]
        for n, lu in lus:
            st_, ar = lu.get("stability", {}), lu.get("after_ready", {})
            md.append(f"| {n} | {st_.get('lines')} | {st_.get('top', 0) * 100:.1f}% | {st_.get('n50')} / {st_.get('n90')} | "
                      f"{ar.get('share_dog_drawing', 0) * 100:.1f}% | {ar.get('mean_extra_draws_40s', 0):.0f} |")
        keys = []
        for _, lu in lus:
            for g in lu.get("bands", []):
                if (g["wait"], g["cut2"]) not in keys:
                    keys.append((g["wait"], g["cut2"]))
        md += ["", "| wait | 2nd cut | " + " | ".join(n for n, _ in lus) + " |", "|---|---|" + "---|" * len(lus)]
        for wk, ck in keys:
            cells = []
            for _, lu in lus:
                g = next((x for x in lu.get("bands", []) if (x["wait"], x["cut2"]) == (wk, ck)), None)
                cells.append("-" if not g else f"{g['share']:.2f} · {g['lines']} lines · {pct(g.get('release'))} / "
                                                f"{pct(g.get('hold'))}")
            md.append(f"| {wk} | {ck} | " + " | ".join(cells) + " |")
        md += ["", "(cell = share of routes · lines · release bite 1 / hold to bite 2, 150 ms cast spread)", ""]
    (root / "DOGSPOTS.md").write_text("\n".join(md) + "\n")
    (root / "dogspots.json").write_text(json.dumps({n: s for n, s in rows}, indent=1, default=str))
    print(f"{len(rows)} save(s) -> {root / 'DOGSPOTS.md'}")


if __name__ == "__main__":
    main()
