"""
Pack Thomas's Jack fishing animation catalog (HM64_Jack_Fishing_Animation_Naming_Catalog, hm64_fishing_work/) into
webapp/assets/jack_fishing.json for the Lucky Timer: the E and SE screen facings of the fishing bases plus the
non-directional extras, as data-URL PNG frames with their tick lengths and anchors.

  python3 -I tools/build_jack_assets.py /path/to/hm64_fishing_work [--out webapp/assets/jack_fishing.json]

1 tick = 1 controller poll ≈ 1 VI at the dock (checked: 386 = 32 ticks = B press +4 → +36 polls; 394 = 20 = the
release window; 402 = 34 = bite+20 → +54; eating 437 = 134 = bite+118 → +252).
Scene offsets (native pixels from Jack's anchor, from the decomp camera (pitch 45°, yaw 315°) and a lab screenshot):
float 2 tiles ahead on the water (y 128 vs 172): SE (+40, +73), E (+96, +23); held item (0, 14, 20) in front: SE (+15, −4),
E (+20, −10).
"""
from __future__ import annotations

import argparse
import base64
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASES = {0: "idle", 24: "hold", 378: "wait", 386: "cast", 394: "bite", 402: "land"}
EXTRAS = {"jack_eating": "eat", "cast_float": "float", "bite_float": "floatBite", "ocean_power_nut": "nut"}
SCENE = {"SE": {"float": [40, 73], "held": [15, -4]}, "E": {"float": [96, 23], "held": [20, -10]}}


def pack(src: Path, e: dict) -> dict:
    frames = [("data:image/png;base64," + base64.b64encode((src / f).read_bytes()).decode()) for f in e["frames"]]
    b = e["frameBounds"]
    return {"frames": frames, "ticks": e["durationTicks"], "loop": e["animationTypeName"] == "LOOP",
            "ax": -b["minLeft"], "ay": -b["minTop"], "w": e["sourceWidth"], "h": e["sourceHeight"]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("catalog")
    ap.add_argument("--out", default=str(ROOT / "webapp" / "assets" / "jack_fishing.json"))
    a = ap.parse_args()
    src = Path(a.catalog)
    m = json.loads((src / "sprite_manifest.json").read_text())
    out = {"schema": "hm64-lucky-jack-v1", "romSha256": m.get("romSha256"), "facings": {}, "extras": {}, "scene": SCENE,
           "note": "Thomas's own catalog (private research); 1 tick = 1 poll ≈ 1 VI at the dock"}
    for e in m["entries"]:
        if e["screenFacing"] in ("E", "SE") and e["base"] in BASES and e.get("status") == "ok":
            out["facings"].setdefault(e["screenFacing"], {})[BASES[e["base"]]] = pack(src, e)
    for e in m["extras"]:
        if e.get("id") in EXTRAS and e.get("status") == "ok":
            out["extras"][EXTRAS[e["id"]]] = pack(src, e)
    miss = [f"{d}:{n}" for d in ("E", "SE") for n in BASES.values() if n not in out["facings"].get(d, {})]
    miss += [n for n in EXTRAS.values() if n not in out["extras"]]
    Path(a.out).write_text(json.dumps(out, separators=(",", ":")))
    nf = sum(len(v["frames"]) for d in out["facings"].values() for v in d.values()) + sum(len(v["frames"]) for v in out["extras"].values())
    print(f"{a.out}: {nf} frames, {Path(a.out).stat().st_size // 1024} KB" + (f"; missing {miss}" if miss else ""))


if __name__ == "__main__":
    main()
