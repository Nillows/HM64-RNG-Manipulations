#!/usr/bin/env python3
"""Ladder self-check: casts started from a ladder rung must equal casts started
from READY (same bite poll, same Nut release polls). Used by smoke_test.

  python3 tools/check_ladder.py states/ready/m00000000_h00c00_p00d00.st
"""
import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "experiments"))

from m64h.core import Emulator                      # noqa: E402
from tools.common import default_rom, default_sram  # noqa: E402


def main():
    state = Path(sys.argv[1]).resolve()
    from campaign_jobs import cast_job_rung, ladder_job
    from hm64.fishing import eval_cast
    store = Path(tempfile.mkdtemp(prefix="ladder-", dir=ROOT / "states"))
    rel = lambda p: str(Path(p).resolve().relative_to(ROOT))
    out = {"checks": []}
    try:
        run_checks(state, store, rel, out, cast_job_rung, ladder_job, eval_cast)
    finally:
        for p in sorted(store.rglob("*"), reverse=True):
            p.unlink() if p.is_file() else p.rmdir()
        store.rmdir()
    out["ok"] = bool(out["checks"]) and all(c["same"] and c["rung"] > 0 and c["bite"][0] for c in out["checks"])
    print(json.dumps(out))
    sys.exit(0 if out["ok"] else 1)


def run_checks(state, store, rel, out, cast_job_rung, ladder_job, eval_cast):
    with Emulator(default_rom(), sram=default_sram()) as emu:
        lad = ladder_job(emu, {"signature": "smoke", "state": rel(state), "horizon": 400, "rung_polls": 60,
                               "store": rel(store)})
        out["rungs"] = [p for p, _ in lad["rungs"]]
        for cast, wh in ((130, []), (200, [140])):
            a = cast_job_rung(emu, {"signature": "smoke", "state": rel(state), "cast": cast, "whistles": wh,
                                    "rungs": lad["rungs"]})
            b = eval_cast(emu, state, cast, whistles=wh)
            same = (a["bite_poll"], a["nut_releases"], a["probes"]) == (b["bite_poll"], b["nut_releases"], b["probes"])
            out["checks"].append({"cast": cast, "whistles": wh, "rung": a["rung"], "bite": [a["bite_poll"], b["bite_poll"]],
                                  "same": same})


if __name__ == "__main__":
    main()
