"""
Full-day lab (2026-11-20, Thomas): the cast table and the dog to the end of the game day, on the dog lines of a
finished dog-watch run (its results folder `--src` with zz_lines.json / Z6_lines.jsonl / Z0_record.json, its state
store in HM64_ZZ_STORE). Jobs: experiments/fullday_jobs.py. Nothing of the dog-watch run is changed.

  python3 tools/fullday_campaign.py --src results/dogwatch/<label> --out results/fullday/<tag> lines
  python3 tools/fullday_campaign.py --src ... --out ... plan            (prints the blocks; writes fd_plan.json)
  python3 tools/fullday_campaign.py --src ... --out ... block N         (casts of block N -> FD_casts_bNN.jsonl)
  python3 tools/fullday_campaign.py --src ... --out ... nblocks         (prints how many blocks there are)

Stage "lines": every dog line's day without a cast (FD1_lines.jsonl): the dog all day, the cast hash every 2 VIs, the
clock, the end of the day. Checked against the dog-watch run: the hashes of the first 33 s must be the same ones.

Blocks = (40 s of cast frames) x (the heaviest lines that carry `--cover` of the route weight | the other lines), in
this order: casts 0-40 s on the heavy lines, 0-40 s on the others, 40-80 s heavy, 40-80 s others, ... to the end of
the day. Every block is complete by itself: each cast is held to the end of the day with every bite, release and the
dog (see fullday_jobs). A cast frame whose state another line (or an earlier block) already cast is not cast again.
Resumable: finished jobs are skipped. Ctrl-C any time.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "experiments"))
from common import default_rom, default_sram   # noqa: E402
from m64h.pool import run_jobs                 # noqa: E402

FD_CODE = "fullday-2 (2026-11-20: limits - casts to 40 s, everything to 90 s after READY by default)"
BLOCK_VI = 2400            # 40 s of cast frames
CAST_LO, CAST_STEP = 6, 2  # as the dog-watch run: one cast per game frame from 0.1 s after READY
CHUNK = 24
LINEUP2_DOG = (-198.5, 223.5)


def load_jsonl(p):
    out = []
    p = Path(p)
    if p.exists():
        with p.open() as f:
            for line in f:
                try:
                    out.append(json.loads(line))
                except ValueError:
                    pass
    return out


def good(p):
    return [r for r in load_jsonl(p) if "_error" not in r and "error" not in r]


def run_stage_shared(name, fn, jobs, out_path, workers, rom, sram, key):
    """The same stage shared with other machines (tools/coord.py): blocks of the job list, top down or bottom up.
    Returns the number of job errors; 0 with a note when the other machine holds what is left."""
    from coord import Coord
    C = Coord(os.environ["HM64_COORD_DIR"], (os.environ.get("HM64_COORD_CAMPAIGN") or "fullday") + "." + Path(out_path).parent.name + "." + Path(out_path).stem,
              os.environ.get("HM64_COORD_MACHINE", ""), os.environ.get("HM64_COORD_ORDER", "up"),
              int(os.environ.get("HM64_COORD_BLOCKS", "50") or 50))
    blocks = C.set_jobs([key(j) for j in jobs])
    print(f"[{name}] shared run: machine {C.me}, order {C.order}, {len(jobs)} jobs in {len(blocks)} blocks; "
          f"other machines: {', '.join(sorted(C.others())) or 'none seen yet'}", flush=True)
    bad, t0, ran, last_hb = 0, time.time(), 0, 0.0
    while True:
        have = {key(r["_job"]) for r in good(out_path) if r.get("ok", True) is not False}
        local_done = {b for b, ix in enumerate(blocks) if all(key(jobs[i]) in have for i in ix)}
        for b in sorted(local_done):
            if C._parse(C.mine)["b"].get(b, ("", 0))[0] != "done":
                C.mark_done(b)
        what, b = C.next_block(local_done)
        if what == "end":
            print(f"[{name}] every block is done ({ran} jobs run here this time)", flush=True)
            return 4 if bad else 0
        if what == "wait":
            print(f"[{name}] {b} blocks left, all held by other machines: waiting (taken over if a machine goes silent "
                  f"for {C.stale / 60:.0f} min)", flush=True)
            C.heartbeat()
            time.sleep(float(os.environ.get("HM64_COORD_POLL_S", "60") or 60))
            continue
        todo = [jobs[i] for i in blocks[b] if key(jobs[i]) not in have]
        print(f"[{name}] block {b + 1}/{len(blocks)} ({ {'up': 'top down', 'down': 'bottom up', 'middle': 'middle out'}[C.order] }): {len(todo)} jobs", flush=True)
        berr = 0
        with Path(out_path).open("a") as f:
            for res in run_jobs(fn, todo, rom=rom, sram=sram, workers=workers):
                if "_error" in res or "error" in res:
                    berr += 1
                    print(f"[{name}] job error: {str(res.get('_error') or res.get('error'))[-400:]}", flush=True)
                f.write(json.dumps(res, separators=(",", ":")) + "\n")
                f.flush()
                ran += 1
                if time.time() - last_hb > 240:
                    C.heartbeat()
                    last_hb = time.time()
        bad += berr
        if berr:
            print(f"[{name}] block {b + 1}: {berr} job errors - the block stays open; stopping (the same command runs it again)", flush=True)
            return 4
        C.mark_done(b)
        el = time.time() - t0
        print(f"[{name}] block {b + 1} done; {ran} jobs here in {el / 60:.0f} min ({ran / max(el, 1) * 60:.1f} jobs/min)", flush=True)



def run_stage(name, fn, jobs, out_path, workers, rom, sram, key):
    done = {key(r["_job"]) for r in good(out_path) if r.get("ok", True) is not False}   # a refused line (ok false) runs again
    todo = [j for j in jobs if key(j) not in done]
    print(f"[{name}] {len(jobs)} jobs, {len(done)} already done, {len(todo)} to run", flush=True)
    if not todo and not (os.environ.get("HM64_COORD_DIR") and name.startswith("FD block")):
        return 0
    if os.environ.get("HM64_COORD_DIR") and name.startswith("FD block"):
        return run_stage_shared(name, fn, jobs, out_path, workers, rom, sram, key)
    t0, n, bad = time.time(), 0, 0
    with Path(out_path).open("a") as f:
        for res in run_jobs(fn, todo, rom=rom, sram=sram, workers=workers):
            if "_error" in res or "error" in res:
                bad += 1
                print(f"[{name}] job error: {str(res.get('_error') or res.get('error'))[-400:]}", flush=True)
            f.write(json.dumps(res, separators=(",", ":")) + "\n")
            f.flush()
            n += 1
            if n % 5 == 0 or n == len(todo):
                el = time.time() - t0
                left = el / n * (len(todo) - n)
                print(f"[{name}] {n}/{len(todo)}  {n / el * 60:.1f} jobs/min  eta "
                      f"{left / 3600:.1f} h" if left > 5400 else
                      f"[{name}] {n}/{len(todo)}  {n / el * 60:.1f} jobs/min  eta {left / 60:.0f} min", flush=True)
    return bad


def src_lines(src):
    """The dog-watch run's lines with a natural path: [(key, weight, rep)] heaviest first, and its Z6 hashes."""
    lines = json.load(open(src / "zz_lines.json"))
    nat = {r["key"]: r for r in good(src / "Z6_lines.jsonl") if r.get("ok")}
    order = sorted((k for k in lines if k in nat), key=lambda k: (-lines[k]["w"], k))
    return [(k, lines[k]["w"], lines[k]["rep"]) for k in order], nat


def dog_spot(src, any_dog):
    rec = json.load(open(src / "Z0_record.json"))
    d = rec["record"]["info"]["stages"]["5"]["dog"] if "record" in rec else rec["info"]["stages"]["5"]["dog"]
    at = [d["x"], d["z"]]
    poke = (rec.get("record", rec).get("info", {}) or {}).get("test_dog_poke") or rec.get("test_dog_poke")
    if not any_dog and (abs(at[0] - LINEUP2_DOG[0]) > 24 or abs(at[1] - LINEUP2_DOG[1]) > 24 or d.get("location") not in (9, 10, 11, 12)):
        sys.exit(f"STOP: the dog of this run is at {at} on map {d.get('location')}, not at the beach-lineup2 spot "
                 f"{list(LINEUP2_DOG)} (pass --any-dog to run another spot on purpose)")
    return at, poke


def build_plan(out, order, cover, cast_last=None):
    """Blocks in running order with their cast lists (deduplicated by state hash over the whole plan)."""
    from fullday_jobs import in_push
    rows = {r["key"]: r for r in good(out / "FD1_lines.jsonl") if r.get("ok")}
    keys = [k for k, _, _ in order if k in rows]
    if not keys:
        sys.exit("STOP: no finished lines (run the stage `lines` first)")
    wt = {k: w for k, w, _ in order}
    tot = sum(wt[k] for k in keys) or 1.0
    acc, heavy = 0.0, []
    for k in keys:
        heavy.append(k)
        acc += wt[k] / tot
        if acc >= cover - 1e-9:
            break
    rest = [k for k in keys if k not in set(heavy)]
    day = min(rows[k]["end"][0] for k in keys)
    last = day - 120                                      # a cast needs 36 VIs to land; nothing can bite after that
    if cast_last is not None:
        last = min(last, cast_last)
    seen, blocks = set(), []
    lo = CAST_LO
    while lo <= last:
        hi = min((lo // BLOCK_VI + 1) * BLOCK_VI - 2, last)
        for part, ks in (("heavy", heavy), ("other", rest)):
            todo = {}
            for key in ks:
                r = rows[key]
                h0, step, hs = r["h0"], r["step"], r["hs"]
                lst = []
                for k in range(lo + (lo % 2), hi + 1, CAST_STEP):
                    i, rem = divmod(k - h0, step)
                    if rem or i < 0 or i >= len(hs) or k > r["end"][0] - 120:
                        continue
                    if in_push(k):
                        lst.append([k, None])             # inside a stay-awake push: always cast, no hash check
                        continue
                    if hs[i] in seen:
                        continue
                    seen.add(hs[i])
                    lst.append([k, hs[i]])
                if lst:
                    todo[key] = lst
            blocks.append({"i": len(blocks), "lo": lo, "hi": hi, "part": part, "lines": len(todo),
                           "casts": sum(len(v) for v in todo.values()), "todo": todo})
        lo = hi + 2
    return {"day_end": day, "heavy": heavy, "other": rest, "cover": acc, "blocks": blocks}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--src", required=True, help="results folder of the finished dog-watch run")
    ap.add_argument("--out", required=True)
    ap.add_argument("--workers", type=int, default=max(1, (os.cpu_count() or 2) - 1))
    ap.add_argument("--cover", type=float, default=float(os.environ.get("HM64_FD_COVER", "0.90")))
    ap.add_argument("--tail", type=int, default=int(os.environ.get("HM64_FD_TAIL", "240")))
    ap.add_argument("--max-lines", type=int, default=int(os.environ.get("HM64_FD_MAX_LINES", "0") or 0))
    ap.add_argument("--max-casts", type=int, default=int(os.environ.get("HM64_FD_MAX_CASTS", "0") or 0),
                    help="test knob: at most this many casts per line and block (evenly spaced)")
    ap.add_argument("--until", default=os.environ.get("HM64_FD_UNTIL", "90"),
                    help="seconds after READY everything is followed to (bites, the dog); 'day' = the end of the day")
    ap.add_argument("--cast-until", default=os.environ.get("HM64_FD_CAST_UNTIL", "40"),
                    help="cast frames up to this many seconds after READY; 'day' = to the end of the day")
    ap.add_argument("--any-dog", action="store_true", default=os.environ.get("HM64_FD_ANY_DOG") == "1")
    ap.add_argument("stage", choices=["lines", "plan", "block", "nblocks"])
    ap.add_argument("n", nargs="?", type=int)
    args = ap.parse_args()
    src, out = Path(args.src), Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    vis = lambda v: None if str(v).strip().lower() in ("day", "", "0") else int(float(v) * 60) - 2   # as the dog-watch run: 90 s -> 5398
    until, cast_last = vis(args.until), vis(args.cast_until)
    for f in ("zz_lines.json", "Z6_lines.jsonl", "Z0_record.json"):
        if not (src / f).exists():
            sys.exit(f"STOP: {src / f} is missing - --src must be the results folder of a finished dog-watch run")
    order, nat = src_lines(src)
    if args.max_lines:
        order = order[:args.max_lines]
    at, poke = dog_spot(src, args.any_dog)
    if args.stage == "nblocks":
        print(len(build_plan(out, order, args.cover, cast_last)["blocks"]))
        return 0
    rom, sram = default_rom(), default_sram()
    import fullday_jobs as FJ
    if args.stage == "lines":
        print(f"{FD_CODE}  lines of {src}  save {sram}  workers {args.workers}  dog at {at}"
              + (f"  (dog written by the test knob: {poke})" if poke else ""), flush=True)
        print(f"  followed to {'the end of the day' if until is None else str(until) + ' VIs after READY'}", flush=True)
        jobs = [{"key": k, "b": rep["b"], "D": rep["D"], "B": rep["B"], "dog_at": at, "until": until} for k, _, rep in order]
        run_stage("FD1 lines", FJ.fd_line_job, jobs, out / "FD1_lines.jsonl", args.workers, rom, sram, lambda j: j["key"])
        rows = {r["key"]: r for r in good(out / "FD1_lines.jsonl")}
        bad = [k for k, _, _ in order if not rows.get(k, {}).get("ok")]
        for k in bad[:8]:
            print(f"  line {k}: {rows.get(k, {}).get('why', 'no row')}", flush=True)
        # the same path as the dog-watch run? its cast hashes (to 40 s, no push before 33.3 s) must be ours
        same = diff = 0
        worst = []
        for k, _, _ in order:
            r = rows.get(k)
            if not r or not r.get("ok"):
                continue
            mine = {r["h0"] + i * r["step"]: h for i, h in enumerate(r["hs"][:1100])}
            d = [kk for kk, h in nat[k]["hashes"] if kk in mine and kk < FJ.WAKE_EVERY - 4 and mine[kk] != h]
            n = sum(1 for kk, h in nat[k]["hashes"] if kk in mine and kk < FJ.WAKE_EVERY - 4)
            same += n - len(d)
            diff += len(d)
            if d:
                worst.append((k, d[0], len(d)))
        ends = sorted({(r["end"][1], r["end"][0]) for r in rows.values() if r.get("ok")})
        clocks = sorted({tuple(r["clock"]) for r in rows.values() if r.get("ok")})
        summ = {"code": FD_CODE, "lines": len(order), "ok": len(order) - len(bad), "failed": bad, "dog_at": at,
                "test_dog_poke": poke, "z6_same": same, "z6_diff": diff, "z6_worst": worst[:10],
                "ends": ends[:12], "ready_clocks": [list(c) for c in clocks[:12]]}
        json.dump(summ, open(out / "fd_lines_summary.json", "w"), indent=1)
        far = [(k[:8], rows[k]["dog_at"]) for k, _, _ in order if rows.get(k, {}).get("ok") and (abs(rows[k]["dog_at"][0] - at[0]) > 24 or abs(rows[k]["dog_at"][1] - at[1]) > 24)]
        if far:
            print(f"  the dog had already left its tile at READY on {len(far)} lines (kept): {far[:6]}", flush=True)
        print(f"[FD1] {summ['ok']} of {summ['lines']} lines ran as planned; hashes against the dog-watch "
              f"run: {same} equal, {diff} different; ended: {ends[:4]}", flush=True)
        if bad or diff:
            print("STOP: " + (f"{len(bad)} lines failed. " if bad else "") +
                  (f"{diff} cast hashes differ from the dog-watch run (first: {worst[:3]}): this run is not on the same "
                   f"paths, the casts would not belong to its lines." if diff else ""), flush=True)
            return 3
        return 0
    plan = build_plan(out, order, args.cover, cast_last)
    if args.stage == "plan":
        slim = dict(plan, blocks=[{k: v for k, v in b.items() if k != "todo"} for b in plan["blocks"]])
        json.dump(slim, open(out / "fd_plan.json", "w"), indent=1)
        print(f"lines followed to {plan['day_end']} VIs ({plan['day_end'] / 59.826:.0f} s) after READY; {len(plan['heavy'])} heavy "
              f"lines ({plan['cover']:.1%} of the route weight), {len(plan['other'])} others; "
              f"{sum(b['casts'] for b in plan['blocks'])} casts in {len(plan['blocks'])} blocks", flush=True)
        for b in plan["blocks"]:
            done = sum(len(r.get("casts", [])) for r in good(out / f"FD_casts_b{b['i']:02d}.jsonl"))
            print(f"  block {b['i']:2d}: casts {b['lo'] / 59.826:5.1f}-{(b['hi'] + 2) / 59.826:5.1f} s after READY, "
                  f"{b['part']:5s} lines ({b['lines']:3d}): {b['casts']:6d} casts" + (f"  ({done} done)" if done else ""),
                  flush=True)
        return 0
    if args.n is None or not 0 <= args.n < len(plan["blocks"]):
        sys.exit(f"STOP: block number 0..{len(plan['blocks']) - 1}")
    b = plan["blocks"][args.n]
    rep = {k: r for k, _, r in order}
    jobs = []
    for key, lst in b["todo"].items():
        if args.max_casts and len(lst) > args.max_casts:
            stp = len(lst) / args.max_casts
            lst = [lst[int(i * stp)] for i in range(args.max_casts)]
        for i in range(0, len(lst), CHUNK):
            ch = lst[i:i + CHUNK]
            if ch[-1][0] - ch[0][0] > 400:                # sparse test lists: one cast per job (the rung is per job)
                for c in ch:
                    jobs.append({"key": key, "b": rep[key]["b"], "D": rep[key]["D"], "B": rep[key]["B"], "casts": [c],
                                 "tail": args.tail, "dog_at": at, "until": until, "tag": f"b{b['i']}:{key}:{c[0]}"})
                continue
            jobs.append({"key": key, "b": rep[key]["b"], "D": rep[key]["D"], "B": rep[key]["B"], "casts": ch,
                         "tail": args.tail, "dog_at": at, "until": until, "tag": f"b{b['i']}:{key}:{ch[0][0]}"})
    print(f"{FD_CODE}  block {b['i']}: casts {b['lo']}..{b['hi']} VIs after READY on the {b['part']} lines "
          f"({b['lines']}), {sum(len(j['casts']) for j in jobs)} casts, each held to "
          + ("the end of the day" if until is None else f"{until} VIs after READY (and to its 2nd bite)"), flush=True)
    bad = run_stage(f"FD block {b['i']}", FJ.fd_cast_job, jobs, out / f"FD_casts_b{b['i']:02d}.jsonl", args.workers,
                    rom, sram, lambda j: j["tag"])
    return 4 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
