#!/usr/bin/env python3
"""
Stage F - link the native arrival scenarios to Thomas's Layer 1 index.

Layer 1 models the natural (no cast, no whistle) dog from each measured READY
anchor, expanded over every UNMEASURED sprite-phase hypothesis (base, frame,
tick, ended, skip). The native lab measures the real phase. For every scenario
this stage:
  1. finds its Layer 1 anchor(s) through the member route labels
     (schedules.label -> anchor_id) and checks the anchor RNG against the
     native READY draw index;
  2. compares the native visible path (ladder segments, VI -> 30 Hz updates as
     u = (t - 1) / 2) with every trajectory of that anchor, from the first
     visible change on, up to the shorter horizon;
  3. reports which hypotheses match (tolerance 0.5 and 1.0 update) and, when
     none do, how far the best one agrees.
A scenario whose real phase is pinned to a few Layer 1 trajectories lets the
player tool search a much smaller space; zero matches flags a Layer 1 model gap.

Sources (read-only, whichever exists in the folder given):
  layer1_spring9_full.sqlite (master: segments by trajectory) - preferred
  layer1_shards/manifest.sqlite + parts/*.sqlite (postings by facing/class/time)

  python3 tools/layer1_link.py results/campaign-oracle /layer1
"""
from __future__ import annotations

import bisect
import csv
import json
import sqlite3
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

TOLS = (0.5, 1.0)
END_MARGIN = 5          # updates ignored at the end of the shorter horizon


def ro(path):
    return sqlite3.connect(f"file:{path}?mode=ro&immutable=1", uri=True)


def load_jsonl(p):
    if not p.exists():
        return []
    return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]


def find_sources(l1: Path):
    if not l1.exists():
        return None, None
    master = None
    cands = [l1] if l1.is_file() else [l1 / "layer1_spring9_full.sqlite", *sorted(l1.glob("*.sqlite"))]
    for p in cands:
        wal = Path(str(p) + "-wal")
        if p.is_file() and wal.is_file() and wal.stat().st_size > 0:
            print(f"[F layer1] {p.name} has un-checkpointed writes in {wal.name}; a read-only mount cannot see "
                  "them, so it is skipped. On the Mac: sqlite3 <file> 'PRAGMA wal_checkpoint(TRUNCATE);'", flush=True)
            continue
        if p.is_file():
            try:
                c = ro(p)
                if c.execute("select 1 from sqlite_master where type='table' and name='segments'").fetchone():
                    master = p
                    break
            except sqlite3.Error:
                pass
    shards = None
    for d in ([l1 / "layer1_shards", l1] if l1.is_dir() else []):
        if (d / "manifest.sqlite").is_file():
            shards = d
            break
    return master, shards


def native_path(ladder):
    """[(u_start, pose)] in 30 Hz updates; pose = (screen, visual_class)."""
    return [((s[0] - 1) / 2.0, (s[2], s[3])) for s in ladder["segments"]], (len(ladder["polls_after"]) - 2) / 2.0


BURN = 4.0   # Layer 1 shows a READY-transition sprite for the first 3-4 updates; compare changes after it


def first_change(nat):
    """Index of the first native change at or after the READY transition window."""
    for i in range(1, len(nat)):
        if nat[i][0] >= BURN:
            return i
    return None


def compare(nat, nat_h, l1segs, l1_h, tol):
    """nat: [(u0, pose)], l1segs: [(t0, t1, screen, class)] sorted. Returns (match, agreed_changes, first_diverge_u)."""
    idx = first_change(nat)
    if idx is None:
        return False, 0, 0.0
    hc = min(nat_h, l1_h) - END_MARGIN
    b1 = nat[idx][0]
    bn = [(u, p) for u, p in nat[idx:] if u < hc]
    l1 = [(t0, (s, v)) for t0, t1, s, v in l1segs]
    bl = [(t0, p) for t0, p in l1 if b1 - tol <= t0 <= hc + tol]
    if len(bl) == len(bn) + 1 and bl[-1][0] >= hc - tol:
        bl = bl[:-1]
    if len(bn) == len(bl) + 1 and bn[-1][0] >= hc - tol:
        bn = bn[:-1]
    # pose just before the first compared change
    starts = [t0 for t0, _ in l1]
    i = bisect.bisect_left(starts, bl[0][0]) - 1 if bl else -1
    agreed = 0
    if i < 0 or l1[i][1] != nat[idx - 1][1]:
        return False, 0, 0.0
    for (u, p), (t, q) in zip(bn, bl):
        if abs(u - t) > tol + 1e-9 or p != q:
            return False, agreed, min(u, t)
        agreed += 1
    if len(bn) != len(bl):
        nxt = bn[len(bl)][0] if len(bn) > len(bl) else bl[len(bn)][0]
        return False, agreed, nxt
    return True, agreed, None


def run(out: Path, l1dir: Path):
    out, l1dir = Path(out), Path(l1dir)
    master, shards = find_sources(l1dir)
    if not master and not shards:
        print(f"[F layer1] no Layer 1 index under {l1dir}; skipped (mount it with HM64_LAYER1)", flush=True)
        return
    from hm64.lcg import seed_at
    routes = [r for r in load_jsonl(out / "A_routes.jsonl") if "_error" not in r and r.get("outcome") == "ready"]
    ladder = {r["signature"]: r for r in load_jsonl(out / "L_ladder.jsonl") if "_error" not in r}
    members = defaultdict(list)
    for r in routes:
        members[r["signature"]].append(r)
    meta = ro(master) if master else ro(shards / "manifest.sqlite")
    try:
        cfg = json.loads(meta.execute("select value from metadata where key='config'").fetchone()[0])
    except sqlite3.Error:
        ident = json.loads(meta.execute("select value from settings where key='identity'").fetchone()[0])
        cfg = ident["source_config"]
    l1_h = float(cfg.get("horizon_updates", 1350))
    print(f"[F layer1] source: {'master ' + str(master) if master else 'shards ' + str(shards)}; "
          f"{len(ladder)} scenarios with a ladder", flush=True)

    rows = []
    for sig, mem in sorted(members.items(), key=lambda kv: -len(kv[1])):
        if sig not in ladder:
            continue
        labels = [m["label"] for m in mem]
        q = ",".join("?" * len(labels))
        sched = meta.execute(f"select label, anchor_id, ready_vi from schedules where label in ({q})", labels).fetchall()
        anchors = sorted({a for _, a, _ in sched})
        native_rngs = sorted({seed_at(m["draw_index"]) for m in mem})
        nat, nat_h = native_path(ladder[sig])
        row = {"signature": sig, "routes": len(mem), "labels_found_in_layer1": f"{len(sched)}/{len(labels)}",
               "anchors": anchors, "anchor_rng_matches_native": None, "trajectories": 0,
               "native_changes_compared": None, "matches_tol0.5": [], "matches_tol1.0": [],
               "best_agreed_changes": 0, "best_first_divergence_u": None,
               "distinct_end_rng_all": None, "distinct_end_rng_matched": None, "hypotheses_tol0.5": []}
        if anchors:
            arng = {a: r for a, r in meta.execute(
                f"select id, rng from anchors where id in ({','.join('?' * len(anchors))})", anchors)}
            row["anchor_rng_matches_native"] = all(arng.get(a) in native_rngs for a in anchors)
        tids = [t for (t,) in meta.execute(
            f"select id from trajectories where anchor_id in ({','.join('?' * len(anchors))})", anchors)] if anchors else []
        row["trajectories"] = len(tids)
        hc = min(nat_h, l1_h) - END_MARGIN
        row["native_changes_compared"] = sum(1 for u, _ in nat[1:] if BURN <= u < hc)
        if tids and master:
            db = ro(master)
            best = (0, None)
            for tid in tids:
                segs = db.execute("select t0, t1, screen, visual_class from segments where trajectory_id=? "
                                  "and t0 < ? order by t0", (tid, hc + 2)).fetchall()
                for tol in TOLS:
                    ok, agreed, div = compare(nat, nat_h, segs, l1_h, tol)
                    if ok:
                        row[f"matches_tol{tol}"].append(tid)
                    elif tol == TOLS[-1] and agreed > best[0]:
                        best = (agreed, div)
            row["best_agreed_changes"], row["best_first_divergence_u"] = best
            if row["matches_tol1.0"]:
                row["best_agreed_changes"] = row["native_changes_compared"]
        elif tids and shards:
            for tol in TOLS:
                row[f"matches_tol{tol}"] = shard_match(shards, meta, nat, nat_h, l1_h, set(tids), tol)
        if tids:
            ends = {}
            q = ",".join("?" * len(anchors))
            for tid, er in meta.execute(f"select id, end_rng from trajectories where anchor_id in ({q})", anchors):
                ends[tid] = er
            row["distinct_end_rng_all"] = len(set(ends.values()))
            row["distinct_end_rng_matched"] = len({ends[t] for t in row["matches_tol0.5"]})
        if row["matches_tol0.5"]:
            q = ",".join("?" * len(row["matches_tol0.5"]))
            row["hypotheses_tol0.5"] = [list(h) for h in meta.execute(
                f"select id, base, screen, frame, tick, ended, first_skip, end_rng from trajectories where id in ({q})",
                row["matches_tol0.5"])]
        rows.append(row)
        print(f"[F layer1] {sig}: anchors {anchors} rng_ok={row['anchor_rng_matches_native']} "
              f"traj={len(tids)} match@0.5={len(row['matches_tol0.5'])} @1.0={len(row['matches_tol1.0'])}", flush=True)

    (out / "layer1_links.json").write_text(json.dumps(rows, indent=1))
    with (out / "layer1_links.csv").open("w", newline="") as f:
        keys = [k for k in rows[0].keys() if k != "hypotheses_tol0.5"] if rows else []
        w = csv.DictWriter(f, fieldnames=keys, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({k: (len(v) if k.startswith("matches") else v) for k, v in r.items() if k in keys})
    linked = [r for r in rows if r["anchors"]]
    m05 = [r for r in linked if r["matches_tol0.5"]]
    m10 = [r for r in linked if r["matches_tol1.0"]]
    rng_ok = sum(1 for r in linked if r["anchor_rng_matches_native"])
    n_traj = sorted(len(r["matches_tol0.5"]) for r in m05)
    L = ["## Layer 1 link (stage F)\n",
         f"Source: `{master.name if master else 'layer1_shards'}` (horizon {l1_h:.0f} updates). Native visible path "
         "compared with every Layer 1 trajectory of the scenario's anchor, from the first visible change after "
         "Layer 1's 4-update READY transition on.\n",
         f"- Scenarios linked to a Layer 1 anchor via route labels: **{len(linked)}/{len(rows)}**; anchor RNG equals "
         f"native READY RNG: **{rng_ok}/{len(linked)}**",
         f"- Scenarios whose real path is one of the Layer 1 hypotheses: **{len(m05)}/{len(linked)}** at 0.5 update, "
         f"**{len(m10)}/{len(linked)}** at 1.0 update"
         + (f"; matching hypotheses per scenario median {n_traj[len(n_traj) // 2]} (of ~"
            f"{sorted(r['trajectories'] for r in linked)[len(linked) // 2]} per anchor)" if n_traj else ""),
         ]
    if m05:
        one = sum(1 for r in m05 if r["distinct_end_rng_matched"] == 1)
        L.append(f"- Matching hypotheses collapse to ONE end state (same RNG at the Layer 1 horizon) for **{one}/{len(m05)}** "
                 "scenarios: they differ only in the sprite shown during the READY transition. Per anchor, all "
                 f"hypotheses together reach a median {sorted(r['distinct_end_rng_all'] for r in m05)[len(m05) // 2]} "
                 "distinct end states, so measuring the arrival pins the phase.")
    miss = [r for r in linked if not r["matches_tol1.0"]]
    if miss and master:
        L.append("- No match (model gap or phase outside the enumerated hypotheses): " + ", ".join(
            f"`{r['signature']}` (best agrees {r['best_agreed_changes']}/{r['native_changes_compared']} changes, "
            f"diverges ~u{r['best_first_divergence_u']})" for r in miss[:8]))
    L.append("\nFiles: `layer1_links.csv`, `layer1_links.json` (matching trajectory ids and their phase hypotheses).")
    text = "\n".join(L) + "\n"
    (out / "LAYER1.md").write_text(text)
    rep = out / "REPORT.md"
    if rep.exists():
        body = rep.read_text()
        cut = body.find("## Layer 1 link (stage F)")
        if cut >= 0:
            body = body[:cut].rstrip() + "\n\n"
        rep.write_text(body + text)
    print(text, flush=True)


def shard_match(shards, meta, nat, nat_h, l1_h, tids, tol):
    """Same test through the posting shards: every native segment from the first
    change on must exist as a posting of the trajectory with matching ends."""
    bucket = int(meta.execute("select value from settings where key='bucket_updates'").fetchone()[0])
    files = {(s, v, b): f for s, v, b, f in meta.execute("select screen, visual_class, bucket, filename from slots")}
    hc = min(nat_h, l1_h) - END_MARGIN
    idx = first_change(nat)
    if idx is None:
        return []
    segs = []
    for i in range(idx - 1, len(nat)):
        u0, pose = nat[i]
        u1 = nat[i + 1][0] if i + 1 < len(nat) else nat_h
        if u0 >= hc:
            break
        segs.append((i, u0, u1, pose))
    alive = set(tids)
    for i, u0, u1, (scr, cls) in segs:
        lo = 0 if i == idx - 1 else u0 - tol
        hi = (nat[idx][0] if i == idx - 1 else u0 + tol)
        hits = set()
        for b in range(int(max(0, lo)) // bucket, int(hi) // bucket + 1):
            f = files.get((scr, cls, b))
            if not f or not (shards / f).is_file():
                if f is None:
                    return []                  # this pose never occurs in Layer 1
                raise FileNotFoundError(f"Layer 1 shard missing: {shards / f}")
            c = ro(shards / f)
            for t0, t1, tid in c.execute("select t0, t1, tid from postings where t0 between ? and ?", (lo, hi)):
                if tid in alive and (u1 >= hc or abs(t1 - u1) <= tol + 1e-9):
                    hits.add(tid)
        alive &= hits
        if not alive:
            return []
    return sorted(alive)


if __name__ == "__main__":
    run(Path(sys.argv[1]), Path(sys.argv[2]))
