"""
Dog-wall heat map report (2026-11-17): one row per dog spot from the per-spot results of tools/dogwall_campaign.py
(dogspot_summary.json, dogwatch.json, zigzag_tables.json) -> DOGWALL.md, dogwall.json and dogwall_heatmap.html
(the wall as a strip, coloured by the Nut odds with dog-watch).
    python3 tools/dogwall_report.py results/dogwall/<tag>
"""
import json
import sys
from pathlib import Path

WIN = ("5.0", "10.0", "15.0")


def load(d):
    s = json.load(open(d / "dogspot_summary.json"))
    dog = s["save"]["dog"]
    row = {"name": d.name, "x": dog["x"], "z": dog["z"], "poke": s["save"].get("test_dog_poke"), "save": s["save"].get("file"),
           "p_ready": s["failures"].get("p_ready"), "lines": s.get("lines"), "members": s.get("members"), "casts": s.get("casts"),
           "nut_casts": s.get("nut_casts"), "checks": [s.get("repeat_checks"), s.get("member_checks")]}
    st = (s.get("lineup") or {}).get("stability") or {}
    row.update(top=st.get("top"), n50=st.get("n50"), n90=st.get("n90"))
    ar = (s.get("lineup") or {}).get("after_ready") or {}
    row["dog_drawing"] = ar.get("share_dog_drawing")
    pool = s.get("pool") or {}
    row["pool"] = {k: {q: (v.get(q) or {}).get("p") for q in ("release", "hold", "either")} for k, v in pool.items()}
    beach = (s["failures"].get("stages") or {}).get("beach") or {}
    row["beach_why"] = beach.get("why")
    kept = (s["failures"]["stages"].get("ranch") or {}).get("mass_kept")
    row["beach_reach"] = (s["failures"].get("p_ready") / kept) if kept else None       # of the routes that get to the beach
    if (d / "dogwatch.json").exists():
        j = json.load(open(d / "dogwatch.json"))
        vis = list(j["visibility"].values())
        row["on_grid"] = sum(v["on_grid"] for v in vis) / max(1, len(vis))
        row["changes_per_min"] = sum(v["changes_per_min"] for v in vis) / max(1, len(vis))
        row["dw"] = {w: {k: j["table"][f"gear|{w}"].get(k) for k in ("top1", "p_true", "left", "logs", "odds_base", "odds_obs", "odds_known")}
                     for w in WIN if f"gear|{w}" in j["table"]}
    return row


def pc(x, nd=1):
    return "—" if x is None or x != x else f"{100 * x:.{nd}f}%"


def main():
    root = Path(sys.argv[1])
    rows = []
    for d in sorted(p for p in root.iterdir() if p.is_dir() and (p / "dogspot_summary.json").exists()):
        try:
            rows.append(load(d))
        except Exception as e:                                         # noqa: BLE001
            print(f"[dogwall] {d.name}: not readable yet ({e})")
    if not rows:
        print("[dogwall] no finished spot yet")
        return 1
    rows.sort(key=lambda r: -r["x"])                                   # from the lineup2 corner north-west along the wall
    ctl = next((r for r in rows if not r["poke"]), None)
    L = ["# Dog-wall heat map — dog spots along the beach's back (south-west) wall", "",
         f"{len(rows)} spots done. Each spot: the dog-watch lab on the fast mornings (menus 0–4 game frames late), dog traces 40 s, casts every game "
         "frame 0.1–20 s after READY. The spot is written into the dog's record at the house load (a stand-in for a save made with the dog put "
         "down there); `control` = the save as it is. Wall = Jack's own track along it (z 222.2, x −447 … −210); north-west = x falling.", "",
         "Odds are the lab report's (cast ±150 ms, release at bite 1 or hold to bite 2, no dock-end tap, cast at least 2 s after the watch and inside "
         "the 20 s of cast tables): use them to RANK spots, not as the app's odds "
         "(on lineup2 the same report says 7 → 15% where the app measured 12 → 28.5%).", "",
         "| spot | dog x | z | routes reaching the dock end | dog lines | heaviest line | lines for 90% | dog on the view grid | "
         "Nut, no logs | **Nut, dog-watch 5 s** | Nut, dog-watch 10 s | Nut, line known | right line on top (5 s) | Nut casts in the tables (bite 1 / 2) |",
         "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for r in rows:
        d = (r.get("dw") or {}).get("5.0") or {}
        d10 = (r.get("dw") or {}).get("10.0") or {}
        L.append(f"| {r['name']} | {r['x']:.1f} | {r['z']:.1f} | {pc(r.get('beach_reach'), 0)} | {r['lines']} | {pc(r['top'], 0)} | {r['n90']} | {pc(r.get('on_grid'), 0)} | "
                 f"{pc(d.get('odds_base'))} | **{pc(d.get('odds_obs'))}** | {pc(d10.get('odds_obs'))} | {pc(d.get('odds_known'))} | {pc(d.get('top1'), 0)} | "
                 f"{(r['nut_casts'] or ['—', '—'])[0]} / {(r['nut_casts'] or ['—', '—'])[1]} of {r['casts']} |")
    L += ["", "## Dog-watch by watch length (Nut no logs → with logs; right line on top)", "", "| spot | 5 s | 10 s | 15 s |", "|---|---|---|---|"]
    for r in rows:
        cells = []
        for w in WIN:
            d = (r.get("dw") or {}).get(w)
            cells.append("—" if not d else f"{pc(d['odds_base'])} → {pc(d['odds_obs'])} ({pc(d['top1'], 0)})")
        L.append(f"| {r['name']} | " + " | ".join(cells) + " |")
    best = max((r for r in rows if (r.get("dw") or {}).get("5.0")), key=lambda r: r["dw"]["5.0"]["odds_obs"] or 0, default=None)
    if best:
        L += ["", f"Best spot so far by Nut with a 5 s dog-watch (casts 7–20 s after READY): **{best['name']}** (x {best['x']:.1f}): {pc(best['dw']['5.0']['odds_obs'])}"
              + (f"; control {pc(ctl['dw']['5.0']['odds_obs'])}" if ctl and (ctl.get('dw') or {}).get('5.0') else "") + ".",
              "A spot counts only if it is on your screen from the dock end (the view-grid column says the game animates the dog there; the "
              "renders in each spot's `render/` folder show where it is on screen) and if the routes still reach the dock end.",
              "Before building on a spot: make a real save with the dog put down there and run the normal dog-watch on it."]
    bad = [r for r in rows if r.get("beach_reach") is not None and r["beach_reach"] < 0.98]
    if bad:
        L += ["", "Routes blocked (the dog stands in Jack's way): " + "; ".join(f"{r['name']} {pc(1 - r['beach_reach'], 0)} ({r.get('beach_why')})" for r in bad)]
    (root / "DOGWALL.md").write_text("\n".join(L) + "\n", encoding="utf8")
    json.dump(rows, open(root / "dogwall.json", "w"), indent=1)
    # heat strip
    vals = [(r, ((r.get("dw") or {}).get("5.0") or {}).get("odds_obs")) for r in rows]
    known = [v for _, v in vals if v is not None]
    lo, hi = (min(known), max(known)) if known else (0, 1)
    W, X0, X1 = 900, -460.0, -180.0
    sx = lambda x: 40 + (x - X0) / (X1 - X0) * (W - 80)
    def col(v):
        if v is None:
            return "#555"
        t = 0.5 if hi <= lo else (v - lo) / (hi - lo)
        return f"rgb({int(40 + 215 * t)},{int(70 + 120 * (1 - abs(2 * t - 1)))},{int(200 - 170 * t)})"
    svg = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} 230" font-family="sans-serif" font-size="12">',
           f'<rect x="0" y="0" width="{W}" height="230" fill="#10202c"/>',
           f'<line x1="{sx(-447.2)}" y1="120" x2="{sx(-210.2)}" y2="120" stroke="#8ea3b2" stroke-width="3"/>',
           f'<text x="{sx(-447.2)}" y="150" fill="#8ea3b2">north-west end of the wall (x −447)</text>',
           f'<text x="{sx(-210.2)}" y="150" fill="#8ea3b2" text-anchor="end">corner (x −210)</text>',
           '<text x="20" y="24" fill="#e8f0f4" font-size="15">Nut odds with a 5 s dog-watch (casts to 20 s), by dog spot on the back wall (lab report odds; red = best)</text>']
    for r, v in vals:
        x = sx(r["x"])
        svg.append(f'<circle cx="{x}" cy="{100 if r["poke"] else 86}" r="17" fill="{col(v)}" stroke="#fff" stroke-width="{2 if not r["poke"] else 0.5}"/>')
        svg.append(f'<text x="{x}" y="{104 if r["poke"] else 90}" fill="#fff" text-anchor="middle" font-size="11">{"—" if v is None else f"{100 * v:.1f}"}</text>')
        svg.append(f'<text x="{x}" y="{64 if r["poke"] else 56}" fill="#e8f0f4" text-anchor="middle" font-size="10">{"control" if not r["poke"] else f"x {r["x"]:.0f}"}</text>')
        if r.get("beach_reach") is not None and r["beach_reach"] < 0.98:
            svg.append(f'<text x="{x}" y="186" fill="#ff9c8a" text-anchor="middle" font-size="10">blocks {100 * (1 - r["beach_reach"]):.0f}%</text>')
        if r.get("on_grid") is not None and r["on_grid"] < 0.5:
            svg.append(f'<text x="{x}" y="200" fill="#ffd28a" text-anchor="middle" font-size="10">off view</text>')
    svg.append("</svg>")
    (root / "dogwall_heatmap.html").write_text("<!DOCTYPE html><html><head><meta charset='utf-8'><title>HM64 dog-wall heat map</title></head>"
                                                "<body style='margin:0;background:#10202c'>" + "".join(svg) + "</body></html>", encoding="utf8")
    print("\n".join(L))
    return 0


if __name__ == "__main__":
    sys.exit(main())
