#!/usr/bin/env python3
"""Horse-table run, pre-flight (2026-11-23). The zigzag reference route (mash 10/s START>A, U276 V52 C80 D86 B134)
from power-on on the beach-lineup2-horse save, twice in fresh emulators (zigzag_jobs.zz_record_job = the dog-spot lab's
Z0 record), compared with the numbers Claude's sandbox measured on the same save with the x86 mupen64plus bundle
(2026-11-23). Equal = the right save, and the build on this machine reproduces the sandbox through the farm with the
horse, the crossroads, the ranch and the beach to READY. Different = stop before anything else runs.
  HM64_SRAM=<save> python3 tools/horse_z0_check.py
Sandbox facts behind EXPECT (same route, same save; diagnostic test copy with horseFlags = 0 for comparison):
  the horse entity loads at farm +99 VIs, draws 2 random numbers there (updateHorse at initializeHorseEntity, decomp
  animals.c), its tile stays off the visibility grid for the whole farm walk (no further draws); without the horse the
  crossroads / ranch / beach loads come at draws 838 / 960 / 1081 instead of 840 / 962 / 1083."""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "experiments"))
from m64h.pool import run_jobs                  # noqa: E402
from tools.common import default_rom, default_sram  # noqa: E402

EXPECT = {"house": [1036, 499], "farm": [1448, 704], "beach": [2264, 1083], "wake": [213, 1190],
          "ready": [339, -92.0, 194.0, 1269]}   # zz_record_job "got", sandbox x86 bundle, 2026-11-23 (two cold boots equal)


def main():
    import zigzag_jobs as ZJ
    res = list(run_jobs(ZJ.zz_record_job, [{"run": 1}, {"run": 2}], rom=default_rom(), sram=default_sram(),
                        workers=2, fresh=True))
    bad = [r for r in res if "_error" in r]
    if bad:
        print("STOP: the record run failed: " + bad[0]["_error"][-600:], flush=True)
        return 2
    res.sort(key=lambda r: r["_job"]["run"])
    a, b = ({k: v for k, v in r.items() if k != "_job"} for r in res)
    got = a["got"]
    sv = a["info"].get("save", {})
    d5 = a["info"]["stages"].get("5", {}).get("dog", {})
    print(f"  save: {sv.get('season_name')} {sv.get('day')} year {sv.get('year')}, weather {sv.get('weather')}, "
          f"rod in hand {sv.get('rod_in_hand')}; dog at the beach load: map {d5.get('location')} x {d5.get('x')} z {d5.get('z')}", flush=True)
    print(f"  reference route: {json.dumps(got)}", flush=True)
    if a != b:
        print("STOP: two cold boots of this save gave different records (not repeatable).", flush=True)
        return 3
    if EXPECT is not None and got != EXPECT:
        print(f"STOP: the reference route does not give the sandbox numbers {json.dumps(EXPECT)} - wrong save, or this "
              "emulator build differs from the sandbox on it. Nothing was run. Send this log to Claude.", flush=True)
        return 3
    print("  equal to Claude's sandbox record of this save (x86 build): OK", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
