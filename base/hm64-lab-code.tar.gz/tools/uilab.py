"""
HM64 UI lab (2026-11-16, "optimization suite"): how good is the app's cast suggestion, measured against the emulator.

A simulated runner plays known route members (the ones the cast tables were built from) through the REAL web app in a
headless browser and through the REAL game in the emulator, on one absolute clock (abs ms 0 = the first light of the
beach fade-in; console VI n of the fade-in stopwatch starts at (n - 1) x 16.715 ms):
  plan       sample attempts: an app variant by its route weight -> a member route (beach state, D, B) that is that
             variant -> the runner's taps, B-press error, bite-tap lags (and, on dog-watch routes, his arrows)
  emu-trace  (dog-watch routes) the dog's facing / animation per VI after the member's READY, from the emulator
  ui 1       the app, fed the taps (+ arrows): where and when it puts the CAST cue, what odds it shows
  emu-cast   the game: the cast at the VI the runner's press falls on (+ casts around the aim), every bite to 90 s
  ui 2       the app again (same inputs), now with the real bite times: the lamp decides release / hold / DUD
  report     Nut rate vs the odds the app showed, where the Nut frames really were around the aim, tables vs emulator
All files live in --dir. The emulator steps need the lab image (m64h, experiments/); the ui steps need a Chromium.
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import glob
import html as _html
import json
import math
import os
import random
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VI_MS = 33.430 / 2
EXIT_VI, CTRL_VI = -70, 66                       # the app's tap cues on the fade-in clock (hm64_lucky CUES)
NUMPAD = {0: [0], 1: [40], 2: [32], 3: [80], 4: [8], 5: [16, 72], 6: [112], 7: [168, 96, 160], 8: [152, 144], 9: [128, 136]}
GROUP_OF = {b: g for g, bs in NUMPAD.items() for b in bs}
MIN_RUN, LONG_VI, READABLE = 12, 60, {0, 4, 5, 6, 7}

RUNNERS = {   # the simulated runner; the app is told the same numbers (a calibrated player), see storage_for()
    "robot":   dict(tap_delay=0, tap_sd=0, press_bias=0, press_sd=0, lag_mu=217, lag_sd=0, note="no timing error at all"),
    "sharp":   dict(tap_delay=230, tap_sd=30, press_bias=0, press_sd=30, lag_mu=217, lag_sd=40),
    "good":    dict(tap_delay=230, tap_sd=50, press_bias=0, press_sd=60, lag_mu=217, lag_sd=58),
    "typical": dict(tap_delay=230, tap_sd=60, press_bias=0, press_sd=100, lag_mu=217, lag_sd=58),
    "loose":   dict(tap_delay=230, tap_sd=80, press_bias=0, press_sd=140, lag_mu=217, lag_sd=58),
}
DOG = dict(lo=10, hi=25, miss_f=0.0, miss_a=0.15, gap=12, numpad=True)      # arrows: reaction VIs, misses, one key per gap VIs


def app_data(path):
    s = Path(path).read_text(encoding="utf8")
    i = s.index("const HM64_DATA=") + len("const HM64_DATA=")
    return json.JSONDecoder().raw_decode(s, i)[0]


def load_jsonl(p):
    out = []
    if os.path.exists(p):
        for line in open(p):
            line = line.strip()
            if line:
                try:
                    out.append(json.loads(line))
                except ValueError:
                    pass
    return out


def storage_for(route, base, rn, dog):
    """the app's stored settings for a player who knows his own numbers (no learning needed inside the test)"""
    press = max(30.0, rn["press_sd"])
    lucky = {"route": base, "routeAnchor": {base: "fadein", route: "fadein"}, "routePace": {}, "tapStrategy": "ebd", "beachCue": "ctrl",
             "sigmaAuto": False, "sigmaMs": round(math.hypot(press, 60)), "tapSdAuto": False, "tapSdMs": max(15, rn["tap_sd"]),
             "biasAuto": False, "biasMs": -rn["press_bias"], "startTapMs": rn["tap_delay"], "autoTune": False, "audio": False,
             "policy": "auto", "castTap": False, "dwOn": bool(dog.get("on")), "dwStrict": bool(dog.get("strict")),
             "dwLateMs": dog.get("late_ms", 1000), "dwKeys": "arrows", "howOpen": False}
    return {"hm64v29_lucky": lucky,
            "hm64v28_settings": {"updateMs": 33.43, "tapMuVI": round(rn["lag_mu"] / VI_MS, 2), "tapSdVI": max(2.5, round(rn["lag_sd"] / VI_MS, 2))},
            "hm64v30_tb": {"from": 33.43, "to": 33.43, "changed": False, "taps": True, "sets": True}}


# ------------------------------------------------------------------------------------------------ plan
def cmd_plan(a):
    D = app_data(a.app)
    R = next(r for r in D["lroutes"] if r["id"] == a.route)
    base = R.get("variant_of") or R["id"]
    lines = json.load(open(a.lines))
    g = next(x for x in R["groups"] if x["id"] == "all")
    rnd = random.Random(a.seed)
    rn = dict(RUNNERS[a.runner])
    if a.runner_json:
        rn.update(json.loads(a.runner_json))
    dog = dict(DOG, on=bool(a.dogwatch) and "dw" in R, strict=bool(a.strict), late_ms=a.late_ms)
    have = None
    if a.store:
        have = {os.path.basename(p)[:-3] for p in glob.glob(os.path.join(a.store, "b", "*.st"))}
    vs = [("line", li, w, o, mt, R["line_info"][li]["key"]) for li, w, o, mt in g["v"]["fadein"]]
    if "dw" in R:
        vs += [("uncast", dwi, w, o, mt, R["dw"]["lines"][dwi]["key"]) for dwi, w, o, mt in (g.get("vu") or {}).get("fadein", [])]
    index, unmatched = {}, 0.0
    for kind, li, w, o, mt, key in vs:                             # members that ARE this variant
        ms = [m for m in lines.get(key, {}).get("members", []) if m.get("k_off") == o + mt - 1 and m.get("ready_rel") == mt + 2
              and (have is None or m["b"].split("@")[0] in have)]
        if ms:
            index[(kind, li, o, mt)] = ms
        else:
            unmatched += w
    keys = [v for v in vs if (v[0], v[1], v[3], v[4]) in index]
    W = sum(v[2] for v in keys)
    if not keys:
        sys.exit("no app variant has a member route in zz_lines.json (wrong results folder for this route?)")
    cum, acc = [], 0.0
    for v in keys:
        acc += v[2]
        cum.append(acc)
    atts = []
    for n in range(a.n):
        x = rnd.random() * W
        lo, hi = 0, len(cum) - 1
        while lo < hi:
            mid = (lo + hi) // 2
            if cum[mid] < x:
                lo = mid + 1
            else:
                hi = mid
        kind, li, w, o, mt, key = keys[lo]
        ms = index[(kind, li, o, mt)]
        m = rnd.choices(ms, weights=[max(1e-12, q.get("w", 1)) for q in ms])[0]
        g_ = lambda sd: rnd.gauss(0, sd) if sd > 0 else 0.0
        taps = [{"cue": "exit", "ms": EXIT_VI * VI_MS + rn["tap_delay"] + g_(rn["tap_sd"])},
                {"cue": "ctrl", "ms": CTRL_VI * VI_MS + rn["tap_delay"] + g_(rn["tap_sd"])},
                {"cue": "dock", "ms": (mt - 1) * VI_MS + rn["tap_delay"] + g_(rn["tap_sd"])}]
        atts.append({"id": n, "kind": kind, "li": li if kind == "line" else -1, "dwi": (R["dw"]["of_line"][li] if kind == "line" else li) if "dw" in R else None,
                     "o": o, "mt": mt, "key": key, "b": m["b"], "D": m["D"], "B": m["B"], "k_off": m["k_off"], "ready_rel": m["ready_rel"],
                     "taps": taps, "pressErr": rn["press_bias"] + g_(rn["press_sd"]),
                     "lags": [max(60.0, rn["lag_mu"] + g_(rn["lag_sd"])) for _ in range(12)], "dogseed": rnd.randrange(1 << 30)})
    out = Path(a.dir)
    out.mkdir(parents=True, exist_ok=True)
    plan = {"route": a.route, "base": base, "sparrows": R.get("variant") == "sparrows", "runner": a.runner, "rn": rn, "dog": dog, "seed": a.seed,
            "n": a.n, "cover": W, "unmatched": unmatched, "storage": storage_for(a.route, base, rn, dog), "window": a.window,
            "bite_until": (R.get("source") or {}).get("bite_horizon", 5398), "attempts": atts, "app": os.path.basename(a.app)}
    if a.goal == "time":                                           # v30.6: the cast picked for the fastest Nut (odds per minute)
        plan["storage"]["hm64v29_lucky"].update(goal="time", goalOverS=a.goal_over)
        plan["goal"] = {"goal": "time", "over": a.goal_over}
    if a.storage:                                                  # the player's own exported browser storage instead
        plan["storage"] = json.load(open(a.storage))
        plan["storage_own"] = True
    json.dump(plan, open(out / "plan.json", "w"))
    shutil.copy(a.app, out / "app.html")
    print(f"[plan] {a.n} attempts on {a.route} (runner {a.runner}{', dog-watch' if dog['on'] else ''}): {len(keys)} of {len(vs)} variants have a member "
          f"({100 * W / (W + unmatched):.1f}% of the route weight), {len({(x['b'], x['D'], x['B']) for x in atts})} distinct member routes")


# ------------------------------------------------------------------------------------------------ emulator steps
def _run_emu(fn_name, jobs, out_path, workers, key="id"):
    sys.path.insert(0, str(ROOT))
    sys.path.insert(0, str(ROOT / "experiments"))
    from m64h.pool import run_jobs
    from tools.common import default_rom, default_sram
    import uilab_jobs
    done = {r[key] for r in load_jsonl(out_path) if "_error" not in r and "error" not in r}
    todo = [j for j in jobs if j[key] not in done]
    print(f"[{fn_name}] {len(jobs)} jobs, {len(done)} done, {len(todo)} to run", flush=True)
    if not todo:
        return
    t0, n = time.time(), 0
    with open(out_path, "a") as f:
        for res in run_jobs(getattr(uilab_jobs, fn_name), todo, rom=default_rom(), sram=default_sram(), workers=workers, fresh=False):
            if "_error" in res or "error" in res:
                print(f"[{fn_name}] job error: {str(res.get('_error') or res.get('error'))[-300:]}", flush=True)
            f.write(json.dumps(res) + "\n")
            f.flush()
            n += 1
            if n % 10 == 0 or n == len(todo):
                el = time.time() - t0
                print(f"[{fn_name}] {n}/{len(todo)}  {n / el:.2f} jobs/s  eta {el / n * (len(todo) - n) / 60:.1f} min", flush=True)


def mkey(x):
    return f"{x['b']}:{x['D']}:{x['B']}"


def cmd_emu_trace(a):
    d = Path(a.dir)
    plan = json.load(open(d / "plan.json"))
    if not plan["dog"]["on"]:
        print("[emu-trace] dog-watch is off for this plan: nothing to do")
        return
    seen, jobs = set(), []
    for x in plan["attempts"]:
        if mkey(x) not in seen:
            seen.add(mkey(x))
            jobs.append({"id": mkey(x), "b": x["b"], "D": x["D"], "B": x["B"], "until": 2400})
    _run_emu("ui_trace_job", jobs, d / "traces.jsonl", a.workers)


def latest_ui(d):
    """per attempt the newest UI row that has a press (pass 2 rows replace pass 1)"""
    rows = {}
    for p in ("ui1.jsonl", "ui2.jsonl"):
        for r in load_jsonl(d / p):
            if r.get("press"):
                rows[r["id"]] = r
    return rows


def cmd_emu_cast(a):
    d = Path(a.dir)
    plan = json.load(open(d / "plan.json"))
    ui = latest_ui(d)
    have = {}
    for r in load_jsonl(d / "casts.jsonl"):
        if "casts" in r:
            have.setdefault(r["_job"]["att"], set()).update(c["tau"] for c in r["casts"])
    jobs, skipped = [], 0
    for x in plan["attempts"]:
        u = ui.get(x["id"])
        if not u:
            continue
        pt, at = u["press"]["tau"], u["press"]["aimTau"]
        a0 = at - ((at + x["k_off"]) % 2)                        # the tables hold one cast per game frame (even k = tau + k_off);
        taus = {pt} | {a0 + k for k in range(-plan["window"], plan["window"] + 1, 2)}   # an odd VI belongs to the frame before it
        taus = {t for t in taus if 4 <= t <= 2398} - have.get(x["id"], set())
        if not (4 <= pt <= 2398):
            skipped += 1
        if taus:
            jobs.append({"id": f"{x['id']}:{min(taus)}:{len(taus)}:{pt}", "att": x["id"], "b": x["b"], "D": x["D"], "B": x["B"], "taus": sorted(taus),
                         "bite_until": plan["bite_until"]})
    if skipped:
        print(f"[emu-cast] {skipped} presses fall outside the tables' range (4..2398 VIs after READY): not evaluated")
    _run_emu("ui_cast_job", jobs, d / "casts.jsonl", a.workers)


def casts_of(d):
    out = {}
    for r in load_jsonl(d / "casts.jsonl"):
        if "casts" in r:
            for c in r["casts"]:
                out.setdefault(r["_job"]["att"], {})[c["tau"]] = c
    return out


# ------------------------------------------------------------------------------------------------ the dog logs
def dog_logs(x, runs, dog, t_from_ms):
    """the runner's arrows / numpad keys (abs ms) from what the dog really showed (runs: k0, k1, facing, base, visible;
    k = VIs after the member's READY). Same runner as DogWatch.simulateLogs: the facing it has when he starts, then every
    facing change that lasts >= 12 VIs (missed with miss_f), numpad for animations >= 1 s in a readable facing."""
    rnd = random.Random(x["dogseed"])
    ms_of = lambda k: (x["mt"] + k - 1) * VI_MS
    fac, grp = [], []
    for k0, k1, f, base, vis in runs:
        if fac and fac[-1][2] == f:
            fac[-1][1] = k1
        else:
            fac.append([k0, k1, f])
        gname = GROUP_OF.get(base, -1 - base)
        if grp and grp[-1][2] == gname:
            grp[-1][1] = k1
        else:
            grp.append([k0, k1, gname, f])
    k_from = (t_from_ms / VI_MS + 1) - x["mt"]
    react = lambda: (dog["lo"] + rnd.random() * (dog["hi"] - dog["lo"])) * VI_MS
    logs = []
    cur = next((r for r in fac if r[0] <= k_from < r[1]), None)
    if cur:
        logs.append({"ms": t_from_ms + react(), "f": cur[2]})
    ev = [("f", r[0], r[1], r[2]) for r in fac] + ([("g", r[0], r[1], r[2]) for r in grp if r[2] >= 0 and r[1] - r[0] >= LONG_VI and r[3] in READABLE]
                                                  if dog.get("numpad", True) else [])
    ev.sort(key=lambda e: e[1])
    for kind, k0, k1, lab in ev:
        if k0 < k_from or k1 - k0 < MIN_RUN or rnd.random() < (dog["miss_f"] if kind == "f" else dog["miss_a"]):
            continue
        ms = ms_of(k0) + react()
        if logs and ms < logs[-1]["ms"] + dog["gap"] * VI_MS:
            ms = logs[-1]["ms"] + dog["gap"] * VI_MS
        logs.append({"ms": ms, kind: lab})
    logs.sort(key=lambda e: e["ms"])
    return logs


# ------------------------------------------------------------------------------------------------ the browser steps
# The app's frame loop (requestAnimationFrame) is put on the page's timer clock: under --virtual-time-budget the browser's
# real animation frames come at real-time 60 Hz while timers run on virtual time, so the app would see only a few frames
# per virtual minute. With this every FRAME_MS of virtual time gets its frame, and a run is repeatable.
FRAME_MS = os.environ.get("HM64_UILAB_FRAME_MS", "16.7")
PRE = """<script>(function(){try{localStorage.clear();var S=%s;for(var k in S)localStorage.setItem(k,JSON.stringify(S[k]));}catch(e){}
window.requestAnimationFrame=function(cb){return window.__UILAB_DONE?0:setTimeout(function(){cb(performance.now());},%s);};
window.__UILAB_SC=%s;})();</script>"""


def run_one(chrome, app_html, driver, storage, sc, budget_ms, tmpdir, timeout=600):
    i = app_html.find("<script>")
    j = app_html.rfind("</body>")
    page = (app_html[:i] + PRE % (json.dumps(storage), FRAME_MS, json.dumps(sc)) + app_html[i:j]
            + "<script>" + driver.replace("</", "<\\/") + "</script>" + app_html[j:])
    f = os.path.join(tmpdir, f"a{sc['id']}_{sc['pass']}.html")
    prof = os.path.join(tmpdir, f"p{sc['id']}_{sc['pass']}")
    open(f, "w", encoding="utf8").write(page)
    cmd = [chrome, "--headless=new", "--no-sandbox", "--disable-gpu", "--disable-dev-shm-usage", "--hide-scrollbars", "--mute-audio",
           f"--user-data-dir={prof}", f"--virtual-time-budget={int(budget_ms)}", "--dump-dom", "file://" + f]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        m = re.search(r'<pre id="testout">(.*?)</pre>', r.stdout, re.S)
        res = json.loads(_html.unescape(m.group(1))) if m else {"id": sc["id"], "pass": sc["pass"], "errors": [f"no output from the page ({len(r.stdout)} bytes of DOM; {r.stderr[-200:]})"]}
    except Exception as e:                                         # noqa: BLE001
        res = {"id": sc["id"], "pass": sc["pass"], "errors": [f"browser: {e}"]}
    finally:
        try:
            os.remove(f)
        except OSError:
            pass
        shutil.rmtree(prof, ignore_errors=True)
    return res


def cmd_ui(a):
    d = Path(a.dir)
    plan = json.load(open(d / "plan.json"))
    app_html = (d / "app.html").read_text(encoding="utf8")
    driver = (ROOT / "uilab" / "uilab_driver.js").read_text(encoding="utf8")
    traces = {r["id"]: r for r in load_jsonl(d / "traces.jsonl") if "runs" in r}
    casts = casts_of(d)
    ui1 = {r["id"]: r for r in load_jsonl(d / "ui1.jsonl")}
    outp = d / f"ui{a.pass_}.jsonl"
    prev = {}
    for r in load_jsonl(outp):
        prev[r["id"]] = r
    chrome = a.chrome or os.environ.get("HM64_CHROME") or next((c for c in ("chromium", "chromium-browser", "google-chrome") if shutil.which(c)), None)
    if not chrome:
        sys.exit("no Chromium found (set HM64_CHROME)")
    todo = []
    for x in plan["attempts"]:
        sc = {"id": x["id"], "pass": a.pass_, "viMs": VI_MS, "lead": 2500, "taps": x["taps"], "sparrows": plan["sparrows"], "pressErr": x["pressErr"],
              "react": 100, "lags": x["lags"], "truth": {"li": x["li"], "o": x["o"], "mt": x["mt"], "dwi": x["dwi"]}, "tR": x["mt"], "bites": None, "dog": []}
        if plan["dog"]["on"]:
            tr = traces.get(mkey(x))
            if not tr:
                continue
            sc["dog"] = dog_logs(x, tr["runs"], plan["dog"], x["taps"][2]["ms"] + 150)
        end = 50000
        if a.pass_ == 2:
            u = (latest_ui(d)).get(x["id"]) or ui1.get(x["id"])
            if not u or not u.get("press"):
                continue
            c = casts.get(x["id"], {}).get(u["press"]["tau"])
            if not c:
                continue
            p = prev.get(x["id"])
            if p and p.get("outcome") and not p.get("resync") and p.get("press", {}).get("tau") == u["press"]["tau"]:
                continue                                           # already played with these bites
            sc["bites"] = {"tau": u["press"]["tau"], "list": [[(x["mt"] + b - 1) * VI_MS, nut] for b, nut in c["bites"] if b is not None]}
            end = max([u["press"]["abs"]] + [b[0] for b in sc["bites"]["list"]]) + 1500
        elif x["id"] in prev and prev[x["id"]].get("press"):
            continue
        todo.append((sc, sc["lead"] + end + 3000))
    print(f"[ui {a.pass_}] {len(todo)} attempts to play in the app ({chrome}, {a.procs} at a time)", flush=True)
    if not todo:
        return
    tmp = tempfile.mkdtemp(prefix="uilab-", dir="/dev/shm" if os.path.isdir("/dev/shm") else None)
    t0, n, bad = time.time(), 0, 0
    try:
        with cf.ThreadPoolExecutor(max_workers=a.procs) as ex, open(outp, "a") as f:
            futs = [ex.submit(run_one, chrome, app_html, driver, plan["storage"], sc, b, tmp) for sc, b in todo]
            for fu in cf.as_completed(futs):
                res = fu.result()
                bad += bool(res.get("errors"))
                f.write(json.dumps(res) + "\n")
                f.flush()
                n += 1
                if n % 10 == 0 or n == len(todo):
                    el = time.time() - t0
                    print(f"[ui {a.pass_}] {n}/{len(todo)}  {n / el:.2f} attempts/s  eta {el / n * (len(todo) - n) / 60:.1f} min  ({bad} with errors)", flush=True)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def cmd_status(a):
    """prints how many attempts still need an emulator cast or a second UI pass (the runner loops on it)"""
    d = Path(a.dir)
    plan = json.load(open(d / "plan.json"))
    ui, casts = latest_ui(d), casts_of(d)
    ui2 = {}
    for r in load_jsonl(d / "ui2.jsonl"):
        ui2[r["id"]] = r
    need_cast = sum(1 for x in plan["attempts"] if x["id"] in ui and 4 <= ui[x["id"]]["press"]["tau"] <= 2398 and ui[x["id"]]["press"]["tau"] not in casts.get(x["id"], {}))
    need_ui2 = sum(1 for x in plan["attempts"] if x["id"] in ui and ui[x["id"]]["press"]["tau"] in casts.get(x["id"], {})
                   and not (ui2.get(x["id"], {}).get("outcome") and not ui2[x["id"]].get("resync")))
    print(f"{need_cast} {need_ui2}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("plan")
    p.add_argument("--app", required=True)
    p.add_argument("--lines", required=True, help="zz_lines.json of the campaign the route table was built from")
    p.add_argument("--route", default="lineup-lineup2")
    p.add_argument("--n", type=int, default=200)
    p.add_argument("--seed", type=int, default=1)
    p.add_argument("--runner", default="typical", choices=sorted(RUNNERS))
    p.add_argument("--runner-json", default="", help='overrides, e.g. {"press_sd": 80}')
    p.add_argument("--dogwatch", type=int, default=0)
    p.add_argument("--strict", type=int, default=0)
    p.add_argument("--late-ms", type=int, default=1000)
    p.add_argument("--window", type=int, default=8, help="casts evaluated around the aim: +-window VIs, every 2nd")
    p.add_argument("--store", default="", help="only members whose beach state is in this state store")
    p.add_argument("--goal", default="odds", choices=["odds", "time"], help="time = the app's 'fastest Nut' aim (app v30.6+)")
    p.add_argument("--goal-over", type=int, default=55, help="seconds an attempt costs besides the wait for the cast")
    p.add_argument("--storage", default="", help="JSON of the player's own browser storage (instead of the calibrated one)")
    p.add_argument("--dir", required=True)
    p.set_defaults(fn=cmd_plan)
    for name, fn in (("emu-trace", cmd_emu_trace), ("emu-cast", cmd_emu_cast)):
        p = sub.add_parser(name)
        p.add_argument("--dir", required=True)
        p.add_argument("--workers", type=int, default=max(1, (os.cpu_count() or 2) - 1))
        p.set_defaults(fn=fn)
    p = sub.add_parser("ui")
    p.add_argument("--dir", required=True)
    p.add_argument("--pass", dest="pass_", type=int, choices=[1, 2], required=True)
    p.add_argument("--procs", type=int, default=max(1, (os.cpu_count() or 2) - 1))
    p.add_argument("--chrome", default="")
    p.set_defaults(fn=cmd_ui)
    p = sub.add_parser("status")
    p.add_argument("--dir", required=True)
    p.set_defaults(fn=cmd_status)
    p = sub.add_parser("report")
    p.add_argument("--dir", required=True)
    p.set_defaults(fn=lambda a: __import__("uilab_report").report(a.dir))
    a = ap.parse_args()
    a.fn(a)


if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    main()
