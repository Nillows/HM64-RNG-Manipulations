#!/usr/bin/env python3
"""
replay_compare.py - row-for-row comparison of two zigzag/lineup result folders
(an existing run vs a replay of the same preset on another emulator build).

  python3 tools/replay_compare.py OLD_DIR NEW_DIR [--md REPLAY.md] [--json replay.json]

Every Z*.jsonl row is keyed by its job (`_job`). For jobs present in both
folders the whole row must be equal (minus `_job` and timing-only fields).
Jobs present on one side only are listed separately: they come from the two
runs choosing different work (code version, sampling), not from the emulator.
Z0_record.json (the reference route record) is compared field by field.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

VOLATILE = {"_job", "t", "sec", "secs", "elapsed", "wall", "time", "host", "pid", "worker"}


def norm(o):
    if isinstance(o, dict):
        return {k: norm(v) for k, v in sorted(o.items()) if k not in VOLATILE}
    if isinstance(o, list):
        return [norm(v) for v in o]
    return o


def key(o):
    return json.dumps(o.get("_job"), sort_keys=True)


def rows(p):
    out, errors = {}, 0
    if not p.exists():
        return None, 0
    for line in p.read_text().splitlines():
        if not line.strip():
            continue
        try:
            o = json.loads(line)
        except ValueError:
            continue
        if "_error" in o or "error" in o:
            errors += 1
            continue
        out[key(o)] = json.dumps(norm(o), sort_keys=True)
    return out, errors


def _lines(p):
    for line in p.read_text().splitlines():
        if line.strip():
            try:
                o = json.loads(line)
            except ValueError:
                continue
            if "_error" not in o and "error" not in o:
                yield o


def flat_z5(p):
    out = {}
    for r in _lines(p):
        for row in r.get("rows", []):
            if not (isinstance(row, list) and len(row) > 6 and isinstance(row[6], list)):
                continue
            out[(r.get("b"), row[0], "head")] = json.dumps(row[:6])
            for cell in row[6]:
                out[(r.get("b"), row[0], cell[0])] = json.dumps(cell)
    return out


def flat_z7(p):
    out = {}
    for r in _lines(p):
        for c in r.get("casts", []):
            x = {k: v for k, v in c.items() if k != "hash_ok"}
            out[(r.get("key"), c.get("k"))] = json.dumps(x, sort_keys=True)
    return out


def first_diff(a, b, path=""):
    if type(a) != type(b):
        return path, a, b
    if isinstance(a, dict):
        for k in sorted(set(a) | set(b)):
            if a.get(k) != b.get(k):
                return first_diff(a.get(k), b.get(k), f"{path}.{k}")
    elif isinstance(a, list):
        if len(a) != len(b):
            return f"{path}[len]", len(a), len(b)
        for i, (x, y) in enumerate(zip(a, b)):
            if x != y:
                return first_diff(x, y, f"{path}[{i}]")
    return path, a, b


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("old"); ap.add_argument("new")
    ap.add_argument("--md"); ap.add_argument("--json")
    ap.add_argument("--upto", default="", help="compare only stages up to this one (Z1..Z8)")
    a = ap.parse_args()
    old, new = Path(a.old), Path(a.new)
    res = {"old": str(old), "new": str(new), "files": {}}
    L = ["# Replay: existing rows vs the same jobs on the other emulator build\n",
         "| file | jobs in the existing run | replayed | same job on both | **rows differing** | only in existing | only in replay | error rows (existing / replay) |",
         "|---|---|---|---|---|---|---|---|"]
    tot_both = tot_diff = 0
    names = sorted({p.name for p in old.glob("Z*.jsonl")} | {p.name for p in new.glob("Z*.jsonl")})
    if a.upto:
        names = [n for n in names if n[1].isdigit() and int(n[1]) <= int(a.upto[1])]
    for n in names:
        ro, eo = rows(old / n)
        rn, en = rows(new / n)
        if ro is None or rn is None:
            L.append(f"| {n} | {'-' if ro is None else len(ro)} | {'-' if rn is None else len(rn)} | - | - | - | - | {eo} / {en} |")
            res["files"][n] = {"old": None if ro is None else len(ro), "new": None if rn is None else len(rn)}
            continue
        both = [k for k in ro if k in rn]
        diff = [k for k in both if ro[k] != rn[k]]
        ex = []
        for k in diff[:5]:
            p, x, y = first_diff(json.loads(ro[k]), json.loads(rn[k]))
            ex.append({"job": json.loads(k), "where": p, "existing": x, "replay": y})
        tot_both += len(both); tot_diff += len(diff)
        L.append(f"| {n} | {len(ro)} | {len(rn)} | {len(both)} | **{len(diff)}** | {len(ro) - len(both)} | "
                 f"{len(rn) - len(both)} | {eo} / {en} |")
        res["files"][n] = {"old": len(ro), "new": len(rn), "both": len(both), "differing": len(diff),
                           "only_old": len(ro) - len(both), "only_new": len(rn) - len(both),
                           "errors": [eo, en], "examples": ex}
    L.append("\nBy content (job labels depend on how a run was split into steps):\n")
    L.append("| what | existing | replay | on both | **differing** |")
    L.append("|---|---|---|---|---|")
    for n, label, flat in (("Z5_beach.jsonl", "Z5 beach walks (beach state, D, B)", flat_z5),
                           ("Z7_casts.jsonl", "Z7 casts (dog line, cast frame)", flat_z7)):
        if n not in names or not (old / n).exists() or not (new / n).exists():
            continue
        fo, fn = flat(old / n), flat(new / n)
        both = [k for k in fo if k in fn]
        diff = [k for k in both if fo[k] != fn[k]]
        tot_both += len(both); tot_diff += len(diff)
        L.append(f"| {label} | {len(fo)} | {len(fn)} | {len(both)} | **{len(diff)}** |")
        res["files"][n + ":content"] = {"old": len(fo), "new": len(fn), "both": len(both), "differing": len(diff),
                                        "examples": [{"job": list(k), "where": "", "existing": fo[k][:200],
                                                      "replay": fn[k][:200]} for k in diff[:5]]}
    z0o, z0n = old / "Z0_record.json", new / "Z0_record.json"
    if z0o.exists() and z0n.exists():
        x, y = norm(json.loads(z0o.read_text())), norm(json.loads(z0n.read_text()))
        for d in (x, y):
            for k in ("code", "save", "test_dog_poke"):
                d.pop(k, None)
        same = x == y
        res["Z0_record"] = {"same": same, "first": None if same else list(map(str, first_diff(x, y)))}
        L.append(f"\nZ0_record.json (reference route record, without code / save name): "
                 f"**{'same' if same else 'DIFFERENT ' + str(res['Z0_record']['first'])}**")
    res["jobs_on_both"], res["rows_differing"] = tot_both, tot_diff
    L.append(f"\n**{tot_both} jobs / walks / casts that both have; {tot_diff} differ.**"
             + ("" if tot_both else " Nothing comparable: no verdict."))
    for n, f in res["files"].items():
        for e in f.get("examples", []):
            L.append(f"\n- {n} job `{json.dumps(e['job'])[:160]}` at `{e['where']}`: existing `{str(e['existing'])[:80]}` "
                     f"vs replay `{str(e['replay'])[:80]}`")
    text = "\n".join(L) + "\n"
    if a.md:
        Path(a.md).write_text(text)
    if a.json:
        Path(a.json).write_text(json.dumps(res, indent=1))
    print(text)
    return 1 if tot_diff else 0


if __name__ == "__main__":
    sys.exit(main())
