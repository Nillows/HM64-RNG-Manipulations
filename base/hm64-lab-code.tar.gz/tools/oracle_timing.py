#!/usr/bin/env python3
"""
Stage E2 - how much Power Nut chance survives human timing error?

Stage E asks whether a press that wins for every remaining candidate exists.
This asks what a runner actually gets when their B press lands sigma VIs off
the tool's target (sigma = clock-alignment error and press jitter combined;
1 VI = 16.7 ms), which is what the tool's histogram is for.

Runner model (Thomas's keyboard logging): each dog change is logged after a
positive lag; the constant part is removed by the clock alignment, the random
part (reaction jitter) only widens the gap tolerance used for elimination.

Policy: wait until the remaining candidates all sit on ONE world line (their
casts agree exactly once lined up on the dog's changes), or until a press
exists that wins for all of them; then aim at the target that maximises the
candidate-weighted win chance blurred by N(0, sigma). The reported chance is
that blur applied to the TRUE arrival's winning frames.

Baselines: 1/51, and a blind press at a random moment 2-20 s after READY.

  python3 tools/oracle_timing.py results/campaign-oracle
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from tools.oracle_sim import build, fill_from_worldlines, worldlines, pct  # noqa: E402

SIGMAS = (0.0, 0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0)      # VIs
LEAD = 30                                             # VIs between plan known and press
REACTION_SD = 4.0                                     # VIs, keyboard logging jitter
SEARCH = 900                                          # look this far ahead for a target (VIs)


def kernel(sigma):
    if sigma <= 0:
        return {0: 1.0}
    r = int(math.ceil(4 * sigma)) + 1
    w = {d: math.exp(-0.5 * ((d - 0.0) / sigma) ** 2) for d in range(-r, r + 1)}
    s = sum(w.values())
    return {d: v / s for d, v in w.items()}


def blurred(win, center2, sigma):
    """P(win) when aiming at center2/2 (half-VI resolution) with N(0, sigma) error."""
    if sigma <= 0:
        if center2 % 2:
            return 0.0
        v = center2 // 2
        return 1.0 if 0 <= v < len(win) and win[v] else 0.0
    c = center2 / 2.0
    lo, hi = int(math.floor(c - 4 * sigma)) - 1, int(math.ceil(c + 4 * sigma)) + 1
    tot = num = 0.0
    for v in range(lo, hi + 1):
        w = math.exp(-0.5 * ((v - c) / sigma) ** 2)
        tot += w
        if 0 <= v < len(win) and win[v]:
            num += w
    return num / tot


def moments(scen, true_sig, g):
    """Yield (tau, k, alive) decision moments for the true arrival (same rules as stage E)."""
    S = scen[true_sig]
    ev = S["ev"]
    C = [s for s, x in scen.items() if x["ev"][0][1] == ev[0][1]]
    for k in range(1, len(ev)):
        tk, pose = ev[k]
        C = [c for c in C if len(scen[c]["ev"]) > k and scen[c]["ev"][k][1] == pose and
             (k < 2 or abs((tk - ev[k - 1][0]) - (scen[c]["ev"][k][0] - scen[c]["ev"][k - 1][0])) <= g)]
        t_next = ev[k + 1][0] if k + 1 < len(ev) else S["horizon"] + 1
        ms = {tk}
        for c in C:
            e2 = scen[c]["ev"]
            if len(e2) > k + 1:
                d = tk + (e2[k + 1][0] - e2[k][0]) + g + 1
                if d < t_next:
                    ms.add(d)
        for tau in sorted(ms):
            alive = [c for c in C if c == true_sig or len(scen[c]["ev"]) <= k + 1 or
                     tk + (scen[c]["ev"][k + 1][0] - scen[c]["ev"][k][0]) + g >= tau]
            yield tau, k, alive


def plan(scen, wl, true_sig, sigma, g):
    S = scen[true_sig]
    for tau, k, alive in moments(scen, true_sig, g):
        one_line = len({wl[c][0] for c in alive}) == 1
        tk = S["ev"][k][0]
        wsum = sum(scen[c]["w"] for c in alive)
        rel = [(scen[c]["w"], scen[c]["ev"][k][0], scen[c]["win_vi"]) for c in alive]
        if not one_line:                         # else: is there a frame that wins for all?
            ok = False
            for d in range(tau - tk + LEAD, tau - tk + LEAD + SEARCH):
                if all(t0 + d < len(wv) and wv[t0 + d] for _, t0, wv in rel):
                    ok = True
                    break
            if not ok:
                continue
        best = (-1.0, None)
        for d2 in range(2 * (tau - tk + LEAD), 2 * (tau - tk + LEAD + SEARCH)):
            est = sum(w * blurred(wv, 2 * t0 + d2, sigma) for w, t0, wv in rel) / wsum
            if est > best[0] + 1e-12:
                best = (est, d2)
        est, d2 = best
        if d2 is None:
            continue
        real = blurred(S["win_vi"], 2 * tk + d2, sigma)
        return {"decide_vi": tau, "press_vi": tk + d2 / 2.0, "est": est, "real": real, "cands": len(alive),
                "one_line": one_line}
    return None


def run(out: Path):
    out = Path(out)
    scen = build(out)
    wl, groups, agree, dis = worldlines(scen)
    if dis == 0:
        scen = fill_from_worldlines(scen, wl, groups)
    total = sum(s["w"] for s in scen.values())
    g = int(round(3 * math.sqrt(2) * REACTION_SD))
    # blind baseline: press at a uniformly random VI 2-20 s after READY
    blind = sum(s["w"] * sum(1 for v in range(120, 1200) if s["win_vi"][v]) / sum(
        1 for v in range(120, 1200) if s["win_vi"][v] is not None) for s in scen.values()) / total
    rows, table = [], []
    for sigma in SIGMAS:
        res = []
        for sig in scen:
            p = plan(scen, wl, sig, sigma, g)
            res.append((sig, p))
            rows.append({"signature": sig, "routes": scen[sig]["w"], "sigma_vi": sigma, **(p or {})})
        got = [(scen[s]["w"], p) for s, p in res if p]
        nut = sum(w * p["real"] for w, p in got) / total
        table.append({"sigma_vi": sigma, "sigma_ms": round(sigma * 1000 / 60, 1), "p_nut": round(nut, 3),
                      "x_blind": round(nut / blind, 1), "x_1_in_51": round(nut * 51, 1),
                      "press_s_median": round(pct([p["press_vi"] for _, p in got], 0.5) / 60, 2),
                      "press_s_p90": round(pct([p["press_vi"] for _, p in got], 0.9) / 60, 2),
                      "with_plan": f"{len(got)}/{len(res)}"})
    (out / "oracle_timing.json").write_text(json.dumps({"blind": blind, "gap_tol_vi": g, "lead_vi": LEAD,
                                                         "table": table, "rows": rows}, indent=1))
    L = ["## Timing error (stage E2)\n",
         f"Chance of the Nut when the B press lands N(0, sigma) VIs from the tool's target. Keyboard logging "
         f"jitter {REACTION_SD} VI -> gap tolerance {g} VI; plan known >= {LEAD} VI before the press; "
         f"world-line filling {'on' if dis == 0 else 'off'}. Baselines: 1/51 = 2.0%; a blind press 2-20 s after "
         f"READY wins {blind:.1%}.\n",
         "| timing error sigma | P(Nut) | x blind | x 1/51 | press time median / p90 (s) | arrivals with a plan |",
         "|---|---|---|---|---|---|"]
    for t in table:
        L.append(f"| {t['sigma_vi']} VI ({t['sigma_ms']} ms) | **{t['p_nut']:.0%}** | {t['x_blind']} | {t['x_1_in_51']} | "
                 f"{t['press_s_median']} / {t['press_s_p90']} | {t['with_plan']} |")
    text = "\n".join(L) + "\n"
    rep = out / "REPORT.md"
    if rep.exists():
        body = rep.read_text()
        cut = body.find("## Timing error (stage E2)")
        if cut >= 0:
            body = body[:cut].rstrip() + "\n\n"
        rep.write_text(body + text)
    print(text, flush=True)


if __name__ == "__main__":
    run(Path(sys.argv[1]))
