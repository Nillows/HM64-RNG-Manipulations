"""Re-render the web app from an existing *_data.json with new Lucky Timer route tables (no lab runs needed).
  python3 -I tools/webapp_rebuild.py OLD_data.json [--routes webapp/assets/lucky_routes.json] --out DIR"""
import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tools.export_webapp import render_html, VERSION  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("data")
ap.add_argument("--routes", default=str(ROOT / "webapp" / "assets" / "lucky_routes.json"))
ap.add_argument("--out", required=True)
a = ap.parse_args()
data = json.loads(Path(a.data).read_text())
data["lroutes"] = json.loads(Path(a.routes).read_text())["routes"]
dest, html = render_html(data, a.out)
print(f"{dest}: {VERSION}, routes {[r['id'] for r in data['lroutes']]}, {len(html) // 1024} KB")
