#!/usr/bin/env python3
"""
Preset zigzag: Thomas's frame-perfect-with-human-cuts route on the dog-beach save (no horse, dog asleep on the beach,
rod in hand), measured from power-on to the dock end, then Power Nut cast tables per dog line.

  HM64_SRAM=<dog-beach save> python3 tools/zigzag_campaign.py --preset zigzag-fast --out results/campaign-zigzag

Stages (all resumable; finished jobs are skipped on a re-run; the full preset reuses the fast preset's rows):
  Z0 check   the reference route from power-on must reproduce the sandbox numbers, else stop
  Z1 menus   mash START→A / START+A at every rate (period T VIs) and phase -> distinct house-entry states
  Z2 house   up-left / down-left / down cut grid (U, V) per house state -> distinct farm states
  Z3 cross   farm left held; crossroads cut grid C per farm state -> distinct ranch states
  Z4 ranch   down-right -> distinct beach states
  Z5 beach   per beach state: first cut D (dog wake + line key), second cut B -> READY spot / blocked
  Z6 lines   one natural path per dog line (representative = earliest READY after the wake); members checked
  Z7 casts   one cast per distinct position-free state (bite 1 released / held -> bite 2), heaviest lines first,
             0-20 s after READY before 20-40 s; 1% of shared states cast again from another line as a check
  report     ZIGZAG.md, zigzag_tables.json (lines, member weights by stage slack, cast tables), zigzag_casttable.csv
Slack bands (VIs late vs the fastest seen): only states within the preset's band go on to the next stage.

Dog-spot lab (presets dogspot-*, run_hm64_dogspots.sh; 2026-11-15): the same recipe on Thomas's dog-placement saves,
dog-neutral. Z0 records the save twice from power-on (date, weather, dog at every map load, the reference route; the two
cold boots must agree; the dog-beach save must reproduce the zigzag check). Failures are kept with where Jack stopped
(house / farm / crossroads / ranch / beach). Z5 walks every first and second cut (no dog-wake rule; zz_beach_neutral_job);
lines are anchored at the beach load and every member is matched to a natural path by its game state at READY
(check_members_neutral), then lines that are the same trajectory started later are merged (merge_same_paths).
Report adds: the save, the failure map, how the lines collapse, the web app's cut presets; dogspot_summary.json and
lucky_route.json (a Lucky Timer route entry) per save; tools/dogspots_report.py compares the saves.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import random
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "experiments"))

from m64h.pool import run_jobs                       # noqa: E402

ZZ_CODE = "zigzag-4f (2026-11-16: every bite to 90 s after READY; dogwatch menus 0-6 frames late; dog-watch traces (observe), house band house_lo, lineup-sparrow; 2026-11-15: lineup + first cut D 86; dog-spot lab - dog-neutral beach + lines, failure map; zigzag-3 pool/core/scan)"
DOGBEACH_SHA = "0d78b95b78e4a988570b3648d9bc16021df59a5faccdc00d06b01273975d8387"
from tools.common import default_rom, default_sram    # noqa: E402

PRESETS = {
    # tight windows: fast mashing, the fastest house/crossroads cuts + a few frames, the tightest beach cut + 12 polls
    "zigzag-fast": dict(styles=["START>A", "START+A"], periods=list(range(4, 13)), holds=["half"],
                        house_slack=8, Us=list(range(270, 284)), Vs=list(range(40, 66)), farm_slack=8,
                        Cs=list(range(69, 105)), ranch_slack=6, Ds=list(range(82, 95)), Bs=list(range(118, 150)),
                        cast_lo=6, cast_hi=2398, cast_step=2, cast_split=1200, verify=0.01, cast_cover=0.90),
    # wide windows: 4-15 presses/s with quick taps too, up to ~0.7 s late per screen, first beach cut up to ~0.9 s late
    "zigzag-full": dict(styles=["START>A", "START+A"], periods=list(range(4, 16)), holds=["half", "2"],
                        house_slack=40, Us=list(range(268, 304)), Vs=list(range(34, 96)), farm_slack=40,
                        Cs=list(range(66, 160)), ranch_slack=40, Ds=list(range(82, 137)), Bs=list(range(110, 158)),
                        cast_lo=6, cast_hi=2398, cast_step=2, cast_split=1200, verify=0.01, cast_cover=1.0),
    # the full preset's grids (every job is a full-preset job, so finished full work is reused and the full preset can
    # continue afterwards) with every screen limited to 9 game frames late (18 VIs) and the first beach cut to 9
    # frames after the first that clears the wall (D <= 102): Thomas's "medium" band (5-9 frames) plus the fast one
    "zigzag-mid": dict(styles=["START>A", "START+A"], periods=list(range(4, 16)), holds=["half", "2"],
                       house_slack=18, Us=list(range(268, 304)), Vs=list(range(34, 96)), farm_slack=18,
                       Cs=list(range(66, 160)), ranch_slack=18, Ds=list(range(82, 103)), Bs=list(range(110, 158)),
                       D_max=102, cast_lo=6, cast_hi=2398, cast_step=2, cast_split=1200, verify=0.01, cast_cover=0.95),
    # sandbox test of the zigzag-2 sparrow cleanup: mornings with the far pair, none and the door pair (10/s, VI 1036-1046)
    "zigzag-sparrowtest": dict(styles=["START>A"], periods=[6], holds=["half"], house_slack=10, Us=list(range(274, 280)),
                               Vs=list(range(46, 57)), farm_slack=8, Cs=[80, 90], ranch_slack=10, Ds=[86], Bs=[128, 132],
                               cast_lo=60, cast_hi=60, cast_step=60, cast_split=60, verify=0.0),
    # dog-spot lab (2026-11-15): Thomas's dog-placement saves through the zigzag-fast recipe of route delays (menus
    # mashed 4-12 per s, every screen up to 8 / 8 / 6 VIs after the fastest, first cut D 82-94), second cut B widened to
    # 112-151: with no dog under the pier the window opens 8 VIs earlier (D >= 86: B 117/118-139 instead of 126-139),
    # dog-neutral: no dog-wake rule or key, every (D, B) decided, lines matched by game state, failures kept and located
    "dogspot-fast": dict(styles=["START>A", "START+A"], periods=list(range(4, 13)), holds=["half"],
                         house_slack=8, Us=list(range(270, 284)), Vs=list(range(40, 66)), farm_slack=8,
                         Cs=list(range(69, 105)), ranch_slack=6, Ds=list(range(82, 95)), Bs=list(range(112, 152)),
                         cast_lo=6, cast_hi=2398, cast_step=2, cast_split=1200, verify=0.01, cast_cover=0.90,
                         neutral=True, blocked_still=60, member_cap_line=40, member_cap=300),
    # lineup lab (2026-11-15, Thomas): first cut fixed at the tightest (D 84: hug the small wall), Jack waits W = 0-30
    # VIs (half a second) longer at the beach load before his first step (a loose first turn corrected by turning up),
    # W in whole game frames (even VIs): the stick is read once per game frame, and with an odd W the D 84 cut lands one
    # frame early (Jack sticks on the small wall, measured); the tight turn after an odd wait = the next even wait,
    # every second cut over the full pier width; zigzag-fast pace before the beach; dog activation point + after-READY
    # dog draws recorded per route / line
    # 2026-11-15 night (zigzag-4b): + first cut D 86. D 84 scrapes the small wall's corner (Jack pushed to x -451.6);
    # D 86, one game frame later, clears it (x -452.0, still the wall column of the dog's view grid) and reaches the
    # dog's wake row 2 VIs sooner (VI 187 vs 189; experiments/transition_lateral_probe.py). D 84 / 86 = the two clean
    # first cuts (D <= 82 sticks on the small wall, D >= 88 runs a tile column out: the dog wakes 10 VIs early), weighted
    # 50/50. rep_prefer_D keeps the D 84 representatives of the first lineup run, so a resumed run reuses its lines and
    # casts and only walks / casts what D 86 adds.
    "lineup-fast": dict(styles=["START>A", "START+A"], periods=list(range(4, 13)), holds=["half"],
                        house_slack=8, Us=list(range(270, 284)), Vs=list(range(40, 66)), farm_slack=8,
                        Cs=list(range(69, 105)), ranch_slack=6, Ds=[84, 86], rep_prefer_D=[84], Ws=list(range(0, 31, 2)),
                        Bs=list(range(112, 152)), cast_lo=6, cast_hi=2398, cast_step=2, cast_split=1200, verify=0.01,
                        cast_cover=0.90, neutral=True, blocked_still=60, member_cap_line=20, member_cap=300),
    # 2026-11-16 (zigzag-4c): the same lineup lab on the mornings 5-9 game frames late (house arrival 10-18 VIs after the
    # fastest: VI 1046-1054 on the dog-beach save; door sparrow pair at 1046 / 1048, far pair 1050, none 1052 / 1054;
    # 27.6% of the menu mass of the lineup-fast grid). house_lo = the band's early edge (VIs after the fastest house);
    # house_ref = the fastest house arrival on this save (VI 1036, measured), so the band does not slide with the grid.
    "lineup-sparrow": dict(styles=["START>A", "START+A"], periods=list(range(4, 13)), holds=["half"],
                           house_ref=1036, house_lo=10, house_slack=18, Us=list(range(270, 284)), Vs=list(range(40, 66)), farm_slack=8,
                           Cs=list(range(69, 105)), ranch_slack=6, Ds=[84, 86], rep_prefer_D=[84], Ws=list(range(0, 31, 2)),
                           Bs=list(range(112, 152)), cast_lo=6, cast_hi=2398, cast_step=2, cast_split=1200, verify=0.01,
                           cast_cover=0.90, neutral=True, blocked_still=60, member_cap_line=20, member_cap=300),
    # 2026-11-16 (zigzag-4d, v30 groundwork): dog-watch. The lineup lab on a save with the dog on screen (beach-lineup2:
    # dog at x -198.5, z 223.5, full 22-VI pier window), mornings 0-9 game frames late (fast band + sparrow mornings:
    # house 0-18 VIs after the fastest, VI 1036), and every dog line's natural path recorded for the runner's eyes:
    # visible runs (animation + facing), the displayed animation, dogInfo decisions, dog draws, position and the
    # visibility grid, 40 s after READY (zigzag_jobs.obs_pack). tools/dogwatch_report.py -> DOGWATCH.md.
    # 2026-11-16 14:16 (Thomas): menus 0-6 game frames late only (house VI 1036-1048). The farm sparrows are a start-of-
    # day roll fixed by the menu timing alone; in this band the door pair shows exactly at 5 and 6 frames late (1046 /
    # 1048; far pair, off screen: 1036 / 1042; none: 1038 / 1040 / 1044), so "sparrows at the door" decides the table.
    # Slower menus are out ("too slow is too slow"). Narrowed mid-run: rows already made for 1050-1054 are ignored.
    "dogwatch": dict(styles=["START>A", "START+A"], periods=list(range(4, 13)), holds=["half"],
                     house_ref=1036, house_lo=0, house_slack=12, Us=list(range(270, 284)), Vs=list(range(40, 66)), farm_slack=8,
                     Cs=list(range(69, 105)), ranch_slack=6, Ds=[84, 86], rep_prefer_D=[84], Ws=list(range(0, 31, 2)),
                     Bs=list(range(112, 152)), cast_lo=6, cast_hi=2398, cast_step=2, cast_split=1200, verify=0.01,
                     cast_cover=0.90, neutral=True, blocked_still=60, member_cap_line=20, member_cap=300,
                     observe=True, observe_hi=2398, bites_max=16, bite_until=5398),
    "dogwatch-test": dict(styles=["START>A"], periods=[6, 10], holds=["half"], house_ref=1036, house_lo=0, house_slack=18,
                          Us=[276], Vs=[52], farm_slack=8, Cs=[80], ranch_slack=10, Ds=[84, 86], rep_prefer_D=[84],
                          Ws=list(range(0, 31, 6)), Bs=list(range(112, 152)), cast_lo=6, cast_hi=606, cast_step=40,
                          cast_split=306, verify=0.02, neutral=True, blocked_still=60, member_cap_line=5, member_cap=20,
                          observe=True, observe_hi=1500),
    "lineup-sparrow-test": dict(styles=["START>A", "START+A"], periods=[10, 12], holds=["half"], house_ref=1036, house_lo=10,
                                house_slack=18, Us=[276], Vs=[52], farm_slack=8, Cs=[80], ranch_slack=10, Ds=[84, 86],
                                rep_prefer_D=[84], Ws=[0, 10, 20], Bs=list(range(112, 152)), cast_lo=6, cast_hi=606,
                                cast_step=40, cast_split=306, verify=0.02, neutral=True, blocked_still=60,
                                member_cap_line=5, member_cap=20),
    "lineup-test": dict(styles=["START>A"], periods=[6], holds=["half"], house_slack=10, Us=[276], Vs=[52],
                        farm_slack=8, Cs=[80], ranch_slack=10, Ds=[84, 86], rep_prefer_D=[84], Ws=list(range(0, 31, 2)),
                        Bs=list(range(112, 152)), cast_lo=6, cast_hi=606, cast_step=40, cast_split=306, verify=0.02,
                        neutral=True, blocked_still=60, member_cap_line=5, member_cap=20),
    # sandbox test of the dog-spot lab
    "dogspot-test": dict(styles=["START>A"], periods=[6], holds=["half"], house_slack=10, Us=list(range(274, 280)),
                         Vs=list(range(46, 57)), farm_slack=8, Cs=[80, 90], ranch_slack=10, Ds=[84, 85, 86, 87],
                         Bs=list(range(112, 152)), cast_lo=6, cast_hi=606, cast_step=40, cast_split=306, verify=0.02,
                         neutral=True, blocked_still=60, member_cap_line=10, member_cap=40),
    # sandbox test: a handful of each
    "zigzag-test": dict(styles=["START>A"], periods=[6], holds=["half"], house_slack=2, Us=[276, 277], Vs=[52, 53],
                        farm_slack=2, Cs=[80, 81], ranch_slack=2, Ds=[86, 87], Bs=[132, 133, 134, 135],
                        cast_lo=6, cast_hi=600, cast_step=60, cast_split=300, verify=0.2),
}


def house_ok(v, h0, cfg):
    """the house-arrival band of a preset: house_lo..house_slack VIs after the fastest house arrival"""
    return cfg.get("house_lo", 0) <= v - h0 <= cfg["house_slack"]


def load_jsonl(p):
    out = []
    if p.exists():
        for line in p.read_text().splitlines():
            if line.strip():
                try:
                    out.append(json.loads(line))
                except ValueError:
                    pass
    return out


def run_stage(name, fn, jobs, out_path, workers, fresh, rom, sram, key):
    done = {key(r["_job"]) for r in load_jsonl(out_path) if "_error" not in r and "error" not in r}
    todo = [j for j in jobs if key(j) not in done]
    print(f"[{name}] {len(jobs)} jobs, {len(done)} already done, {len(todo)} to run", flush=True)
    if not todo:
        return
    t0 = time.time()
    n = 0
    with out_path.open("a") as f:
        for res in run_jobs(fn, todo, rom=rom, sram=sram, workers=workers, fresh=fresh):
            if "_error" in res:
                print(f"[{name}] job error: {res['_error'][-400:]}", flush=True)
            f.write(json.dumps(res) + "\n")
            f.flush()
            n += 1
            if n % 10 == 0 or n == len(todo):
                el = time.time() - t0
                print(f"[{name}] {n}/{len(todo)}  {n / el:.2f} jobs/s  eta {el / n * (len(todo) - n) / 60:.1f} min",
                      flush=True)


def ok_rows(p):
    return [r for r in load_jsonl(p) if "_error" not in r and "error" not in r]


def mine(rows, cfg, **grids):
    """rows whose job used exactly this preset's grids (the full preset re-runs stages with wider grids in the same
    folder; rows of the other preset must not be counted twice)."""
    out = []
    for r in rows:
        j = r.get("_job", {})
        if all(tuple(j.get(k, ())) == tuple(cfg[v]) for k, v in grids.items()):
            out.append(r)
    return out


def menu_rows(out, cfg):
    ok = {(s_, T, hold_of(h, T)) for s_ in cfg["styles"] for T in cfg["periods"] for h in cfg["holds"]}
    return [r for r in ok_rows(out / "Z1_menus.jsonl") if (r["style"], r["T"], r["h"]) in ok]


def hold_of(h, T):
    return max(1, T // 2) if h == "half" else int(h)


def norm(d):
    s = sum(d.values())
    return {k: v / s for k, v in d.items()} if s else {}


# ------------------------------------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--preset", choices=sorted(PRESETS), default="zigzag-fast")
    ap.add_argument("--out", default="results/campaign-zigzag")
    ap.add_argument("--workers", type=int, default=max(1, (os.cpu_count() or 2) - 1))
    ap.add_argument("--stop-after", default=os.environ.get("HM64_ZZ_STOP_AFTER", ""),
                    help="stop after this stage (Z1..Z7)")
    ap.add_argument("--cast-max-lines", type=int, default=int(os.environ.get("HM64_ZZ_MAX_LINES", "0") or 0))
    args = ap.parse_args()
    cfg = dict(PRESETS[args.preset])
    if os.environ.get("HM64_ZZ_DS"):                      # test knob: override the first-cut grid (e.g. "84")
        cfg["Ds"] = [int(v) for v in os.environ["HM64_ZZ_DS"].split(",")]
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    rom, sram = default_rom(), default_sram()
    print(f"{ZZ_CODE}  preset {args.preset}  save {sram}  workers {args.workers}", flush=True)
    import zigzag_jobs as ZJ
    t_start = time.time()
    W = args.workers

    def stop(stage):
        if args.stop_after and args.stop_after.upper() == stage:
            print(f"stopping after {stage} (--stop-after)", flush=True)
            report(out, cfg, args)
            sys.exit(0)

    choose_cpu(out, rom, sram)

    if cfg.get("neutral"):
        record_save(out, cfg, args, rom, sram, W)
    # Z0 check
    chk = out / "Z0_check.json"
    if cfg.get("neutral"):
        pass
    elif not chk.exists():
        res = list(run_jobs(ZJ.zz_check_job, [{"check": 1}], rom=rom, sram=sram, workers=1, fresh=True))[0]
        chk.write_text(json.dumps(res, indent=1))
    if not cfg.get("neutral"):
        res = json.loads(chk.read_text())
        print(f"[Z0] check: {'OK' if res.get('ok') else 'MISMATCH'}  got {res.get('got')}", flush=True)
        if not res.get("ok"):
            print("STOP: the reference route does not reproduce the sandbox numbers - send the zip as is.", flush=True)
            report(out, cfg, args)
            sys.exit(2)

    # Z1 menus
    jobs = [{"style": s, "T": T, "h": hold_of(h, T)} for s in cfg["styles"] for T in cfg["periods"] for h in cfg["holds"]]
    jobs = list({(j["style"], j["T"], j["h"]): j for j in jobs}.values())
    run_stage("Z1 menus", ZJ.zz_menu_job, jobs, out / "Z1_menus.jsonl", W, True, rom, sram,
              key=lambda j: (j["style"], j["T"], j["h"]))
    hstates = {}
    for r in menu_rows(out, cfg):
        for row in r["rows"]:
            if row.get("house"):
                hstates[row["house"]] = row["house_vi"]
    if not hstates:
        print("STOP: no house states", flush=True)
        sys.exit(2)
    h0 = cfg.get("house_ref") or min(hstates.values())
    hkeep = sorted(h for h, v in hstates.items() if house_ok(v, h0, cfg))
    print(f"[Z1] {len(hstates)} distinct house arrivals (VI {h0}..{max(hstates.values())}); "
          f"{len(hkeep)} within {cfg.get('house_lo', 0)}-{cfg['house_slack']} VIs of the fastest "
          f"(VI {sorted(hstates[h] for h in hkeep)})", flush=True)
    stop("Z1")

    # Z2 house (first: the one-time cleanup of farm states stored with the zigzag-1 fingerprint)
    sparrow_fix(out, rom, sram, W)
    jobs = [{"h": h, "Us": cfg["Us"], "Vs": cfg["Vs"]} for h in hkeep]
    run_stage("Z2 house", ZJ.zz_house_job, jobs, out / "Z2_house.jsonl", W, False, rom, sram,
              key=lambda j: (j["h"], tuple(j["Us"]), tuple(j["Vs"])))
    fstates = {}
    farm_min = None
    z2rows = mine(ok_rows(out / "Z2_house.jsonl"), cfg, Us="Us", Vs="Vs")
    for r in z2rows:
        if r["h"] not in hkeep:
            continue
        for U, V, rel, key, draw in r["rows"]:
            if rel is not None:
                farm_min = rel if farm_min is None else min(farm_min, rel)
    for r in z2rows:
        if r["h"] not in hkeep:
            continue
        for U, V, rel, key, draw in r["rows"]:
            if rel is not None and rel - farm_min <= cfg["farm_slack"]:
                fstates[key] = rel
    print(f"[Z2] fastest farm arrival {farm_min} VIs after the house load; {len(fstates)} farm states within "
          f"{cfg['farm_slack']}", flush=True)
    stop("Z2")

    # Z3 crossroads
    jobs = [{"f": f, "Cs": cfg["Cs"]} for f in sorted(fstates)]
    run_stage("Z3 cross", ZJ.zz_cross_job, jobs, out / "Z3_cross.jsonl", W, False, rom, sram,
              key=lambda j: (j["f"], tuple(j["Cs"])))
    rstates = {}
    ranch_min = None
    z3 = [r for r in mine(ok_rows(out / "Z3_cross.jsonl"), cfg, Cs="Cs") if r["f"] in fstates]
    for r in z3:
        for C, rel, key, draw in r["rows"]:
            if rel is not None:
                ranch_min = rel if ranch_min is None else min(ranch_min, rel)
    for r in z3:
        for C, rel, key, draw in r["rows"]:
            if rel is not None and rel - ranch_min <= cfg["ranch_slack"]:
                rstates[key] = rel
    print(f"[Z3] fastest ranch arrival {ranch_min} VIs after the farm load; {len(rstates)} ranch states", flush=True)
    stop("Z3")

    # Z4 ranch
    jobs = [{"r": r} for r in sorted(rstates)]
    run_stage("Z4 ranch", ZJ.zz_ranch_job, jobs, out / "Z4_ranch.jsonl", W, False, rom, sram, key=lambda j: j["r"])
    bstates = sorted({r["b"] for r in ok_rows(out / "Z4_ranch.jsonl") if r.get("b") and r["r"] in rstates})
    print(f"[Z4] {len(bstates)} distinct beach states", flush=True)
    if cfg.get("Ws"):
        bstates = [f"{b}@w{w}" for b in bstates for w in cfg["Ws"]]
        print(f"[Z4] x {len(cfg['Ws'])} beach waits (W {cfg['Ws'][0]}-{cfg['Ws'][-1]} VIs before the first step) = "
              f"{len(bstates)} beach starts", flush=True)
    stop("Z4")

    # Z5 beach (zigzag-3: rows are shared per (beach state, D) whatever grid produced them; scan job)
    wantD = [d for d in cfg["Ds"] if d <= cfg.get("D_max", 10 ** 6)]
    have = beach_rows(out, cfg["Bs"])
    jobs = []
    for b in bstates:
        miss = [d for d in wantD if d not in have.get(b, {}).get("covered", set())]
        if miss:
            jobs.append({"b": b, "Ds": miss, "Bs": [min(cfg["Bs"]), max(cfg["Bs"])]})
    print(f"[Z5] {len(bstates)} beach states, {len(bstates) - len(jobs)} already decided for D {wantD[0]}-{wantD[-1]}",
          flush=True)
    if cfg.get("neutral"):
        for j in jobs:
            j["blocked_still"] = cfg.get("blocked_still", 60)
    run_stage("Z5 beach", ZJ.zz_beach_neutral_job if cfg.get("neutral") else ZJ.zz_beach_scan_job, jobs,
              out / "Z5_beach.jsonl", W, False, rom, sram, key=lambda j: (j["b"], tuple(j["Ds"]), tuple(j["Bs"])))
    scans = [r.get("scan", {}) for r in ok_rows(out / "Z5_beach.jsonl") if "scan" in r]
    if scans:
        print(f"[Z5] scan jobs: {len(scans)}, walks {sum(x.get('walks', 0) for x in scans)}, "
              f"fell back to the full grid: {sum(1 for x in scans if x.get('fallback'))}", flush=True)
    weights = route_weights(out, cfg)
    lines = (line_members_neutral if cfg.get("neutral") else line_members)(out, cfg, weights)
    print(f"[Z5] {len(lines)} dog lines (line keys) from {sum(len(v['members']) for v in lines.values())} "
          f"(beach state, D, B) members", flush=True)
    stop("Z5")

    # Z6 lines (+ split members whose state at READY does not match their line's representative)
    for rnd in range(16 if cfg.get("neutral") else 4):
        jobs = []
        for key, L in lines.items():
            rep = L["rep"]
            jobs.append({"key": key, "b": rep["b"], "D": rep["D"], "B": rep["B"], "key_off": L["key_off"],
                         "until": max(cfg["cast_hi"], cfg.get("observe_hi", 0)), "step": 2,
                         **({"observe": True} if cfg.get("observe") else {})})
        run_stage(f"Z6 lines r{rnd}", ZJ.zz_line_job, jobs, out / "Z6_lines.jsonl", W, False, rom, sram,
                  key=lambda j: (j["key"], j["b"], j["D"], j["B"]))
        nat = {r["key"]: r for r in ok_rows(out / "Z6_lines.jsonl") if r.get("ok")}
        if cfg.get("neutral"):
            lines, moved, pending = check_members_neutral(lines, nat, cfg.get("rep_prefer_D"))
            print(f"[Z6] round {rnd}: {len(lines)} lines ({pending} new, their paths run next round); {moved} members "
                  f"on another line's path or not matched yet", flush=True)
            if not pending:
                break
            continue
        lines, moved = check_members(lines, nat)
        print(f"[Z6] round {rnd}: {len(lines)} lines, {moved} members moved to their own line", flush=True)
        if not moved:
            break
    json.dump(lines, open(out / "zz_lines.json", "w"))
    stop("Z6")

    # Z7 casts
    nat = {r["key"]: r for r in ok_rows(out / "Z6_lines.jsonl") if r.get("ok")}
    order = sorted((k for k in lines if k in nat), key=lambda k: -lines[k]["w"])
    tot = sum(lines[k]["w"] for k in order) or 1.0
    cover, acc, cut = cfg.get("cast_cover", 1.0), 0.0, len(order)
    for i, k in enumerate(order):                          # heaviest lines up to the preset's weight cover
        acc += lines[k]["w"] / tot
        if acc >= cover - 1e-9:
            cut = i + 1
            break
    order = order[:cut]
    if args.cast_max_lines:
        order = order[:args.cast_max_lines]
    print(f"[Z7] casting {len(order)} of {len(lines)} dog lines "
          f"({sum(lines[k]['w'] for k in order) / tot:.1%} of the route weight)", flush=True)
    done_hash = set()
    for r in ok_rows(out / "Z7_casts.jsonl"):
        for c in r.get("casts", []):
            if c.get("hash_ok") is not False and c["status"] == "ok":
                done_hash.add(c["hash"])
    rnd = random.Random(7)
    # 2026-11-16 (Thomas): every bite in the forecast time, not just two. Bites 1 and 2 as before (no time limit), then
    # every later bite that shows by bite_until VIs after READY (dogwatch: 90 s; HM64_ZZ_BITE_UNTIL=<seconds> overrides)
    bite_cfg = {}
    if cfg.get("bites_max", 2) > 2 or os.environ.get("HM64_ZZ_BITE_UNTIL"):
        bu = int(float(os.environ["HM64_ZZ_BITE_UNTIL"]) * 60) - 2 if os.environ.get("HM64_ZZ_BITE_UNTIL") else cfg["bite_until"]
        bite_cfg = {"bites_max": max(3, cfg.get("bites_max", 16)), "bite_until": bu}
        print(f"[Z7] every bite up to {(bu + 2) / 60:.0f} s after READY (bites 1-2 always)", flush=True)
    for phase, (lo, hi) in enumerate(((cfg["cast_lo"], cfg["cast_split"]), (cfg["cast_split"] + 1, cfg["cast_hi"]))):
        jobs, seen = [], set(done_hash)
        verify = []
        for key in order:
            hs = dict(nat[key]["hashes"])
            want = [(k, hs[k]) for k in range(lo + (lo % 2), hi + 1, cfg["cast_step"]) if k in hs]
            todo = []
            for k, h in want:
                if h in seen:
                    if rnd.random() < cfg["verify"]:
                        verify.append((key, k, h))
                    continue
                seen.add(h)
                todo.append((k, h))
            rep = lines[key]["rep"]
            for i in range(0, len(todo), 24):
                chunk = todo[i:i + 24]
                jobs.append({"key": key, "b": rep["b"], "D": rep["D"], "B": rep["B"], "casts": chunk,
                             "tag": f"p{phase}:{key}:{chunk[0][0]}", **bite_cfg})
        for key, k, h in verify:                          # shared state: cast it again from this line's own route
            rep = lines[key]["rep"]
            jobs.append({"key": key, "b": rep["b"], "D": rep["D"], "B": rep["B"], "casts": [(k, h)],
                         "tag": f"v{phase}:{key}:{k}"})
        run_stage(f"Z7 casts {'0-20 s' if phase == 0 else '20-40 s'}", ZJ.zz_cast_job, jobs,
                  out / "Z7_casts.jsonl", W, False, rom, sram, key=lambda j: j["tag"])
        # Z8: members that are not their line's representative cast from their own route (shared-cast check)
        vj = []
        for key in order:
            ms = [m for m in lines[key]["members"] if "k_off" in m and (m["k_off"] > 0 or m is not lines[key]["rep"])]
            ms = [m for m in ms if (m["b"], m["D"], m["B"]) != (lines[key]["rep"]["b"], lines[key]["rep"]["D"],
                                                               lines[key]["rep"]["B"])]
            if not ms:
                continue
            pick = [m for m in ms if rnd.random() < max(cfg["verify"] * 2, 0.02)] or ([ms[0]] if len(vj) < 8 else [])
            if cfg.get("member_cap_line") and len(pick) > cfg["member_cap_line"]:   # dog-spot saves: huge lines
                pick = rnd.sample(pick, cfg["member_cap_line"])
            grid = list(range(lo + (lo % 2), hi + 1, cfg["cast_step"]))
            for m in pick:
                ko = m.get("k_off", 0)
                taus = sorted({k - ko for k in rnd.sample(grid, min(3, len(grid))) if k - ko >= cfg["cast_lo"]})
                if taus:
                    vj.append({"line": key, "b": m["b"], "D": m["D"], "B": m["B"], "taus": taus,
                               "k_off": m.get("k_off", 0), "tag": f"m{phase}:{key}:{m['b']}:{m['D']}:{m['B']}"})
        if cfg.get("member_cap") and len(vj) > cfg["member_cap"]:
            vj = rnd.sample(vj, cfg["member_cap"])
        run_stage(f"Z8 member checks {phase}", ZJ.zz_member_cast_job, vj, out / "Z8_members.jsonl", W, False,
                  rom, sram, key=lambda j: j["tag"])
        report(out, cfg, args)
    print(f"zigzag campaign done in {(time.time() - t_start) / 60:.1f} min -> {out}/ZIGZAG.md", flush=True)


# ------------------------------------------------------------------------------------------------ zigzag-2 cleanup
def sparrow_fix(out, rom, sram, W):
    """Once per work folder. zigzag-1 merged farm states (house -> farm +104) on a fingerprint without the farm
    sparrows; the door pair keeps drawing random numbers after that point, so mornings with and without sparrows could
    share a farm key and only one future was simulated. zigzag-2 fingerprints live sparrows (states without sparrows
    keep their keys). This scans every stored house and farm state (each must load on its own map, else it stops
    without changing anything), then:
      - deletes the stored farm states that hold live sparrows (they were stored under a sparrow-blind key);
      - drops the Z2 rows of sparrow mornings (slot-4 roll 1 or 2) and of mornings that reached such a key, so they run
        again: sparrow mornings get their own farm keys, the others store their own state for their key;
      - drops the Z3 rows run from such a state.
    Everything else (all later stages, casts) is kept and reused by key; route weights are rebuilt from the rows every
    run. Dropped rows are kept in *.before-sparrowfix.jsonl, deleted states in states/zigzag/f-before-sparrowfix/."""
    import zigzag_jobs as ZJ
    marker = out / "Z2_sparrowfix.json"
    if marker.exists():
        return json.loads(marker.read_text())
    z2p, z3p = out / "Z2_house.jsonl", out / "Z3_cross.jsonl"
    z2 = load_jsonl(z2p)
    if not z2:
        info = {"code": ZZ_CODE, "note": "no Z2 rows yet: nothing to fix"}
        marker.write_text(json.dumps(info, indent=1))
        return info
    houses = sorted({r["h"] for r in z2 if "h" in r})
    fdir = ZJ.STORE / "f"
    fkeys = sorted(p.name[:-3] for p in fdir.glob("*.st")) if fdir.exists() else []
    items = [["h", h] for h in houses] + [["f", k] for k in fkeys]
    print(f"[Z2 fix] scanning {len(houses)} house and {len(fkeys)} farm states for farm sparrows", flush=True)
    chunks = [{"items": items[i:i + 40], "i": i} for i in range(0, len(items), 40)]
    res = []
    for r in run_jobs(ZJ.zz_sparrow_scan_job, chunks, rom=rom, sram=sram, workers=W, fresh=False):
        if "_error" in r:
            print(f"STOP: the sparrow scan failed: {r['_error'][-400:]}", flush=True)
            sys.exit(3)
        res += r["items"]
    bad = [x for x in res if x[2] is False]
    if bad:
        print(f"STOP: {len(bad)} stored states did not load on their map (e.g. {bad[0][:2]}); nothing was changed - "
              f"send the zip.", flush=True)
        sys.exit(3)
    spar_h = {key for kind, key, ok, s4, n in res if kind == "h" and ok and s4 in (1, 2)}
    door_h = {key for kind, key, ok, s4, n in res if kind == "h" and ok and s4 == 1}
    spar_f = {key for kind, key, ok, s4, n in res if kind == "f" and ok and n}
    drop_h = set(spar_h)
    for r in z2:
        if any(row[3] in spar_f for row in r.get("rows", []) if row[3]):
            drop_h.add(r.get("h"))
    keep2 = [r for r in z2 if r.get("h") not in drop_h]
    gone2 = [r for r in z2 if r.get("h") in drop_h]
    z3 = load_jsonl(z3p)
    keep3 = [r for r in z3 if r.get("f") not in spar_f]
    gone3 = [r for r in z3 if r.get("f") in spar_f]
    with open(out / "Z2_house.before-sparrowfix.jsonl", "a") as fh:
        fh.write("".join(json.dumps(r) + "\n" for r in gone2))
    with open(out / "Z3_cross.before-sparrowfix.jsonl", "a") as fh:
        fh.write("".join(json.dumps(r) + "\n" for r in gone3))
    for name, rows in ((z2p, keep2), (z3p, keep3)):
        tmp = name.with_suffix(".jsonl.tmp")
        tmp.write_text("".join(json.dumps(r) + "\n" for r in rows))
        os.replace(tmp, name)
    bk = ZJ.STORE / "f-before-sparrowfix"
    bk.mkdir(parents=True, exist_ok=True)
    for k in spar_f:
        for suf in (".st", ".st.json"):
            src = fdir / f"{k}{suf}"
            if src.exists():
                os.replace(src, bk / f"{k}{suf}")
    info = {"code": ZZ_CODE, "houses": len(houses), "sparrow_mornings": len(spar_h), "door_pair_mornings": len(door_h),
            "farm_states": len(fkeys), "farm_states_with_sparrows": len(spar_f), "z2_jobs_redo": len(gone2),
            "z3_jobs_redo": len(gone3)}
    marker.write_text(json.dumps(info, indent=1))
    print(f"[Z2 fix] {info}", flush=True)
    return info


# ------------------------------------------------------------------------------------------------ zigzag-3 helpers
def beach_rows(out, Bs):
    """Z5 rows merged per beach state: {b: {"rows": {D: row}, "covered": set(D)}}, whatever job or grid produced them
    (old full-grid jobs, zigzag-fast's narrower grid, scan jobs: the same simulation). A row counts if its job searched
    the whole B range wanted here, or if its READY window lies strictly inside the B range its job searched (so the
    window is complete). A D the job decided without a row (cut after the dog woke, as in
    zz_beach_job) counts as covered. First counted row wins."""
    lo, hi = min(Bs), max(Bs)
    out_ = {}
    for r in ok_rows(out / "Z5_beach.jsonl"):
        j = r.get("_job", {})
        jb = [int(x) for x in (j.get("Bs") or [])]
        if not jb:
            continue
        jlo, jhi = min(jb), max(jb)
        whole = jlo <= lo and jhi >= hi
        e = out_.setdefault(r["b"], {"rows": {}, "covered": set()})
        with_row = set()
        for row in r.get("rows", []):
            with_row.add(row[0])
            ready = [x[0] for x in row[6] if x[1] is not None]
            if whole or (ready and min(ready) > jlo and max(ready) < jhi):
                e["rows"].setdefault(row[0], row)
                e["covered"].add(row[0])
        e["covered"] |= {int(d) for d in r.get("covered", j.get("Ds", []))} - with_row
    return out_


def choose_cpu(out, rom, sram):
    """Pick the emulator CPU core for this machine (saved in core.json; env M64H_CPU forces one). dynarec (a JIT) and
    the cached interpreter give bit-identical results (sandbox 2026-11-15: every beach row equal); under Rosetta
    (Docker on Apple silicon) the JIT is slow and its regenerated code exhausts Rosetta's VmTracker, so each core is
    timed here on the lab's load-heavy work and the faster one is used. Different results = STOP."""
    import zigzag_jobs as ZJ
    if os.environ.get("M64H_CPU"):
        print(f"[core] M64H_CPU={os.environ['M64H_CPU']} (set by you)", flush=True)
        return os.environ["M64H_CPU"]
    shared = Path(os.environ["HM64_CORE_FILE"]) if os.environ.get("HM64_CORE_FILE") else None
    if shared and shared.exists():                     # dog-spot runs: the first save's choice is used for the rest
        try:
            c = json.loads(shared.read_text())["chosen"]
            os.environ["M64H_CPU"] = c
            print(f"[core] using {c} (chosen on this machine earlier: {shared.name})", flush=True)
            return c
        except (ValueError, KeyError):
            pass
    res = {}
    for cpu in ("dynarec", "cached"):
        r = list(run_jobs(ZJ.zz_bench_job, [{"bench": cpu}], rom=rom, sram=sram, workers=1, fresh=True,
                          emu_kwargs={"cpu": cpu}))[0]
        if "_error" in r:
            print(f"[core] {cpu}: failed ({r['_error'][-200:]})", flush=True)
            continue
        res[cpu] = r
        print(f"[core] {cpu}: {r['t']:.1f} s for the benchmark", flush=True)
    if not res:
        print("STOP: neither CPU core ran the benchmark", flush=True)
        sys.exit(3)
    if len({r["h"] for r in res.values()}) > 1:
        print(f"STOP: the CPU cores disagree on the benchmark results ({ {k: v['h'] for k, v in res.items()} }) - "
              f"send the log", flush=True)
        sys.exit(3)
    best = min(res, key=lambda k: res[k]["t"])
    os.environ["M64H_CPU"] = best
    (out / "core.json").write_text(json.dumps({"chosen": best, "bench": res, "code": ZZ_CODE}, indent=1))
    if shared:
        shared.parent.mkdir(parents=True, exist_ok=True)
        shared.write_text(json.dumps({"chosen": best, "bench": res, "code": ZZ_CODE}, indent=1))
    print(f"[core] using {best} (results identical)", flush=True)
    return best


# ------------------------------------------------------------------------------------------------ weights
def route_weights(out, cfg):
    """Probability of each beach state, by stage: menus (per mash rate, phase uniform, styles/holds pooled),
    house cuts (U, V uniform over runs that reach the farm in the band), crossroads cuts (C uniform), ranch."""
    hstates_w = Counter()
    hvi = {}
    for r in menu_rows(out, cfg):
        for row in r["rows"]:
            if row.get("house"):
                hstates_w[(r["T"], row["house"])] += 1.0 / r["T"]
                hvi[row["house"]] = row["house_vi"]
    h0 = cfg.get("house_ref") or (min(hvi.values()) if hvi else 0)
    hkeep = {h for h, v in hvi.items() if house_ok(v, h0, cfg)}
    house_to_farm, farm_rel = defaultdict(Counter), {}
    z2 = [r for r in mine(ok_rows(out / "Z2_house.jsonl"), cfg, Us="Us", Vs="Vs") if r["h"] in hkeep]
    fmin = min((row[2] for r in z2 for row in r["rows"] if row[2] is not None), default=0)
    for r in z2:
        for U, V, rel, key, draw in r["rows"]:
            if rel is not None and rel - fmin <= cfg["farm_slack"]:
                house_to_farm[r["h"]][key] += 1
                farm_rel[key] = rel
    farm_to_ranch, ranch_rel = defaultdict(Counter), {}
    z3 = [r for r in mine(ok_rows(out / "Z3_cross.jsonl"), cfg, Cs="Cs") if r["f"] in farm_rel]
    rmin = min((row[1] for r in z3 for row in r["rows"] if row[1] is not None), default=0)
    for r in z3:
        for C, rel, key, draw in r["rows"]:
            if rel is not None and rel - rmin <= cfg["ranch_slack"]:
                farm_to_ranch[r["f"]][key] += 1
                ranch_rel[key] = rel
    ranch_to_beach = {r["r"]: r["b"] for r in ok_rows(out / "Z4_ranch.jsonl") if r.get("b")}
    # beach state weights per mash period T (and pooled), with the stage slack of the path
    beach_w = defaultdict(Counter)            # T -> beach -> weight
    slack = {}                                # beach -> min total slack seen (house + farm + ranch, VIs)
    for (T, h), wh in hstates_w.items():
        if h not in hkeep:
            continue
        for f, wf in norm(house_to_farm.get(h, {})).items():
            for rr, wr in norm(farm_to_ranch.get(f, {})).items():
                b = ranch_to_beach.get(rr)
                if b is None:
                    continue
                beach_w[T][b] += wh * wf * wr
                s = (hvi[h] - h0) + (farm_rel[f] - fmin) + (ranch_rel[rr] - rmin)
                slack[b] = min(slack.get(b, 10 ** 9), s)
    pooled = Counter()
    for T, d in beach_w.items():
        for b, w in norm(d).items():
            pooled[b] += w / len(beach_w)
    out_w = {"by_T": {T: norm(d) for T, d in beach_w.items()}, "pooled": dict(pooled), "slack": slack,
             "h0": h0, "fmin": fmin, "rmin": rmin}
    if cfg.get("Ws"):                                    # lineup lab: every beach state x every beach wait, W uniform
        Ws = cfg["Ws"]
        out_w["by_T"] = {T: {f"{b}@w{w}": v / len(Ws) for b, v in d.items() for w in Ws} for T, d in out_w["by_T"].items()}
        out_w["pooled"] = {f"{b}@w{w}": v / len(Ws) for b, v in pooled.items() for w in Ws}
        out_w["slack"] = {f"{b}@w{w}": v + w for b, v in slack.items() for w in Ws}
    return out_w


def line_members(out, cfg, weights):
    """Members (beach state, D, B) of each line key, with weights (beach weight x D uniform x B uniform over B
    that reach the dock end). Representative = earliest READY after the wake."""
    lines = {}
    wantD = {d for d in cfg["Ds"] if d <= cfg.get("D_max", 10 ** 6)}
    for b, e in beach_rows(out, cfg["Bs"]).items():
        wb = weights["pooled"].get(b, 0.0)
        if wb <= 0 or not wantD <= e["covered"]:
            continue
        rows = [e["rows"][d] for d in sorted(e["rows"]) if d in wantD]
        nD = len(rows)
        for D, wake_rel, wake_draw, key_off, key, late, brow in rows:
            good = [x for x in brow if x[1] is not None and x[0] in cfg["Bs"]]
            if not good or wake_rel is None:
                continue
            lid = hashlib.blake2b(f"{key_off}:{key}".encode(), digest_size=8).hexdigest()
            L = lines.setdefault(lid, {"key": key, "key_off": key_off, "late": late, "members": [], "w": 0.0})
            for B, ready_rel, x, z, rdraw, s_chk, chk in good:
                w = wb / nD / len(good)
                L["members"].append({"b": b, "D": D, "B": B, "wake_rel": wake_rel, "wake_draw": wake_draw,
                                     "ready_rel": ready_rel, "r": ready_rel - wake_rel, "spot": [x, z],
                                     "s_chk": s_chk, "chk": chk, "w": w, "slack": weights["slack"].get(b, 0)})
                L["w"] += w
    for L in lines.values():
        L["rep"] = min(L["members"], key=lambda m: (m["r"], -m["w"]))
    return lines


def check_members(lines, nat):
    """A member belongs to its line if its position-free state at its READY detection equals the representative's
    natural path at the same time since the wake. Others get a line of their own (key = that state + time)."""
    new = {}
    moved = 0
    for lid, L in lines.items():
        n = nat.get(lid)
        if n is None or n.get("D") != L["rep"]["D"] or n.get("b") != L["rep"]["b"] or n.get("B") != L["rep"]["B"]:
            new[lid] = L                                   # not run yet (or rep changed): keep as is
            continue
        hs = dict(n["lhashes"])
        base = n["ready_rel"] - n["wake_rel"]              # rep's READY in VIs after its wake
        keep = []
        for m in L["members"]:
            k = m["s_chk"] - base
            if hs.get(k) == m["chk"]:
                m["k_off"] = m["r"] - base                 # member READY = rep k_off (VIs after rep READY)
                keep.append(m)
            else:
                lid2 = hashlib.blake2b(f"chk:{m['s_chk']}:{m['chk']}".encode(), digest_size=8).hexdigest()
                L2 = new.setdefault(lid2, {"key": m["chk"], "key_off": m["s_chk"], "late": L["late"],
                                           "members": [], "w": 0.0, "split_from": lid})
                L2["members"].append(m)
                L2["w"] += m["w"]
                moved += 1
        L["members"] = keep
        L["w"] = sum(m["w"] for m in keep)
        if keep:
            new[lid] = L
    for L in new.values():
        if L["members"] and "rep" not in L:
            L["rep"] = min(L["members"], key=lambda m: (m["r"], -m["w"]))
    return new, moved


# ------------------------------------------------------------------------------------------------ dog-spot lab
def record_save(out, cfg, args, rom, sram, W):
    """Z0 for the dog-spot saves: the zigzag reference route recorded twice from power-on (fresh emulators). STOP if
    the two records differ (not repeatable); on the dog-beach save it must also reproduce the zigzag check numbers
    (lab health). A save whose reference route never reaches the dock end goes on (that is a result, not an error)."""
    import zigzag_jobs as ZJ
    z0 = out / "Z0_record.json"
    if not z0.exists():
        res = list(run_jobs(ZJ.zz_record_job, [{"run": 1}, {"run": 2}], rom=rom, sram=sram, workers=min(2, W),
                            fresh=True))
        bad = [r for r in res if "_error" in r]
        if bad:
            print(f"STOP: the record run failed: {bad[0]['_error'][-400:]}", flush=True)
            sys.exit(2)
        res.sort(key=lambda r: r["_job"]["run"])
        a, b = ({k: v for k, v in r.items() if k != "_job"} for r in res)
        sha = hashlib.sha256(Path(sram).read_bytes()).hexdigest() if sram else None
        import zigzag_jobs as ZJ2
        rec = {"code": ZZ_CODE, "save": Path(sram).name if sram else None, "save_sha256": sha, "deterministic": a == b,
               "record": a, "record2": None if a == b else b,
               "test_dog_poke": os.environ.get("HM64_ZZ_TEST_DOG") or None}
        if sha == DOGBEACH_SHA and not rec["test_dog_poke"]:
            rec["reference_check"] = a["got"] == ZJ2.REFERENCE["expect"]
        z0.write_text(json.dumps(rec, indent=1))
    rec = json.loads(z0.read_text())
    info = rec["record"]["info"]
    sv, st = info.get("save", {}), info.get("stages", {})
    d1 = st.get("1", {}).get("dog", {})
    print(f"[Z0] save {rec['save']}  sha256 {(rec['save_sha256'] or '')[:12]}  "
          f"{sv.get('season_name')} {sv.get('day')} year {sv.get('year')}  weather {sv.get('weather')}  "
          f"{sv.get('hour')}:{sv.get('minutes', 0):02d}  rod in hand: {sv.get('rod_in_hand')}", flush=True)
    print(f"[Z0] dog at the house load: {d1.get('map')} (map {d1.get('location')}) x {d1.get('x')} z {d1.get('z')} "
          f"dir {d1.get('direction')} flags {d1.get('flag_names')}", flush=True)
    seen = [f"{['', 'house', 'farm', 'crossroads', 'ranch', 'beach'][int(k)]}" for k, v in sorted(st.items())
            if v.get("dog_here")]
    print(f"[Z0] dog on screen at the load of: {', '.join(seen) or 'none of the route screens'}", flush=True)
    end = info.get("end", {})
    got = rec["record"]["got"]
    print(f"[Z0] reference route (mash 10/s, U276 V52 C80 D86 B134): {route_times(info)}; "
          + (f"READY {got['ready'][0]} VIs after the beach load at x {got['ready'][1]} z {got['ready'][2]}"
             if got.get("ready") and end.get("ready_at_dock_end") else
             f"no READY - {end.get('why')} on the {['', 'house', 'farm', 'crossroads', 'ranch', 'beach'][end.get('stage') or 0]}"
             f" at {end.get('pos')}"), flush=True)
    print(f"[Z0] repeatable (two cold boots equal): {'yes' if rec['deterministic'] else 'NO'}", flush=True)
    if not rec["deterministic"]:
        print("STOP: two cold boots of this save gave different records - send the zip.", flush=True)
        report(out, cfg, args)
        sys.exit(2)
    if rec.get("reference_check") is False:
        print("STOP: the dog-beach save does not reproduce the zigzag check numbers - send the zip.", flush=True)
        report(out, cfg, args)
        sys.exit(2)
    if rec.get("reference_check"):
        print("[Z0] dog-beach save: the zigzag check numbers are reproduced (lab health OK)", flush=True)
    return rec


def route_times(info):
    """'house VI 1036, farm +412, crossroads +586, ...' (map loads of the reference route, VIs after the one before)"""
    st = info.get("stages", {})
    names = {1: "house", 2: "farm", 3: "crossroads", 4: "ranch", 5: "beach"}
    out, prev = [], None
    for k in sorted(int(x) for x in st):
        v = st[str(k)]["vi"]
        out.append(f"{names.get(k, k)} VI {v}" if prev is None else f"{names.get(k, k)} +{v - prev}")
        prev = v
    return ", ".join(out)


def _lid(s):
    return hashlib.blake2b(s.encode(), digest_size=8).hexdigest()


def line_members_neutral(out, cfg, weights):
    """Dog-neutral lines (dog-spot lab): one candidate line per beach state, anchored at the beach load (no dog wake).
    Members = (beach state, D, B) that reach the dock end; weight = beach-state weight x D uniform over the D grid
    (D that never reach keep their share: lost weight) x B uniform over the B that reach. check_members_neutral then
    puts every member on the line whose natural path holds its game state at READY."""
    lines = {}
    wantD = {d for d in cfg["Ds"] if d <= cfg.get("D_max", 10 ** 6)}
    for b, e in beach_rows(out, cfg["Bs"]).items():
        wb = weights["pooled"].get(b, 0.0)
        if wb <= 0 or not wantD <= e["covered"]:
            continue
        rows = [e["rows"][d] for d in sorted(e["rows"]) if d in wantD]
        nD = len(rows)
        mem = []
        Wb = int(b.split("@w")[1]) if "@w" in b else 0
        for D, move, edraw, _ko, _key, _late, brow in rows:
            good = [x for x in brow if x[1] is not None and x[0] in cfg["Bs"]]
            for x in good:
                B, ready_rel, px, pz, rdraw, det, h0, pat = x[:8]
                mem.append({"b": b, "D": D, "B": B, "W": Wb, "wake_rel": 0, "wake_draw": edraw, "dog_move": move,
                            "ready_rel": ready_rel, "r": ready_rel, "spot": [px, pz], "ready_draw": rdraw,
                            "s_chk": det, "chk": h0, "pat": pat, "w": wb / nD / len(good),
                            "slack": weights["slack"].get(b, 0), "vis": x[9] if len(x) > 9 else None})
        if mem:
            lines[_lid(f"entry:{b}")] = {"key": b, "key_off": 0, "late": False, "anchor": "beach", "members": mem,
                                         "w": sum(m["w"] for m in mem)}
    pref = set(cfg.get("rep_prefer_D") or [])
    for L in lines.values():
        L["rep"] = min(L["members"], key=lambda m: (m["D"] not in pref if pref else False, m["r"], -m["w"], m["D"], m["B"]))
    return lines


def check_members_neutral(lines, nat, prefer_D=None):
    """Match every member of every line whose natural path has run to a path by its game state at READY: the dog-line
    hash at its READY detection and the next 2 VIs (the triple pins the game-frame phase) must appear on the path.
    Preference: its own line at the same time since the beach load (same beach state as the representative), then its
    own line, then another line (same beach state + same time, else the earliest place). k_off = the member's READY
    in VIs after that line's READY. Members found on no path get a new line per beach state (representative = the
    earliest), run in the next round. Returns (lines, members not on their own line's path, new lines)."""
    run, pending = {}, {}
    for lid, L in lines.items():
        n = nat.get(lid)
        rep = L["rep"]
        if n and (n.get("b"), n.get("D"), n.get("B")) == (rep["b"], rep["D"], rep["B"]):
            run[lid] = (L, n)
        else:
            pending[lid] = L
    tri = defaultdict(list)
    for lid in sorted(run):
        hk = dict(run[lid][1]["lhashes"])
        for k in sorted(hk):
            if k + 2 in hk:
                tri[(hk[k], hk[k + 1], hk[k + 2])].append((lid, k))
    new = {}
    for lid, (L, n) in run.items():
        new[lid] = {q: v for q, v in L.items() if q != "members"}
        new[lid]["members"] = []
    new.update(pending)
    moved, unmatched = 0, defaultdict(list)
    for lid in sorted(run):
        L, n = run[lid]
        for m in L["members"]:
            hits = tri.get(tuple(m["pat"] or ()), [])
            pick = None
            if m["b"] == L["rep"]["b"] and (lid, m["s_chk"] - n["ready_rel"]) in hits:
                pick = (lid, m["s_chk"] - n["ready_rel"])
            if pick is None:
                own = [h for h in hits if h[0] == lid]
                pick = own[0] if own else None
            if pick is None:
                for lid2, k in hits:
                    L2, n2 = run[lid2]
                    if m["b"] == L2["rep"]["b"] and k == m["s_chk"] - n2["ready_rel"]:
                        pick = (lid2, k)
                        break
            if pick is None and hits:
                pick = hits[0]
            if pick is None:
                unmatched[m["b"]].append(m)
                continue
            lid2, k = pick
            m["k_off"] = k - (m["s_chk"] - m["r"])
            m["line_k"] = k
            new[lid2]["members"].append(m)
            if lid2 != lid:
                moved += 1
    pref = set(prefer_D or [])
    for b, ms in unmatched.items():
        rep = min(ms, key=lambda m: (m["D"] not in pref if pref else False, m["r"], -m["w"], m["D"], m["B"]))
        lid = _lid(f"u:{b}:{rep['D']}:{rep['B']}")
        for m in ms:
            m.pop("k_off", None)
            m.pop("line_k", None)
        prev = new.get(lid)
        if prev is not None and prev is not pending.get(lid):
            new[lid]["members"].extend(ms)              # its path ran and still does not hold them: kept, unresolved
            new[lid]["unresolved"] = new[lid].get("unresolved", 0) + len(ms)
            continue
        new[lid] = {"key": f"{b}:{rep['D']}:{rep['B']}", "key_off": 0, "late": False, "anchor": "beach",
                    "members": ms, "rep": rep}
        moved += len(ms)
    outl = {lid: L for lid, L in new.items() if L["members"]}
    for L in outl.values():
        L["w"] = sum(m["w"] for m in L["members"])
    pend = sum(1 for lid in outl if lid not in run)
    if not pend:
        outl = merge_same_paths(outl, tri)
    return outl, moved, pend


MERGE_MAX_SHIFT = 120    # VIs: a line whose READY state lies on an earlier line's path joins it if it starts <= 2 s later


def merge_same_paths(lines, tri):
    """Final round: a line whose representative's READY state (3-VI triple) lies on another line's natural path is the
    same RNG trajectory started later (e.g. the same dog line reached from two beach states, one READY later than the
    other): its members join that line with k_off shifted, so a line = one trajectory. Only for shifts up to
    MERGE_MAX_SHIFT (the joined members lose that much table at the 40 s end)."""
    alive = set(lines)
    changed = True
    while changed:
        changed = False
        for lid in sorted(alive):
            L = lines[lid]
            lag = L["rep"]["s_chk"] - L["rep"]["r"]
            hits = sorted((k - lag, lid2) for lid2, k in tri.get(tuple(L["rep"].get("pat") or ()), [])
                          if lid2 != lid and lid2 in alive and 0 <= k - lag <= MERGE_MAX_SHIFT)
            if not hits:
                continue
            shift, lid2 = hits[0]
            for m in L["members"]:
                if "k_off" in m:
                    m["k_off"] += shift
                    m["line_k"] = m.get("line_k", 0) + shift
            T = lines[lid2]
            T["members"].extend(L["members"])
            T["w"] += L["w"]
            T.setdefault("merged", []).append([lid, shift])
            alive.discard(lid)
            changed = True
    return {lid: lines[lid] for lid in sorted(alive)}


# ------------------------------------------------------------------------------------------------ report
def report(out, cfg, args):
    try:
        from tools import zigzag_report
        zigzag_report.write(out, cfg, args.preset)
    except Exception as e:                       # the report must never kill a run
        import traceback
        print(f"report failed: {e}\n{traceback.format_exc()[-600:]}", flush=True)


if __name__ == "__main__":
    main()
