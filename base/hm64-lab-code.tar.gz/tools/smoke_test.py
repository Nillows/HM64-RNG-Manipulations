#!/usr/bin/env python3
"""
End-to-end health check for the lab. Run this first in any new container,
after any change to native/ or m64h/, and before trusting a new result.

  python3 tools/smoke_test.py            # ~3-5 min on a laptop
  python3 tools/smoke_test.py --quick    # skips the slower equivalence checks

Checks (each prints PASS/FAIL/SKIP):
  1 lcg          LCG step/index round-trips; QuickSave2 seed 0x705EE83C -> 1716
  2 save         SRAM detected, diary slots found
  3 boot         power-on -> diary -> anchors, twice; must be bit-identical
  4 roundtrip    savestate save/load reproduces a 900-VI trace exactly
  5 poke         seed poke at the LOAD anchor == genuinely later diary press
  6 dogmodel     hm64.dog reproduces every dog decision in a 3000-VI trace
  7 visual       headless and rendered (rice under Xvfb) traces identical
  8 qs2          QuickSave2(1) Nut regression 8/8 (if states/qs2.st exists)
  9 route        cold boot -> carry route -> dock READY reproduces the legacy
                 v13 baseline at all 9 stages (VI + RNG)
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
PY = sys.executable
SMOKE = ROOT / "states" / "smoke"
results = []


def report(name, ok, detail=""):
    tag = {True: "PASS", False: "FAIL", None: "SKIP"}[ok]
    results.append((name, tag))
    print(f"[{tag}] {name:10s} {detail}", flush=True)


def run(args, **kw):
    return subprocess.run(args, capture_output=True, text=True, cwd=ROOT, **kw)


def boot(delays, out, load_out):
    r = run([PY, "tools/boot.py", "--delays", delays, "--out", str(out), "--load-out", str(load_out)])
    if r.returncode:
        raise RuntimeError(r.stderr[-2000:])
    return json.loads(r.stdout.strip().splitlines()[-1])


def trace(state, vis, out, extra=(), xvfb=False):
    cmd = [PY, "tools/trace.py", "--state", str(state), "--vis", str(vis), "--out", str(out), *extra]
    if xvfb:
        cmd = ["xvfb-run", "-a", "-s", "-screen 0 1024x768x24"] + cmd
    r = run(cmd)
    if r.returncode:
        raise RuntimeError(r.stderr[-2000:])
    import csv
    with open(out) as f:
        return [tuple(v for k, v in row.items() if k not in ("vi", "polls")) for row in csv.DictReader(f)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    a = ap.parse_args()
    from tools.common import default_rom, default_sram
    rom, sram = default_rom(), default_sram()
    if not rom:
        print("No ROM found: put your .z64 in data/rom/ (or set HM64_ROM)."); sys.exit(2)
    SMOKE.mkdir(parents=True, exist_ok=True)
    tmp = Path(tempfile.mkdtemp(prefix="smoke-"))

    # 1 lcg
    from hm64.lcg import index, seed_at, step
    ok = all(index(seed_at(n)) == n for n in (0, 1, 1219, 25110, 10**7)) and index(0x705EE83C) == 1716
    report("lcg", ok, "index(0x705EE83C)=%d" % index(0x705EE83C))

    # 2 save
    if sram:
        from m64h.sram import detect, slots
        data = Path(sram).read_bytes()
        kind, _ = detect(data)
        report("save", True, f"{Path(sram).name}: {kind}, diary slots {slots(data)}")
    else:
        report("save", None, "no save in data/saves/ - boot tests will start a new game and likely fail")

    # 3 boot determinism
    try:
        i1 = boot("0,0,0,0", SMOKE / "anchor_d0.st", SMOKE / "load_d0.st")
        i2 = boot("0,0,0,0", tmp / "a.st", tmp / "l.st")
        same = all(i1[k] == i2[k] for k in ("load_vi", "load_idx", "anchor_vi", "idx"))
        report("boot", same, f"load anchor VI {i1['load_vi']} idx {i1['load_idx']}; control anchor VI "
                             f"{i1['anchor_vi']} idx {i1['idx']}" + ("" if same else f" vs {i2}"))
    except Exception as e:
        report("boot", False, str(e)[-500:])
        i1 = None

    if i1:
        # 4 roundtrip
        t1 = trace(SMOKE / "load_d0.st", 900, tmp / "t1.csv")
        t2 = trace(SMOKE / "load_d0.st", 900, tmp / "t2.csv")
        report("roundtrip", t1 == t2, f"{len(t1)} VIs")

        # 6 dog model
        trace(SMOKE / "load_d0.st", 3000, tmp / "dog.csv",
              extra=["--inputs", '[{"at":600,"press":["CR"]},{"at":1500,"press":["CR"]}]'])
        from tools.validate_dog_model import load, validate
        ex, un, _, wh = validate(load(tmp / "dog.csv"))
        report("dogmodel", len(ex) > 50 and not un, f"{len(ex)} decisions explained, {len(wh)} whistle resets, "
                                                    f"{len(un)} unexplained")

        if not a.quick:
            # 5 poke equivalence
            i3 = boot("0,0,0,4", SMOKE / "anchor_d4.st", SMOKE / "load_d4.st")
            nat = trace(SMOKE / "load_d4.st", 1800, tmp / "nat.csv")
            pok = trace(SMOKE / "load_d0.st", 1800, tmp / "pok.csv",
                        extra=["--poke-index", str(i3["load_idx"])])
            report("poke", nat == pok, f"diary+4 (idx {i3['load_idx']}) vs load_d0+poke over 1800 VIs")

            # 7 visual
            if shutil.which("xvfb-run"):
                try:
                    tv = trace(SMOKE / "load_d0.st", 600, tmp / "tv.csv", extra=["--mode", "visual"], xvfb=True)
                    tf = trace(SMOKE / "load_d0.st", 600, tmp / "tf.csv")
                    report("visual", tv == tf, "rice+Xvfb vs headless, 600 VIs")
                except Exception as e:
                    report("visual", False, str(e)[-400:])
            else:
                report("visual", None, "xvfb-run not installed")
        else:
            report("poke", None, "--quick"); report("visual", None, "--quick")

    # 8 qs2
    qs2 = ROOT / "states" / "qs2.st"
    if qs2.exists():
        r = run([PY, "tools/regress_qs2.py", "--state", str(qs2)])
        last = [l for l in r.stdout.splitlines() if "match the recorded" in l]
        report("qs2", r.returncode == 0 and bool(last) and last[-1].split(":")[1].strip().startswith("8/8"),
               last[-1] if last else r.stderr[-300:])
    else:
        report("qs2", None, "states/qs2.st missing (convert QuickSave2(1) with tools/convert_bizhawk_state.py)")

    # 9 route
    ready = SMOKE / "ready_v13.st"
    r = run([PY, "tools/route_run.py", "--check-v13", "--save", str(ready)])
    try:
        d = json.loads(r.stdout)
        ok = d.get("v13_check") == "MATCH"
        fr = d["stages"].get("fishing_ready") or {}
        report("route", ok, f"fishing_ready VI {fr.get('vi')} draw {fr.get('draw_index')}" +
               ("" if ok else f" diffs: {json.dumps(d.get('v13_check'))[:300]}"))
    except Exception:
        report("route", False, (r.stderr or r.stdout)[-400:])

    # 10 ladder: casts from a rung == casts from READY
    if ready.exists():
        r = run([PY, "tools/check_ladder.py", str(ready)])
        try:
            d = json.loads(r.stdout.strip().splitlines()[-1])
            report("ladder", d["ok"], "; ".join(f"cast {c['cast']} whistle {c['whistles']} from rung {c['rung']}: "
                                                 f"bite {c['bite'][0]} vs {c['bite'][1]}" for c in d["checks"]))
        except Exception:
            report("ladder", False, (r.stderr or r.stdout)[-400:])
    else:
        report("ladder", False, "route check did not save a READY state")

    shutil.rmtree(tmp, ignore_errors=True)
    fails = [n for n, t in results if t == "FAIL"]
    print("\nSMOKE:", "ALL PASSED" if not fails else f"FAILED: {', '.join(fails)}")
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    os.environ.setdefault("PYTHONUNBUFFERED", "1")
    main()
