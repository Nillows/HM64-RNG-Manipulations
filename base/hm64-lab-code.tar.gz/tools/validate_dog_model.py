#!/usr/bin/env python3
"""
Check hm64.dog.decide() against an emulator trace (tools/trace.py CSV).

For every VI where the dog could have made a decision (its stateTimer was 0
going in), try "the dog's RNG calls start after `o` other rand() calls this
VI" for o = 0..calls and see if the model reproduces the next state, timer
and direction the game actually stored. Reports:
  explained   decisions the model reproduces (and at which offset o)
  unexplained state/timer changed but no offset reproduces it  -> model bug
              or an RNG consumer we don't know about
"""
from __future__ import annotations

import argparse
import csv
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from hm64.dog import decide          # noqa: E402
from hm64.lcg import step            # noqa: E402


def load(path):
    with open(path) as f:
        return [{k: (float(v) if "." in v else int(v)) for k, v in r.items()} for r in csv.DictReader(f)]


def validate(rows, verbose=False):
    explained, unexplained, offsets, whistles = [], [], Counter(), []
    for prev, cur in zip(rows, rows[1:]):
        if not (prev["dog_flags"] & 0x04) or prev["mode"] != 1:
            continue
        if prev["dog_timer"] != 0:
            continue
        executed = prev["dog_state"]
        following = bool(prev["dog_flags"] & 0x10)
        changed = (cur["dog_state"] != prev["dog_state"] or cur["dog_timer"] != prev["dog_timer"]
                   or cur["dog_dir"] != prev["dog_dir"])
        hit = None
        for o in range(0, cur["calls"] + 1):
            d = decide(executed, step(prev["seed"], o), following)
            if o + d.calls > cur["calls"]:
                continue
            if d.next_state != cur["dog_state"] or d.state_timer != cur["dog_timer"]:
                continue
            if d.direction is not None and d.direction != cur["dog_dir"]:
                continue
            if d.calls == 0 and not changed:
                continue
            hit = (o, d)
            break
        if hit:
            o, d = hit
            offsets[o] += 1
            explained.append((cur["vi"], executed, d.next_state, o, d.calls, cur["calls"]))
        elif changed and cur["dog_state"] == 0 and (cur["dog_flags"] & 0x10):
            whistles.append(cur["vi"])        # handleWhistleForDog(): state=0 + FOLLOWING, no RNG
        elif changed:
            unexplained.append((cur["vi"], prev["dog_state"], cur["dog_state"], prev["dog_timer"],
                                cur["dog_timer"], cur["calls"], following))
    return explained, unexplained, offsets, whistles


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv", nargs="+")
    ap.add_argument("-v", action="store_true")
    a = ap.parse_args()
    for p in a.csv:
        ex, un, off, wh = validate(load(p), a.v)
        print(f"{p}: explained {len(ex)} decisions, whistle resets {len(wh)}, unexplained {len(un)}; "
              f"dog-call offset within VI: {dict(off)}")
        for u in un[:15]:
            print("  UNEXPLAINED vi=%d state %d->%d timer %d->%d calls=%d following=%s" % u)
        if a.v:
            for e in ex[:40]:
                print("  ok vi=%d exec=%d next=%d o=%d dogcalls=%d total=%d" % e)


if __name__ == "__main__":
    main()
