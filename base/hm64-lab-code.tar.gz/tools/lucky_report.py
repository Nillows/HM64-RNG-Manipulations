"""
Lucky Timer report (stage M of the `lucky` preset): blind attempts after mashing C-right at READY.

  python3 tools/lucky_report.py results/campaign-lucky

Reads M_mash.jsonl (mash plans: whistle times + game-state hashes on the cast grid) and M_casts.jsonl (one cast per
distinct state, bites 1 and 2). For every plan k (whistles) it builds, per mash variant (arrival, mash speed,
phase), the outcome of a cast on each grid poll, then the route-weighted chance of the Power Nut for a cast at
stopwatch time T after READY with human timing error sigma (Gaussian over the grid casts), for two fixed policies:
  bite1  release at the first bite;   hold  hold B through the first bite, release at the second.
k = 0 (no whistle) comes from the casttables run (K_casts.jsonl) on the same arrivals, when present.
Also the "zone" policy: release at bite 1 only if it comes in a time zone where bite-1 Nuts outweigh bite-2 Nuts
(bite times seen with the same timing error), otherwise hold.

Writes LUCKY.md and lucky_tables.json (input of tools/export_webapp.py --lucky).
Times: t = VIs after READY (t = 1 is the READY instant); an arrival at offset o casts at path poll o + t - 1.
"""
from __future__ import annotations

import json
import math
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
VI_MS = 33.053 / 2                      # Thomas's measured console game update / 2
SIGMAS_MS = (100, 250)
T_MAX = 2700                            # 45 s


def load_jsonl(p):
    if not Path(p).exists():
        return []
    out = []
    for line in Path(p).read_text().splitlines():
        if line.strip():
            try:
                out.append(json.loads(line))
            except ValueError:
                pass
    return out


def grid_polls(grid):
    g, lo = [], 0
    for step, end in grid:
        g += [p for p in range(lo, end) if p % step == 0]
        lo = end
    return g


def outcome(c):
    """(n1, b1, n2, b2) with bite offsets from the cast poll; None if unusable."""
    if c.get("status") != "ok" or not c.get("bites") or c["bites"][0].get("bite_poll") is None:
        return None
    b = c["bites"]
    n1, b1 = int(b[0]["nut"]), b[0]["bite_poll"] - c["cast"]
    if len(b) > 1 and b[1].get("bite_poll") is not None:
        return n1, b1, int(b[1]["nut"]), b[1]["bite_poll"] - c["cast"]
    return n1, b1, None, None


def kernel(sig_vi):
    r = int(math.ceil(3 * sig_vi))
    x = np.arange(-r, r + 1)
    k = np.exp(-0.5 * (x / sig_vi) ** 2)
    return k / k.sum(), r


def smooth(vals, known, sig_vi):
    """Gaussian-weighted mean of the known grid values around every poll."""
    k, r = kernel(sig_vi)
    num = np.convolve(np.where(known, vals, 0.0), k, mode="same")
    den = np.convolve(known.astype(float), k, mode="same")
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(den > 1e-9, num / den, np.nan)


def build(out):
    out = Path(out)
    mash = [r for r in load_jsonl(out / "M_mash.jsonl") if "_error" not in r]
    casts = load_jsonl(out / "M_casts.jsonl")
    res, checks = {}, {"hash_bad": 0, "verify": 0, "verify_mismatch": 0, "cast_rows": 0, "not_ok": 0}
    verify = []
    for row in casts:
        if "_error" in row:
            continue
        isv = row["tag"].endswith(":verify")
        for c in row["casts"]:
            checks["cast_rows"] += 1
            if c.get("hash_ok") is False:
                checks["hash_bad"] += 1
                continue
            o = outcome(c)
            if o is None:
                checks["not_ok"] += 1
            k = (row["path"], c["cast"], c["hash"])
            if isv:
                verify.append((k, o))
            else:
                res[k] = o
    for k, o in verify:
        if k in res:
            checks["verify"] += 1
            checks["verify_mismatch"] += int(res[k] != o)
    return mash, res, checks


def series_for(mash_row, res):
    """{grid poll: (n1, b1, n2, b2)} for one mash plan."""
    s = {}
    for p, h in mash_row["hashes"]:
        o = res.get((mash_row["path"], p, h))
        if o is not None:
            s[p] = o
    return s


def baseline(out, pairs):
    """k = 0 from the casttables run: {rep signature: {cast poll: outcome}}."""
    table = defaultdict(dict)
    for name in ("K_casts.jsonl", "K_parity.jsonl"):
        for r in load_jsonl(Path(out) / name):
            if "_error" in r or r.get("whistles"):
                continue
            o = outcome({"status": r.get("status"), "cast": r["cast"], "bites": r.get("bites") or []})
            if o is not None:
                table[r["signature"]][r["cast"]] = o
    return table


def curves(variants, horizon, sig_vi, which):
    """variants: [(weight, o, {poll: outcome})] -> route-weighted P(Nut) for t = 1..T_MAX (index t)."""
    tot = np.zeros(T_MAX + 1)
    wsum = np.zeros(T_MAX + 1)
    idx = 0 if which == "bite1" else 2
    t = np.arange(T_MAX + 1)
    for w, o, s in variants:
        vals = np.zeros(horizon + 1)
        known = np.zeros(horizon + 1, bool)
        for p, oc in s.items():
            if p <= horizon and oc[idx] is not None:
                vals[p], known[p] = oc[idx], True
        if not known.any():
            continue
        sm = smooth(vals, known, sig_vi)
        c = o + t - 1
        ok = (c >= 0) & (c <= horizon)
        v = np.full(T_MAX + 1, np.nan)
        v[ok] = sm[c[ok]]
        m = ~np.isnan(v)
        tot[m] += w * v[m]
        wsum[m] += w
    with np.errstate(invalid="ignore", divide="ignore"):
        return np.where(wsum > 0, tot / wsum, np.nan), wsum


def zone_value(variants, t, sig_vi, bin_vi=6):
    """Release at bite 1 only in zones where bite-1 Nuts outweigh bite-2 Nuts (zones judged with sig_vi)."""
    k, r = kernel(sig_vi)
    scen = []
    for w, o, s in variants:
        c0 = o + t - 1
        ws, rows = [], []
        for d in range(-r, r + 1):
            oc = s.get(c0 + d)
            if oc is not None and oc[2] is not None:
                ws.append(k[d + r])
                rows.append((c0 + d, oc))
        if not ws:
            continue
        z = sum(ws)
        for kw, (c, (n1, b1, n2, b2)) in zip(ws, rows):
            scen.append((w * kw / z, c + b1 - o + 1, n1, n2))           # bite-1 time in VIs after READY
    if not scen:
        return None, []
    W = sum(x[0] for x in scen)
    hi = max(x[1] for x in scen) + 4 * sig_vi + bin_vi
    nb = int(hi // bin_vi) + 2
    d1, d2 = np.zeros(nb), np.zeros(nb)
    for w, b, n1, n2 in scen:
        d1[int(b // bin_vi)] += w * n1
        d2[int(b // bin_vi)] += w * n2
    kb, rb = kernel(max(sig_vi / bin_vi, 0.3))
    s1, s2 = np.convolve(d1, kb, mode="same"), np.convolve(d2, kb, mode="same")
    zone = s1 > s2 + 1e-12
    centers = (np.arange(nb) + 0.5) * bin_vi
    val = 0.0
    for w, b, n1, n2 in scen:
        pin = np.exp(-0.5 * ((centers - b) / sig_vi) ** 2)
        pin = float((pin * zone).sum() / pin.sum())
        val += w * (pin * n1 + (1 - pin) * n2)
    zones, cur = [], None
    for i, z in enumerate(zone):
        if z and cur is None:
            cur = [i * bin_vi, (i + 1) * bin_vi]
        elif z:
            cur[1] = (i + 1) * bin_vi
        elif cur is not None:
            zones.append(cur)
            cur = None
    if cur:
        zones.append(cur)
    return val / W, zones


T_MIN = 30                              # 0.5 s: earliest stopwatch cast a runner can aim for


def windows(curve, n=3, sep=60):
    """Top local maxima of a curve, at least `sep` VIs apart (t >= T_MIN)."""
    order = np.argsort(-np.nan_to_num(curve, nan=-1))
    picked = []
    for t in order:
        if t < T_MIN or np.isnan(curve[t]):
            continue
        if all(abs(t - q) >= sep for q in picked):
            picked.append(int(t))
        if len(picked) >= n:
            break
    return picked


def run(out, ks=None, grid=None, pairs=None):
    """ks / grid / pairs: the scope that was cast (a lighter run casts a subset); variants outside it, or with under
    half of their grid casts known, are left out of the report and the app tables."""
    out = Path(out)
    mash, res, checks = build(out)
    if not mash:
        print("lucky report: no M_mash rows")
        return
    grid = grid or mash[0]["_job"]["grid"]
    if ks is not None or pairs is not None:
        mash = [r for r in mash if (ks is None or r["_job"]["whistles"] in ks)
                and (pairs is None or (r["_job"]["signature"], r["_job"]["o"]) in pairs)]
    horizon = grid[-1][1]
    G = grid_polls(grid)
    Gs = set(G)
    kept = []
    for r in mash:                                  # enough of this variant's casts known on the active grid?
        pts = [p for p, h in r["hashes"] if p in Gs]
        known = sum(1 for p, h in r["hashes"] if p in Gs and (r["path"], p, h) in res)
        if pts and known >= 0.5 * len(pts):
            kept.append(r)
    if len(kept) < len(mash):
        print(f"lucky report: {len(mash) - len(kept)} of {len(mash)} mash variants left out (under half their casts known)")
    mash = kept
    if not mash:
        print("lucky report: nothing to report yet")
        return
    pairs = {}
    for r in mash:
        j = r["_job"]
        pairs[(j["signature"], j["o"])] = (j["path"], j["w"])
    tot_w = sum(w for _, w in pairs.values())
    all_w = None
    try:
        from tools.strategy_lab import Truth
        all_w = float(sum(Truth(out).w))
    except Exception:                               # report still works without the observe rows
        pass
    nper = {}
    for r in mash:
        j = r["_job"]
        nper.setdefault(j["whistles"], set()).add(j["period"])
    plans = {}
    for r in mash:
        j = r["_job"]
        k = j["whistles"]
        w = j["w"] / len(nper[k]) / (j["period"] // 2)
        plans.setdefault(k, []).append((w, j["o"], series_for(r, res), r))
    base = baseline(out, pairs)
    if base:
        plans[0] = [(w, o, dict(base.get(sig, {})), None) for (sig, o), (path, w) in pairs.items()]
    lines = ["# Lucky Timer: blind attempts after mashing C-right at READY", "",
             f"Arrivals covered: {len(pairs)} (path, offset) pairs, {tot_w:.0f} routes"
             f"{f' ({tot_w / all_w:.0%} of all)' if all_w else ''}. Cast grid {grid} polls. "
             f"Human timing error σ = {', '.join(str(s) for s in SIGMAS_MS)} ms (Gaussian, over the grid casts).",
             f"Checks: {checks['cast_rows']} cast rows, state-hash mismatches {checks['hash_bad']}, "
             f"unresolved {checks['not_ok']}, shared-state double checks {checks['verify']} "
             f"with {checks['verify_mismatch']} disagreements.", "",
             "| whistles | policy | σ ms | best cast time | P(Nut) | 2nd | 3rd | mean 1–45 s |",
             "|---|---|---|---|---|---|---|---|"]
    summary = {}
    for k in sorted(plans):
        var = [(w, o, s) for w, o, s, _ in plans[k]]
        for pol in ("bite1", "hold"):
            for sms in SIGMAS_MS:
                cv, ws = curves(var, horizon, sms / VI_MS, pol)
                top = windows(cv)
                fmt = lambda t: f"{t * VI_MS / 1000:.2f} s → {cv[t]:.1%}"
                mean = np.nanmean(cv[60:T_MAX + 1])
                summary[(k, pol, sms)] = (top, cv)
                cells = [fmt(t) for t in top] + [""] * (3 - len(top))
                lines.append(f"| {k} | {pol} | {sms} | {cells[0].split(' → ')[0]} | {cells[0].split(' → ')[-1]} | "
                             f"{cells[1]} | {cells[2]} | {mean:.1%} |")
    lines += ["", "## Zone policy (release at bite 1 only inside the zones, else hold for bite 2)", "",
              "| whistles | σ ms | cast time | P(Nut) | release zones (s after READY) |", "|---|---|---|---|---|"]
    best_zone = {}
    for k in sorted(plans):
        var = [(w, o, s) for w, o, s, _ in plans[k]]
        for sms in SIGMAS_MS:
            sig = sms / VI_MS
            cand = set()
            for pol in ("bite1", "hold"):
                cand |= set(summary[(k, pol, sms)][0])
            best = None
            for t in sorted(cand | set(range(T_MIN, T_MAX, 30))):
                v, zones = zone_value(var, t, sig)
                if v is not None and (best is None or v > best[0]):
                    best = (v, t, zones)
            if best:
                v, t, zones = best
                for dt in range(-24, 25, 4):
                    if T_MIN <= t + dt <= T_MAX:
                        v2, z2 = zone_value(var, t + dt, sig)
                        if v2 is not None and v2 > v:
                            v, t, zones = v2, t + dt, z2
                best_zone[(k, sms)] = (v, t, zones)
                zs = ", ".join(f"{a * VI_MS / 1000:.1f}–{b * VI_MS / 1000:.1f}" for a, b in zones[:6])
                lines.append(f"| {k} | {sms} | {t * VI_MS / 1000:.2f} s | {v:.1%} | {zs}{' …' if len(zones) > 6 else ''} |")
    lines += ["", "## By mash speed (bite1, σ 100 ms, at each plan's best time)", ""]
    for k in sorted(p for p in plans if p > 0):
        top = summary[(k, "bite1", 100)][0]
        if not top:
            continue
        t = top[0]
        cells = []
        for P in sorted(nper[k]):
            var = [(w, o, s) for w, o, s, r in plans[k] if r["_job"]["period"] == P]
            cv, _ = curves(var, horizon, 100 / VI_MS, "bite1")
            cells.append(f"{60 / P:.1f} presses/s: {cv[t]:.1%}")
        lines.append(f"- {k} whistle(s), cast {t * VI_MS / 1000:.2f} s: " + "; ".join(cells))
    lines += ["", "Baseline for blind casting is 1/51 = 2.0% per catch only if every catch were an independent "
              "roll; the dock's RNG makes some cast times much better and most worse.",
              "Not shown: arrivals outside the covered pairs (their routes are left out of every percentage)."]
    (out / "LUCKY.md").write_text("\n".join(lines) + "\n")
    export = {"grid": grid, "G": G, "covered_routes": tot_w, "checks": checks, "plans": []}
    for k in sorted(p for p in plans if p > 0):
        sid, series, scen = {}, [], []
        for w, o, s, r in plans[k]:
            pts = [p for p in G if p in s]
            if not pts:
                continue
            i0 = G.index(pts[0])
            i1 = G.index(pts[-1])
            sub = G[i0:i1 + 1]
            n1 = "".join("." if p not in s else str(s[p][0]) for p in sub)
            n2 = "".join("." if p not in s or s[p][2] is None else str(s[p][2]) for p in sub)
            b1 = [-1 if p not in s else s[p][1] for p in sub]
            b2 = [-1 if p not in s or s[p][3] is None else s[p][3] for p in sub]
            key = (r["path"], i0, n1, n2, tuple(b1), tuple(b2))
            if key not in sid:
                sid[key] = len(series)
                series.append({"path": r["path"], "i0": i0, "n1": n1, "n2": n2, "b1": b1, "b2": b2})
            scen.append([sid[key], o, round(w, 4), r["_job"]["period"], r["starts"]])
        export["plans"].append({"k": k, "series": series, "scen": scen})
    (out / "lucky_tables.json").write_text(json.dumps(export, separators=(",", ":")))
    print("\n".join(lines[:4 + 6 * len(plans) + 4]))
    print(f"lucky report: {out / 'LUCKY.md'}, {out / 'lucky_tables.json'}", flush=True)


if __name__ == "__main__":
    run(sys.argv[1] if len(sys.argv) > 1 else ROOT / "results" / "campaign-lucky")
