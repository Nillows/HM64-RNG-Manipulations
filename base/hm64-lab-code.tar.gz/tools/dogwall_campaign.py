"""
Dog-wall heat map (2026-11-17): the dog-watch campaign of tools/zigzag_campaign.py, fast mornings only, casts 0-20 s,
run once per dog spot along the beach's back (south-west) wall. The spot is set with HM64_ZZ_TEST_DOG (dogInfo
location / x / z written at the house load, experiments/zigzag_jobs.py _test_dog_poke): a screening stand-in for a
save made with the dog put down there. Nothing in zigzag_campaign.py is changed; this only adds two presets.
  dogwall       = dogwatch with menus 0-4 game frames late (house 1036-1044), casts 6..1198 VIs after READY (0.1-20 s),
                  dog traces 40 s; bites 1-2 (HM64_DOGWALL_ALLBITES=1: every bite to 90 s, about twice the cast time)
  dogwall-test  = a small grid for the sandbox
Usage: as zigzag_campaign.py, e.g.  python3 tools/dogwall_campaign.py --preset dogwall --workers 13 --out results/dogwall/x-240
"""
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import zigzag_campaign as zc   # noqa: E402

b = dict(zc.PRESETS["dogwatch"])
b.update(house_slack=8, cast_hi=1198, cast_split=1198)
if os.environ.get("HM64_DOGWALL_ALLBITES") != "1":
    b.pop("bites_max", None)
    b.pop("bite_until", None)
zc.PRESETS["dogwall"] = b
t = dict(zc.PRESETS["dogwatch-test"])
t.update(periods=[6], house_slack=8, Ws=[0, 12], cast_hi=206, cast_split=206)
zc.PRESETS["dogwall-test"] = t

if __name__ == "__main__":
    sys.exit(zc.main())
