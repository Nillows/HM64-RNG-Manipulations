#!/usr/bin/env python3
"""
Stage Q - how much does one C-right "pulse" (plus a few keyboard logs) tell the tool?

Game code [DECOMP player.c handleWhistleForDogAnimation, animals.c handleWhistleForDog / updateDog]:
the press starts the player's whistle animation; when it ends (a fixed delay) the dog gets
FOLLOWING + actionState 0, but the dog only acts at its next animation-cycle end with stateTimer 0.
So every press frame inside one window between such boundaries gives the SAME future ("class");
the future changes only where the press crosses a boundary. Following then lasts until a 1-in-21
roll per running cycle ends it - an RNG-driven "how long the dog follows you".

Data: W_single.jsonl (one press on every game frame per dog path, 20 s recorded after it),
W_double.jsonl (press pairs), W_lines.json (paths + route weights).

What the runner can do after a pulse (the tool records the press time from the key pressed
together with C-right, +-HAND VIs):
  R1     log only the response (one key: "the dog reacted"), no pose
  D3     direction-only (Space) for the first 3 facing changes after the press
  AD1/2/3  animation+direction for the first 1/2/3 changes after the press
  AD8s   animation+direction for every change in the 8 s after the press
Logs land REACT VIs after the change (random), never after the animation ended; REACT is
U[10,25] VIs for an uncalibrated runner and U[14,20] once the tool has calibrated their reaction.

Placement: random (the runner whistles whenever) or edge-cued (the tool asks for the press at the
class edge nearest its current estimate). Prior: the dog path is already known from natural logs
and the press frame is known only to +-W frames (W=15 ~ +-0.5 s, W=5).

Reports per strategy: share of pulses after which the future is known (one class left), the
press-frame window left (= how tightly the tool's clock is pinned), bits gained per pulse, and a
projection of how many cued pulses reach +-1 frame.

  python3 tools/pulse_sim.py results/campaign-pulse
"""
from __future__ import annotations

import json
import math
import random
import sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

REACT = (10, 25)        # VIs from a change to the key press (uncalibrated runner)
REACT_CAL = (14, 20)    # a runner whose reaction time the tool has calibrated (+-3 VIs)
MIN_RUN = 12            # animations shorter than this are not logged
HAND = 2                # C-right vs keyboard key, +-VIs
JITTER = 2              # keypress/display jitter, +-VIs
WINDOW_S = 8.0          # logs considered after a press
REPS = 200              # simulated pulses per path and setting
STRATEGIES = ("R1", "D3", "AD1", "AD2", "AD3", "AD8s")
VI_S = 60.0


def load_jsonl(p):
    if not p.exists():
        return []
    return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]


def presses_of(r):
    return r.get("presses") or [r["press"]]


def load(out):
    lines = json.loads((out / "W_lines.json").read_text()) if (out / "W_lines.json").exists() else []
    single = defaultdict(dict)
    for r in load_jsonl(out / "W_single.jsonl"):
        if "_error" not in r:
            single[r["signature"]][presses_of(r)[-1]] = r
    double = defaultdict(lambda: defaultdict(dict))
    for r in load_jsonl(out / "W_double.jsonl"):
        if "_error" not in r:
            ps = presses_of(r)
            double[r["signature"]][ps[0]][ps[-1]] = r
    if not lines:
        lines = [{"line": i, "signature": s, "routes": 1.0} for i, s in enumerate(sorted(single))]
    return lines, single, double


def classes(atlas):
    """[(first press, last press, sig)] runs of consecutive presses with the same future."""
    out = []
    for p in sorted(atlas):
        s = atlas[p]["sig"]
        if out and out[-1][2] == s and p - out[-1][1] <= 2:
            out[-1][1] = p
        else:
            out.append([p, p, s])
    return out


def follow_end(r):
    ev = r["events"]
    on = [e for e in ev if len(e) > 4 and e[4] == 1]
    off = [e for e in ev if len(e) > 4 and e[4] == 0 and on and e[0] > on[0][0]]
    return off[0][0] if off else None


def structure(lines, single):
    rows = []
    for L in lines:
        at = single.get(L["signature"])
        if not at:
            continue
        cl = classes(at)
        lens = sorted((c[1] - c[0]) // 2 + 1 for c in cl)
        resp = sorted(r["response"] for r in at.values() if r.get("response"))
        hand = Counter(r.get("handler") for r in at.values())
        fol = sorted(f for f in (follow_end(r) for r in at.values()) if f is not None)
        # futures after following ended, in absolute draw terms: how many classes share one
        tails = Counter()
        for c in cl:
            r = at[c[0]]
            fe = follow_end(r)
            if fe is not None:
                tails[json.dumps([e[1:4] for e in r["events"] if e[0] > fe])] += 1
        rows.append({"line": L["line"], "routes": L["routes"], "presses": len(at), "classes": len(cl),
                     "class_frames_med": lens[len(lens) // 2], "class_frames_p10": lens[len(lens) // 10],
                     "class_frames_p90": lens[9 * len(lens) // 10], "single_frame_classes": sum(1 for x in lens if x == 1),
                     "handler_vi": hand.most_common(1)[0][0], "response_vi_med": resp[len(resp) // 2] if resp else None,
                     "response_vi_range": [resp[0], resp[-1]] if resp else None,
                     "follow_s_med": round(fol[len(fol) // 2] / VI_S, 2) if fol else None,
                     "follow_s_range": [round(fol[0] / VI_S, 2), round(fol[-1] / VI_S, 2)] if fol else None,
                     "post_follow_futures": len(tails), "classes_with_follow_end": sum(tails.values())})
    return rows


# ------------------------------------------------------------------ observation model
def changes(r):
    """Visible changes after the press: [(t0, t1, screen, class)] (t relative to the press VI)."""
    lim = WINDOW_S * VI_S
    return [(v[0], v[1], v[2], v[3]) for v in r["vis"][1:] if v[0] <= lim]


def make_logs(r, strat, rnd, e_h, react=REACT):
    ch = [c for c in changes(r) if c[1] - c[0] >= MIN_RUN and c[3] is not None]
    resp = r.get("response")
    if strat == "R1":
        if resp is None:
            return []
        c = next((c for c in r["vis"] if c[0] == resp), None)
        L = (c[1] - c[0]) if c else 30
        return [("R", None, resp + min(rnd.randint(*react), max(L - 1, 0)) - e_h)]
    if strat == "D3":
        out, prev = [], r["vis"][0][2]
        for c in ch:
            if c[2] != prev:
                out.append(("D", c[2], c[0] + min(rnd.randint(*react), c[1] - c[0] - 1) - e_h))
                prev = c[2]
            if len(out) == 3:
                break
        return out
    k = {"AD1": 1, "AD2": 2, "AD3": 3, "AD8s": 10 ** 6}[strat]
    return [("AD", (c[2], c[3]), c[0] + min(rnd.randint(*react), c[1] - c[0] - 1) - e_h) for c in ch[:k]]


def consistent(r, logs, react=REACT):
    """A candidate press survives if every log fits: the logged pose (or facing) is on screen at the log
    time AND it began at most react[1] VIs before the log (the runner logs promptly after a change)."""
    vis = r["vis"]
    slack = HAND + JITTER
    facing = []
    for v in vis:
        if facing and facing[-1][2] == v[2]:
            facing[-1][1] = v[1]
        else:
            facing.append([v[0], v[1], v[2]])
    for kind, val, t in logs:
        if kind == "R":
            resp = r.get("response")
            if resp is None or not (t - react[1] - slack <= resp <= t - react[0] + slack):
                return False
            continue
        runs = vis if kind == "AD" else facing
        ok = False
        for v in runs:
            if v[1] <= t - slack:
                continue
            if v[0] > t + slack:
                break
            hit = (v[2], v[3]) == val if kind == "AD" else v[2] == val
            early = min(react[0], v[1] - v[0] - 1)          # a short animation is logged before it ends
            if hit and t - react[1] - slack <= v[0] <= t - early + slack:
                ok = True
                break
        if not ok:
            return False
    return True


def one_pulse(at, keys, strat, W, rnd, cued, edges, react=REACT):
    """Simulate one pulse; returns (future_known, window_frames, bits, n_logs, t_last_s) or None."""
    lo_k, hi_k = keys[0] + 2 * W, keys[-1] - 2 * W
    if hi_k <= lo_k:
        return None
    if cued:
        e = rnd.choice([x for x in edges if lo_k <= x <= hi_k] or [lo_k])
        est = e
        p_true = e + 2 * rnd.randint(-W, W)
    else:
        p_true = lo_k + 2 * rnd.randint(0, (hi_k - lo_k) // 2)
        est = p_true + 2 * rnd.randint(-W, W)
    if p_true not in at:
        return None
    e_h = rnd.randint(-HAND, HAND)
    logs = make_logs(at[p_true], strat, rnd, e_h, react)
    cands = [p for p in range(est - 2 * W, est + 2 * W + 1, 2) if p in at]
    surv = [p for p in cands if consistent(at[p], logs, react)]
    if p_true not in surv:          # model violation (should not happen)
        surv.append(p_true)
    sigs = {at[p]["sig"] for p in surv}
    width = (max(surv) - min(surv)) // 2 + 1
    bits = math.log2(len(cands) / len(surv))
    return (len(sigs) == 1, width, bits, len(logs), (max(t for _, _, t in logs) / VI_S) if logs else 0.0)


def info_table(lines, single, W, cued, rnd, react=REACT):
    res = []
    total = sum(L["routes"] for L in lines if L["signature"] in single)
    for strat in STRATEGIES:
        acc = defaultdict(float)
        widths, times = [], []
        for L in lines:
            at = single.get(L["signature"])
            if not at:
                continue
            keys = sorted(at)
            edges = [c[0] for c in classes(at)[1:]]
            n = 0
            for _ in range(REPS):
                o = one_pulse(at, keys, strat, W, rnd, cued, edges, react)
                if o is None:
                    continue
                n += 1
                acc["known"] += o[0] * L["routes"]
                acc["frame1"] += (o[1] <= 1) * L["routes"]
                acc["bits"] += o[2] * L["routes"]
                acc["w"] += L["routes"]
                widths.append(o[1])
                times.append(o[4])
        W_ = acc["w"] or 1
        widths.sort()
        times.sort()
        res.append({"strategy": strat, "prior_frames": f"+-{W}", "placement": "edge-cued" if cued else "random",
                    "reaction": "calibrated" if react == REACT_CAL else "uncalibrated",
                    "future_known": round(acc["known"] / W_, 3), "pinned_to_1_frame": round(acc["frame1"] / W_, 3),
                    "window_frames_med": widths[len(widths) // 2] if widths else None,
                    "window_frames_p90": widths[9 * len(widths) // 10] if widths else None,
                    "bits": round(acc["bits"] / W_, 2),
                    "logs_done_s_med": round(times[len(times) // 2], 2) if times else None})
    return res


def projection(lines, single, rnd, strat="AD2", react=REACT):
    """Repeated edge-cued pulses: the window left after one pulse becomes the next prior
    (uses the single-press atlas as a stand-in for later pulses)."""
    out = []
    for start in (15, 5):
        n_runs, needed = 0, []
        for L in lines:
            at = single.get(L["signature"])
            if not at:
                continue
            keys = sorted(at)
            edges = [c[0] for c in classes(at)[1:]]
            for _ in range(60):
                W, k = start, 0
                while W > 0 and k < 8:
                    o = one_pulse(at, keys, strat, W, rnd, True, edges, react)
                    if o is None:
                        break
                    k += 1
                    W = max(0, (o[1] - 1) // 2)
                if W == 0:
                    needed.append(k)
                n_runs += 1
        needed.sort()
        out.append({"start_prior_frames": f"+-{start}", "reaction": "calibrated" if react == REACT_CAL else "uncalibrated",
                    "reached_1_frame": round(len(needed) / max(n_runs, 1), 3),
                    "pulses_med": needed[len(needed) // 2] if needed else None,
                    "pulses_p90": needed[9 * len(needed) // 10] if needed else None})
    return out


def double_structure(lines, double):
    rows = []
    for L in lines:
        dd = double.get(L["signature"])
        if not dd:
            continue
        for first, at in sorted(dd.items()):
            cl = classes(at)
            lens = sorted((c[1] - c[0]) // 2 + 1 for c in cl)
            rows.append({"line": L["line"], "first_press": first, "second_presses": len(at), "classes": len(cl),
                         "class_frames_med": lens[len(lens) // 2], "class_frames_p90": lens[9 * len(lens) // 10]})
    return rows


def run(out: Path):
    out = Path(out)
    lines, single, double = load(out)
    if not single:
        print("[Q pulse] no W_single.jsonl rows; skipped", flush=True)
        return
    rnd = random.Random(2026)
    st = structure(lines, single)
    info = []
    for react in (REACT, REACT_CAL):
        for W, cued in ((15, False), (5, True)):
            info += info_table(lines, single, W, cued, rnd, react)
    proj = projection(lines, single, rnd) + projection(lines, single, rnd, react=REACT_CAL)
    dbl = double_structure(lines, double)
    (out / "pulse_summary.json").write_text(json.dumps({"structure": st, "info": info, "projection": proj,
                                                         "double": dbl}, indent=1))
    L = ["## C-right pulses (stage Q)\n",
         "One press on every game frame of each dog path; a *class* is a run of press frames that give the "
         "identical future (the game only acts on a whistle at the dog's next decision boundary). "
         f"Runner logs land {REACT[0]}-{REACT[1]} VIs after a change, press time known to +-{HAND} VIs "
         "(C-right and key pressed together).\n",
         "### What a press does, per dog path",
         "| path | routes | classes / presses | class length frames med (p10-p90) | 1-frame classes | "
         "whistle delay VI | press->visible response VI med (range) | follow s med (range) | futures after "
         "following ends / classes |",
         "|---|---|---|---|---|---|---|---|---|"]
    for r in st:
        L.append(f"| {r['line']} | {r['routes']:.0f} | {r['classes']} / {r['presses']} | {r['class_frames_med']} "
                 f"({r['class_frames_p10']}-{r['class_frames_p90']}) | {r['single_frame_classes']} | {r['handler_vi']} | "
                 f"{r['response_vi_med']} ({r['response_vi_range']}) | {r['follow_s_med']} ({r['follow_s_range']}) | "
                 f"{r['post_follow_futures']} / {r['classes_with_follow_end']} |")
    L += ["", "### Information from one pulse (path already known)",
          "| logs after the press | runner reaction | prior | placement | future known | clock pinned to 1 frame | "
          "press-frame window left med (p90) | bits | logs done (s after press) |", "|---|---|---|---|---|---|---|---|---|"]
    for r in info:
        L.append(f"| {r['strategy']} | {r['reaction']} | {r['prior_frames']} | {r['placement']} | {r['future_known']:.0%} | "
                 f"{r['pinned_to_1_frame']:.0%} | {r['window_frames_med']} ({r['window_frames_p90']}) | {r['bits']} | "
                 f"{r['logs_done_s_med']} |")
    L += ["", "### Repeated cued pulses (projection, AD2 after each press)",
          "| start | runner reaction | reach +-1 frame | pulses med (p90) |", "|---|---|---|---|"]
    for r in proj:
        L.append(f"| {r['start_prior_frames']} | {r['reaction']} | {r['reached_1_frame']:.0%} | {r['pulses_med']} "
                 f"({r['pulses_p90']}) |")
    if dbl:
        L += ["", "### Second press (press pairs): class structure after the first whistle",
              "| path | first press poll | second presses | classes | class length frames med (p90) |",
              "|---|---|---|---|---|"]
        for r in dbl:
            L.append(f"| {r['line']} | {r['first_press']} | {r['second_presses']} | {r['classes']} | "
                     f"{r['class_frames_med']} ({r['class_frames_p90']}) |")
    L.append("\nFiles: `pulse_summary.json`, raw `W_single.jsonl`, `W_double.jsonl`, `W_lines.json`.")
    text = "\n".join(L) + "\n"
    (out / "PULSE.md").write_text(text)
    rep = out / "REPORT.md"
    body = rep.read_text() if rep.exists() else "# HM64 pulse study\n\n"
    cut = body.find("## C-right pulses (stage Q)")
    if cut >= 0:
        body = body[:cut].rstrip() + "\n\n"
    rep.write_text(body + text)
    print(text, flush=True)


if __name__ == "__main__":
    run(Path(sys.argv[1]))
