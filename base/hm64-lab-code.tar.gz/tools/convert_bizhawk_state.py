#!/usr/bin/env python3
"""
Convert a BizHawk Mupen64Plus-core savestate (*.Mupen64Plus.QuickSaveN.State,
a ZIP holding Core.bin.zst) into a native mupen64plus .st the harness can load.

The BizHawk core blob embeds a standard "M64+SAVE" snapshot (version 1.0):
  44-byte header (magic, version, ROM MD5) + 16,788,244 bytes of machine state
  + an interrupt event queue of u32 pairs terminated by 0xFFFFFFFF.
We cut exactly that out, gzip it, and refuse if the embedded ROM MD5 does not
match the ROM you pass. The original file is never modified.

  python3 tools/convert_bizhawk_state.py \
      --state "data/states_bizhawk/Harvest Moon 64 (USA).Mupen64Plus.QuickSave2(1).State" \
      --out states/qs2.st
Ares states (also Core.bin.zst) are a different format and are rejected.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import struct
import sys
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from tools.common import default_rom   # noqa: E402

MAGIC = b"M64+SAVE"
BODY = 16788244
MAX_QUEUE = 1024


def extract(state_path: Path) -> bytes:
    import zstandard
    with zipfile.ZipFile(state_path) as z:
        names = z.namelist()
        if "Core.bin.zst" not in names:
            raise SystemExit(f"{state_path}: no Core.bin.zst (members: {names})")
        raw = zstandard.ZstdDecompressor().decompressobj().decompress(z.read("Core.bin.zst"))
    at = raw.find(MAGIC)
    if at < 0:
        raise SystemExit("no M64+SAVE snapshot inside Core.bin (Ares or other core?)")
    version = struct.unpack(">I", raw[at + 8:at + 12])[0]
    if version >> 16 != 1:
        raise SystemExit(f"unsupported snapshot version {version:#010x}")
    q = at + 44 + BODY
    end = None
    for off in range(q, min(q + MAX_QUEUE, len(raw) - 3), 4):
        if raw[off:off + 4] == b"\xff\xff\xff\xff":
            end = off + 4
            break
    if end is None:
        raise SystemExit("event queue terminator not found")
    return raw[at:end], version


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--state", help="default: data/states_bizhawk/*QuickSave2(1).State")
    ap.add_argument("--rom", default=default_rom())
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    if not a.state:
        from tools.common import DATA
        hits = sorted((DATA / "states_bizhawk").glob("*QuickSave2(1).State"))
        if not hits:
            raise SystemExit("no --state given and no *QuickSave2(1).State in data/states_bizhawk/")
        a.state = str(hits[0])
    blob, version = extract(Path(a.state))
    md5_state = blob[12:44].decode("ascii", "replace").upper()
    md5_rom = hashlib.md5(Path(a.rom).read_bytes()).hexdigest().upper()
    if md5_state != md5_rom:
        raise SystemExit(f"ROM mismatch: state was made with {md5_state}, your ROM is {md5_rom}")
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with gzip.open(out, "wb") as f:
        f.write(blob)
    src_sha = hashlib.sha256(Path(a.state).read_bytes()).hexdigest()
    meta = {"vi": 0, "source": Path(a.state).name, "source_sha256": src_sha,
            "kind": "converted-bizhawk", "m64p_version": f"{version:#010x}", "rom_md5": md5_rom}
    out.with_suffix(out.suffix + ".json").write_text(json.dumps(meta, indent=1))
    print(f"Converted M64+SAVE v{version >> 16}.{(version >> 8) & 0xFF} -> {out}  (ROM MD5 {md5_rom})")


if __name__ == "__main__":
    main()
