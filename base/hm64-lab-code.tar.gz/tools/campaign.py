#!/usr/bin/env python3
"""
HM64 Power Nut campaign: cold boot -> realistic arrivals -> natural and whistle
plans -> observation tables -> REPORT.md. Resumable: re-running skips work
already in the output folder.

  python3 tools/campaign.py --preset quick --out results/campaign-quick
  python3 tools/campaign.py --preset oracle --out results/campaign-oracle --layer1 /layer1

Stages
  A  arrival pool: sampled measured routes (data/routes/ROUTE_TO_CHECKPOINT_LINKS.csv)
     replayed from power-on to dock READY; natural future (no input) for
     `horizon` VIs; arrivals grouped into scenarios by that future.
  L  ladder: each scenario's natural path for 2700 VIs (what the dog visibly
     shows every VI) + a savestate rung every 60 polls; B/P/C start from rungs.
  B  natural plans: every scenario x cast poll (0-based polls after READY):
     bite window + whether the Nut is awarded, release window mapped for wins.
  P  parity: odd neighbours of the first/last win (which 2 polls = 1 game frame).
  C  whistle plans: C-right at poll w, then cast. By default only for scenarios
     with no natural Nut cast in range ("rescue"); --whistle-all for all.
  D  analysis: scenarios.csv, natural_plans.csv, whistle_plans.csv,
     observation_elimination.csv, oracle_table.json, REPORT.md.
  E  oracle simulation (tools/oracle_sim.py): ORACLE.md, oracle_sim.csv,
     oracle_scenarios.json.
  F  Layer 1 link (tools/layer1_link.py, --layer1 DIR): LAYER1.md, layer1_links.*
Presets size the work; every knob can be overridden on the command line.
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import random
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "experiments"))

from m64h.pool import run_jobs                            # noqa: E402
from tools.common import default_rom, default_sram         # noqa: E402

PRESETS = {
    # routes per family (or "all"), horizon VIs, natural casts a:b:s, whistle polls, cast span after last whistle
    "smoke":    dict(menu=6, travel=3, interaction=3, horizon=1200, casts="0:120:4",
                     whistles="4,16", wspan="44:160:4", whistle_all=False),
    "quick":    dict(menu=60, travel=30, interaction=30, horizon=1800, casts="0:240:2",
                     whistles="4,16,28", wspan="44:240:2", whistle_all=False),
    "standard": dict(menu=600, travel=200, interaction=200, horizon=1800, casts="0:400:2",
                     whistles="4,12,20,28,36", wspan="44:300:2", whistle_all=False),
    "full":     dict(menu="all", travel="all", interaction="all", horizon=1800, casts="0:600:2",
                     whistles="4,12,20,28,36,44", wspan="44:400:2", whistle_all=True),
    # oracle: same 121-route pool as quick, but casts across the whole observation window
    "oracle":   dict(menu=60, travel=30, interaction=30, horizon=1800, casts="0:1200:2",
                     whistles="4,16,28", wspan="44:240:2", whistle_all=False),
    # observe: every Layer 1 anchor (up to 2 routes each) -> 60 s of what the runner can see -> how
    # many keyboard logs, of which kind, until the RNG/dog state is known (stages A, O, I only)
    "observe":  dict(menu=0, travel=0, interaction=0, per_anchor=2, horizon=1800, observe_vi=4800,
                     casts="0:0:2", whistles="4", wspan="44:44:2", whistle_all=False, stages="AOI"),
    # pulse: C-right "pulses" on every dog path (world line): one press on every game frame 2-30 s after
    # READY (+20 s recorded after it), and press pairs on the 10 most common paths; then how much each
    # pulse + a few keyboard logs tells the tool (stages W, Q; needs the observe run's rows, reused)
    "pulse":    dict(menu=0, travel=0, interaction=0, per_anchor=2, horizon=1800, observe_vi=4800,
                     casts="0:0:2", whistles="4", wspan="44:44:2", whistle_all=False,
                     pulse="120:1800:2", pulse_post=1200, pulse2_lines=10, pulse2_first="600,900",
                     pulse2_gap="60:540:2", pulse2_post=900, stages="WQ"),
    # casttables: natural Power Nut cast tables for every dog path (its representative arrival), a cast on
    # every game frame 0-75 s after READY, plus parity probes; feeds the v28 web app (stage K)
    "casttables": dict(menu=0, travel=0, interaction=0, per_anchor=2, horizon=1800, observe_vi=4800,
                       casts="0:4500:2", whistles="4", wspan="44:44:2", whistle_all=False, stages="K"),
    # casttables after 40 s with Thomas's SE stay-awake push at 38.3 s (polls 2300-2303): without it the
    # farmer naps at poll 2401 (player.c playerIdleCounter == 1200) and no cast starts. Push = RNG/dog neutral.
    # 180 s: a push every 2000 polls (33.3 s) keeps him awake (each push resets the 40 s idle counter); the ladder
    # also records the dog's visible path to ~184 s, which extends the app's dog timelines past the 80 s observe run
    "awake": dict(menu=0, travel=0, interaction=0, per_anchor=2, horizon=1800, observe_vi=4800,
                  casts="2402:10800:2", wake="2000,4000,6000,8000,10000", kprefix="K2", whistles="4",
                  wspan="44:44:2", whistle_all=False, stages="K"),
    # one whistle in the barren zone (no bite-1 Nut after ~72 s): whistle at 74/82/90/98 s, then casts every 4th
    # game frame for 40 s (bites 1 and 2), awake pushes kept; rungs come from the awake run's K2 ladder
    "whistle": dict(menu=0, travel=0, interaction=0, per_anchor=2, horizon=1800, observe_vi=4800,
                    casts="46:2446:8", kwhistles="4440,4920,5400,5880", ladder_from="K2", kprefix="K3",
                    wake="2000,4000,6000,8000,10000", whistles="4", wspan="44:44:2", whistle_all=False, stages="K"),
    # lucky: blind attempts for the Lucky Timer. The runner mashes C-right from READY and stops at the k-th whistle
    # (k = 1, 2, 3; mash speeds 6/8/10 polls per press, every phase), then casts at a stopwatch time. Casts every 4
    # polls to 25 s, every 8 to 46 s, bites 1 and 2, for the arrivals covering 93% of routes. Equal game states
    # (RNG + dog + dog sprite + player) share one cast evaluation; 1% of shared states are cast twice to check.
    "lucky": dict(menu=0, travel=0, interaction=0, per_anchor=2, horizon=1800, observe_vi=4800,
                  casts="0:0:2", whistles="4", wspan="44:44:2", whistle_all=False, wake="2000",
                  lucky_k="1,2,3", lucky_periods="6,8,10", lucky_cover=0.93, lucky_grid="4:1500,8:2770",
                  lucky_verify=0.01, stages="M"),
}
LADDER_HORIZON = 2700   # VIs of natural path recorded per scenario (= Layer 1's 1350-update horizon)
RUNG_POLLS = 60
LINKS = ROOT / "data" / "routes" / "ROUTE_TO_CHECKPOINT_LINKS.csv"
VI_PER_S = 60.0


def rng_range(spec):
    a, b, s = (int(x) for x in spec.split(":"))
    return list(range(a, b, s))


def load_jsonl(p):
    if not p.exists():
        return []
    out = []
    for line in p.read_text().splitlines():
        if line.strip():
            try:
                out.append(json.loads(line))
            except ValueError:
                pass
    return out


def run_stage(name, fn, jobs, out_path, workers, fresh, rom, sram, key):
    done = {key(r["_job"]) for r in load_jsonl(out_path) if "_error" not in r}
    todo = [j for j in jobs if key(j) not in done]
    print(f"[{name}] {len(jobs)} jobs, {len(done)} already done, {len(todo)} to run", flush=True)
    if not todo:
        return
    t0 = time.time()
    n = 0
    with out_path.open("a") as f:
        for res in run_jobs(fn, todo, rom=rom, sram=sram, workers=workers, fresh=fresh):
            f.write(json.dumps(res) + "\n")
            f.flush()
            n += 1
            if n % 10 == 0 or n == len(todo):
                el = time.time() - t0
                eta = el / n * (len(todo) - n)
                print(f"[{name}] {n}/{len(todo)}  {n / el:.2f} jobs/s  eta {eta / 60:.1f} min", flush=True)


# ---------------------------------------------------------------- stage A
def family(r):
    if any(int(r[k]) for k in ("menu0", "menu1", "menu2", "menu3")):
        return "menu"
    if int(r["h"]) or int(r["c"]):
        return "travel"
    if int(r["p"]) or int(r["d"]):
        return "interaction"
    return "baseline"


def route_jobs(cfg, seed):
    fams = defaultdict(list)
    with open(LINKS) as f:
        for r in csv.DictReader(f):
            fams[family(r)].append(r)
    rnd = random.Random(seed)
    picked = list(fams["baseline"])
    for fam in ("menu", "travel", "interaction"):
        n = cfg[fam]
        rows = fams[fam]
        picked += rows if n == "all" else rnd.sample(rows, min(int(n), len(rows)))
    if cfg.get("per_anchor"):
        by_anchor = defaultdict(list)
        for fam_rows in fams.values():
            for r in fam_rows:
                by_anchor[r["anchor_id"]].append(r)
        have = {r["label"] for r in picked}
        for a in sorted(by_anchor, key=lambda x: int(x) if x.isdigit() else x):
            rows = sorted(by_anchor[a], key=lambda r: r["label"])
            for r in rnd.sample(rows, min(int(cfg["per_anchor"]), len(rows))):
                if r["label"] not in have:
                    picked.append(r)
                    have.add(r["label"])
    rnd.shuffle(picked)
    return [{"label": r["label"], "family": family(r), "horizon": cfg["horizon"],
             "legacy": [int(r["ready_vi"]), int(r["draw_index"])],
             "case": [int(r[k]) for k in ("menu0", "menu1", "menu2", "menu3", "h", "c", "p", "d")]}
            for r in picked]


def scenarios_from(routes):
    sc = {}
    for r in routes:
        if r.get("outcome") != "ready":
            continue
        s = sc.setdefault(r["signature"], {"signature": r["signature"], "state": r["state"], "members": [],
                                           "families": Counter(), "draw_indices": set(), "ready_vis": set(),
                                           "dog_at_ready": r["dog_at_ready"], "events": r["events"],
                                           "first_idle_nap_vi": r.get("first_idle_nap_vi")})
        s["members"].append(r["label"])
        s["families"][r["family"]] += 1
        s["draw_indices"].add(r["draw_index"])
        s["ready_vis"].add(r["ready_vi"])
    return sorted(sc.values(), key=lambda s: (-len(s["members"]), s["signature"]))


# ---------------------------------------------------------------- stage D helpers
def visible_events(events):
    """(t, anim, dir) whenever what a human sees changes: animation or facing."""
    out, last = [], None
    for t, state, anim, d in events:
        if (anim, d) != last:
            out.append((t, anim, d))
            last = (anim, d)
    return out


def _obs_key(ev, k, tau):
    """What a player can record: animation + facing of each change, and (if tau)
    the gap since the PREVIOUS change in tau-VI buckets. No absolute time:
    the player cannot know the READY frame on hardware."""
    key = []
    for i, (t, a, d) in enumerate(ev[:k]):
        gap = None if (tau is None or i == 0) else (t - ev[i - 1][0]) // tau
        key.append((a, d, gap))
    return tuple(key)


def elimination(scen, taus=(None, 30, 6), kmax=12):
    rows = []
    weights = {s["signature"]: len(s["members"]) for s in scen}
    vis = {s["signature"]: visible_events(s["events"]) for s in scen}
    for tau in taus:
        for k in range(1, kmax + 1):
            classes = defaultdict(list)
            for sig, ev in vis.items():
                classes[_obs_key(ev, k, tau)].append(sig)
            sizes = [len(v) for v in classes.values()]
            singles = sum(1 for v in classes.values() if len(v) == 1)
            wexp = sum(weights[s] * len(v) for v in classes.values() for s in v) / max(1, sum(weights.values()))
            rows.append({"gap_tolerance_vi": tau or "order-only", "k_events": k, "classes": len(classes),
                         "unique_scenarios": singles, "max_class": max(sizes),
                         "route_weighted_expected_candidates": round(wexp, 2)})
    ttu = {}
    for sig, ev in vis.items():
        for k in range(1, len(ev) + 1):
            key = _obs_key(ev, k, 6)
            if sum(1 for e2 in vis.values() if _obs_key(e2, k, 6) == key) == 1:
                ttu[sig] = (ev[k - 1][0] - ev[0][0], k)
                break
    return rows, ttu


def write_csv(path, rows):
    if not rows:
        path.write_text("")
        return
    keys = list(rows[0].keys())
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def analyze(out, cfg, args):
    routes = [r for r in load_jsonl(out / "A_routes.jsonl") if "_error" not in r]
    errors_a = [r for r in load_jsonl(out / "A_routes.jsonl") if "_error" in r]
    scen = scenarios_from(routes)
    casts = [r for r in load_jsonl(out / "B_natural.jsonl") if "_error" not in r]
    whist = [r for r in load_jsonl(out / "C_whistle.jsonl") if "_error" not in r]
    errors_bc = sum(1 for f in ("B_natural.jsonl", "C_whistle.jsonl") for r in load_jsonl(out / f) if "_error" in r)

    # legacy agreement + discovery curve
    agree = sum(1 for r in routes if r.get("outcome") == "ready" and
                [r["ready_vi"], r["draw_index"]] == r["_job"]["legacy"])
    ready = [r for r in routes if r.get("outcome") == "ready"]
    seen, curve = set(), []
    for i, r in enumerate(ready, 1):
        seen.add(r["signature"])
        curve.append((i, len(seen)))
    marks = sorted({max(1, int(len(curve) * q)) for q in (0.1, 0.25, 0.5, 0.75, 1.0)}) if curve else []

    nat = defaultdict(list)
    for r in casts:
        nat[r["signature"]].append(r)
    wh = defaultdict(list)
    for r in whist:
        wh[r["signature"]].append(r)

    def wins(rs):
        return sorted((r for r in rs if r["nut_releases"] or "nut" in r["probes"].values()),
                      key=lambda r: (r["cast"], r["whistles"]))

    elim, ttu = elimination(scen)
    scen_rows, nat_rows, wh_rows, oracle = [], [], [], []
    for i, s in enumerate(scen):
        sig = s["signature"]
        nw = wins(nat[sig])
        ww = wins(wh[sig])
        first_nat = nw[0] if nw else None
        first_wh = ww[0] if ww else None
        scen_rows.append({
            "scenario": i, "signature": sig, "routes": len(s["members"]),
            "families": dict(s["families"]), "ready_draw_indices": sorted(s["draw_indices"]),
            "ready_vis": sorted(s["ready_vis"]), "dog_at_ready": s["dog_at_ready"],
            "casts_tested": len(nat[sig]), "natural_nut_casts": len(nw),
            "earliest_natural_nut_cast": first_nat["cast"] if first_nat else None,
            "earliest_natural_release_window": ([first_nat["nut_releases"][0], first_nat["nut_releases"][-1]]
                                                if first_nat and first_nat["nut_releases"] else None),
            "whistle_plans_tested": len(wh[sig]), "whistle_nut_plans": len(ww),
            "best_whistle_plan": ({"whistle": first_wh["whistles"], "cast": first_wh["cast"],
                                   "release": [first_wh["nut_releases"][0], first_wh["nut_releases"][-1]]
                                   if first_wh["nut_releases"] else None} if first_wh else None),
            "solved": bool(nw or ww),
            "events_to_unique_gap6": ttu[sig][1] if sig in ttu else None,
            "seconds_after_first_change_to_unique": round(ttu[sig][0] / VI_PER_S, 2) if sig in ttu else None,
            "idle_nap_vi": s["first_idle_nap_vi"], "state": s["state"]})
        for r in nw:
            nat_rows.append({"scenario": i, "signature": sig, "cast": r["cast"],
                             "cast_started_poll": r.get("cast_started_poll"), "bite_poll": r["bite_poll"],
                             "release_first": r["nut_releases"][0] if r["nut_releases"] else None,
                             "release_last": r["nut_releases"][-1] if r["nut_releases"] else None,
                             "release_count": len(r["nut_releases"]),
                             "window_codes": (r["window_outcomes"] or {}).get("codes")})
        for r in ww:
            wh_rows.append({"scenario": i, "signature": sig, "whistles": r["whistles"], "cast": r["cast"],
                            "cast_started_poll": r.get("cast_started_poll"), "bite_poll": r["bite_poll"],
                            "release_first": r["nut_releases"][0] if r["nut_releases"] else None,
                            "release_last": r["nut_releases"][-1] if r["nut_releases"] else None,
                            "release_count": len(r["nut_releases"])})
        oracle.append({"scenario": i, "signature": sig, "routes": len(s["members"]),
                       "visible": [list(v) for v in visible_events(s["events"])][:16],
                       "natural": [{"cast": r["cast"], "release": [r["nut_releases"][0], r["nut_releases"][-1]]
                                    if r["nut_releases"] else None, "bite": r["bite_poll"]} for r in nw],
                       "whistle": [{"whistle": r["whistles"], "cast": r["cast"], "bite": r["bite_poll"],
                                    "release": [r["nut_releases"][0], r["nut_releases"][-1]]
                                    if r["nut_releases"] else None} for r in ww]})

    extra_rows = []
    for sig in sorted({r["signature"] for r in casts + whist if r["signature"].startswith("extra:")}):
        nw, ww = wins(nat[sig]), wins(wh[sig])
        extra_rows.append({"state": sig[6:], "casts_tested": len(nat[sig]), "natural_nut_casts": [r["cast"] for r in nw],
                           "whistle_nut_plans": [[r["whistles"], r["cast"]] for r in ww]})
        for r in nw:
            nat_rows.append({"scenario": sig, "signature": sig, "cast": r["cast"],
                             "cast_started_poll": r.get("cast_started_poll"), "bite_poll": r["bite_poll"],
                             "release_first": r["nut_releases"][0] if r["nut_releases"] else None,
                             "release_last": r["nut_releases"][-1] if r["nut_releases"] else None,
                             "release_count": len(r["nut_releases"]),
                             "window_codes": (r["window_outcomes"] or {}).get("codes")})
    write_csv(out / "scenarios.csv", scen_rows)
    write_csv(out / "natural_plans.csv", nat_rows)
    write_csv(out / "whistle_plans.csv", wh_rows)
    write_csv(out / "observation_elimination.csv", elim)
    (out / "oracle_table.json").write_text(json.dumps(oracle, indent=1))

    # ---- summary + report
    n_sc = len(scen)
    solved_nat = sum(1 for r in scen_rows if r["natural_nut_casts"])
    solved_any = sum(1 for r in scen_rows if r["solved"])
    w_routes = sum(r["routes"] for r in scen_rows)
    w_solved = sum(r["routes"] for r in scen_rows if r["solved"])
    unsolved = [r for r in scen_rows if not r["solved"]]
    earliest = [r["earliest_natural_nut_cast"] for r in scen_rows if r["earliest_natural_nut_cast"] is not None]
    widths = [r["release_count"] for r in nat_rows if r["release_count"]]
    summary = {
        "preset": args.preset, "config": cfg, "routes_run": len(routes), "route_errors": len(errors_a),
        "ready": len(ready), "outcomes": dict(Counter(r.get("outcome") for r in routes)),
        "legacy_agreement": f"{agree}/{len(ready)}", "scenarios": n_sc,
        "discovery_curve": [curve[m - 1] for m in marks] if curve else [],
        "cast_jobs": len(casts), "whistle_jobs": len(whist), "cast_errors": errors_bc,
        "scenarios_with_natural_nut": solved_nat, "scenarios_solved_any": solved_any,
        "route_weighted_solved": f"{w_solved}/{w_routes}",
        "earliest_natural_nut_cast_median": sorted(earliest)[len(earliest) // 2] if earliest else None,
        "nut_release_window_polls_min_median_max": [min(widths), sorted(widths)[len(widths) // 2], max(widths)]
        if widths else None,
        "unsolved_scenarios": [r["scenario"] for r in unsolved],
        "extra_states": extra_rows,
    }
    (out / "summary.json").write_text(json.dumps(summary, indent=1))

    L = []
    L.append(f"# HM64 Power Nut campaign — preset `{args.preset}`\n")
    L.append(f"Generated {time.strftime('%Y-%m-%d %H:%M')} by `tools/campaign.py`. All inputs are real controller "
             "input from power-on (no RAM/RNG writes). Polls in plans are 0-based controller reads after the "
             "dock READY state (legacy `fishing_ready` predicate).\n")
    L.append("## Arrival pool (stage A)\n")
    L.append(f"- Routes replayed: **{len(routes)}** (errors {len(errors_a)}); outcomes {dict(summary['outcomes'])}")
    L.append(f"- Agreement with your legacy cohort (ready VI + draw index): **{summary['legacy_agreement']}**")
    L.append(f"- Distinct arrival scenarios (identical {cfg['horizon']}-VI natural future): **{n_sc}**")
    if curve:
        L.append(f"- Discovery curve (routes → scenarios): " + ", ".join(f"{a}→{b}" for a, b in summary['discovery_curve']))
    L.append(f"- Largest scenarios by route count: " + ", ".join(
        f"#{r['scenario']} ({r['routes']} routes, draw {r['ready_draw_indices']})" for r in scen_rows[:5]))
    L.append("\n## Natural plans (stage B)\n")
    L.append(f"- Casts tested per scenario: `{cfg['casts']}` (polls after READY). Cast jobs: {len(casts)}.")
    L.append(f"- Scenarios with at least one natural Nut cast in range: **{solved_nat}/{n_sc}**")
    if earliest:
        L.append(f"- Earliest natural Nut cast: median **{summary['earliest_natural_nut_cast_median']}** polls "
                 f"(~{summary['earliest_natural_nut_cast_median'] / VI_PER_S:.1f} s) after READY; "
                 f"range {min(earliest)}–{max(earliest)}")
    if widths:
        a, b, c = summary["nut_release_window_polls_min_median_max"]
        L.append(f"- Nut release window width (polls, every winning cast mapped): min {a}, median {b}, max {c}")
    L.append("\n## Whistle plans (stage C)\n")
    L.append(f"- Whistle polls `{cfg['whistles']}`, casts `{cfg['wspan']}` after the last whistle; "
             f"{'all scenarios' if cfg['whistle_all'] else 'only scenarios without a natural Nut (rescue)'}. "
             f"Jobs: {len(whist)}.")
    L.append(f"- Scenarios solved by natural OR whistle plan: **{solved_any}/{n_sc}**; "
             f"route-weighted: **{summary['route_weighted_solved']}**")
    if unsolved:
        L.append(f"- Still unsolved in the tested ranges: scenarios {summary['unsolved_scenarios']} "
                 "(widen casts / whistle grid before calling them unsolvable).")
    for e in extra_rows:
        L.append(f"- Extra state `{e['state']}`: natural Nut casts {e['natural_nut_casts'] or 'none'} "
                 f"(of {e['casts_tested']} tested); whistle plans {e['whistle_nut_plans'] or 'none'}")
    L.append("\n## Observation (stage D)\n")
    L.append("Visible event = change of (animation name, internal facing) at a dog decision. The player records "
             "each change and, optionally, the gap since the previous change (bucketed by the tolerance); no "
             "absolute time, since READY's exact frame is unknowable on hardware. Animation names merge "
             "identical-state aliases but NOT the per-facing sprite ambiguities in your v25 ambiguity matrix, "
             "so these numbers are an upper bound on what a human can read.\n")
    L.append("| gap tolerance (VI) | changes seen | classes | unique scenarios | largest class | route-weighted candidates |")
    L.append("|---|---|---|---|---|---|")
    for r in elim:
        if r["k_events"] in (1, 2, 3, 4, 6, 8, 12):
            L.append(f"| {r['gap_tolerance_vi']} | {r['k_events']} | {r['classes']} | {r['unique_scenarios']} | "
                     f"{r['max_class']} | {r['route_weighted_expected_candidates']} |")
    tt = sorted(r["seconds_after_first_change_to_unique"] for r in scen_rows
                if r["seconds_after_first_change_to_unique"] is not None)
    if tt:
        L.append(f"\nWith 0.1 s gap tolerance, a scenario becomes unique a median {tt[len(tt) // 2]} s after the "
                 f"first visible change (90th pct {tt[max(0, int(len(tt) * 0.9) - 1)]} s); "
                 f"{n_sc - len(tt)} scenarios never become unique within the horizon.")
    shapes = Counter((r["window_codes"] or "")[:26] for r in nat_rows if r.get("window_codes"))
    if shapes:
        L.append("\nRelease-window shapes seen on mapped winning casts (n=Nut f=fish h=held through, from the "
                 "first branchable poll): " + "; ".join(f"`{k}` ×{v}" for k, v in shapes.most_common(5)))
    L.append("\n## Files\n")
    L.append("`scenarios.csv` (one row per scenario), `natural_plans.csv`, `whistle_plans.csv`, "
             "`observation_elimination.csv`, `oracle_table.json` (visible dog sequence → plans, for the player "
             "tool), raw `A_routes.jsonl`, `L_ladder.jsonl`, `B_natural.jsonl`, `P_parity.jsonl`, "
             "`C_whistle.jsonl`, `summary.json`. Stages E and F append their sections below.")
    L.append("\n## What this does NOT establish\n")
    L.append("- Real-console timing: polls/VIs here are emulator-exact; human reaction and N64 poll phase are not "
             "modelled.\n- Scenarios are defined by the natural future over the horizon; two arrivals equal over "
             f"{cfg['horizon']} VIs could still differ later.\n- Untested casts/whistles are unknown, not losses.\n"
             "- Long dock waits can trigger the idle nap; plans that wait >~ the recorded nap VI need the SE wake "
             "policy, which is not applied here.")
    (out / "REPORT.md").write_text("\n".join(L) + "\n")
    print(json.dumps(summary, indent=1))


def pulse_reps(out, scen):
    """One representative arrival per dog path (world line): the one that joins the path earliest."""
    from tools.ident_sim import build as ibuild
    d = ibuild(out)
    state = {s["signature"]: s["state"] for s in scen}
    reps = {}
    for i, sig in enumerate(d["sigs"]):
        line = int(d["wl"][i])
        if sig not in state:
            continue
        key = (int(d["DRAW"][i, 1]), sig)
        if line not in reps or key < reps[line][0]:
            reps[line] = (key, sig)
    weight = defaultdict(float)
    for i, sig in enumerate(d["sigs"]):
        weight[int(d["wl"][i])] += float(d["w"][i])
    rows = [{"root": line, "signature": sig, "state": state[sig], "routes": round(weight[line], 1),
             "ready_draw": key[0]} for line, (key, sig) in reps.items()]
    rows.sort(key=lambda r: -r["routes"])
    for k, r in enumerate(rows, 1):
        r["line"] = k                                  # path 1 = the most common dog path
    (out / "W_lines.json").write_text(json.dumps(rows, indent=1))
    return rows


def run_cast_tables(out, cfg, args, scen):
    """Natural cast tables per dog path: ladder + one cast per game frame + odd-poll parity probes."""
    from campaign_jobs import cast_job_rung, ladder_job
    reps = json.loads((out / "W_lines.json").read_text()) if (out / "W_lines.json").exists() else pulse_reps(out, scen)
    K = cfg.get("kprefix", "K")
    wake = [int(w) for w in str(cfg.get("wake", "")).split(",") if w.strip()]
    extra = {"wake": wake} if wake else {}
    store = {"store": "states/campaign/ladder_awake"} if wake else {}
    reps = sorted(reps, key=lambda r: int(r.get("line", 99)))
    if getattr(args, "cast_paths", 0):
        reps = reps[:args.cast_paths]
    a, b, st = (int(x) for x in os.environ.get("HM64_CASTS", cfg["casts"]).split(":"))
    print(f"cast tables: {len(reps)} dog paths, casts {a}..{b} step {st}", flush=True)
    LK = cfg.get("ladder_from", K)
    if LK == K:
        jobs = [{"signature": r["signature"], "state": r["state"], "horizon": b + 240, "rung_polls": RUNG_POLLS,
                 "rung_until": b, **extra, **store} for r in reps]
        run_stage(f"{K} ladder", ladder_job, jobs, out / f"{K}_ladder.jsonl", args.workers, False,
                  args.rom, args.sram, key=lambda j: j["signature"])
    rungs = {r["signature"]: r["rungs"] for r in load_jsonl(out / f"{LK}_ladder.jsonl") if "_error" not in r}
    if cfg.get("kwhistles"):                                   # whistle feasibility: (whistle, cast) grid, no parity
        ws = [int(w) for w in str(cfg["kwhistles"]).split(",")]
        jobs = [{"signature": r["signature"], "state": r["state"], "whistles": [w], "cast": w + c, "hold_bites": 2,
                 "map_window": False, "rungs": rungs.get(r["signature"], []), **extra}
                for w in ws for c in range(a, b, st) for r in reps]
        run_stage(f"{K} casts", cast_job_rung, jobs, out / f"{K}_casts.jsonl", args.workers, False,
                  args.rom, args.sram, key=lambda j: (j["signature"], j["whistles"][0], j["cast"]))
        rows = [r for r in load_jsonl(out / f"{K}_casts.jsonl") if "_error" not in r]
        bad = sum(1 for r in rows if r.get("status") != "ok")
        for w in ws:
            rr = [r for r in rows if r.get("whistles") == [w] and r.get("status") == "ok"]
            n1 = sum(1 for r in rr if r["bites"] and r["bites"][0].get("nut"))
            n2 = sum(1 for r in rr if len(r["bites"]) > 1 and r["bites"][1].get("nut") and not r["bites"][0].get("nut"))
            print(f"whistle at {w / 60:5.1f} s: {len(rr)} casts, bite-1 Nut {n1}, hold-only Nut {n2}", flush=True)
        if bad:
            print(f"note: {bad} casts did not resolve ok", flush=True)
        return
    jobs = [{"signature": r["signature"], "state": r["state"], "whistles": [], "cast": c, "hold_bites": 2,
             "map_window": False, "rungs": rungs.get(r["signature"], []), **extra} for c in range(a, b, st) for r in reps]
    run_stage(f"{K} casts", cast_job_rung, jobs, out / f"{K}_casts.jsonl", args.workers, False,
              args.rom, args.sram, key=lambda j: (j["signature"], j["cast"]))
    bad = sum(1 for r in load_jsonl(out / f"{K}_casts.jsonl") if r.get("status") == "cast_failed")
    if bad:
        print(f"WARNING: {bad} casts did not start (farmer napping? check the wake schedule)", flush=True)
    wins = defaultdict(list)
    for r in load_jsonl(out / f"{K}_casts.jsonl"):
        if "_error" not in r and any(x.get("nut") for x in r.get("bites", [])):
            wins[r["signature"]].append(r["cast"])
    st_of = {r["signature"]: r["state"] for r in reps}
    jobs = []
    for sig, ws in wins.items():
        ws = sorted(ws)
        for w in sorted({ws[0], ws[len(ws) // 2], ws[-1]}):
            for c in (w - 1, w + 1):
                jobs.append({"signature": sig, "state": st_of[sig], "whistles": [], "cast": c, "hold_bites": 2,
                             "map_window": False, "rungs": rungs.get(sig, []), **extra})
    run_stage(f"{K} parity", cast_job_rung, jobs, out / f"{K}_parity.jsonl", args.workers, False,
              args.rom, args.sram, key=lambda j: (j["signature"], j["cast"]))
    n = sum(len(v) for v in wins.values())
    print(f"cast tables: {n} winning casts over {len(wins)} paths", flush=True)


def run_pulse_stages(out, cfg, args, scen):
    from campaign_jobs import ladder_job, whistle_job
    reps = pulse_reps(out, scen)
    print(f"pulse: {len(reps)} dog paths; reps {[r['signature'] for r in reps]}", flush=True)
    a, b, st = (int(x) for x in cfg["pulse"].split(":"))
    g0, g1, gs = (int(x) for x in cfg["pulse2_gap"].split(":"))
    firsts = [int(x) for x in cfg["pulse2_first"].split(",")]
    last = max(b, max(firsts) + g1)
    jobs = [{"signature": r["signature"], "state": r["state"], "horizon": last + 120, "rung_polls": RUNG_POLLS,
             "rung_until": last} for r in reps]
    run_stage("W ladder", ladder_job, jobs, out / "W_ladder.jsonl", args.workers, False,
              args.rom, args.sram, key=lambda j: j["signature"])
    rungs = {r["signature"]: r["rungs"] for r in load_jsonl(out / "W_ladder.jsonl") if "_error" not in r}
    jobs = [{"signature": r["signature"], "state": r["state"], "rungs": rungs.get(r["signature"], []),
             "presses": [p], "post_vi": int(cfg["pulse_post"])} for r in reps for p in range(a, b, st)]
    run_stage("W single press", whistle_job, jobs, out / "W_single.jsonl", args.workers, False,
              args.rom, args.sram, key=lambda j: (j["signature"], tuple(j["presses"])))
    jobs = [{"signature": r["signature"], "state": r["state"], "rungs": rungs.get(r["signature"], []),
             "presses": [f, f + gap], "post_vi": int(cfg["pulse2_post"])}
            for r in reps[:int(cfg["pulse2_lines"])] for f in firsts for gap in range(g0, g1, gs)]
    run_stage("W press pairs", whistle_job, jobs, out / "W_double.jsonl", args.workers, False,
              args.rom, args.sram, key=lambda j: (j["signature"], tuple(j["presses"])))


def lucky_pairs(out, cover):
    """(dog path representative, arrival offset) pairs by route weight until `cover` of all routes."""
    from tools.strategy_lab import Truth
    tr = Truth(out)
    lines = {L["signature"]: L for L in json.loads((out / "W_lines.json").read_text())}
    pw = defaultdict(float)
    for i in range(len(tr.sigs)):
        if tr.rep[i] is not None and tr.rep[i] in lines:
            pw[(tr.rep[i], int(tr.offset[i]))] += float(tr.w[i])
    tot = sum(pw.values()) or 1.0
    pairs, acc = [], 0.0
    for (rep, o), w in sorted(pw.items(), key=lambda x: (-x[1], x[0])):
        if acc / tot >= cover:
            break
        pairs.append({"signature": rep, "path": int(lines[rep]["line"]) - 1, "state": lines[rep]["state"],
                      "o": o, "w": w})
        acc += w
    return pairs, acc / tot, tot


def run_lucky(out, cfg, args):
    """Stage M: mash plans (hash pass) -> one cast per distinct game state on the cast grid -> LUCKY.md."""
    from lucky_jobs import in_grid, lucky_cast_job, mash_job
    env = lambda k: os.environ.get("HM64_" + k.upper()) or cfg[k]
    ks = [int(x) for x in str(env("lucky_k")).split(",")]
    periods = [int(x) for x in str(env("lucky_periods")).split(",")]
    grid = [[int(a), int(b)] for a, b in (seg.split(":") for seg in str(env("lucky_grid")).split(","))]
    until = grid[-1][1]
    wake = [int(w) for w in str(cfg.get("wake", "")).split(",") if w.strip()]
    pairs, cov, tot = lucky_pairs(out, float(env("lucky_cover")))
    if getattr(args, "cast_paths", 0):
        pairs = pairs[:args.cast_paths]
        cov = sum(pr["w"] for pr in pairs) / tot
    print(f"lucky: {len(pairs)} arrivals (path, offset) covering {cov:.1%} of {tot:.0f} routes; whistles {ks}, "
          f"mash periods {periods} polls, grid {grid}", flush=True)
    jobs = [{"path": pr["path"], "signature": pr["signature"], "state": pr["state"], "o": pr["o"], "w": pr["w"],
             "start": pr["o"] + ph, "period": P, "whistles": k, "until": until, "grid": grid, "wake": wake}
            for pr in pairs for k in ks for P in periods for ph in range(0, P, 2)]
    key = lambda j: (j["signature"], j["start"], j["period"], j["whistles"])
    run_stage("M mash", mash_job, jobs, out / "M_mash.jsonl", args.workers, False, args.rom, args.sram, key=key)
    want = {key(j) for j in jobs}
    rows = [r for r in load_jsonl(out / "M_mash.jsonl") if "_error" not in r and key(r["_job"]) in want]
    for r in rows:                                  # a coarser grid than recorded uses a subset of the recorded hashes
        r["hashes"] = [[p, h] for p, h in r["hashes"] if in_grid(p, grid)]
    done = set()                                    # states already cast (any earlier grid or scope) are not cast again
    for row in load_jsonl(out / "M_casts.jsonl"):
        if "_error" not in row and not row["tag"].endswith(":verify"):
            done.update((row["path"], c["cast"], c["hash"]) for c in row["casts"] if c.get("hash_ok") is not False)
    weight = {}
    for r in rows:
        j = r["_job"]
        weight[key(j)] = j["w"] / len(periods) / (j["period"] // 2)
    holders = defaultdict(list)                     # (path, poll, hash) -> mash plans that reach that state
    for r in rows:
        for p, h in r["hashes"]:
            holders[(r["path"], p, h)].append(r)
    order = lambda r: (r["whistles"], r["period"], r["start"])
    own, ver = defaultdict(list), defaultdict(list)
    wsum = defaultdict(float)
    for (path, p, h), rs in holders.items():
        if (path, p, h) in done:
            continue
        rs = sorted(rs, key=order)
        own[key(rs[0]["_job"])].append((p, h))
        wsum[key(rs[0]["_job"])] += sum(weight[key(r["_job"])] for r in rs)
        if len(rs) > 1 and int(h[:6], 16) % 1000 < float(cfg.get("lucky_verify", 0.01)) * 1000:
            ver[key(rs[-1]["_job"])].append((p, h))
    by_key = {key(r["_job"]): r for r in rows}
    chunks = []
    for tag, book in (("", own), (":verify", ver)):
        for kk, casts in book.items():
            r = by_key[kk]
            casts.sort()
            cur = []
            for c in casts:
                if cur and (c[0] - cur[0][0] > 240 or len(cur) >= 40):
                    chunks.append((r, cur, tag))
                    cur = []
                cur.append(c)
            if cur:
                chunks.append((r, cur, tag))
    cj = [{"path": r["path"], "signature": r["signature"], "state": r["_job"]["state"], "edges": r["edges"],
           "quiet_at": r["quiet_at"], "period": r["period"], "wake": wake, "casts": [list(c) for c in cs],
           "weight": wsum[key(r["_job"])],
           "tag": f"{r['signature']}:{r['start']}:{r['period']}:{r['whistles']}:{cs[0][0]}{tag}"} for r, cs, tag in chunks]
    cj.sort(key=lambda j: (j["tag"].endswith("verify"), -j["weight"], j["tag"]))
    n_states = sum(len(v) for v in own.values())
    n_plain = sum(len(r["hashes"]) for r in rows)
    print(f"lucky: {n_plain} plan x cast-time pairs -> {n_states} distinct game states still to cast "
          f"({len(done)} already cast; +{sum(len(v) for v in ver.values())} check casts) in {len(cj)} chunks", flush=True)
    run_stage("M casts", lucky_cast_job, cj, out / "M_casts.jsonl", args.workers, False, args.rom, args.sram,
              key=lambda j: j["tag"])
    from tools.lucky_report import run as lucky_run
    lucky_run(out, ks=ks, grid=grid, pairs={(pr["signature"], pr["o"]) for pr in pairs})


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--preset", choices=sorted(PRESETS), default="quick")
    ap.add_argument("--out", required=True)
    ap.add_argument("--workers", type=int)
    ap.add_argument("--stages", default=None,
                    help="A routes, L ladder, B natural casts, P parity, C whistle, D report, E oracle sim, "
                         "F Layer 1 link, O observation recording, I identification study "
                         "(default ALBPCDEF; preset observe: AOI)")
    ap.add_argument("--layer1", default=os.environ.get("HM64_LAYER1", "/layer1"),
                    help="Layer 1 output folder (layer1_spring9_full.sqlite and/or layer1_shards/); skipped if absent")
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--rom", default=default_rom())
    ap.add_argument("--sram", default=default_sram())
    for k in ("menu", "travel", "interaction", "horizon", "casts", "whistles", "wspan"):
        ap.add_argument(f"--{k}")
    ap.add_argument("--whistle-all", action="store_true")
    ap.add_argument("--max-scenarios", type=int, help="limit stages B/C to the N most common scenarios")
    ap.add_argument("--cast-paths", type=int, default=0, help="stage K: only the N most common dog paths (0 = all)")
    ap.add_argument("--extra-states", default="auto",
                    help="comma list of extra READY-like states to solve in B/C (e.g. states/qs2.st); "
                         "'auto' = states/qs2.st if present; 'none' to skip")
    args = ap.parse_args()
    cfg = dict(PRESETS[args.preset])
    if args.stages is None:
        args.stages = cfg.pop("stages", "ALBPCDEF")
    cfg.pop("stages", None)
    for k in ("menu", "travel", "interaction"):
        v = getattr(args, k)
        if v is not None:
            cfg[k] = v if v == "all" else int(v)
    for k in ("casts", "whistles", "wspan"):
        if getattr(args, k) is not None:
            cfg[k] = getattr(args, k)
    if args.horizon:
        cfg["horizon"] = int(args.horizon)
    if args.whistle_all:
        cfg["whistle_all"] = True
    out = Path(args.out)
    if not out.is_absolute():
        out = ROOT / out
    out.mkdir(parents=True, exist_ok=True)
    (out / "config.json").write_text(json.dumps({"preset": args.preset, **cfg, "seed": args.seed,
                                                 "max_scenarios": args.max_scenarios}, indent=1))
    from campaign_jobs import cast_job_rung, ladder_job, observe_job, route_job
    t0 = time.time()

    if "A" in args.stages:
        run_stage("A routes", route_job, route_jobs(cfg, args.seed), out / "A_routes.jsonl", args.workers,
                  True, args.rom, args.sram, key=lambda j: j["label"])
    scen = scenarios_from([r for r in load_jsonl(out / "A_routes.jsonl") if "_error" not in r])
    if args.max_scenarios:
        scen = scen[:args.max_scenarios]
    extra = []
    spec = args.extra_states
    if spec == "auto":
        spec = "states/qs2.st" if (ROOT / "states" / "qs2.st").exists() else "none"
    if spec != "none":
        for p in spec.split(","):
            extra.append({"signature": "extra:" + Path(p).stem, "state": p})
    print(f"scenarios: {len(scen)} from routes + {len(extra)} extra states", flush=True)
    scen_bc = scen + extra

    if "O" in args.stages and scen:
        jobs = [{"signature": s["signature"], "state": s["state"], "horizon": cfg.get("observe_vi", 3600)}
                for s in scen]
        run_stage("O observe", observe_job, jobs, out / "O_observe.jsonl", args.workers, False,
                  args.rom, args.sram, key=lambda j: j["signature"])

    if "L" in args.stages and scen_bc:
        last = max([int(cfg["casts"].split(":")[1])] +
                   [max(int(w) for w in cfg["whistles"].split(",")) + int(cfg["wspan"].split(":")[1])])
        jobs = [{"signature": s["signature"], "state": s["state"], "horizon": LADDER_HORIZON,
                 "rung_polls": RUNG_POLLS, "rung_until": last} for s in scen_bc]
        run_stage("L ladder", ladder_job, jobs, out / "L_ladder.jsonl", args.workers, False,
                  args.rom, args.sram, key=lambda j: j["signature"])
    rungs = {r["signature"]: r["rungs"] for r in load_jsonl(out / "L_ladder.jsonl") if "_error" not in r}

    if "B" in args.stages and scen:
        jobs = [{"signature": s["signature"], "state": s["state"], "whistles": [], "cast": c,
                 "rungs": rungs.get(s["signature"], [])}
                for c in rng_range(cfg["casts"]) for s in scen_bc]
        run_stage("B natural", cast_job_rung, jobs, out / "B_natural.jsonl", args.workers, False,
                  args.rom, args.sram, key=lambda j: (j["signature"], tuple(j["whistles"]), j["cast"]))

    if "P" in args.stages and scen:
        # which neighbouring poll shares a winning game frame (casts are swept every 2 polls)
        # casts are swept every 2 polls; a 30 Hz game frame spans 2 polls. Probe the odd
        # neighbours of the first and last winning cast to learn which poll pairs with which.
        wins_by = defaultdict(list)
        for r in load_jsonl(out / "B_natural.jsonl"):
            if "_error" not in r and r["nut_releases"] and r["cast"] > 0:
                wins_by[r["signature"]].append(r["cast"])
        st = {s["signature"]: s["state"] for s in scen_bc}
        jobs = [{"signature": sig, "state": st[sig], "whistles": [], "cast": c, "rungs": rungs.get(sig, []),
                 "parity_probe": True}
                for sig, ws in wins_by.items() if sig in st
                for w in sorted({min(ws), max(ws)}) for c in (w - 1, w + 1)]
        run_stage("P parity", cast_job_rung, jobs, out / "P_parity.jsonl", args.workers, False,
                  args.rom, args.sram, key=lambda j: (j["signature"], j["cast"]))

    if "C" in args.stages and scen:
        nat = defaultdict(bool)
        for r in load_jsonl(out / "B_natural.jsonl"):
            if "_error" not in r and (r["nut_releases"] or "nut" in r["probes"].values()):
                nat[r["signature"]] = True
        targets = scen_bc if cfg["whistle_all"] else [s for s in scen_bc if not nat[s["signature"]]]
        a, b, st = (int(x) for x in cfg["wspan"].split(":"))
        jobs = [{"signature": s["signature"], "state": s["state"], "whistles": [w], "cast": w + c,
                 "rungs": rungs.get(s["signature"], [])}
                for w in (int(x) for x in cfg["whistles"].split(",")) for c in range(a, b, st) for s in targets]
        run_stage("C whistle", cast_job_rung, jobs, out / "C_whistle.jsonl", args.workers, False,
                  args.rom, args.sram, key=lambda j: (j["signature"], tuple(j["whistles"]), j["cast"]))

    if "D" in args.stages:
        analyze(out, cfg, args)
    if "K" in args.stages:
        run_cast_tables(out, cfg, args, scen_bc)
    if "W" in args.stages:
        run_pulse_stages(out, cfg, args, scen_bc)
    if "M" in args.stages:
        run_lucky(out, cfg, args)
    if "Q" in args.stages:
        from tools.pulse_sim import run as pulse_run
        pulse_run(out)
    if "I" in args.stages:
        from tools.ident_sim import run as ident_run
        ident_run(out)
    if "E" in args.stages:
        from tools.oracle_sim import run as oracle_run
        from tools.oracle_timing import run as timing_run
        oracle_run(out)
        timing_run(out)
    if "F" in args.stages:
        from tools.layer1_link import run as l1_run
        l1_run(out, Path(args.layer1))
    print(f"campaign done in {(time.time() - t0) / 60:.1f} min -> {out}/REPORT.md", flush=True)


if __name__ == "__main__":
    main()
