# HM64 RNG Lab — instructions for Claude Code agents

You are working in Thomas's Harvest Moon 64 (USA) research container. The
long-term goal is an RTA tool for real N64 hardware: **watch what the dog is
doing on screen, infer the RNG state, then tell the runner how many times to
whistle (C-right) and when to cast / hold / release B so the catch rolls the
ocean Power Nut.** This container is the emulator research backend: agents
collect RNG + dog-state data, run controlled experiments, and turn results
into tables the oracle can use.

Current project state lives in `project_docs/` (mirrors of the claude.ai project docs: START_HERE,
LAB_STATUS, TECH_REFERENCE, MAC_RUNBOOK) - read those first.

Prior project history lives in `data/knowledge/` (read-only): Thomas's master
backup restored there (`ORIGINAL_UPLOADS/`, `LIBRARY/`, `RECOVERY_EXTRAS/`, plus
the PART_99 index files). Read before starting new work, newest first:

- `data/knowledge/MASTER_BACKUP_README.md` + `MISSING_DATA_RETRIEVAL_NOTES.md`:
  coverage limits (701 of 1,656 Library files recovered; the large Layer1/CAST
  SQLite databases are NOT included; CAST "Nut zero" rows are source-model
  outputs, not verified awards).
- `data/knowledge/LIBRARY/v27.7g.*` folders (Nov 10-11): whistle branch
  calibration, steering, repeated-whistle cadence, whistle timing classifier
  and Nut draw phase, native final whistle alignment, boot-seed source phase.
  Start with each folder's `README_START_HERE.md` / `FINDINGS_*.md` /
  `STATUS_*.md`.
- `data/knowledge/LIBRARY/START_NEXT_CHAT_CURRENT.md` and
  `LIBRARY/Project Migration Handoff v27.6v Raw Award Verified November 9 2026/00_START_HERE.md`.
- The roadmap / acceptance gates (`**/06_PRODUCTION_ROADMAP_AND_ACCEPTANCE_GATES.md`).
  Those gates still apply here.

Prior results came from other harnesses (BizHawk, the older Mupen runner, Ares).
Treat them by their own confidence labels, and where they matter, re-check them
in this lab. Example: an older note says bite = actionPhase 3, but this lab
sees 2 → 4 at VI granularity. Record any disagreement instead of silently
picking one.

## Ground rules

1. **Evidence hierarchy:** decomp source (`data/decomp/`) > deterministic emulator
   experiment in this lab > direct observation > community claims > folklore.
   Tag every claim you write down: `[DECOMP file:line]`, `[EMU results/...]`,
   `[OBS]`, `[CLAIM]`. Cite paths.
2. **`data/` is read-only and holds Thomas's originals** (ROM, SaveRAM, BizHawk
   states, decomp, notes). Never try to modify it. Derived files go in `states/`
   and `results/`.
3. **Run `make smoke` (or `/smoke`) first** in a new container and after touching
   `native/`, `m64h/` or `hm64/`. Do not trust results from a lab that fails it.
4. **Keep negative and failed results.** Every experiment run writes to
   `results/<YYYY-MM-DD>-<slug>/` with the exact command, the experiment file
   copy, raw output (JSONL/CSV), and a short README: hypothesis, method, result,
   what it does *not* show.
5. **Freeze predictions before looking at truth.** When testing a predictor,
   write the prediction file first, then run the ground-truth emulator job.
6. **Seed poking is for exploration only.** Final validation of any route or
   policy must use real controller input timing (poll schedules / menu delays),
   never `w32(RAND_SEED, …)`. Gate 4 in the roadmap says the same.
7. Never present branch counts as probabilities; never arm a "go" cue that has
   not been verified over every surviving candidate.

## Layout

```
m64h/      headless mupen64plus driver (ctypes): VI stepping, RAM, savestates, poll-exact input, pool
native/    two tiny C plugins: scripted input (+ poll schedule), per-VI video hook (null or real renderer)
hm64/      game knowledge: addresses.py (decomp-sourced RAM map), lcg.py, dog.py (exact AI model),
           observe.py (DogObserver), state.py (snapshots, control_regained)
tools/     boot.py, trace.py, seed_sweep.py, validate_dog_model.py, regress_qs2.py,
           convert_bizhawk_state.py, smoke_test.py
experiments/  one module per experiment (job(emu, j) [+ jobs()]); start from the examples
states/    savestates you create (anchors, converted BizHawk states)      [writable]
results/   experiment outputs                                             [writable]
data/      ROM, saves, BizHawk states, decomp, knowledge                  [READ-ONLY]
```

## Quick reference

```bash
make smoke                                   # health check, must be ALL PASSED
make qs2 && make regress                     # pier state from BizHawk + 8/8 Nut regression
make anchors                                 # load/control anchors for diary delays 0..10
make ready                                   # cold boot -> route -> dock READY baseline state
python3 tools/route_run.py --case 0,0,0,0,10,20,4,0 --save states/ready/x.st
python3 tools/seed_sweep.py experiments/arrival_pool.py --out results/x/pool.jsonl
HM64_CASTS=0:300:2 HM64_WHISTLES="none;10" python3 tools/seed_sweep.py experiments/ready_cast_sweep.py --out results/x/casts.jsonl
python3 tools/boot.py --delays 0,0,0,6 --out states/a6.st --load-out states/l6.st
python3 tools/trace.py --state states/l6.st --vis 3000 --out results/x/trace.csv \
        --inputs '[{"at":600,"press":["CR"]}]'
python3 tools/seed_sweep.py experiments/dog_observation.py --start 480 --count 200 --out results/x/obs.jsonl
python3 tools/seed_sweep.py experiments/qs2_whistle_cast_grid.py --out results/x/grid.jsonl
python3 tools/validate_dog_model.py results/x/trace.csv
xvfb-run -a python3 your_script.py           # only needed for mode="visual" (screenshots)
```

Harness in Python:

```python
from m64h import Emulator
from hm64 import addresses as A
with Emulator(rom, sram=save_path) as emu:          # mode="visual" for pixels (under xvfb-run)
    emu.load_state("states/qs2.st")                  # paused 1 VI after the saved instant
    emu.schedule_polls([(424, ["B"]), (1634, [])])   # call BEFORE load_state; poll 0 = first read after load
    emu.advance(60)                                  # run exactly 60 VIs
    emu.set_input("CR"); emu.advance(2); emu.release()
    seed = emu.u32(A.RAND_SEED); dog_state = emu.u8(A.DOG + 0x17)
    emu.save_state("states/x.st")                    # leaves you exactly 1 VI later
    emu.add_listener(fn)                             # fn(emu) after every VI, on the emu thread
```

Route (cold boot) jobs set `FRESH_BOOT = True` so each job gets a new
process booted from power-on. One `Emulator` per **process** (the core is a singleton). Parallelise with
`m64h.pool.run_jobs` / `tools/seed_sweep.py` (`--workers`, default CPUs-1).
Fast mode is ~800-1500 VI/s per worker natively; under Rosetta on the Mac
expect less — measure before planning a huge sweep.

## Verified facts (all reproduced in this lab unless noted)

| Fact | Evidence |
|---|---|
| RNG = libkmc LCG `s = s*1103515245 + 12345`; output `((s+1)>>16)&0x7FFF`; state `sRandNext` at **0x8013CDF0** | `[DECOMP lib/libkmc/src/rand.c]`, ROM disasm @0xEB810 |
| `getRandomNumberInRange(lo,hi)` = 2 rand() calls, first discarded; value `lo + (r*(hi-lo+1)>>15)` | `[DECOMP src/system/math.c]` → `hm64/lcg.py range_roll` |
| Boot seed 0; stream index of any seed is exact via `hm64.lcg.index` (QuickSave2 seed 0x705EE83C = 1716; 0x8FDA0F1F = 1219) | `[EMU smoke lcg]` matches BizHawk-era notes |
| Ambient consumption 1 rand() per 2 VIs (30 Hz logic) during intro and in-house idle | `[EMU boot trace]` |
| Dog AI = `updateDogActionState` Markov chain; `hm64/dog.py` reproduces **every** observed decision (217 idle + 103 whistle-trace + smoke run, 0 unexplained); the dog's rand() calls are always **first** in their VI | `[DECOMP src/game/animals.c:2679]` `[EMU tools/validate_dog_model.py]` |
| RAM `dogInfo.actionState` is the NEXT state; the animation on screen is the state just executed | `[DECOMP]` + `hm64/observe.py` |
| C-right = whistle → `handleWhistleForDog`: sets FOLLOWING, actionState=0, no RNG itself; changes later dog RNG use (following state 4 rolls (0,20) each decision) | `[DECOMP src/game/player.c:1148, animals.c:10488]` `[EMU]` |
| Diary load: dog entity initialises and makes its **first decision in the same VI the house map loads** (MAP_LOAD → house) | `[EMU loadseq]` |
| **Seed poke at the LOAD anchor ≡ a genuinely later diary press** (bit-identical RNG/dog/position over 3600 VIs, 5 delays). Poking at the control anchor is **NOT** equivalent (dog already rolled during fade-in) | `[EMU smoke poke]` |
| Load-anchor index rises 1 per 2 VIs of menu delay; different timings can reach the same seed at different VIs (diary+0 and +4 both 650 at control) | `[EMU make anchors]` |
| Controller polls: "poll N" = N-th read, 0-based from the instant a state finishes loading. QuickSave2(1) recorded outcomes reproduce **8/8** (win84/85/424/470, fish 40/82/86, no-catch 83) | `[EMU tools/regress_qs2.py]` |
| Fishing (actionHandler 22) phases seen: 1 cast, 2 waiting, 4 bite (2→4 at VI granularity), 6 reel, 7 catch; Nut = `acquiredPowerNutBits` (u32 @0x80215EB8) bit 4, held item 87; roll `!getRandomNumberInRange(0,50)` only when fishingSpotType==3 | `[DECOMP src/game/player.c:3849]` `[EMU]` |
| Whistling before the cast moves the bite (QuickSave2: k=0 → bite poll 1630, k=1 → 928) | `[EMU experiments/qs2_whistle_cast_grid.py]` |
| Route port reproduces the legacy v13 baseline at **all 9 stages** (cabin VI 1050 … fishing_ready VI 2668, RNG 0x37A2FD60 = draw 1312) and replays sampled measured-cohort routes with identical ready VI + draw index (37/37 first sample; see results/*route-replay*) | `[EMU tools/route_run.py --check-v13, experiments/route_replay_check.py]` |
| Fishing loop: phase 2 rolls `getRandomNumberInRange(0,400)` per update; bite 3→4→5 (~22 polls); release in 3..5 → catch + Nut roll; holding through → next bite. Once the cast is right the Nut release window is ~20 polls wide (QS2 cast 424: releases 1630–1649 all Nut; 1628–29 / 1650–51 fish) | `[DECOMP player.c:2647, 3749]` `[EMU hm64/fishing.py]` |
| The cast poll is the sharp variable: QS2 cast 84 → bite 1410, Nut window 1410–1429; cast 83 → bite 1430, all fish | `[EMU]` |
| Cold-boot baseline arrival (m00000000_h00c00_p00d00): casts +32 and +120 polls (stride-4 scan of 4..120) give a Nut with 20-poll release windows; the rest give fish | `[EMU /tmp castsweep, rerun with ready_cast_sweep]` |
| Legacy native corpus ran with mupen's default `RandomizeInterrupt=True`, seeded by `srand(time(NULL))` (r4300_core.c) - i.e. not strictly reproducible. This lab defaults it OFF; the sampled cohort still matched exactly, so the jitter rarely matters here, but keep it in mind for anomalies (e.g. P=25,D=28 no_farm) | `[DECOMP mupen core]` `[CLAIM v11 README]` |

Determinism traps that are already handled (do not undo): core option
`RandomizeInterrupt` is forced **off** (2.6 default is on); savestates are
captured synchronously but written by a worker thread, so `save_state` steps
exactly 1 VI then waits without emulating; the headless renderer raises the
RDP DP interrupt (HM64 hangs otherwise); screenshots are read on the emu
thread in the frame callback (GL context is thread-bound).

## The pipeline this lab exists for

Thomas's plan, in order. Every step has a tool here; agents extend them.

1. **Cold boot -> controlled route -> dock READY.** Power on, hard reset at
   legacy callback 120, menus, pick the dog up in the house, hold straight LEFT
   on the farm, crossroads script, DOWN+RIGHT on Green Ranch, carry the dog to
   the dock, put it down, face SE: `hm64/route.py`, `tools/route_run.py`,
   `make ready`. Route timing is 8 delays `(d0..d3, H, C, P, D)` with budgets
   menu<=30, H+C<=60, P+D<=60 (polls). Recipes and the 36,014 measured
   arrivals are in `data/routes/`.
2. **Pool of realistic arrival scenarios.** Run many recipes, save every ready
   state, and group them by their *natural future* (dog decisions + RNG with
   no input): `experiments/arrival_pool.py`. Same RNG at ready is NOT the same
   scenario - dog timer/phase differ; group by the natural signature.
3. **Per scenario: natural Nut plans.** For each ready state, which cast polls
   give a Nut, and for which release polls: `experiments/ready_cast_sweep.py`
   (uses `hm64/fishing.py`: every bite window, every release poll).
4. **Per scenario: whistle corrections ("intercept").** Where no natural cast
   is convenient (or to move a win earlier), C-right at poll w changes the
   dog's RNG use and therefore every later bite/roll: same sweep with
   `HM64_WHISTLES`. Goal: show every arrival scenario is solvable by some
   (whistle?, cast, release) and find the earliest/widest such plan.
5. **Observation model.** From READY, what does the dog visibly do (animation
   onsets + facing, `hm64.observe.DogObserver`), and how fast does that
   eliminate scenarios? Respect the ROM sprite ambiguity classes in
   `data/knowledge`. Output: decision trees / elimination tables.
6. **The player tool.** Thomas enters dog animations as he sees them on real
   hardware, nudges a time offset to sync, and gets histograms: whether/when to
   whistle, then when to cast, hold and release. The lab supplies the tables
   (scenario -> visible future -> plan + timing windows); the UI lineage is
   the v25/v27.5o/v27.7a observer in `data/knowledge/LIBRARY`.

Timing semantics to keep straight: polls (controller reads, ~1/VI) are what
inputs are scheduled in; VIs are 60 Hz frames; game logic runs at 30 Hz (2 VIs).
A plan for hardware must be expressed relative to something the player can
see (READY / a dog animation onset), never to absolute boot polls.

## Campaign runner

`tools/campaign.py --preset smoke|quick|oracle|standard|full --out results/<dir>`
runs the pipeline end to end and is resumable (rows already in the out folder
are skipped). Stages (`--stages`, default ALBPCDEF):
- A arrival pool: FRESH_BOOT route jobs; READY states de-duplicated by natural
  signature into `states/campaign/<sig>.st`.
- L ladder (`campaign_jobs.ladder_job`): per scenario, the natural path for
  1800 VIs (ROM sprite class + screen facing per VI, `polls_after` timing) and
  a savestate "rung" every 60 polls in `states/campaign/ladder/<sig>/`.
- B natural casts (`cast_job_rung`): start from the latest rung >= 2 polls
  before the first input; results identical to starting at READY (checked by
  `tools/check_ladder.py`, smoke check 10).
- P parity: casts at the odd neighbours of the first/last win, to learn which
  two polls form one 30 Hz game frame.
- C whistle rescue (scenarios with no natural Nut; `--whistle-all` for all).
- D analysis: `REPORT.md`, `scenarios.csv`, `natural_plans.csv`,
  `whistle_plans.csv`, `observation_elimination.csv`, `oracle_table.json`.
- E oracle simulation (`tools/oracle_sim.py`): a simulated player logs the
  dog's visible changes (gap tolerance g), candidates are eliminated, and a
  cast "D VIs after change k" is issued when it wins for every candidate
  (or for >= 50% of candidate routes). Writes `ORACLE.md`, `oracle_sim.csv`,
  `oracle_scenarios.json` (the compact table the player tool needs).
  Then `tools/oracle_timing.py` (E2): Nut chance when the B press lands
  N(0, sigma) VIs off target, the tool's histogram aimed at the best
  blurred target; baselines 1/51 and a blind press (`oracle_timing.json`).
  World lines: arrivals that are the same dog path entered at different
  times; their casts agree once aligned on the dog's changes (4,061 agreeing
  wins, 0 disagreements in the first oracle run).
- F Layer 1 link (`tools/layer1_link.py`, `--layer1 <dir>`): which Layer 1
  phase hypotheses equal the measured native path (`LAYER1.md`,
  `layer1_links.csv/json`). Layer 1 is opened read-only (`immutable=1`).
- Preset `observe` (stages A, O, I): up to 2 routes per Layer 1 anchor (all
  268) -> O (`campaign_jobs.observe_job`): 80 s after READY per arrival, what
  the runner sees per VI (facing + ROM sprite class) and the hidden state
  (absolute rand() draw index, dog actionState/direction/stateTimer) -> I
  (`tools/ident_sim.py`): simulated keyboard logging (start log AD, reaction
  10-25 VIs, short animations missed), strategies AD / D-turns / D-all /
  AD-every2, unanchored vs READY-anchored; how many logs until one dog path is
  left and how tightly the RNG position is pinned (`IDENT.md`).
- Preset `pulse` (stages W, Q; reuses the observe run's rows): one representative arrival per dog path
  (world line, from O data) -> W ladder -> `whistle_job` with one C-right press on every game frame
  2-30 s after READY (20 s recorded after it) and press pairs on the 10 most common paths ->
  `tools/pulse_sim.py`: classes of press frames with identical futures, response delays, follow
  durations, information per pulse for R1/D3/AD1-3/AD8s logging, random vs edge-cued presses,
  uncalibrated vs calibrated reaction, projection of repeated cued pulses (`PULSE.md`).
- Whistle mechanics [DECOMP player.c handleWhistleForDogAnimation, animals.c handleWhistleForDog,
  updateDog]: handleWhistleForDog runs when the player's whistle animation ends (41 VIs after the
  press, constant [EMU]); it sets FOLLOWING + actionState 0 but the dog only acts at its next
  animation-cycle end with stateTimer 0, so press frames between two such boundaries give identical
  futures (pilot on path 1: 27 classes in 200 frames, median 9 frames). Following ends on a 1-in-21
  roll per running cycle.
- Save sensitivity (decomp + emulator, 2026-11-12): the main loop calls rand()
  once per game frame on every screen; extra draws come from entity AI. The
  horse is loaded by MAP (horseInfo.location == current map), not distance; in
  Thomas's save it is on the farm (82) and its AI draws ~6 random numbers per
  crossing: removing it shifts READY by -6 draws, moving it can shift by -2.
`hm64.fishing.eval_cast` is the fast evaluator: hold B, stop at the first bite
(on the emulator thread via `emu.advance_until`), checkpoint, probe releases at
window+4/+12, and map every release poll only for winners. Only the FIRST bite
is evaluated; holding through to later bites is not explored yet. The
`run_hm64_campaign.sh` script at the repo root deploys the tarball and runs all
of this on Thomas's Mac (mounts Layer 1 read-only, reuses the richest earlier
run's rows and states).

## Subagents (in .claude/agents/)

- `decomp-analyst` — answers "what does the game do" from source, with file:line citations.
- `emu-experimenter` — writes and runs experiments with the harness; owns results/ hygiene.
- `rng-analyst` — turns JSONL/CSV into equivalence classes, tables, plots.
- `verifier` — independently re-checks a claimed result with real inputs and fresh runs.

For anything you'd call "confirmed", have `verifier` reproduce it without
seeing the producing agent's reasoning.
