/* headless (v29.6, two-step cuts v29.7): Lucky Timer multi-line route "nodog-zigzag-fast" (tools/zigzag_routes.py). Route switch, preset
   cards (1st cut row, then 2nd cut row for that 1st cut), anchors (dock end READY first, beach load), an attempt from one member variant (cast +
   bite tap: fits, most likely dog line), the per-route line check, the beach anchor, then back to the dog-carry route. */
(function () {
  setTimeout(() => {
    const A = window.HM64LuckyApp, C = window.HM64Lucky, $ = id => document.getElementById(id), out = { errors: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    try {
      ['hm64v29_lucky_taps', 'hm64v29_lucky_tally', 'hm64v29_lucky'].forEach(k => localStorage.removeItem(k));
      $('arLucky').click();
      A.L.audio = false; A.L.sigmaMs = 100; $('lkSigma').value = 100; $('lkSigma').onchange();
      out.routes = [...$('lkRoute').options].map(o => o.textContent);
      $('lkRoute').value = 'nodog-zigzag-fast'; $('lkRoute').onchange({ target: $('lkRoute') });
      out.sel = C.selection; out.anchors = [...$('lkAnchor').options].map(o => o.textContent);
      out.cards = [...document.querySelectorAll('#lkPace .lkcard')].map(c => c.textContent.replace(/\s+/g, ' ').trim());
      out.paceTxt = $('lkPaceTxt').textContent.slice(0, 260);
      out.plan = { T: $('lkT').textContent, P: $('lkP').textContent, txt: $('lkPlanTxt').textContent, how: $('lkHow').textContent.slice(0, 420) };
      document.querySelectorAll('#lkPace .lkcard')[1].click();            // 1st cut tight
      const cardTxt = () => [...document.querySelectorAll('#lkPace .lkcard')].map(c => (c.classList.contains('sel') ? '[x] ' : '') + c.textContent.replace(/\s+/g, ' ').trim());
      out.tight = { sel: C.selection, T: $('lkT').textContent, P: $('lkP').textContent, txt: $('lkPlanTxt').textContent,
                    cards: cardTxt(), paceTxt: $('lkPaceTxt').textContent.slice(0, 300) };
      document.querySelectorAll('#lkPace .lkcard')[5].click();            // 2nd cut early (after Any)
      out.cell = { sel: C.selection, T: $('lkT').textContent, P: $('lkP').textContent, txt: $('lkPlanTxt').textContent,
                   cards: cardTxt(), paceTxt: $('lkPaceTxt').textContent.slice(0, 300) };
      document.querySelectorAll('#lkPace .lkcard')[2].click();            // flip the 1st cut to mid: the 2nd cut stays early
      out.flip = { sel: C.selection, P: $('lkP').textContent, paceTxt: $('lkPaceTxt').textContent.slice(0, 200) };
      document.querySelectorAll('#lkPace .lkcard')[1].click();            // back to tight (+ early)
      document.querySelector('#lkPol button[data-pol="zone"]').click();
      const vims = 33.053 / 2, P0 = C.plans[0], T = A.run.T;
      const x = P0.variants.slice().sort((a, b) => b.w - a.w)[0], s = P0.series[x.s];
      let d = 0; while (s.n1[T + d + x.o - s.v0] < 0 && d < 40) d++;
      const i = T + d + x.o - s.v0, castT = T + d + 0.5, t1 = castT + s.b1[i];
      A.start(); A.run.wall0 = performance.now() - (castT - 1) * vims; A.registerCast(castT);
      A.run.wall0 = performance.now() - (t1 + 15 - 1) * vims; A.registerTap(t1 + 15);
      out.attempt = { truthLine: C.routeOf('nodog-zigzag-fast').sidxs.indexOf(x.s) + 1, truthNut1: s.n1[i], truthNut2: s.n2[i],
                      fit: A.run.tapInfo.fit, p1: +A.run.tapInfo.p1.toFixed(3), held: A.run.tapInfo.holdish };
      A.record(false, 'fish'); out.attempt.last = $('lkLast').textContent.slice(0, 300);
      out.tally = $('lkTally').textContent.slice(0, 300);
      $('lkAnchor').value = 'beach'; $('lkAnchor').onchange({ target: $('lkAnchor') });
      out.beach = { sel: C.selection, T: $('lkT').textContent, P: $('lkP').textContent, how: $('lkHow').textContent.slice(0, 200),
                    cards: cardTxt(), paceTxt: $('lkPaceTxt').textContent.slice(0, 300) };
      $('lkRoute').value = 'carry'; $('lkRoute').onchange({ target: $('lkRoute') });
      out.carry = { sel: C.selection, cards: document.querySelectorAll('#lkPace .lkcard').length, P: $('lkP').textContent };
      $('lkRoute').value = 'nodog-nohorse-no-pickup'; $('lkRoute').onchange({ target: $('lkRoute') });
      out.legacy = { sel: C.selection, P: $('lkP').textContent, paceHidden: $('lkPace').hidden };
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, 600);
})();
