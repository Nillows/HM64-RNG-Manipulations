/* headless (v29.9): tap data behind the auto precision - one set per route + tap strategy + beach cue (own
   localStorage key), the "Tap data" fold (rows, usual difference, far-off flag), cull / restore, clear one set,
   one-clock-tap strategies borrowing the spread, and the migration of the old shared list. Taps are placed in wall
   time from a known console first light F0 (exit tap = cue + 230 ms + extra, beach-cue tap = cue + 230 ms). */
(function () {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => {
    const A = window.HM64LuckyApp, $ = id => document.getElementById(id), out = { errors: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    window.confirm = () => true;
    try {
      $('arLucky').click();
      A.L.audio = false;
      $('lkRoute').value = 'lineup-dogbeach'; $('lkRoute').onchange({ target: $('lkRoute') });
      A.setStrategy('ebd'); A.setBeachCue('ctrl');
      const vi = 33.053 / 2, R_MS = 230;
      const x = A.plans[0].variants.slice().sort((a, b) => b.w - a.w)[0];
      const T = { exit: -70, fade: 0, ctrl: 66 };
      const seq = async (ids, exitExtra) => {                    // exitExtra: the exit tap this much later (ms)
        const F0 = performance.now() - 40000;
        const ws = ids.map(id => id === 'dock' ? F0 + (x.minT - 1) * vi + R_MS : F0 + T[id] * vi + R_MS + (id === 'exit' ? exitExtra || 0 : 0)).sort((a, b) => a - b);
        A.start(ws[0]);
        for (const w of ws.slice(1)) A.seqPress(w);
        await sleep(300);
        A.stop(true);
      };
      const rows = () => [...document.querySelectorAll('#lkTapDataTbl tr')].slice(1).map(tr => tr.textContent.replace(/\s+/g, ' ').trim());
      const prec = () => { const p = A.precision(); return { sd: Math.round(p.sd), src: p.src, n: p.n }; };
      /* 6 normal attempts (exit tap +40 ms vs the beach cue tap, +-15) and one fumble (+240, 3rd, while auto is still 60 ms) */
      const extras = [40, 55, 240, 25, 40, 50, 30];
      out.prec0 = prec();
      for (const e of extras) await seq(['exit', 'ctrl', 'dock'], e);
      await sleep(50);
      out.key = A.curTs();
      out.n = A.taprec.length;
      out.lsKeys = Object.keys(localStorage).filter(k => k.startsWith('hm64v29_lucky_tapset'));
      out.precAll = prec();
      out.summary = $('lkTapData') && $('lkTapData').querySelector('summary').textContent;
      out.rows = rows().slice(0, 3);
      out.flagged = rows().filter(r => r.includes('far off')).length;
      /* cull the fumble (3rd attempt = 5th row, newest first) with its button, then restore it */
      document.querySelector('#lkTapDataTbl button[data-tsi="2"]').click();
      out.precCulled = prec(); out.rowCulled = rows()[4]; out.summaryCulled = $('lkTapData').querySelector('summary').textContent;
      document.querySelector('#lkTapDataTbl button[data-tsi="2"]').click();
      out.precRestored = prec();
      out.flaggedRow = rows()[4]; A.cullRec(2, true); out.precFinal = prec();
      /* another strategy = another set */
      A.setStrategy('eb');
      out.eb0 = { key: A.curTs(), n: A.taprec.length, prec: prec() };
      await seq(['exit', 'ctrl'], 45); await seq(['exit', 'ctrl'], 35);
      out.eb1 = { n: A.taprec.length, prec: prec() };
      /* one clock tap: borrowed from the eb + ebd sets of this route + beach cue */
      A.setStrategy('bd');
      out.bd = { key: A.curTs(), prec: prec(), box: ($('lkTapData') || {}).textContent.replace(/\s+/g, ' ').slice(0, 400) };
      await seq(['ctrl', 'dock']);
      out.bdStored = A.taprec.length;
      /* the other beach cue = its own sets */
      A.setStrategy('ebd'); A.setBeachCue('fade');
      out.fade = { key: A.curTs(), n: A.taprec.length, prec: prec() };
      A.setBeachCue('ctrl');
      /* clear this set: ebd/ctrl goes, eb/ctrl stays */
      document.getElementById('lkTapSetClear').click();
      out.cleared = { n: A.taprec.length, keys: A.tsKeys().map(k => k.replace('hm64v29_lucky_tapset/', '')), ebLeft: A.tsGet('hm64v29_lucky_tapset/lineup-dogbeach/eb/ctrl').length };
      /* migration of the old shared list */
      localStorage.setItem('hm64v29_lucky_taprec', JSON.stringify([{ at: 1, route: 'lineup-lineup2', y: { exit: 20, ctrl: -20 } },
        { at: 2, route: 'lineup-lineup2', y: { exit: 10, fade: -10 } }, { at: 3, y: { exit: 5, ctrl: -5 } }]));
      localStorage.removeItem('hm64v29_lucky_tapset_v');
      A.migrateTapRec(); A.refresh();
      out.migrated = { old: localStorage.getItem('hm64v29_lucky_taprec'), l2ctrl: A.tsGet('hm64v29_lucky_tapset/lineup-lineup2/ebd/ctrl'),
                       l2fade: A.tsGet('hm64v29_lucky_tapset/lineup-lineup2/ebd/fade').length, db: A.tsGet('hm64v29_lucky_tapset/lineup-dogbeach/ebd/ctrl').length };
      /* forget all */
      document.getElementById('lkFade2Forget') ? document.getElementById('lkFade2Forget').click() : null;
      out.forgot = A.tsKeys();
      out.open = { before: A.L.tapDataOpen };
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, 600);
})();
