(function () {
  setTimeout(() => document.getElementById('practiceBtn').click(), 200);
  setTimeout(() => {
    const img = document.getElementById('tvImg'), App = window.HM64App;
    const out = { tv_has_sprite: !!(img.dataset.src && img.dataset.src.startsWith('data:image')), tv_txt: document.getElementById('tvTxt').textContent,
                  practice: App.st.practice && { k: App.st.practice.k, o: App.st.practice.o } };
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, 4000);
})();
