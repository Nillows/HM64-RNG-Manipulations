/* headless (v29.4): Thomas's plan. Fast pace, smart zones (release windows + bite-2 fallback). Cast tap; bite 1 before
   the first window -> held + tapped -> bite-2 forecast (DUD or Nut chance + moments); bite 2 tapped; outcome. */
(function () {
  setTimeout(() => {
    const A = window.HM64LuckyApp, C = window.HM64Lucky, $ = id => document.getElementById(id), out = { attempts: [] };
    ['hm64v29_lucky_taps', 'hm64v29_lucky_tally', 'hm64v29_lucky'].forEach(k => localStorage.removeItem(k));
    $('arLucky').click();
    A.L.audio = false; A.L.sigmaMs = 100; $('lkSigma').value = 100; $('lkSigma').onchange();
    A.setSelection('fast', 'dog');
    document.querySelector('#lkPol button[data-pol="zone"]').click();
    const vims = 33.053 / 2, P0 = C.plans[0], T = A.run.T, zones = A.run.zone.zones, inZ = t => zones.some(([a, b]) => t >= a && t < b);
    out.T = +((T - 1) * vims / 1000).toFixed(2); out.windows = zones.map(([a, b]) => [+((a - 1) * vims / 1000).toFixed(2), +((b - 1) * vims / 1000).toFixed(2)]);
    out.how = $('lkHow').textContent.match(/Keep B held[^]*?tap it too\./)?.[0];
    // pick attempts whose bite 1 is outside every window: one with a bite-2 Nut, one without
    const find = want2 => { for (const x of P0.variants.slice().sort((a, b) => b.w - a.w)) { const s = P0.series[x.s]; for (let d = -3; d <= 3; d++) { const i = T + d + x.o - s.v0; if (i >= 0 && i < s.len && s.n1[i] >= 0 && s.n2[i] === want2 && !inZ(T + d + s.b1[i])) return { s, i, d }; } } };
    for (const [sc, kind] of [[find(1), 'nut'], [find(0), 'fish']]) {
      A.start();
      const castT = T + sc.d + 0.5, t1 = castT + sc.s.b1[sc.i], t2 = castT + sc.s.b2[sc.i];
      A.run.wall0 = performance.now() - (castT - 1) * vims; A.registerCast(castT);
      A.run.wall0 = performance.now() - (t1 + 15 - 1) * vims; A.registerTap(t1 + 15);
      const ti = A.run.tapInfo;
      const r = { truth2: sc.s.n2[sc.i], bite1_s: +((t1 - 1) * vims / 1000).toFixed(2), bite2_s: +((t2 - 1) * vims / 1000).toFixed(2), held: ti.holdish, dud: ti.dud, pNut2: +ti.pNut.toFixed(3),
                  spans2: ti.spans2.map(([a, b]) => [+((a - 1) * vims / 1000).toFixed(2), +((b - 1) * vims / 1000).toFixed(2)]) };
      if (!ti.dud) { A.run.wall0 = performance.now() - (t2 + 15 - 1) * vims; document.dispatchEvent(new KeyboardEvent('keydown', { key: ' ' })); }
      r.tau2 = ti.tau2 != null; r.p2b = isNaN(ti.p2b) ? null : +ti.p2b.toFixed(3);
      A.record(kind === 'nut', kind);
      r.last = $('lkLast').textContent;
      out.attempts.push(r);
    }
    out.taps = A.taps.map(t => ({ c: t.c, tau: t.tau, tau2: t.tau2 }));
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, 600);
})();
