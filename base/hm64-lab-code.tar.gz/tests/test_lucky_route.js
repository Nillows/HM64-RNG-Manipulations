// node tests/test_lucky_route.js DATA.json [route] : an extra Lucky Timer route (v29.5, tools/route_tables.py).
// Best plans per policy and timing spread (READY start, seconds after READY at 60 Hz for comparison with the lab's
// own scan), and the line check: does a bite tap tell an attempt on this dog line from one on another line?
const fs = require('fs');
const C = require('../webapp/hm64_lucky_v29.js');
const D = JSON.parse(fs.readFileSync(process.argv[2]));
const rid = process.argv[3] || 'nodog-nohorse-no-pickup', vi = 33.053 / 2;
C.prepare(D, vi, { route: rid });
const R = C.routeOf(rid);
if (R.id !== rid) { console.log('no route', rid, 'in', process.argv[2]); process.exit(1); }
const s60 = (t, P) => ((t - 1 - P.r0) / 60).toFixed(2);
for (const a of R.anchors) {
  C.select({ route: rid, anchor: a.id });
  const P = C.plans[0];
  for (const ms of [100, 150, 250]) {
    const sig = ms / vi, b = C.best(P, sig, P.firstT + 29);
    console.log(`${rid} start=${a.id} ±${ms} ms: smart zones ${s60(b.zone.t, P)} s after READY → ${(100 * b.zone.p).toFixed(1)}% · ` +
      `release bite 1 ${s60(b.bite1.t, P)} s ${(100 * b.bite1.p).toFixed(1)}% · hold to bite 2 ${s60(b.hold.t, P)} s ${(100 * b.hold.p).toFixed(1)}%`);
  }
}
C.select({ route: rid, anchor: R.anchors[0].id });
const P = C.plans[0], x = P.variants[0], s = P.series[x.s], sig = 100 / vi, T = C.best(P, sig, P.firstT + 29).zone.t;
let seed = 11; const rnd = () => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);
const gauss = () => { let u = 0; while (!u) u = rnd(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(6.2832 * rnd()); };
const known = []; for (let i = 0; i < s.len; i++) if (s.n1[i] >= 0) known.push(i);
const castCfg = { sd: Math.hypot(2.4, 2.4), tapSd: 2.4 };
for (const useCast of [true, false]) {
  let onFit = 0, offFlag = 0; const n = 2000;
  for (let k = 0; k < n; k++) {
    const xs = T + gauss() * sig, i0 = Math.round(xs) + x.o - s.v0, i = s.n1[i0] >= 0 ? i0 : i0 + 1;
    const delta = gauss() * 2.4, c = xs + delta + gauss() * 2.4, lag = 15 + gauss() * 3;
    const j = known[Math.floor(rnd() * known.length)];       // another line, modelled as a bite delay unrelated to this cast
    const post = tau => C.tapPosterior(P, T, sig, 0, tau, 15, 5, null, useCast ? { c, ...castCfg } : null);
    if (post(xs + s.b1[i] + delta + lag).Z > 1e-4) onFit++;
    if (!(post(xs + s.b1[j] + delta + lag).Z > 1e-4)) offFlag++;
  }
  console.log(`line check (${useCast ? 'cast + bite tap' : 'bite tap only'}): on-line attempts accepted ${(100 * onFit / n).toFixed(1)}%, ` +
    `off-line attempts flagged ${(100 * offFlag / n).toFixed(1)}% (upper bound: a neighbouring line may share some bite delays)`);
}
