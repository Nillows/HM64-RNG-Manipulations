/* headless (v29.9, 2026-11-16 build 4): "Your timing" (L5) - one place, four rows (start taps, B press on CAST, bite
   taps, how much you vary), auto from all data (practice presses + real casts pooled), set by hand per row, one
   start-tap delay for every start, and auto-tune from cast-tap attempts only. */
(function () {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => {
    const A = window.HM64LuckyApp, C = window.HM64Lucky, $ = id => document.getElementById(id), out = { errors: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    try {
      $('arLucky').click(); A.L.audio = false;
      $('lkRoute').value = 'lineup-dogbeach'; $('lkRoute').onchange({ target: $('lkRoute') });
      A.setSelection('all', 'fadein');
      const vi = 33.053 / 2, rows = () => [...document.querySelectorAll('#lkTimingSum tr')].map(tr => tr.textContent.replace(/\s+/g, ' ').trim());
      out.empty = { corr: A.cueCorr(), sigma: A.sigmaMs(), rows: rows(), biasDisabled: $('lkBias').disabled, sigmaDisabled: $('lkSigma').disabled };
      /* practice presses: median +80, then real casts (cast tap) +120 */
      let seed = 5; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647, g = () => Math.sqrt(-2 * Math.log(rnd())) * Math.cos(2 * Math.PI * rnd());
      for (let i = 0; i < 12; i++) A.pracLog.push({ at: Date.now() + i, e: Math.round(80 + 40 * g()), m: A.L.pracLine ? 'line' : 'beeps', src: 't', v: 1 });
      A.refresh();
      out.practice = { corr: A.cueCorr(), sigma: A.sigmaMs(), eff: A.sigEffMs(), rows: rows(), biasDisabled: $('lkBias').disabled, sigmaDisabled: $('lkSigma').disabled, biasInput: $('lkBias').value };
      for (let i = 0; i < 8; i++) A.tally.push({ at: Date.now() + 100 + i, castErrMs: Math.round(120 + 30 * g()), v: 1, route: 'lineup-dogbeach', hit: false });
      A.refresh();
      out.pooled = { corr: A.cueCorr(), sigma: A.sigmaMs(), row: rows()[1] };
      /* old beep-era casts (no v tag) stay apart while sound is off */
      A.tally.push({ at: Date.now() + 200, castErrMs: 900, route: 'lineup-dogbeach', hit: false }); A.refresh();
      out.beepEraIgnored = A.cueCorr() === out.pooled.corr;
      /* auto-tune: the clock learns from cast-tap attempts only (bias0); without cast taps it stays put (was: bias) */
      A.L.autoTune = true;
      A.TEST.prof = { n: 10, nCast: 0, bias: 120 / vi, bias0: 0 };
      out.autoNoCast = { autoB_ms: Math.round(A.autoB() * vi), corr: A.cueCorr(), wasBefore_ms: 120, want: 0 };
      A.TEST.prof = { n: 10, nCast: 10, bias: 120 / vi, bias0: 30 / vi };
      out.autoCast = { autoB_ms: Math.round(A.autoB() * vi) };
      A.TEST.prof = null;
      /* set by hand: the correction keeps its last auto value as the start */
      $('lkBiasAuto').checked = false; $('lkBiasAuto').onchange({ target: $('lkBiasAuto') });
      out.manual = { corr: A.cueCorr(), biasDisabled: $('lkBias').disabled, row: rows()[1] };
      $('lkBias').value = -50; $('lkBias').onchange({ target: $('lkBias') });
      out.manual2 = { corr: A.cueCorr(), L: A.L.biasMs };
      $('lkBiasAuto').checked = true; $('lkBiasAuto').onchange({ target: $('lkBiasAuto') });
      out.backAuto = A.cueCorr();
      $('lkSigmaAuto').checked = false; $('lkSigmaAuto').onchange({ target: $('lkSigmaAuto') });
      out.sigmaManual = { sigma: A.sigmaMs(), disabled: $('lkSigma').disabled };
      $('lkSigmaAuto').checked = true; $('lkSigmaAuto').onchange({ target: $('lkSigmaAuto') });
      /* one start-tap delay for every start */
      $('lkStartDelay').value = 210; $('lkStartDelay').onchange({ target: $('lkStartDelay') });
      out.startFade = A.startDelay();
      A.setSelection(null, 'pier'); out.startPier = { delay: A.startDelay(), input: $('lkStartDelay').value, lbl: $('lkStartDelayLbl').textContent };
      A.setSelection(null, 'fadein');
      out.practiceApplyHidden = $('lkPracApply').hidden;
      out.note = ($('lkTimingSum').querySelector('div') || {}).textContent;
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, 600);
})();
