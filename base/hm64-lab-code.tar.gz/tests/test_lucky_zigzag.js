// node tests/test_lucky_zigzag.js DATA.json [route] : a multi-line Lucky Timer route (v29.6+, tools/zigzag_routes.py).
// Per start anchor and preset: best plan per policy (seconds after the start at 60 Hz, comparable with ZIGZAG.md),
// then simulated attempts on the whole pool (a member drawn by weight, Gaussian cast, the bite-1 tap): how often the
// tap's top dog line is the true one, and how often the tool's release/hold call is right.
const fs = require('fs');
const C = require('../webapp/hm64_lucky_v29.js');
const D = JSON.parse(fs.readFileSync(process.argv[2]));
const rid = process.argv[3] || 'nodog-zigzag-fast', vi = 33.053 / 2;
C.prepare(D, vi, { route: rid });
const R = C.routeOf(rid);
if (R.id !== rid || !R.groups) { console.log('no multi-line route', rid); process.exit(1); }
const s60 = (t, P) => ((t - 1 - P.r0) / 60).toFixed(2);
for (const a of R.anchors) {
  for (const g of R.groups) {
    C.select({ route: rid, anchor: a.id, pace: g.id });
    const P = C.plans[0];
    const row = [100, 150, 250].map(ms => {
      const b = C.best(P, ms / vi, P.firstT + 29);
      return `±${ms}: zones ${(100 * b.zone.p).toFixed(1)}% @${s60(b.zone.t, P)} · b1 ${(100 * b.bite1.p).toFixed(1)}% @${s60(b.bite1.t, P)} · b2 ${(100 * b.hold.p).toFixed(1)}% @${s60(b.hold.t, P)}`;
    });
    console.log(`${a.id.padEnd(5)} ${g.id.padEnd(11)} share ${(100 * g.share).toFixed(0).padStart(3)}% vars ${String(P.variants.length).padStart(3)} | ${row.join(' | ')}`);
  }
}
// simulated attempts, pier anchor, whole pool
C.select({ route: rid, anchor: R.anchors[0].id, pace: 'all' });
const P = C.plans[0], sig = 100 / vi, T = C.best(P, sig, P.firstT + 29).zone.t;
let seed = 5; const rnd = () => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);
const gauss = () => { let u = 0; while (!u) u = rnd(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(6.2832 * rnd()); };
const W = P.variants.reduce((a, x) => a + x.w, 0);
const pick = () => { let r = rnd() * W; for (const x of P.variants) { r -= x.w; if (r <= 0) return x; } return P.variants[0]; };
let n = 0, ok = 0, top = 0, nut = 0, calls = 0, right = 0;
for (let k = 0; k < 3000; k++) {
  const x = pick(), s = P.series[x.s], xs = T + gauss() * sig, i0 = Math.round(xs) + x.o - s.v0;
  const i = s.n1[i0] >= 0 ? i0 : s.n1[i0 + 1] >= 0 ? i0 + 1 : -1;
  if (i < 0) continue;
  n++;
  const lag = 15 + gauss() * 3, tau = xs + s.b1[i] + lag;
  const post = C.tapPosterior(P, T, sig, 0, tau, 15, 5, null, null);
  if (!(post.Z > 1e-6)) continue;
  ok++;
  const sum = C.tapSummary(post, tau);
  if (sum && sum.path === x.s) top++;
  const truth = s.n1[i] === 1 ? 'b1' : s.n2[i] === 1 ? 'b2' : 'none';
  if (truth !== 'none') nut++;
  if (post.pNut !== undefined && truth !== 'none') { calls++; if ((post.p1 >= 0.5) === (truth === 'b1')) right++; }
}
console.log(`pool, pier start, aim ${s60(T, P)} s ±100 ms: ${n} attempts with data, bite tap fits the pool ${(100 * ok / n).toFixed(1)}%, ` +
  `top dog line right ${(100 * top / ok).toFixed(1)}%, Nut available on bite 1 or 2 ${(100 * nut / n).toFixed(1)}%, ` +
  `release/hold call right on those ${(100 * right / Math.max(1, calls)).toFixed(1)}%`);
