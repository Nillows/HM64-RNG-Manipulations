/* headless (v29.9): route lineup-dogbeach-sparrow-door (dog-beach, door-sparrow mornings) - presets, starts, tap strategy box, one sequence */
(function () {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => {
    const A = window.HM64LuckyApp, C = window.HM64Lucky, $ = id => document.getElementById(id), out = { errors: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    try {
      localStorage.clear();
      $('arLucky').click(); A.L.audio = false;
      $('lkRoute').value = 'lineup-dogbeach'; $('lkRoute').onchange({ target: $('lkRoute') }); A.setSparrows(true);
      out.sel = C.selection; out.T = $('lkT').textContent; out.P = $('lkP').textContent; out.box = !$('lkTapBox').hidden;
      out.cards = [...document.querySelectorAll('#lkPace .lkcard')].map(c => c.textContent.replace(/\s+/g, ' ').trim()).slice(0, 4);
      out.howto = ($('lkHow') && $('lkHow').textContent.slice(0, 160)); out.routes = [...$('lkRoute').options].map(o => o.textContent);
      out.anchors = [...$('lkAnchor').options].map(o => o.textContent);
      const vi = 33.053 / 2, F0 = performance.now() - 40000, x = A.plans[0].variants.slice().sort((a, b) => b.w - a.w)[0];
      A.start(F0 - 70 * vi + 230); A.seqPress(F0 + 66 * vi + 230); A.seqPress(F0 + (x.minT - 1) * vi + 230);
      await sleep(2500);
      out.g = { cues: Object.keys(A.run.gp.cue), bands: (A.run.gp.g3 && A.run.gp.g3.bands || []).map(b => b.label + ' ' + Math.round(100 * b.p)) };
      A.stop(true);
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, 600);
})();
