/* headless check of the right-click name:key editor and group buttons */
(function () {
  const out = {}, $ = id => document.getElementById(id), App = window.HM64App;
  const rc = el => el.dispatchEvent(new MouseEvent('contextmenu', { bubbles: true, cancelable: true, clientX: 100, clientY: 100 }));
  const enter = () => $('kvInput').dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
  setTimeout(() => {
    rc(document.querySelector('[data-base="96"]'));
    out.popup_text = $('kvInput').value;                                   // expect "sniff-sitting:8"
    $('kvInput').value = 'sniffy:j'; enter();
    out.tile_after = document.querySelector('[data-base="96"]').textContent;
    out.stored_key = JSON.parse(localStorage.getItem('hm64v28_keys'))['96'];
    out.stored_name = JSON.parse(localStorage.getItem('hm64v28_names'))['96'];
    rc(document.querySelector('[data-base="0"]')); $('kvInput').value = 'Idle:j'; enter();   // steal j
    out.key_moved = { idle: JSON.parse(localStorage.getItem('hm64v28_keys'))['0'], sniffy: JSON.parse(localStorage.getItem('hm64v28_keys'))['96'] };
    rc(document.querySelector('[data-base="0"]')); $('kvInput').value = 'Idle:['; enter();
    out.reserved_error = $('kvErr').textContent;
    document.querySelector('[data-add]').click(); $('kvInput').value = 'sitsquat:k=sit+squat'; enter();
    out.groups = App.groups.map(g => [g.name, g.key, g.bases]);
    rc(document.querySelector('[data-group="0"]')); out.group_popup = $('kvInput').value; $('kvInput').value = 'shoulder:u=shoulder-sitting+shoulder-standing'; enter();
    out.groups2 = App.groups.map(g => [g.name, g.key, g.bases]);
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'u', bubbles: true }));
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'k', bubbles: true }));
    out.logs = App.st.logs.map(l => [l.base, l.bases, l.group]);
    out.logtext = document.getElementById('log').textContent.slice(0, 120);
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, 300);
})();
