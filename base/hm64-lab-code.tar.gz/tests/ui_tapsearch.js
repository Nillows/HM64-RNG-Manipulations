/* headless: (1) move the tap key to Space in Settings, (2) a scripted runner on a hidden lab dog uses only taps
   (Space) for `obs` s: one tap at READY, then every visible change ~13 VI late; reports identification + clock. */
(function () {
  const Core = window.HM64Core, App = window.HM64App, D = Core.data, $ = id => document.getElementById(id);
  const q = new URLSearchParams(location.search), ai = +(q.get('arrival') || 0), obsS = +(q.get('obs') || 20), facing = q.get('facing') === '1';
  const out = {};
  // (1) key capture
  $('settingsBtn').click(); $('capTap').click();
  $('settingsDlg').dispatchEvent(new KeyboardEvent('keydown', { key: ' ', bubbles: true }));
  out.tapKey = JSON.stringify(App.st && window.HM64Core.settings.tapKey); out.faceKey = JSON.stringify(window.HM64Core.settings.faceKey);
  if (facing) $('s_tapFacing').checked = true;
  $('settingsDlg').close();
  out.keysHelp = $('keysHelp').textContent.slice(0, 90);
  // (2) tap-only runner
  const [k, o, , head] = D.arrivals[ai];
  const vi = Core.viMs(), t0 = performance.now() + 300;
  const show = t => Core.showAt(k, t + o, head && head.length ? ai : -1);
  const vals = []; for (let t = 1; t <= obsS * 60 + 60; t++) vals.push(show(t));
  const events = [{ t: 18, dir: vals[17].dir }];
  for (let t = 20; t < obsS * 60; t++) {
    if (vals[t - 1].val === vals[t - 2].val || vals[t - 1].val < 0) continue;
    let L = 1; while (t - 1 + L < vals.length && vals[t - 1 + L].val === vals[t - 1].val) L++;
    if (L >= 12) events.push({ t: t + 13, dir: vals[t - 1].dir });
  }
  const press = () => document.dispatchEvent(new KeyboardEvent('keydown', { key: ' ', bubbles: true }));
  events.forEach(ev => setTimeout(() => { App.setFacing(ev.dir); press(); }, t0 + ev.t * vi - performance.now()));
  const tEnd = events[events.length - 1].t + 20;
  setTimeout(() => {
    const g = App.st.groups[0], truthNow = (performance.now() - t0) / vi + o;
    Object.assign(out, { arrival: ai, path: k, taps: App.st.logs.filter(l => l.kind === 'T').length, kinds: [...new Set(App.st.logs.map(l => l.kind))],
      top_path: g.k, top_mass: +g.mass.toFixed(4), auto: App.st.auto, n_groups: App.st.groups.length,
      clock_err_vi: +(g.mean + (performance.now() - App.st.wall0) / vi - truthNow).toFixed(2), histEnabled: !$('histBtn').disabled });
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, t0 + tEnd * vi - performance.now());
})();
