/* headless (v29.8): Lucky Timer cast practice. Quick reps with known press offsets (vs the cue), a miss, a far-too-early
   press (ignored), a real keydown, the profile text + Apply (beep correction = -median, spread = hypot(SD, 60) rounded to
   10), the beeps-only mode (separate profile), full-wait mode (start press, then the cast of the whole plan), Esc, and a
   normal attempt afterwards (practice leaves the attempt log alone). */
(function () {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => {
    const A = window.HM64LuckyApp, C = window.HM64Lucky, $ = id => document.getElementById(id), out = { errors: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    const until = async (f, ms = 15000) => { const t0 = performance.now(); while (!f() && performance.now() - t0 < ms) await sleep(25); return f(); };
    try {
      ['hm64v29_lucky_taps', 'hm64v29_lucky_tally', 'hm64v29_lucky', 'hm64v29_lucky_castprac', 'hm64v29_lucky_prac'].forEach(k => localStorage.removeItem(k));
      $('arLucky').click();
      A.L.audio = false;
      $('lkRoute').value = 'nodog-zigzag-fast'; $('lkRoute').onchange({ target: $('lkRoute') });
      out.panel = { btn: $('lkPractice').textContent, line: $('lkPracLine').checked, full: $('lkPracFull').checked, txt: $('lkPracTxt').textContent.slice(0, 120) };
      const tally0 = localStorage.getItem('hm64v29_lucky_tally');
      $('lkPractice').click();
      out.started = { state: A.run.practice && A.run.practice.state, btn: $('lkPractice').textContent, startBtn: $('lkStart').textContent };
      const offs = [32, 18, 25, 41, 12, 29, 22, 35, -5, 27];
      const seen = [];
      for (let i = 0; i < offs.length + 2; i++) {
        if (!(await until(() => A.run.practice && A.run.practice.state === 'armed'))) { out.errors.push('never armed at rep ' + i); break; }
        const p = A.run.practice;
        if (i === 0) { out.armed = { msg: A.practiceMsg(A.run.T - 60), msgLate: A.practiceMsg(A.run.T - 30), cueIn: Math.round(p.cue - performance.now()), T: A.run.T, clock: $('lkClock').textContent }; }
        if (i === 3) { A.practiceInput(p.cue - 900, 'test'); out.early = { state: p.state, msg: A.practiceMsg(A.run.T - 100) }; }
        if (i === offs.length) { await until(() => p.state === 'done', 8000); out.miss = { last: p.last, msg: A.practiceMsg(0) }; continue; }
        if (i === offs.length + 1) {                                   // a real key press (event time), as the player would
          await until(() => performance.now() > p.cue - 100, 8000);
          document.dispatchEvent(new KeyboardEvent('keydown', { key: ' ', bubbles: true }));
          out.key = { last: p.last && { e: p.last.e, src: p.last.src, m: p.last.m }, state: p.state };
          continue;
        }
        A.practiceInput(p.cue + offs[i], 'test');
        seen.push(p.last.e);
        if (i === 1) { await sleep(50); out.done = { msg: A.practiceMsg(A.run.T + 10), timeline: !!document.getElementById('lkTimeline') }; }
      }
      out.seen = seen;
      const s = A.castStats(A.pracLog.filter(r => r.m === 'line' && Number.isFinite(r.e) && r.src === 'test').map(r => r.e));
      out.stats = { n: s.n, med: s.med, sd: +s.sd.toFixed(1), out: s.out };
      A.refresh();
      out.txt = $('lkPracTxt').textContent.slice(0, 700);
      const before = { bias: A.L.biasMs, sig: A.L.sigmaMs };
      $('lkPracApply').click();
      out.apply = { before, bias: A.L.biasMs, sig: A.L.sigmaMs, biasInput: $('lkBias').value, sigInput: $('lkSigma').value };
      $('lkPracLine').click();                                         // beeps only: its own (empty) profile
      out.beeps = { line: A.L.pracLine, txt: $('lkPracTxt').textContent.slice(0, 120) };
      await until(() => A.run.practice && A.run.practice.state === 'armed');
      out.beepsArmed = { msg: A.practiceMsg(A.run.T - 60) };
      A.practiceInput(A.run.practice.cue + 15, 'test');
      out.beepsAfter = { m: A.run.practice.last.m, e: A.run.practice.last.e };
      $('lkPracLine').click();
      $('lkPracFull').click();                                         // full wait: restarts in idle, start press, then the whole plan
      out.fullIdle = { state: A.run.practice.state, msg: A.practiceMsg(0) };
      const t0 = performance.now();
      A.practiceInput(t0, 'test');
      const p = A.run.practice;
      out.fullArmed = { state: p.state, cueAfterStartMs: Math.round(p.cue - t0), planCastMs: Math.round((A.run.T - 1) * 33.053 / 2) };
      A.practiceInput(p.cue - 12, 'test');
      out.fullPress = { e: p.last.e, state: p.state };
      $('lkPracFull').click();
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
      out.stopped = { practice: A.run.practice, btn: $('lkPractice').textContent, startBtn: $('lkStart').textContent };
      out.tallyUntouched = localStorage.getItem('hm64v29_lucky_tally') === tally0;
      A.start(); out.attemptStarts = A.run.wall0 !== null; A.stop(true);
      out.logSize = A.pracLog.length;
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, 600);
})();
