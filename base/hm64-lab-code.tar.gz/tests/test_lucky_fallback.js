// node tests/test_lucky_fallback.js DATA.json [pace] : Thomas's plan (v29.4). Release bite 1 if it comes inside a
// release window; if it comes before it or the window passes, hold, tap the bite, and the tool forecasts bite 2 (Nut
// chance, when, DUD -> reset). Simulated runners with a cast tap; truth from the cast tables.
const fs = require('fs');
const LC = require('../webapp/hm64_lucky_v29.js');
const D = JSON.parse(fs.readFileSync(process.argv[2]));
const pace = process.argv[3] || 'fast', vi = 33.053 / 2;
LC.prepare(D, vi, { pace, anchor: 'dog' });
const P = LC.plans[0], sig = 100 / vi, castCfg = { sd: Math.hypot(2.4, 2.4), tapSd: 2.4 };
let seed = 5; const rnd = () => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);
const gauss = () => { let u = 0; while (!u) u = rnd(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(6.2832 * rnd()); };
const W = P.variants.reduce((a, x) => a + x.w, 0);
const pick = () => { let r = rnd() * W; for (const x of P.variants) { r -= x.w; if (r <= 0) return x; } return P.variants[0]; };
const s2 = t => ((t - 1) * vi / 1000).toFixed(2);
const b = LC.best(P, sig, 46);
for (const [name, T] of [['cast at the 1st-bite optimum', b.bite1.t], ['cast at the smart-zone optimum', b.zone.t]]) {
  const z = LC.zoneAt(P, T, sig, sig, true), inZ = t => z.zones.some(([a, c]) => t >= a && t < c);
  let n = 0, nut1 = 0, nut2 = 0, held = 0, dud = 0, dudLost = 0, nut2Held = 0, inWin = 0, saved = 0, pOnNut = 0, pOnFish = 0, fishHeld = 0;
  for (let a = 0; a < 4000; a++) {
    const x = pick(), s = P.series[x.s], xs = T + gauss() * sig, i = Math.round(xs) + x.o - s.v0;
    if (i < 0 || i >= s.len || s.n1[i] < 0 || s.n2[i] < 0 || Math.round(xs) < x.minT) continue;
    n++;
    const delta = gauss() * 2.4, c = xs + delta + gauss() * 2.4, t1 = xs + s.b1[i] + delta, t2 = xs + s.b2[i] + delta;
    if (inZ(t1 + gauss() * 3)) { nut1 += s.n1[i]; continue; }                  // inside a window: release bite 1
    held++;
    const tau = t1 + 15 + gauss() * 3;                                           // hold through it, tap it
    const r = LC.tapPosterior(P, T, sig, 0, tau, 15, 5, null, { c, ...castCfg });
    const p2 = r.Z > 1e-4 ? r.pNut : 0.02;
    if (s.n2[i]) { nut2Held++; pOnNut += p2; } else { fishHeld++; pOnFish += p2; }
    if (p2 < 0.01) { dud++; if (s.n2[i]) dudLost++; else saved += (t2 - tau) * vi / 1000; continue; }
    nut2 += s.n2[i];
    if (s.n2[i]) {
      const spans = LC.nutSpans(r.sc.filter(e => e.n2).map(e => [e.t2, e.w]), 0.25, 30);
      if (spans.some(([a, e]) => t2 >= a - 6 && t2 < e + 6)) inWin++;
    }
  }
  console.log(`${pace}, ${name} ${s2(T)} s; release windows ${z.zones.map(([a, e]) => s2(a) + '–' + s2(e)).join(', ')} (model ${(100 * z.value).toFixed(1)}%)`);
  console.log(`  Nut ${(100 * (nut1 + nut2) / n).toFixed(1)}% per attempt (bite 1 ${(100 * nut1 / n).toFixed(1)}%, bite 2 ${(100 * nut2 / n).toFixed(1)}%) · held bite 1 in ${(100 * held / n).toFixed(0)}%`);
  console.log(`  after the bite-1 tap: shown bite-2 Nut chance ${(100 * pOnNut / Math.max(1, nut2Held)).toFixed(0)}% on true Nuts vs ${(100 * pOnFish / Math.max(1, fishHeld)).toFixed(1)}% on fish; ` +
    `DUD (reset now) on ${(100 * dud / Math.max(1, held)).toFixed(0)}% of holds, Nuts lost to it ${dudLost}/${nut2Held}, ~${(saved / Math.max(1, dud - dudLost)).toFixed(1)} s saved each; ` +
    `bite-2 Nuts inside the forecast window ${inWin}/${nut2}`);
}
