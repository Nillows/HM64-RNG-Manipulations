// node tests/test_webapp_core.js DATA.json CASES.json  -> identification + clock error per strategy
const fs = require('fs');
const Core = require('../webapp/hm64_core_v28.js');
const D = JSON.parse(fs.readFileSync(process.argv[2]));
const cases = JSON.parse(fs.readFileSync(process.argv[3]));
const settings = JSON.parse(process.argv[4] || '{}');
Core.prepare(D, settings);
const res = {};
let t0 = Date.now();
for (const cs of cases) {
  const L = cs.logs, t1 = L[0].t;
  const logs = L.map((l, n) => ({ kind: l.kind, value: l.value, dir: l.dir, base: l.base, dVI: l.t - t1, first: n === 0 }));
  Core.recompute(logs);
  const g = Core.groups();
  const top = g[0];
  const last = logs[logs.length - 1].dVI;
  const truthNow = L[L.length - 1].t + cs.offset;
  const r = res[cs.strategy] = res[cs.strategy] || { n: 0, right: 0, conv: 0, convWrong: 0, err: [], massTrue: 0, n_logs: 0 };
  r.n++; r.n_logs += logs.length;
  const right = top && top.k === cs.path;
  if (right) { r.right++; r.err.push(top.mean + last - truthNow); }
  if (top && top.mass >= 0.95) { r.conv++; if (!right) r.convWrong++; }
  r.massTrue += g.filter(x => x.k === cs.path).reduce((a, x) => a + x.mass, 0);
}
for (const [s, r] of Object.entries(res)) {
  const e = r.err, rms = Math.sqrt(e.reduce((a, x) => a + x * x, 0) / e.length);
  const bias = e.reduce((a, x) => a + x, 0) / e.length;
  const w1 = e.filter(x => Math.abs(x) <= 1).length / e.length, w2 = e.filter(x => Math.abs(x) <= 2).length / e.length;
  console.log(`${s.padEnd(34)} n=${r.n} logs/run=${(r.n_logs / r.n).toFixed(1)} top path right ${(100 * r.right / r.n).toFixed(1)}%  ` +
    `converged(>=95%) ${(100 * r.conv / r.n).toFixed(1)}% (wrong ${r.convWrong})  mass on truth ${(100 * r.massTrue / r.n).toFixed(1)}%  ` +
    `clock RMS ${rms.toFixed(2)} VI bias ${bias.toFixed(2)} within1 ${(100 * w1).toFixed(0)}% within2 ${(100 * w2).toFixed(0)}%`);
}
console.log('ms per case', ((Date.now() - t0) / cases.length).toFixed(1), 'candidates', Core.cands.n);

// end to end: identification -> histogram -> aimed press (1 VI press noise) -> true outcome on the true path
function randn() { let u = 0, v = 0; while (!u) u = Math.random(); while (!v) v = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); }
const e2e = {};
for (const cs of cases) {
  const L = cs.logs, t1 = L[0].t;
  const logs = L.map((l, n) => ({ kind: l.kind, value: l.value, dir: l.dir, base: l.base, dVI: l.t - t1, first: n === 0 }));
  Core.recompute(logs);
  const g = Core.groups();
  const decide = logs[logs.length - 1].dVI + 30;                  // half a second after the last log
  const gs = (g[0].mass >= 0.95 ? [g[0]] : g).map(x => ({ k: x.k, mass: x.mass, nowVI: x.mean + decide, sd: x.sd }));
  const bins = Core.histogram(gs, { hold: false });
  const tg = Core.pickTargets(bins, 1)[0];
  const r = e2e[cs.strategy] = e2e[cs.strategy] || { n: 0, planned: 0, nut: 0, fish: 0, unk: 0, pred: 0 };
  r.n++;
  if (!tg) continue;
  r.planned++; r.pred += tg.p;
  const truthDecide = L[L.length - 1].t + cs.offset + 30;
  const v = Math.floor(truthDecide + tg.dVI + randn() * Core.settings.pressSdVI);
  const c = Core.castAt(cs.path, v);
  if (!c) r.unk++; else if (c.n1) r.nut++; else r.fish++;
}
for (const [s, r] of Object.entries(e2e))
  console.log(`E2E ${s.padEnd(34)} plan found ${r.planned}/${r.n}  predicted P(Nut) ${(100 * r.pred / r.planned).toFixed(1)}%  ` +
    `actual Nut ${(100 * r.nut / r.planned).toFixed(1)}%  fish ${r.fish}  outside table ${r.unk}`);
