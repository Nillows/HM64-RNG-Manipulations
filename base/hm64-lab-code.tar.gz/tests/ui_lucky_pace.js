/* headless: pace presets + dog-landing start + bite tap in every policy (v29.2). */
(function () {
  setTimeout(() => {
    const A = window.HM64LuckyApp, C = window.HM64Lucky, $ = id => document.getElementById(id), out = {};
    ['hm64v29_lucky_taps', 'hm64v29_lucky_tally', 'hm64v29_lucky'].forEach(k => localStorage.removeItem(k));
    $('arLucky').click();
    A.L.audio = false;
    const vims = 1000 / 60.0988, sec = t => +((t - 1) * vims / 1000).toFixed(2);
    out.anchor0 = C.selection; out.startBtn = $('lkStart').textContent;
    out.cards = [...document.querySelectorAll('#lkPace .lkcard')].map(e => e.textContent.replace(/\s+/g, ' ').trim());
    // Thomas: fast, clean execution
    A.L.sigmaMs = 100; $('lkSigma').value = 100; $('lkSigma').onchange();
    document.querySelectorAll('#lkPace .lkcard')[1].click();
    out.fast = { sel: C.selection, T: $('lkT').textContent, P: $('lkP').textContent, plan: $('lkPlanTxt').textContent,
                 pace: $('lkPaceTxt').textContent, how: $('lkHow').textContent.slice(0, 700) };
    out.cards100 = [...document.querySelectorAll('#lkPace .lkcard')].map(e => e.textContent.replace(/\s+/g, ' ').trim());
    // zone policy: a tap at bite 1 is logged (no dud logic)
    document.querySelector('#lkPol button[data-pol="zone"]').click();
    A.start();
    const T = A.run.T, tau = T + 900;
    A.run.wall0 = performance.now() - (tau - 1) * vims;
    out.tapZone = A.registerTap(tau);
    out.tapInfoZone = A.run.tapInfo && { holdish: A.run.tapInfo.holdish, dud: A.run.tapInfo.dud, fit: A.run.tapInfo.fit };
    window.dispatchEvent(new Event('resize'));
    A.record(false);
    out.tapsAfterZone = A.taps.map(t => ({ anchor: t.anchor, pace: t.pace, pol: t.pol, T: t.T }));
    // hold policy: tap -> dud / Nut chance
    document.querySelector('#lkPol button[data-pol="hold"]').click();
    A.start();
    const P0 = C.plans[0], x = P0.variants.find(v => v.w > 50) || P0.variants[0], s = P0.series[x.s];
    const T2 = A.run.T, i = T2 + x.o - s.v0, t1 = s.v0 + i - x.o + s.b1[i], tau2 = t1 + 13;
    A.run.wall0 = performance.now() - (tau2 - 1) * vims;
    out.tapHold = A.registerTap(tau2);
    out.tapInfoHold = A.run.tapInfo && { holdish: A.run.tapInfo.holdish, pNut: +A.run.tapInfo.pNut.toFixed(3), dud: A.run.tapInfo.dud, fit: A.run.tapInfo.fit, truth2: s.n2[i] };
    A.record(!!s.n2[i]);
    out.profile = $('lkProfile').textContent.slice(0, 200);
    // READY start: same plan ~16 VI earlier on the stopwatch, taps from the dog start do not apply
    document.querySelector('#lkPol button[data-pol="auto"]').click();
    const Tdog = A.run.T;
    $('lkAnchor').value = 'ready'; $('lkAnchor').onchange({ target: $('lkAnchor') });
    out.ready = { sel: C.selection, T: $('lkT').textContent, dT_vi: Tdog - A.run.T, after: $('lkTAfter').textContent,
                  delayLbl: $('lkStartDelayLbl').textContent, delay: $('lkStartDelay').value, profile: $('lkProfile').textContent.slice(0, 120) };
    $('lkAnchor').value = 'dog'; $('lkAnchor').onchange({ target: $('lkAnchor') });
    out.back = { sel: C.selection, delay: $('lkStartDelay').value, hint: $('lkStartDelayHint').textContent };
    out.tally = JSON.parse(localStorage.getItem('hm64v29_lucky_tally')).map(t => ({ pace: t.pace, start: t.start, pol: t.pol }));
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, 600);
})();
