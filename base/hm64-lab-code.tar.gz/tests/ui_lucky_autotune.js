/* headless (v29.9): auto-tune. A runner whose fade-in tap comes 100 ms later than the 150 ms start-key delay (clock
   ~6 VIs late), casting on the beep with a cast tap and tapping bite 1, attempt after attempt (fade-in start, one tap).
   After 8 bite taps the clock shifts by the profile's learned offset; taps are stored unshifted, so the learned offset
   must stay put (no chasing) and the casts then land on the console's aim. */
(function () {
  setTimeout(async () => {
    const A = window.HM64LuckyApp, $ = id => document.getElementById(id), out = { errors: [], steps: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    try {
      ['hm64v29_lucky_taps', 'hm64v29_lucky_tally', 'hm64v29_lucky', 'hm64v29_lucky_fade2', 'hm64v29_lucky_dock'].forEach(k => localStorage.removeItem(k));
      $('arLucky').click();
      A.L.audio = false; A.L.tapStrategy = 'b'; A.L.beachCue = 'fade';
      A.L.biasAuto = false; A.L.sigmaAuto = false; A.L.biasMs = 0; A.L.sigmaMs = 150;   // clock auto-tune only: its synthetic casts search a cast frame (not real B-press data)
      $('lkRoute').value = 'lineup-dogbeach'; $('lkRoute').onchange({ target: $('lkRoute') });
      const vi = 33.053 / 2, P0 = A.plans[0], W = P0.variants.reduce((a, x) => a + x.w, 0);
      let seed = 9; const rnd = () => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);
      const pick = () => { let r = rnd() * W; for (const x of P0.variants) { r -= x.w; if (r <= 0) return x; } return P0.variants[0]; };
      for (let k = 0; k < 14; k++) {
        const F0 = performance.now() - 40000;
        A.start(F0 + 250);
        const cs = A.run.cs, off = (A.run.wall0 - F0) / vi;      // console plan time = stopwatch + off
        const x = pick(), s = P0.series[x.s];
        let c = A.run.T, i = Math.round(c + off) + x.o - s.v0, dd = 0;
        while (!(s.n1[i + dd] >= 0) && dd < 40) dd++;
        i += dd; c += dd;
        A.registerCast(c);
        A.registerTap(c + s.b1[i] + 13);
        A.record(false, 'fish');
        out.steps.push({ k, cs: +cs.toFixed(2), offVI: +off.toFixed(2), autoAfter: +A.autoB().toFixed(2) });
      }
      out.profile = $('lkProfile').textContent.slice(0, 400);
      out.fade = $('lkTapBox').textContent.slice(0, 500);
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, 600);
})();
