// node tests/test_lucky_cast.js DATA.json [pace] : Space with B at the cast + Space at bite 1 (v29.3).
// Simulated runners on the dog-landing stopwatch: how often the bite verdict (Nut bite / fish bite) is decisive and
// right, with and without the cast tap, and whether the profile learns the runner's bite reaction and stopwatch offset.
const fs = require('fs');
const LC = require('../webapp/hm64_lucky_v29.js');
const D = JSON.parse(fs.readFileSync(process.argv[2]));
const pace = process.argv[3] || 'fast', vi = 33.053 / 2;
LC.prepare(D, vi, { pace, anchor: 'dog' });
const P = LC.plans[0], sig = 100 / vi;
const T = LC.best(P, sig, 46).bite1.t;
let seed = 3; const rnd = () => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);
const gauss = () => { let u = 0; while (!u) u = rnd(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(6.2832 * rnd()); };
const W = P.variants.reduce((a, x) => a + x.w, 0);
const pick = () => { let r = rnd() * W; for (const x of P.variants) { r -= x.w; if (r <= 0) return x; } return P.variants[0]; };
const castCfg = { sd: Math.hypot(2.4, 2.4), tapSd: 2.4 };
console.log(`${pace}, cast aim ${((T - 1) * vi / 1000).toFixed(2)} s after the dog lands (release at bite 1), B spread 100 ms`);
function attempt(runner) {
  for (;;) {
    const x = pick(), s = P.series[x.s], xs = T + runner.late + gauss() * sig;   // true cast, true stopwatch
    const i = Math.round(xs) + x.o - s.v0;
    if (i < 0 || i >= s.len || s.n1[i] < 0 || s.n2[i] < 0 || Math.round(xs) < x.minT) continue;
    const delta = runner.start + gauss() * 2.4, lag = runner.lag + gauss() * 3;          // tool stopwatch = true + delta
    return { truth: s.n1[i], c: xs + delta + gauss() * 2.4, tau: xs + s.b1[i] + delta + lag, lag };
  }
}
for (const runner of [{ name: 'quick release (250 ms), start on time', lag: 15, start: 0, late: 0 },
                      { name: 'slow release (430 ms), start 50 ms late', lag: 26, start: 3, late: 0 },
                      { name: 'release 330 ms, presses B 80 ms late', lag: 20, start: -2, late: 5 }]) {
  for (const useCast of [false, true]) {
    let n = 0, dec = 0, decOK = 0, nutCalls = 0, nutTrue = 0;
    const taps = [];
    let prof = null;
    for (let a = 0; a < 40; a++) {
      const at = attempt(runner);
      const tapMu = prof ? prof.tapMu : 13, tapSd = prof ? prof.tapSd : 3.5, b = prof ? (useCast ? prof.bias0 : prof.bias) : 0;
      const r = LC.tapPosterior(P, T, sig, b, at.tau, tapMu, Math.max(tapSd, 6), null, useCast ? { c: at.c, ...castCfg } : null);
      if (r.Z > 1e-4) {
        n++;
        if (r.p1 > 0.8 || r.p1 < 0.02) { dec++; if ((r.p1 > 0.8) === (at.truth === 1)) decOK++; }
        if (r.p1 > 0.8) nutCalls++;
      }
      nutTrue += at.truth;
      taps.push(useCast ? { k: 0, T, tau: at.tau, c: at.c } : { k: 0, T, tau: at.tau });
      if (a % 5 === 4) prof = LC.profile(taps, sig, 13, 3.5, 3, castCfg);
    }
    console.log(`  ${runner.name.padEnd(42)} ${useCast ? 'cast+bite' : 'bite only'}: verdict decisive ${dec}/${n}, right ${decOK}/${dec}; ` +
      `"Nut bite" calls ${nutCalls} (true Nut bites ${nutTrue}/40) · learned reaction ${prof.lag ? Math.round(prof.lag.mu * vi) + ' ms' : '—'} ` +
      `(true ${Math.round(runner.lag * vi)}) · stopwatch offset ${Math.round((useCast ? prof.bias0 : prof.bias) * vi)} ms`);
  }
}
