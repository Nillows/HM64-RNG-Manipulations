/* headless (v29.9, 2026-11-16 build): route in Settings + "sparrows at the door" checkbox (S key, mid-attempt switch),
   the dock-end tap's guess highlighted on the L1 cards (and back after the attempt), personalized cast suggestions
   (measured lopsided timing -> aim moves), and the visual cue lamp (countdown pulses, CAST, release windows). */
(function () {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => {
    const A = window.HM64LuckyApp, C = window.HM64Lucky, $ = id => document.getElementById(id), out = { errors: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    try {
      $('arLucky').click();
      out.sound = A.L.audio;
      out.routeOpts = [...$('lkRoute').options].map(o => o.value);
      $('lkRoute').value = 'lineup-dogbeach'; $('lkRoute').onchange({ target: $('lkRoute') });
      A.setStrategy('ebd'); A.setBeachCue('ctrl'); A.setSelection('wait-w1', 'fadein');
      /* A: sparrows */
      $('lkSparrows').checked = true; $('lkSparrows').onchange({ target: $('lkSparrows') });
      out.spOn = { route: C.selection.route, pace: C.selection.pace, cls: $('lkSparLbl').className };
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 's' }));
      out.spOffKey = { route: C.selection.route, pace: C.selection.pace, checked: $('lkSparrows').checked };
      $('lkRoute').value = 'lineup-lineup2'; $('lkRoute').onchange({ target: $('lkRoute') });
      out.l2 = { route: C.selection.route, disabled: $('lkSparrows').disabled };
      $('lkRoute').value = 'lineup-dogbeach'; $('lkRoute').onchange({ target: $('lkRoute') });
      A.setSelection('all', 'fadein');
      /* B: dock-end guess. Truth: a route of preset wait-w2 + 2nd cut middle (its heaviest READY) */
      const vi = 33.053 / 2, R_MS = 230;
      const R = A.routeDef(), g = R.groups.find(x => x.id === 'wait-w2+cut2-mid'), pl = C.planSet(g.id, 'fadein', 'lineup-dogbeach')[0];
      const v = pl.variants.slice().sort((a, b) => b.w - a.w)[0];
      const F0 = performance.now() - 3000;                       // first light 3 s ago
      A.start(F0 - 70 * vi + R_MS); A.seqPress(F0 + 66 * vi + R_MS); A.seqPress(F0 + (v.minT - 1) * vi + R_MS);
      await sleep(2500);
      const g3 = A.run.gp.g3;
      out.guess = g3 && g3.guess ? { ax: g3.guess.ax, p1: +g3.guess.p1.toFixed(2), l2: g3.guess.l2, p2: g3.guess.p2 && +g3.guess.p2.toFixed(2), sure2: g3.guess.sure2 } : null;
      const cards = () => [...document.querySelectorAll('#lkPace .lkcard')].map(c => (c.classList.contains('sel') ? '[G]' : '') + (c.classList.contains('own') ? '[own]' : '') + c.querySelector('b').textContent);
      out.cardsDuring = cards();
      out.note = ([...document.querySelectorAll('#lkPace .small')].find(d => d.textContent.startsWith('Your dock-end')) || {}).textContent;
      out.flash = A.run.flash && A.run.flash.text;
      /* mid-attempt sparrow switch keeps the clock and taps, re-reads the dock tap on the new table */
      const w0 = A.run.wall0;
      A.setSparrows(true);
      out.midSwitch = { route: C.selection.route, sameClock: A.run.wall0 === w0, g3again: !!(A.run.gp.g3 && A.run.gp.g3.guess), plan0IsPlan: A.run.plan0 !== null };
      A.setSparrows(false);
      A.stop(true);
      await sleep(100);
      out.cardsAfter = cards();
      /* C: personalized cast suggestion */
      A.setSelection('wait-w0', 'fadein');
      const stdT = A.run.T, stdP = $('lkP').textContent;
      let seed = 3; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
      for (let i = 0; i < 40; i++) A.pracLog.push({ at: Date.now(), e: Math.round(60 + 160 * Math.pow(rnd(), 2) - 40 * rnd()), m: A.L.pracLine ? 'line' : 'beeps', src: 'test', v: 1 });
      A.L.personalCast = true; $('lkPersonalCast').checked = true; $('lkPersonalCast').onchange({ target: $('lkPersonalCast') });
      const pk = A.personalKernel();
      out.personal = { stdT, stdP, T: A.run.T, P: $('lkP').textContent, kernel: { r: pk.r, sdMs: Math.round(pk.sd * vi), meanMs: Math.round(pk.mean * vi) },
                       parts: { n: pk.parts.es.length, mean: Math.round(pk.parts.mean), sd: Math.round(pk.parts.sd), skew: +pk.parts.skew.toFixed(2), sc: Math.round(pk.parts.sc), sb: Math.round(pk.parts.sb) },
                       txt: $('lkPersonalTxt').textContent };
      A.L.biasMs = -100; A.refresh();                             // with a cast-cue correction that removes the late habit
      out.personalCorr = { T: A.run.T, P: $('lkP').textContent, meanMs: Math.round(A.personalKernel().mean * vi), txt: $('lkPersonalTxt').textContent.slice(-220) };
      A.L.biasMs = 0;
      $('lkPersonalCast').checked = false; $('lkPersonalCast').onchange({ target: $('lkPersonalCast') });
      out.personalOff = { T: A.run.T, P: $('lkP').textContent, hidden: $('lkPersonalTxt').hidden };
      /* D: lamp + glow during a countdown pulse */
      A.start(performance.now() - 10);
      const T = A.run.T, lampAt = dt => { const c = A.cueAt(T - dt / vi, ''); return `${c.kind} ${c.big}${c.bar != null ? ' bar ' + c.bar.toFixed(2) : ''}${c.glow ? ' glow ' + c.glow : ''}`; };
      await sleep(1000);                                          // let the tap flash expire
      out.lamp = [6000, 1800, 1450, 900, 450, 50, -100].map(d => d + ': ' + lampAt(d));
      const zs = A.run.zone ? A.run.zone.zones : [];
      out.zoneLamp = zs.length ? [zs[0][0] - 80, zs[0][0] - 30, zs[0][0] + 1, zs[0][1] + 2].map(t => { const c = A.cueAt(t, ''); return `${c.kind} ${c.big} | ${c.sub}`; }) : [];
      A.stop(true);
      A.run.wall0 = performance.now() - (T - 1) * vi + 1450;   // a live clock 1.45 s before CAST: draw the lamp once
      A.renderCue(T - 1450 / vi, '');
      out.dom = { cls: $('lkCue').className, big: $('lkCueBig').textContent, bar: $('lkCueBar').style.width, glow: $('cueGlow').style.boxShadow.slice(0, 60) };
      A.run.wall0 = null; A.renderCue(0, ''); out.domIdle = { cls: $('lkCue').className, glow: $('cueGlow').style.boxShadow };
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, 600);
})();
