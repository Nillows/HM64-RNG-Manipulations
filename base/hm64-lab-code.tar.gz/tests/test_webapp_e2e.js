// node tests/test_webapp_e2e.js DATA.json CASES.json -> end to end: logs for X s -> histogram -> aimed press
// (1 VI press noise) -> true outcome on the true path, with and without holding through the first bite.
const fs = require('fs');
const Core = require('../webapp/hm64_core_v28.js');
const D = JSON.parse(fs.readFileSync(process.argv[2]));
const cases = JSON.parse(fs.readFileSync(process.argv[3])).filter(c => c.strategy === 'AD every change, 60 s');
Core.prepare(D, { reactMuVI: 17.5, reactSdVI: 4.5, horizonS: 30 });
let seed = 11; const rnd = () => { seed = (seed * 1103515245 + 12345) % 2147483648; return seed / 2147483648; };
const randn = () => { let u = 0, v = 0; while (!u) u = rnd(); while (!v) v = rnd(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };
for (const obsS of [5, 10, 20, 30]) for (const hold of [false, true]) {
  const r = { n: 0, plan: 0, pred: 0, nut: 0, viaHold: 0, fish: 0, unk: 0, wait: 0 };
  for (const cs of cases) {
    const L0 = cs.logs, t1 = L0[0].t, L = L0.filter(l => l.t - t1 <= obsS * 60);
    if (L.length < 2) continue;
    const logs = L.map((l, n) => ({ kind: l.kind, value: l.value, dir: l.dir, base: l.base, dVI: l.t - t1, first: n === 0 }));
    Core.recompute(logs);
    const g = Core.groups()[0];
    r.n++;
    if (g.mass < 0.95) continue;                                      // the app waits for one dog
    const decide = logs[logs.length - 1].dVI + 30;
    const bins = Core.histogram([{ k: g.k, mass: 1, nowVI: g.mean + decide, sd: g.sd }], { hold });
    const best = Math.max(0, ...bins.map(b => b.p));
    const tg = Core.pickTargets(bins, 3).find(b => b.p >= 0.85 * best);
    if (!tg) continue;
    r.plan++; r.pred += tg.p; r.wait += tg.dVI;
    const v = Math.floor(L[L.length - 1].t + cs.offset + 30 + tg.dVI + randn());
    const c = Core.castAt(cs.path, v);
    if (!c) r.unk++; else if (c.n1) r.nut++; else if (hold && c.n2) { r.nut++; r.viaHold++; } else r.fish++;
  }
  console.log(`observe ${String(obsS).padStart(2)} s, ${hold ? 'hold allowed' : 'release at bite 1'}: plan ${r.plan}/${r.n} · predicted ${(100 * r.pred / r.plan).toFixed(1)}% · ` +
    `actual Nut ${(100 * r.nut / r.plan).toFixed(1)}% (${r.viaHold} via hold) · fish ${r.fish} · no table ${r.unk} · cast ${(r.wait * Core.viMs() / r.plan / 1000).toFixed(1)} s after deciding`);
}
