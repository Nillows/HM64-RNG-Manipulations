// node tests/test_webapp_groups.js DATA.json CASES.json -> cost of logging lumped animation groups
const fs = require('fs');
const Core = require('../webapp/hm64_core_v28.js');
const D = JSON.parse(fs.readFileSync(process.argv[2]));
const cases = JSON.parse(fs.readFileSync(process.argv[3]));
Core.prepare(D, {});
const GROUPINGS = {
  'exact animations': [],
  'look-alikes that rarely touch: shoulder pair, bark/bork, run/sprint, smell/wiggle-bum': [[128, 136], [144, 152], [16, 72], [160, 200]],
  'well: sit + sleep': [[40, 112]],
  'well: sit + scratch + shoulder-sitting': [[40, 120, 128]],
  'well: Idle + shoulder-standing + sniff-standing': [[0, 136, 168]],
  'well: trans32 + rollover': [[32, 80]],
  'all three wells': [[40, 120, 128, 112], [0, 136, 168], [32, 80]],
  "5 pose groups (v27.7a)": [[8, 16, 72], [40, 48, 96, 104, 120, 128], [0, 88, 136, 144, 152, 160, 168, 176, 200], [80, 112], [32, 56, 64, 184, 192]],
};
const rms = a => Math.sqrt(a.reduce((s, x) => s + x * x, 0) / a.length);
for (const strat of [...new Set(cases.map(c => c.strategy))]) {
  console.log('\n' + strat);
  for (const [gname, groups] of Object.entries(GROUPINGS)) {
    const gOf = b => groups.find(g => g.includes(b));
    let n = 0, right = 0, conv = 0, wrongConv = 0, logsN = 0; const err = [], need = [];
    for (const cs of cases.filter(c => c.strategy === strat)) {
      const L = cs.logs, t1 = L[0].t;
      const logs = []; let prevKey = null;
      L.forEach((l, i) => {
        const g = l.kind === 'AD' ? gOf(l.base) : null;
        const key = l.kind === 'AD' ? (g ? 'g' + g.join() : 'b' + l.base) + ':' + l.dir : 'd' + l.dir;
        if (i > 0 && key === prevKey) return;              // a change inside a group is not seen as a change
        prevKey = key;
        logs.push({ kind: l.kind, value: l.value, dir: l.dir, base: l.base, bases: g || undefined, dVI: l.t - t1, first: i === 0, t: l.t });
      });
      n++; logsN += logs.length;
      Core.recompute(logs);
      const g = Core.groups()[0];
      if (g.k === cs.path) { right++; err.push(g.mean + logs[logs.length - 1].dVI - (logs[logs.length - 1].t + cs.offset)); }
      if (g.mass >= 0.95) { conv++; if (g.k !== cs.path) wrongConv++; }
      // logs until the right path holds 95%
      let k95 = null;
      for (let m = 1; m <= logs.length && k95 === null; m++) { Core.recompute(logs.slice(0, m)); const h = Core.groups()[0]; if (h.k === cs.path && h.mass >= 0.95) k95 = m; }
      if (k95) need.push(k95);
    }
    need.sort((a, b) => a - b);
    console.log(`  ${gname.padEnd(84)} logs/run ${(logsN / n).toFixed(1)}  right path ${(100 * right / n).toFixed(0)}%  auto-select ${(100 * conv / n).toFixed(0)}% (wrong ${wrongConv})  ` +
      `logs to 95%: median ${need[need.length >> 1]}  clock RMS ${rms(err).toFixed(2)} VI`);
  }
}
