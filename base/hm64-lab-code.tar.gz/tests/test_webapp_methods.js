// node tests/test_webapp_methods.js DATA.json CASES.json  -> clock error of each line-up method,
// with the console running at the assumed speed and 0.3% / 0.6% faster (wall clock vs game updates)
const fs = require('fs');
const Core = require('../webapp/hm64_core_v28.js');
const D = JSON.parse(fs.readFileSync(process.argv[2]));
const cases = JSON.parse(fs.readFileSync(process.argv[3]));
Core.prepare(D, {});
function randn() { let u = 0, v = 0; while (!u) u = Math.random(); while (!v) v = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); }
const rms = a => Math.sqrt(a.reduce((s, x) => s + x * x, 0) / a.length);
for (const f of [1, 1.003, 1.006]) {
  const res = {};
  for (const cs of cases) {
    const L = cs.logs, t1 = L[0].t;
    const logs = L.map((l, n) => ({ kind: l.kind, value: l.value, dir: l.dir, base: l.base, dVI: (l.t - t1) / f, first: n === 0 }));
    Core.recompute(logs);
    const g = Core.groups()[0];
    if (!g || g.k !== cs.path) continue;
    const xLast = logs[logs.length - 1].dVI, truth = L[L.length - 1].t + cs.offset;
    // taps: every visible change of the true path during the observation, ~13 VI late (sd 3)
    const tEnd = L[L.length - 1].t;
    const tapsAll = Core.changesIn(cs.path, t1 + cs.offset + 20, tEnd + cs.offset)
      .map(c => ((c - cs.offset) + 13 + 3 * randn() - t1) / f);
    // line-up taps: the changes of the 12 s right after the last log (tapping while lining up)
    const lineEnd = tEnd + 720;
    const taps = Core.changesIn(cs.path, tEnd + cs.offset + 10, lineEnd + cs.offset)
      .map(c => ((c - cs.offset) + 13 + 3 * randn() - t1) / f);
    const xNow = (lineEnd - t1) / f, truthNow = lineEnd + cs.offset;
    const lr = Core.fitLogsClock(g.bestJ, true);
    const est = {                                   // clock at the end of a 12 s line-up after the last log
      'logs only': g.mean + xNow,
      'logs+speed': lr ? lr.A + lr.B * xNow : null,
      'taps': (() => { const r = Core.fitTapsClock(cs.path, g.mean, 1, taps); return r && r.matched >= 2 ? r.A + r.B * xNow : null; })(),
      'taps+logs speed': (() => { if (!lr) return null; const r = Core.fitTapsClock(cs.path, lr.A, lr.B, taps, 1e9);
        if (!r || r.matched < 2) return null; const off = r.A - lr.A, B = lr.B;
        const xs = taps; const m = xs.reduce((a, b) => a + b, 0) / xs.length;            // offset at the taps, speed from logs
        return (lr.A + lr.B * m) + (r.A + r.B * m - (lr.A + lr.B * m)) + B * (xNow - m); })(),
    };
    const key = cs.strategy;
    res[key] = res[key] || {};
    for (const [m, e] of Object.entries(est)) { if (e === null) continue; (res[key][m] = res[key][m] || []).push(e - truthNow); }
  }
  console.log(`\nconsole speed x${f}`);
  for (const [s, ms] of Object.entries(res))
    console.log('  ' + s.padEnd(34) + Object.entries(ms).map(([m, e]) => `${m}: ${rms(e).toFixed(2)} VI (n=${e.length})`).join(' | '));
}

// how precisely one session measures the console speed (logs fit, dense 60 s logging)
for (const f of [1, 1.003]) {
  const bs = [];
  for (const cs of cases.filter(c => c.strategy === 'AD every change, 60 s')) {
    const L = cs.logs, t1 = L[0].t;
    Core.recompute(L.map((l, n) => ({ kind: l.kind, value: l.value, dir: l.dir, base: l.base, dVI: (l.t - t1) / f, first: n === 0 })));
    const g = Core.groups()[0]; if (!g || g.k !== cs.path) continue;
    const r = Core.fitLogsClock(g.bestJ, true); if (r && r.rateFitted) bs.push(r.B);
  }
  const m = bs.reduce((a, b) => a + b, 0) / bs.length, sd = Math.sqrt(bs.reduce((a, b) => a + (b - m) ** 2, 0) / bs.length);
  console.log(`speed x${f}: fitted ${m.toFixed(5)} ± ${sd.toFixed(5)} per session (n=${bs.length}) -> ${(100 * sd).toFixed(3)}% per session`);
}
