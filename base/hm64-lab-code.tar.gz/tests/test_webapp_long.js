// node tests/test_webapp_long.js DATA.json -> Nut chance vs observation length (generated runners, 0-180 s tables)
// Runner: animation+facing log at READY (10-40 VI after), then every visible change (>= 12 VI) 10-25 VI late.
// Decides 0.5 s after the last log, casts at the best target within 30 s (85% rule), 1-VI press error, holds when told.
const fs = require('fs');
const Core = require('../webapp/hm64_core_v28.js');
const D = JSON.parse(fs.readFileSync(process.argv[2]));
Core.prepare(D, { reactMuVI: 17.5, reactSdVI: 4.5, horizonS: 30 });
let seed = 3; const rnd = () => { seed = (seed * 1103515245 + 12345) % 2147483648; return seed / 2147483648; };
const randn = () => { let u = 0, v = 0; while (!u) u = rnd(); while (!v) v = rnd(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };
const W = D.arrivals.map(a => a[2]), Wt = W.reduce((a, b) => a + b, 0);
const pick = () => { let r = rnd() * Wt, i = 0; while (r > W[i]) { r -= W[i]; i++; } return i; };
const N = +(process.argv[3] || 200);
for (const obsS of [10, 20, 30, 45, 60, 75, 90]) {
  const r = { n: 0, plan: 0, pred: 0, nut: 0, hold: 0, castAt: [] };
  for (let rep = 0; rep < N; rep++) {
    const ai = pick(), [k, o, , head] = D.arrivals[ai], hi = head && head.length ? ai : -1;
    const show = t => Core.showAt(k, t + o, hi);
    const u0 = 10 + Math.floor(rnd() * 31), logs = [];
    const s0 = show(u0); logs.push({ kind: 'AD', base: s0.base, dir: s0.dir, value: s0.val, dVI: 0, first: true, t: u0 });
    let prev = s0.val;
    for (let t = u0 + 1; t < obsS * 60; t++) {
      const s = show(t); if (s.val === prev || s.val < 0) continue;
      let L = 1; while (L < 12 && show(t + L).val === s.val) L++;
      prev = s.val; if (L < 12) continue;
      const lt = t + 10 + Math.floor(rnd() * 16);
      logs.push({ kind: 'AD', base: s.base, dir: s.dir, value: s.val, dVI: lt - u0, first: false, t: lt });
    }
    Core.recompute(logs); const g = Core.groups()[0]; r.n++;
    if (g.mass < 0.95) continue;
    const decide = logs[logs.length - 1].dVI + 30;
    const bins = Core.histogram([{ k: g.k, mass: 1, nowVI: g.mean + decide, sd: g.sd }], { hold: true });
    const best = Math.max(0, ...bins.map(b => b.p)), tg = Core.pickTargets(bins, 3).find(b => b.p >= 0.85 * best);
    if (!tg) continue;
    r.plan++; r.pred += tg.p;
    const v = Math.floor(logs[logs.length - 1].t + o + 30 + tg.dVI + randn());
    r.castAt.push((v - o) / 60);
    const c = Core.castAt(k, v);
    if (c && c.n1) r.nut++; else if (c && c.n2) { r.nut++; r.hold++; }
  }
  const med = r.castAt.sort((a, b) => a - b)[r.castAt.length >> 1];
  console.log(`observe ${String(obsS).padStart(2)} s: plan found ${r.plan}/${r.n} · predicted ${r.plan ? (100 * r.pred / r.plan).toFixed(0) : '-'}% · ` +
    `actual Nut ${r.plan ? (100 * r.nut / r.plan).toFixed(0) : '-'}% (${r.hold} by holding) · Nut per attempt ${(100 * r.nut / r.n).toFixed(0)}% · cast ~${med ? med.toFixed(0) : '-'} s after READY`);
}
