/* headless: "2nd bite + tap" flow in the real UI. Simulated runner always on dog path 2: taps the first bite,
   the tool reports dud / Nut chance, the profile learns the path and the plan re-aims. */
(function () {
  setTimeout(() => {
    const A = window.HM64LuckyApp, C = window.HM64Lucky, out = { steps: [] };
    localStorage.removeItem('hm64v29_lucky_taps'); localStorage.removeItem('hm64v29_lucky_tally');
    document.getElementById('arLucky').click();
    A.L.audio = false;
    document.querySelector('#lkPol button[data-pol="tap"]').click();
    out.policy = A.run.pol; out.T0 = +((A.run.T - 1) * 33.053 / 2000).toFixed(2);
    const P0 = C.plans[0], mine = P0.variants.filter(x => x.s === 1);
    let seed = 5; const rnd = () => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);
    for (let a = 0; a < 6; a++) {
      A.start();
      const T = A.run.T, x = mine[Math.floor(rnd() * mine.length)], s = P0.series[x.s];
      const i = T + x.o - s.v0 + Math.round((rnd() - 0.5) * 8);
      const t1 = s.v0 + i - x.o + s.b1[i], tau = t1 + 13 + (rnd() - 0.5) * 4;
      A.run.wall0 = performance.now() - (tau - 1) * 33.053 / 2;
      A.registerTap(tau);
      const ti = A.run.tapInfo;
      out.steps.push({ T_s: +((T - 1) * 33.053 / 2000).toFixed(2), tap_s: +((tau - 1) * 33.053 / 2000).toFixed(2), truthNut2: s.n2[i],
                       pNut: ti && +ti.pNut.toFixed(3), dud: ti && ti.dud, fit: ti && ti.fit, status: document.getElementById('lkStatus').textContent });
      A.record(!!s.n2[i]);
    }
    out.profile = A.prof && { n: A.prof.n, bias_ms: Math.round(A.prof.bias * 33.053 / 2), top: Object.entries(A.prof.byPath).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([k, m]) => [+k + 1, +m.toFixed(2)]) };
    A.refresh();
    out.T_after = +((A.run.T - 1) * 33.053 / 2000).toFixed(2); out.p_after = document.getElementById('lkP').textContent;
    out.profileText = document.getElementById('lkProfile').textContent.slice(0, 160);
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, 400);
})();
