/* headless (v29.9): tap format on the fade-in start (ranch exit, first light, first control, dock end; miss any one),
   clock-tap precision + the cascade into the timing spread, the dock-end re-weighting, auto-tune, and the dock-only
   format switching to the dock-end start. Taps are placed in wall time from a known console first light F0. */
(function () {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  setTimeout(async () => {
    const A = window.HM64LuckyApp, C = window.HM64Lucky, $ = id => document.getElementById(id), out = { errors: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    try {
      ['hm64v29_lucky_taps', 'hm64v29_lucky_tally', 'hm64v29_lucky', 'hm64v29_lucky_fade2', 'hm64v29_lucky_dock', 'hm64v29_lucky_taprec'].forEach(k => localStorage.removeItem(k));
      $('arLucky').click();
      A.L.audio = false;
      $('lkRoute').value = 'lineup-dogbeach'; $('lkRoute').onchange({ target: $('lkRoute') });
      const vi = 33.053 / 2, dly = 150, R_MS = 230;
      out.sel = C.selection; out.box = { hidden: $('lkTapBox').hidden, cues: [...$('lkTapBox').querySelectorAll('input[data-cue]')].map(e => e.dataset.cue + ':' + e.checked),
                                         txt: $('lkTapBox').textContent.replace(/\s+/g, ' ').slice(0, 700) };
      out.sig = { slider: A.L.sigmaMs, eff: A.sigEffMs('fadein'), pier: A.sigEffMs('pier') };
      const P0 = A.plans[0], x = P0.variants.slice().sort((a, b) => b.w - a.w)[0];
      const T = { exit: -70, fade: 0, ctrl: 66 };
      const tapAt = (F0, id) => id === 'dock' ? F0 + (x.minT - 1) * vi + R_MS : F0 + T[id] * vi + R_MS;
      const seq = async (ids, extra) => {
        const F0 = performance.now() - 40000, ws = ids.map(id => tapAt(F0, id)).concat(extra ? [F0 + extra] : []).sort((a, b) => a - b), res = [];
        A.start(ws[0]);
        for (const w of ws.slice(1)) res.push(A.seqPress(w));
        await sleep(2500);
        const g = A.run.gp;
        const r = { res, cues: Object.keys(g.cue), clockErrMs: Math.round(A.run.wall0 - (F0 + R_MS - dly)), sdF: Math.round(g.sdF),
                    g3: g.g3 ? { off: !!g.g3.off, moved: g.g3.moved, bands: (g.g3.bands || []).map(b => b.label + ' ' + Math.round(100 * b.p)) } : null };
        A.stop(true);
        return r;
      };
      const cuesNow = () => A.tapCues().map(c => c.id);
      out.defaults = { strat: A.L.tapStrategy, beach: A.L.beachCue, cues: cuesNow(), radios: $('lkStrat').value };
      out.all3 = await seq(['exit', 'ctrl', 'dock']);
      out.missExit = await seq(['ctrl', 'dock']);
      out.missCtrl = await seq(['exit', 'dock']);
      out.missDock = await seq(['exit', 'ctrl']);
      out.stray = await seq(['exit', 'ctrl', 'dock'], 3000);
      out.taprec = A.taprec.length;
      A.L.tapSdAuto = false; A.L.tapSdMs = 30;
      out.sharp = { eff: A.sigEffMs('fadein'), clockSd: A.clockSd() };
      A.L.tapSdAuto = true; A.L.tapSdMs = 60;
      /* two-tap sets: the 2nd may be missed */
      A.setStrategy('eb'); out.eb = { cues: cuesNow(), sig: A.sigEffMs('fadein'), both: await seq(['exit', 'ctrl']), miss2: await seq(['exit']) };
      A.setStrategy('bd'); out.bd = { cues: cuesNow(), sig: A.sigEffMs('fadein'), both: await seq(['ctrl', 'dock']), miss2: await seq(['ctrl']) };
      A.setStrategy('b'); out.b = { cues: cuesNow(), sig: A.sigEffMs('fadein'), one: await seq(['ctrl']) };
      /* the other beach cue */
      A.setStrategy('ebd'); A.setBeachCue('fade');
      out.fade = { cues: cuesNow(), all3: await seq(['exit', 'fade', 'dock']), missFade: await seq(['exit', 'dock']) };
      A.setBeachCue('ctrl');
      /* dock end only = the dock-end start; picking another strategy goes back */
      A.setStrategy('d'); out.dOnly = { sel: C.selection.anchor, radios: $('lkStrat').value };
      A.setStrategy('ebd'); out.back = { sel: C.selection.anchor, cues: cuesNow() };
      /* auto-tune shift */
      A.TEST.autoB = 3; { const F0 = performance.now() - 40000; A.start(tapAt(F0, 'exit')); out.auto = { cs: A.run.cs, shiftMs: Math.round((F0 + R_MS - dly) - A.run.wall0) }; A.stop(true); }
      A.TEST.autoB = null;
      out.stats = A.tapStats(); out.boxAfter = $('lkTapBox').textContent.replace(/\s+/g, ' ').slice(0, 900);
      $('lkRoute').value = 'nodog-zigzag-fast'; $('lkRoute').onchange({ target: $('lkRoute') });
      out.zigzag = { hidden: $('lkTapBox').hidden, sig: A.sigEffMs() };
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, 600);
})();
