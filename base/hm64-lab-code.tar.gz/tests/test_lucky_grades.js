// node tests/test_lucky_grades.js DATA.json [route] : v29.9 travel grades (cabin, crossroads) x cuts on a members route.
// Best odds (max over smart zones / release bite 1 / hold to bite 2) at ±100 ms for each combination and start.
const fs = require('fs');
const C = require('../webapp/hm64_lucky_v29.js');
const D = JSON.parse(fs.readFileSync(process.argv[2]));
const rid = process.argv[3] || 'nodog-zigzag-fast', vi = 33.053 / 2;
C.prepare(D, vi, { route: rid });
const R = C.routeOf(rid);
const val = (anchor, ax) => {
  const g = C.groupFor(R, ax); if (!g) return null;
  C.select({ route: rid, anchor, pace: g.id });
  const P = C.plans[0], b = C.best(P, 100 / vi, P.firstT + 29);
  return { p: Math.max(b.zone.p, b.bite1.p, b.hold.p), share: g.share, cover: g.cover };
};
const f = x => (x ? (100 * x.p).toFixed(1).padStart(5) : '   — ');
const H = ['fast', 'mid', 'slow'], X = ['fast', 'mid', 'slow'];
for (const anchor of ['pier', 'beach']) {
  const cuts = anchor === 'pier' ? [{}, { cut1: 'tight' }, { cut1: 'tight', cut2: 'early' }, { cut1: 'tight', cut2: 'mid' }] : [{}, { cut1: 'tight' }];
  for (const cut of cuts) {
    const tag = Object.entries(cut).map(([a, o]) => a + '=' + o).join(' ') || 'any cuts';
    console.log(`\n${anchor} start, ${tag}: rows = cabin, columns = crossroads (any | fast | medium | slow); share of the pool in []`);
    for (const h of [null].concat(H)) {
      const cells = [null].concat(X).map(x => { const ax = Object.assign({}, cut); if (h) ax.house = h; if (x) ax.cross = x; return val(anchor, ax); });
      console.log(`  cabin ${(h || 'any').padEnd(4)} | ${cells.map(f).join(' | ')}   [${cells.map(c => (c ? (100 * c.share).toFixed(1) : '-')).join(' ')}]`);
    }
  }
}
