// node tests/test_lucky_tap.js DATA.json : simulated runners tap bite 1 (hold-only), the profile learns them.
const fs = require('fs');
const LC = require('../webapp/hm64_lucky_v29.js');
const D = JSON.parse(fs.readFileSync(process.argv[2]));
const vi = 33.053 / 2; LC.prepare(D, vi);
const P0 = LC.plans[0], sigMs = 150, sig = sigMs / vi, tapMu = 13, tapSd = 3.5;
let seed = 11; const rnd = () => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);
const gauss = () => { let u = 0; while (!u) u = rnd(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(6.2832 * rnd()); };
const W = P0.variants.reduce((q, x) => q + x.w, 0);
function attempt(dist, T, biasVI) {
  let u = rnd(), a = dist[dist.length - 1].x;
  for (const e of dist) { u -= e.p; if (u <= 0) { a = e.x; break; } }
  const s = P0.series[a.s], i = T + a.o - s.v0 + Math.round(biasVI + gauss() * sig);
  if (i < 0 || i >= s.len || s.n1[i] < 0 || s.n2[i] < 0) return null;
  return { k: 0, T, tau: s.v0 + i - a.o + s.b1[i] + tapMu + gauss() * tapSd, n2: s.n2[i] };
}
const holdAt = (plan, t) => LC.curve(plan, sig, 'hold').P[t];
const T0 = LC.best(P0, sig, 30).hold.t;
const runners = [['crowd (route weights), on time', () => true, 0], ['always dog path 2, on time', x => x.s === 1, 0],
                 ['always dog path 4, 120 ms late', x => x.s === 3, 120 / vi], ['always dog path 3, 120 ms early', x => x.s === 2, -120 / vi]];
for (const [name, keep, bias] of runners) {
  const mine = P0.variants.filter(keep), Wm = mine.reduce((q, x) => q + x.w, 0);
  const dist = mine.map(x => ({ x, p: x.w / Wm }));
  const truth = Object.assign(Object.create(Object.getPrototypeOf(P0)), P0, { variants: mine });
  const out = [];
  for (const N of [0, 3, 6, 12]) {
    let acc = 0, bsum = 0;
    const reps = N ? 12 : 1;
    for (let r = 0; r < reps; r++) {
      const taps = []; let T = T0;
      for (let a = 0; a < N; a++) {                      // the plan updates after every attempt, as in the app
        const at = attempt(dist, T, bias); if (at) taps.push(at);
        const prof = LC.profile(taps, sig, tapMu, tapSd);
        T = LC.best(LC.personal(P0, prof), sig, 30).hold.t;
      }
      const prof = LC.profile(taps, sig, tapMu, tapSd);
      const b = prof ? prof.bias : 0;
      const Tp = LC.best(LC.personal(P0, prof), sig, 30).hold.t;
      const tAim = Math.max(1, Tp - b);                  // beep moved earlier by the measured offset
      acc += holdAt(truth, Math.min(LC.TMAX, Math.max(1, Math.round(tAim + bias)))); bsum += b;
    }
    out.push(`${N} taps ${(100 * acc / reps).toFixed(1)}%` + (N ? ` (offset ${(bsum / reps * vi).toFixed(0)} ms)` : ''));
  }
  console.log(`${name.padEnd(34)} ${out.join(' · ')}`);
}
