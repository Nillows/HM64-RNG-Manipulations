/* headless (v29.9): Lucky Timer route "lineup-dogbeach" (tools/zigzag_routes.py --lineup): anchors (fade-in first, dock
   end), wait presets then 2nd-cut presets, the fade-in how-to, an attempt from the heaviest member variant (cast + bite
   tap), the dock-end start, then back to the zig-zag route (texts there unchanged). */
(function () {
  setTimeout(() => {
    const A = window.HM64LuckyApp, C = window.HM64Lucky, $ = id => document.getElementById(id), out = { errors: [] };
    window.addEventListener('error', e => out.errors.push(String(e.message)));
    try {
      ['hm64v29_lucky_taps', 'hm64v29_lucky_tally', 'hm64v29_lucky'].forEach(k => localStorage.removeItem(k));
      $('arLucky').click();
      A.L.audio = false; A.L.tapStrategy = 'b'; A.L.beachCue = 'fade'; A.L.sigmaMs = 150; $('lkSigma').value = 150; $('lkSigma').onchange();
      out.routes = [...$('lkRoute').options].map(o => o.textContent);
      $('lkRoute').value = 'lineup-dogbeach'; $('lkRoute').onchange({ target: $('lkRoute') });
      const cardTxt = () => [...document.querySelectorAll('#lkPace .lkcard')].map(c => (c.classList.contains('sel') ? '[x] ' : '') + c.textContent.replace(/\s+/g, ' ').trim());
      out.sel = C.selection; out.anchors = [...$('lkAnchor').options].map(o => o.textContent);
      out.startTxt0 = ($('lkPaceTxt').textContent.match(/Start:.*$/) || [''])[0];
      out.head = $('lkPaceHead').textContent;
      out.cards = cardTxt(); out.paceTxt = $('lkPaceTxt').textContent.slice(0, 300);
      out.plan = { T: $('lkT').textContent, P: $('lkP').textContent, txt: $('lkPlanTxt').textContent, how: $('lkHow').textContent.slice(0, 900) };
      out.delayHint = $('lkStartDelayHint').textContent;
      document.querySelectorAll('#lkPace .lkcard')[1].click();            // wait clean
      out.clean = { sel: C.selection, T: $('lkT').textContent, P: $('lkP').textContent, cards: cardTxt(), paceTxt: $('lkPaceTxt').textContent.slice(0, 300) };
      document.querySelectorAll('#lkPace .lkcard')[6].click();            // 2nd cut middle (cards: Any, 3 waits, Any, early, middle, late)
      out.cell = { sel: C.selection, T: $('lkT').textContent, P: $('lkP').textContent, cards: cardTxt(), paceTxt: $('lkPaceTxt').textContent.slice(0, 320),
                   start: ($('lkPaceTxt').textContent.match(/Start:.*$/) || [''])[0], anchors: [...$('lkAnchor').options].map(o => o.textContent) };
      const vims = 33.053 / 2, P0 = C.plans[0], T = A.run.T;
      const x = P0.variants.slice().sort((a, b) => b.w - a.w)[0], s = P0.series[x.s];
      let d = 0; while (s.n1[T + d + x.o - s.v0] < 0 && d < 40) d++;
      const i = T + d + x.o - s.v0, castT = T + d + 0.5, t1 = castT + s.b1[i];
      A.start(); A.run.wall0 = performance.now() - (castT - 1) * vims; A.registerCast(castT);
      A.run.wall0 = performance.now() - (t1 + 15 - 1) * vims; A.registerTap(t1 + 15);
      out.attempt = { fit: A.run.tapInfo.fit, p1: +A.run.tapInfo.p1.toFixed(3), truthNut1: s.n1[i], truthNut2: s.n2[i] };
      A.record(false, 'fish'); out.attempt.last = $('lkLast').textContent.slice(0, 200);
      const useIt = document.querySelector('#lkPaceTxt [data-start]');
      out.useIt = useIt ? useIt.dataset.start : null;
      if (useIt) useIt.click(); else { $('lkAnchor').value = 'pier'; $('lkAnchor').onchange({ target: $('lkAnchor') }); }
      out.pier = { sel: C.selection, T: $('lkT').textContent, P: $('lkP').textContent, cards: cardTxt(), how: $('lkHow').textContent.slice(0, 300),
                   start: ($('lkPaceTxt').textContent.match(/Start:.*$/) || [''])[0], anchors: [...$('lkAnchor').options].map(o => o.textContent) };
      $('lkRoute').value = 'nodog-zigzag-fast'; $('lkRoute').onchange({ target: $('lkRoute') });
      document.querySelectorAll('#lkPace .lkcard')[1].click();
      out.zigzag = { sel: C.selection, head: $('lkPaceHead').textContent.slice(0, 80), paceTxt: $('lkPaceTxt').textContent.slice(0, 300), P: $('lkP').textContent,
                     start: ($('lkPaceTxt').textContent.match(/Start:.*$/) || [''])[0], anchors: [...$('lkAnchor').options].map(o => o.textContent) };
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, 600);
})();
