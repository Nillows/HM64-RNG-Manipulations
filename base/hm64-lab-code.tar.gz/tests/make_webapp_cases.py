"""Simulated runners (strategy_lab) -> JSON test cases for the v28 web app core (node tests)."""
import json, random, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from tools.strategy_lab import Truth, simulate_runner
out, data_json, dest = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
strats = [json.loads(Path(p).read_text()) for p in sys.argv[4:]]
D = json.loads(data_json.read_text())
idx = {s: n for n, s in enumerate(D["arrival_sigs"])}
tr = Truth(out)
rnd = random.Random(7)
cases = []
for st in strats:
    for rep in range(150):
        i = rnd.choices(range(len(tr.sigs)), weights=tr.w)[0]
        if tr.sigs[i] not in idx:
            continue
        logs, _ = simulate_runner(tr, i, st, rnd)
        if not logs:
            continue
        runs = tr.runs[i]
        L = []
        for t, kind, v, trig in logs:
            r = next((q for q in reversed(runs) if q[0] <= t and (q[2] * 1000 + (q[3] if q[3] is not None else -999) == v
                                                                   if kind == "AD" else q[2] == v)), None)
            L.append({"t": t, "kind": kind, "value": v, "dir": r[2] if r else v // 1000, "base": r[4] if r else -1})
        k, o = D["arrivals"][idx[tr.sigs[i]]][:2]
        cases.append({"strategy": st["name"], "arrival": idx[tr.sigs[i]], "path": k, "offset": o, "logs": L})
dest.write_text(json.dumps(cases))
print(len(cases), "cases")
