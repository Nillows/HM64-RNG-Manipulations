/* headless (v29.5): Lucky Timer route "nodog-nohorse-no-pickup" (Thomas's dog-on-beach save, one dog line). Route switch,
   anchors (beach entry / pier-end READY), plan, an on-line attempt (cast + bite taps fit), an off-line one (bite fits no
   cast frame), per-route attempt log and line check, and back to the dog-carry route. */
(function () {
  setTimeout(() => {
    const A = window.HM64LuckyApp, C = window.HM64Lucky, $ = id => document.getElementById(id), out = {};
    ['hm64v29_lucky_taps', 'hm64v29_lucky_tally', 'hm64v29_lucky'].forEach(k => localStorage.removeItem(k));
    $('arLucky').click();
    A.L.audio = false; A.L.sigmaMs = 100; $('lkSigma').value = 100; $('lkSigma').onchange();
    out.routes = [...$('lkRoute').options].map(o => o.value);
    $('lkRoute').value = 'nodog-nohorse-no-pickup'; $('lkRoute').onchange({ target: $('lkRoute') });
    const vims = 33.053 / 2, P0 = C.plans[0], sec = t => +((t - 1) * vims / 1000).toFixed(2);
    out.sel = C.selection; out.anchors = [...$('lkAnchor').options].map(o => o.value);
    out.plan = { T: $('lkT').textContent, P: $('lkP').textContent, txt: $('lkPlanTxt').textContent, after: $('lkTAfter').textContent,
                 paceHidden: $('lkPace').hidden, routeNote: $('lkPaceTxt').textContent.slice(0, 160), how: $('lkHow').textContent.slice(0, 330),
                 delayLbl: $('lkStartDelayLbl').textContent, delay: $('lkStartDelay').value, r0: P0.r0, firstT: P0.firstT };
    document.querySelector('#lkPol button[data-pol="zone"]').click();
    const T = A.run.T, s = P0.series[P0.variants[0].s], o = P0.variants[0].o;
    out.zones = A.run.zone.zones.map(([a, b]) => [sec(a), sec(b)]);
    // on-line attempt: a cast frame near the aim, bite tap 15 VI after its bite
    let d = 0; while (s.n1[T + d + o - s.v0] < 0) d++;
    const i = T + d + o - s.v0, castT = T + d + 0.5, t1 = castT + s.b1[i];
    A.start(); A.run.wall0 = performance.now() - (castT - 1) * vims; A.registerCast(castT);
    A.run.wall0 = performance.now() - (t1 + 15 - 1) * vims; A.registerTap(t1 + 15);
    out.onLine = { bite1_s: sec(t1), truthNut1: s.n1[i], fit: A.run.tapInfo.fit, p1: +A.run.tapInfo.p1.toFixed(3), held: A.run.tapInfo.holdish, pNut2: +A.run.tapInfo.pNut.toFixed(3) };
    A.record(false, 'fish'); out.onLine.last = $('lkLast').textContent;
    // off-line attempt: the bite comes where no cast frame near the tap has one
    A.start(); A.run.wall0 = performance.now() - (castT - 1) * vims; A.registerCast(castT);
    const tau = castT + 300; A.run.wall0 = performance.now() - (tau - 1) * vims; A.registerTap(tau);
    out.offLine = { fit: A.run.tapInfo.fit, status: null };
    A.record(false, 'fish'); out.offLine.last = $('lkLast').textContent;
    out.tally = $('lkTally').textContent;
    // pier-end READY start: the same plan 328 VI earlier on the stopwatch
    const Tb = A.run.T; $('lkAnchor').value = 'pier'; $('lkAnchor').onchange({ target: $('lkAnchor') });
    out.pier = { sel: C.selection, T: $('lkT').textContent, dT: Tb - A.run.T, how: $('lkHow').textContent.slice(0, 120) };
    // back to the dog-carry route: its own log, pace cards back
    $('lkRoute').value = 'carry'; $('lkRoute').onchange({ target: $('lkRoute') });
    out.carry = { sel: C.selection, paceHidden: $('lkPace').hidden, cards: document.querySelectorAll('#lkPace .lkcard').length, tally: $('lkTally').textContent.slice(0, 120) };
    out.taps = A.taps.map(t => ({ route: t.route, anchor: t.anchor, c: t.c }));
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, 600);
})();
