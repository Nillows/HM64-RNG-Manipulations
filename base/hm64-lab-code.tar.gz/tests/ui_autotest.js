/* Injected into a copy of the built app for headless Chrome (virtual time). A scripted runner logs a hidden
   lab dog (fixed 17-VI delay) for `obs` s, then taps every change for `tapS` s (13-VI delay), picks `method`,
   generates the histogram and reports every method's clock error. `speed`: console faster by this factor. */
(function () {
  const Core = window.HM64Core, App = window.HM64App, D = Core.data;
  const q = new URLSearchParams(location.search), ai = +(q.get('arrival') || 0), obsS = +(q.get('obs') || 10);
  const tapS = +(q.get('tapS') || 6), method = q.get('method') || 'logs', f = +(q.get('speed') || 1);
  const [k, o, w, head] = D.arrivals[ai];
  const vi = Core.viMs(), t0 = performance.now() + 500;               // READY
  const wallOf = t => t0 + t * vi / f;                                  // true VI after READY -> wall time
  const show = t => Core.showAt(k, t + o, head && head.length ? ai : -1);
  const plan = [];
  let prev = show(1).val;
  plan.push({ t: 18, s: show(1) });
  for (let t = 2; t < obsS * 60; t++) { const s = show(t); if (s.val !== prev && s.val >= 0) { plan.push({ t: t + 17, s }); prev = s.val; } }
  plan.forEach(p => setTimeout(() => { App.setFacing(p.s.dir); App.logAD(p.s.base); }, wallOf(p.t) - performance.now()));
  const tEnd = plan[plan.length - 1].t + 20, tTapEnd = tEnd + tapS * 60;
  const taps = Core.changesIn(k, tEnd + o, tTapEnd + o).map(c => c - o + 13);
  taps.forEach(t => setTimeout(() => App.tap(), wallOf(t) - performance.now()));
  setTimeout(() => {
    App.setMethod(method);
    const g = App.st.groups[0];
    App.generate();
    const h = App.st.hist, truthNow = (performance.now() - t0) / vi * f + o;
    const err = {};
    for (const [m, x] of Object.entries(h.methods)) err[m] = x === null ? null : +(x - truthNow).toFixed(2);
    const out = { arrival: ai, path: k, logs: App.st.logs.length, taps: App.st.taps.length, top_path: g.k, top_mass: +g.mass.toFixed(4),
      auto: App.st.auto, used: h.method, errors: err, fitWarn: !document.getElementById('fitWarn').hidden,
      targets: h.targets.map(b => ({ in_s: +(b.dVI * vi / 1000).toFixed(2), p: +b.p.toFixed(3) })) };
    if (App.st.armed) {
      const a = App.st.armed, v = Math.floor(truthNow + a.b.dVI * f);
      const c = Core.castAt(k, v); out.true_outcome_on_target = c ? (c.n1 ? 'nut' : 'fish') : 'unknown';
    }
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, wallOf(tTapEnd + 10) - performance.now());
})();
