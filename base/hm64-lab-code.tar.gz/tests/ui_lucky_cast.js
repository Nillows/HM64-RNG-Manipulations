/* headless (v29.3): Fast pace, 1st-bite plan. Start key at the dog landing, again with B (cast tap), again at the bite;
   outcome keys H / M / E; the "last attempt" diagnosis and the profile's bite-tap reaction. */
(function () {
  setTimeout(() => {
    const A = window.HM64LuckyApp, C = window.HM64Lucky, $ = id => document.getElementById(id), out = { attempts: [] };
    ['hm64v29_lucky_taps', 'hm64v29_lucky_tally', 'hm64v29_lucky'].forEach(k => localStorage.removeItem(k));
    $('arLucky').click();
    A.L.audio = false; A.L.sigmaMs = 100; $('lkSigma').value = 100; $('lkSigma').onchange();
    A.setSelection('fast', 'dog');
    document.querySelector('#lkPol button[data-pol="bite1"]').click();
    const vims = 33.053 / 2, P0 = C.plans[0], T = A.run.T;
    out.T = +((T - 1) * vims / 1000).toFixed(2); out.nutBites = A.nutBites().map(([a, b]) => [+((a - 1) * vims / 1000).toFixed(2), +((b - 1) * vims / 1000).toFixed(2)]);
    out.how = $('lkHow').textContent.match(/Nut bite can only come at [^:]*/)?.[0];
    // scenarios at the aim: one Nut-bite frame and one fish-bite frame (known truth)
    const at = want => { for (const x of P0.variants.slice().sort((a, b) => b.w - a.w)) { const s = P0.series[x.s]; for (let d = -4; d <= 4; d++) { const i = T + d + x.o - s.v0; if (i >= 0 && i < s.len && s.n1[i] === want && s.n2[i] >= 0) return { x, s, i, d }; } } };
    const plan = [[at(1), 'empty', 26], [at(1), 'fish', 21], [at(0), 'fish', 15], [at(1), 'nut', 15]];
    for (const [sc, kind, lagVI] of plan) {
      A.start();
      const castT = T + sc.d + 0.6, t1 = castT + sc.s.b1[sc.i], tau = t1 + lagVI;
      A.run.wall0 = performance.now() - (castT - 1) * vims;
      out.castLogged = A.registerCast(castT);
      A.run.wall0 = performance.now() - (tau - 1) * vims;
      A.registerTap(tau);
      const ti = A.run.tapInfo;
      const r = { truthBite1Nut: sc.s.n1[sc.i], kind, p1: ti && +ti.p1.toFixed(3), lagShownMs: ti && ti.sum ? Math.round(ti.sum.lag * vims) : null, trueLagMs: Math.round(lagVI * vims) };
      A.record(kind === 'nut', kind);
      r.last = $('lkLast').textContent;
      out.attempts.push(r);
    }
    out.tally = $('lkTally').textContent.slice(0, 260);
    out.taps = A.taps.map(t => ({ c: t.c, tau: t.tau }));
    out.profile = $('lkProfile').textContent.slice(0, 400);
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, 600);
})();
