// node tests/test_webapp_taps.js DATA.json CASES.json -> how well bare taps ("the dog changed now") find the dog
// Simulated runner: first input at READY (10-40 VI after), then reacts to every visible change (new pose or facing
// lasting >= 12 VI). Taps: delay ~N(13,3) VI; animation+direction logs: uniform 10-25 VI (strategy-lab runner).
// Misses: 15% of changes not tapped; false taps: 1 per 20 s.
const fs = require('fs');
const Core = require('../webapp/hm64_core_v28.js');
const D = JSON.parse(fs.readFileSync(process.argv[2]));
const cases = JSON.parse(fs.readFileSync(process.argv[3]));
Core.prepare(D, { reactMuVI: 17.5, reactSdVI: 4.5, tapMuVI: 13, tapSdVI: 3 });
let seed = 7; const rnd = () => { seed = (seed * 1103515245 + 12345) % 2147483648; return seed / 2147483648; };
const randn = () => { let u = 0, v = 0; while (!u) u = rnd(); while (!v) v = rnd(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };
const MISS = +(process.argv[4] || 0.15), FALSE_PER_S = +(process.argv[5] || 0.05);
const uniq = cases.slice(0, +(process.argv[6] || 300));

const STRATS = {
  'AD logs (animation+facing key)': 'AD',
  'taps only (one button)': 'T',
  'taps + facing (arrows held, then tap)': 'TD',
  'AD at READY, then taps only': 'ADT',
};
const H = [5, 10, 20, 30];
const res = {};
for (const cs of uniq) {
  const [k, o, , head] = D.arrivals[cs.arrival];
  const hi = head && head.length ? cs.arrival : -1;
  const show = t => Core.showAt(k, t + o, hi);
  const T = 30 * 60 + 40;
  const vals = []; for (let t = 1; t <= T + 60; t++) vals.push(show(t));
  const changes = [];
  for (let t = 2; t < T; t++) {
    if (vals[t - 1].val === vals[t - 2].val || vals[t - 1].val < 0) continue;
    let L = 1; while (t - 1 + L < vals.length && vals[t - 1 + L].val === vals[t - 1].val) L++;
    if (L >= 12) changes.push({ t, s: vals[t - 1] });
  }
  const u0 = 10 + Math.floor(rnd() * 31), s0 = vals[u0 - 1];
  for (const [name, mode] of Object.entries(STRATS)) {
    const logs = [];
    if (mode === 'AD' || mode === 'ADT') logs.push({ kind: 'AD', base: s0.base, dir: s0.dir, value: s0.val, t: u0 });
    else logs.push({ kind: 'T', dir: mode === 'TD' ? s0.dir : undefined, t: u0 });
    for (const c of changes) {
      if (c.t <= u0) continue;
      if (rnd() < MISS) continue;
      if (mode === 'AD') logs.push({ kind: 'AD', base: c.s.base, dir: c.s.dir, value: c.s.val, t: c.t + 10 + Math.floor(rnd() * 16) });
      else logs.push({ kind: 'T', dir: mode === 'TD' ? c.s.dir : undefined, t: c.t + Math.max(6, Math.round(13 + 3 * randn())) });
    }
    if (mode !== 'AD') for (let t = u0; t < T; t += 60) if (rnd() < FALSE_PER_S) logs.push({ kind: 'T', dir: mode === 'TD' ? vals[t].dir : undefined, t });
    logs.sort((a, b) => a.t - b.t);
    for (const h of H) {
      const L = logs.filter(l => l.t <= u0 + h * 60);
      const cl = L.map((l, n) => ({ kind: l.kind, base: l.base, dir: l.dir, value: l.value, dVI: l.t - u0, first: n === 0 }));
      Core.recompute(cl);
      const g = Core.groups()[0];
      const r = res[name + '|' + h] = res[name + '|' + h] || { n: 0, right: 0, sel: 0, wrong: 0, err: [], logs: 0 };
      r.n++; r.logs += L.length;
      if (g.k === k) { r.right++; r.err.push(g.mean + cl[cl.length - 1].dVI - (L[L.length - 1].t + o)); }
      if (g.mass >= 0.95) { r.sel++; if (g.k !== k) r.wrong++; }
    }
  }
}
console.log(`${uniq.length} simulated runners · ${100 * MISS}% of changes missed · ${FALSE_PER_S * 20} false tap per 20 s`);
for (const name of Object.keys(STRATS)) {
  console.log('\n' + name);
  for (const h of H) {
    const r = res[name + '|' + h], e = r.err;
    const rms = Math.sqrt(e.reduce((a, x) => a + x * x, 0) / Math.max(1, e.length));
    console.log(`  after ${String(h).padStart(2)} s: ${(r.logs / r.n).toFixed(1).padStart(4)} inputs · right dog on top ${(100 * r.right / r.n).toFixed(0).padStart(3)}% · ` +
      `auto-selected ${(100 * r.sel / r.n).toFixed(0).padStart(3)}% (wrong ${r.wrong}) · clock RMS ${rms.toFixed(1)} VI`);
  }
}
