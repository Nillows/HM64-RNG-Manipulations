/* headless check of the Lucky Timer arena: keys stay in their arena, start/miss/hit flow, plans and zones present */
(function () {
  const key = k => document.dispatchEvent(new KeyboardEvent('keydown', { key: k, bubbles: true }));
  setTimeout(() => {
    const A = window.HM64LuckyApp, O = window.HM64App, out = {};
    localStorage.removeItem('hm64v29_lucky_tally');
    document.getElementById('arLucky').click();
    A.L.audio = false;
    out.arena_lucky_visible = !document.getElementById('luckyArena').hidden && document.getElementById('oracleArena').hidden;
    out.plans = A.plans.map(p => p.label);
    out.plan = A.run.plan.label; out.policy = A.run.pol; out.T_s = +((A.run.T - 1) * 33.053 / 2000).toFixed(2);
    out.zones = A.run.zone ? A.run.zone.zones.length : 0;
    out.p_shown = document.getElementById('lkP').textContent;
    key(' '); out.started = A.run.wall0 !== null;
    key('z'); out.oracle_logs_while_lucky = O.st.logs.length;
    key('m'); out.stopped_after_miss = A.run.wall0 === null;
    out.tally_text = document.getElementById('lkTally').textContent.slice(0, 60);
    key(' '); key('h'); out.result = A.run.result;
    document.getElementById('arOracle').click();
    key('z'); out.oracle_logs_after_switch = O.st.logs.length;
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, 400);
})();
