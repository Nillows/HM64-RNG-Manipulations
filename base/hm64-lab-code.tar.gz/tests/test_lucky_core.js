// node tests/test_lucky_core.js DATA.json [sigmaMs,...] -> best Lucky Timer plans per policy + timing
const fs = require('fs');
const LC = require('../webapp/hm64_lucky_v29.js');
const D = JSON.parse(fs.readFileSync(process.argv[2]));
const viMs = 33.053 / 2;
const sigmas = (process.argv[3] || '100,150,250').split(',').map(Number);
let t0 = Date.now();
const plans = LC.prepare(D, viMs);
console.log(`prepare ${Date.now() - t0} ms, plans: ${plans.map(p => p.label + ' (' + p.variants.length + ' variants, cover ' + (100 * p.cover).toFixed(1) + '%)').join(', ')}`);
const s = t => ((t - 1) * viMs / 1000).toFixed(2) + ' s';
const out = {};
for (const sm of sigmas) {
  for (const p of plans) {
    t0 = Date.now();
    const b = LC.best(p, sm / viMs, 30);
    const ms = Date.now() - t0;
    const z = LC.zoneAt(p, b.zone.t, sm / viMs, sm / viMs, true);
    out[`${p.k}/${sm}`] = { bite1: [b.bite1.t, +b.bite1.p.toFixed(4)], hold: [b.hold.t, +b.hold.p.toFixed(4)], zone: [b.zone.t, +b.zone.p.toFixed(4)] };
    console.log(`σ ${String(sm).padStart(3)} ms  ${p.label.padEnd(11)} bite1 ${s(b.bite1.t)} ${(100 * b.bite1.p).toFixed(1)}%  ` +
      `hold ${s(b.hold.t)} ${(100 * b.hold.p).toFixed(1)}%  zone ${s(b.zone.t)} ${(100 * b.zone.p).toFixed(1)}% ` +
      `(${z ? z.zones.length : 0} zones; at that time bite1 ${(100 * z.bite1).toFixed(1)}% hold ${(100 * z.hold).toFixed(1)}%)  [${ms} ms]`);
  }
}
if (process.argv[4]) fs.writeFileSync(process.argv[4], JSON.stringify(out));
