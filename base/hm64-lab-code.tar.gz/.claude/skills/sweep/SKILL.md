---
name: sweep
description: Run an experiment module over many jobs in parallel (seed indices from a load anchor, or the module's own jobs() grid) and file the results properly.
argument-hint: "<experiments/module.py> [--start N --count K] [--workers W]"
disable-model-invocation: true
---

Arguments: `$ARGUMENTS`

1. Create `results/<YYYY-MM-DD>-<module-name>[-suffix]/` and copy the
   experiment module into it.
2. Pilot: run `python3 tools/seed_sweep.py <module> ...` with the same args but
   `--count 4` (or the first 4 jobs) into `pilot.jsonl`. Check for `_error`
   rows and that outputs look sane. Report the measured rate (jobs/s).
3. Estimate the full runtime from the pilot rate. If it is over ~30 minutes,
   say so and propose a smaller first pass before continuing.
4. Run the full sweep into `raw.jsonl`, saving the exact command in
   `command.txt`.
5. Write `README.md` there: hypothesis, starting state (path + sha256),
   parameters, row count, error count, 3-5 headline observations, and what
   the run does NOT establish. Then suggest handing the data to the
   `rng-analyst` subagent.
