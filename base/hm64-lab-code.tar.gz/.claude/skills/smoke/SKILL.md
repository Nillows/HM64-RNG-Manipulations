---
name: smoke
description: Run the HM64 lab health check (determinism, savestates, seed-poke equivalence, dog model, renderer parity, QuickSave2 Nut regression) and report the result.
disable-model-invocation: true
---

Run `python3 tools/smoke_test.py $ARGUMENTS` from /work (pass `--quick` to skip
the slower checks).

Then report each check as PASS / FAIL / SKIP in a short table.

- If any check FAILS: show the failing detail, look at the most recent change
  under `m64h/`, `native/`, `hm64/` or the Docker image, and propose the
  smallest fix. Do not run experiments until it passes.
- If `qs2` is SKIPPED, tell Thomas to put
  `Harvest Moon 64 (USA).Mupen64Plus.QuickSave2(1).State` in
  `data/states_bizhawk/` and run `make qs2`.
- If `save` is SKIPPED, the boot checks cannot load a diary; ask for the SaveRAM.
