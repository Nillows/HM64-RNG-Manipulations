---
name: new-experiment
description: Scaffold a new HM64 experiment module from a plain-language question, following the lab's conventions (load anchors, poll schedules, DogObserver, results hygiene).
argument-hint: "<question to answer>"
disable-model-invocation: true
---

Question: $ARGUMENTS

1. Restate it as a measurable hypothesis and say which starting state answers
   it: a LOAD anchor (`states/load_diary*.st`, seed sweeps allowed) or a fixed
   state such as `states/qs2.st` (vary real inputs only).
2. If it depends on game logic you have not checked, ask the `decomp-analyst`
   subagent first and cite what it finds in the module docstring.
3. Copy the closest example (`experiments/dog_observation.py` for seed sweeps,
   `experiments/qs2_whistle_cast_grid.py` for input grids) to
   `experiments/<short_name>.py`. Keep `job(emu, j)` pure: load state, apply
   inputs, measure, return a JSON-serialisable dict. Use `emu.schedule_polls`
   (before `load_state`) for poll-exact input.
4. Run 2 jobs directly to make sure it works, then hand off to `/sweep`.
