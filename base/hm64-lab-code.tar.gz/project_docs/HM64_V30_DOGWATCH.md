# HM64 v30 — Dog-watch: the Dog Oracle inside the Lucky Timer (design + lab, 2026-11-16)

Thomas (2026-11-16 12:06): the next stage is to harmonize both halves. While the runner waits at the dock end after
READY, he logs the dog's animations (Dog Oracle keys: a letter for the animation, an arrow / numpad for the facing),
and the app narrows the dog line — hence the RNG path — before the cast. Experimental, behind a Settings checkbox,
until raw lab data backs it. Start of version 30. Lab first, "even from the ground up".

## Why it can work (game facts)
- Every dog decision draws from the one RNG (seed 0x8013CDF0) that later rolls the bite and the Nut. A dog line =
  one RNG trajectory from READY on, so the dog's visible behaviour after READY is a readout of the line.
- dogInfo (0x801886B0): +0x17 actionState (the NEXT state), +0x18 direction, +0x1A stateTimer. Decisions happen at
  animation-cycle ends with stateTimer 0 (`updateDog`). What a person sees = entity sprite base (+0x54) + screen
  facing (+0x67) → visual class; displayed animation +0x56.
- Lag model (Thomas: "check backwards slightly for the state that caused that animation"): the runner logs at τ; the
  change on screen began r = 10–25 VIs earlier (reaction); the decision that chose it is at that change (lab pilot:
  decision → visible change median 0 VI, p10 0, p90 30 VI). So a log is matched to a visible onset in
  [τ − 25 − tol, τ − 10 + tol] VIs on each candidate line's trace (tol = 2 × clock spread); the decision (and its RNG
  draw) is read off the same trace, not guessed.

## Lab: the dog-watch run (lab code zigzag-4d)
- Preset `dogwatch` (tools/zigzag_campaign.py): beach-lineup2 save (dog at x −198.5, z 223.5, on screen from the dock
  end), menus 0–9 game frames late (house 0–18 VIs after the fastest, VI 1036 = fast + sparrow mornings), house / farm /
  crossroads / ranch within 8 / 8 / 6 VIs, D 84 / 86, beach wait 0–30, B 112–151 (full pier), `observe`: Z6 records per
  dog line 40 s after READY with no input: visible runs [k0, k1, screen facing, class, base], displayed animation,
  dogInfo (k, act, dir, timer), dog RNG draws, position, visibility grid (experiments/zigzag_jobs.py `obs_pack`).
  Then fast cast tables 0.1–40 s, bites 1 and 2.
- Runner `run_hm64_dogwatch.sh` (package hm64-powernut-lab_dogwatch_2026-11-16.zip, tarball hm64-lab-dogwatch.tar.gz,
  queues on runs/dogspots/.running, own state store states/dogwatch/<label>, results/dogwatch/beach-lineup2-52cfd712):
  phase 1 Z1–Z6 + DOGWATCH.md (early zip), phase 2 renders of the dock-end view (B 118/124/130/138, 10 s, a frame per
  0.5 s → render/B*/sheet.png), phase 3 casts + DOGWATCH.md with odds. HM64_DOGWATCH_PHASES=1 stops after 1–2.
- Report `tools/dogwatch_report.py`: simulated runners (changes ≥ 12 VI logged, reaction U(10, 25) VI, 15% missed, clock
  ±3 VI, hard elimination) for three alphabets (animation + facing, animation only, bare Space taps) and windows
  3/5/10/15/20 s; Nut odds no logs → logs → line known (cast ≥ 2 s after the window, ±150 ms). Also writes
  dogwatch_traces.json = what a v30 app would load per route (variants + per-line visible runs + decisions).

## Sandbox pilot (dogwatch-test: U276 V52 C80, 2 mash rates, 26 lines, 342 variants, 25 s traces)
- The dog is on screen from the dock end but sits at the lower-left edge, half under the black map border, a few
  pixels tall (renders at B 118/124/138). CRT overscan may hide it: Thomas checks readability on his TV first.
- It stays on its tile (moves median 0 units), ~60 visible changes / min, 90% of them last ≥ 12 VI.
- Logging 5 s: animation + facing → right line on top 90% (posterior 85%, 1.7 lines left); animation only 89%; bare
  taps need ~10 s (87%). Taps alone are the fallback when the animation can't be read.
- Pilot animation shares of the wait (route-weighted): idle 22.5%, stand (base 32) 15.5%, sit 11.1%, rollover 7.7%,
  shoulder-sitting 5.2%, walk 4.8%, run 3.9%, bork 3.8%, shoulder-standing 3.2%, sniff-standing 3.0%, the rest < 3%.
  Facings on screen: 1 (41%), 7, 5, 3, 4, 6, 2.

## App design (v30, mockups: Design canvas "HM64 v30 — Dog-watch + Lucky Timer layouts")
- One key rule: a key means what the phase says. Before the dock end: Space = route taps, S = sparrows. DOCK END ✓ →
  HANDS ON B (default 2 s before the cast): letters = dog animations (S, H, E included), arrows / numpad = facing (top-row
  digits stay animation keys), Space = "it changed", Backspace = undo. After the cast: Space = bites, H / M / E = result.
- Live: each log re-weights the (line, k_off) variants (same matching as the report), L1 / the cast re-aim like the
  dock-end tap (only while ≥ 3 s away), frozen at HANDS ON B. The attempt stores the logs (lab can check them against
  the line the bites point to).
- Layouts (Settings → Dog-watch → Layout): Full board (lamp + lines left + logs-vs-lines timeline + key strip) or Lamp
  first (giant countdown to HANDS ON B, last 5 logs, top line + odds). Reading level: animation + facing / animation
  only / changes only (Space).
- Settings page "Dog-watch": the checkbox (off), layout, reading level, hands-on lead, reaction look-back (170–420 ms),
  facing pad, animation palette (shared with the Dog Oracle; flickers < 0.35 s — sprint, squat, good-boy,
  sniff-sitting, flapper — are logged with Space).

## Thomas's TV check and logging model (2026-11-16 13:31)
- Readable at the lineup2 dock end: facing changes in every direction; distinct animations (sniff, bark, sleep, …)
  while the dog faces N, S or any eastern direction. West-facing animations are unreliable (screen facings SW, W, NW =
  +0x67 values 1, 2, 3).
- His logging plan: letters only for the longest-lasting animations; arrows to follow the dog's facing, the time it
  keeps each facing being the signature; Space at the bite as now (a bite tap is only as good as its bite cluster).
  Goal: early duds — certain animations at certain times mark a dud line, so he resets before casting.
- Report (tools/dogwatch_report.py, same day): alphabets `thomas` (arrows at every facing change + letters for animations
  >= 1 s that start in a readable facing, READABLE = {S, N, NE, E, SE}) and `facing` (arrows only); with cast tables, a
  dud section: reset when the best cast for what the logs leave is under 5% / 8% (attempts called dud, Nut on kept
  attempts, Nut thrown away) and an "early dud signs" table (what you log in each 1-s slot after READY: share of
  attempts showing it, share of those on dud lines). Runs on any observe results folder; the Mac zip has everything.
- Pilot (26 lines, 25 s, no casts) under his readability: the dog faces SW 41% of the wait (S/N/NE/E/SE together 46%),
  so few letters get logged. Right line on top: 5 s 25%, 10 s 44%, 15 s 61% (vs 86 / 90 / 90% with every facing
  readable). Ablation (experiments/dogwatch_ablate.py): the >= 1 s rule costs nothing (all facings, long only: 86 / 90 /
  90%); readable facings with any length: 26 / 44 / 64%; adding SW alone: 72 / 79 / 84%. Arrows only: 17 / 32 / 52%.
  So the west-facing blind spot, not the long-only rule, is what limits it at this spot — open question: is SW
  (down-left, three-quarter view) readable on his TV?

## Input scheme decided by Thomas (2026-11-16 13:59): the facing gear
- The dog's facing is always readable and easy to spot → the runner logs every facing change on an 8-way "gear":
  arrow keys or WASD (Settings), diagonals = both keys. Rule: the first key makes the log at its own time; a second,
  orthogonal key pressed while the first is still down (within 0.25 s) turns that same log into the diagonal (time
  kept), so ↑ then ← is NW, never N then W; released and pressed again = a new turn. One arrow as the watch starts
  gives the starting facing. No press = still the same facing (the app counts every turn a candidate line has but the
  runner did not log as a miss).
- Reactive, like a bite tap: the look-back leeway is the bite-tap reaction from L5 (one number for every surprise).
- Animations: numpad 0–9 only (e.code Numpad0–9, so NumLock / Mac "clear" do not matter; top-row digits ignored while
  watching), at most 10 groups. Default: 0 idle, 1 sit, 2 stand, 3 rollover, 4 walk, 5 run (+ sprint), 6 sleep,
  7 sniff (sniff-standing, sniff-sitting, smell), 8 bark (bark, bork), 9 shoulder (shoulder-sitting, -standing). Only
  for animations lasting about 1 s or more while the dog faces S, N or east. The run ranks which ten are worth a key.
- Space only for the clock taps and the bites (no "it changed" tap).
- Report alphabets `gear` (arrows + numpad, starting facing, unlogged turns count as misses at 10%) and `gear-arrows`.
  Pilot (26 lines, 25 s): right line on top — gear 5 s 29%, 10 s 57%, 15 s 74%; gear arrows only 29 / 53 / 62%
  (20 s 71%); the same arrows without "no press = same facing" 14 / 35 / 48%. The dog turns rarely here (~0.3 logged
  turns in the first 10 s), so the starting facing and "still the same" carry most of it.

## The Mac run's order and time (started 2026-11-16 ~13:5x)
One pass, both morning bands together (fast + sparrow mornings share most beach states and dog lines, so each line is
simulated once): Z0 repeat check + CPU core → Z1 menus → Z2 house → Z3 farm / crossroads → Z4 ranch → Z5 beach (D 84 / 86 ×
waits × every 2nd cut) → Z6 dog lines + traces → DOGWATCH.md early + early zip → 4 renders → Z7 casts 0–20 s (every
line, heaviest first) → Z8 member checks → Z7 casts 20–40 s → Z8 → final report + zip. The split by morning (sparrows at
the door or not) comes afterwards from the same data (as for dog-beach's door-sparrow table). Estimate: phase 1
~1.5–2.5 h, renders ~15 min, each cast half ~2–2.5 h → ~6–8 h in all (the README's 4–5 h was low: lineup2 alone took
~3 h + 110 min for D 84 + D 86 on the fast band). Each stage prints jobs/s and an ETA.

## Menus 0–6 frames late only (2026-11-16 14:16, lab code zigzag-4e)
- Thomas: keep only menus 0–6 game frames late, so "sparrows at the door" is a decisive rule; slower is too slow.
- Sparrows = start-of-day roll (`randomizeMiscAnimalSpawnVariants`, slot 4, at startGame before the house loads) →
  fixed by the menu timing alone (farm load not winter, sunny, 6–8 am); not a threshold but a roll per frame.
  Beach-lineup2 save, all 144 dogwatch menu configs (experiments/sparrow_menus.py, sandbox) — identical to dog-beach:
  0 far pair · 1 none · 2 none · 3 far pair · 4 none · **5 door** · **6 door** · 7 far · 8 none · 9 none · 10 door ·
  11–13 none · 14 door · 19 door (frames late; house VI = 1036 + 2 × frames). The far pair is off screen on this route.
  In 0–6: door pair ⇔ 5–6 frames late. Outside it, door sparrows also mean 10 / 14 / 19 frames late (out of the tables).
- Preset `dogwatch` house_slack 18 → 12 (VI 1036–1048; sandbox Z1: 7 of 16 house arrivals kept). Package
  hm64-powernut-lab_dogwatch06_2026-11-16.zip (run_hm64_dogwatch06.sh, hm64-lab-dogwatch06.tar.gz): continues the same
  work / results / state folders; rows already made for 1050–1054 are ignored by every stage (all filter by hkeep).

## Every bite, not two (2026-11-16 14:31, lab code zigzag-4f)
- Thomas: no reason to stop at two bites; bites can come seconds apart; use every bite in the forecast time. Holding B
  through a bite re-casts by itself (phase 5 → 1 → 2), so with the cast frame pinned by the bite taps the whole bite
  sequence and which bite (if any) is the Nut are deterministic: the app can say "hold, release at bite 5".
- `eval_cast(hold_until, always_bites=2, probes_more=(4,))`: bites 1–2 as before (probes 4 and 12, no time limit),
  then every later bite that shows by `hold_until`, one release probe each (every release in the window gives the same
  catch, 1,824/1,824). `zz_cast_job` passes `bites_max` / `bite_until` (VIs after READY); preset dogwatch: 16 bites,
  to 90 s after READY (`HM64_ZZ_BITE_UNTIL=<seconds>` overrides). Z7 rows keep the same shape (more entries in
  `bites`); zigzag_report still reads bites 1–2, the extra ones are for the v30 forecast.
- Sandbox (pilot line c16e…, 4 casts): first two bites identical to the old job; to READY + 60 s 2–3 bites, 15.9 s vs
  12.3 s; to READY + 90 s 4–7 bites (5.2 on average over a 16-cast test), 25.0 s ≈ 2× the cast time. Gaps between bites
  run from ~2 s to ~47 s. Package hm64-powernut-lab_dogwatch-allbites_2026-11-16.zip (run_hm64_dogwatch06b.sh,
  hm64-lab-dogwatch06b.tar.gz), continuing the same folders; estimate ~9–11 h for the whole run.

## Open
- Is the SW facing (down-left) readable on Thomas's TV? (Answered 13:59 for facings in general: always readable;
  animations still only while facing S / N / east.) It is 41% of the wait in the pilot. If west-ish facings stay
  unreadable: a dog spot where the dog faces east / south more, or one nearer the pier end.
- The real numbers come from the Mac run (all mornings, both first cuts, full pier width).
- A dog-watch practice mode (reaction to a dog change, for the look-back) once the palette is fixed.

## App before v30 — Lucky Timer: Space inferred by time, one-reaction auto-tune, NaN fix (v29.9, 2026-11-16, 5th build)
Thomas: B vs Space was unclear, and the tool should tell what each Space press is without a held key. B always = the
N64 controller's B; Space = the keyboard tap. Every Space is classed by time (unchanged mechanics, now said plainly in
L3 and in the how-to doc "HM64 Lucky Timer v29.10 — how to use and calibrate"): stopwatch off → start; start .. 1.5 s
before CAST → route taps (assigned to the strategy's cues; misses skipped, strays ignored); 1.5 s before .. 0.6 s after →
nothing (cast tap only if turned on); from the plop → bite 1, 0.4 s later → bite 2. The cast tap stays optional (off).
- **Bug (all builds since the cast-cue correction):** stored taps keep the CAST cue's sub-VI time (aim + correction /
  VI); LuckyCore.tapPosterior used that fractional T as an index → Z NaN → the profile (auto-tune, "Best for me"
  re-weighting) learned nothing from bite taps whenever the correction was not a whole VI. Fixed (T rounded inside
  tapPosterior); stored taps are re-read correctly by the new build.
- **One-reaction tie, corrected:** start tap k VIs later than the start-tap delay d → the stopwatch runs k behind the
  console → b = p + k (p = B press vs CAST from practice) and the bite-tap lag in stopwatch terms = d exactly (not
  d + k as first written). 1-D fit over k; applied as round(0.7 k) (shrunk: bite taps slower than start taps push k
  up by about half the difference). Lab sim (experiments/sim_timing_double.js style, start taps +50 ms, 24 attempts):
  untuned landing ~+60 ms; bite taps as late as start taps → +27 ms (unshrunk +14); 100 ms slower → −35 ms (unshrunk
  −56). With the cast tap (no assumption): +16 ms. Needs 5 cast-practice presses + 8 attempts with a bite tap.
- L3 key line, L5 learn label, Settings cast-tap label and the bite messages now say "B (controller)" / "Space".
(Same section in HM64_DOGBEACH_SAVE.md of the lab code.)
