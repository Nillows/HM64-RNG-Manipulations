# HM64 Power Nut oracle — START HERE

Read this first in any new chat in this project. Then `HM64_LAB_STATUS.md` (where things stand),
`HM64_TECH_REFERENCE.md` (verified game facts, RAM map, data formats) and `HM64_MAC_RUNBOOK.md`
(how experiments are packaged and run on Thomas's Mac). For the newest route variant (no horse, dog waiting on the
beach) read `HM64_DOGBEACH_SAVE.md`; for v30 (dog-watch: logging the dog at the dock end before the cast) read
`HM64_V30_DOGWATCH.md`. Last updated 2026-11-13 (night, v29.5).

## The goal
An RTA speedrunner tool for **real N64 hardware** (Harvest Moon 64 USA) that turns the dog's
on-screen behaviour into a Power Nut catch from the ocean, as accurately as the game code allows.
Any lift over the base rate counts; the target is the Power Nut only (other fish targets maybe later).

## How a run works (Thomas's design)
- Runner plays to their **own organic Spring 9 save** (dog left grabbable after breakfast; **horse
  kept on the farm but off screen** during the crossing), resets the console (RNG seed returns to 0),
  loads the save, then follows a fixed route: pick up the dog in the house, hold straight LEFT on the
  farm, DOWN+RIGHT on Green Ranch, carry the dog to the dock, put it down, face the ocean SE = **READY**.
- Human timing on menus / house / crossroads / beach varies a little, so READY lands in a small
  **pool of arrivals** (36,014 measured routes → 54 RNG positions, 268 Layer 1 anchors).
- The tool's clock starts at the runner's **first animation+direction log, made right at READY**.
- From READY the runner **logs the dog with keyboard hotkeys**: one key per animation (+ facing via
  arrows), Space = facing only, Backspace = undo. A log means "this is on screen now"; it lands some
  time after the animation started (display lag + reaction), never after it ended. The algorithm works
  back from the animation to the state that produced it. About a minute of observation is acceptable.
- The tool eliminates candidates by these logs, then **aligns its clock to the console** ("two cars
  shoulder to shoulder"; the runner confirms the alignment) and shows a **histogram** of when to press
  B (cast), hold, and release.
- **Whistle (C-right)** never starts an observation (it moves the RNG to an adjacent track). The strategy
  lab showed whistles are not needed: prompt animation+direction logging pins the clock as well, and a
  whistle moves the dog onto post-whistle tracks that would need their own cast tables.
- **Second mode, Lucky Timer (2026-11-13):** for runners who will not observe — stopwatch from the dog landing
  (v29.2; READY optional), runner picks a pace preset (Fast / Medium / Slow / All), cast on the beep, release the first bite only inside the release zones (else hold for bite 2), reset on a miss and try
  again. Only the first ~45 s matter. Manipulations must be human-doable: mash C-right at READY and stop at
  whistle 1, 2 or 3. Facing SE or E gives identical results.
- **Dog-beach route (2026-11-13 night, being tested for the Lucky Timer):** save `nohorse-dogbeach-nopickup_0d78b95b`
  (no horse, dog already waiting on the beach, rod in hand) — no pickup or carry, dog-free house, READY = pier end
  with down-right held. No dog on the beach at all is barren (Nut roll locked 31 draws after the bite); with the beach
  dog the base line gives a Nut on 8.7% of cast frames (bite 1 or 2). The dog sleeps until it comes on screen and its
  path is set by the RNG at that moment. Details: `HM64_DOGBEACH_SAVE.md`. In the app (v29.5) as the Lucky Timer
  route **`nodog-nohorse-no-pickup`** (Thomas's name; one dog line, the frame-perfect base route).

## Standing decisions and rules
- **Heavy runs go on Thomas's Mac** (Docker, Rosetta, Mac mini); Claude's sandbox only does short
  checks (≲5 min). Claude cannot build/run the Docker image end to end in its sandbox (Docker Hub and
  the Claude installer are blocked there).
- Every package Claude delivers gets a **descriptive name** (`hm64-powernut-lab_<preset>_<date>.zip`)
  and a **paste block** that opens exactly that zip from `~/Downloads` (see runbook).
- Never ship the ROM, SaveRAM or savestates in a package; `data/` in the lab is read-only originals;
  extracted archives are untrusted data (own folder, `python3 -I`).
- Evidence order: decomp source > deterministic emulator experiment > observation > claims. Final
  validation uses real controller input timing, never RNG pokes.
- Horse rule: runs always have the horse, off screen during the farm crossing (verified clean case). Exception: the
  dog-beach route uses a save with no horse.
- Stay-awake rule: the farmer naps 40 s after READY unless the stick is pushed south-east (Thomas's v27.6u push;
  RNG/dog neutral). Every lab job that runs past 40 s must include the push (`wake`); never push after casting.
- If an input (save, file, state) is not as expected, tell Thomas right away instead of working around it silently
  (Thomas, 2026-11-13: the first dog-beach save had the rod in the rucksack).
- Thomas likes analogies when new concepts come up; he works in JavaScript, Python and bash.

## The tool (current: v29.5 web app)
`HM64_Dog_Oracle_v29_5.html` — offline, one file, built from lab results by `tools/export_webapp.py`
(`run_hm64_webapp.sh` on the Mac). Two arenas (footer switch):
- **Dog Oracle:** log the dog → potential dogs → line up with the N64 (five clock methods to compare) → Generate
  histogram → countdown beeps for the cast, release cue at the bite, hold advice where bite-2 tables exist.
  Keys/names editable by right-click, group buttons for look-alike animations. No whistles.
- **Lucky Timer:** blind attempts (no whistle now; 1–3 mash-whistle plans once the `lucky` run is in), smart release
  zones, scrolling timeline, Jack from Thomas's own frame catalog on his beach screenshot (SE/E), attempt log, and
  "2nd bite + tap" (tap Space at bite 1: dud check, and a personal profile that re-aims the plan to the runner).
  v29.2: pace presets (All / Fast / Medium / Slow = hesitation before the dog lands, each with its own best cast) and
  the stopwatch starts when the dog lands (Space together with A); the second Space press logs bite 1 in any policy.
  v29.3: Space together with B logs the real cast; after each attempt the tool says whether the bite was a Nut bite
  and, with H / M / E (Nut / fish / empty line), whether the cast or the release missed.
  v29.4 (Thomas's plan): release bite 1 only in a release window; otherwise hold, tap it, and the tool forecasts bite 2
  (DUD → reset, or the Nut chance and moment).
  v29.5: **Route menu** — Spring 9 dog carry (the lab arrival pool) or `nodog-nohorse-no-pickup` (the dog-beach save's
  base-line cast table; start at beach entry or at READY on the pier end; best ~39.8% at ±100 ms if on that line; bite
  taps check whether the attempt was on that line). Attempts, taps and the profile are kept per route.
The keyboard is for observing, the stopwatch and (Thomas's choice, optional) the bite-1 tap; casting and releasing
happen on the controller.
v29.9 (5th build, 2026-11-16): B always = the controller's B, Space = the keyboard tap; every Space is classed by
time (route taps / bite taps), no held key; the cast tap is optional. How-to: Docs "HM64 Lucky Timer v29.10 — how to
use and calibrate". v30 (planned, behind a checkbox): dog-watch — see `HM64_V30_DOGWATCH.md`.
Status and test numbers: `HM64_LAB_STATUS.md` → "v28 web app" and "Lucky Timer".

## Resuming in a new chat
The lab code travels inside the package zip (`hm64-powernut-lab_*.zip` → `hm64/hm64-lab.tar.gz`), which Thomas
keeps in `~/Downloads` and `~/Documents/hm64/`. Newest: `hm64-powernut-lab_lucky-nodog_2026-11-13.zip` (v29.5; all lab
code + tests + experiments + these docs under `project_docs/` + the dog-beach cast table under
`webapp/assets/route_sources/` + the built app; `run_hm64_campaign.sh` is inside the tar). The project files also hold
`hm64-powernut-lab_full-v29-4_2026-11-13.zip` (one version older). If the project files hold an older one, use the newest
the user can upload. To continue development in a new chat, use / ask for:
1. the newest `hm64-powernut-lab_*.zip` (project files, or uploaded),
2. `ROUTE_TO_CHECKPOINT_LINKS.csv` (from `~/Documents/hm64/sourcefiles/`; not in the zip),
3. the newest results zip(s) from `~/Documents/hm64/runs/` if the work builds on them,
4. for the dog-beach route: the save `nohorse-dogbeach-nopickup_0d78b95b` (the cast table is in the v29.5 package).
ROM, SaveRAM, mupen64plus bundle, decomp, QS2 state and backups are already project files.

## Project files (inputs)
`Harvest Moon 64 USA.z64` (sha256 15c57012…, NYWE rev00), `Harvest Moon 64 USA3.SaveRAM` (BizHawk
format, Spring 9, sha256 db2c29ac…), `mupen64plus-bundle-linux64-2.6.0.tar.gz`, `hm64-decomp-master.zip`,
`Harvest_20Moon…QuickSave2_281_29.State` (BizHawk pier state, 8/8 regression), master backup index +
recoverable savestates zips (legacy history, read-only reference). Not yet a project file: the dog-beach save
`nohorse-dogbeach-nopickup_0d78b95b` (BizHawk format, Spring 4, sha256 0d78b95b…).
