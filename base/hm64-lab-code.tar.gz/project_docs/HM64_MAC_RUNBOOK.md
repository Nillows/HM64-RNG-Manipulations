# HM64 lab — Mac runbook (how experiments get run)

Thomas runs every heavy experiment on his Mac mini (Apple silicon, Docker Desktop with Rosetta, zsh).
Claude builds the package, Thomas pastes one block into Terminal, then sends back the results zip.
Last updated 2026-11-16 (dog-watch lab package, v30 groundwork; earlier: dog-spot lab, zigzag-3 fix, web app v29.9).

## Folder layout on the Mac
```
~/Downloads/hm64-powernut-lab_<preset>_<date>.zip     package from Claude (browser may add " (1)")
~/Documents/hm64/run_hm64_campaign.sh                  runner (unpacked from the package)
~/Documents/hm64/hm64-lab.tar.gz                       lab code (unpacked from the package)
~/Documents/hm64/run_hm64_zigzag.sh                    zigzag runner (since 2026-11-14) + hm64-lab-zigzag.tar.gz
~/Documents/hm64/sourcefiles/                          ROM, Spring 9 SaveRAM, dog-beach SaveRAM, ROUTE_TO_CHECKPOINT_LINKS.csv
                                                       (loose or zipped; saves are told apart by sha256)
~/Documents/hm64/HM64_Layer1_Mac_Generator/output/     Layer 1 master + shards (mounted read-only)
~/Documents/hm64/runs/<timestamp>/hm64-lab/            one work folder per run (states/ hold READY savestates + ladder rungs)
~/Documents/hm64/runs/zigzag/hm64-lab/                 the zigzag work folder (kept: fast and full presets continue here)
~/Documents/hm64/run_hm64_dogspots.sh                  dog-spot runner (since 2026-11-15) + hm64-lab-dogspots.tar.gz
~/Documents/hm64/sourcefiles/dogspots/                 Thomas's dog-placement SaveRAMs (any names, also zipped)
~/Documents/hm64/runs/dogspots/hm64-lab/               the dog-spot work folder (states/dogspots/<label>, results/dogspots/<label>)
~/Documents/hm64/runs/hm64-dogspots-<timestamp>.zip    dog-spot results to send back (DOGSPOTS.md + one folder per save)
~/Documents/hm64/runs/hm64-campaign-<preset>-<timestamp>.zip   results to send back (no ROM/save/savestates)
```

## Package convention
- Name every package `hm64-powernut-lab_<preset>_<YYYY-MM-DD>[letter].zip`; inside: `hm64/run_hm64_campaign.sh`,
  `hm64/hm64-lab.tar.gz`, `hm64/README_RUN.txt`. The zigzag package ships its own runner and tarball name
  (`hm64/run_hm64_zigzag.sh`, `hm64/hm64-lab-zigzag.tar.gz`, `hm64/README_ZIGZAG.txt`) so it never replaces the
  campaign runner or tarball; the dog-spot package likewise (`hm64/run_hm64_dogspots.sh`,
  `hm64/hm64-lab-dogspots.tar.gz`, `hm64/README_DOGSPOTS.txt`).
- **Add-on packages** (when the Mac has a newer lab than the one Claude built on): `hm64/<name>/install_<name>.sh` +
  the new files + full copies and unified diffs of the changed files. The installer replaces a file only if it is still
  the version Claude built on (sha256), otherwise patch-merges after a dry run, and stops without changes on a conflict;
  backups `*.before-<name>`. First one: `hm64-powernut-lab_dogbeach_2026-11-13.zip`.
- Give Thomas a paste block that opens exactly that name (template below). No `#` comments in pasted blocks
  (zsh treats them as commands); wrap in `bash <<'EOF' … EOF` so bash semantics apply; `</dev/null` on the runs.

```
bash <<'EOF'
set -e
ZIP="$(ls -t ~/Downloads/hm64-powernut-lab_pulse_2026-11-12*.zip 2>/dev/null | head -1)"
[ -n "$ZIP" ] || { echo "STOP: hm64-powernut-lab_pulse_2026-11-12.zip is not in Downloads"; exit 1; }
echo "==> using $ZIP"
unzip -o "$ZIP" -d ~/Documents
cd ~/Documents/hm64
HM64_DRY_RUN=1 bash run_hm64_campaign.sh pulse </dev/null
sleep 2
caffeinate -i bash run_hm64_campaign.sh pulse </dev/null
EOF
```

## Strategy lab (no Docker, no emulation)
`~/Documents/hm64/run_strategy_lab.sh [strategy files]` unpacks the lab code into `~/Documents/hm64/strategy-lab/`,
links the newest run folder that has `O_observe.jsonl` + `W_single.jsonl` as ground truth, and runs
`tools/strategy_lab.py` with the conda `python3` (needs numpy). Thomas edits/adds JSON files in
`strategy-lab/strategies/` (never overwritten); results in `strategy-lab/truth/STRATEGY.md`. ~25 s per strategy.

## Web app (no Docker, no emulation)
`~/Documents/hm64/run_hm64_webapp.sh` unpacks the lab code into `webapp-build/`, takes dog paths from the newest
run with `O_observe.jsonl` + `W_lines.json` and cast tables from every run with `B_natural.jsonl` or
`K_casts.jsonl`, plus the Lucky Timer whistle plans from the newest `lucky_tables.json` (preset lucky), and writes
`~/Documents/hm64/webapp/HM64_Dog_Oracle_v29_9.html` (opens it; v29.9 since 2026-11-15 adds route lineup-dogbeach + the
fade-in start; v29.8 since 2026-11-14 — Lucky Timer routes come from
`webapp/assets/lucky_routes.json` in the lab code: the old single line + the zig-zag fast-zone line mix). ~1 min, needs numpy.
App-only packages (e.g. `hm64-powernut-lab_lucky-practice_2026-11-14.zip`, v29.8: cast practice in L3) carry a prebuilt `hm64/webapp/<app>.html`, the lab
tarball and `run_hm64_webapp.sh`, never `run_hm64_campaign.sh`; unzipping them does not touch a running zigzag campaign.
Run it after every `casttables` run. Preset `casttables` reuses the newest run that has `O_observe.jsonl`
(not the run with the most rows) and `W_lines.json`; `HM64_CAST_PATHS=10` limits it to the top 10 paths.

## What `run_hm64_campaign.sh <preset>` does
1. New run folder, extracts the lab, finds inputs in `sourcefiles/` (also inside zips), checks ROM/SaveRAM sha256.
   Saves are picked by sha256 (since the dogbeach add-on): Spring 9 `db2c29ac…` → `data/saves/` (health check and every
   other preset); dog-beach `0d78b95b…` → `data/saves_dogbeach/` and `-e HM64_SRAM=…` for preset dogbeach.
2. Finds Layer 1 (`HM64_LAYER1`, default `<script dir>/HM64_Layer1_Mac_Generator/output`) and mounts it read-only.
3. **Reuse:** copies finished rows (A/L/B/P/C/O jsonl) and `states/campaign/` from the earlier run with the most
   rows, so nothing is redone (`HM64_REUSE=0` to start clean). Preset dogbeach reuses only the newest earlier dogbeach
   run (`Y_*.jsonl`, `Y_check.json`, `states/dogbeach/`).
4. `HM64_DRY_RUN=1` stops here (prints `layer1` and `reuse` lines — check them).
5. Builds the amd64 image, runs the 10-check health test (aborts on failure), runs `tools/campaign.py`,
   zips `results/campaign-<preset>/` into `runs/`. Prints a resume command if stopped.

## What `run_hm64_zigzag.sh zigzag-fast|zigzag-full` does (2026-11-14)
1. Work folder `runs/zigzag/hm64-lab`, kept between runs: the code is replaced from `hm64-lab-zigzag.tar.gz`,
   `states/`, `results/`, `data/` are kept, so a re-run or the full preset continues where the last one stopped.
   A lock (`runs/zigzag/.running`) stops a second zigzag run from starting.
2. Inputs: ROM (sourcefiles or zips there); the dog-beach save by sha256 `0d78b95b…` from sourcefiles/zips, else
   ~/Downloads, ~/Desktop, ~/Documents (copied into sourcefiles as `nohorse-dogbeach-nopickup_0d78b95b.SaveRAM`);
   the Spring 9 save is optional (only for the lab health test). `HM64_DRY_RUN=1` stops after this.
3. Docker image, health test (if Spring 9 present), then `tools/zigzag_campaign.py` with
   `HM64_SRAM=/work/data/saves_dogbeach/nohorse-dogbeach-nopickup.SaveRAM`; it starts with its own route check (Z0)
   and stops on a mismatch. Options: `HM64_ZZ_STOP_AFTER=Z5`, `HM64_ZZ_MAX_LINES=N`.
4. Zips `results/campaign-zigzag/` to `runs/hm64-campaign-<preset>-<timestamp>.zip`. No rungs on disk (casts replay
   the line's representative), so disk use stays small.

## Dog-spot lab: `run_hm64_dogspots.sh [workers]` (zigzag-4, 2026-11-15)
Package `hm64-powernut-lab_dogspots_2026-11-15.zip`. Thomas makes SaveRAMs with the dog at spots he can repeat by hand
and drops them in `sourcefiles/dogspots/`; every save runs preset `dogspot-fast` (the zigzag-fast recipe of route
delays, dog-neutral), one after the other, in `runs/dogspots/hm64-lab` (one lab, per-save `HM64_ZZ_STORE` state store
and `results/dogspots/<label>/`; label = file name + sha256[:8]; duplicate bytes skipped; the dog-beach save, if put
there or with `HM64_DOGSPOTS_CONTROL=1`, is labelled `control-dogbeach-0d78b95b`). A save that stops (e.g. not
repeatable) is noted and the next one runs. The CPU core is benchmarked on the first save and reused
(`results/dogspots/core.json`). Then `tools/dogspots_report.py` → `results/dogspots/DOGSPOTS.md`; zip →
`runs/hm64-dogspots-<timestamp>.zip`. Options: `HM64_ZZ_STOP_AFTER=Z6` (no casts), `HM64_DOGSPOTS_ONLY=<text>`,
`HM64_DRY_RUN=1` (lists the saves and labels). Lock `runs/dogspots/.running`. Do not run it while a zigzag run is going.
Per save (see HM64_DOGBEACH_SAVE.md "Dog-spot lab" for the method): Z0 record ×2 (must be equal), Z1–Z4 with failure
rows, Z5 `zz_beach_neutral_job` (D 82–94 × B 112–151, every cut decided), Z6 dog-neutral lines + merge, Z7/Z8 casts.
Sandbox self-tests use `HM64_ZZ_TEST_DOG` (dogInfo poke at the house load) — never set by the runner.
**Package `hm64-powernut-lab_dogspots-123_2026-11-15.zip`** (supersedes the first dogspots zip): carries Thomas's four
saves (his request) in `hm64/sourcefiles/dogspots/1|2|3/` → order = folder number, then file name; labels
`1-house-rightside-table-01e9334f`, `2-default-location-b520985c`, `3-crossroads-north-e51bdbf8`,
`3-crossroads-west-28029e45`. After each save the runner prints FAST RESULTS (`dogspots_report.py --one`: dog, recipe,
failures, 2nd-cut windows, lines, RNG draw range at READY, Nut casts / earliest Nut, cut presets) and writes
`runs/hm64-dogspots-<label>-<stamp>.zip` before the next save; the final zip has all of them. It refuses to start while
`runs/zigzag/.running` exists. Z8 member checks capped (40 per line, 300 per phase). One-line start:
`cd ~/Documents && unzip -o "$(ls -t ~/Downloads/hm64-powernut-lab_dogspots-123_2026-11-15*.zip | head -1)" && cd hm64 && caffeinate -i bash run_hm64_dogspots.sh </dev/null`

## Dog-watch lab: `run_hm64_dogwatch.sh [workers]` (zigzag-4d, 2026-11-16, v30 groundwork)
Package `hm64-powernut-lab_dogwatch_2026-11-16.zip` (`hm64/run_hm64_dogwatch.sh`, `hm64/hm64-lab-dogwatch.tar.gz`,
`hm64/README_DOGWATCH.txt`; no saves). Preset `dogwatch` on the beach-lineup2 save only (found by sha256 52cfd712… in
sourcefiles/lineup, dogwatch or dogspots), from the ground up: `HM64_ZZ_STORE=/work/states/dogwatch/<label>`, results
`runs/dogspots/hm64-lab/results/dogwatch/beach-lineup2-52cfd712`. Same lock / queue as the dog-spot runner. Phase 1
`HM64_ZZ_STOP_AFTER=Z6` + `tools/dogwatch_report.py` → early zip `runs/hm64-dogwatch-early-<label>-<stamp>.zip`; phase 2
xvfb renders (`experiments/dogwatch_render.py`, B 118/124/130/138) → `render/B*/sheet.png`; phase 3 the full campaign
(casts) + report → `runs/hm64-dogwatch-<label>-<stamp>.zip`. `HM64_DOGWATCH_PHASES=1` (phases 1–2 only),
`HM64_DOGWATCH_RENDER=0`. One-line start:
`cd ~/Documents && unzip -o "$(ls -t ~/Downloads/hm64-powernut-lab_dogwatch_2026-11-16*.zip | head -1)" && cd hm64 && caffeinate -i bash run_hm64_dogwatch.sh </dev/null`

## zigzag-3 (2026-11-15): Rosetta-proof pool, CPU-core choice, beach scan
- Cause of the stall: amd64 image under Rosetta; mupen's dynarec JIT code is regenerated after every savestate load and
  Rosetta re-translates it → slow, and its VmTracker slab runs out ("assertion failed [_slab_allocator_break >=
  kSlabAllocatorBase]") → workers die; multiprocessing.Pool loses a dead worker's job and would hang at the end.
- `m64h/pool.py`: own supervisor (Process + Pipe per worker): a dead worker's job goes to a fresh worker (3 tries, then
  an error row, re-run on resume); workers recycled every `M64H_RECYCLE` jobs (default 6); CPU core from `M64H_CPU`.
- `choose_cpu` (campaign start): `zz_bench_job` (reference route + 12 reloaded beach walks) with dynarec and cached;
  identical results required (else STOP), faster one used; `results/campaign-zigzag/core.json`. Sandbox x86: dynarec
  8.4 s, cached 23.1 s, identical; cached also gave identical beach rows. Force with `M64H_CPU=cached|dynarec`.
- `zz_beach_scan_job`: even D and even D+B only, B scanned around the READY window (2 misses past each end), copies for
  the rest; both copy rules walked once per job (fallback to the full grid if either fails); "late" line keys (key
  read when the B grid starts, before wake + 8) are read for D+1 itself. Non-READY walks stop after 20 still VIs.
  Sandbox: identical rows to zz_beach_job on 4 states (D 82–102, B 110–157), 136 vs 1,008 walks, 58 vs 425 s.
- `beach_rows`: Z5 rows merged per (beach state, D) from any job (a row counts if its job searched the whole B range
  wanted, or its READY window lies strictly inside the job's range); jobs only for missing (b, D). zigzag-mid now
  Ds 82–102. zigzag-fast still gives 47 lines / 6,776 members from its rows.

## zigzag-2 (2026-11-14 evening): preset zigzag-mid and the farm-sparrow merge fix
- `run_hm64_zigzag.sh zigzag-mid`: the full preset's grids (so every job is a full-preset job: finished full work is
  reused and zigzag-full continues afterwards) with house/farm/ranch slack 18 VIs (9 game frames per screen) and
  members capped at D <= 102 (1st cut 9 frames late). cast_cover 0.95.
- The farm fingerprint now includes live sparrows (`hm64/zigzag.py sparrow_part`); states without sparrows keep their
  keys. First zigzag-2 run in a folder: stage "Z2 fix" (`tools/zigzag_campaign.py sparrow_fix`, job
  `zz_sparrow_scan_job`) scans stored house/farm states (each must load on its map, else STOP without changes),
  moves sparrow farm states to `states/zigzag/f-before-sparrowfix/`, drops Z2 rows of sparrow mornings (+ mornings that
  reached those keys) and Z3 rows from those states (kept in `*.before-sparrowfix.jsonl`); marker
  `Z2_sparrowfix.json`. A stored state is the snapshot one VI after its key, so keys cannot be recomputed from files.
- To stop a running zigzag run: Ctrl-C in its Terminal, then stop any container of image hm64-lab:latest and remove
  `runs/zigzag/.running` only when no runner process is left (paste block in the chat, 2026-11-14 21:4x).

## Preset dogbeach (stage Y) — superseded by zigzag on 2026-11-14 (legacy beach walk, legacy house path)
Save `nohorse-dogbeach-nopickup_0d78b95b`; menus first-frame / 1-frame-late (5 states, weights 1/4/6/4/1), waits P ≤ 60,
H + C ≤ 60 → 2,430 routes → ~100 READY states → one cast per distinct state, every game frame 0.07–40 s, bites 1 + 2.

## Runs so far
| Date | Preset | Result zip | Notes |
|---|---|---|---|
| 2026-11-12 02:38 | quick | hm64-campaign-quick-… | 121 routes, casts 0–238 |
| 2026-11-12 08:22 | oracle | hm64-campaign-oracle-20261112-082221.zip | 126 min; 27,000 casts, ladder, Layer 1 link |
| 2026-11-12 12:59 | observe | hm64-campaign-observe-20261112-125908.zip | 15.5 min; 646 routes, 271 arrivals, 16 paths |
| 2026-11-12 14:12 | pulse | hm64-campaign-pulse-20261112-141257.zip | 84 min; 13,440 single presses + 4,800 pairs |
| 2026-11-12 17:07 | casttables | hm64-campaign-casttables-20261112-170706.zip | 191 min; 36,000 casts; valid 0–40 s (farmer naps after: no SE push) |
| 2026-11-12 22:14 | awake | hm64-campaign-awake-20261112-221418.zip | 572 min; 67,184 casts 40–180 s, all started; dog path to 184 s |
| 2026-11-13 09:10 | whistle | hm64-campaign-whistle-20261113-091005.zip | 274 min; 19,200 casts after 1 whistle at 74/82/90/98 s: 2 bite-1 Nuts (74 s), 0 otherwise → no |
| 2026-11-13 10:49 | lucky (paused) | runs/20261113-104912 | 504 mash jobs done; 27,989 distinct states / 947 chunks; casts ~0.4/s on the Mac (4× slower than K casts) → ~20 h; paused at 14 chunks. Resume in place: `docker compose run --rm -T lab python3 tools/campaign.py --preset lucky --workers N --out results/campaign-lucky` from that hm64-lab (skips states already cast) |
| pending | lucky-lite | hm64-campaign-lucky-lite-… | package hm64-powernut-lab_lucky-lite_2026-11-13.zip: same folder, `-e HM64_LUCKY_K=1,2 -e HM64_LUCKY_GRID=8:1500,16:2770 -e HM64_LUCKY_COVER=0.80` (8 arrivals, ~83% of routes, ~5k casts, ~3.5 h) |
| superseded | dogbeach | — | replaced by zigzag before it was run |
| 2026-11-14 12:51 | zigzag-fast | hm64-campaign-zigzag-fast-20261114-125147.zip | ~3 h on 13 workers: Z0 OK; 16 house arrivals (5 in band), 11 farm, 44 beach states; 47 dog lines from 6,776 members (0 split); 24 lines cast (90.8% weight), 15,281 cast states; repeat casts 179/0, member recasts 667/0 → Lucky Timer v29.6 route nodog-zigzag-fast |
| 2026-11-14 ~15:50 | zigzag-full (stopped ~21:40) | — | stopped by Thomas for zigzag-mid; its finished jobs stay in runs/zigzag and are reused |
| 2026-11-14 ~21:45 | zigzag-mid (zigzag-2, stopped 2026-11-15 ~07:20) | — | Z1–Z4 done, Z5 320/714 at 0.01 jobs/s with Rosetta "VmTracker slab allocator has run out of memory" worker crashes; stopped by Thomas |
| pending | zigzag-mid (zigzag-3) | hm64-campaign-zigzag-mid-… | package hm64-powernut-lab_zigzag-mid-fix_2026-11-15.zip: supervised pool, CPU-core check, beach scan job, rows shared per (beach state, D); continues in runs/zigzag |
| pending | lineup-fast (zigzag-4 + lineup) | hm64-lineup-fast-… | package hm64-powernut-lab_lineup_2026-11-15.zip: dog-beach + beach-lineup2 saves, D 84, waits 0–30, full pier width; `HM64_DOGSPOTS_PRESET=lineup-fast HM64_DOGSPOTS_DIR=lineup`; results/lineup-fast/<label>; casts several h per save |
| pending | dogwatch (zigzag-4d), beach-lineup2 only | hm64-dogwatch-beach-lineup2-52cfd712-… | package hm64-powernut-lab_dogwatch_2026-11-16.zip: `bash run_hm64_dogwatch.sh` in ~/Documents/hm64 (queues); from the ground up (states/dogwatch, results/dogwatch); phase 1 early zip hm64-dogwatch-early-…, phase 2 dock-end renders, phase 3 casts; see HM64_V30_DOGWATCH.md |
| 2026-11-16 00:45 | lineup-sparrow (zigzag-4c), dog-beach only | hm64-lineup-sparrow-1-dogbeach-under-pier-0d78b95b-20261116-004521.zip | menus 5-9 frames late (house VI 1046-1054): 99 lines; door-pair mornings (1046/1048) -> app route lineup-dogbeach-sparrow-door (`tools/zigzag_routes.py <results/lineup-sparrow/1-dogbeach-under-pier-0d78b95b> --lineup --houses 1046,1048 --id lineup-dogbeach-sparrow-door ...`); see HM64_DOGBEACH_SAVE.md "Sparrow mornings: results" |
| 2026-11-15 20:23 | lineup-fast + D 86 (zigzag-4b), both saves | hm64-lineup-fast-20261115-202348.zip | save 1 53.8 min (66 lines), save 2 110 min (83 lines); routes lineup-dogbeach + lineup-lineup2 in the app |
| (superseded) queued 2026-11-15 ~20:10 | lineup-fast + D 86 (zigzag-4b) | hm64-lineup-fast-…-<new stamp> | package hm64-powernut-lab_lineup86_2026-11-15.zip: `bash run_hm64_lineup86.sh` in ~/Documents/hm64 (own runner/tarball names, so it can be unpacked while the first lineup run goes; it waits for that run's lock, then continues the same results/lineup-fast/<label> folders: D 84 work reused, D 86 walks + new lines/casts + member checks only). Sandbox lineup-test resume: 1 new line of 19, 5 new cast jobs of 41, member recasts 220/0 |
| pending | dogspot-fast (zigzag-4) | hm64-dogspots-… | package hm64-powernut-lab_dogspots-123_2026-11-15.zip with the 4 saves (house / farm / crossroads ×2); est. 2–4 h per save |

## Troubleshooting history
- Finder unzips into `hm64 2` when `hm64` exists → always unzip from Terminal (`unzip -o … -d ~/Documents`).
- Browser renames repeats (`… (1).zip`), so an old file may keep the plain name → open by descriptive name.
- The runner once died silently on an empty earlier run folder (`set -e` + `pipefail` in the reuse scan) → fixed.
- Extracted bundle files are read-only: delete run folders with `rm -rf`.
- With two SaveRAMs in sourcefiles the old runner took the first match → fixed in the dogbeach add-on (sha256 choice).

## Claude's sandbox limits
Docker Hub, the Docker frontend image and the Claude Code installer are blocked; base images had to be built
locally with debootstrap just to test. Local emulator tests should stay short (≲5 min, 2 CPUs); anything bigger
goes to the Mac. One emulator per process. No rsync in the sandbox (the zigzag runner uses cp, not rsync).
