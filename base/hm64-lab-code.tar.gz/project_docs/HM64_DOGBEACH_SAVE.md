# HM64 dog-beach save — no horse, dog waits on the beach, no pickup (2026-11-13 night)

Thomas's simplification of the Lucky Timer route: a save with **no horse** and the **dog already on the beach**, so
the route has no pickup / carry / put-down. All numbers below are from Claude's sandbox emulator (same headless
mupen64plus lab, v29.4 lab code from `hm64-powernut-lab_full-v29-4_2026-11-13.zip`), one process per emulator.

## The save
- **`nohorse-dogbeach-nopickup_0d78b95b`** = Thomas's `Harvest_Moon_64_USA.SaveRAM` (BizHawk format), sha256
  `0d78b95b78e4a988570b3648d9bc16021df59a5faccdc00d06b01273975d8387`. Not yet a project file — Thomas to add it
  (the dogbeach installer copies it into `~/Documents/hm64/sourcefiles/` by sha256).
- Read from RAM after loading: **Spring 4, year 1, sunny** (old save: Spring 9), 6:48 at READY; horse flags 0 (no horse);
  dog `location` 9 (beach) at (−197.57, 142.43), facing 1; **fishing rod in hand** (toolSlots `[2,1,3,4,5,0,0,0]`, hand 24).
- The first upload (sha256 `eca55c0e…`) had the rod in rucksack slot 6 and an empty hand, so B did nothing at the
  pier. The hand is `toolSlots[8]` = save byte 0x418 of the slot (gameFile.c loads 9 tool bytes from 0x410). A
  2-byte test copy (rod moved 0x415 → 0x418; slot checksum = byte sum of 0..4093, unchanged) behaved **identically**
  to 0d78b95b everywhere it was compared (42 s natural path, 42 arrivals, 16 casts incl. 9 Nut casts) despite the
  dog's 0.6-unit position difference.

## Why "no dog at the beach at all" is barren (measured first, on the old save with the dog left in the house)
- Without a dog on the beach the RNG is a pure clock: 1 draw per game frame walking/standing, 3 while the line is out
  (1 main loop + 2 bite roll); cast outcomes repeat every 3 game frames.
- Frame order (verified by fish sizes): bite pair, main draw; catch frame: fish-type pair, Nut pair, main draw.
  **Nut roll = bite slot + 31 draws, always** (300/300 casts every game frame for 10 s; 3 traced catches).
- First bite slot whose +31 draw can be a Nut: **#26,210** (READY ≈ #1,300) → ≥ 276 s of continuous fishing.
  The dog's own draws between bite and catch are what make Nuts possible (e.g. #3815 needs +37 = 31 + 6 dog draws).

## Route (dog-free house) and READY
Legacy v14 recipe (`hm64/route.py`) with the dog interactions removed:
menus START, START, A, A · house: wait 266 polls (breakfast), UL 20, DL 35, D held to the door (legacy U4 + A4 + N14
dropped) · farm L held · crossroads N C, L 78, DL held · ranch DR held · beach DR 86, DL 34, D 100, L 35, **DR held
until the water stops him**.
- **READY = pier end (−92.993, 178.257)**, facing SE, 9 units past the old lab READY (−101.993): holding DR stops there.
  This is probably the spot in Thomas's READY screenshot (open question v29.0d).
- Legacy-timed recipe (menu presses at polls 681/753/887/975): beach entry VI 2296 (draw 1081) → READY arrival VI 2624
  (draw 1264), 328 VIs entry → READY (328 on every route tested, the beach walk is fixed).
- Screen DR = world +x, screen DL = world +z, screen D = world diagonal. **DR/DL/DR alone cannot reach the pier**: all
  672 splits tried stop at a wall at x = −212; the legacy D and L legs go around it and slide into the pier lane.

## Menus: first possible frame vs the legacy recipe (measured 2026-11-13 late night)
Main loop index 0x8020564A / title mode (TITLE_CTX+0). Presses are edges (`checkButtonPressed`); one game frame = 2 polls.
- **Press 1 START skips the intro** (map 53 MAIN_GAME from poll 228): accepted from poll **665** (presses before do
  nothing lasting; mashing from power-on = mashing from poll 600: identical timelines); the title screen (0x32) starts
  ~71 polls later. **Press 2 START** on the title: first poll 738 (+73). **Press 3 A** (or START) on the Play menu (mode 3):
  873 (+135). **Press 4 A** on the diary select (0x35, appears ~940; A accepted only from 962): 962 (+89) → map load at
  poll 1000, house map at 1002 (draw 500).
- A late press moves every later screen by one frame; the 16 first/late combos reach the house at 1002 + 2 × (late
  presses) and **combos with the same count reach identical READY states** (all 16 at P = 0 and P = 7 → 5 states).
- **The legacy recipe is ~7 frames slower** (house at 1014). So the "base line" scanned below (and the v29.5 app route)
  is the legacy-timed line, not frame-perfect mashing.

## The dog on the beach sleeps until it is on screen
- From beach entry the dog is frozen (animation reset while off the visibility grid) until the farmer brings it on
  screen, **~192 VIs after beach entry** on this walk (farmer ≈ (−300, 47)); a few draws (3–7) can happen before that.
- 42 human-like variants of the legacy-timed route (menu d0 0–10, house P 1–10 / H 1–6, crossroads C 1–10, beach pauses)
  → 7 world lines, the same wake draw always on the same line; a beach pause before the wake = a new line, after it =
  same line with READY later. Crossroads waits 1–9 polls change nothing; legacy d0 1–2 lose a menu press.
- **Correction (late night):** the route before the beach is *not* a pure clock in general. In the legacy-timed sample the
  beach-entry draw followed the VI exactly, but with frame-perfect menus all-late (LLLL) reaches the beach with ~24 more
  draws than all-first (FFFF) (+4 expected), some waits add ±4 draws, and the first 192 VIs on the beach add 3–7.
  Preset `dogbeach` therefore assumes nothing: it runs every route and merges only identical game states.

## Cast scan, legacy-timed line (wake draw 1184): every game frame 0–40 s, bite 1 and bite 2
`eval_cast(hold_bites=2)` via `cast_job_rung` (rungs every 60 polls), releases at bite+4 / +12, Nut windows mapped.
Times are polls after READY (60 = 1 s); casts end at 40 s (nap rule; fishing itself keeps him awake).
- **1,200 cast frames: Nut on bite 1 51 (4.2%), Nut on bite 2 when held 53 (4.4%), either 104 (8.7%) — not barren.**
- Per 5 s of cast time (either): 13, 14, 10, 16, 20, 14, 8, 9 of 150. Nut bites land 28–52 s after READY.
- Checks: +4 and +12 releases never disagree; 6/6 casts replayed straight from READY = rung results; 16/16 casts
  identical between the test copy and 0d78b95b; `lucky_cast_job` (the preset's cast path) = this scan 40/40.
- Lucky-style, **this line only** (cast lands Gaussian around the aim; "smart" = Space at bite 1, ±40 ms, the tool
  picks release vs hold from the bite time):

| cast spread (1 s.d.) | smart | best aim | release bite 1 only | hold to bite 2 only |
|---|---|---|---|---|
| 100 ms | **39.9%** | 25.05 s after READY (35.5% at 3.02 s) | 23.5% (22.12 s) | 26.5% (20.38 s) |
| 150 ms | 32.4% | 25.03 s | 17.0% (22.12 s) | 19.4% (20.35 s) |
| 250 ms | 23.2% | 25.00 s | 13.4% (22.32 s) | 13.9% (20.30 s) |

  For comparison, v29.4 on the old route (whole arrival pool, Fast, ±100 ms) simulates 28.2%. The table above assumes
  the runner is on this one line; the dogbeach run measures the real pool.
- Files (sent to Thomas): `HM64_dogbeach_0d78b95b_casttable.csv` (per cast frame: bite 1 time, Nut 1, release window,
  bite 2 time, Nut 2) and `.json` (full eval_cast rows, K_casts shape); since v29.5 also in the lab package under
  `webapp/assets/route_sources/`.

## In the Lucky Timer (v29.5, 2026-11-13 night): route `nodog-nohorse-no-pickup`
Thomas's name for this route in the app (the save itself is `nohorse-dogbeach-nopickup_0d78b95b`; the dog *is* on the
beach — "nodog" = no dog carried). It currently holds the **legacy-timed line** only (see Menus).
- `tools/route_tables.py` packs the cast table exactly like the dog paths (poll c read during VI c + 1; 1,200 casts,
  0 mismatches vs the CSV, 51 / 53 Nuts; odd polls left unknown: the game-frame pairing was not measured on this route)
  → `webapp/assets/lucky_routes.json` → app data `lroutes`. Route menu in the Lucky Timer: Spring 9 dog carry (the lab
  arrival pool, pace presets) | nodog-nohorse-no-pickup (one dog line, no pace cards).
- Start anchors: **beach entry** (recommended; READY = entry + 328 VI on the base walk, and the dog's line is fixed at
  its wake, entry + 192 VI, so a slower walk after the wake does not shift the dog on this stopwatch) or **READY at the
  pier end** (Space when Jack stops at the water; a slower walk after the wake shifts this one). Start-key delay
  default +150 ms for both (reaction); the first visible beach frame vs the map change is not calibrated — the
  profile learns the stopwatch offset from bite taps.
- The app's numbers (LuckyCore, independent of the scan's own simulation) agree within 0.2 points: smart zones
  25.05 s after READY → **39.8% / 32.3% / 23.1%** at ±100 / 150 / 250 ms; release bite 1 at 22.12 s → 23.3 / 16.9 /
  13.4%; hold-only at 19.25 s → 26.3 / 19.3 / 13.8%. The app shows 24.84 s after READY (30.26 s after beach entry)
  because it counts time with Thomas's measured console rate (16.53 ms per VI) — the same frame count.
  One release window, ~42.2–43.4 s after READY: the Nut bite comes there either as bite 1 (release) or, after a
  held earlier bite, as bite 2 (the bite-2 forecast then points at it).
- **Line check:** with one line, a bite tap that fits no cast frame near the cast tap means another line. Simulated
  (`tests/test_lucky_route.js`): on-line attempts accepted 100%; off-line attempts (bite delay unrelated to the cast)
  flagged 92% with the cast tap, 87% without (an upper bound: a neighbouring line may share bite delays). The attempt
  log (kept per route) shows "Line check: x of y tapped bites fit this route's dog line" — Thomas's hardware test of
  how often he really lands on the base line.

## Preset `dogbeach` (package `hm64-powernut-lab_dogbeach_2026-11-13.zip`, Mac run pending)
Thomas's spec: menus frame-perfect or one frame late per press (razor-sharp scope), the old 1–2 s margins without the
pickup/put-down time, second-bite data for the fallback.
- **Routes:** menu combos FFFF, LFFF, LLFF, LLLF, LLLL (weights 1/4/6/4/1 of 16) × waits P 0–60, H 1–60, C 1–60 and
  P 0–60 × (H, C) ∈ {(30,0), (60,0), (0,30), (0,60), (30,30)} (486) = 2,430 cold-boot routes → READY (pier end).
- **Lines:** READY states merged by the lucky state hash (RNG, dogInfo, dog entity + sprite object, player). Each line's
  natural path is recorded 2,700 VIs and hashed every game frame for 40 s (`experiments/dogbeach_jobs.py db_line_job`).
- **Casts:** one `lucky_cast_job` evaluation per distinct state hash (results stored relative to the cast, reused
  wherever the state recurs), every game frame **0.07–40 s** after READY (polls 4–2398; poll 0/2 excluded: the shared
  cast job's checkpoint lands one poll off there), bite 1 released and held → bite 2 released (+4/+12), replay hash
  checks, 1% of shared states cast again. Order: every line's 0–20 s before any 20–40 s, heaviest lines first.
- **Health check first:** the legacy-timed recipe must reproduce beach VI 2296 / draw 1081, READY VI 2624 / draw 1264
  and casts 76 (bite 1 Nut at 1684) and 126 (bite 2 Nut at 1720), else the run stops.
- **Report** (`tools/dogbeach_report.py`): DOGBEACH.md (lines, Nut counts, Lucky plans over the pool with smart
  release/hold + DUD rate, per late-press count and slack band), `dogbeach_tables.json`, `dogbeach_casttable.csv`,
  `dogbeach_lucky.json`.
- **Sandbox tests:** 4 small end-to-end runs (12 routes each); 0 replay-hash failures, check casts identical, resume with
  a wider cast window casts only the missing states. Size sample: FFFF with P 0–29 → 16 READY states, 9,353 distinct
  cast states over 40 s (~585 per state, 49% of line × poll pairs) → full run ≈ 100 lines, 55–65k casts ≈ 6 h at the
  casttables speed (~3 casts/s). Caveat: the paused `lucky` run cast at 0.4/s with the same cast job on the Mac (cause
  unknown; sandbox speed equals cast_job_rung).
- **Installer** (`dogbeach/install_dogbeach.sh`): finds the save by sha256, patches the installed lab (v29.4 or newer)
  — replaced if still v29.4, patch-merged otherwise, stops without changes if a patch conflicts; backups kept. The runner
  now picks saves by sha256 (Spring 9 for the health check and other presets, dog-beach for this preset) and passes
  `HM64_SRAM` + `HM64_DB_*` into Docker. Options: `HM64_DB_CASTS=4:1200:2` (0–20 s only), `HM64_DB_MAXLINES`,
  `HM64_DB_STOP_AFTER=lines`, `HM64_DB_ALL_COMBOS=1`.

## Route audit for Thomas's "funny business" check (2026-11-14, sandbox)
- **House start.** On the Spring 9 save the first poll at which a 2-poll stick tap moves Jack is house map + 263 polls
  (`experiments/house_control_probe.py`); the route's first step comes at + 266 (+ P). So P = 0 is ~3 polls (1–2 game
  frames) after the first possible frame: holding up-left through the house fade is slightly faster than any route in
  the run. To re-measure on the dog-beach save. Farm, ranch and the first beach leg hold the stick through the load
  (frame-perfect by construction); crossroads waits 1–9 change nothing (fade).
- **The lab's hard reset at VI 121** (inherited from the legacy runner) is harmless: rand() is not called before it;
  with the reset the boot's draws start at ~VI 262 instead of ~140 and the timeline is the same, shifted ~121 VIs
  (`experiments/reset_seed_probe.py`). Only the absolute poll numbers (665 / 738 / 873 / 962) include it.
- **Stick → movement** [DECOMP controller.c `calculateAnalogStickDirection`, player.c, graphic.c]: 8 directions only;
  a diagonal registers when the smaller axis is at least half the larger (≈ 27°–63°); speed = larger axis / 10, capped
  at 6, so any push ≥ 60 on the main axis equals the lab's ±80; dead zone both axes < 30. A real stick matches the
  scripted inputs as long as it stays in the sector and reaches 60.
- **Coverage limits of preset `dogbeach`** (read its results with these in mind): menu lateness 0–4 game frames in
  total, at most one per press (whether one press 2 frames late equals two presses 1 frame late is untested); waits
  sampled as a cross (one screen at a time + 5 mixes), not a measured human spread; weights 1/4/6/4/1 = a coin flip per
  press; beach walk fixed (the wake at ~entry + 192 VIs follows the camera, so beach timing before the wake changes
  the line, after it only READY moves — measured with pauses only); house / crossroads / beach legs are the legacy
  dog-carry path.

## Thomas's route corrections (2026-11-14 morning) and sandbox measurements
Thomas: the run must model **frame-perfect traversal with human turn-timing deviations**, not legacy waits.
- **Beach = 3-leg zig-zag, two turns only:** hold down-right through the ranch → beach load, cut down-left as soon as
  Jack clears the small wall (varied), run along the back of the beach, cut down-right into the pier lane (varied over
  the pier width), hold down-right to the dock end. No beach wait, no straight-down leg. Space at the dock end.
- **Menus:** model mashing (presses per second) instead of fixed first/late presses — menus only, before the house.
- **House:** get around the table as fast as possible (same idea as the beach).
- Player choice wanted: cast tables per turn style (tight / loose cuts), sortable by Nut odds.

Measured (Spring 9 save; geometry, camera and menus only — dog-beach save not in this session; scripts in `experiments/`):
- **Beach** (`beach_entry_state.py`, `beach_zigzag_grid.py`, `beach_walk_geometry.py`): Jack answers the stick from VI 65
  after the beach map change (holding through the load = frame-perfect). First cut: DR movement d ≥ 17 polls clears the
  small wall (17 slides along its corner, ≤ 16 stuck at z = −193). DL always starts at z = −208, so the pier window is
  the same for every first cut: DL 118–139 polls (11 game frames, z 146–206 at the cut) → Jack stops at the dock end,
  x −92…−94, z 156.6 / 156.2 / 158 / 164 / … / 194 / 195.8 / 195.4 (11 spots). Cuts outside the window hit the wall at
  x = −212 — what the earlier "672 splits all fail" test hit. READY ≈ 326–348 VIs after the map change.
  **The zig-zag works; the 2026-11-13 claim that DR/DL/DR cannot reach the pier was wrong.**
- **Dog appearance** (`beach_dog_visibility.py`, decomp entity.c `updateEntities` + map.h: mainMap 0x8013DC40,
  visibilityGrid +0x19E28 [38][42], origin +0x1A608, tile size 0x8013DC6C): the dog-beach dog's tile (−197.57, 142.43)
  enters the camera grid at first move + g(d), g = 123/121/113/115/117/119/121/111/115/119/115 VIs for d = 17/19/21/23/
  25/27/29/31/35/39/45 — a 12-VI sawtooth (camera tiles), independent of the second cut; a beach wait only shifts it.
  Old walk: visible at VI 166 vs measured wake ~192 (≈ one idle animation cycle; confirm on the save).
- **House** (`house_pickup_state.py`, `legs_until_map.py`): Jack answers the stick from ~VI 262 after the house map
  change; the recipe's 266 = that game-forced fade + ~4 polls (the old carry route's 192 + 74 breakfast wait), P was the
  only deliberate delay. Path from the start spot, floor clear: legacy UL 20 / DL 35 / D → farm 161 VIs after the first
  move; **fastest UL 13–14 / DL 52 / D → 149**; UL 12–16 × DL 44–56 stay within 149–161. (With the Spring 9 dog on the
  floor UL is blocked — not relevant to the dog-beach save.)
- **Crossroads** (`cross_entry_state.py`): Jack answers from VI 66; L held through the load then DL: L 76–84 polls from
  the map change → ranch at 234 VIs (legacy 78 is in this plateau); 70–74 or 90 cost 2–6 VIs. Farm (L) and ranch (DR)
  are one held direction.
- **Menu mashing** (`menu_mash_probe.py`, square wave, half duty, every phase, from VI 600 after the VI-121 reset):
  START alone never loads the house (the diary needs A); A alone never passes the intro; START until the Play menu then
  A, or START+A together, work. 5–15 presses/s → house map at VI 1035–1073, 16 distinct (time, draw) arrivals; 1035 /
  draw 500 = frame-perfect FFFF. Draws at the house are not a clock (title-screen dog: 1037 → 505, 1039 → 502). Per rate
  (START→A): 15/s 1037–1039 · 12/s 1041–1045 · 10/s 1035–1045 · 8.6/s 1041–1047 · 7.5/s 1037–1043 · 6/s 1051–1059 ·
  5/s 1041–1061 (not monotonic: mash period vs the game's accept frames). The F/L design covered 1035–1043 only.

## Measured on the dog-beach save itself (2026-11-14 midday, sandbox; Thomas uploaded 0d78b95b to the chat)
- **First control after each load** (VIs after the map change): house 263 (UL held through the fade moves him there),
  farm: spawn warp at 99, stick live 167; crossroads 67; ranch 67; beach 67.
- **House:** fastest farm arrival 411–412 VIs after the house load (UL ~13 VIs of movement, DL 52, D); the Spring 9
  geometry numbers hold. Two paths reaching the farm on the same VI can still differ by a few draws after the farm's
  spawn warp (e.g. 715 vs 712) — kept apart by the merge hash. No horse on this save (no farm horse draws).
- **Crossroads:** C ≤ 68 never reaches the ranch; C 77–86 fastest (ranch 235 VIs after the crossroads load);
  each ranch arrival VI = one state.
- **The sleeping dog blocks the pier lane.** Second cuts that bring Jack along z < ~170 run into the dog at
  (−197.6, 142.4) and stop (x ≈ −221…−225); cuts past the window hit the x = −212 wall. On the base line about 7 game
  frames of the 11-frame pier window reach the dock end (spots z 170–196). Collision also flags the dog
  (DOG_COLLISION_WITH_PLAYER) — such routes are simply not READY routes.
- **The dog wakes during the down-left leg** (~183–193 VIs after the beach load, later for later first cuts) and its
  future then depends on the wake state only: for one beach state + first cut, landing spots z 170/182/194 give the same
  RNG and dog for 40 s, and casts at the same moment give identical bites (8 casts); the only difference in the dog's
  RAM is `entity.viewSpacePosition` (0x40–0x4B = coordinates − camera, render-only per entity.c), so it is left out of
  the line/cast hashes. Pipeline check (test preset): 40/40 casts from members' own routes = the shared line table.
- **Savestate gotchas (fixed in hm64/zigzag.py):** a load polls the controller while it is processed (twice), with the
  poll counter reset in between — (1) install the poll callback BEFORE `load_state`, else those polls are neutral and a
  walking Jack loses a game frame; (2) time inputs by VI label (restored exactly), not by poll count. Verified by
  matching hashes against an uninterrupted cold run.
- **Menus (mash model):** 5–15 presses/s, both button styles, every phase → 16 distinct house arrivals, VI 1036–1074
  (1036 = frame-perfect); 5 within 8 VIs.

## The dog is under the pier and invisible (rendered check, 2026-11-14 noon)
- Rendered with the real renderer (rice, `experiments/zigzag_gif.py`, GIFs sent to Thomas): the dog-beach dog is never
  visible on the beach. Its entity sits at (−197.6, **y 118.3**, 142.4): ~50 below the pier deck (Jack on the deck
  y ≈ 172, on the sand ≈ 160) at the deck's lower edge, so the deck/water hides it. Diagnostic only (RAM write,
  not used in any data): moving the entity next to Jack renders the dog normally, so the sprite is fine.
- Collision ignores height: on the lower pier lanes Jack stops on the deck at (−224, 164) with
  `player entity.collision` (0x5C) = 1 (the dog's slot) and `dog entity.entityCollidedWithIndex` (0x58) = 0 (Jack).
  Blocks at |dz| 21.6 (with dx 26.4), passes at |dz| 27.6 → roughly a ±26 box, not a 34 radius.
- In both rendered routes the dog stayed at its spot after waking (within the clips). Thomas to confirm on hardware
  (no dog visible on the beach; an invisible stop on the lower side of the pier near where it leaves the sand).
- Rendered = fast mode: fastest fast-zone route (menus 10/s ph 0, U 276 V 52, C 80, D 86, B 126) READY VI 2595,
  slowest (10/s ph 5, U 283 V 44, C 104, D 94, B 138) READY VI 2635; blocked example (fastest with B 124) stops VI 2549.

## Preset zigzag (package `hm64-powernut-lab_zigzag_2026-11-14.zip`, runner `run_hm64_zigzag.sh`)
Code: `hm64/zigzag.py` (ZigZagInput, Session, drive, stage_hash / line_hash / cast_hash), `experiments/zigzag_jobs.py`,
`tools/zigzag_campaign.py` (ZZ_CODE zigzag-1), `tools/zigzag_report.py`. Stages Z0 check (reference route from power-on
= house 1036/499, farm 1448/704, beach 2264/1073, wake 191/1169, READY 339 at (−92, 194) draw 1263) → Z1 menus → Z2
house (U, V) → Z3 crossroads (C) → Z4 ranch → Z5 beach (D × B: wake, line key = line_hash 8 VIs after the wake,
READY/blocked per B) → Z6 one natural path per line (representative = earliest READY after the wake; members whose
state at their READY differs get their own line) → Z7 casts (one per distinct cast_hash, even VIs 6–2398 after READY,
bites 1 + 2, 0–20 s first; 1% repeat casts) → Z8 member recasts (2%) → ZIGZAG.md, zigzag_tables.json,
zigzag_casttable.csv. Merge points: house entry, farm +104, crossroads/ranch/beach +40 VIs. Casts replay the line's
representative (no rungs on disk). Member time base: a member's READY is `k_off` VIs after its line representative's.
Presets: zigzag-fast (rates 5–15/s, house/farm slack 8, ranch 6, D 82–94, B 118–149) and zigzag-full (4–15/s + 2-VI
taps, slack 40 per screen, D 82–136, B 110–157); the full run continues in the same work folder
(`runs/zigzag/hm64-lab`). Sandbox: test preset end to end OK (2 lines, all checks agree).

## zigzag-fast results (Mac, `hm64-campaign-zigzag-fast-20261114-125147.zip`, ~3 h on 13 workers)
- Z0 reference route matched. Menus: 16 house arrivals over VI 1036–1074 (1036 = frame-perfect); the fast class keeps the
  5 within 8 VIs of it (0–4 game frames late). 11 farm states, 44 beach states.
- **47 dog lines** from 6,776 members (0 split at the READY member check). 24 lines cast (90.8% of the route weight);
  42 lines have some casts (98% cover). Repeat casts 179/0 disagree, member recasts 667/0.
- Pool odds at ±100 ms (any line mix, Space at the dock end): zones 12.7% at 23.7 s after READY; release at bite 1
  7.1% at 6.8 s; hold to bite 2 10.4% at 23.7 s. Space at the beach load instead: 13.8%. 1st cut tight
  (`(D−84)//2 ≤ 1`): 14.9% (dock-end start) / 16.9% (beach-load start).
- The Lucky Timer reproduces the Python report's numbers exactly (tests/test_lucky_zigzag.js, tests/ui_lucky_zigzag.js).
  Simulated bite-1 identification: top line right 30.7%, release/hold call right 79.6%.

## In the Lucky Timer (v29.6 → v29.7, 2026-11-14 afternoon): route `nodog-zigzag-fast`
- Built with `tools/zigzag_routes.py <results>/campaign-zigzag --id nodog-zigzag-fast --label ...` into
  `webapp/assets/lucky_routes.json`; app rebuilt with `tools/webapp_rebuild.py` (same Dog Oracle data, new routes file).
  Packages `hm64-powernut-lab_lucky-zigzag_2026-11-14.zip` (v29.6, one row of preset cards) and
  `hm64-powernut-lab_lucky-zigzag-cuts_2026-11-14.zip` (v29.7, two-step cuts): prebuilt app, lab tarball,
  `run_hm64_webapp.sh`; no campaign runner, no ROM/save/states.
- A multi-line route: each of the 42 lines with casts is one cast series; the timer mixes them by weight. Two starts
  (anchors): **dock end** (Space when Jack stops at the end of the pier = READY, recommended) and **beach load**.
- Presets in two steps (v29.7, Thomas's request): row 1 = 1st cut Any / Tight (D 84–87) / Mid (88–91) / Loose (92–94);
  row 2 = 2nd cut Any / Early / Middle / Late, shown with odds only once a 1st cut is picked, each for the routes with
  **both** cuts (groups `cut1-<x>+cut2-<y>`; no 2nd-cut-only presets). ★ = best 2nd cut for that 1st cut; changing the
  1st cut keeps the 2nd. The text under the cards gives the same cast's odds if the cut was really another one.
- The pier window is exactly 7 game frames for every first cut (B window shifts with D), landing on 5 visible dock-end
  spots: z 170, 176 (Early, frames 1–2), 182, 188 (Middle, 3–4), 194 / 195.8 / 195.4 (Late = far edge, 5–7). Cuts before
  the window hit the dog (dead stop), after it the x = −212 wall.
- **The 2nd cut never changes the dog's line** (the dog wakes ~183–193 VIs after the beach load, the 2nd cut comes at
  ~D + 125–143); it only moves READY. So with the beach-load start the 2nd-cut odds equal the 1st-cut odds exactly
  (the app says so), and with the dock-end start knowing the 2nd cut removes READY spread. ±100 ms, smart zones:

| 1st cut | dock end, any 2nd | + early | + middle | + late | beach load (any 2nd) |
|---|---|---|---|---|---|
| any | 12.7% | — | — | — | 13.8% |
| tight | 14.9% | 16.6% | 16.6% | 15.5% | 16.9% |
| mid | 13.5% | 15.9% | 15.9% | 14.5% | 16.0% |
| loose | 13.2% | 14.4% | 14.4% | 13.6% | 14.4% |

  Cross check (dock end): plan for tight + early played as tight + middle 15.5%, as tight + late 11.7%; mid + early
  played as mid + late 7.6% — on the dock-end start a wrong 2nd-cut pick costs a lot.
- After the bite-1 tap the timer names the most likely dog line ("line N of M") and gives the release/hold call.
- The dog stopping Jack dead on the pier means off-pace (or a wrong save): restart. Cutting down the middle of the
  pier goes around it.
- The old single line (`nodog-nohorse-no-pickup`, legacy menus + beach walk) is kept and relabelled. The carry route
  keeps its own presets (pace is stored per route).

## Farm sparrows = a menu-timing tell (2026-11-14 evening, sandbox, `experiments/sparrow_probe.py`)
- Decomp: `startGame` → `func_800598E0` (start of day, before the house map loads) → `randomizeMiscAnimalSpawnVariants`:
  `gMiscAnimals[i].spawnVariant = getRandomNumberInRange(0, 3)` for 7 slots (0x8016FB08, 7 × 0x1C, variant at +0x16).
  Farm map load (`spawnWildAnimals`): not winter, sunny, hour 6–8 → slot 4 = 1: sparrow pair **at the door / doghouse**
  (−336, 0), (−368, 32); = 2: pair at the far east side (320, −352), (288, −352), off screen on this route; 0/3: none.
  Fixed by the house arrival (menu timing) only; the house walk cannot change it.
- All 16 house arrivals of the zigzag-fast run replayed in the sandbox (strict hashes = the Mac's) and walked to the
  farm (U 276 V 52): slot 4 = 2 at VI 1036, 1042, 1050; = 1 at 1046, 1048, 1056, 1064, 1074; none at 1038, 1040, 1044,
  1052, 1054, 1058, 1060, 1062. Spawned sparrows matched every time.
- **Fast zone (house VI 1036–1044):** 34.0% of the route weight has sparrows, all the far pair (VI 1036 1.6%, 1042
  32.4%), never on screen when leaving the house; the door pair never occurs. Sparrows at the doghouse on leaving the
  house = menus ≥ 5 game frames late (outside the fast zone) → restart early. No door sparrows proves nothing.
  Rendered check: `door_pair.gif` (START+A 12/s ph 0 → house 1046) shows the pair by the doghouse; the fast GIFs don't.
- Thomas (17:35): the sparrows he sees are the door pair → those attempts had menus ≥ 5 frames late, outside the fast
  table. Full preset menus (sandbox, `experiments/sparrow_menus.py`, 438 configs → 22 house arrivals VI 1036–1076):
  door pair at 1046, 1048, 1056, 1064, 1070, 1074 (draw 520) = **23.6%** of the full pool, far pair 17.7%, none 58.6%;
  42% of the full pool is in the fast band.
- **Checkbox idea ("sparrows at the door"), measured with an equivalent split on the fast data** (far pair 1036/1042 vs
  none; same arithmetic): best odds move only ~0.5 points (dock end 12.7 → 13.3 / 13.0; tight 14.9 → 15.7 / 15.4; beach
  load tight 16.9 → 17.3 / 17.1). The house arrival is one of several sources of line variety; the later cuts reshuffle
  it. Re-measure on the full data (22 arrivals, door split real) before building it.
- **Merge hazard for zigzag-full (found 2026-11-14 17:50).** `stage_hash` (RNG, clock, dog, player, main loop) leaves
  out the start-of-day rolls (misc-animal spawn variants, NPC locations). Measured farm draws (`experiments/
  sparrow_farm_draws.py`): any sparrow pair spawns with +4 draws by farm +100 (before the +104 merge point); the far
  pair then stays frozen (off screen); the **door pair keeps drawing** (+6–8 by stick-live 167, +14 over the farm).
  Fast run: 3 of 11 farm states merged far-pair and no-sparrow mornings; cold runs from each contributing house (10
  routes) gave identical crossroads/ranch/beach states, wake, READY and 40 s of dog/RNG after READY → fast data OK.
  Ranch animals (slots 0–4 < 2) differed between those mornings with no effect (off screen). Full run: door-pair
  mornings can merge at farm +104 with other mornings and then diverge → affected branches carry the wrong future.
  **Fixed in zigzag-2 (21:40):** farm fingerprint includes live sparrow slots (spawnVariant byte blanked); one-time
  cleanup of old folders (Z2 fix). Sandbox test preset `zigzag-sparrowtest` (10/s START>A: mornings 1036/1042 far pair,
  1038/1040/1044 none, 1046 door pair; U 274–279, V 46–56): the zigzag-1 fingerprint merged the door-pair morning with
  far-pair mornings in 3 farm states → 16 dog lines; zigzag-2 clean → 20 lines; zigzag-1 folder + cleanup + resume =
  zigzag-2 clean exactly (396 house paths, Z3 mapping, 20 lines, members, weights). Cold runs: far-pair mornings that
  zigzag-1 had merged into the door-pair state reach READY with draw 1257 / wake 1171 (zigzag-2 predicts the same),
  not 1269 / 1181 (zigzag-1). The door-pair routes themselves matched both (their state was the stored one).

## Turn windows of the fast zone, with goalposts (2026-11-14 evening; clips `experiments/zigzag_clip.py` + `_compose.py`)
VIs after each screen's map change (game frames = 2 VIs); from Z2/Z3/Z5 of the zigzag-fast run.
- House turn 1 (UL → DL) 272–283; **≤ 271 never reaches the farm (snags on the coffee table)**. Turn 2 (→ D) 316–335,
  but the two trade off inside the 8-VI house budget: turn 1 at 272 allows turn 2 at 320–333, at 283 only 324–327.
- Crossroads cut 72–104 (78–87 fastest, ranch at farm load + 586; 72–77 / 88–104 cost 2–6 VIs; 104 = top of the tested
  range); 70–71 cost 8 (over the 6-VI budget); 69 never reaches the ranch.
- Beach 1st cut 84–94 (82–83 never clear the small wall). 2nd cut: the 7-frame pier window (1st cut 86 → 212–225 after
  the load); one frame early → the dog stops Jack at (−224, 164); one frame late → the x = −212 wall at (−210, 220.5).
- Dock-end spots (1st cut 86): frames 1–7 → z 170, 176 (early), 182, 188 (middle), 194, 195.8, 195.4 (late, far edge).
- Budgets are per screen (menus: house ≤ 1036 + 8; house: farm ≤ house load + 420; farm + crossroads: ranch ≤ farm load
  + 592; beach: geometry only). Lateness does not carry over to the next screen's budget in this table; inside the
  house it does (turn 1 vs turn 2).
- Sent to Thomas: 5 side-by-side earliest-vs-latest MP4s (house turn 1, turn 2, crossroads, beach cut 1, cut 2), a 3×3
  pier-window MP4 (too early, frames 1–7, too late) and 3 still sheets (turn frames, pier-cut frames, landing spots).

## Cabin / crossroads travel grades — tested, no edge on the fast zone (2026-11-14 evening)
Thomas's idea: let the player grade the cabin and the crossroads fast / medium / slow by travel spread, on top of the cuts.
- Travel time is not monotonic in turn timing: crossroads fastest (ranch at farm + 586) only for the cut at 78–87, early
  (72–77) and late (88–104) cuts both arrive later; cabin fastest (farm at house + 412) only for turn 1 276–277 + turn 2
  328–329. So grades are by arrival (frames after the fastest), split in thirds: cabin 0–1 / 2 / 3–4 frames (13 / 32 /
  54% of the pool), crossroads 0 / 1–2 / 3 frames (30 / 55 / 15%).
- `tools/zigzag_routes.py --grades` emits member rows tagged with both grades (beach states reached by routes of
  different grades split by the route_weights chain) and the four-row axes; LuckyCore.groupOf builds any combination
  (v29.9 core; harmless without member rows). `tests/test_lucky_grades.js` scores the 9 × cuts tables.
- Result (±100 ms): best cells 19–19.6% vs 16.6–16.9% for the cuts alone, but random tags shuffled across the routes
  give the same or bigger gains (pool-weighted: real 17.6 / 17.4 vs random 17.0–17.2 / 17.4–19.1) — narrowing, not
  information. With grading errors (each screen graded right with prob q): beach start tight 17.6 (q = 1), 16.9 (0.8),
  16.3 (0.6), 15.6 (guessing) vs 16.9 without grades; dock end tight+early 17.4 / 16.7 / 16.1 / 15.5 vs 16.6. A 1–2
  game-frame difference (33–67 ms) is not something a player can grade reliably → not shipped in the app.
- Worth re-testing on the full table (40 VIs ≈ 0.7 s spread per screen, i.e. perceivably slow vs fast).

## Beach timing rules (measured 2026-11-15 on the zigzag-fast Z5 rows; used by zz_beach_scan_job)
- The stick is read once per game frame from the beach load: B and B+1 give identical results when D+B is even
  (8,888/8,888 pairs); D+1 (D even) gives D's row with every B shifted by −1 (264/264), i.e. only the absolute second-cut
  frame matters. The B that reach the dock end are one unbroken 14-VI window (484/484); its start depends only on D
  (D 84: B 130, D 85: 129, even D 86–94: 126, odd: 125).
- With the B grid starting at 110, the line key is read at t = D + 109, often before wake + 8 ("late" keys, key_off
  depends on D); harmless (the member check splits any mismatch) but it can split one dog line by D.

## Dog-spot lab (zigzag-4, 2026-11-15; package `hm64-powernut-lab_dogspots_2026-11-15.zip`)
Thomas's next experiment: SaveRAMs with the dog at spots he can repeat by hand (he picks the spots; nothing automated
searches spots), each run through the zigzag-fast recipe of route delays, cast tables per save, and a map of where the
recipe never reaches READY. Runner `run_hm64_dogspots.sh` (saves from `sourcefiles/dogspots/`), preset `dogspot-fast`,
comparison `tools/dogspots_report.py` → DOGSPOTS.md.
- **Dog-neutral.** No dog-wake rule (old: no row for a first cut made after the wake) and no wake key. Z5
  (`zz_beach_neutral_job`): every even D and every B with D+B even over B 112–151 is walked, the other parity copied by
  the two input-timing rules; rule 1 is walked for real at every D, rule 2 once per job; any mismatch → every (D, B)
  walked. B widened from 118–149 because with no dog under the pier the window opens 8 VIs earlier. READY now also
  needs x ≥ −96 (dock end; every zigzag-fast READY was at x −94.6…−92.0); non-READY walks are `blocked` (still 60 VIs
  short of the pier), `short` (stopped on the pier before its end) or `timeout`, with Jack's position.
- **Lines:** one candidate line per beach state anchored at the beach load; each member stores the dog-line hash at its
  READY detection and the next 2 VIs (the triple pins the game-frame phase, since odd VIs often repeat the state). After
  the representative's natural path runs, every member is matched to a path holding its triple (own line at the same
  time since the beach load first, then own line, then any line); unmatched members get a new line per beach state,
  run next round. Final round: a line whose representative's triple lies on another line's path ≤ 120 VIs after that
  line's READY is the same trajectory started later → merged (`merge_same_paths`).
- **Z0 for each save:** the zigzag reference route recorded twice from power-on (date, weather, clock, `currentTool`
  0x1D = 0x18 rod in hand, dogInfo at every map load, map-load times, READY or why not); the two records must be equal,
  the dog-beach save must reproduce the zigzag check numbers. Stage detection now accepts the seasonal map indices
  (maps.h: farm 82–85, crossroads 78–81, ranch 0–3, beach 9–12), so saves made on another day/season still run.
  Failure rows: house (U, V) never reaching the farm, farm walk never reaching the crossroads (1,200 VIs), crossroads C,
  ranch, all with where Jack stopped.
- **Report per save:** the save + where the dog is, the failure map (mass = uniform choices over the grids, stage by
  stage: kept / slower than the band / never reached, positions), the second-cut windows per first cut (READY / partly
  READY / why the rest stop), line collapse (lines per beach state), the web app's cut presets (share + best release /
  hold), plus `dogspot_summary.json` and `lucky_route.json` (Lucky Timer route entry, `zigzag_routes.build(save=…)`).
- **Sandbox validation (preset `dogspot-test`: 10/s START>A, U 274–279 × V 46–56, C 80/90, D 84–87; dog-beach save):**
  neutral lines vs the old wake-keyed lines on the same grid: all 1,680 members' predicted dog-line states agree
  (992,696 / 0 disagree over 40 s); member recasts 381/0, repeat casts 25/0; scan rows = full walk rows (2 states × 4 D
  × 40 B, incl. a wandering dog). Test-only `HM64_ZZ_TEST_DOG` (dogInfo poke at the house load; never set by runners):
  - dog off the route (village): **all 30 beach states and 2,640 routes collapse onto one line** (the RNG is the same
    trajectory, offset ≤ 80 VIs); the pier window is 22 VIs (D 84: B 122–143; D ≥ 86: 118–139) instead of 14 — the
    early 8 VIs were the sleeping dog blocking the lower lane.
  - dog on the final beach leg (−300, 194): reference route blocked at (−326, 194); each D keeps ~10 VIs READY, the
    rest of the window only partly (14–26% of beach states), Jack stopped at x≈−328.
  - dog on the farm path (−450, 40): every farm state stuck at x≈−424 z≈32 for > 1,200 VIs (the cold record shows the
    farm took 3,860 VIs until the dog wandered off) → the whole recipe fails at the farm.
- Run time per save ≈ zigzag-fast (Z5 ~1.5× the old full beach job's walks per state, casts dominate, ~3 h on the Mac);
  `HM64_ZZ_STOP_AFTER=Z6` gives the recipe, failure map and lines in minutes.

## Dog-spot saves from Thomas (2026-11-15) and "does the dog keep drawing at the pier?"
Saves (all made from the dog-beach save: spring 4, sunny, rod in hand; 11–15 bytes differ; all repeatable, reference
route reaches READY): 1 house right of the table (7.2, 6.9) · 2 farm default spot (−432, 96) · 3 crossroads north
(17.5, −129.5) · 3 crossroads west (−22.3, 81.8) · 4 beach-lineup1, beach (−373.5, −217.9) near the entry.
Packaged with the runner in `hm64-powernut-lab_dogspots-123_2026-11-15.zip` (saves 1–3; Thomas's request).
- **No Nut is reachable in 0–40 s without dog draws during the fishing:** with no dog on the beach the Nut roll is the
  bite roll + 31 draws; on the LCG stream, draws #1,000–#6,000 hold 8 bite-capable positions and none has a Nut at +31
  (first: #26,208; with offsets 30 / 37 there are #2,937 / #3,813 — they need dog draws between bite and catch).
  READY lands at #1,228–#1,297 on every save tested (the dog before the beach moves it by tens of draws only).
- **Draw probe** (`experiments/dogspot_draws.py`: route replayed from its ranch state, draw index every VI from the
  beach load to READY, then 2,400 VIs standing at the pier with no input), small grid (`dogspot-test`):

| save | beach load → READY: draws − game frames | READY → +40 s standing: extra draws | lines / beach states |
|---|---|---|---|
| no dog on the route (village poke) and save 1 (house dog) | +1 on every route (the clock) | 0 on every route | 1 / 30 and 8 / 192 |
| dog-beach (asleep under the pier) | +3…+21 | +130…+232 on every route (3–6/s; +28…+70 by 10 s) | 21 / 30 |
| save 4 beach-lineup1 | +3…+23 (dog on screen from VI 67) | **0 on 93.5% of the route weight**; +46…+148 on 6.5% | 98 / 30 |
| save 5 beach-lineup2, dog (−198.5, 223.5) | +3…+19 (dog first moves 209–215 VIs after the load) | +130…+232 on every route | 32 / 30 |

- Line concentration (lines holding 50% / 90% of the route weight): dog-beach 3 / 11 (top line 24.6%), save 5 4 / 10
  (13.3%), save 4 15 / 52 (7.6%). Same cast sample on the 3 heaviest lines each (every 15 game frames, 0–40 s, 240
  casts): dog-beach Nut bite 1 8 / bite 2 10; save 5 6 / 4; save 4 1 / 1. Save 5 walks the full pier width (all 22 VIs
  at every first cut reach the dock end; Thomas: no dog-block pier checks for these spots).

- Save 4: the dog never blocks (pier window 22 VIs, all cuts reach), but it reacts to the walk — 4–11 lines per beach
  state, split by the second cut B (every line holds all D) — and then mostly goes quiet at the pier. Cast sample (every
  15 game frames, 0–40 s, 80 casts per line): the two heaviest quiet lines 0 Nuts; an active line Nuts at 23.6 s (bite 1)
  and 35.1 s (bite 2). The dog-beach save's dog keeps drawing after READY on every route, which is why it is fishable.
- So what matters for the Nut is a dog that keeps drawing while Jack fishes; the draw count before READY barely moves
  the stream. Thomas's next idea: beach starting spots that keep the dog on screen and active at the pier (a "heat
  zone"), ranked by extra draws after READY and by line count (stability).

## Lineup lab: fixed tight first turn + beach wait (2026-11-15, Thomas's hypothesis)
Thomas: the dog "smears" because the zig-zag enters its activation perimeter at different points; fix the entry by the
tightest first turn (hug the small wall), vary a wait before the first step (a loose first turn corrected by turning
up costs ≤ half a second), keep the full pier width for the second cut.
- **Decomp:** there is no proximity circle in the dog AI. updateDog (animals.c) advances (and draws RNG) only when the
  dog entity's animation cycle ends (or on player collision); updateEntities (entity.c) resets the animation every
  frame while the dog's tile is off the visibility grid; the grid = tiles inside the camera's view quad (map.c
  checkTileVisible: 4 frustum corners = ±viewExtent rotated, around the camera tile that follows Jack). So the
  perimeter is the camera's view around Jack, tile-quantized — activation = the dog's tile entering it.
- **Model:** ZigZagInput `W`: stick neutral until VI 67 + W (Jack first moves at VI 67 with down-right held), legs late
  by W; beach starts `<beach key>@w<W>` (weights: W uniform). W in whole game frames (even VIs): with an odd W the D 84
  cut lands a frame early (stuck on the small wall); (W 1, D 85) = (W 2, D 84) on all 40 second cuts.
  Presets `lineup-fast` (zigzag-fast pace, D 84, W 0–30 step 2, B 112–151) / `lineup-test`. New per-route data: first
  VI the dog's tile is visible + Jack's x, z then (`dog_visible` in zigzag_jobs), dog visible at the end; per line
  draws every 60 VIs after READY + VIs visible. Report sections "Lineup: …"; runner env HM64_DOGSPOTS_PRESET /
  HM64_DOGSPOTS_DIR; package `hm64-powernut-lab_lineup_2026-11-15.zip` (sourcefiles/lineup/1 dog-beach, 2 lineup2).
- **Sandbox (lineup-test: U276 V52 C80 START>A 6/s → 6 mornings × 16 waits, full pier width, no casts):**
  dog-beach save: activation at VI 189 + W, Jack on the wall (x −456…−448, z 96…104), before any second cut →
  **1 line per beach start** over its whole window (B 130–143). beach-lineup2: VI 211 + W, Jack on the wall
  (x −452, z 160…168) → 3 lines per start: B 126–143 one line, the two tightest frames B 122–123 and 124–125 split off
  (Jack turns before activation). Fixed wait + second cut across the 6 mornings: 5–6 lines (the route before the beach
  now carries the spread). 18 / 19 lines in all; heaviest 15.6% / 15.3%; dog drawing after READY on every route
  (+42 / +41 draws over the first 10 s). zigzag-fast had 17 lines among D 84 members (44 beach states, W 0).

## Lineup-fast results, dog-beach save, and Lucky Timer v29.9 route `lineup-dogbeach` (2026-11-15 evening)
Mac run `hm64-lineup-fast-1-dogbeach-under-pier-0d78b95b-20261115-145613.zip` (D 84, waits 0–30 step 2, B 112–151):
704 beach starts (44 beach states × 16 waits), 9,856 members, **every beach start one line over its whole window
(B 130–143)**; dog activates at VI 189 + W with Jack at x −456…−448, z 96…104 for 100% of routes; 65 lines (heaviest
13.3%, 7 hold 50%, 19 hold 90%); a fixed wait + 2nd cut still spans 10–17 lines across the 44 beach states (the route
before the beach); dog drawing after READY on every route (+173 over 39 s). 11,685 cast states, Nut b1 416 / b2 338;
repeat casts 174/0, member recasts 1,046/0. Dock-end odds at 150 ms (report, aims with ≥ 80% coverage): pool release
7.6% / hold 8.2%; wait 0–8 VIs 8.8% / 9.7%.
- **Beach fade-in** (`experiments/beach_fade_probe.py`, rice render, 3 ranch states): the ranch fades to black ~9 VIs
  before the map change; the first non-black beach frame is 3 VIs after it (brightness ~3% of full, +2.5/80 per game
  frame), full at ~VI 65; Jack moves at VI 67.
- **App v29.9:** route `lineup-dogbeach` (tools/zigzag_routes.py `--lineup`): axes wait (Clean 0–8 / Small fix 10–18 /
  Big fix 20–30 VIs) × 2nd cut (spot z); anchors **fadein** (stopwatch from the first fade-in frame = map change + 3,
  recommended) and pier; `axes_head` text; axis words in renderAxes taken from the axes' `short`. LuckyCore.best now
  searches aims only where ≥ 80% of the plan's routes have a cast table (okMask; removed fake end-of-table highs: pier
  "all" zones 16.9% @40.3 s → 10.5% @21.6 s); zigzag-fast and legacy numbers unchanged. App (±150 ms, smart zones):
  fade-in start Any 10.7% @25.5 s, Clean 13.3% @32.8 s, Small fix 10.3%, Big fix 12.5%; dock end Clean 12.6%, Clean +
  early / middle 13.4%. Package `hm64-powernut-lab_lucky-lineup_2026-11-15.zip`; UI test `tests/ui_lucky_lineup.js`.
  Then (same evening, `hm64-powernut-lab_lucky-lineup-starts_2026-11-15.zip`): every multi-line route compares its starts
  for the picked preset (startRow / startCompare: best plan per start, no profile) - a "Start: …" line under the
  presets with a "use it" link to the best start, and the Start menu shows each start's odds and marks the best.

## Transition goalposts, double tap, and the dog's wake on the back wall (2026-11-15 night)
- **Ranch exit -> beach (rendered + 30/30 ranch states, `experiments/beach_transition_shots.py`,
  `transition_delta_probe.py`):** Jack's last step at VI -69 (vs the beach map change); main loop EXIT_LEVEL at -67 =
  first frame Jack stands still = first dimmer frame (game.c handleExitLevel: map + entities fade, rate 8/frame, black at
  -3); MAP_LOAD -3, LEVEL_LOAD +1, first light +3 (~3% brightness), MAIN_GAME +65, Jack moves +67. Goalpost 1 (-67) to
  goalpost 2 (+3) = **70 VIs on every ranch state**.
- **App v29.9 double tap** (fade-in start, on by default): tap 1 at goalpost 1 gives a provisional start (tap 1 + gap +
  m); tap 2 sets start = average (k = 1/2); |e| > 400 ms (or > 3 robust SD with 5+ pairs) = fumble -> tap 2 alone; no
  tap 2 within due + 900 ms -> tap 1 alone. Pairs d = tap2 - tap1 - gap in localStorage `hm64v29_lucky_fade2`; m =
  median shrunk n/(n+2). The pair gives the difference and steadiness of the two reactions, not the absolute offset
  (that still comes from the bite taps). Test `tests/ui_lucky_fade2.js`. Package
  `hm64-powernut-lab_lucky-doubletap_2026-11-15.zip` (+ screenshots).
- **Dog wake on the wall (dogbeach save):** visibility tiles 32, origin (784, 528): column = int((x + 800)/32), row =
  int((z + 544)/32); the dog's tile enters the view quad when column + row >= 30. Wall run x -451.6 (D84) or -452.0
  (D86) = column 10 -> wakes at row 20 (z >= 96; D84 VI 189 + W). x >= -448 (column 11, e.g. D88 x -446) -> wakes at
  z >= 64 (VI 179, 10 VIs early); x >= -416 -> z >= 32. D <= 82 sticks on the small wall. **D86 (one frame after the
  tightest cut) clears the small wall's corner and wakes the dog at VI 187 = 2 VIs before D84 W0: not in the lineup
  tables (W starts at 0 on D84).** Fix probe: a late cut by k frames + k up-left frames (x back to -449) wakes the dog
  at 187 + 4k (= D84 W 4k - 2) whenever the fix lands before the frame Jack's z reaches 64; the fix timing inside that
  window changes nothing. Screenshot sheet `HM64_dogbeach_wake_wall.png` (deadline = the dock corner's tip appearing
  at the bottom edge).

## Lineup + first cut D 86 (zigzag-4b, 2026-11-15 night)
- Presets lineup-fast / lineup-test: Ds [84, 86] (50/50), `rep_prefer_D=[84]` (line representatives stay the D 84
  ones of the first run, in line_members_neutral and in check_members_neutral's unmatched groups) so a resumed run
  reuses Z6 paths and Z7 casts by key / state hash. Env test knob HM64_ZZ_DS. Report: "first cut D" table (share,
  lines, lines shared, wake VI - W, odds) in ZIGZAG.md and the --one summary.
- Sandbox check (lineup-test, dog-beach, 6 mornings x 16 waits): D 84 only, then resumed with D 86: Z5 96 new walks;
  Z6 97 -> 19 lines, only 1 new (D 86 W w wakes at the same VI as D 84 W w-2 with the same RNG = the same dog line;
  the new one is D 86 W 0); Z7 5 new cast jobs of 41; member recasts 220/0 (D 86 members cast from their own routes
  agree with the shared tables). D 86 second-cut window B 126-139 (D 84: 130-143). Route builder (--lineup) mixes
  both cuts in every preset.
- Runner: run_hm64_dogspots.sh gains HM64_DOGSPOTS_WAIT=1 (queue behind the run holding the lock) and
  HM64_LAB_TARBALL; run_hm64_lineup86.sh = the same with defaults lineup-fast / sourcefiles/lineup / wait on /
  hm64-lab-lineup86.tar.gz. Package hm64-powernut-lab_lineup86_2026-11-15.zip (no saves: they are on the Mac from the
  lineup package). When the zips come: rebuild route lineup-dogbeach (howto: the first moment Jack clears the small
  wall or the frame after: both in the tables) and add beach-lineup2.

## Lucky Timer tap sequence + auto-tune (v29.9, 2026-11-15 ~21:30)
- Fade-in start, "tap sequence" (setting key fadeDouble): up to three Space taps, any one missable: 1 ranch exit
  (Jack's first still frame = first dim frame), 2 first light (always +70 VIs), 3 dock end (READY). Clock from 1 + 2
  (each estimates the first light; equal weights; > 400 ms apart or > 3 SD with 5+ pairs = fumble -> tap 2). seqPress
  classifies by timing: ~one gap after tap 1 = tap 2; else the dock end, scored against READY on the plan's routes
  (minT 331..379 VIs after the first light, mean 353, SD 10.9) under "first tap = exit" (prior 0.75) or "first tap =
  fade-in, exit missed" (0.25, re-anchors the clock); |z| > 3.5 = stray (ignored); < 400 ms after the last = bounce.
- Dock-end tap (goal3): routes re-weighted by N(tau3 - minT - r3, hypot(tap SD, clock SD)), r3 = the fade-in tap's
  delay (startDelay + auto-tune shift); band posterior shown (Clean / Small fix / Big fix); cast re-aimed when it gains
  >= 0.2 points and is >= 180 VIs after the tap; zones + bite forecasts use the re-weighted plan (_final, P() skips it).
  Simulation (tests via /home/claude/scratch/sim_ready.js, 300 attempts, 150 ms cast spread, zones): 9.9% without ->
  11.7 / 11.6 / 11.8% with a 30 / 60 / 100 ms tap SD; 11.5% when the tap is 50 ms later than assumed.
- **One bite tap does not pin an attempt's console offset or route** on this plan (posterior offset SD 3.3 VIs = its
  prior, READY SD ~10.6 VIs = prior): absolute per-cue reactions per attempt are not measurable; dock records
  (tap 3 vs the bite posterior's READY) are kept (localStorage hm64v29_lucky_dock) to check the same-delay assumption.
- Auto-tune (L.autoTune, on): run.cs = the profile's offset (bias0 with cast taps, else bias; n >= 8, clamp +-18 VIs)
  shifts wall0; taps are saved minus cs and posteriors use b - cs, so the profile fits the unshifted clock. Test
  ui_lucky_autotune.js: true offset 6.05 VIs -> learned 6-8, residual -2..0 VIs over 6 more attempts. Tests
  ui_lucky_tapseq.js (all 3, each one missed, bounce, stray, auto shift, dock records). Package
  hm64-powernut-lab_lucky-tapseq_2026-11-15.zip.

## Lucky Timer tap format + clock-tap precision cascade (v29.9, 2026-11-15 ~22:00)
- **First control cue** (rendered, D84 route, down-right held through the load): MAIN_GAME at VI 65 after the map
  change; Jack moves 6 units at 67 (a hair of camera scroll, sprite unchanged) and turns to face down-right at 69 (the
  visible cue) = **66 VIs (1.091 s) after the first light**. Sheet HM64_first_control_beach.png.
- Tap format (L.tapCues, default exit + fade + ctrl + dock; old fadeDouble off -> ['fade']): cue times on the fade-in
  clock -70 / 0 / +66 / READY. assign(): every assignment of the taps (time order) to the ticked cues (time order) or
  "stray", scored by the clock taps' agreement on one first light (spread s each), the dock tap vs READY (plan mean /
  SD), log 0.1 per skipped cue, log 0.05 + log(1/8000 ms) per stray; clock = mean of clock taps minus per-cue offsets
  vs the fade-in tap (taprec records, shrunk n/(n+2)), start-key delay alignment, auto-tune shift. Tests: all four,
  each one missed, a stray, fade + first control only (gaps 1.157 vs 1.091 s are told apart by the dock tap), dock only
  -> dock-end start.
- Clock-tap precision (L.tapSdAuto / L.tapSdMs): auto = pooled SD of the clock taps around each attempt's mean (5+
  attempts with 2+ clock taps; floor 15 ms), else 60. Cascade: sigEffMs('fadein') = sqrt(max(slider^2 - 60^2, 30^2)
  + (s/sqrt(n))^2) feeds sigVI() (all plans, zones, posteriors; cache keys use it); dock-end read with
  hypot(max(s, 50), clock SD). Sim: dock-end tap with 30 ms spread and 50 ms late: 9.9% -> 11.4%. Package
  hm64-powernut-lab_lucky-tapformat_2026-11-15.zip.
- Thomas (22:00): the beach cue is the first light OR first control, never both (1.09 s apart, too tight to tap and
  play). Panel: ranch exit checkbox, beach-cue radio (default first control), dock-end checkbox; a saved setting with
  both keeps first control; editing the format switches to the fade-in start. Defaults now exit + ctrl + dock (2 clock
  taps: 150 ms slider -> 144 ms at 60 ms taps). Package hm64-powernut-lab_lucky-tapformat2_2026-11-15.zip.

## Tap strategies + the "arrival profile" question (2026-11-15 ~22:15)
- App: L.tapStrategy b / eb / bd / ebd (default) / d (= dock-end start) + L.beachCue ctrl (default) | fade; the plan
  uses the strategy's clock-tap count in the cascade; in two-tap sets a lone tap = the first cue (the 2nd may be
  missed), in the three-tap set any one. Cue offsets are learned vs the current beach cue; the bite-tap profile
  (auto-tune) is kept per beach cue (taps store ref). Old v29.9 settings migrate. Package
  hm64-powernut-lab_lucky-tapstrategy_2026-11-15.zip.
- **Arrival profile (taps at every screen's gain / loss of control) - measured, not worth it**
  (experiments/arrival_value.py on the save-1 lineup data, 150 ms, release-or-hold): 44 beach states load 2264-2286
  VIs after power-on (12 values, up to 8 states on one VI); the RNG draw at the beach minus VI/2 takes 4 values
  (route-dependent extra draws), so the arrival time does not fix the RNG. Best odds: whole mix 8.2%; beach-load VI
  known 8.3%; beach state known 8.4%; wait W known 9.9%; **beach state + wait known 20.2%** (= the exact dog line). Only
  frame-exact knowledge of both pays, and leg times differ by 2 VIs while human taps scatter 2-4 VIs: the dog line is
  identified after the cast by the bite fingerprint instead.

## App settings reorganised (v29.9, 2026-11-15 ~22:30)
- Lucky Timer: left = L1 Plan (how-to in a remembered fold) + L2 Start & taps (start, start key, tap strategy and
  beach cue as dropdowns, clock-tap precision); right = L3 Run, L4 Attempts, L5 Timing & offsets with one summary line
  (renderTimingSum: clock = taps -/+ start-key delay, auto-tune, beep correction, plan spread), timing spread,
  auto-tune, bite-tap profile (no duplicate offset lines; "Set beep correction" only with auto-tune off), folds
  "Manual offsets" (start-key delay, beep correction) and "Cast practice" (canvas redraws on open).
- Settings dialog tabs (settingsTab in hm64_app_v28.js; opens on the current side): Lucky Timer (cast tap + its
  precision, facing, chirps, sound, angler frames) / Dog Oracle (your timing; logging and taps; histogram and
  display; console and practice; sound; "Dog Oracle defaults") / Calibration & data. All element ids unchanged; UI
  tests pass (ui_labels gives no output on v29.8 either). Package hm64-powernut-lab_lucky-layout_2026-11-15.zip.

## Full lineup run with D 84 + D 86, both dog spots (hm64-lineup-fast-20261115-202348, 2026-11-15 23:15)
- Save 1 dog-beach (dog under the pier): D 86 added 1 line (65 -> 66), 53.8 min; save 2 beach-lineup2 (dog x -198.5,
  z 223.5): 83 lines, 110 min (the "83 lines" log Thomas pasted at 21:42 was save 2, not save 1).
- **Stability:** whole mix about equal - heaviest line 13.7% / 13.6%, lines for 50% 7 / 6, for 90% 19 / 21. Per beach
  start save 1 is deterministic: 2 lines per start (= 1 per first cut, 684/704 starts), the dog wakes at one spot on
  the wall for 100% (189 + W / 187 + W); save 2: 3-5 lines per start (the tightest 2nd cuts B 118-123 change the
  line), wake spot on the wall for 72.7% (27.3% from x -448..-440, z 144-160), wake VI 211 (82%) / 207 / 209.
- **Nut opportunities (app, 150 ms; fade-in start):** Any 10.7% (save 1) vs 11.5% (save 2); Clean 13.1 / 13.0; Small
  fix 10.7 / 11.8; Big fix 12.7 / 12.6; dock-end start Any 10.6 / 11.0. Known-line best 25.7% / 26.3% (lines >= 20%:
  76% / 82% of routes; >= 30%: 36% / 27%). Bite-tap pool sim (dock-end start, own best aim +-100 ms): top dog line
  right 31.9% / 41.3%, release/hold call right 75.1% / 90.3%, Nut available on bite 1 or 2 10.8% / 13.4%. Report
  (release / hold, dock-end aim): 7.54 / 8.12% vs 7.17 / 8.32%. Verdict: stability ~equal overall (save 1 steadier
  per start); save 2 has slightly more Nut opportunity, mostly in the forecast after the bite tap.
- App: routes lineup-dogbeach (66 lines) + lineup-lineup2 (83 lines) rebuilt/added (lucky_routes.json 4.1 MB, app
  7.8 MB); test ui_lucky_lineup2.js. Package hm64-powernut-lab_lucky-2spots_2026-11-15.zip.
- Pre-beach taps (e.g. a farm-exit tap to drop routes that arrive too early): bounded by "beach state known"
  (arrival_value.py on the D 84 + 86 data, release-or-hold 150 ms): save 1 whole mix 8.1% -> beach-load VI known 8.2,
  beach state known 8.4, wait known 9.4, beach state + wait 14.9; save 2 8.3 -> 8.4 / 9.2 / 8.9 / 13.8. The tables
  already hold only the fast band (house +8, farm +8, ranch +6 VIs of the fastest), and a farm-exit tap sees only part
  of the route timing at 2-4 VIs of tap scatter: not worth a tap. The dock-end tap already carries the wait info.
- Thomas's tap fingerprint (taps at house load, farm load, ranch load -> farm + ranch legs; mean reflex calibrated,
  scatter left; experiments/tap_fingerprint_value.py, 1,500 draws, release-or-hold 150 ms). Ceilings with the wait
  KNOWN: save 1 no route taps 9.5% -> scatter 60 / 35 / 20 / 10 / 0 ms: 9.7 / 9.9 / 10.4 / 11.4 / 12.0%; save 2 9.0 ->
  9.2 / 9.3 / 9.7 / 10.5 / 11.0%. Wait unknown: +0.1-0.3 at any scatter. Legs come in 1-game-frame (33 ms) steps; tap
  differences carry sqrt(2) x scatter, and calibrating the mean delay does not shrink the scatter (it cancels in the
  differences anyway). Worth building only if a runner's measured clock-tap spread is <= ~15-20 ms (the app's auto
  precision shows it after 5 attempts) and the wait is pinned (the dock tap only narrows it).

## Lineup lab on the sparrow mornings (zigzag-4c, 2026-11-16 ~00:45)
- Thomas: dog-beach is his field; explore menus 5-9 game frames late. Menu mass of the lineup-fast grid by house VI:
  1036 0.9%, 1038 10.5, 1040 11.7, 1042 15.0, 1044 15.8 (fast band 53.9%); 1046 9.5, 1048 3.3, 1050 2.8, 1052 6.0,
  1054 6.0 (5-9 frames: 27.6%; door pair 1046/1048, far pair 1050, none 1052/1054); slower 18.5%.
- Code: house_ok() band (house_lo..house_slack VIs after house_ref or the run's fastest) in the campaign (Z1 keep,
  route_weights), the report's failure map and the route builder; zigzag_routes._preset_of now matches the results
  folder's preset (lineup builds were reading zigzag-fast's cfg: checked, the built groups/lines are identical).
  Presets lineup-sparrow (house_ref 1036, house_lo 10, house_slack 18, rest = lineup-fast) and lineup-sparrow-test
  (sandbox: houses 1046/1048/1052/1054 picked, 13 lines, Z1-Z8 + report + route build OK, 10 min).
- Runner run_hm64_sparrow59.sh (lineup-sparrow, sourcefiles/lineup, only 1-dogbeach, queues). Package
  hm64-powernut-lab_sparrow59_2026-11-16.zip.

## Sparrow mornings: results + the door-sparrow table (2026-11-16 morning)
- Run hm64-lineup-sparrow-1-dogbeach-under-pier-0d78b95b-20261116-004521 (lineup-sparrow: menus 5-9 game frames late,
  house VI 1046-1054): 99 dog lines (97 with casts), 24,008 cast states, repeat checks 604/0; heaviest line 11.0%,
  10 lines hold 50%, 56 hold 90% (fast band: 66 lines, 13.8%, 7 / 18). The dog wakes on the back wall every time
  (D 84: 189 + W, D 86: 187 + W); 2 lines per start, as on the fast band.
- Failure map: 0.2759 of the menu mass in the band -> 0.1035 reaches the dock end. House losses (330 of 1820 runs,
  mass 0.050) = turn 1 at U 270-271 (all 130 + 130: the coffee-table snag, as on the fast grid) + 85 at U 272-275.
  Not the sparrows.
- 52 beach states, 36 of them reached from more than one house arrival (mornings merge by the beach). Split by the
  route_weights chain (`zigzag_routes.house_split`): door-pair mornings 1046/1048 = 59.5% of the run's weight,
  53 lines (52 with casts; heaviest 13.5%, 7 lines for 50%, 27 for 90%); 1050-1054 (far pair / none) 40.5%, 76 lines.
- Lucky Timer odds (LuckyCore, 150 ms, smart zones, best aim), preset All / Clean wait:

  | mornings (table used) | fade-in start | dock-end start |
  |---|---|---|
  | fast band 0-4 (lineup-dogbeach) | 10.7 / 13.1 | 10.6 / 12.6 |
  | door sparrows 1046/1048, own table | 11.7 / 12.4 | 10.9 / 12.0 |
  | door sparrows, aimed with the fast table | 9.1 / 8.6 | 9.0 / 8.6 |
  | 7-9 late (no door pair), own table | 11.5 / 10.3 | 11.3 / 9.9 |
  | 7-9 late, aimed with the fast table | 11.1 / 6.9 | 10.1 / 6.9 |
  | all 5-9 in one table | 10.8 / 10.7 | 10.7 / 10.5 |

- No-door mornings = fast band + 7-9 late, mixed by menu mass (53.9 : 14.8): fast table 10.8 / 11.7 (fade-in, All /
  Clean), a merged table 10.8 / 11.9; dock end 10.5 / 11.3 vs 10.6 / 11.6 -> no merged table (<= 0.3 points). The
  fast table's Clean preset shows 13.1% but plays ~11.7% when 7-9-late mornings slip in (mash-model mix).
- Built: route `lineup-dogbeach-sparrow-door` "Dog-beach · sparrows at the door: menus 5-6 frames late (53 dog
  lines)" with `tools/zigzag_routes.py RESULTS --lineup --houses 1046,1048` (new option: member weights x the
  house-arrival path share; the results folder must sit under results/lineup-sparrow/ so the preset is found).
  lineup-dogbeach's howto now says: sparrows by the doghouse as you leave the house -> switch to this route.
  lucky_routes.json 5.3 MB, app 9.0 MB (v29.9 data). Test tests/ui_lucky_sparrowdoor.js (app, default 3 taps: fade-in
  All 11.8%, Clean 12.5%, dock end 10.9%; tap sequence OK). Package hm64-powernut-lab_lucky-sparrowdoor_2026-11-16.zip.
- Door sparrows also show at house 1056/1064/1070/1074 (10+ frames late, no table): slow menus + door pair = restart.

## Lucky Timer: tap data per route / strategy / beach cue (v29.9, 2026-11-16 ~09:30)
- Thomas: show the tap data behind the auto precision, stored per tap strategy; clear one strategy/route set; cull
  blatant fumbles. (Context: a per-screen Kalman filter on the taps pays only at <= ~15 ms per-tap scatter; this
  section is where that number is read.)
- Storage: one localStorage key per set `hm64v29_lucky_tapset/<route>/<strategy>/<beach cue>` = [{at, y: {exit,
  ctrl|fade: ms, centred per attempt}, d?: dock tapped, s?: strays, x?: culled, m?: migrated}], <= 120 per set; offsets
  and spread from the last 40 kept. The old shared list `hm64v29_lucky_taprec` (+ older fade2 pairs) migrates once into
  `<route>/ebd/<cue>` (strategy not recorded; rows "carried over"); marker `hm64v29_lucky_tapset_v`.
- Auto precision: eb / ebd from their own set (60 ms until 5 attempts); b / bd (one clock tap: no spread to measure)
  borrow from eb + ebd of the same route + beach cue. The beach cue is part of the set (the old pooled list mixed exit
  offsets vs first light and vs first control).
- UI: fold "Tap data for this strategy (n attempts, k culled -> ±s ms)" in the L2 tap box (L.tapDataOpen): set name; per
  attempt the gap exit tap -> beach-cue tap, vs the game's gap (2.248 s first control / 1.157 s first light at
  16.53 ms/VI), vs your usual (median); ⚠ beyond max(100 ms, 3 robust SDs); cull / restore per row; "Clear this set";
  "Forget all tap data". Changes refresh the plan (caches keyed by the spread); during an attempt they apply from the
  next one. Taps far off both cues are strays in assign() and never stored (threshold ~6.5 x one tap's spread).
- Test tests/ui_lucky_tapdata.js: 7 attempts incl. a +240 ms fumble -> ±57 ms; cull -> ±15; restore -> ±57; eb its own
  set (2 attempts -> 60); bd borrows ±15 from 8; fade-cue set empty; clear set keeps eb; migration; forget all. In
  ui_lucky_tapseq the stats are now per set (3 records -> 60 ms default instead of a pooled 15). Package
  hm64-powernut-lab_lucky-tapdata_2026-11-16.zip.

## Lucky Timer: sparrows checkbox, dock-end guess on the cards, personalized casts, visual cues (v29.9, 2026-11-16, 3rd build)
- **Route in Settings + sparrows checkbox.** Route entries may carry `variant_of` / `variant` (zigzag_routes.py
  `--variant-of lineup-dogbeach --variant sparrows`); lineup-dogbeach-sparrow-door is the dog-beach route's `sparrows`
  variant. Settings (Lucky tab) lists base routes only; L1 shows the route + "Sparrows at the door" (also the S key;
  L.sparrows remembered). Switching keeps the preset and the start; during an attempt (before the cast is due) the clock
  and taps carry on and the dock-end tap is re-read on the other table. Tap sets are keyed by the base route.
- **Dock-end guess on the L1 cards.** goal3 computes the posterior over every wait x 2nd-cut preset (share x mean
  likelihood of the tap); during the attempt the cards highlight the likeliest wait (green), the player's own pick is
  dashed, back after the attempt; a lamp flash "SMALL FIX 53% ✓". Simulated (1,200 dock taps per route, READY-time
  likelihood as goal3): wait right 67-70% at 30-60 ms tap spread (chance 37%), shown confidence calibrated (67% shown /
  67% right); 2nd cut right 45% on dog-beach (chance 43%), 62% on lineup2 (55%): READY moves with the wait far more than
  with the 2nd cut. So the 2nd cut is highlighted only when >= 70% (else "the tap can't tell"); on the fade-in start it
  changes nothing anyway. Preset rows are pre-computed during the attempt (one per 40 ms) so the highlight is instant.
- **Personalized cast suggestion (checkbox, experimental, off by default).** LuckyCore accepts a measured kernel
  {id, k, r, sd} wherever it took a Gaussian SD (k[d + r] = P(landing d VIs after the aim); smoothing now indexes k by
  landing - aim, identical for symmetric kernels; caches keyed by the kernel id). The app's kernel: the B presses to the
  current cue type (practice, last 80, + real casts with the cast tap, last 40; beyond 3 MAD dropped) + the cast-cue
  correction, KDE (Silverman bandwidth >= 10 ms) convolved with the clock error (clock-tap spread / sqrt(clock taps); 60 ms
  for a one-tap start) and the console-offset uncertainty (auto-tune: one bite tap's spread / sqrt(n); not learned:
  60 ms); < 8 presses: the slider's B-press part. The profile fit keeps the standard Gaussian. L1 text: the kernel's parts
  and the standard aim's odds under the player's own timing. Example (dog-beach, Clean, fade-in, correction -110 ms,
  60 presses each, offset not learned): presses ±25 ms -> aim 32.82 s 16.1% (standard aim 25.96 s gives 14.4% with that
  timing); ±70 -> 32.82 s 14.7% (13.9); ±140 -> stays on the 25.9 s plateau 12.7% (12.7); ±90 with a late tail -> 32.74 s
  13.6% (13.3). The average delay itself is removed by the cast-cue correction (both modes); the spread and how well
  the offset is known decide peak vs plateau.
- **Visual cues replace the beeps** (sound off by default, migrated once with L.cueV; Settings: sound back on, edge
  glow). Lamp at the top of L3 (cueAt / renderCue, per frame): GET READY + bar from 2 s, amber pulses 3/2/1 at 1.5/1.0/
  0.5 s, green CAST (0.35 s); after the cast green = release on a bite now (zone / Nut-bite moment / bite-2 Nut moment,
  bar = time left), amber = one opens within 1.5 s (bar fills, two blinks at 0.6 / 0.3 s), yellow = hold, red = DUD;
  flashes for taps (cue name ✓, extra tap ignored, cast logged ±ms, dock-end read). Screen-edge glow (inset box-shadow
  on a fixed overlay) on pulses / CAST / windows. Practice uses the same lamp; presses to the visual cue are tagged v: 1
  and kept apart from presses to beeps (pracErrs by cue type). UI texts: "beep" -> CAST cue / cast-cue correction.
  The Dog Oracle side still beeps (its countdown also shows on screen).
- Tests: tests/ui_lucky_v2910.js (route options, sparrows checkbox + S key + lineup2 disabled, mid-attempt switch, guess
  highlight + own dashed + revert, personalized on / off, lamp states + DOM + glow); ui_lucky_sparrowdoor.js uses the
  checkbox; all other UI tests: same numbers, texts changed. Package hm64-powernut-lab_lucky-cues_2026-11-16.zip.

## Lucky Timer: "Your timing" - the offsets harmonized (v29.9, 2026-11-16, 4th build)
- Thomas: too many offsets; one place, the same person's data harmonized. Inventory before: start-key delay per start
  (fade-in / dock end / beach 150, READY 120, dog landing -130), auto-tune shift (bite taps), clock-tap per-cue offsets
  (tap data), cast-cue ("beep") correction written by three things (by hand, cast practice Apply / keep applying, the
  profile's "Set correction" button when auto-tune was off), timing-spread slider (by hand or practice Apply, then the
  clock-tap cascade, then the personalized kernel), bite-tap lag (profile; prior = the Dog Oracle tap delay), cast-tap
  precision (Settings), dock-end delay (assumed = the clock taps').
- Now L5 · Your timing: four rows, each from ALL of its data (auto) or set by hand (L5 › Set by hand, one box per row):
  start taps (one start-tap delay for every start, dog landing aside; + auto-tune), B press on CAST (cast practice +
  real casts with the cast tap, same cue type; correction = minus the median), bite taps (profile lag), how much you
  vary (one spread = sqrt(press SD^2 + 60^2 start tap + offset SD^2), offset SD = 60 ms until auto-tune has 8 cast-tap
  attempts, then per-tap / sqrt(n); the fade-in cascade replaces the 60 ms by the clock taps). Practice Apply = "Copy to
  my hand-set values" (only shown when a row is manual); the profile's correction button and "keep applying" are gone.
  Reacting to an untimed cue (start, bite: ~150-300 ms) and pressing on a seen countdown (CAST: near 0) stay separate
  rows on purpose. With data the standard bell curve and the personalized kernel now nearly agree (test: ±91 vs ±94 ms,
  same aim 32.8 s); the kernel adds only the shape.
- **Auto-tune learns the clock only from attempts with the cast tap** (bias0; nCast >= 8). Without it a bite tap mixes
  clock, B press and bite-tap lag. Sim (experiments/sim_timing_double.js, a headless page script like tests/ui_*.js; dog-beach all, fade-in 1 tap; start tap 50 ms later than
  the delay, B 100 ms after CAST ±25, bite taps 13 VIs; correction -95 from 10 practice presses): with the cast tap the
  clock learned +3...+4 VIs (true +3) and the landing error went from about +55 ms to +16 ms (attempts 9-12); without it the
  fit put the shift into the bite lag (bias ~0): my first rule (bias + correction, to undo a suspected double count of the
  B press) shifted the clock -94 ms (landing +167 ms) - rejected; the old rule (bias) learned ~nothing there. Now: no
  cast taps -> the clock stays at the start-tap delay and L5 says why.
- Start-tap delay migrated from the fade-in value (else dock end, else 150); the carry route's READY start now uses it
  too (was 120). Tally entries and practice presses carry v: 1 when made to the visual cue (sound off); press data is
  pooled by cue type.
- Dog state in the lineup / sparrow tables: none at frame level (each line = state hashes per frame, RNG draws every
  60 VIs, wake / first-move VI, VIs on the visibility grid; members: wake spot and READY). The dog-beach dog is under
  the pier deck (never visible), so the Dog Oracle has nothing to watch there. On lineup2 the dog is on the open beach:
  re-recording the 83 lines' natural paths with the dog's position / facing / animation per VI (Z6 replay, no casts)
  would show whether what a player can see separates the lines before the cast (known-line ceiling ~26% vs ~11%).
- Tests: tests/ui_lucky_timing.js (rows, pooled presses, beep-era casts kept apart, auto-tune rule, manual rows, one
  start delay); ui_lucky_autotune.js runs with the press rows by hand (its synthetic casts search a cast frame) and gives
  the old steps exactly. Package hm64-powernut-lab_lucky-timing_2026-11-16.zip.

## Lucky Timer: Space inferred by time, one-reaction auto-tune, NaN fix (v29.9, 2026-11-16, 5th build)
Thomas: B vs Space was unclear, and the tool should tell what each Space press is without a held key. B always = the
N64 controller's B; Space = the keyboard tap. Every Space is classed by time (unchanged mechanics, now said plainly in
L3 and in the how-to doc "HM64 Lucky Timer v29.10 — how to use and calibrate"): stopwatch off → start; start .. 1.5 s
before CAST → route taps (assigned to the strategy's cues; misses skipped, strays ignored); 1.5 s before .. 0.6 s after →
nothing (cast tap only if turned on); from the plop → bite 1, 0.4 s later → bite 2. The cast tap stays optional (off).
- **Bug (all builds since the cast-cue correction):** stored taps keep the CAST cue's sub-VI time (aim + correction /
  VI); LuckyCore.tapPosterior used that fractional T as an index → Z NaN → the profile (auto-tune, "Best for me"
  re-weighting) learned nothing from bite taps whenever the correction was not a whole VI. Fixed (T rounded inside
  tapPosterior); stored taps are re-read correctly by the new build.
- **One-reaction tie, corrected:** start tap k VIs later than the start-tap delay d → the stopwatch runs k behind the
  console → b = p + k (p = B press vs CAST from practice) and the bite-tap lag in stopwatch terms = d exactly (not
  d + k as first written). 1-D fit over k; applied as round(0.7 k) (shrunk: bite taps slower than start taps push k
  up by about half the difference). Lab sim (experiments/sim_timing_double.js style, start taps +50 ms, 24 attempts):
  untuned landing ~+60 ms; bite taps as late as start taps → +27 ms (unshrunk +14); 100 ms slower → −35 ms (unshrunk
  −56). With the cast tap (no assumption): +16 ms. Needs 5 cast-practice presses + 8 attempts with a bite tap.
- L3 key line, L5 learn label, Settings cast-tap label and the bite messages now say "B (controller)" / "Space".

## Next
0. Dog-spot lab: Thomas makes the saves and runs `run_hm64_dogspots.sh`; then compare DOGSPOTS.md and add the useful
   saves' `lucky_route.json` entries to the Lucky Timer.
1. zigzag-full is running on the Mac (same work folder); when it is done, build route `nodog-zigzag` (full) with
   `tools/zigzag_routes.py`, and consider presets by mash rate and by per-screen slack.
2. Hardware: how many frames Thomas really spreads over per screen (the bite-1 line check will show it).
3. Calibrate the beach-load cue (first visible beach frame vs the map change) for the beach-load start.
