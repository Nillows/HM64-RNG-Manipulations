# HM64 lab — status and results (2026-11-13)

What has been established, what each run showed, and what is next. Facts and formats are in
`HM64_TECH_REFERENCE.md`; how runs are executed is in `HM64_MAC_RUNBOOK.md`.

## Where things stand
- **The lab works and is trusted:** deterministic headless mupen64plus; the route port reproduces the legacy
  measurements exactly; the dog AI model has 0 unexplained decisions; the BizHawk pier state reproduces 8/8
  recorded catches; casts from savestate rungs equal casts from READY.
- **The oracle works in the emulator:** every arrival has natural Nut casts; a simulated runner can identify
  the dog path within seconds; the limiting factor is how precisely a human can press B.
- **The whole arrival pool is 16 dog paths.** 36,014 routes → 268 anchors → 271 arrivals → 16 world lines
  (same dog + RNG path entered up to ~0.9 s earlier/later). Top 10 paths = 95% of routes.
- **Identification is easy; the clock comes from prompt logging.** Three animation+direction logs (~2.3 s from a
  READY log) identify the path. Logging animation+direction promptly at each change for 10 s pins the clock to
  ~1.5 VIs (strategy lab); whistles are not needed (no better per data point, and they move the dog onto
  post-whistle tracks that would need their own cast tables).

## Oracle run (Mac, 2026-11-12, 126 min; 121 routes → 45 arrivals; casts every game frame 0–20 s)
- Every arrival has natural Nut casts; earliest a median 0.2 s after READY. Release is easy: any poll in the
  20 after the bite shows. No whistles needed for any arrival.
- Blind press at the dock 2–20 s after READY: 6.1% Nut (emulator; ~3× the 1/51 assumption; needs hardware check).
- World lines: 45 arrivals = 15 dog paths; overlapping winning casts agree 4,061 times, disagree 0.
- Perfect-timing oracle (relative logging, ±3–17 VI gap tolerance): a press that wins for every remaining
  candidate exists for 45/45 arrivals, median 2.6 s after READY (p90 ~5 s), ~4 candidates left.
- **Timing error decides the odds** (tool aims at the best blurred target; estimated odds = realised):

| B-press error (1 s.d.) | 0 | 8 ms | 17 ms | 25 ms | 33 ms | 50 ms | 67 ms | 100 ms |
|---|---|---|---|---|---|---|---|---|
| P(Nut) | 100% | 99% | 85% | 74% | 63% | 48% | 38% | 28% |

  With loose timing the tool aims at runs of 2–3 consecutive winning frames, many 5–6.5 s after READY.
  Reaction-only clock alignment probably leaves 30–50 ms (≈50–60%); a whistle/READY key anchor could approach 1 frame.
- Layer 1 link (full index): 45/45 arrivals linked, anchor RNG = native READY RNG for all; 44/45 native paths
  are one of the Layer 1 hypotheses and collapse to one end state; the 1 miss changes sprite at READY+1 VI,
  inside Layer 1's READY-transition window (comparison now starts after it; recheck pending).

## Observe run (Mac, 2026-11-12 12:59, 15.5 min; ≤2 routes per anchor, 80 s after READY)
- 271 arrivals from 268 anchors (8 anchors reached two arrivals). World-line check: 1,004,627 aligned VIs between
  copies, **0 visible and 0 hidden-state mismatches**; copy offsets −54..+46 VIs, always even (same 30 Hz phase).
- Paths by route share: 26%, 16%, 13%, 12%, 10%, 5%, 5%, 5%, 2.7%, 2.5%, then 6 small ones (4.7% together). 15 of 16 paths (all but one 3-route path) have cast data
  from the oracle run (via copies). Loggable visible changes: 0.7–0.95 per second.
- Simulated keyboard logging (first log 0.5–3 s after READY, reaction 10–25 VIs, <12-VI animations missed):

| logging | path known: logs / s (median, p90) | ±0.5 s | ±0.1 s within 60 s | path bits removed by log 2 |
|---|---|---|---|---|
| AD every change, no READY key | 3 / 4.1 s (6.97) | 4.8 s | 13% (~14 s) | 1.12 |
| AD every change, READY key ±10 VI | 2 / 3.3 s (6.8) | 3.7 s | 66% (~14 s) | 0.86 |
| direction only on turns | 2 / 7.2 s (18.3), 81% reach | 37% | ~0% | 1.62 |
| direction (Space) at every change | 6 / 7.0 s (26) | 9.9 s | 5% | 0.08 |
| AD every second change | 3 / 5.1 s (13.9) | 7 s | 8% | 1.04 |

  Frame-level timing (±1 frame) essentially never comes from logs. A turn log is as informative as an AD log but
  turns are rare; Space at every change is nearly worthless.

## Pulse run (Mac, 2026-11-12 14:12, 84 min; 16 paths × one C-right press per game frame 2–30 s + press pairs)
- Every press: `handleWhistleForDog` 41 VIs later (all 13,440 presses). Press frames between two dog decision
  boundaries give the same future ("class"): median 11 frames (0.37 s), p90 15–22, 1–13 one-frame classes per path.
  Visible response 43–175 VIs after the press (median ~58). Following lasts 1.1 s to 20 s+ (median 5–10 s).
- Second presses (pairs): classes median 8–15 frames — no finer than first presses.
- Information per pulse (path known, simulated keyboard logs): random press + 3 AD logs ≈ 2.0 bits (window
  ±15 → median 8 frames, future known 53%); tool-cued at a class edge with a ±5-frame prior → 5 frames left;
  calibrated reaction adds ~0.3–0.5 bits. Projection: **3–4 cued pulses pin the clock to ±1 frame** (98–100%).
- **Tracks:** after following ends, futures collapse: 955 single-press classes → **95 tracks**; press pairs → 22
  tracks, 83% of them the same as single-press tracks. **No** post-whistle future rejoined the 16 natural paths
  within 20 s. So whistles move the dog onto a small, mostly shared set of tracks ("adjacent tracks").

## Strategy lab results (2026-11-12, no new emulation; 271 arrivals, 4 simulated runners each, route-weighted)
`tools/strategy_lab.py` + `strategies/*.json` (runner: first AD log at READY, reaction 10–25 VIs). Clock error =
tool's "now" vs truth at the last data point; Nut estimate = oracle timing curve at that error + 1-VI press error.

| strategy (prompt logging: key pressed 10–25 VIs after the animation starts) | points | path known | clock RMS (VI) hard / soft | Nut est. |
|---|---|---|---|---|
| AD every change, 10 s | 9 | 100% | 1.55 / 1.32 | 71–73% |
| AD every 10 s (next change), 60 s | 6 | 93% | 2.22 / 1.84 | 59–63% |
| AD every 10 s (whatever is on screen), 60 s | 7 | 93% | 5.26 / 4.64 | 48% |
| AD every 5 s (next change), 60 s | 12 | 93% | 2.14 / 1.65 | 62–66% |
| direction only every 10 s (next turn), 60 s | 6 | 60% | 2.33 / 2.54 | 37–38% |
| AD every change, 60 s | 48 | 100% | 1.17 / 0.49 | 74–83% |
| AD every 10 s, 5 pose groups instead of sprite classes | 6 | 93% | 2.27 / 1.86 | 59–62% |
| AD to 10 s, whistle at 12 s, AD every change to 20 s | 6 | 91% | 1.83 / 2.01 | 61–64% |

- "Anytime" logging (key pressed at any moment while the animation is on screen) roughly doubles clock error for
  sparse logs (AD every 10 s: 3.8 VI, ~52%); AD every change for 60 s still reaches ~1 VI (77%).
- READY prior barely matters (first log within 0.75 s vs 15 s of READY: same results).
- **Whistles are not a better fingerprint per data point** (bits per point ≈ 1.3 either way). After a whistle the
  dog runs at the player for 1–20 s with nothing new to log, so a pulse yields fewer usable observations.
  Conclusion (Thomas's view confirmed): natural animation+direction logs are enough; whistle stays optional.
- Caveat: Nut estimates use the natural cast curve from 0–20 s after READY; casts after a 60 s observation need
  natural-path cast tables at 60–90 s (not recorded yet).

## Observation protocol (decided with Thomas, 2026-11-12)
- The clock starts at the **first animation+direction log, made right at READY** (no separate READY key; a whistle
  can never start an observation because it moves the RNG to an adjacent track).
- Simulated (observe data): path known 100% after 3 AD logs, **2.3 s** median (p90 6.7); ±0.5 s at 3.5 s; ±0.1 s
  only 27% within 60 s; ±1 frame never from logs. Then cued pulses close the clock.

## Save sensitivity (2026-11-12)
- Only entity AI adds save-dependent RNG draws on the trip; the main loop's 1 draw per game frame is universal.
- The horse matters only if it comes into view on the farm. Off screen it makes one load-time decision and
  freezes: 22/35 sampled positions behave exactly like Thomas's save. **Decision: runs always have the horse,
  kept off screen during the crossing** — that is the measured pool. No horse on the farm = a different pool.
- Thomas is making a second save to compare anyway.

## Observation study (preset `observe`, package hm64-powernut-lab_observe_2026-11-12.zip, run pending)
- ≤2 routes per Layer 1 anchor (~530 routes, oracle routes reused) → 80 s after READY per arrival.
- Simulated keyboard runner (start log = animation+direction 0.5–3 s after READY; later logs 10–25 VIs after
  each change, never after it ended; <12-VI animations missed; ±2 VI jitter). Strategies: AD at every change,
  direction on turns, direction at every change, AD every second change; unanchored vs READY key (±10 VIs).
- Reports logs/seconds until one path is left, then until the RNG position is within ±0.5 s / ±0.1 s / ±1 frame
  (the remainder is the alignment step), and path bits removed per log (selectivity of each log kind).
- 20-arrival local preview: AD → one path after ~3 logs (~4.5 s), ±0.5 s by log 4; direction-on-turns also
  ~2–3 logs but ~8 s and weak timing; frame-level timing never comes from logs alone.

## v28 web app (2026-11-12; package hm64-powernut-lab_webapp-v28_2026-11-12.zip)
Thomas's lineage (v18 → v27.7) continued as **HM64_Dog_Oracle_v28_0.html**: one offline file, no server, built by
`tools/export_webapp.py` from lab results (sources: `webapp/hm64_core_v28.js`, `hm64_app_v28.js`, template).
- Flow: 01 log AD (his hotkeys/sprites; arrows/numpad facing, Space = facing only, Backspace = undo; first AD log
  at READY starts the clock) → 02 potential dogs (path × start time, share of evidence; ≥95% → auto-selected) →
  03 line up (tool's dog + upcoming changes; nudge `[` `]` ±1 update, Shift ×5) → 04 Generate histogram
  (P(Nut) per press moment; targets; countdown beeps; per-landing-frame table: bite time, release / hold / fish).
- Search: candidates = arrival × first-log VI (2,438), soft likelihood (log lag ~ N(μ,σ) from the animation's
  start on screen; neighbouring facing −2.5; late −3; mismatch −5.8 nats — one bad log is not fatal).
- Tests (`tests/test_webapp_core.js`, 450 simulated runners from the strategy lab): right path 100% (every-change
  logging), no wrong auto-selection; clock RMS 1.9 VI (10 s), 0.7–0.9 VI (60 s). End to end, 10 s observation:
  predicted P(Nut) 51.5% vs simulated outcome 50.0% (25× the 1/51 baseline). Headless Chrome run of the real UI
  (`tests/ui_autotest.js`): auto-select, clock error ~1 VI, target outcome Nut 3/3.
- Practice mode: a hidden lab dog on a "virtual N64"; Enter = B press; tells Nut/fish and the clock error.
- Enter at the cast and at the bite records the press error (bite time identifies the frame) → press history.
- **v28.1 (same day, Thomas's direction):** fishing is controller-only (no Enter at cast/bite; the keyboard is
  only for observing). Section 03 offers five clock methods side by side so Thomas can pick: logs only; logs +
  speed fit; nudge by eye; tap on changes (Enter = "TV dog changed now", no animation key); taps + logs speed.
  Practice mode scores every method against the hidden dog's true clock (running RMS kept in the browser) and can
  run the virtual console faster than the setting to test speed fitting. "No good fit" warning when ≥2 logs (or
  ≥20%) match nothing on the best dog: 100/100 corrupted sessions flagged, 0/100 clean ones.
- Clock methods, simulated (`tests/test_webapp_methods.js`; clock error at the end of a 12 s line-up):
  correct speed — logs 0.9–2.2 VI, line-up taps 0.9–1.1 VI; console 0.3% fast — logs only 2.7–6.8 VI (a wrong
  speed grows with observation length), logs + speed fit 1.9, taps 1.3–1.5, taps + logs speed 1.0–1.5. One 60 s
  every-change session measures the console speed to ±0.07%; saved measurements average across sessions.
- **v28.2:** right-click any animation → `name:key` editor (e.g. `sniff-sitting:8`), saved in the browser; a key
  moves to its new owner; Settings exports/imports names/keys/groups. **Group buttons** ("either of these",
  `name:key=animation+animation`; seeded: shoulder-sitting + shoulder-standing): a group log matches any member,
  and a switch between members does not count as a change (onset = start of the group run).
  Cost, simulated perfect runners (`tests/test_webapp_groups.js`): shoulder pair, or shoulder + sit/squat +
  bark/bork, no measurable loss (same path identification, clock within 0.05 VI); the v27.7a 5 coarse pose groups
  cost more (10 s: auto-select 100% → 93%, clock 2.0 → 2.9 VI; sparse 60 s logging 2.35 → 5.3 VI). The gain for a
  real runner (fewer wrong keys) is not in the simulation.
- **v28.3 layout:** two columns fit one 1440×900 screen (01 observe | 02 potential dogs + 03 line-up); the virtual
  N64 sits beside the tool's dog in 03 during practice; 04 (cast · hold · release) is a pop-up docked at the bottom,
  enabled once a dog is selected (Esc / ✕ closes and cancels the countdown); the title bar is a footer for now.
- **Which animations to group (2026-11-12, 16 paths, route-weighted, `tests/test_webapp_groups.js`):** the dog lives in
  wells — standing hub Idle (26% of time; excursions shoulder-standing, sniff-standing, smell, bark, mess, walk),
  seated hub sit (13%; sleep, scratch, shoulder-sitting) and transition 32 (16.5%, unnamed; ↔ rollover). Grouping
  animations that follow each other costs timing (a switch inside a group is no longer a loggable change): sit+sleep
  10 s → auto-select 89%; all three wells 10 s → 63%, clock 5.8 VI; at 60 s all wells cost little (1.2 vs 0.96 VI).
  Grouping look-alikes that rarely touch is free: shoulder pair, bark/bork, run/sprint, smell/wiggle-bum (identical
  results). good-boy, flapper, sniff-sitting, squat, transitions 56/64 are 2–6 VI flickers (unloggable; first frames
  match Idle).
- **v28.4:** Thomas renamed transition 32 "stand". The exporter classes each animation (`anim_stats`: median on-screen
  length from onset, appearances/min): flickers (median < 21 VI ≈ 0.35 s: sprint, squat, good-boy, sniff-sitting,
  flapper, transitions 56/64) and never-at-the-dock (184, 192) are hidden from the palette and their keys disabled
  (toggle tile restores them); tile tooltips show the usual length. Longest common ones to train on: rollover 2.2 s,
  walk 1.8 s, bork 1.7 s, sleep 1.3 s; hubs stand/Idle/sit ≈ 28 of ~50 changes per minute.
- **Bare taps as the search itself (2026-11-12, `tests/test_webapp_taps.js`, 300 simulated runners, core log kind `T`):**
  runner taps every visible change (new pose or facing lasting ≥12 VI) ~13±3 VI late, misses 15%, 1 false tap/20 s.
  After 10 / 20 s: taps only → right dog on top 99% / 100%, auto-selected 82% / 97%, clock 1.3 / 1.0 VI; taps +
  facing → 100% / 100%, 96% / 99%, 1.3 / 0.9 VI; animation+facing logs → 100% / 100%, 100% / 100%, 1.9 / 1.3 VI.
  With 30% missed and 2 false taps/20 s, taps only still reach 99% on top / 93% auto-selected / 1.1 VI at 20 s.
  No wrong auto-selection except AD-start + taps at 30% misses (1–2 of 300). The change rhythm is a barcode: logs
  identify faster, taps give the better clock. **v28.5:** tap search in the app (Settings, on by default): taps are search
  inputs (a first tap at READY starts the clock), optionally carrying the facing; tap key and facing-only key are
  assignable (Thomas: tap on Space). Headless UI: Space-only runners on 4 lab dogs → all identified, auto-selected.
- **v28.6:** scrub bar in 03 (Thomas's design): centred at 0, ±3 s by default (Settings: range = sensitivity); dragging
  sets the nudge offset live (the tool's dog keeps playing at that offset, like scrubbing a movie), sprite markers on
  the bar show the coming changes, `[` `]` fine-tune and move the bar, double-click resets; focus returns to logging.
- **Casttables run (Mac, 2026-11-12 17:07, 191 min; 36,000 casts + 96 parity, bite 1 and bite 2):** every cast up to
  poll 2400 started; **every cast from 2402 failed** on all 16 paths: player action 9 = IDLE_NAP. player.c:
  `playerIdleCounter` counts idle game updates in ANIM_DEFAULT; at 1200 (40 s) `startAction(IDLE_NAP)`; during the nap
  any button only wakes him (no cast). **Claude's omission:** the lab never applied Thomas's v27.6u south-east
  stay-awake push after READY (observe/pulse/cast jobs ran hands-off), so the farmer napped in every recording.
  Valid data: casts 0–40 s on all 16 paths (19,216 casts; **0 conflicts** with the 27,000 oracle casts; parity +1
  everywhere; bite-1 Nut 2.6% of frames, hold-only Nut another 2.5%).
- **SE push re-validated on our paths (lab, f0a10e rep):** stick (+35,−35) for 4 polls at 25/33/38 s, and 0.5 s /
  2 s / full-tilt variants: RNG, dog state and sprite identical to the no-input run for 3000 VIs, farmer position
  (−512, −208) and facing unchanged (the water blocks him), no nap. Casts after 40 s then start, and the outcome
  does not depend on when the push came (casts at 41.7 s and 50 s identical for pushes at 25/33/38 s). The nap
  itself is also RNG/dog-neutral, so the 80 s dog recordings stay valid for an awake runner.
- **End to end with the 0–40 s tables (`tests/test_webapp_e2e.js`, 150 simulated runners, 1-VI press error):**
  release at bite 1 only → 51–58% Nut (10–30 s observation); holding through bite 1 where the landed frame's Nut is
  on bite 2 → **75–83%** (predicted 77–81%). Assumes the runner reads the bite time to know hold vs release.
- **Awake run (Mac, 2026-11-12 22:14, 572 min; 67,184 casts 40–180 s, pushes every 33 s):** every cast started
  (push works); 0 conflicts; dog timelines now to 184 s (ladder vs observe: 77,438 overlapping VIs, 0 differences).
  Nut wins stop for bites after ~72 s (bite-1 Nut by bite time: 10–20 s 0%, 20–70 s 3–8%, 80–200 s 0%, a few
  bite-2 Nuts ~200 s).
- **Why: the Nut lives on a few random-number slots.** The LCG sequence from power-on is fixed. A bite needs a draw
  ≤ 81 (range(0,400)==0) — only 18 such slots between draws 1300 and 10000 (~1 per 480 draws). The Nut is the draw
  ~37 later (≤ 642). Traced: two different winning casts both bite on slot #3815 (value 14) and roll the Nut on
  #3852 (value 420). Nut-capable slots at gaps 30–50: #2939 (+30), **#3815 (+37, nearly all Nuts)**, #4965 (+43),
  #8290 (+46), #9092 (+34). So casts must make a bite land on #3815 (rarely #2939/#4965); after the RNG passes it
  (~72 s) bite 1 cannot give the Nut. Not a lab artefact; matches the decomp (no time condition on the roll).
- **Observation length (full tables, `tests/test_webapp_long.js`, 200 generated runners each, hold allowed):**
  observe 10 s → 78% Nut per attempt (cast ~25 s); **20 s → 89%** (~26 s); 30 s → 82% (~34 s); 45 s → 57%;
  60 s → 37%; 75 s+ → 0%. Sweet spot: observe ~15–25 s, cast by ~35 s. Holding gives ~40% of the wins.
- **Blind casting (no observation; full tables, all 271 arrivals route-weighted):** average over 1–70 s = 4.2%
  (release at bite 1) / 3.3% (always hold) vs 1/51 = 2%. Dense windows with ±250 ms stopwatch error: cast **2.5 s
  after READY, release at bite 1 → 11.5%**; cast **21.2 s after READY, always hold to bite 2 → 11.8%**
  (±100 ms → ~15%; perfect timing 36% / 44%). Nothing after ~72 s.
- **Whistle in the barren zone (preset `whistle`, stage K3; Mac run 2026-11-13 09:10, 274 min) — NO:** a whistle cannot
  add bite slots but changes the dog's draws between bite and catch; the remaining Nut slots need gaps +43 (#4965),
  +46 (#8290). Test: one whistle at 74/82/90/98 s on each of the 16 paths, then casts every 4th game frame for 40 s
  (bites 1 and 2), awake pushes kept, rungs from the awake run's K2 ladder; baseline (no whistle) = 0%.
  Result: 19,193 casts → **2 bite-1 Nuts, 0 hold Nuts** (whistle 74 s; paths 1 and 10, cast poll 6134/6142 ≈ 102 s,
  bite 58 polls later; single frames). 82/90/98 s: 0. A late whistle does not move the runner onto a fruitful track;
  the oracle keeps "cast by ~35 s, no whistles".
- **Earlier plan (done):** 3-minute awake run: preset `awake` (stage K2): casts 40–180 s (polls 2402–10800, 67,184 casts,
  ~6 h) with SE pushes every 2000 polls (33.3, 66.7, 100, 133, 167 s; a cast drops a push <30 polls before it);
  the K2 ladder also records the dog to ~184 s and the exporter extends the path timelines with it (checked: ladder
  vs observe 75,840 overlapping VIs, 0 differences). App cue windows: 33–38.5 s, 66–71.5 s, … after the first log.
- **v28.7:** hold-aware cues (beeps and countdown follow the Nut bite, 1st or 2nd), stay-awake cue 33–38.5 s
  after the first log (unless a cast before 39 s is armed), red 40 s line in the histogram. Longer observations get "no cast table" until the
  `casttables` preset runs (stage K: 16 paths × every game frame 0–75 s, bite 1 **and** bite 2 after holding).

## Lucky Timer (2026-11-13; app v29.0, preset `lucky`)
Thomas's design: a second arena for runners who do not want to observe — start a stopwatch at READY, cast on the beep,
and if it is not the Nut, reset and try again. Only the first ~45 s matter (a miss resets). Manipulations must be
human-doable: **mash C-right from READY and stop at whistle 1, 2 or 3** — nothing timed later.
- **Facing E = SE** (Thomas: only E and SE can fish the ocean from the pier): an E stick tap (+60, 0, 4 polls) 30 polls
  before the cast turns him (direction 6 → 5; he also steps ~12 units along the pier); 13/13 casts identical to SE
  (same bite poll, same catch, Nut or fish). [EMU]
- **Smart zones (no whistles, existing tables, all 271 arrivals route-weighted):** release at bite 1 only if it comes
  inside a "release zone" (bite-1 times where bite-1 Nuts outweigh bite-2 Nuts), otherwise hold and release bite 2;
  zones judged with the same timing spread as the cast. Cast ~17.9 s after READY → **22.0% (±100 ms), 19.6%
  (±150 ms), 17.6% (±250 ms)**; zones ~31.0–32.1, 33.0–34.7, 36.5–39.1 s after READY. Fixed rules for comparison:
  release bite 1 at 2.5 s 14.5% / 11.5%, hold at 21 s 15.0% / 11.8% (±100 / ±250 ms). The bite time is a clue to the
  hidden dog path, so the runner gets some of the oracle's benefit without observing.
- **Mash mechanics [EMU, f0a10e rep]:** C-right is read once per game frame (`checkButtonPressed`, edge) and ignored
  during the 40-poll whistle animation; whistles start every 44 polls (15 presses/s) or 48 (7.5–5 presses/s). An
  edge on the frame right after a whistle ends gives a **one-frame "instant" whistle** (action 18 for 2 polls, handler
  runs at once) — at 10 presses/s whistle 2 is usually instant. Human model in the lab: edges every 6/8/10 polls
  (10/7.5/6 per s), every phase, first edge 0–P polls after the arrival's READY, input quiet once whistle k started.
- **Mash variants collapse:** on path 1 (offset 0) the 27 variants (k 1–3 × 3 speeds × 3 phases) give only 3 game
  states, grouped by when the last handler ran; over 7 arrivals ~3.4 distinct states per arrival per cast time.
  `lucky` therefore casts once per distinct state. The state hash must include the **dog's sprite object**
  (globalSprites 0x801FD630, stride 0x9C: frame, tick counter, cycle-ended flag): without it two runs matched on RNG,
  dogInfo, dog entity and player yet split 8 polls later (the sprite cycle end times the dog's next decision). With
  it: equal hash → identical casts (6/6), no coincidental merges.
- **Preset `lucky` (stage M, pending Mac run ~4 h):** the 14 (path, offset) arrivals covering 93% of routes × k 1–3 ×
  mash speeds × phases (504 mash jobs: whistle times + state hash on the cast grid), then one cast per distinct state
  (grid every 4 polls to 25 s, every 8 to 46 s; bites 1 and 2; SE push at 33.3 s; ~24k casts) + 1% double casts of
  shared states as a check → `LUCKY.md` (best time and P(Nut) per k, policy, ±100/250 ms; zones; by mash speed) and
  `lucky_tables.json` for the app. Local pipeline test (2 arrivals, coarse grid): 418 plan×time pairs → 82 casts,
  0 hash mismatches, check casts agree; app and report give the same numbers.
- **Lucky run on the Mac (2026-11-13 10:49, paused):** 27,989 distinct states (estimate was ~24k) but casts ran ~0.4/s
  (K casts ran 1.9/s) → ~20 h; paused after 14 of 947 chunks. Lab change: casts are now skipped by state (path, poll,
  hash) already cast, a coarser grid reuses the recorded hashes, the replay check runs on the first/last/every 8th cast
  of a chunk, and the report keeps only variants with ≥ half their casts known. **Lucky-lite** in the same folder:
  k 1–2, grid 8 polls to 25 s / 16 to 46 s, 8 arrivals (~83% of routes) → ~5k casts (~3.5 h); the full run resumes
  later and casts only what is missing.
- **v29.0 app:** footer switch Dog Oracle | Lucky Timer. Lucky Timer: plan cards (no whistle / 1 / 2 / 3 whistles once the
  lucky run is in) with their best P(Nut); policy (auto, smart zones, 1st bite, 2nd bite); cast time (best, ±1 frame,
  or click the 0–45 s histogram); start key at READY (Space), countdown beeps, zone chirps (in/out), stay-awake
  banner if casting after ~38 s; scrolling timeline (P(Nut) by cast moment, cast marker, first bites grey, Nut-if-
  released green, Nut on bite 2 yellow, release bands, Power Nut icons at the catch); an original stick-figure angler
  facing SE or E (idle, whistle, cast, wait, release zone, bite, reel, catch — Thomas can load his own captured frames);
  ▶ preview of a winning attempt; attempt log (H Nut / M miss, rate vs plan, tries per Nut); keyboard-only practice
  of the cast beep (measures spread and bias). Keys stay in their arena. Tests: `tests/test_lucky_core.js` (node),
  `tests/ui_lucky.js` (headless: arena switch, start/miss/hit, oracle keys silent while in Lucky), oracle
  `ui_autotest` unchanged (right path, auto-select, clock 0.03 VI, Nut on target).
- **v29.0b (same day):** Thomas asked for Jack's fishing frames from the source; Claude does not extract or ship the
  character's sprite art (the "load your own frames" slot stays). Instead the fishing *timeline* was taken from the
  decomp and measured (TECH_REFERENCE → Fishing timeline): the stick figure now casts for 36 VI and the bobber
  "plops" then (marked on the timeline: an audible check of the cast), bite = 20-VI rod pull (release window), held →
  re-cast at bite+24, released → reel to bite+54, Power Nut held up 60 VI then eaten (done at bite+250).
- **v29.0c:** Thomas supplied his own Jack fishing frame catalog (8 facings, source-verified metadata); the Lucky Timer now
  shows Jack from it (E/SE), frame by frame on the game timeline (ticks = polls, matched exactly), with the float and the
  held Power Nut composited at the camera-projected offsets (pitch 45°, yaw 315°), checked against emulator screenshots
  (idle SE identical; float within ~2 px). Timeline catch markers use his Power Nut sprite. L3 can switch to the stick
  figure. Correction: the E tap does move Jack ~12 units along the pier (outcomes still identical).
- **v29.0d:** background = Thomas's empty-pier screenshot (640×480 = 2× native), Jack's frames at 2× on it, float and
  held Nut at the projected offsets. Alignment: his screenshots equal the lab's rice render shifted (−38, +12) px; Jack
  is at (321, 240) in both (camera-centred), so the lab READY spot is (283, 252) in his screenshot — **his READY
  screenshot shows Jack ~2/3 tile (≈ (7, −19) world units) further along the pier than the lab's READY** (player
  (−101.993, 178.257), the route recipes' end point that every table uses). Open question for Thomas: is that his
  normal READY spot? (The E tap moved Jack 12 units with identical casts, so small shifts may not matter; unverified
  for this one.) The panel draws Jack at the lab spot.
- **v29.1 "2nd bite + tap" (Thomas's idea, 2026-11-13):** the crowd plan averages over route weights and a centred timing
  spread, so a runner who keeps landing on a few arrivals, or presses early/late, sits off it. Policy: hold through bite 1
  and tap Space when it bites (keyboard, one tap). Posterior over (variant, cast offset) given the tap (tap lag ~ N(13,
  3.5) VI from the oracle's tap settings): P(Nut on bite 2) and when bite 2 comes; < 1% → "DUD, reset now". Simulated
  (no-whistle tables, σ 150 ms, hold-only best 20.94 s → 13.2%): one tap puts ~50% of the posterior on the true dog path;
  39% of attempts are duds, flagged at a cost of 1 Nut in 357, ~20 s saved each; on true-Nut attempts the shown chance is
  typically 40–90%. Profile (browser, last 60 taps): timing offset by maximum evidence (N(0, 9 VI) prior), arrival masses
  shrunk to route weights (α = 3); "fit the plan to me" re-aims after every attempt. Runners (`tests/test_lucky_tap.js`):
  always dog path 2: 1.8% → 21.6% after 3 taps; path 3 & 120 ms early: 19.5% → 34%; path 4 & 120 ms late: 18.8% → 24%;
  crowd runner 13.2% → ~12% (learning noise). Offset estimate is noisy (shown after 8 taps, applied only by a button).
  Headless UI (`tests/ui_lucky_tap.js`): 6 path-2 taps → profile path 2 64%, plan re-aimed 20.94 → 23.47 s, Nut attempts
  shown 88–89%, duds 0%.
- **v29.2 pace presets + dog-landing start (Thomas, 2026-11-13):**
  - **Start when the dog lands.** Measured: READY − dog_placed = 16 + 2·(D//2) VI (D = beach wait), and in A_routes
    every family of routes that differ only in D reaches the same dog path at offset o + 2·(D//2) (51 families). So on a
    stopwatch started when the dog lands the beach wait changes nothing; on a READY stopwatch it shifts every timing
    by the runner's own wait (the route set is mostly D = 0, so a human with D = 20 sat 0.33 s off the READY model).
    Variants re-anchored: path VI = u + o − 16 − 2·(D//2), first possible cast u = 17 + 2·(D//2) (`tools/pace.py`).
    The A press is read 8 VI before dog_placed (lab, route D = 0): start key together with A → delay −130 ms
    (default); key on seeing it land → about +150 ms. Whistle plans keep the READY start.
  - **Pace = slack before the dog lands** = d0+d1+d2+d3+P+H+C polls; bands from the route set's terciles:
    Fast ≤ 21 (9,975 routes, 28%), Medium 22–27 (13,478, 37%), Slow ≥ 28 (12,561, 35%). Route weights as before
    (count/share per anchor), split by group. Coverage caveat: the measured routes vary the menus up to 30 frames and
    the walking waits only on single axes, so a much slower human is outside the data.
  - Best per group (dog start, no whistle; tool's 16.53 ms VI), smart zones:
    | pace | σ 100 ms | σ 150 ms |
    |---|---|---|
    | All | 18.15 s 22.0% | 18.16 s 19.7% |
    | Fast | 5.77 s 26.2% | 5.78 s 22.3% |
    | Medium | 18.25 s 30.4% | 18.25 s 25.9% |
    | Slow | 18.08 s 26.3% | 6.18 s 23.9% |
    Cross (σ 100, row = plan used, column = true pace): All plan → fast runner 14.4%; Fast plan → medium 18.6%,
    slow 9.1%; Medium plan → fast 13.1%, slow 13.3%. Hold-only bests 21.1–21.7 s (16.0 / 23.1 / 20.9%).
    Thomas (Fast, clean ±100 ms): cast 5.77 s after the dog lands; release zones 23.8–24.7, 25.7–26.6, 29.5–31.3 s
    (first bite elsewhere → hold, release bite 2); first bites 16.8–30.3 s (10–90%); ±0.1 s → 22.3%, ±0.2 s → 14–16%.
    Alternatives: release bite 1, cast 2.20 s → 16.9%; hold-only, cast 21.47 s → 16.0%.
    Sub-bands are lumpy (arrival is chaotic in slack): ≤ 17 → 5.79 s 31.7%; 18–21 → 25.2 s 25.9% (σ 100).
  - App: pace cards (All / Fast / Medium / Slow, best cast + chance, "the same plan if you are really another pace"),
    start select (dog lands | READY, separate start-key delays), second start-key press logs bite 1 in every policy
    (hold policies keep the DUD check; taps store anchor + pace; the profile uses taps of the active start only and the
    group's weights as its prior). Core: per-variant first cast (minT), plan sets per pace/anchor, `valueWith`,
    zone optimum from a 6-VI grid + per-VI refinement of the best 6 peaks (the old 12-VI grid missed ±100 ms peaks),
    curve memo per plan. Tests: `tests/ui_lucky_pace.js` (headless), old lucky tests unchanged.
- **v29.3 cast tap + "what went wrong" (Thomas, 2026-11-13; he aims the Fast 1st-bite cast at 2.20 s, no Nut yet):**
  - Start key at the dog landing, again **together with B** (cast tap: logged if within −1.5/+0.75 s of the aim), again
    at bite 1. With the cast tap the posterior centres the landed frame on the tap (spread = tap + start-key precision,
    default 40 ms each) and uses the bite's delay after the cast as the fingerprint (t1 = c + b1); bias0 = stopwatch vs
    console. Profile: stopwatch offset and bite-tap lag fitted jointly (grid b ±18 VI × lag 6–36 VI, priors N(0,9) and
    N(16,8)); they trade off otherwise (a late tap looks like a shifted cast).
  - Simulated (`tests/test_lucky_cast.js`, Fast, 1st-bite plan 2.20 s, B spread 100 ms, 40 attempts each): the verdict
    "that bite was a Power Nut bite / a fish bite" is decisive (P ≥ 80% or ≤ 2%) on 83–88% of attempts with the cast tap
    (70–90% without) and right 97–100%; learned bite reaction within 15–35 ms of the truth with cast taps (33–66 ms
    without). Per-attempt lag is not reliable (Nut bites of different frames sit within ~0.2 s), so only the profile
    shows it (after 6 taps).
  - Outcome keys H (Nut) / M (fish) / **E (line came back empty)**. Decomp rule (player.c handleFishingAction): B up in
    phases 3–5 (the bite, 20 polls) → phase 6 → catch; B up in any other phase → phase 8 → lose-fish animation, nothing
    caught. Diagnosis per attempt: empty → release outside the window; fish from a Nut bite → 1–2 frames late (lab:
    +20/+21 polls give a fish); fish from a fish bite → cast/dog path, not the release.
  - Fast 1st-bite plan (cast 2.20 s): first bites 16–34 s, but a bite-1 Nut only at **~23.9 s or 27.7–28.4 s** (the
    Nut-capable RNG slots); everything else is a fish. 1st-bite policy now plays two soft ticks 0.6/0.3 s before each
    Nut-bite span (anticipate, don't react: 0.33 s minus TV lag minus reaction is tight). Smart zones at the same
    cast: 18.5% vs 16.9% (σ 100), the Fast optimum stays 5.77 s / 26.2%.
- **v29.4 Thomas's plan: release windows + bite-2 fallback (2026-11-13).** Space with A, Space with B; release bite 1
  only inside a release window; a bite before a window, or after one passed, is held through and tapped → posterior
  (cast tap + bite delay) → bite-2 forecast: DUD (< 1% → reset) or the Nut chance and the bite-2 Nut moment(s)
  (`nutSpans` of the Nut scenarios' bite-2 times; two ticks 0.6/0.3 s before each; bite-1 window chirps cancelled).
  Optional Space at bite 2 (both bites in the likelihood; stored as tau2 and used by the profile). This is the smart-zone
  policy plus the forecast; the zone windows are the optimal version of "where bite 1 can be the Nut".
  Simulated (`tests/test_lucky_fallback.js`, B spread 100 ms, lag 15 VI, cast tap): Fast cast 2.20 s → 18.4% (bite 1
  15.7 + bite 2 2.8), holds 72%, DUD on 69% of holds (1/108 Nuts lost), ~18.6 s saved each; Fast cast 5.77 s → **28.2%**
  (16.9 + 11.3), DUD on 57% of holds, 0/450 Nuts lost, ~16 s saved; every bite-2 Nut inside the forecast moment
  (450/450, 107/107). Shown bite-2 chance on true Nuts 42% vs 7.5% on fish (5.77 s). Medium: 2.73 s → 22.5%, 18.25 s
  → 29.9%. Headless UI (`tests/ui_lucky_fallback.js`): bite 1 at 18.35 s held → forecast Nut 44% at ~30.1 s, true bite
  2 at 30.22 s, bite-2 tap → "Power Nut bite 94.7%"; second attempt → DUD.
  Fix: the curve cache is keyed by the variant list (a plan copy with other weights, e.g. the tests' single-path
  runners, had inherited cached curves); `test_lucky_tap.js` back to path 2 1.8% → 19–22%, path 3 early 19.5% → 33–35%.
- **v29.5 route tables: `nodog-nohorse-no-pickup` (Thomas, 2026-11-13 night).** The dog-beach save's base-line cast
  table (`HM64_DOGBEACH_SAVE.md`, scanned in another chat: 1,200 cast frames 0–40 s, bites 1 and 2) packed by
  `tools/route_tables.py` → `webapp/assets/lucky_routes.json` (23 KB; same packing as the dog paths; 0 mismatches vs
  the CSV; odd polls unknown — parity not measured there) → app data `lroutes`. Lucky Timer **Route menu** (Spring 9 dog
  carry | nodog-nohorse-no-pickup); a route table is one variant per start anchor: beach entry (READY = +328 VI on the
  base walk; the dog's line is fixed at its wake, entry + 192 VI) or READY at the pier end; no pace cards. Attempts,
  taps and the profile are kept per route (+ start); old ones count as dog carry.
  Best (LuckyCore; the other chat's own simulation agrees within 0.2 points): smart zones 25.05 s after READY (60 Hz;
  the app shows 24.84 s with the 16.53 ms console VI) → **39.8% / 32.3% / 23.1%** at ±100 / 150 / 250 ms; release bite 1
  22.12 s → 23.3 / 16.9 / 13.4%; hold 19.25 s → 26.3 / 19.3 / 13.8%. One release window ~42.2–43.4 s after READY: the
  Nut bite comes there as bite 1 or, after a held earlier bite, as bite 2.
  Line check: a bite tap that fits no cast frame of the line → "off this line"; simulated (`tests/test_lucky_route.js`):
  on-line attempts accepted 100%, off-line attempts (bite delay unrelated to the cast) flagged 92% with the cast tap,
  87% without (upper bound: a neighbouring line may share bite delays); the attempt log shows "Line check: x of y".
  Headless UI (`tests/ui_lucky_route.js`): route switch, anchors beach/pier, plan 30.26 s after beach entry = 24.84 s
  after READY (39.8%), on-line attempt held → bite-2 forecast 63%, off-line attempt flagged, per-route log, the dog-carry
  route unchanged (pace cards 22.0 / 26.2 / 30.4 / 26.3%; `test_lucky_core`, `test_lucky_fallback`, `ui_lucky_pace`,
  `ui_lucky_fallback` same numbers as v29.4).

## Beach walk and the time since reset (sandbox probe, 2026-11-13; Thomas asked about a beach-entry tap)
`experiments/beach_walk_probe.py` (one route per process, ~4 s) + `beach_walk_match.py` (joins each run's draw index
sequence from the landing to the 16 dog paths' timelines, O_observe, exact match per VI).
- **The measured routes never vary the beach walk** (recipe DR86 DL34 D100 L35 DR70 UL1 A2: beach entry → landing is
  always 334 VI). A pause of k polls in the walk (after D:100, dog carried) lands on: k = 2 path 12 (−16, measured),
  4 path 5 at −2 (**offset not in the route set**), 6 path 9 (−16), 8 **no known path until 30.7 s**, 10 **none
  within 41 s**, 14 path 6 (+6, measured), 20 **none until 10.9 s** (then path 1 at −24), 30 path 5 (+20, measured).
  So a human whose walk differs from the recipe by some frames can be on a dog the lab has never recorded (no cast
  tables) — the tool would then be confidently wrong. Coverage gap, not fixed yet.
- The same delays in the menus/house/crossroads/pickup (2–20 polls) all land on measured arrivals, almost all at offset
  −16 on the landing stopwatch (the dog's path starts at the landing).
- **Time since reset alone does not fix the path:** same landing VI, different futures depending on where the delay was
  spent (2656: C20 | H4 = P4 | walk4; 2672: H20 | P20 | d0 20 | walk20; draw index at landing differs, and even equal
  draw index + landing VI (H6 vs walk6) differ — the carried dog's state). In the route set alone the landing VI would
  look decisive (arrival entropy 3.62 → 0.44 bits; a reset→landing timer ±33 ms simulated 22 → 33% per attempt) but that
  only holds for the route set's mix of delays.
- Next (proposed, Mac): a `beachwalk` preset — walk pauses 0–60 polls at a few points of the walk (and a few human-like
  stick variants) → stage A + O (which paths, new ones), K cast tables for new paths; calibrate the fade-to-black frame
  vs the first beach VI (screenshots); then a beach-entry tap in the app (Space at the fade → Space with A gives the walk
  time, which selects the arrivals). Until then a beach-entry tap can only measure how much the walk varies.

## Cast · hold · release (decomp player.c, verified against data)
- Cast: B read at game frame f decides everything after. Main loop 1 rand()/frame + dog decisions keep drawing.
- Hold (actionPhase 2): +1 getRandomNumberInRange(0,400) per frame (0 = bite); dog keeps drawing → tables must
  come from the emulator. Adjacent cast frames bite seconds apart (bite time identifies the frame).
- Release: B up in phases 3–5 → phase 6; catch rolls (fish type, then Nut !range(0,50)) run at the next animation
  boundaries, so releases bite+0..+19 polls give one catch (1,824/1,824 mapped windows); +20,+21 fish; later =
  held through → phase 5 → 1 → 2, waiting resumes → bite 2 (now probed by `eval_cast(hold_bites=2)`; pilot: Nut on
  bite 2 exists where bite 1 is fish).

## Next
0a. **Dog-beach route on hardware** (v29.5, route nodog-nohorse-no-pickup): the line check tells how often Thomas lands
   on the base line; the `dogbeach` Mac preset adds the neighbouring lines (see `HM64_DOGBEACH_SAVE.md` → Next).
0. **Beach-walk coverage (see "Beach walk" above):** `beachwalk` preset on the Mac, then a beach-entry tap.
1. **Lucky run (paused) / lucky-lite** when the Mac is free, then `bash run_hm64_webapp.sh` puts the 1–3 whistle
   plans into the Lucky Timer (READY start, pace All). Analyse LUCKY.md: does mashing at READY make the blind field
   denser than the no-whistle smart zones (~18–22%)? (`whistle` barren-zone run: done, NO.)
2. Pace presets: the real slack of a human (menus + walking) is unmeasured; Thomas's bite taps per pace card will
   show whether his attempts fit the Fast arrivals. Open: is his READY screenshot spot his normal one (v29.0d)?
2. Tune strategies + search in the strategy lab (e.g. likelihood search, adaptive "log until the clock is ±1 VI").
3. Per-animation visual onset (first frames that look like the previous pose) to refine reaction timing.
4. Use the console's measured frame rate in the tool (a 0.1% rate error drifts ~1 frame per 17 s).
5. Compare Thomas's second save; one console capture to confirm emulator frame timing.

## History (short)
- 2026-11-11: lab built (headless harness, route port, dog model, Docker image, Mac runner); quick package.
- 2026-11-12: quick run (Mac); ladder + oracle + Layer 1 stages; oracle run (Mac); timing-error analysis;
  runner model clarified with Thomas; horse/save sensitivity; observe run (16 paths); whistle mechanics from the
  decomp + pilot; pulse run (classes, tracks); protocol: clock starts at the READY AD log; strategy lab;
  v28 web app + casttables preset (bite 2 / hold).
- 2026-11-12 night: casttables + awake runs (Mac); RNG-slot explanation; blind windows; whistle (barren) preset.
- 2026-11-13: Lucky Timer arena (v29.0), smart zones, facing E = SE, mash mechanics, preset `lucky`; v29.1 bite tap;
  v29.2 pace presets + dog-landing start; v29.3 cast tap, bite verdict, empty-line diagnosis;
  v29.4 release windows + bite-2 forecast (Thomas's plan); v29.5 Route menu + dog-beach route table.
