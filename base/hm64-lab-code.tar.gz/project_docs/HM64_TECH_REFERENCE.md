# HM64 lab — technical reference (verified facts, RAM map, conventions, data formats)

Tags: [DECOMP] = hm64-decomp-master source, [EMU] = reproduced in the lab's deterministic emulator.
Last updated 2026-11-13.

## Time and input conventions
- VI = one 60 Hz video frame. Game logic runs at 30 Hz (one update per 2 VIs). At the dock there is
  ~1 controller poll per VI.
- "poll N" = the N-th controller read, **0-based from the instant a savestate finishes loading**.
- Ladder/observation time `t` = VIs after READY, **t = 1 is the READY instant**. Pressing B from VI v is
  read at poll `polls_after[v-1]`. Layer 1 time is 30 Hz updates: `u = (t - 1) / 2`.
- Casts are swept every 2 polls; a game frame spans 2 polls. Where measured (36/45 arrivals) the odd
  poll belongs to the frame of the preceding even poll ("parity +1").

## RNG
- libkmc LCG `s = s*1103515245 + 12345`, output `((s+1)>>16)&0x7FFF`, state at **0x8013CDF0**. [DECOMP lib/libkmc/src/rand.c]
- `getRandomNumberInRange(lo,hi)` = 2 rand() calls (first discarded), `lo + (r*(hi-lo+1)>>15)`. [DECOMP src/system/math.c]
- Boot seed 0. Absolute draw index of any seed is exact (`hm64.lcg.index`, jump trick).
- **The main loop calls rand() once per game frame on every screen** ("update RNG seed", mainLoop.c),
  so the draw index works as a clock (~30 draws/s) plus extra draws from entity AI. [DECOMP] [EMU census]
- Route census (baseline): ~0.5 draws/VI on menus, house, farm, crossroads, ranch, beach; extras: breakfast
  ~+24, ranch ~+13, farm +6 (the horse). READY = draw 1312 on the baseline route.

## Dog
- `updateDogActionState` Markov chain; `hm64/dog.py` reproduces every observed decision (0 unexplained);
  the dog's rand() calls come first in their VI. RAM `dogInfo.actionState` is the NEXT state. [DECOMP animals.c:2679] [EMU]
- Whistle (C-right): the player's whistle animation plays, and when it ends (**41 VIs after the press**, constant)
  `handleWhistleForDog` sets FOLLOWING + actionState 0 (no RNG; bark SFX; +1 affection once a day). The dog acts
  only at its next animation-cycle end with stateTimer 0 (`updateDog`), so every press between two such boundaries
  gives the identical future. FOLLOWING: state 0 faces the player (stateTimer 10), state 4 runs at the player and
  each running cycle rolls range(0,20); 0 ends following. A cast < ~44 polls after a whistle does not start.
  [DECOMP player.c handleWhistleForDogAnimation, animals.c handleWhistleForDog, updateDog, updateDogActionState] [EMU]
- Dog decisions happen at animation-cycle ends when stateTimer is 0 (otherwise the timer counts down per cycle).
  The cycle end is the dog's **sprite object** flag (`checkSpriteAnimationCycleEnded`: globalSprites[i].stateFlags
  bit 0x40; globalSprites @0x801FD630, stride 0x9C, i = dog entity +0x52; +0x90 frame, +0x91 tick counter,
  +0x9A stateFlags). Two states equal in RNG, dogInfo, dog entity and player but not in this object diverge.
  [DECOMP globalSprites.c/h, entity.c checkEntityAnimationStateChanged] [EMU]
- Whistle input: C-right is an edge (`checkButtonPressed`, player.c:1148) read once per game frame, only while the
  farmer is idle; presses during the 40-poll whistle animation are ignored. Mashing: whistles every 44 polls at
  15 presses/s, 48 at 7.5–5/s; an edge on the frame right after a whistle ends gives a one-frame whistle (action 18
  for 2 polls, `handleWhistleForDog` at once). [DECOMP player.c handleWhistleForDogAnimation] [EMU]
- Pulse atlas (13,440 presses): handler delay 41 VIs every time; identical-future press classes median 11 frames;
  response 43–175 VIs after the press; following 1.1–20+ s. After following ends, futures coalesce onto ~100
  "tracks" (955 classes → 95; press pairs mostly land on the same tracks); none rejoined a natural path in 20 s.
- What the runner sees is the entity's ANIMATION, not dogInfo.actionState: `updateEntities` starts the sprite
  animation when animationIndex (+0x54) + direction differs from the one displayed (nextAnimationIndex, +0x56), and
  only if the entity's tile is in the map's visibilityGrid (or camera-tracked); otherwise the sprite animation is
  reset - which is why an off-screen horse never finishes a cycle. [DECOMP src/system/entity.c updateEntities]
  The state→animation→TV lag is constant and absorbed by the clock alignment.
- Visible state = dog entity sprite base (+0x54) + screen facing (+0x67, dirs S,SW,W,NW,N,NE,E,SE).
  ROM sprite equivalence: 25 bases × 8 facings = 200 keys → 141 visual classes
  (`hm64/data/sprite_equivalence.json`, same classes as Layer 1 and the v27.7a observer).

## Fishing / Power Nut
- Phases: 1 cast, 2 waiting (rolls range(0,400) per update), 3→4→5 bite (~22 polls), 6 reel, 7 catch.
  Release during 3–5 → catch; holding through → next bite. Oracle run: first bite only; stage K also probes bite 2. [DECOMP player.c:2647,3749]
- Nut roll `!getRandomNumberInRange(0,50)` at catch, only at fishingSpotType 3; Nut = `acquiredPowerNutBits`
  (u32 @0x80215EB8) bit 4, held item 87. [DECOMP player.c:3849]
- Once the cast frame is right, every release in the 20 polls after the bite shows gives the Nut
  (526/526 and 27,000-cast oracle run: shape 20×Nut, then fish, then held-through). The **cast frame is the
  sharp variable**: wins are mostly single game frames; runs of 2 (131×) and 3 (32×) consecutive frames exist.
- Emulator per-cast Nut rate at the dock: 6.4% of game-frame casts over 0–20 s after READY (≈10% first 6 s,
  ≈5% later) — higher than 1/51, presumably correlation in the LCG between bite roll and Nut roll (unverified).

- Release mechanics (player.c handleFishingAction / handleFishingRodAnimation): B up in phases 3–5 → phase 6;
  case 6 (next animation boundary) → lose-fish animation, phase 7; case 7 (its end) → fish-type roll, then the Nut
  roll. The catch frame does not depend on when in phase 4 B went up → releases bite+0..+19 all equal (1,824/1,824).
  Holding through: case 5 → phase 1 → rod respawn → phase 2, bite rolls resume. `eval_cast(hold_bites=2)` records
  `bites: [{bite_poll, probes, nut}, …]` (stage K).
- **Fishing timeline** (polls ≈ VI; f0a10e rep, SE and E identical) [DECOMP player.c handleFishingRodAnimation] [EMU]:
  B press → action 22 at +2, cast animation (player anim 386) → phase 2 at **+36**: bobber entity 157 spawns 2 tiles
  ahead with PLOP_SFX, waiting anim 378. Bite: phase 3→4 in one frame, rod-pull anim 394 (bobber anim 158) for **20**
  polls = the release window. Held through: phase 5 → 1 → 2 (re-cast, plop again) by bite+24. Released: phase 6 at
  B-up, lose-fish/reel anim 402 (phase 7) from bite+20, **catch at bite+54** (fish-type roll, then the Nut roll) for
  any release in the window. Power Nut → `startAction(EATING)` (action 6): held up 60 polls, eaten (held item 0) at
  bite+138, action over at bite+250 (+15 max stamina, +4 happiness). A fish is held at bite+54. The Lucky Timer's
  angler and preview use these numbers. Thomas's frame catalog (HM64_Jack_Fishing_Animation_Naming_Catalog_v1: player
  bases 0/378/386/394/402/24 × 8 screen facings, eating 437, floats 157/158, Power Nut item 210) has tick lengths that
  equal these polls exactly (386 = 20+6+6, 394 = 10×2, 402 = 4+30, 437 = 134): **1 animation tick = 1 poll ≈ 1 VI**.
  Packed by `tools/build_jack_assets.py` → `webapp/assets/jack_fishing.json` (E and SE only, 55 frames).
- **B up outside the bite = empty line** (`handleFishingAction`: released in phases 3–5 → phase 6 → catch; released
  in phase 1 (cast / re-cast) or 2 (waiting) → phase 8 → lose-fish animation, phase 9, resetAction, nothing caught).
  So an empty line tells the runner the release missed the window (too late, or before the bite). [DECOMP]

## Where the Nut can happen (RNG slots)
- Bite = getRandomNumberInRange(0,400)==0 → second draw ≤ 81; Nut = getRandomNumberInRange(0,50)==0 → draw ≤ 642
  [DECOMP player.c handleFishingAction, catch case 7]. Every cast frame that bites on the same slot catches on the
  same later slots, so outcomes depend on (bite slot, draws until the catch). Traced: bite slot #3815 → Nut slot
  #3852 (+37 draws, 54 VIs). Bite slots in draws 1300–10000: 18; Nut-capable at +30..+50: #2939, #3815, #4965,
  #8290, #9092. Bites after the RNG passes #3815 (~72 s after READY) give no bite-1 Nut. [EMU, lcg]

## Facing at the pier
- READY faces SE (player world direction 6, screen facing 7). An E stick tap (+60, 0, 4 polls) turns him (direction 5,
  screen facing 6) and moves him ~12 units along the pier (entity (−102, 178.3) → (−93.5, 169.8)); casts are identical to
  SE casts (13/13: same bite poll, same catch). Only E and SE reach the ocean from the pier (Thomas). [EMU]
- Camera: world rotation pitch 45°, yaw 315° (`currentWorldRotationAngles` @0x8017044C; graphic.c), orthographic, 1 unit
  ≈ 1 native pixel; screen right = world (+1, 0, −1)/√2. Float entity (item base 39, anim 157/158) 2 tiles ahead at
  y 128: on screen SE (+40, +73), E (+96, +23) native px from Jack's anchor; held item attachment (0, 14, 20) in front:
  SE (+15, −4), E (+20, −10). Checked against rice-renderer screenshots (xvfb). [DECOMP] [EMU]
- At the lab READY the camera centres Jack's anchor at (321, 240) of a 640×480 (2×) frame. Thomas's beach screenshots
  (`tools/build_beach_asset.py` → `webapp/assets/beach_ready.json`) are the lab render shifted (−38, +12) px; in them
  the lab READY spot is (283, 252) (E-facing: (307, 252)).

## Idle nap and the stay-awake push
- `playerIdleCounter` (player.c) counts game updates in ANIM_DEFAULT (standing, not riding); at **1200 (40 s)**
  `startAction(IDLE_NAP, ANIM_IDLE_NAP)` = player action 9. During the nap any held button only sets the wake-up
  phase (no cast). ANIM_WALKING and every other action reset the counter to 0. In the lab the nap starts at poll
  2401 after READY on all 16 paths (casts read at ≤2400 work, ≥2402 fail). [DECOMP player.c handlePlayerAnimation,
  handleIdleNapAction/Animation] [EMU]
- Thomas's push (v27.6u): analog stick X=+35, Y=−35 (SE, walk), e.g. 4 polls. At the dock the water blocks him:
  position (−512, −208) and facing unchanged; RNG and dog identical (his native gate 1,493/1,493 snapshots; lab
  3000 VIs for pushes at 25/33/38 s, 4–120 polls, gentle or full tilt). Cast outcomes after 40 s do not depend on
  when the push came. Harness: `FishController(wake=[poll…])`, job key `wake`, preset `awake`.

## Horse (save sensitivity)
- `horseInfo` @0x8016FDD0 (0x24 bytes): +0x08/+0x10 x/z f32, +0x14 entityIndex (38), +0x16 location (map),
  +0x17 actionState, +0x18 direction, +0x1C grown, +0x20 flags (1 ACTIVE, 4 ENTITY_LOADED, 0x10 FOLLOWING,
  0x20 COLLISION_WITH_PLAYER). [DECOMP animals.h]
- Loaded by MAP (location == current map), not distance. On farm load: actionState reset to 0 and one decision
  (2 or 6 draws). After that it only decides when its animation cycle ends, which happens only where it comes
  into view while the player walks left. Thomas's save: horse on farm (82) at (-240,-384), off screen.
  Sweep of 35 positions: 22 identical to the save (READY 1312), 13 left/upper-left ones drew more (1310–1477);
  no horse on the farm → 1306. [DECOMP animals.c initializeHorseEntity/updateHorse] [EMU]

## Route (cold boot → READY)
- Legacy `v14_two_poll_DR_finish`, ported faithfully (v13 baseline matches at all 9 stages; 121/121 and
  158/158 sampled measured routes reproduce ready VI + draw index). Hard reset at legacy callback 120.
- Label `mD0D1D2D3_hHHcCC_pPPdDD` (2-digit polls ≈ 1/60 s): d0–d3 four menu-screen delays (sum ≤ 30);
  P wait before the pickup, H house wait after the pickup, C crossroads wait, D beach wait after putting the
  dog down (budgets H+C ≤ 60, P+D ≤ 60). READY = player at (-101.993, 178.257) facing SE with the dog down.
- `ROUTE_TO_CHECKPOINT_LINKS.csv`: 36,014 measured routes → `draw_index` (54 distinct, 1305 minimum),
  `ready_vi`, `anchor_id` (268 distinct Layer 1 anchors). One extra delay frame usually moves the RNG a few
  draws; crossroads waits move nothing for 9 frames; beach ≈ 1 draw per 2 frames; rare jumps of hundreds.
- Map indices seen (u8 @0x80170458): title 53, house 87, farm 82, crossroads 78, Green Ranch 0, beach 9.
- **The beach walk matters and is not in the route set:** beach entry → landing is a fixed 334 VI in every measured
  route. Pausing the carried dog's walk by 2–30 polls changes the dog's path (k = 8, 10, 20: paths not among the 16 for
  10–41 s; k = 4: a known path at an unmeasured offset). Delays elsewhere (menus, house, crossroads, pickup) land on
  measured arrivals. Time since reset does not determine the path by itself. [EMU, `experiments/beach_walk_probe.py`]

## Arrivals and world lines
- **Beach wait = pure time shift from the dog landing.** dog_placed = first beach VI with the dog's held flag clear
  (`hm64/route.py` StageTracker); the A press that puts it down is read 8 VI earlier (route D = 0: A at VI 2644,
  dog_placed 2652, READY 2668). READY − dog_placed = 16 + 2·(D//2) VI (D = 0..60 measured). In A_routes all 51 route
  families that differ only in D land on the same dog path at offset o + 2·(D//2). Hence a stopwatch started at the
  landing sees one dog regardless of D: path VI = u + o − 16 − 2·(D//2), u = 1 at dog_placed (`tools/pace.py`).
- Pace (Lucky Timer presets) = slack before the landing = d0+d1+d2+d3+P+H+C polls. The arrival is chaotic in it
  (neighbouring slack values land on different dog paths), so groups are coarse mixtures: Fast ≤ 21, Medium 22–27,
  Slow ≥ 28 (route-set terciles). The route set varies menus ≤ 30 frames and walking waits on single axes only.
- **All 36,014 routes reach only 16 world lines** (observe run: 271 arrivals; 0 mismatches over 1,004,627
  aligned VIs; copies offset by an even number of VIs, −54..+46). Top 10 lines = 95% of routes.
- Arrival = natural future signature (1800 VIs, no input). 121 routes → 45 arrivals → **15 world lines**:
  arrivals that are the same dog+RNG path entered at different times. Copies share absolute draw indices at
  the same world time and their winning casts agree once aligned on the dog's changes (4,061 agree, 0 disagree).
- Layer 1 (Thomas's index, `~/Documents/hm64/HM64_Layer1_Mac_Generator/output/`): master
  `layer1_spring9_full.sqlite` (17.8 GB; tables anchors(id, rng…), schedules(label, anchor_id, ready_vi,
  signature), trajectories(id, anchor_id, base, screen, frame, tick, ended, first_skip, end_rng, cover_updates),
  segments(trajectory_id, t0, t1, screen, visual_class)) and `layer1_shards/` (6.5 GB; manifest.sqlite with
  settings/slots/anchors/schedules/trajectories, parts/v{screen}_c{class}_t{bucket}.sqlite postings(t0,t1,tid),
  bucket 3000 updates). 567,984 trajectories = anchors × unmeasured sprite-phase hypotheses; horizon 12,600
  updates. Link: route label → schedules.label → anchor; anchor RNG = native READY RNG (45/45).
  44/45 native paths are a Layer 1 hypothesis; matches collapse to one end state. Layer 1 shows a READY
  transition sprite for the first 3–4 updates (compare after it).

## RAM map (decomp-sourced, `hm64/addresses.py`)
RAND_SEED 0x8013CDF0 · MAIN_LOOP_INDEX 0x8020564A · TITLE_CTX 0x80126570 · BASE_MAP_INDEX 0x80170458 (u8) ·
PLAYER 0x80189060 · DOG 0x801886B0 (+0x17 actionState, +0x18 direction, +0x1A stateTimer) ·
ENTITIES 0x801FC160, stride 0x6C (dog = entity 1, horse = 38; +0x54 sprite base, +0x67 screen facing) ·
horseInfo 0x8016FDD0 · acquiredPowerNutBits 0x80215EB8.

## Harness facts (mupen64plus 2.6.0, headless)
- One Emulator per **process** (core is a singleton; a second instance in the same process silently breaks).
- Determinism: RandomizeInterrupt forced OFF (default ON is wall-clock seeded); save_state steps exactly 1 VI
  then waits for the async writer; null renderer raises the DP interrupt; screenshots taken in the frame callback.
- Load-anchor seed poke ≡ genuine later menu press; poke at the control anchor is NOT equivalent.
- Casts from a ladder rung ≡ casts from READY (8/8 incl. whistle; smoke check 10).

## Campaign pipeline (`tools/campaign.py`, outputs in `results/campaign-<preset>/`)
| Stage | What | Output rows |
|---|---|---|
| A | cold-boot routes → READY savestates, deduped by signature | `A_routes.jsonl`: label, family, signature, state, draw_index, ready_vi, outcome |
| L | 2700-VI visible path + savestate rung every 60 polls | `L_ladder.jsonl`: segments [t0,t1,screen,class,base], rungs, polls_after, end |
| B / P / C | casts (natural / parity probes / after whistles), from rungs | signature, cast, whistles, bite_poll, probes, nut_releases, window_outcomes, status, rung |
| K | cast tables per dog path (preset casttables): K_ladder, K_casts (every game frame), K_parity | as B, plus `bites` (bite 1 and bite 2 after holding) |
| K2 | same after 40 s with the SE push (preset awake, `wake` [2300]) | K2_ladder / K2_casts / K2_parity |
| D | report | REPORT.md, scenarios/natural_plans/whistle_plans/observation_elimination CSVs |
| E | oracle sim + timing-error analysis | ORACLE.md, oracle_sim.csv, **oracle_scenarios.json** (tool table), oracle_timing.json |
| F | Layer 1 link | LAYER1.md, layer1_links.csv/json |
| O | 80 s after READY: visible + hidden state | `O_observe.jsonl`: vis, draw [[t, draw_index]], dog [[t, act, dir, timer]] |
| I | keyboard-logging identification study | IDENT.md, ident_runs.csv, ident_curves.csv |
| W | per dog path: ladder, one C-right press per game frame (2–30 s), press pairs | `W_lines.json`, `W_single.jsonl` / `W_double.jsonl`: presses, handler, response, vis, events [[t, draw, act, dir, following]], sig |
| Q | pulse information study | PULSE.md, pulse_summary.json |
| M | Lucky Timer (preset lucky): mash C-right at READY to whistle k (1–3), speeds 6/8/10 polls, every phase, on the arrivals covering 93% of routes → state hashes on the cast grid; one cast per distinct state | `M_mash.jsonl`: path, start, period, whistles, starts, handlers, edges, quiet_at, hashes [[poll, hash]]; `M_casts.jsonl`: tag, casts [{cast, hash, hash_ok, status, bites}]; LUCKY.md; lucky_tables.json |
Strategy lab (`tools/strategy_lab.py`, `strategies/*.json`, `run_strategy_lab.sh` natively on the Mac): JSON
strategies (alphabet, start, prior, runner model incl. prompt/anytime logging, steps: every_change / next_change /
clock logs and pulses) are simulated on O + W ground truth and scored for hard and soft (likelihood) search.
Presets: smoke, quick (121 routes), oracle (quick + casts 0–1198), observe (≤2 routes per anchor, A+O+I),
pulse (W+Q on the observe rows), casttables (K on the observe/pulse rows; `--cast-paths N`), awake (K2), whistle (K3),
lucky (M; env HM64_LUCKY_K / _PERIODS / _GRID / _COVER override), standard, full.

## Web app data (tools/export_webapp.py → HM64_DATA in the v28 HTML)
- Path time = VI of the path's representative arrival (W_lines); arrival VI t ↔ path VI t + offset (offsets 0..+62,
  even). `paths[k].runs` = [t0, t1, facing, sprite class, base] merged by (facing, class); 14 arrivals keep their
  own first ≤28 VIs (`arrivals[i][3]`, they look different right after their READY).
- `casts[k]`: from VI `lo`, per VI v (= press first read in VI v = poll v−1−offset of an arrival): `n1` Nut at
  bite 1 (1/0/.), `b1` bite VI − v, `n2`/`b2` after holding through bite 1. Odd polls filled from the game-frame
  pairing (parity +1 on every path). 0 conflicts between arrivals of one path.
- `release` {first 0, last 19}: release polls after the bite's first poll that give the catch.
- `lucky` (null until the lucky run): `G` cast-grid polls (rep path polls; path VI = poll + 1), `plans` [{k, series
  [{path, i0 (index into G), n1, n2 (strings over G), b1, b2 (bite poll − cast poll)}], scen [[series, offset,
  weight, period, whistle starts]]}], `covered_routes`, `checks`. A mash variant at offset o casting at stopwatch VI
  t uses path VI t + o (the same rule as the no-whistle arrivals). `webapp/hm64_lucky_v29.js` (LuckyCore, also
  `require`-able in node) computes route-weighted P(Nut) per cast time with a Gaussian timing spread, and the zone
  policy (bite-1 times binned 6 VI, densities smoothed with the spread, membership judged with the spread).
- `pace` (v29.2, `tools/pace.py`): {lag0 16, groups [{id all|fast|medium|slow, lo, hi (slack polls), routes,
  covered, ready [[path, o, w]], dog [[path, o − 16 − 2·(D//2), w, 2·(D//2)]], slack histogram}]}. `ready` of group
  all = the arrivals' route weights exactly. LuckyCore.select({pace, anchor}) builds the no-whistle plan from it;
  each dog-anchored variant has a first cast minT = 17 + 2·(D//2) (its READY); whistle plans only for all + ready.
- `lroutes` (v29.5, `tools/route_tables.py` → `webapp/assets/lucky_routes.json`): extra Lucky Timer routes, each
  {id, label, note, save, route, basis, source {file, sha256, casts, polls, nut1, nut2}, casts (one table in the
  `casts[k]` format, from VI lo = poll + 1), anchors [{id, label, r0}]}: on anchor a's stopwatch READY sits r0 VI after
  the start event, path VI = t − r0, first cast t = r0 + 1. `nodog-nohorse-no-pickup`: anchors beach (r0 328), pier
  (r0 0). LuckyCore appends the route tables to the dog-path series list; selection {route, pace, anchor}.
