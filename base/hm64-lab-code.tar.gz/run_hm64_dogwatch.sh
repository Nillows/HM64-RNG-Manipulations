#!/usr/bin/env bash
# HM64 Power Nut lab - DOG-WATCH lab (zigzag-4d, 2026-11-16, v30 groundwork): what the dog shows on screen while you
# wait at the dock end, before the cast - can a runner's dog logs (Dog Oracle keys: animation + facing) tell the dog
# lines apart, and what does that add to the Power Nut odds?
# The beach-lineup2 save only (dog on screen from the dock end), from the ground up (own state store and results):
# menus 0-9 game frames late (house 0-18 VIs after the fastest, VI 1036: fast mornings + sparrow mornings), house /
# farm / crossroads / ranch within 8 / 8 / 6 VIs of the fastest walk, first cut D 84 / 86, beach wait 0-30 VIs, every
# second cut across the pier (B 112-151), and per dog line its natural path 40 s after READY: what you can see (sprite
# animation + screen facing, per VI), the displayed animation, dogInfo decisions (actionState / direction / timer),
# dog RNG draws, position, visibility grid. Then the fast cast tables (every game frame 0.1-40 s, bites 1 and 2).
#
#   bash run_hm64_dogwatch.sh [workers]
#
# Phase 1 (route recipe + dog lines + traces, no casts) -> DOGWATCH.md early: runs/hm64-dogwatch-early-<label>-<t>.zip
# Phase 2 (renders): frames of the dock-end view on 4 second cuts -> results/dogwatch/<label>/render/*/sheet.png
# Phase 3 (cast tables) -> DOGWATCH.md with the Nut odds: runs/hm64-dogwatch-<label>-<t>.zip  (send this one)
# Saves: the beach-lineup2 SaveRAM (sha256 52cfd712...) from sourcefiles/lineup/ (lineup package), sourcefiles/dogwatch/
# or sourcefiles/dogspots/ (first one that has it). Queues behind a lab run that is going. Ctrl-C any time; the same
# command continues. Env: HM64_DOGWATCH_PHASES=1 (stop after phase 1+2), HM64_DOGWATCH_RENDER=0 (no renders),
# HM64_DOGSPOTS_PRESET (default dogwatch), HM64_DOGSPOTS_WAIT=0 (do not queue), M64H_CPU, M64H_RECYCLE, HM64_RUN_ROOT.
set -euo pipefail

say() { printf '\n==> %s\n' "$*"; }
die() { printf '\nSTOP: %s\n' "$*" >&2; exit 1; }

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKERS=${1:-}
PRESET=${HM64_DOGSPOTS_PRESET:-dogwatch}
RES="results/$PRESET"
TARBALL="${HM64_LAB_TARBALL:-$HERE/hm64-lab-dogwatch.tar.gz}"
INPUTS="$HERE/sourcefiles"
LINEUP2_SHA=52cfd712095494d3217fdc032f88439216abfb6b6f2e55e0fb14e4c6d0e31a84
DOGBEACH_SHA=0d78b95b78e4a988570b3648d9bc16021df59a5faccdc00d06b01273975d8387
SPRING9_SHA=db2c29ace807ab980ebbc7eccad11e30e37ea3dad53113c3fb1bdc073b759d63
ROM_SHA=15c570120bfaa97b4580762f5ee5939a56ba054e696925ea81ccfa55a022d2a6
[ -f "$TARBALL" ] || die "$(basename "$TARBALL") is not next to this script ($HERE)"
mkdir -p "$INPUTS"

if [ "${HM64_DRY_RUN:-0}" != 1 ]; then
  command -v docker >/dev/null || die "docker not found"
  docker info >/dev/null 2>&1 || die "Docker is not running (start Docker Desktop)"
fi

RUN_ROOT=${HM64_RUN_ROOT:-$HERE/runs}
WORK="$RUN_ROOT/dogspots"
LAB="$WORK/hm64-lab"
mkdir -p "$WORK"
LOCK="$WORK/.running"
WAITED=0
while :; do                                    # one lab run at a time; HM64_DOGSPOTS_WAIT=1: queue behind the current one
  if [ -d "$RUN_ROOT/zigzag/.running" ]; then busy="a zigzag run ($RUN_ROOT/zigzag/.running)"
  elif mkdir "$LOCK" 2>/dev/null; then break
  else busy="the dog-spot / lineup run now going ($LOCK)"
  fi
  [ "${HM64_DOGSPOTS_WAIT:-1}" = 1 ] || die "$busy - start this one after it finishes (one lab run at a time; if none is running, delete that folder)"
  if [ $((WAITED % 15)) -eq 0 ]; then
    echo "  $(date +%H:%M) waiting for $busy to finish; this run starts by itself right after it (Ctrl-C cancels; if nothing is running, delete that folder)"
  fi
  WAITED=$((WAITED + 1))
  sleep 60
done
trap 'rmdir "$LOCK" 2>/dev/null || true' EXIT
STAMP=$(date +%Y%m%d-%H%M%S)
LOG="$WORK/run-$PRESET-$STAMP.log"
exec > >(tee -a "$LOG") 2>&1
say "work folder: $LAB  (preset $PRESET)"

say "1/7 lab code"
TMPX="$WORK/.code-$STAMP"
mkdir -p "$TMPX"
tar -xzf "$TARBALL" -C "$TMPX"
[ -f "$TMPX/hm64-lab/docker-compose.yml" ] || die "tarball does not contain hm64-lab/"
mkdir -p "$LAB"
for e in "$TMPX/hm64-lab/"* "$TMPX/hm64-lab/".[!.]*; do
  [ -e "$e" ] || continue
  b=$(basename "$e")
  case "$b" in states|results|data) continue ;; esac
  if [ -e "$LAB/$b" ]; then chmod -R u+w "$LAB/$b" 2>/dev/null || true; rm -rf "${LAB:?}/${b:?}"; fi
  cp -R "$e" "$LAB/$b"
done
mkdir -p "$LAB/data" "$LAB/states" "$LAB/results"
for d in "$TMPX/hm64-lab/data/"*; do
  [ -e "$LAB/data/$(basename "$d")" ] || cp -R "$d" "$LAB/data/"
done
chmod -R u+w "$TMPX" 2>/dev/null || true
rm -rf "${TMPX:?}"
echo "  lab code: $(grep -m1 "^ZZ_CODE" "$LAB/tools/zigzag_campaign.py" || echo unknown)"

say "2/7 inputs"
XTR="$WORK/extracted-inputs"; mkdir -p "$XTR"
sha() { shasum -a 256 "$1" | cut -d' ' -f1; }
ROM=$(find -L "$INPUTS" -type f -iname '*.z64' ! -path "*/runs/*" 2>/dev/null | head -n 1 || true)
if [ -z "$ROM" ]; then
  while IFS= read -r z; do
    m=$(unzip -Z1 "$z" 2>/dev/null | grep -i -E '\.z64$' | head -n 1 || true)
    if [ -n "$m" ]; then unzip -q -o -j "$z" "$m" -d "$XTR" && ROM="$XTR/$(basename "$m")" && break; fi
  done < <(find -L "$INPUTS" -type f -iname '*.zip' ! -path "*/runs/*" 2>/dev/null)
fi
[ -n "$ROM" ] || die "no *.z64 ROM under $INPUTS"
RS=$(sha "$ROM")
[ "$RS" = "$ROM_SHA" ] && echo "  ROM      $ROM  (sha256 OK, NYWE rev00)" || echo "  WARNING: ROM sha256 $RS is not the known NYWE rev00 dump ($ROM)"

SAVE=""; SAVEDIR=""
for dn in lineup dogwatch dogspots; do                 # the beach-lineup2 save: first folder that has it (also in zips)
  d="$INPUTS/$dn"
  [ -d "$d" ] || continue
  SPX="$XTR/$dn"; mkdir -p "$SPX"
  while IFS= read -r z; do
    zn=$(basename "$z" .zip | tr -c 'A-Za-z0-9._-' '-')
    mkdir -p "$SPX/$zn"
    unzip -q -o "$z" -d "$SPX/$zn" >/dev/null 2>&1 || true
  done < <(find -L "$d" -type f -iname '*.zip' 2>/dev/null)
  while IFS= read -r f; do
    case "$f" in */__MACOSX/*|*/._*) continue ;; esac
    if [ "$(sha "$f")" = "$LINEUP2_SHA" ]; then SAVE="$f"; SAVEDIR="$d"; break; fi
  done < <(find -L "$d" "$SPX" -type f \( -iname '*.SaveRAM' -o -iname '*.sra' -o -iname '*.sav' -o -iname '*.srm' \) 2>/dev/null | sort)
  [ -n "$SAVE" ] && break
done
[ -n "$SAVE" ] || die "the beach-lineup2 save (sha256 ${LINEUP2_SHA:0:8}...) is in none of sourcefiles/lineup, sourcefiles/dogwatch, sourcefiles/dogspots - put 'Harvest Moon 64 (USA).beach-lineup2.SaveRAM' in sourcefiles/dogwatch/"
S9SAVE=""
while IFS= read -r f; do
  [ "$(sha "$f")" = "$SPRING9_SHA" ] && [ -z "$S9SAVE" ] && S9SAVE="$f"
done < <(find -L "$INPUTS" -maxdepth 1 -type f \( -iname '*.SaveRAM' -o -iname '*.sra' -o -iname '*.sav' \) 2>/dev/null)
mkdir -p "$LAB/data/rom" "$LAB/data/saves" "$LAB/data/saves_dogspots"
chmod -R u+w "$LAB/data" 2>/dev/null || true
cp "$ROM" "$LAB/data/rom/Harvest_Moon_64_USA.z64"
[ -n "$S9SAVE" ] && cp "$S9SAVE" "$LAB/data/saves/Harvest_Moon_64_USA3.SaveRAM"
label="beach-lineup2-${LINEUP2_SHA:0:8}"
cp "$SAVE" "$LAB/data/saves_dogspots/$label.SaveRAM"
echo "  save     $label   <- $SAVE  (sha256 OK)"
if [ "${HM64_DRY_RUN:-0}" = 1 ]; then echo; echo "DRY RUN: inputs found as above; stopping before Docker."; exit 0; fi
chmod -R a+rwX "$LAB/states" "$LAB/results" "$LAB/experiments" 2>/dev/null || true

say "3/7 building the Docker image (first time: several minutes)"
cd "$LAB"
# shellcheck disable=SC2086
docker build --platform linux/amd64 -t hm64-lab:latest --build-arg INSTALL_CLAUDE="${INSTALL_CLAUDE:-1}" \
  ${HM64_DOCKER_BUILD_EXTRA:-} .
if [ -z "$WORKERS" ]; then
  NCPU=$(docker run --rm --platform linux/amd64 hm64-lab:latest nproc 2>/dev/null || echo 2)
  WORKERS=$(( NCPU > 1 ? NCPU - 1 : 1 ))
fi

say "4/7 lab health test"
if [ -n "$S9SAVE" ]; then
  docker compose run --rm -T lab bash -lc 'python3 tools/smoke_test.py' \
    || die "smoke test failed - see $LOG (results would not be trustworthy)"
else
  echo "  skipped (no Spring 9 save); every save starts with its own repeatability record (Z0)"
fi

RES_L="$RES/$label"
mkdir -p "$LAB/$RES_L"
zz() {                                                 # zz <stop-after or ''>: the dog-watch campaign on this save
  docker compose run --rm -T -e HM64_SRAM="/work/data/saves_dogspots/$label.SaveRAM" \
    -e HM64_ZZ_STORE="/work/states/dogwatch/$label" -e HM64_CORE_FILE=/work/results/core.json \
    -e HM64_ZZ_STOP_AFTER="$1" -e HM64_ZZ_MAX_LINES="${HM64_ZZ_MAX_LINES:-0}" \
    -e M64H_CPU="${M64H_CPU:-}" -e M64H_RECYCLE="${M64H_RECYCLE:-6}" lab \
    python3 tools/zigzag_campaign.py --preset "$PRESET" --workers "$WORKERS" --out "$RES_L" </dev/null
}
dwreport() {
  docker compose run --rm -T lab python3 tools/dogwatch_report.py "$RES_L" </dev/null || echo "  (dog-watch report failed - see $LOG)"
}
pack() {                                               # pack <zip>: this save's results (no ROM / saves / savestates)
  ( cd "$LAB/$RES" && zip -q -r "$1" "$label" -x "*.SaveRAM" "*.st" "*.state" ) && echo "  zip      $1"
}

say "5/7 phase 1: route recipe + dog lines + what the dog shows after READY ($PRESET, $WORKERS workers)"
T0=$(date +%s)
zz Z6 || die "phase 1 stopped - see $LAB/$RES_L/ZIGZAG.md and $LOG (run the same command again to continue)"
dwreport
echo
echo "------------------------------------------------------------------------------------------------"
echo " DOG-WATCH, EARLY (no cast tables yet)   $label   ($(( ($(date +%s) - T0) / 60 )) min)"
echo "------------------------------------------------------------------------------------------------"
sed -n '1,40p' "$LAB/$RES_L/DOGWATCH.md" 2>/dev/null || true
pack "$RUN_ROOT/hm64-dogwatch-early-$label-$STAMP.zip" || true

if [ "${HM64_DOGWATCH_RENDER:-1}" = 1 ]; then
  say "6/7 phase 2: dock-end view renders (what the dog looks like on screen; 4 second cuts, 10 s after READY each)"
  for B in 118 124 130 138; do
    out="$RES_L/render/B$B"
    [ -f "$LAB/$out/sheet.png" ] && { echo "  B $B: done before"; continue; }
    docker compose run --rm -T -e HM64_SRAM="/work/data/saves_dogspots/$label.SaveRAM" lab \
      xvfb-run -a -s "-screen 0 640x480x24" python3 experiments/dogwatch_render.py "$out" \
      "{\"T\": 6, \"h\": 3, \"ph\": 0, \"style\": \"START>A\", \"U\": 276, \"V\": 52, \"C\": 80, \"D\": 86, \"B\": $B}" 600 30 \
      </dev/null || echo "  (render B $B failed - the lab results do not depend on it)"
  done
fi

if [ "${HM64_DOGWATCH_PHASES:-3}" = 1 ]; then
  echo; echo "DONE (phases 1-2 only, HM64_DOGWATCH_PHASES=1). Run again without it for the cast tables."
  exit 0
fi

say "7/7 phase 3: cast tables (every game frame 0.1-40 s after READY, bites 1 and 2) + the odds"
T1=$(date +%s)
rc=0
zz "" || rc=$?
[ "$rc" = 0 ] || echo "  the campaign stopped (exit $rc) - see $LAB/$RES_L/ZIGZAG.md; the report below uses what is there"
dwreport
cp "$LOG" "$LAB/$RES_L/run-$PRESET-$STAMP.log" 2>/dev/null || true
echo
echo "------------------------------------------------------------------------------------------------"
echo " DOG-WATCH RESULTS   $label   (phase 3: $(( ($(date +%s) - T1) / 60 )) min)"
echo "------------------------------------------------------------------------------------------------"
sed -n '1,40p' "$LAB/$RES_L/DOGWATCH.md" 2>/dev/null || true
OUTZIP="$RUN_ROOT/hm64-dogwatch-$label-$STAMP.zip"
pack "$OUTZIP" || die "zip failed"
echo
echo "DONE."
echo "  report     : $LAB/$RES_L/DOGWATCH.md  (and ZIGZAG.md, renders in render/B*/sheet.png)"
echo "  zip        : $OUTZIP   (no ROM / saves / savestates inside; send this one)"
