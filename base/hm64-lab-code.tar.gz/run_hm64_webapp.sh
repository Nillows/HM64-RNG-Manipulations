#!/bin/bash
# Rebuild the v28 Dog Oracle web app from your lab runs (natively: no Docker, no emulation, ~10 s).
# Run it after a new campaign run (e.g. the casttables preset) to put the new cast tables into the app.
#
#   cd ~/Documents/hm64 && bash run_hm64_webapp.sh
#
# Needs python3 with numpy (conda base has it). Output: ~/Documents/hm64/webapp/HM64_Dog_Oracle_v29_9.html
# The Lucky Timer's whistle plans come from the newest run with lucky_tables.json (preset lucky), if any.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
WA="$HERE/webapp-build"
die() { echo "ERROR: $*" >&2; exit 1; }
[ -f "$HERE/hm64-lab.tar.gz" ] || die "hm64-lab.tar.gz not next to this script"
PY="${HM64_PYTHON:-python3}"
"$PY" -c "import numpy" 2>/dev/null || die "$PY has no numpy (try: conda activate base, or pip3 install numpy)"
TMP="$(mktemp -d)"
tar -xzf "$HERE/hm64-lab.tar.gz" -C "$TMP"
rm -rf "$WA"; mkdir -p "$WA/data/routes"
cp -R "$TMP/hm64-lab/tools" "$TMP/hm64-lab/hm64" "$TMP/hm64-lab/webapp" "$WA/"
rm -rf "$TMP"
CSV="$(find -L "$HERE/sourcefiles" -iname '*ROUTE_TO_CHECKPOINT_LINKS*.csv' 2>/dev/null | head -1 || true)"
if [ -n "$CSV" ]; then cp "$CSV" "$WA/data/routes/ROUTE_TO_CHECKPOINT_LINKS.csv"
else echo "note: ROUTE_TO_CHECKPOINT_LINKS.csv not found in sourcefiles - arrivals will not be route-weighted"; fi
TRUTH=""
for d in $(ls -dt "$HERE"/runs/*/hm64-lab/results/campaign-* 2>/dev/null); do
  if [ -f "$d/O_observe.jsonl" ] && [ -f "$d/W_lines.json" ]; then TRUTH="$d"; break; fi
done
[ -n "$TRUTH" ] || die "no run folder with O_observe.jsonl + W_lines.json under $HERE/runs (run the pulse or casttables preset first)"
CASTS=()
for d in $(ls -dt "$HERE"/runs/*/hm64-lab/results/campaign-* 2>/dev/null); do
  if [ -f "$d/B_natural.jsonl" ] || [ -f "$d/K_casts.jsonl" ]; then CASTS+=("$d"); fi
done
echo "==> dog paths from: $TRUTH"
for d in ${CASTS[@]+"${CASTS[@]}"}; do echo "==> cast tables from: $d"; done
LK="$(ls -t "$HERE"/runs/*/hm64-lab/results/campaign-*/lucky_tables.json 2>/dev/null | head -1 || true)"
if [ -n "$LK" ]; then echo "==> Lucky Timer whistle plans from: $LK"; else echo "==> Lucky Timer: no-whistle plans only (run the lucky preset for 1-3 whistle plans)"; fi
mkdir -p "$HERE/webapp"
cd "$WA"
"$PY" tools/export_webapp.py --truth "$TRUTH" --casts ${CASTS[@]+"${CASTS[@]}"} \
  --sprites webapp/assets/dog_sprites.json --names webapp/assets/user_names_keys.json --out "$HERE/webapp" \
  --lucky "${LK:-none}"
APP="$HERE/webapp/HM64_Dog_Oracle_v29_9.html"
echo "==> app: $APP"
if command -v open >/dev/null 2>&1 && [ "${HM64_NO_OPEN:-0}" != 1 ]; then open "$APP"; fi
