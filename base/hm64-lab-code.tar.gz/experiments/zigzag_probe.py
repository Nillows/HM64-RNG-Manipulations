"""Zig-zag route probe on the dog-beach save (HM64_SRAM). One process, one cold boot per spec.
  HM64_SRAM=<dog-beach save> python3 experiments/zigzag_probe.py '<json spec>' ['<json spec>' ...]
spec keys: T h ph style (mash), U V C D B (cuts, polls after each map change), hz (VIs to record after READY).
Prints per spec: stage starts (poll, VI, draw), first move per stage, beach: dog wake (first dogInfo change) VI/draw,
READY VI / position, strict stage hashes, draw index and dog signature every 30 VIs after READY."""
import sys, json, hashlib
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from m64h.core import Emulator
from tools.common import default_rom, default_sram
from hm64 import addresses as A
from hm64.lcg import index
from hm64.zigzag import ZigZagInput, Mash, stage_hash, player_xz, dog_sig, RESET_VI, MAP_BEACH


def run(emu, sp):
    inp = ZigZagInput(Mash(sp.get("T", 6), sp.get("h", 3), sp.get("ph", 0), sp.get("style", "START>A")),
                      U=sp["U"], V=sp["V"], C=sp["C"], D=sp["D"], B=sp["B"])
    rec = {"stages": {}, "first_move": {}, "wake": None, "ready": None}
    st = {"stage": 0, "last_pos": None, "still": 0, "dog0": None, "beach_vi": None}

    def watch(e):
        inp.sample(e)
        if inp.stage != st["stage"]:
            st["stage"] = inp.stage
            rec["stages"][inp.stage] = {"vi": e.vi, "poll": inp.stage_start, "draw": index(e.u32(A.RAND_SEED)),
                                        "hash": stage_hash(e), "clock": [e.u8(A.HOUR), e.u8(A.MINUTES), e.u8(A.SECONDS)]}
            st["last_pos"] = player_xz(e)
            if inp.stage == 5:
                st["dog0"] = dog_sig(e)
                st["beach_vi"] = e.vi
            return
        p = player_xz(e)
        s = inp.stage
        if s >= 1 and s not in rec["first_move"] and p != st["last_pos"]:
            rec["first_move"][s] = e.vi - rec["stages"][s]["vi"]
        if s == 5:
            if rec["wake"] is None and dog_sig(e) != st["dog0"]:
                rec["wake"] = {"vi": e.vi - st["beach_vi"], "draw": index(e.u32(A.RAND_SEED)), "pos": p}
            if rec["ready"] is None and inp.stage_start and (e.polls() - inp.stage_start) > sp["D"] + sp["B"]:
                st["still"] = st["still"] + 1 if p == st["last_pos"] else 0
                if st["still"] >= 4 and p[0] > -100:
                    rec["ready"] = {"vi": e.vi - 4 - st["beach_vi"], "pos": p, "draw": index(e.u32(A.RAND_SEED)),
                                    "abs_vi": e.vi - 4}
                    inp.released = True
        st["last_pos"] = p

    emu.schedule_hard_reset(RESET_VI)
    emu.add_listener(watch)
    emu.set_poll_callback(inp)
    while emu.vi < 6000 and rec["ready"] is None:
        emu.advance(1)
    after = []
    if rec["ready"]:
        for k in range(sp.get("hz", 0) // 30):
            emu.advance(30)
            after.append([emu.vi - st["beach_vi"], index(emu.u32(A.RAND_SEED)),
                          hashlib.blake2b(dog_sig(emu), digest_size=4).hexdigest()])
    rec["after"] = after
    rec["spec"] = sp
    return rec


specs = [json.loads(s) for s in sys.argv[1:]]
for sp in specs:
    with Emulator(default_rom(), sram=default_sram()) as emu:
        print(json.dumps(run(emu, sp)), flush=True)
