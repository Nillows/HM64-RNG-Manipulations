"""Play stick legs from a state and report the VI (from the state) when a map value appears; the last leg is held.
  python3 experiments/legs_until_map.py <state.st> <map_value> <legs> [<legs> ...]   legs: "N:263,DR:10,D:0" """
import sys, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from m64h.core import Emulator
from tools.common import default_rom, default_sram
from hm64 import route as R
from hm64 import addresses as A
ent = A.ENTITIES + A.ENTITY_PLAYER * A.ENTITY_SIZE
STICK = {"N": (0, 0), "DR": (80, -80), "DL": (-80, -80), "D": (0, -80), "L": (-80, 0), "R": (80, 0),
         "UL": (-80, 80), "UR": (80, 80), "U": (0, 80)}
st, target = sys.argv[1], int(sys.argv[2])
with Emulator(default_rom(), sram=default_sram()) as emu:
    for spec in sys.argv[3:]:
        emu.load_state(st)
        v0 = emu.vi
        legs = [(n, int(t)) for n, t in (p.split(":") for p in spec.split(","))]
        hit, path = None, []
        for i, (n, t) in enumerate(legs):
            emu.set_input(*STICK[n]) if False else emu.set_input(x=STICK[n][0], y=STICK[n][1])
            k = t if i < len(legs) - 1 else 1200
            for _ in range(k):
                emu.advance(1)
                path.append((round(emu.f32(ent + 0x28), 1), round(emu.f32(ent + 0x30), 1)))
                if emu.u16(R.MAP_CTRL) == target:
                    hit = emu.vi - v0
                    break
            if hit:
                break
        emu.release()
        moving = [i for i in range(1, len(path)) if path[i] != path[i - 1]]
        print(json.dumps({"legs": spec, "map_at": hit, "first_move": moving[0] + 1 if moving else None,
                          "last_pos": path[-1] if path else None}), flush=True)
