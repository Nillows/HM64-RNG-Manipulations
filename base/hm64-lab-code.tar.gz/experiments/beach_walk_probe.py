"""Beach-walk probe (2026-11-13, sandbox): does the dog's future from the landing depend on where the delay was spent?
One route per process (one emulator per process):
  python3 experiments/beach_walk_probe.py <kind> <k> [horizon_vi] > out.json
kind: base | d0 | H | C | P (the route delays) | walk (pause k polls in the beach walk, after "D:100", dog carried).
Prints JSON: landing (dog_placed) VI, READY VI and per VI from the landing (rng, dog action, direction, timer).
Match the output against the dog paths with experiments/beach_walk_match.py."""
import sys, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from m64h.core import Emulator
from tools.common import default_rom, default_sram
from hm64 import route as R
from hm64 import addresses as A
kind, k = sys.argv[1], int(sys.argv[2]); HZ = int(sys.argv[3]) if len(sys.argv) > 3 else 900
orig = R.beach_steps
if kind == "walk":                       # pause k polls in the middle of the beach walk (dog still carried)
    def beach_steps(D, variant=R.BEACH_V14):
        return orig(D, variant).replace("D:100,", f"D:100,N:{k},", 1)
    R.beach_steps = beach_steps
case = R.RouteCase(**({} if kind in ("base", "walk") else {kind: k}))
rows = {}
with Emulator(default_rom(), sram=default_sram()) as emu:
    emu.add_listener(lambda e: rows.__setitem__(e.vi - 1, (e.u32(A.RAND_SEED), e.u8(A.DOG + 0x17), e.u8(A.DOG + 0x18), e.u8(A.DOG + 0x1A))))
    r = R.run_route(emu, case)
    st = r["stages"]
    emu.advance(HZ)
dp = st["dog_placed"]["vi"]
seq = [rows.get(dp + i) for i in range(0, HZ)]
print(json.dumps({"kind": kind, "k": k, "outcome": r["outcome"], "beach": st["beach_held"]["vi"], "dog_placed": dp,
                  "ready": st["fishing_ready"]["vi"], "seq": seq}))
