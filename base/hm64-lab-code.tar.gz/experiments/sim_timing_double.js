/* a runner whose start tap comes 50 ms later than the start-tap delay, who presses B 100 ms after the CAST cue (+-25),
   NO cast tap, bite taps 13 VIs after the bite; the CAST cue is corrected by -100 ms (old build: set by hand as cast
   practice's Apply did; new build: learned from 10 practice presses). Landing error vs the aim over 16 attempts. */
(function () {
  setTimeout(async () => {
    const A = window.HM64LuckyApp, $ = id => document.getElementById(id), out = { errors: [], steps: [] }; window.requestAnimationFrame = () => 0;
    try {
      $('arLucky').click();
      A.L.audio = false; A.L.tapStrategy = 'b'; A.L.beachCue = 'fade'; A.L.castTap = false; A.L.autoTune = true;
      $('lkRoute').value = 'lineup-dogbeach'; $('lkRoute').onchange({ target: $('lkRoute') });
      const vi = 33.053 / 2;
      let seed = 21; const rnd = () => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff), g = () => Math.sqrt(-2 * Math.log(rnd() + 1e-9)) * Math.cos(2 * Math.PI * rnd());
      if (A.cueCorr) { for (let i = 0; i < 10; i++) A.pracLog.push({ at: Date.now() + i, e: Math.round(100 + 25 * g()), m: A.L.pracLine ? 'line' : 'beeps', src: 't', v: 1 }); A.refresh(); }
      else { A.L.biasMs = -100; A.refresh(); }
      out.corr = A.cueCorr ? A.cueCorr() : A.L.biasMs;
      const P0 = A.plans[0], W = P0.variants.reduce((a, x) => a + x.w, 0);
      const pick = () => { let r = rnd() * W; for (const x of P0.variants) { r -= x.w; if (r <= 0) return x; } return P0.variants[0]; };
      for (let k = 0; k < 13; k++) {
        const F0 = performance.now() - 40000;
        A.start(F0 + 150 + 50);                                  // the fade-in tap: start-tap delay 150 + 50 ms slower
        const cs = A.run.cs, off = (A.run.wall0 - F0) / vi;      // console plan time = stopwatch + off
        const corr = A.cueCorr ? A.cueCorr() : A.L.biasMs;
        const x = pick(), s = P0.series[x.s];
        let c = A.run.T + corr / vi + (100 + 25 * g()) / vi;     // B press: 100 ms after the CAST cue
        let i = Math.round(c + off) + x.o - s.v0, dd = 0;
        while (!(s.n1[i + dd] >= 0) && dd < 3) dd++;
        if (!(s.n1[i + dd] >= 0)) { A.stop(true); continue; }
        i += dd; c += dd;
        A.registerTap(c + s.b1[i] + 13);
        A.record(false, 'fish');
        out.steps.push({ k, cs: +cs.toFixed(1), landErrMs: Math.round((c + off - A.run.T) * vi) });
      }
      const late = out.steps.filter(x => x.k >= 9).map(x => x.landErrMs);
      out.meanLandErrAfterTune = Math.round(late.reduce((a, v) => a + v, 0) / late.length);
    } catch (e) { out.errors.push(String(e && e.stack || e)); }
    const pre = document.createElement('pre'); pre.id = 'testout'; pre.textContent = JSON.stringify(out); document.body.appendChild(pre);
  }, 600);
})();
