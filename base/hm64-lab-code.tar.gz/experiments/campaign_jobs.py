"""
Job functions for tools/campaign.py (must be importable for the process pool).

route_job : cold boot -> carry route -> dock READY, then the natural future
            (no input) for `horizon` VIs. Ready states are de-duplicated by
            natural signature into states/campaign/<sig>.st.
cast_job  : one (scenario state, whistles, cast) plan via hm64.fishing.eval_cast.
"""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
from pathlib import Path

from _base import ROOT, A
from hm64.lcg import index
from hm64.observe import DogObserver
from hm64.route import RouteCase, run_route


def route_job(emu, j):
    horizon = int(j.get("horizon", 1800))
    store = ROOT / j.get("store", "states/campaign")
    store.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(suffix=".st", dir=str(store)); os.close(fd)
    res = run_route(emu, RouteCase(*j["case"]), max_vi=3600, ready_state_path=tmp)
    out = {"label": j["label"], "family": j.get("family"), "outcome": res["outcome"]}
    if res["outcome"] != "ready":
        for p in (tmp, tmp + ".json"):
            if os.path.exists(p):
                os.remove(p)
        out["stages_reached"] = [k for k, v in res["stages"].items() if v]
        return out
    fr = res["stages"]["fishing_ready"]
    obs = DogObserver(emu)
    traj = []
    emu.add_listener(obs)
    emu.add_listener(lambda e: traj.append((e.u32(A.RAND_SEED), e.u16(A.PLAYER + 0x64))))
    emu.advance(horizon)
    dec = [(e["t"], e["state"], e["dir"]) for e in obs.events if e["kind"] == "decision"]
    sig = hashlib.sha256(json.dumps([dec, traj]).encode()).hexdigest()[:16]
    final = store / f"{sig}.st"
    if final.exists():
        os.remove(tmp); os.remove(tmp + ".json")
    else:
        os.replace(tmp, final); os.replace(tmp + ".json", str(final) + ".json")
    naps = [i for i, (_, act) in enumerate(traj) if act == 9]
    return {**out, "ready_vi": fr["vi"], "draw_index": index(fr["rng"]),
            "dog_at_ready": [fr["dog_action"], fr["dog_direction"], fr["dog_timer"]],
            "signature": sig, "state": str(final.relative_to(ROOT)),
            "events": [[e["t"], e["state"], e["anim"], e["dir"]] for e in obs.events if e["kind"] == "decision"],
            "unexplained": sum(e["kind"] == "unexplained" for e in obs.events),
            "first_idle_nap_vi": naps[0] if naps else None, "horizon": horizon}


def cast_job(emu, j):
    from hm64.fishing import eval_cast
    r = eval_cast(emu, ROOT / j["state"], j["cast"], whistles=j.get("whistles", ()))
    return {"signature": j["signature"], **r}


def ladder_job(emu, j):
    """Walk a scenario's natural path (no input) from READY for `horizon` VIs:
    record what the dog visibly shows (ROM sprite class + facing) every VI and
    save a checkpoint ("rung") every `rung_polls` controller polls. Cast jobs
    then start from the nearest rung instead of from READY.

    Times: t in VIs after READY (t=1 is the first VI after the READY instant);
    rung p = absolute poll after READY at which the rung was taken (after
    loading a rung, poll 0 == READY-relative poll p).
    """
    from hm64.sprites import visual_class
    horizon = int(j.get("horizon", 1800))
    step = int(j.get("rung_polls", 60))
    rung_until = int(j.get("rung_until", 10 ** 9))     # no rungs past the last cast that will use them
    store = ROOT / j.get("store", "states/campaign/ladder") / j["signature"].replace(":", "_")
    store.mkdir(parents=True, exist_ok=True)
    ent = A.ENTITIES + A.ENTITY_DOG * A.ENTITY_SIZE
    wake = [int(w) for w in j.get("wake", [])]          # SE stay-awake pushes (polls after READY)
    if wake:
        from hm64.fishing import FishController
        emu.set_poll_callback(FishController(wake=wake))
    else:
        emu.set_poll_callback(None)
    emu.load_state(ROOT / j["state"])
    v0 = emu.vi - 1
    rows = []
    rec = emu.add_listener(lambda e: rows.append((e.vi - v0, e.polls(), e.u16(ent + 0x54), e.u8(ent + 0x67),
                                                  e.u32(A.RAND_SEED))))
    rows.append((1, emu.polls(), emu.u16(ent + 0x54), emu.u8(ent + 0x67), emu.u32(A.RAND_SEED)))
    rungs, mark = [], step
    try:
        while emu.vi - v0 < horizon:
            emu.advance_until(lambda e: e.polls() >= mark or e.vi - v0 >= horizon, horizon)
            if emu.polls() >= mark and emu.vi - v0 < horizon:
                p = emu.polls()
                if p > rung_until:
                    mark = 10 ** 9                       # keep recording the path, stop saving rungs
                    continue
                path = store / f"p{p:05d}.st"
                emu.save_state(path, meta={"poll_after_ready": p, "signature": j["signature"]})
                rungs.append([p, str(path.relative_to(ROOT))])
                mark = p + step
    finally:
        emu.remove_listener(rec)
    seg = []
    for t, polls, base, scr, _ in rows:
        key = (scr, visual_class(base, scr))
        if seg and (seg[-1][2], seg[-1][3]) == key:
            seg[-1][1] = t + 1
        else:
            seg.append([t, t + 1, scr, key[1], base])
    vi_poll = [(t, p) for t, p, *_ in rows]
    polls_after = [0] * (vi_poll[-1][0] + 1)          # polls_after[t] = polls read by the end of VI t
    for t, p in vi_poll:
        polls_after[t] = p
    for t in range(1, len(polls_after)):
        polls_after[t] = max(polls_after[t], polls_after[t - 1])
    return {"signature": j["signature"], "segments": seg, "rungs": rungs, "polls_after": polls_after,
            "polls_minus_vi_end": vi_poll[-1][1] - vi_poll[-1][0],
            "end": {"t": rows[-1][0], "rng": rows[-1][4], "draw": index(rows[-1][4])}}


def cast_job_rung(emu, j):
    """cast_job, but start from the latest ladder rung at least 2 polls before
    the first input (falls back to READY). Results are in READY-relative polls."""
    from hm64.fishing import eval_cast
    first_input = min([j["cast"]] + list(j.get("whistles", [])))
    p, st = 0, j["state"]
    for rp, rpath in j.get("rungs", []):
        if rp <= first_input - 2 and rp > p:
            p, st = rp, rpath
    r = eval_cast(emu, ROOT / st, j["cast"] - p, whistles=[w - p for w in j.get("whistles", [])],
                  hold_bites=int(j.get("hold_bites", 1)), map_window=bool(j.get("map_window", True)),
                  wake=[w - p for w in j.get("wake", []) if w >= p and w + 30 <= j["cast"]])   # a runner never pushes right before casting
    if j.get("wake"):
        r["wake"] = list(j["wake"])
    shift = lambda v: None if v is None else v + p
    r["cast"] = j["cast"]
    r["whistles"] = list(j.get("whistles", []))
    r["bite_poll"] = shift(r["bite_poll"])
    r["cast_started_poll"] = shift(r.get("cast_started_poll"))
    r["nut_releases"] = [x + p for x in r["nut_releases"]]
    if r.get("window_outcomes"):
        r["window_outcomes"]["from_poll"] += p
    for b in r.get("bites", []):
        if b.get("bite_poll") is not None:
            b["bite_poll"] += p
    r["rung"] = p
    return {"signature": j["signature"], **r}


def observe_job(emu, j):
    """What a runner can see for `horizon` VIs after READY (no input), plus the
    hidden state it comes from, for the observation/identification study.

    Returns (t = VIs after READY, t=1 is the READY instant):
      vis   [[t0, t1, screen, visual_class, sprite_base], ...]  merged runs of what is on screen
      draw  [[t, draw_index], ...]       absolute rand() count since boot, whenever it changes
      dog   [[t, actionState, direction, stateTimer], ...]   whenever any of them changes
    """
    from hm64.lcg import MASK, step as lcg_step
    from hm64.sprites import visual_class
    horizon = int(j.get("horizon", 3600))
    ent = A.ENTITIES + A.ENTITY_DOG * A.ENTITY_SIZE
    emu.set_poll_callback(None)
    emu.load_state(ROOT / j["state"])
    v0 = emu.vi - 1
    rows = []

    def snap(e):
        rows.append((e.vi - v0, e.u16(ent + 0x54), e.u8(ent + 0x67), e.u32(A.RAND_SEED),
                     e.u8(A.DOG + 0x17), e.u8(A.DOG + 0x18), e.u8(A.DOG + 0x1A)))
    snap(emu)
    rec = emu.add_listener(snap)
    try:
        emu.advance_until(lambda e: e.vi - v0 >= horizon, horizon + 2)
    finally:
        emu.remove_listener(rec)
    vis, draw, dog = [], [], []
    d = index(rows[0][3])
    seed = rows[0][3]
    for t, base, scr, s, act, dr, tm in rows:
        cls = visual_class(base, scr)
        if vis and vis[-1][2] == scr and vis[-1][3] == cls:
            vis[-1][1] = t + 1
        else:
            vis.append([t, t + 1, scr, cls, base])
        n = 0
        while seed != s and n < 100000:                 # few rand() calls per VI
            seed = lcg_step(seed) & MASK
            n += 1
        if seed != s:
            d, seed = index(s), s
        else:
            d += n
        if n and (not draw or draw[-1][1] != d):
            draw.append([t, d])
        if not dog or dog[-1][1:] != [act, dr, tm]:
            dog.append([t, act, dr, tm])
    return {"signature": j["signature"], "horizon": horizon, "draw0": index(rows[0][3]),
            "vis": vis, "draw": draw, "dog": dog}


def whistle_job(emu, j):
    """C-right press(es) after READY (each held 2 polls), then record what follows the LAST press.

    j: signature, state, rungs, presses [poll, ...] (or press), post_vi.
    Returns, times in VIs relative to the VI in which the last press is read (t=1):
      handler   VI when handleWhistleForDog runs for the last press (actionState set to 0, FOLLOWING on)
      response  first VI after the handler where the dog's visible pose/facing changes
      vis       [[t0, t1, screen, class, base]] visible runs from the last press on
      events    [[t, draw_index, actionState, direction, following]] dog changes after the last press
      draw_at_press, sig (hash of events from the response on, in absolute draw terms: equal futures share it)
    """
    import hashlib
    from hm64.lcg import MASK, step as lcg_step
    from hm64.sprites import visual_class
    presses = [int(x) for x in (j.get("presses") or [j["press"]])]
    first, last, post = presses[0], presses[-1], int(j.get("post_vi", 600))
    rp, rstate = 0, j["state"]
    for p, path in j.get("rungs", []):
        if rp < p <= first - 2:
            rp, rstate = p, path
    ent = A.ENTITIES + A.ENTITY_DOG * A.ENTITY_SIZE
    emu.set_poll_callback(None)
    emu.clear_schedule()
    sched = []
    for p in presses:
        sched += [(p - rp, ["CR"]), (p - rp + 2, [])]
    emu.schedule_polls(sched, arm_on_load=True)
    emu.load_state(ROOT / rstate)
    rows = []

    def snap(e):
        rows.append((e.polls(), e.u16(ent + 0x54), e.u8(ent + 0x67), e.u32(A.RAND_SEED),
                     e.u8(A.DOG + 0x17), e.u8(A.DOG + 0x18), e.u8(A.DOG + 0x1A), e.u16(A.DOG + 0x1E)))
    rec = emu.add_listener(snap)
    try:
        emu.advance_until(lambda e: e.polls() > last - rp, last - rp + 900)
        k0 = len(rows)
        emu.advance(post)
    finally:
        emu.remove_listener(rec)
        emu.clear_schedule()
    seed0 = rows[k0 - 1][3]
    d = index(seed0)
    draw_at_press, seed = d, seed0
    vis, events, handler, response = [], [], None, None
    last_pose = (rows[k0 - 1][2], visual_class(rows[k0 - 1][1], rows[k0 - 1][2]))
    last_ev = None
    prev_act, prev_fl = rows[k0 - 1][4], rows[k0 - 1][7]
    HANDLER_VI = 41      # whistle animation length: handleWhistleForDog runs 41 VIs after the press [EMU]
    for k in range(k0, len(rows)):
        t = k - k0 + 1
        pol, base, scr, sd, act, dr, tm, fl = rows[k]
        n = 0
        while seed != sd and n < 100000:
            seed = lcg_step(seed) & MASK
            n += 1
        d = d + n if seed == sd else index(sd)
        seed = sd
        cls = visual_class(base, scr)
        if vis and vis[-1][2] == scr and vis[-1][3] == cls:
            vis[-1][1] = t + 1
        else:
            vis.append([t, t + 1, scr, cls, base])
        if handler is None and t >= 20 and fl & 0x10 and not prev_fl & 0x10:
            handler = t                                   # FOLLOWING switched on (a single press)
        prev_fl = fl
        if response is None and t > (handler or HANDLER_VI) and (scr, cls) != last_pose:
            response = t
        prev_act = act
        last_pose = (scr, cls)
        ev = (act, dr, 1 if fl & 0x10 else 0)
        if ev != last_ev:
            events.append([t, d, *ev])
            last_ev = ev
    tail = [e[1:] for e in events if response is not None and e[0] >= response]
    sig = hashlib.sha1(json.dumps(tail).encode()).hexdigest()[:16]
    return {"signature": j["signature"], "presses": presses, "rung": rp, "draw_at_press": draw_at_press,
            "handler": handler or HANDLER_VI, "handler_seen": handler is not None, "response": response, "vis": vis, "events": events, "sig": sig}
