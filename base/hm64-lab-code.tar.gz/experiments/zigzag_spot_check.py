"""Does Jack's pier spot (second cut B) change the dog's line? From a beach-entry state, run cut D then each B to READY,
release the stick, and record (draw index, dog signature hash) every 2 VIs to beach VI `until`; compare the B values
on the VIs after all of them reached READY.
  python3 experiments/zigzag_spot_check.py <beach_entry.st> D B1,B2,... [until_vi]"""
import sys, json, hashlib
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from m64h.core import Emulator
from tools.common import default_rom, default_sram
from hm64 import addresses as A
from hm64.lcg import index
from hm64.zigzag import ZigZagInput, drive, dog_sig
st, D = sys.argv[1], int(sys.argv[2])
Bs = [int(x) for x in sys.argv[3].split(",")]
until = int(sys.argv[4]) if len(sys.argv) > 4 else 2700
res = {}
with Emulator(default_rom(), sram=default_sram()) as emu:
    for B in Bs:
        emu.load_state(st)
        v0 = emu.vi - 1
        inp = ZigZagInput(D=D, B=B, start_stage=5, elapsed=1)
        rec = drive(emu, inp, ready=True, track_wake=True, beach_vi0=v0, max_vi=900)
        seq = {}
        while emu.vi - v0 < until:
            emu.advance(2)
            seq[emu.vi - v0] = (index(emu.u32(A.RAND_SEED)), hashlib.blake2b(dog_sig(emu), digest_size=4).hexdigest())
        res[B] = {"ready": rec["ready"], "wake": rec["wake"], "seq": seq}
start = max(r["ready"]["vi"] for r in res.values() if r["ready"]) + 4
keys = sorted(k for k in res[Bs[0]]["seq"] if k >= start)
first_diff = {}
for B in Bs[1:]:
    d = next((k for k in keys if res[B]["seq"].get(k) != res[Bs[0]]["seq"].get(k)), None)
    first_diff[B] = d
print(json.dumps({"D": D, "ready": {B: res[B]["ready"] for B in Bs}, "wake": {B: res[B]["wake"] for B in Bs},
                  "compare_from_vi": start, "first_diff_vs_B0": first_diff,
                  "draw_at_end": {B: res[B]["seq"][keys[-1]] for B in Bs}}))
