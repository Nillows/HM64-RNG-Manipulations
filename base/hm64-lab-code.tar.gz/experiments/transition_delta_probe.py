"""(2026-11-15) ranch exit -> beach fade timing over every ranch state of a store: EXIT_LEVEL / LEVEL_LOAD / MAIN_GAME
   relative to the beach map change.  python3 experiments/transition_delta_probe.py <store> <SaveRAM>"""
import glob, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / "experiments"))
from m64h.core import Emulator
from tools.common import default_rom
from hm64 import addresses as A
from hm64.zigzag import ZigZagInput, Session, player_xz, MAP_CTRL
store, sram = sys.argv[1], sys.argv[2]
rps = sorted(glob.glob(store + "/r/*.st"))
out = []
with Emulator(default_rom(), sram=sram, mode="fast") as emu:
    for rp in rps:
        m = json.load(open(rp + ".json"))
        inp = ZigZagInput(D=84, B=134, W=0, start_stage=4, stage_start_vi=m["stage_start"])
        ses = Session(emu, inp, load=rp)
        ev, lastx, prevloop, prevx, entry = {}, None, None, None, None
        for _ in range(900):
            emu.advance(1)
            x, z = player_xz(emu)
            lp = emu.u16(A.MAIN_LOOP_INDEX)
            if entry is None and prevx is not None and x != prevx:
                lastx = emu.vi
            if lp != prevloop:
                ev.setdefault(lp, []).append(emu.vi)
            if entry is None and inp.stage == 5:
                entry = emu.vi
            prevloop, prevx = lp, x
            if entry is not None and emu.vi - entry > 80:
                break
        ses.close()
        rel = lambda v: v - entry
        exit6 = [v for v in ev.get(6, []) if v < entry][-1]
        load5 = [v for v in ev.get(5, []) if v > entry][0]
        main1 = [v for v in ev.get(1, []) if v > entry][0]
        lx = max(v for v in [lastx] if v is not None)
        out.append((Path(rp).stem[:8], rel(lx), rel(exit6), rel(load5), rel(main1)))
for o in out: print(o)
print("exit6 rel set", sorted({o[2] for o in out}), "load5", sorted({o[3] for o in out}), "main1", sorted({o[4] for o in out}))
