"""Dog-watch readability ablation (2026-11-16): which readability limit costs the most? python3 -I experiments/dogwatch_ablate.py RESULTS_DIR (an observe-preset folder)."""
import sys, numpy as np
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
import dogwatch_report as R
out = sys.argv[1]
lines, obs = R.load(out)
vs = R.variants(lines, obs)
obs = {k: o for k, o in obs.items() if k in {v[0] for v in vs}}
for name, rd, lv in [("thomas (readable S/N/E, long>=60)", {0,4,5,6,7}, 60), ("readable facings, any length>=12", {0,4,5,6,7}, 12),
                     ("all facings, long>=60", set(range(8)), 60), ("all facings, long>=30", set(range(8)), 30),
                     ("readable + SW, long>=60", {0,1,4,5,6,7}, 60)]:
    R.READABLE, R.LONG_VI = rd, lv
    row = []
    for W in (5, 10, 15):
        r = R.simulate(vs, obs, "thomas", W, 1.0, 3.0, np.random.default_rng(1), 300, None)
        row.append(f"{W}s top {100*r['top1']:.0f}% post {100*r['p_true']:.0f}% left {r['left']:.1f} logs {r['logs']:.1f}")
    print(f"{name:<38s} | " + " | ".join(row), flush=True)
