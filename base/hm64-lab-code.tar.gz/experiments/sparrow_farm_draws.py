import sys, json
from pathlib import Path
ROOT = Path("/home/claude/hm64-lab"); sys.path.insert(0, str(ROOT))
from m64h.core import Emulator
from tools.common import default_rom, default_sram
from hm64 import addresses as A
from hm64.lcg import index
from hm64.zigzag import ZigZagInput, Mash, RESET_VI
SLOT = 0x8016FB08
for sp in map(json.loads, sys.argv[1:]):
    with Emulator(default_rom(), sram=default_sram()) as emu:
        inp = ZigZagInput(Mash(sp["T"], sp["h"], sp["ph"], sp["style"]), U=sp["U"], V=sp["V"], C=80, D=86, B=128)
        st = {"farm": None, "end": None}; tr = []
        def w(e):
            inp.sample(e)
            if inp.stage == 2 and st["farm"] is None: st["farm"] = e.vi
            if st["farm"] is not None and inp.stage == 2:
                spar = sum(1 for i in range(7) if e.u8(SLOT + i * 0x1C + 0x15) == 11 and e.u16(SLOT + i * 0x1C + 0x18) & 1)
                tr.append((e.vi - st["farm"], index(e.u32(A.RAND_SEED)), spar))
        emu.schedule_hard_reset(RESET_VI); emu.add_listener(w); emu.set_poll_callback(inp)
        while emu.vi < 4000 and inp.stage < 3: emu.advance(1)
        d0 = dict((t, d) for t, d, s in tr)
        base = d0[0]
        marks = {t: d0[t] - base for t in (60, 98, 100, 104, 120, 167, 200, 250, 300, 350, 400) if t in d0}
        print(sp["name"], "farm VIs", tr[-1][0], "sparrows active", max(s for *_, s in tr), "draws since farm load at t:", marks,
              "total", tr[-1][1] - base)
