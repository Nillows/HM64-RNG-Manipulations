"""Ranch -> beach transition and the dog's activation on the beach, rendered (rice, visual mode; run under xvfb-run).
(2026-11-15) For one route (ranch state + D, B, W): per VI from ranch entry + 40 to the beach READY: mean brightness,
Jack's x/z, the main loop / map values, whether the dog's tile is on the visibility grid; saves frames at chosen VIs
(relative to the beach map change) as PNG.
  xvfb-run -a -s "-screen 0 640x480x24" python3 experiments/beach_transition_shots.py <store> <SaveRAM> <ranch key|first>
      <D> <B> <W> <outdir> <vi,vi,...>"""
import glob
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "experiments"))
from m64h.core import Emulator  # noqa: E402
from tools.common import default_rom  # noqa: E402
from hm64 import addresses as A  # noqa: E402
from hm64.zigzag import ZigZagInput, Session, player_xz, MAP_CTRL  # noqa: E402
import zigzag_jobs as ZJ  # noqa: E402

store, sram, rkey, D, B, W, outdir = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4]), int(sys.argv[5]), \
    int(sys.argv[6]), Path(sys.argv[7])
want = sorted(int(v) for v in sys.argv[8].split(",")) if len(sys.argv) > 8 and sys.argv[8] else []
outdir.mkdir(parents=True, exist_ok=True)
rp = sorted(glob.glob(store + "/r/*.st"))[0] if rkey == "first" else f"{store}/r/{rkey}.st"
m = json.load(open(rp + ".json"))
log, frames = [], {}
with Emulator(default_rom(), sram=sram, mode="visual") as emu:
    emu.capture = True
    inp = ZigZagInput(D=D, B=B, W=W, start_stage=4, stage_start_vi=m["stage_start"])
    ses = Session(emu, inp, load=rp)
    entry = None
    for _ in range(1400):
        emu.advance(1)
        fr = emu._last_frame
        img = emu.frame_image() if fr else None
        lum = sum(img.convert("L").resize((40, 30)).getdata()) / 1200 if img else None
        if entry is None and inp.stage == 5:
            entry = emu.vi
        x, z = player_xz(emu)
        log.append({"vi": emu.vi, "lum": None if lum is None else round(lum, 2), "x": round(x, 1), "z": round(z, 1),
                    "map": emu.u16(MAP_CTRL), "stage": inp.stage, "dogvis": ZJ.dog_visible(emu),
                    "loop": emu.u16(A.MAIN_LOOP_INDEX), "img": img})
        if entry is not None and emu.vi - entry > 360:
            break
    ses.close()
for r in log:
    r["rel"] = r["vi"] - entry
    if r["rel"] in want and r["img"] is not None:
        p = outdir / f"vi{r['rel']:+04d}.png"
        r["img"].save(p)
        frames[r["rel"]] = str(p)
for r in log:
    r.pop("img")
(outdir / "log.json").write_text(json.dumps({"ranch": Path(rp).stem, "D": D, "B": B, "W": W, "log": log}))
print("saved", sorted(frames))
