"""Drive the legacy route (Spring 9 save) to the first VI of the house map and save a state there (house geometry only).
  python3 experiments/house_entry_state.py <out.st>"""
import sys, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from m64h.core import Emulator
from tools.common import default_rom, default_sram
from hm64 import route as R
from hm64 import addresses as A
ent = A.ENTITIES + A.ENTITY_PLAYER * A.ENTITY_SIZE
case = R.RouteCase()
route = R.RouteInput(case)
with Emulator(default_rom(), sram=default_sram()) as emu:
    emu.schedule_hard_reset(case.reset_at_callback + 1)
    emu.add_listener(route.sample_map)
    emu.set_poll_callback(route)
    while emu.vi < 4000 and route.stage < 1:
        emu.advance(1)
    vi = emu.vi
    emu.set_poll_callback(None)
    emu.remove_listener(route.sample_map)
    emu.release()
    emu.save_state(sys.argv[1])
    print(json.dumps({"house_vi": vi, "poll": route.stage_start, "pos": (emu.f32(ent + 0x28), emu.f32(ent + 0x30))}))
