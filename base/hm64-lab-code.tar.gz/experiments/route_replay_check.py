"""
Experiment: does this lab reproduce the legacy measured cohort?

Replays a fixed, stratified sample of routes from
data/routes/ROUTE_TO_CHECKPOINT_LINKS.csv (36,014 ready routes from the
v27.7g9 Mac export) with RandomizeInterrupt OFF and compares the ready VI and
RNG draw index with what the legacy runs recorded. The legacy runs used
mupen's default RandomizeInterrupt=True (wall-clock-seeded interrupt jitter),
so a mismatch can mean jitter mattered for that route, not that the port is
wrong - the baseline matches exactly at every stage.

  python3 tools/seed_sweep.py experiments/route_replay_check.py --out results/<date>-route-replay/raw.jsonl
Env: HM64_REPLAY_PER_FAMILY (default 12), HM64_REPLAY_SEED (default 7).
"""
import csv
import os
import random

from _base import ROOT
from hm64.route import RouteCase, run_route

LINKS = ROOT / "data" / "routes" / "ROUTE_TO_CHECKPOINT_LINKS.csv"
FRESH_BOOT = True          # each route needs a real power-on


def _family(r):
    if any(int(r[k]) for k in ("menu0", "menu1", "menu2", "menu3")):
        return "menu"
    if int(r["h"]) or int(r["c"]):
        return "travel"
    if int(r["p"]) or int(r["d"]):
        return "interaction"
    return "baseline"


def jobs():
    per = int(os.environ.get("HM64_REPLAY_PER_FAMILY", "12"))
    rng = random.Random(int(os.environ.get("HM64_REPLAY_SEED", "7")))
    fams = {}
    with open(LINKS) as f:
        for r in csv.DictReader(f):
            fams.setdefault(_family(r), []).append(r)
    out = []
    for fam, rows in sorted(fams.items()):
        for r in (rows if fam == "baseline" else rng.sample(rows, min(per, len(rows)))):
            out.append({"label": r["label"], "family": fam, "ready_vi": int(r["ready_vi"]),
                        "draw_index": int(r["draw_index"]),
                        "case": [int(r[k]) for k in ("menu0", "menu1", "menu2", "menu3", "h", "c", "p", "d")]})
    return out


def job(emu, j):
    from hm64.lcg import index
    res = run_route(emu, RouteCase(*j["case"]), max_vi=3600)
    fr = res["stages"].get("fishing_ready")
    lab_vi = fr["vi"] if fr else None
    lab_idx = index(fr["rng"]) if fr else None
    return {"label": j["label"], "family": j["family"], "outcome": res["outcome"],
            "legacy": [j["ready_vi"], j["draw_index"]], "lab": [lab_vi, lab_idx],
            "match": (lab_vi, lab_idx) == (j["ready_vi"], j["draw_index"])}
