"""Farm sparrows on the dog-beach save (HM64_SRAM), per house arrival of a zigzag run's menu stage.
  HM64_SRAM=<dog-beach save> python3 -I experiments/sparrow_probe.py RESULTS_DIR [--farm U,V]

Decomp: startGame -> func_800598E0 (start of the day, before the house map loads) -> randomizeMiscAnimalSpawnVariants:
gMiscAnimals[i].spawnVariant = getRandomNumberInRange(0, 3) for the 7 slots (2 rand() calls each). On a farm map load
spawnWildAnimals: not winter, sunny, 6 <= hour <= 8 -> slot 4 variant 1: sparrows at (-336, 0) and (-368, 32);
variant 2: sparrows at (320, -352) and (288, -352); 0 / 3: none.
gMiscAnimals = 0x8016FB08 (config/us/symbol_addrs.txt, size 0xC4 = 7 x 0x1C); spawnVariant at +0x16, animalType +0x15,
flags +0x18 (u16), coordinates +0x00 (3 x f32), mapIndex +0x0E.

For one menu config per distinct house state in Z1_menus.jsonl: mash to the house load, check the strict stage hash
against the run's, read the 7 spawn variants. With --farm: walk the house (U, V) to the farm merge point (+104 VIs)
and list the misc-animal slots there (type 11 = sparrow), checking the farm hash against Z2_house.jsonl."""
import argparse
import json
import os
import struct
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from m64h.core import Emulator                                    # noqa: E402
from tools.common import default_rom, default_sram                # noqa: E402
from hm64 import addresses as A                                   # noqa: E402
from hm64.lcg import index                                        # noqa: E402
from hm64.zigzag import ZigZagInput, Mash, Session, stage_hash, player_xz, RESET_VI, MASH_FROM, MERGE  # noqa: E402

MISC = 0x8016FB08
SZ = 0x1C
TYPES = {11: "sparrow", 12: "bird", 15: "white butterfly", 16: "ladybug", 0: "player dog"}


def f32(emu, a):
    return struct.unpack(">f", struct.pack(">I", emu.u32(a)))[0]


def slots(emu):
    out = []
    for i in range(7):
        b = MISC + i * SZ
        out.append({"i": i, "type": emu.u8(b + 0x15), "variant": emu.u8(b + 0x16), "flags": emu.u16(b + 0x18),
                    "map": emu.u8(b + 0x0E), "xyz": [round(f32(emu, b + 4 * k), 1) for k in range(3)]})
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("results")
    ap.add_argument("--farm", default="")
    a = ap.parse_args()
    res = Path(a.results)
    z1 = [json.loads(l) for l in (res / "Z1_menus.jsonl").read_text().splitlines() if l.strip()]
    first = {}
    for r in z1:
        for row in r["rows"]:
            if row.get("house") and row["house"] not in first:
                first[row["house"]] = (r["style"], r["T"], r["h"], row["ph"], row["house_vi"], row["draw"])
    z2 = {}
    if a.farm:
        U, V = (int(x) for x in a.farm.split(","))
        for l in (res / "Z2_house.jsonl").read_text().splitlines():
            if l.strip():
                r = json.loads(l)
                for row in r.get("rows", []):
                    if row[0] == U and row[1] == V:
                        z2[r["h"]] = row
    tmp = tempfile.mkdtemp()
    with Emulator(default_rom(), sram=default_sram()) as emu:
        emu.schedule_hard_reset(RESET_VI)
        emu.advance(MASH_FROM)
        s600 = os.path.join(tmp, "s600.st")
        emu.save_state(s600)
        for key, (style, T, h, ph, hvi, draw) in sorted(first.items(), key=lambda kv: (kv[1][4], kv[1][5])):
            inp = ZigZagInput(Mash(T, h, ph, style),
                              U=U if a.farm else 10 ** 6, V=V if a.farm else 0, C=80, D=86, B=126)
            inp.vi = MASH_FROM
            ses = Session(emu, inp, load=s600)
            ok = ses.until_stage(1, max_vi=1600)
            row = {"house": key, "cfg": f"{style} T{T} h{h} ph{ph}", "house_vi_run": hvi, "draw_run": draw}
            if ok:
                row.update(house_vi=emu.vi, draw=index(emu.u32(A.RAND_SEED)), hash_ok=stage_hash(emu) == key,
                           variants=[s["variant"] for s in slots(emu)], hour=emu.u8(A.HOUR))
                if a.farm and ses.until_stage(2, max_vi=900) and ses.until_t(MERGE[2]):
                    fk = stage_hash(emu)
                    exp = z2.get(key)
                    row["farm"] = {"t": inp.t(), "hash_ok": (exp[3] == fk) if exp else None, "jack": player_xz(emu),
                                   "slots": [s for s in slots(emu) if s["flags"] & 1]}
            ses.close()
            print(json.dumps(row), flush=True)


if __name__ == "__main__":
    main()
