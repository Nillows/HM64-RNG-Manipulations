"""(2026-11-15) dog-beach wake vs the first-turn timing D (Jack's x on the back-wall run): wake VI and spot.
   python3 experiments/transition_lateral_probe.py <store> <SaveRAM> <n ranch states> <D,D,...>"""
import glob, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / "experiments"))
from m64h.core import Emulator
from tools.common import default_rom
from hm64.zigzag import ZigZagInput, Session, player_xz
import zigzag_jobs as ZJ
store, sram = sys.argv[1], sys.argv[2]
rps = sorted(glob.glob(store + "/r/*.st"))[:int(sys.argv[3])]
Ds = [int(v) for v in sys.argv[4].split(",")]
with Emulator(default_rom(), sram=sram, mode="fast") as emu:
    for rp in rps:
        m = json.load(open(rp + ".json"))
        for D in Ds:
            inp = ZigZagInput(D=D, B=200, W=0, start_stage=4, stage_start_vi=m["stage_start"])
            ses = Session(emu, inp, load=rp)
            entry, hit, xs = None, None, []
            for _ in range(1300):
                emu.advance(1)
                if entry is None and inp.stage == 5:
                    entry = emu.vi
                if entry is None:
                    continue
                rel = emu.vi - entry
                x, z = player_xz(emu)
                if rel == D + 40:
                    xs.append(round(x, 1))
                if ZJ.dog_visible(emu):
                    hit = (rel, round(x, 1), round(z, 1))
                    break
                if rel > 600:
                    break
            ses.close()
            print(Path(rp).stem[:8], "D", D, "run-x", xs, "dog tile visible at VI", hit and hit[0], "Jack x,z", hit and hit[1:], flush=True)
