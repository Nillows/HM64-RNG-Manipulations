"""Helpers shared by experiment modules (import as `from _base import ...`)."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from hm64 import addresses as A        # noqa: E402
from hm64.lcg import seed_at, index    # noqa: E402


def start_at(emu, state: str, n: int):
    """Load a LOAD anchor and replace the seed with stream position n."""
    info = emu.load_state(ROOT / state if not Path(state).is_absolute() else state)
    emu.w32(A.RAND_SEED, seed_at(n))
    return info


def wait_control(emu, max_vi=600):
    """Advance to the first VI the player can move (cheap check: same VI offset
    as the anchor family; for exactness use hm64.state.control_regained)."""
    from hm64.state import control_regained
    for _ in range(max_vi):
        if control_regained(emu):
            return emu.vi
    raise RuntimeError("no control")
