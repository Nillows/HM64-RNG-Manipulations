"""Which dog path (and offset on the landing stopwatch) does each probe run join, and from when?
  python3 -I experiments/beach_walk_match.py WEBAPP_DATA.json O_observe.jsonl probe1.json [probe2.json ...]"""
import json, glob, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from hm64.lcg import index
D = json.load(open(sys.argv[1]))
reps = {p['rep']: p['id'] for p in D['paths']}
rep_draw = {}
for l in open(sys.argv[2]):
    r = json.loads(l)
    if r.get('signature') in reps:
        H = r['horizon']; arr = [r['draw0']] * (H + 2)
        for t, d in r['draw']:
            if t <= H + 1:
                for i in range(t, H + 2): arr[i] = d
        rep_draw[reps[r['signature']]] = arr
print('rep horizon', len(next(iter(rep_draw.values()))) - 2)
for f in sys.argv[3:]:
    d = json.load(open(f)); wd = [index(s[0]) for s in d['seq']]; n = len(wd)
    found = None
    for i0 in range(0, n - 300, 30):
        for p, rd in rep_draw.items():
            for delta in range(-200, 2000):
                lo, hi = i0, min(n, len(rd) - 1 - delta)
                if hi - lo < 300: continue
                if all(rd[i + delta] == wd[i] for i in range(lo, hi)):
                    found = (i0, p, delta, hi - lo); break
            if found: break
        if found: break
    if found:
        i0, p, delta, span = found
        print(f"{f}: joins dog path {p + 1} from {i0 * 16.53 / 1000:.1f} s after the landing (offset {delta:+d} VI on the landing stopwatch; {span} VI compared)")
    else:
        print(f"{f}: joins none of the 16 paths within {n * 16.53 / 1000:.0f} s")
