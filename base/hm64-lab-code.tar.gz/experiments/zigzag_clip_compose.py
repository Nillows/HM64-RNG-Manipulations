import json, subprocess, shutil, tempfile
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

C = Path("/home/claude/scratch/clips")
OUT = Path("/home/claude/scratch/clips/out"); OUT.mkdir(exist_ok=True)
FB = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 15)
FS = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 13)
GREEN, ORANGE, GREY, RED = (110, 230, 130), (255, 170, 70), (200, 200, 200), (255, 110, 110)


def load(name):
    m = json.loads((C / name / "meta.json").read_text())
    by_t = {}
    for f in m["frames"]:
        if f["stage"] == m["stage"] and f["t"] is not None:
            by_t[f["t"]] = C / name / f"f{f['f']:05d}.png"
    tail = [C / name / f"f{f['f']:05d}.png" for f in m["frames"] if f["stage"] != m["stage"]]
    return m, by_t, tail


def head(img, text, col, sub=""):
    w, h = img.size
    can = Image.new("RGB", (w, h + 40), (12, 12, 16))
    can.paste(img, (0, 40))
    d = ImageDraw.Draw(can)
    d.text((6, 3), text, font=FB, fill=col)
    if sub:
        d.text((6, 21), sub, font=FS, fill=GREY)
    return can


def frame_at(by_t, t):
    ks = [k for k in by_t if k <= t]
    return by_t[max(ks)] if ks else by_t[min(by_t)]


def video(cells, cols, out, t0=0, hold=45):
    """cells: [(name, label, colour, sub)] played in sync by stage time t (from t0); each cell holds its last frame."""
    data = [load(n) for n, *_ in cells]
    tmax = max(max(bt) for _, bt, _ in data)
    tmp = Path(tempfile.mkdtemp(dir="/dev/shm"))
    k = 0
    for t in range(t0 - t0 % 2, tmax + 2 + 2 * hold, 2):
        ims = []
        for (n, lab, col, sub), (m, bt, tail) in zip(cells, data):
            if t <= max(bt):
                p = frame_at(bt, t)
            else:
                extra = (t - max(bt)) // 2 - 1
                p = tail[min(extra, len(tail) - 1)] if tail else bt[max(bt)]
            ims.append(head(Image.open(p).convert("RGB"), lab, col, sub))
        w, h = ims[0].size
        rows = (len(ims) + cols - 1) // cols
        can = Image.new("RGB", (w * cols + 4 * (cols - 1), h * rows + 4 * (rows - 1)), (0, 0, 0))
        for i, im in enumerate(ims):
            can.paste(im, ((i % cols) * (w + 4), (i // cols) * (h + 4)))
        if can.size[0] % 2 or can.size[1] % 2:
            can = can.crop((0, 0, can.size[0] - can.size[0] % 2, can.size[1] - can.size[1] % 2))
        can.save(tmp / f"f{k:05d}.png"); k += 1
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-framerate", "30", "-i", str(tmp / "f%05d.png"),
                    "-c:v", "libx264", "-preset", "veryfast", "-crf", "21", "-pix_fmt", "yuv420p", str(out)], check=True)
    shutil.rmtree(tmp)
    return k


def frame_ge(by_t, t):
    ks = [k for k in by_t if k >= t]
    return by_t[min(ks)] if ks else by_t[max(by_t)]


def sheet(cells, cols, out, title):
    ims = []
    for name, t, lab, col, sub in cells:
        m, bt, tail = load(name)
        ims.append(head(Image.open(frame_ge(bt, t)).convert("RGB"), lab, col, sub))
    w, h = ims[0].size
    rows = (len(ims) + cols - 1) // cols
    can = Image.new("RGB", (w * cols + 6 * (cols - 1), 34 + h * rows + 6 * (rows - 1)), (0, 0, 0))
    ImageDraw.Draw(can).text((8, 8), title, font=FB, fill=(255, 230, 140))
    for i, im in enumerate(ims):
        can.paste(im, ((i % cols) * (w + 6), 34 + (i // cols) * (h + 6)))
    can.save(out, quality=88)


def ready_t(name):
    m = json.loads((C / name / "meta.json").read_text())
    vi = m["ready"] or m["blocked"]
    beach = [f for f in m["frames"] if f["stage"] == 5]
    return next(f["t"] for f in beach if f["vi"] >= vi), [f for f in beach if f["vi"] >= vi][0]["jack"]


# --- side-by-side videos: earliest vs latest, in sync from the screen load
pairs = [
    ("1_house_turn1", "H1e", "H1l", "EARLIEST turn 1: down-left at t=272", "LATEST turn 1: down-left at t=283",
     "2nd turn (down) at t=327 in both", 240),
    ("2_house_turn2", "H2e", "H2l", "EARLIEST turn 2: down at t=316", "LATEST turn 2: down at t=335",
     "1st turn (down-left) at t=276 in both", 240),
    ("3_crossroads", "Ce", "Cl", "EARLIEST cut: down-left at t=72", "LATEST cut: down-left at t=104", "", 0),
    ("4_beach_cut1", "B1e", "B1l", "EARLIEST 1st cut: down-left at t=84", "LATEST 1st cut: down-left at t=94",
     "2nd cut in the middle of the pier window (frame 3) in both", 0),
    ("5_beach_cut2", "P126", "P138", "EARLIEST 2nd cut: down-right at t=212 (frame 1)",
     "LATEST 2nd cut: down-right at t=224 (frame 7)", "1st cut at t=86 in both", 0),
]
for out, a, b, la, lb, sub, t0 in pairs:
    n = video([(a, la, GREEN, sub), (b, lb, ORANGE, sub)], 2, OUT / f"{out}_earliest_vs_latest.mp4", t0)
    print(out, n, "frames")

# --- pier window grid video: too early, frames 1-7, too late
P = [("P124", "TOO EARLY t=210: the dog stops Jack", RED), ("P126", "EARLY  frame 1  t=212", GREEN),
     ("P128", "EARLY  frame 2  t=214", GREEN), ("P130", "MIDDLE frame 3  t=216", (120, 200, 255)),
     ("P132", "MIDDLE frame 4  t=218", (120, 200, 255)), ("P134", "LATE   frame 5  t=220", ORANGE),
     ("P136", "LATE   frame 6  t=222", ORANGE), ("P138", "LATE   frame 7  t=224", ORANGE),
     ("P140", "TOO LATE t=226: the wall stops Jack", RED)]
n = video([(nm, lab, col, "1st cut t=86; 2nd cut (down-right) as labelled") for nm, lab, col in P], 3,
          OUT / "6_pier_window_all_cuts.mp4", 150)
print("pier grid", n)

# --- stills
sheet([("H1e", 272, "House turn 1 EARLIEST (t=272)", GREEN, "the frame Jack turns down-left"),
       ("H1l", 283, "House turn 1 LATEST (t=283)", ORANGE, "the frame Jack turns down-left"),
       ("H2e", 316, "House turn 2 EARLIEST (t=316)", GREEN, "the frame Jack turns down"),
       ("H2l", 335, "House turn 2 LATEST (t=335)", ORANGE, "the frame Jack turns down"),
       ("Ce", 72, "Crossroads EARLIEST (t=72)", GREEN, "the frame Jack turns down-left"),
       ("Cl", 104, "Crossroads LATEST (t=104)", ORANGE, "the frame Jack turns down-left"),
       ("B1e", 84, "Beach 1st cut EARLIEST (t=84)", GREEN, "the frame Jack turns down-left"),
       ("B1l", 94, "Beach 1st cut LATEST (t=94)", ORANGE, "the frame Jack turns down-left"),
       ("P126", 212, "Beach 2nd cut EARLIEST (t=212, frame 1)", GREEN, "the frame Jack turns down-right"),
       ("P138", 224, "Beach 2nd cut LATEST (t=224, frame 7)", ORANGE, "the frame Jack turns down-right")],
      2, OUT / "7_turn_positions_earliest_vs_latest.jpg",
      "Where Jack is on the frame of each turn: earliest (left) vs latest (right) in the fast zone")
cuts = {"P124": 210, "P126": 212, "P128": 214, "P130": 216, "P132": 218, "P134": 220, "P136": 222, "P138": 224, "P140": 226}
sheet([(nm, cuts[nm], lab, col, "the frame Jack turns down-right") for nm, lab, col in P], 3,
      OUT / "8_pier_cut_positions.jpg", "Where Jack turns down-right for each frame of the pier window (1st cut t=86)")
land = []
for nm, lab, col in P:
    t, jk = ready_t(nm)
    land.append((nm, t + 2, lab, col, f"stopped at x {jk[0]:.0f}, z {jk[1]:.1f}" + (" (READY)" if "TOO" not in lab else " (short of the dock)")))
sheet(land, 3, OUT / "9_pier_landing_spots.jpg", "Where Jack stops: dock end (READY) for each pier-cut frame, and the two misses")
print("done")
