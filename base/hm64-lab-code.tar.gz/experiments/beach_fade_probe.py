"""When does the beach fade in, relative to the beach map change (the lab's beach-load VI)? (2026-11-15)
Replays ranch states to the beach with the real renderer (visual mode, rice; run under xvfb-run) and logs the mean
brightness of every rendered frame from 40 VIs before to 100 VIs after the map change, plus Jack's first move.
  xvfb-run -a -s "-screen 0 640x480x24" python3 experiments/beach_fade_probe.py <store> <SaveRAM> <n states> <out.json>"""
import glob
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from m64h.core import Emulator  # noqa: E402
from tools.common import default_rom  # noqa: E402
from hm64.zigzag import ZigZagInput, Session, player_xz  # noqa: E402

store, sram, n, out = sys.argv[1], sys.argv[2], int(sys.argv[3]), sys.argv[4]
res = []
with Emulator(default_rom(), sram=sram, mode="visual") as emu:
    emu.capture = True
    for rp in sorted(glob.glob(store + "/r/*.st"))[:n]:
        m = json.load(open(rp + ".json"))
        inp = ZigZagInput(D=84, B=134, start_stage=4, stage_start_vi=m["stage_start"])
        ses = Session(emu, inp, load=rp)
        log = []
        while inp.stage < 5 and len(log) < 1200:
            emu.advance(1)
            fr = emu._last_frame
            img = emu.frame_image() if fr else None
            lum = sum(img.convert("L").resize((40, 30)).getdata()) / 1200 if img else None
            log.append([emu.vi, lum, fr[3] if fr else None])
        entry = emu.vi
        p0, moved = player_xz(emu), None
        for _ in range(100):
            emu.advance(1)
            fr = emu._last_frame
            img = emu.frame_image() if fr else None
            lum = sum(img.convert("L").resize((40, 30)).getdata()) / 1200 if img else None
            log.append([emu.vi, lum, fr[3] if fr else None])
            p = player_xz(emu)
            if moved is None and p != p0 and emu.vi - entry > 20:
                moved = emu.vi - entry
            p0 = p
        ses.close()
        rel = [[v - entry, None if l is None else round(l, 1), None if fv is None else fv - entry] for v, l, fv in log
               if v - entry >= -40]
        dark = [r for r in rel if r[0] >= -40 and r[1] is not None]
        res.append({"state": Path(rp).stem, "jack_moves": moved, "lum": rel})
        black_start = next((r[0] for r in dark if r[1] < 3), None)
        fade_in = next((r[0] for r in dark if r[0] > (black_start or -40) and r[1] >= 3), None)
        print(Path(rp).stem[:8], "screen black from", black_start, "| first non-black after it:", fade_in,
              "| Jack moves:", moved, "| lum sample:", [(r[0], r[1]) for r in rel if r[0] % 4 == 0 and -20 <= r[0] <= 70])
Path(out).write_text(json.dumps(res))
