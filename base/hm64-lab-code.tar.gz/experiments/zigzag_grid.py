"""Zig-zag route grids on the dog-beach save (HM64_SRAM), one process.
  python3 experiments/zigzag_grid.py boot  <dir> '<json spec>'        cold boot, stage-entry states -> <dir>/s<k>.st
  python3 experiments/zigzag_grid.py house <dir> U_lo:U_hi V_lo:V_hi   from <dir>/s1.st, cut grid -> farm arrival
  python3 experiments/zigzag_grid.py cross <dir> C_lo:C_hi             from <dir>/s3.st -> ranch arrival
  python3 experiments/zigzag_grid.py beach <dir> D_lo:D_hi B_lo:B_hi   from <dir>/s5.st -> wake, READY / blocked
Cut times are polls after the screen's map change. One JSON line per run."""
import sys, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from m64h.core import Emulator
from tools.common import default_rom, default_sram
from hm64.zigzag import ZigZagInput, Mash, drive, RESET_VI


def rng(spec):
    v = [int(x) for x in spec.split(":")]
    return range(v[0], v[1] + 1, v[2] if len(v) > 2 else 1)


mode, d = sys.argv[1], Path(sys.argv[2])
d.mkdir(parents=True, exist_ok=True)
with Emulator(default_rom(), sram=default_sram()) as emu:
    if mode == "boot":
        sp = json.loads(sys.argv[3])
        inp = ZigZagInput(Mash(sp.get("T", 6), sp.get("h", 3), sp.get("ph", 0), sp.get("style", "START>A")),
                          U=sp["U"], V=sp["V"], C=sp["C"], D=sp["D"], B=sp["B"])
        emu.schedule_hard_reset(RESET_VI)
        def save(e, k, rec):
            e.save_state(str(d / f"s{k}.st"))
        rec = drive(emu, inp, ready=True, track_wake=True, on_stage=save, max_vi=6000)
        print(json.dumps(rec))
    elif mode == "house":
        for U in rng(sys.argv[3]):
            for V in rng(sys.argv[4]):
                info = emu.load_state(str(d / "s1.st"))
                v0 = emu.vi
                rec = drive(emu, ZigZagInput(U=U, V=V, start_stage=1, elapsed=1), until_stage=2, max_vi=900)
                s2 = rec["stages"].get(2)
                print(json.dumps({"U": U, "V": V, "farm": s2["vi"] - v0 if s2 else None,
                                  "hash": s2["hash"] if s2 else None, "end": rec["end"]["pos"]}), flush=True)
    elif mode == "cross":
        for C in rng(sys.argv[3]):
            emu.load_state(str(d / "s3.st"))
            v0 = emu.vi
            rec = drive(emu, ZigZagInput(C=C, start_stage=3, elapsed=1), until_stage=4, max_vi=900)
            s4 = rec["stages"].get(4)
            print(json.dumps({"C": C, "ranch": s4["vi"] - v0 if s4 else None, "hash": s4["hash"] if s4 else None,
                              "end": rec["end"]["pos"]}), flush=True)
    elif mode == "beach":
        for D in rng(sys.argv[3]):
            for B in rng(sys.argv[4]):
                emu.load_state(str(d / "s5.st"))
                v0 = emu.vi
                rec = drive(emu, ZigZagInput(D=D, B=B, start_stage=5, elapsed=1), ready=True, track_wake=True,
                            beach_vi0=v0 - 1, max_vi=900)
                r = rec["ready"]
                print(json.dumps({"D": D, "B": B, "wake": rec["wake"], "ready": r,
                                  "end": rec["end"]["pos"]}), flush=True)
