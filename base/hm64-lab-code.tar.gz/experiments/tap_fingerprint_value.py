"""(2026-11-16) Thomas's tap fingerprint: taps at the screen transitions (house load, farm load, ranch load) measure the
farm and ranch legs; with the beach wait W known, how much does that buy at a given tap scatter (the mean reflex delay
is calibrated out; the scatter stays)? Monte Carlo on the lineup data, release-or-hold at a 150 ms cast spread.
  python3 -I experiments/tap_fingerprint_value.py <results/lineup-fast/<label>> [samples]"""
import json, sys, random
from collections import defaultdict
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
import zigzag_report as ZR
out = Path(sys.argv[1]); N = int(sys.argv[2]) if len(sys.argv) > 2 else 1500
rows = lambda p: [json.loads(l) for l in open(out / p) if l.strip()]
house = {x["house"]: x["house_vi"] for r in rows("Z1_menus.jsonl") for x in r["rows"] if x.get("house")}
farm, ranch = defaultdict(set), defaultdict(set)
for r in rows("Z2_house.jsonl"):
    for U, V, rel, key, draw in r["rows"]:
        if rel is not None: farm[r["h"]].add((key, rel))
for r in rows("Z3_cross.jsonl"):
    for C, rel, key, draw in r["rows"]:
        if rel is not None: ranch[r["f"]].add((key, rel))
beach = {r["r"]: r["b"] for r in rows("Z4_ranch.jsonl") if r.get("b")}
legs = {}
for h in house:
    for fk, frel in farm.get(h, ()):
        for rk, rrel in ranch.get(fk, ()):
            b = beach.get(rk)
            if b and (b not in legs or (frel, rrel) < legs[b]): legs[b] = (frel, rrel)
lines = json.loads((out / "zz_lines.json").read_text())
res, _, _ = ZR.cast_results(out)
tab, nat = ZR.line_tables(out, lines, res)
gkey = lambda m: (m.get("W", 0),) + legs.get(m["b"].split("@w")[0], (-1, -1))
gw = defaultdict(float)
for L in lines.values():
    for m in L["members"]:
        if "k_off" in m: gw[gkey(m)] += m["w"]
G = sorted(gw)
taus = None; REL, HOLD, COV = [], [], []
for g in G:
    r = ZR.lucky(lines, tab, sig_vi=150 / 1000 * 60, members_filter=(lambda g_: (lambda m: gkey(m) == g_))(g))["rows"]
    d = {x[0]: x for x in r}
    if taus is None: taus = sorted(d)
    REL.append([d[t][1] if t in d else 0 for t in taus]); HOLD.append([d[t][2] if t in d else 0 for t in taus]); COV.append([d[t][4] if t in d else 0 for t in taus])
REL, HOLD, COV = np.array(REL), np.array(HOLD), np.array(COV)
Wg = np.array([gw[g] for g in G]); Wg /= Wg.sum()
Wv = np.array([g[0] for g in G]); F = np.array([g[1] for g in G], float); Rr = np.array([g[2] for g in G], float)
def decide(post):
    w = post * Wg; c = (w[:, None] * COV).sum(0); tot = w.sum()
    ok = c / tot >= 0.8
    pr = np.where(ok, (w[:, None] * COV * REL).sum(0) / np.maximum(c, 1e-12), -1)
    ph = np.where(ok, (w[:, None] * COV * HOLD).sum(0) / np.maximum(c, 1e-12), -1)
    i, j = int(pr.argmax()), int(ph.argmax())
    return (REL, i) if pr[i] >= ph[j] else (HOLD, j)
rng = np.random.default_rng(7)
vi = 1000 / 60 * 0.9916                                        # ms per VI (the app's 16.5265)
idx = rng.choice(len(G), size=N, p=Wg)
print(f"{out.name}: {len(G)} groups (W, farm leg, ranch leg); farm legs {sorted(set(F.astype(int)))}, ranch legs {sorted(set(Rr.astype(int)))}")
for know_w in (True, False):
    for sd_ms in (0, 10, 20, 35, 60):
        s = sd_ms / vi; acc = 0.0
        for g in idx:
            if s > 0:
                e = rng.normal(0, s, 3); mf = F[g] + e[1] - e[0]; mr = Rr[g] + e[2] - e[1]
                df, dr = mf - F, mr - Rr                       # likelihood with the shared middle tap: cov s^2 [[2,-1],[-1,2]]
                q = (2 * df * df + 2 * df * dr + 2 * dr * dr) / (3 * s * s)
                post = np.exp(-0.5 * (q - q.min()))
            else:
                post = ((F == F[g]) & (Rr == Rr[g])).astype(float)
            if know_w: post = post * (Wv == Wv[g])
            M, t = decide(post)
            acc += M[g, t]
        print(f"  W {'known' if know_w else 'unknown'}, tap scatter {sd_ms:3d} ms: {100 * acc / N:.1f}%")
    acc = 0.0
    for g in idx:
        post = (Wv == Wv[g]).astype(float) if know_w else np.ones(len(G))
        M, t = decide(post); acc += M[g, t]
    print(f"  W {'known' if know_w else 'unknown'}, no route taps: {100 * acc / N:.1f}%")
