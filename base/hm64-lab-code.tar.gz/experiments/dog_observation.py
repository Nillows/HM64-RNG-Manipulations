"""
Experiment: what does the dog visibly do in the first SECONDS after the house
loads, as a function of the RNG stream position n at the load anchor?

This is the "observation model": group n's by identical visible sequences to
see how many bits of RNG state a human can read off the dog.

  python3 tools/seed_sweep.py experiments/dog_observation.py --start 480 --count 64 \
      --out results/dog_obs.jsonl
"""
from _base import start_at
from hm64.observe import DogObserver

STATE = "states/load_diary0.st"
SECONDS = 20
VIS = SECONDS * 60


def job(emu, n):
    start_at(emu, STATE, n)
    obs = DogObserver(emu)
    emu.add_listener(obs)
    try:
        emu.advance(VIS)
    finally:
        emu.remove_listener(obs)
    decisions = [e for e in obs.events if e["kind"] == "decision"]
    return {
        "n": n,
        "visible": obs.visible_sequence(collapse=True),
        "decisions": [(e["t"], e["state"], e["dir"]) for e in decisions],
        "unexplained": sum(e["kind"] == "unexplained" for e in obs.events),
        "end_idx": decisions[-1]["idx"] if decisions else None,
    }
