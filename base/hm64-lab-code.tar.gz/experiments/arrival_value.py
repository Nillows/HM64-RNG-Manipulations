"""What an 'arrival profile' could buy on the lineup data (save 1): beach-load time from power-on per beach state,
RNG draw at the beach, and the best odds if the beach state (and the wait) were known vs the whole mix."""
import json, sys
from collections import defaultdict
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
import zigzag_report as ZR
out = Path(sys.argv[1])
rows = lambda p: [json.loads(l) for l in open(out / p) if l.strip()]
house = {}
for r in rows("Z1_menus.jsonl"):
    for x in r["rows"]:
        if x.get("house"):
            house[x["house"]] = (x["house_vi"], x["draw"])
farm = defaultdict(set)                     # house -> (farm key, rel, draw)
for r in rows("Z2_house.jsonl"):
    for U, V, rel, key, draw in r["rows"]:
        if rel is not None:
            farm[r["h"]].add((key, rel, draw))
ranch = defaultdict(set)
for r in rows("Z3_cross.jsonl"):
    for C, rel, key, draw in r["rows"]:
        if rel is not None:
            ranch[r["f"]].add((key, rel, draw))
beach = {r["r"]: (r["b"], r["beach_rel"], r["draw"]) for r in rows("Z4_ranch.jsonl") if r.get("b")}
lines = json.loads((out / "zz_lines.json").read_text())
bs = {m["b"].split("@w")[0] for L in lines.values() for m in L["members"]}
arr = defaultdict(set)
for h, (hvi, hd) in house.items():
    for fk, frel, fd in farm.get(h, ()):
        for rk, rrel, rd in ranch.get(fk, ()):
            if rk in beach:
                b, brel, bd = beach[rk]
                if b in bs:
                    arr[b].add((hvi, frel, rrel, brel, hvi + frel + rrel + brel, bd))
tot = sorted({t[4] for v in arr.values() for t in v})
print(f"beach states in the lines: {len(bs)}; with a route path: {len(arr)}")
print(f"beach load VI from power-on: {tot[0]}..{tot[-1]} ({len(tot)} values)")
rel = defaultdict(set)
for b, v in arr.items():
    for t in v:
        rel[t[5] - t[4] // 2].add(b)
print("draw at the beach - (VI/2):", sorted((k, len(v)) for k, v in rel.items()))
per_t = defaultdict(set)
for b, v in arr.items():
    for t in v:
        per_t[t[4]].add(b)
print("beach states per beach-load VI:", sorted((t, len(v)) for t, v in per_t.items()))
print("house / farm / ranch / beach legs seen:", sorted({t[0] for v in arr.values() for t in v}), sorted({t[1] for v in arr.values() for t in v}),
      sorted({t[2] for v in arr.values() for t in v}), sorted({t[3] for v in arr.values() for t in v}))
res, _, _ = ZR.cast_results(out)
tab, nat = ZR.line_tables(out, lines, res)
sig = 150 / 1000 * 60
def bestp(flt):
    L_ = ZR.lucky(lines, tab, sig_vi=sig, members_filter=flt)
    r1, r2 = ZR.best(L_["rows"], 1, 0.8), ZR.best(L_["rows"], 2, 0.8)
    return max(r1["p"] if r1 else 0, r2["p"] if r2 else 0), L_["W"]
p_all, W_all = bestp(None)
print(f"\nwhole mix (release or hold, 150 ms): {p_all * 100:.1f}%")
for name, keyf in (("beach-load VI known", lambda m: min(t[4] for t in arr.get(m["b"].split('@w')[0], {(0,0,0,0,-1,0)}))),
                   ("beach state known", lambda m: m["b"].split("@w")[0]),
                   ("wait W known", lambda m: m.get("W", 0)),
                   ("beach state + wait known", lambda m: m["b"]),
                   ("wait + beach-load VI known", lambda m: (m.get("W", 0), min(t[4] for t in arr.get(m["b"].split('@w')[0], {(0,0,0,0,-1,0)})))),
                   ("wait + time house->beach known", lambda m: (m.get("W", 0), min(t[4] - t[0] for t in arr.get(m["b"].split('@w')[0], {(0,0,0,0,-1,0)})))),
                   ("wait + every leg known", lambda m: (m.get("W", 0), min(t[:4] for t in arr.get(m["b"].split('@w')[0], {(0,0,0,0,-1,0)})))),
                   ("wait + legs after the house known", lambda m: (m.get("W", 0), min(t[1:4] for t in arr.get(m["b"].split('@w')[0], {(0,0,0,0,-1,0)}))))):
    groups = defaultdict(float)
    for L in lines.values():
        for m in L["members"]:
            if "k_off" in m:
                groups[keyf(m)] += m["w"]
    acc = 0.0
    for g, w in groups.items():
        p, W = bestp((lambda g_: (lambda m: keyf(m) == g_))(g))
        acc += p * W
    print(f"{name:34s}: {len(groups):4d} groups, weighted best {acc / sum(groups.values()) * 100:.1f}%")
