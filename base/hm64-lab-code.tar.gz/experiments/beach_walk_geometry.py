"""Beach geometry from a saved beach-entry state: play a list of stick legs, record the player's position per VI.
  python3 experiments/beach_walk_geometry.py <entry.st> <legs> [<legs> ...]
legs = "N:5,DR:20,DL:150,DR:0"  (last leg with 0 = held until Jack stands still 6 VIs, max 900 VIs)
Prints one JSON line per legs string: final pos, VIs to the stop, and the path every VI."""
import sys, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from m64h.core import Emulator
from tools.common import default_rom, default_sram
from hm64 import route as R
from hm64 import addresses as A
ent = A.ENTITIES + A.ENTITY_PLAYER * A.ENTITY_SIZE
STICK = {"N": (0, 0), "DR": (80, -80), "DL": (-80, -80), "D": (0, -80), "L": (-80, 0), "R": (80, 0),
         "UL": (-80, 80), "UR": (80, 80), "U": (0, 80)}
st = sys.argv[1]
with Emulator(default_rom(), sram=default_sram()) as emu:
    for spec in sys.argv[2:]:
        emu.load_state(st)
        v0 = emu.vi
        path = []
        def pos():
            return [round(emu.f32(ent + 0x28), 3), round(emu.f32(ent + 0x30), 3)]
        legs = [(n, int(t)) for n, t in (p.split(":") for p in spec.split(","))]
        stop = None
        for i, (n, t) in enumerate(legs):
            x, y = STICK[n]
            emu.set_input(x=x, y=y)
            if t > 0:
                for _ in range(t):
                    emu.advance(1); path.append(pos())
            else:
                still = 0
                for _ in range(900):
                    emu.advance(1); path.append(pos())
                    still = still + 1 if len(path) > 1 and path[-1] == path[-2] else 0
                    if still >= 6:
                        stop = len(path) - 6
                        break
        emu.release()
        print(json.dumps({"legs": spec, "final": path[-1], "stop_vi": stop, "path": path}))
