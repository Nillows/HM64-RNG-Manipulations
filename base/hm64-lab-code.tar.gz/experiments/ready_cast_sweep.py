"""
Experiment: for dock "fishing ready" states, which cast polls (optionally after
whistles) produce the ocean Power Nut, and for which release polls?

Natural plan  : cast at poll c (B down, held), release inside the bite window.
Whistle plan  : C-right at poll w (one or more times), then cast at poll c.
Polls are relative to the ready savestate (0 = first controller read after
it loads). Uses hm64.fishing.solve_cast: find every bite window while B is
held, then branch EVERY release poll across it. Real input only.

Env:
  HM64_READY_STATES  comma list of states (default: every states/ready/*.st)
  HM64_CASTS         "start:stop:step" (default 0:600:2)
  HM64_WHISTLES      ";"-separated whistle plans, each a comma list of polls,
                     e.g. "none;10;10,70" (default "none")
  HM64_MAX_BITES     bite windows to branch per cast (default 1)

  python3 tools/seed_sweep.py experiments/ready_cast_sweep.py --out results/<date>-casts/raw.jsonl
Cost: ~3-6 s per (state, plan, cast) per worker. Pilot first (/sweep does).
Long waits on the dock can trigger the idle nap; see CLAUDE.md (SE wake policy).
"""
import glob
import os

from _base import ROOT
from hm64.fishing import solve_cast, whistle_prefix


def _range(spec):
    a, b, s = (int(x) for x in spec.split(":"))
    return range(a, b, s)


def jobs():
    states = os.environ.get("HM64_READY_STATES")
    states = states.split(",") if states else sorted(
        str(p.relative_to(ROOT)) for p in (ROOT / "states" / "ready").glob("*.st"))
    plans = os.environ.get("HM64_WHISTLES", "none").split(";")
    casts = _range(os.environ.get("HM64_CASTS", "0:600:2"))
    out = []
    for st in states:
        for plan in plans:
            w = [] if plan in ("", "none") else [int(x) for x in plan.split(",")]
            for c in casts:
                if w and c <= max(w) + 2:
                    continue
                out.append({"state": st, "whistles": w, "cast": c})
    return out


def job(emu, j):
    prefix = whistle_prefix(j["whistles"]) if j["whistles"] else ()
    r = solve_cast(emu, ROOT / j["state"], j["cast"], prefix=prefix,
                   max_bites=int(os.environ.get("HM64_MAX_BITES", "1")))
    first = r["bites"][0] if r["bites"] else None
    return {**j, "bite_windows": [b["window"] for b in r["bites"]],
            "nut_releases": r["nut_releases"],
            "first_window_outcomes": "".join(x["outcome"][0] for x in first["releases"]) if first else ""}
