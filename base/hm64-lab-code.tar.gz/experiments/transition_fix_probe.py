"""(2026-11-15) dog-beach wake vs a loose first turn fixed by up-left taps (UL n VIs at beach time a): wake VI and spot.
   python3 experiments/transition_fix_probe.py <store> <SaveRAM>"""
import glob, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / "experiments"))
from m64h.core import Emulator
from tools.common import default_rom
import hm64.zigzag as Z
import zigzag_jobs as ZJ
store, sram = sys.argv[1], sys.argv[2]
rp = sorted(glob.glob(store + "/r/*.st"))[0]
m = json.load(open(rp + ".json"))

class Fix(Z.ZigZagInput):
    """beach: D path, then hold UL for n VIs from stage time a (the 'fix' toward the back wall)"""
    def __init__(self, a, n, **kw):
        super().__init__(**kw); self.a, self.n = a, n
    def _leg(self, t):
        if self.stage == 5 and self.a is not None and self.a <= t < self.a + self.n:
            return "UL"
        return super()._leg(t)

cases = [(84, None, 0), (86, None, 0), (88, None, 0)]
for a in (100, 130, 160, 170, 174, 176, 178):
    cases.append((88, a, 2))
for a in (100, 150, 170):
    cases.append((90, a, 4))
cases += [(92, 120, 6), (96, 120, 10)]
with Emulator(default_rom(), sram=sram, mode="fast") as emu:
    for D, a, n in cases:
        inp = Fix(a, n, D=D, B=200, W=0, start_stage=4, stage_start_vi=m["stage_start"])
        ses = Z.Session(emu, inp, load=rp)
        entry, hit, xz = None, None, None
        for _ in range(1400):
            emu.advance(1)
            if entry is None and inp.stage == 5:
                entry = emu.vi
            if entry is None:
                continue
            rel = emu.vi - entry
            x, z = Z.player_xz(emu)
            if a is not None and rel == a + n + 4:
                xz = (round(x, 1), round(z, 1))
            if ZJ.dog_visible(emu):
                hit = (rel, round(x, 1), round(z, 1))
                break
            if rel > 400:
                break
        ses.close()
        print("D", D, "UL", n, "VIs at", a, "-> x,z after", xz, "| wake VI", hit and hit[0], "at", hit and hit[1:], flush=True)
