"""Same line, different pier spots: cast at the same beach VIs and compare bites (bite 1 and held bite 2).
  python3 experiments/zigzag_spot_casts.py <beach_entry.st> D B1,B2 VI1,VI2,..."""
import sys, json, os, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from m64h.core import Emulator
from tools.common import default_rom, default_sram
from hm64.fishing import eval_cast
from hm64.zigzag import ZigZagInput, drive
st, D = sys.argv[1], int(sys.argv[2])
Bs = [int(x) for x in sys.argv[3].split(",")]
VIs = [int(x) for x in sys.argv[4].split(",")]
tmp = tempfile.mkdtemp(dir="/dev/shm")
out = {}
with Emulator(default_rom(), sram=default_sram()) as emu:
    for B in Bs:
        for V in VIs:
            emu.load_state(st)
            v0 = emu.vi - 1
            drive(emu, ZigZagInput(D=D, B=B, start_stage=5, elapsed=1), ready=True, beach_vi0=v0, max_vi=900)
            emu.set_poll_callback(None)
            emu.advance(V - (emu.vi - v0))
            p = os.path.join(tmp, "c.st"); emu.save_state(p)
            r = eval_cast(emu, p, 2, hold_bites=2, map_window=False, probes=(4, 12), tmpdir=tmp)
            out.setdefault(V, {})[B] = [(b.get("bite_poll"), bool(b.get("nut"))) for b in r.get("bites", [])] + [r["status"]]
print(json.dumps(out))
