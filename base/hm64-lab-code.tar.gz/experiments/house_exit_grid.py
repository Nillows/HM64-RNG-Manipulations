"""House exit from a house-entry state: hold UL from the load for (T0 + u) polls, DL v, then D until the farm map loads.
Prints one JSON line per (W, u, v): VIs from the house map change to the farm map change, and the path checkpoints.
  python3 experiments/house_exit_grid.py <house.st> <T0> W1,W2 u_lo:u_hi:u_step v_lo:v_hi:v_step"""
import sys, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from m64h.core import Emulator
from tools.common import default_rom, default_sram
from hm64 import route as R
from hm64 import addresses as A
ent = A.ENTITIES + A.ENTITY_PLAYER * A.ENTITY_SIZE
st, T0 = sys.argv[1], int(sys.argv[2])
Ws = [int(x) for x in sys.argv[3].split(",")]
ul = [int(x) for x in sys.argv[4].split(":")]
vl = [int(x) for x in sys.argv[5].split(":")]
with Emulator(default_rom(), sram=default_sram()) as emu:
    def pos():
        return (round(emu.f32(ent + 0x28), 2), round(emu.f32(ent + 0x30), 2))
    for W in Ws:
        for u in range(ul[0], ul[1] + 1, ul[2]):
            for v in range(vl[0], vl[1] + 1, vl[2]):
                emu.load_state(st)
                v0 = emu.vi
                if W:
                    emu.release(); emu.advance(T0 + W); emu.set_input(x=-80, y=80); emu.advance(u)
                else:
                    emu.set_input(x=-80, y=80); emu.advance(T0 + u)
                p1 = pos()
                emu.set_input(x=-80, y=-80); emu.advance(v)
                p2 = pos()
                emu.set_input(x=0, y=-80)
                farm = None
                for _ in range(600):
                    emu.advance(1)
                    if emu.u16(R.MAP_CTRL) == R.MAP_FARM:
                        farm = emu.vi - v0
                        break
                emu.release()
                print(json.dumps({"W": W, "u": u, "v": v, "after_UL": p1, "after_DL": p2, "end": pos(), "farm_vi": farm}), flush=True)
