import sys, json, os, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from m64h.core import Emulator
from tools.common import default_rom, default_sram
from hm64 import route as R
from hm64 import addresses as A
ent = A.ENTITIES + A.ENTITY_PLAYER * A.ENTITY_SIZE
case = R.RouteCase()
route = R.RouteInput(case)
rows = []
with Emulator(default_rom(), sram=default_sram()) as emu:
    emu.schedule_hard_reset(case.reset_at_callback + 1)
    emu.add_listener(route.sample_map)
    emu.set_poll_callback(route)
    while emu.vi < 2000 and route.stage < 1:
        emu.advance(1)
    hv = emu.vi; hp = emu.polls()
    emu.set_poll_callback(None)
    emu.remove_listener(route.sample_map)
    emu.advance(250)
    fd, path = tempfile.mkstemp(suffix=".st", dir="/dev/shm"); os.close(fd)
    def pos():
        return (round(emu.f32(ent + 0x28), 3), round(emu.f32(ent + 0x30), 3))
    emu.save_state(path)
    base_vi = emu.vi
    emu.release(); emu.advance(30); neutral = pos()
    for k in range(0, 20):
        emu.load_state(path)
        emu.release()
        if k: emu.advance(k)
        v0 = emu.vi - hv
        emu.set_input(x=0, y=-80); emu.advance(2); emu.release()
        emu.advance(30 - k - 2)
        rows.append([v0, pos() != neutral, pos()])
print(json.dumps({"house_vi": hv, "house_polls_after": hp, "base_vi_after_house": base_vi - hv, "neutral": neutral, "rows": rows}))
