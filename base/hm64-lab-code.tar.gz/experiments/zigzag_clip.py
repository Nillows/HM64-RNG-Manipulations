"""Render ONE screen of a zig-zag route from power-on with the real renderer (rice; run under xvfb-run): every game
frame (2 VIs) from that screen's map change to the next screen (beach: to READY / blocked + 60 VIs), annotated like
zigzag_gif.py, saved as PNG frames + meta.json (per frame: VI, stage time t, Jack's position; route events).
  xvfb-run -a -s "-screen 0 640x480x24" python3 experiments/zigzag_clip.py <out_dir> '<json spec>' <stage> [title]
stage: 1 house, 2 farm, 3 crossroads, 4 ranch, 5 beach. spec: T h ph style U V C D B."""
import sys, json, os, shutil, subprocess, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from PIL import Image, ImageDraw, ImageFont
from m64h.core import Emulator
from tools.common import default_rom, default_sram
from hm64 import addresses as A
from hm64.zigzag import ZigZagInput, Mash, RESET_VI, player_xz, dog_sig, ENT_PLAYER, ENT_DOG

outdir = Path(sys.argv[1]); outdir.mkdir(parents=True, exist_ok=True)
sp = json.loads(sys.argv[2])
STAGE = int(sys.argv[3])
title = sys.argv[4] if len(sys.argv) > 4 else outdir.name
start = 10 ** 9
SCREEN = {0: "menus", 1: "house", 2: "farm", 3: "crossroads", 4: "ranch", 5: "beach"}
FONT = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", 11)
FONTB = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf", 12)
W, H, PH, MW = 320, 240, 78, 170


def decode(v):
    btn = [n for n, m in (("A", 0x80), ("B", 0x40), ("START", 0x10)) if v & m]
    x = (v >> 16) & 0xFF
    y = (v >> 24) & 0xFF
    x = x - 256 if x > 127 else x
    y = y - 256 if y > 127 else y
    d = ("U" if y > 0 else "D" if y < 0 else "") + ("L" if x < 0 else "R" if x > 0 else "")
    return (d or "neutral"), btn


inp = ZigZagInput(Mash(sp["T"], sp["h"], sp["ph"], sp["style"]), U=sp["U"], V=sp["V"], C=sp["C"], D=sp["D"], B=sp["B"])
st = {"last_in": 0, "in_log": [], "prev_desc": None, "events": [], "ready": None, "blocked": None, "still": 0,
      "last_pos": None, "dog0": None, "wake": None, "beach": None, "stop_at": None, "frames": 0, "stage": 0}


TRAIL = []


def to_map(x, z):
    """beach top-down, turned like the game camera (screen down-right = +x, down-left = +z)"""
    u, v = (x - z) * 0.7071, (x + z) * 0.7071
    return W + 8 + (u + 505) * 0.26, 18 + (v + 515) * 0.26


def minimap(d, e, p):
    x0 = W
    d.rectangle([x0, 0, x0 + MW - 1, H + PH - 1], fill=(24, 26, 34))
    d.text((x0 + 4, 2), "beach, top-down" if inp.stage == 5 else "this route", font=FONT, fill=(200, 200, 200))
    if inp.stage != 5:
        lines = ["cuts, VIs after the", "screen loads:", f" house DL {inp.U}", f"       D  {inp.U + inp.V}",
                 f" cross DL {inp.C}", f" beach DL {inp.D}", f"       DR {inp.D + inp.B}",
                 f"mash {60 / sp['T']:.0f}/s ph {sp['ph']}", f" {sp['style']}"]
        for i, t in enumerate(lines):
            d.text((x0 + 4, 30 + 14 * i), t, font=FONT, fill=(170, 170, 190))
        return
    TRAIL.append(p)
    a, b = to_map(-92, 168), to_map(-92, 197)
    d.line([a, b], fill=(120, 255, 140), width=3)
    d.text((b[0] - 40, b[1] + 2), "dock end", font=FONT, fill=(120, 255, 140))
    pts = [to_map(*q) for q in TRAIL]
    if len(pts) > 1:
        d.line(pts, fill=(80, 200, 255), width=1)
    dx, dz = e.f32(ENT_DOG + 0x28), e.f32(ENT_DOG + 0x30)
    cx, cy = to_map(dx, dz)
    box = [to_map(dx + sx * 26, dz + sz * 26) for sx, sz in ((-1, -1), (1, -1), (1, 1), (-1, 1), (-1, -1))]
    d.line(box, fill=(255, 150, 60), width=1)
    d.ellipse([cx - 3, cy - 3, cx + 3, cy + 3], fill=(255, 150, 60))
    jx, jy = to_map(*p)
    d.ellipse([jx - 3, jy - 3, jx + 3, jy + 3], fill=(255, 255, 255))
    dy = e.f32(ENT_DOG + 0x2C)
    d.text((x0 + 4, H + PH - 40), "o dog, box = blocks Jack", font=FONT, fill=(255, 150, 60))
    d.text((x0 + 4, H + PH - 28), f"  (~26 each way) dog y={dy:.0f}", font=FONT, fill=(255, 150, 60))
    d.text((x0 + 4, H + PH - 16), f"  Jack y={e.f32(ENT_PLAYER + 0x2C):.0f} (pier ~172)", font=FONT, fill=(255, 255, 255))


def poll(n):
    v = inp(n)
    st["last_in"] = v
    return v


META = []


def listen(e):
    inp.sample(e)
    vi = e.vi
    desc = decode(st["last_in"])
    if desc != st["prev_desc"]:
        st["in_log"].append((vi, SCREEN[inp.stage], inp.t(), desc[0], "+".join(desc[1]) or "-"))
        st["prev_desc"] = desc
    if inp.stage != st["stage"]:
        st["stage"] = inp.stage
        st["events"].append((vi, f"{SCREEN[inp.stage]} loads"))
        if inp.stage == STAGE:
            global start
            start = vi + (vi % 2)
        elif inp.stage == STAGE + 1 and st["stop_at"] is None:
            st["stop_at"] = vi + 6
        if inp.stage == 5:
            st["beach"] = vi
            st["dog0"] = dog_sig(e)
    p = player_xz(e)
    if inp.stage == 5:
        t = inp.t()
        if st["wake"] is None and st["dog0"] is not None and dog_sig(e) != st["dog0"]:
            st["wake"] = vi
            st["events"].append((vi, "dog wakes (first move)"))
        if t is not None and t == inp.D:
            st["events"].append((vi, "cut 1: down-left"))
        if t is not None and t == inp.D + inp.B:
            st["events"].append((vi, "cut 2: down-right"))
        if t is not None and t > inp.D + inp.B and st["ready"] is None and st["blocked"] is None:
            st["still"] = st["still"] + 1 if p == st["last_pos"] else 0
            if st["still"] >= 4 and p[0] > -100:
                st["ready"] = vi - 4
                inp.released = True
                st["events"].append((vi - 4, "READY (Jack stopped at the dock end)"))
                st["stop_at"] = vi + 90
            elif st["still"] >= 60:
                st["blocked"] = vi - 60
                st["events"].append((vi - 60, "BLOCKED (stopped short of the dock)"))
                st["stop_at"] = vi + 60
    if inp.stage == 1 and inp.U is not None and inp.t() in (inp.U, inp.U + inp.V):
        st["events"].append((vi, "house cut: down-left" if inp.t() == inp.U else "house cut: down"))
    if inp.stage == 3 and inp.C is not None and inp.t() == inp.C:
        st["events"].append((vi, "crossroads cut: down-left"))
    st["last_pos"] = p
    if vi < start or vi % 2 or (inp.stage != STAGE and st["stop_at"] is None):
        return
    try:
        img = e.frame_image().resize((W, H), Image.BILINEAR)
    except Exception:
        return
    can = Image.new("RGB", (W + MW, H + PH), (16, 16, 20))
    can.paste(img, (0, 0))
    d = ImageDraw.Draw(can)
    minimap(d, e, p)
    y0 = H + 3
    t = inp.t()
    d.text((4, y0), f"{title}", font=FONTB, fill=(255, 220, 120))
    d.text((4, y0 + 14), f"VI {vi:5d}  {SCREEN[inp.stage]:<10s} t={'' if t is None else t}", font=FONT, fill=(230, 230, 230))
    dirn, btn = desc
    col = (120, 255, 140) if dirn != "neutral" or btn else (160, 160, 160)
    d.text((4, y0 + 27), f"input: stick {dirn:<7s} buttons {'+'.join(btn) or '-'}", font=FONT, fill=col)
    line = f"Jack ({p[0]:7.1f},{p[1]:6.1f})"
    if inp.stage == 5:
        dx, dz = e.f32(ENT_DOG + 0x28), e.f32(ENT_DOG + 0x30)
        line += f"  dog ({dx:6.1f},{dz:5.1f})"
    d.text((4, y0 + 40), line, font=FONT, fill=(200, 200, 255))
    if inp.stage == 5:
        jc, dc = e.u16(ENT_PLAYER + 0x5C), e.u16(ENT_DOG + 0x58)
        coll = "RAM: Jack is touching the DOG" if jc == e.u16(A.DOG + 0x14) and dc == 0 \
            else f"collision Jack={jc:#x} dog={dc:#x}"
        d.text((4, y0 + 53), coll, font=FONT, fill=(255, 120, 120) if "DOG" in coll else (150, 150, 150))
    ev = [x for x in st["events"] if vi - 40 <= x[0] <= vi]
    if ev:
        d.text((4, y0 + 64), ev[-1][1], font=FONT, fill=(255, 255, 0))
    can.save(outdir / f"f{st['frames']:05d}.png")
    META.append({"f": st["frames"], "vi": vi, "stage": inp.stage, "t": t, "jack": [round(p[0], 1), round(p[1], 1)]})
    st["frames"] += 1


with Emulator(default_rom(), sram=default_sram(), mode="visual") as emu:
    emu.set_poll_callback(poll)
    emu.add_listener(listen)
    emu.schedule_hard_reset(RESET_VI)
    while emu.vi < 6000 and (st["stop_at"] is None or emu.vi < st["stop_at"]):
        emu.advance(1)

(outdir / "meta.json").write_text(json.dumps({"spec": sp, "stage": STAGE, "title": title, "frames": META,
    "events": st["events"], "ready": st["ready"], "blocked": st["blocked"], "wake": st["wake"], "beach": st["beach"]}))
print(json.dumps({"frames": st["frames"], "ready": st["ready"], "blocked": st["blocked"], "out": str(outdir)}))
