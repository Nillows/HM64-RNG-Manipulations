"""
UI lab (2026-11-16): emulator side of tools/uilab.py - what really happens in the game for one attempt of a known
member route (beach state b, first cut D, second cut B, wait W), on the same state store as the zig-zag campaign.

  ui_trace_job   replay the member from its beach state to READY, release, and record what the dog shows every VI
                 (screen facing +0x67, sprite base +0x54, on the visibility grid) for `until` VIs after its READY:
                 the ground truth a runner's dog-watch arrows are generated from.
  ui_cast_job    replay the member to READY and evaluate casts at the given taus (VIs after ITS READY: B first read
                 at READY + tau, the campaign's convention, zz_member_cast_job): every bite up to `bite_until` VIs
                 after READY (bites 1-2 always), one release probe per bite -> [{bite: VIs after READY, nut}].
Both check that the replay reaches READY at the member's recorded ready_rel (VIs after the beach load).
"""
from __future__ import annotations

import os

from _base import A
from hm64.zigzag import ZigZagInput, drive, ENT_DOG
from zigzag_jobs import STORE, _meta, _tmpdir, _cleanup, _bkey, dog_visible


def _to_ready(emu, j):
    real, Wt = _bkey(j["b"])
    bp = STORE / "b" / f"{real}.st"
    m = _meta(bp)
    inp = ZigZagInput(D=int(j["D"]), B=int(j["B"]), start_stage=5, stage_start_vi=m["stage_start"], W=Wt)
    rec = drive(emu, inp, ready=True, beach_vi0=m["entry_vi"], max_vi=900, load=bp)
    emu.set_poll_callback(None)                              # stick released at READY
    r = rec["ready"]
    if not r or not r["pier"]:
        return None, m, "no READY on replay"
    return r["abs_vi"], m, None


def ui_trace_job(emu, j):
    R, m, err = _to_ready(emu, j)
    if err:
        return {"id": j["id"], "error": err}
    until = int(j.get("until", 2400))
    runs = []                                                # [k0, k1, facing, base, visible]
    while True:
        k = emu.vi - R
        if k >= 1:
            cur = (emu.u8(ENT_DOG + 0x67), emu.u16(ENT_DOG + 0x54), bool(dog_visible(emu)))
            if runs and tuple(runs[-1][2:]) == cur and runs[-1][1] == k:
                runs[-1][1] = k + 1
            else:
                runs.append([k, k + 1, cur[0], cur[1], cur[2]])
        if k >= until:
            break
        emu.advance(1)
    return {"id": j["id"], "ready_rel": R - m["entry_vi"], "runs": runs}


def ui_cast_job(emu, j):
    from hm64.fishing import eval_cast
    taus = sorted(set(int(t) for t in j["taus"]))
    tmp = _tmpdir()
    out = []
    try:
        R, m, err = _to_ready(emu, j)
        if err:
            return {"id": j["id"], "error": err}
        k0 = taus[0] - 2
        if emu.vi - R > k0:
            return {"id": j["id"], "error": f"first cast {taus[0]} is before READY+{emu.vi - R + 2}", "ready_rel": R - m["entry_vi"]}
        emu.advance(R + k0 - emu.vi)
        rung = os.path.join(tmp, "rung.st")
        emu.save_state(rung)
        bu = int(j.get("bite_until", 5398))
        for tau in taus:
            r2 = eval_cast(emu, rung, tau - k0, hold_bites=int(j.get("bites_max", 16)), map_window=False, probes=(4, 12),
                           tmpdir=tmp, hold_until=bu - k0, always_bites=2, probes_more=(4,))
            bites = [[None if b.get("bite_poll") is None else b["bite_poll"] + k0, bool(b.get("nut"))]
                     for b in r2.get("bites", [])]
            out.append({"tau": tau, "status": r2["status"], "bites": bites})
    finally:
        emu.set_poll_callback(None)
        _cleanup(tmp)
    return {"id": j["id"], "ready_rel": R - m["entry_vi"], "casts": out}
