"""Cold boot a zig-zag route (fast mode) to the beach merge point, then sweep the second cut B for the given first
cuts D: READY (VIs after power-on and after the beach load, spot) or blocked (where Jack stopped).
  python3 experiments/zigzag_pick_b.py '<json: T h ph style U V C>' D1,D2 B_lo:B_hi"""
import sys, json, os, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from m64h.core import Emulator
from tools.common import default_rom, default_sram
from hm64.zigzag import ZigZagInput, Mash, Session, drive, RESET_VI, MERGE
sp = json.loads(sys.argv[1])
Ds = [int(x) for x in sys.argv[2].split(",")]
blo, bhi = (int(x) for x in sys.argv[3].split(":"))
tmp = tempfile.mkdtemp(dir="/dev/shm")
with Emulator(default_rom(), sram=default_sram()) as emu:
    inp = ZigZagInput(Mash(sp["T"], sp["h"], sp["ph"], sp["style"]), U=sp["U"], V=sp["V"], C=sp["C"], D=10 ** 6, B=0)
    ses = Session(emu, inp)
    emu.schedule_hard_reset(RESET_VI)
    ses.until_stage(5, max_vi=6000)
    beach = inp.stage_start
    ses.until_t(MERGE[5])
    p = os.path.join(tmp, "b.st")
    emu.save_state(p)
    ses.close()
    for D in Ds:
        for B in range(blo, bhi + 1):
            inp2 = ZigZagInput(D=D, B=B, start_stage=5, stage_start_vi=beach)
            rec = drive(emu, inp2, ready=True, beach_vi0=beach, max_vi=700, load=p)
            r = rec["ready"]
            print(json.dumps({"D": D, "B": B, "beach_vi": beach,
                              "ready_abs": r["abs_vi"] if r else None, "ready_rel": r["vi"] if r else None,
                              "spot": r["pos"] if r else None, "end": rec["end"]["pos"]}), flush=True)
