"""Menu mashing model (before the house only). Power-on (+ the lab's hard reset at VI 121) to VI 600, then mash a
button as a square wave (period T VIs, held h VIs, phase ph) until the house map loads. Records the house-map VI and
the RNG draw index there and 40 VIs later, so different mash patterns can be grouped by the state they reach.
  python3 experiments/menu_mash_probe.py <buttons> <periods> <press_len|half> <phases|all>
buttons: START | A | START+A (both together) | START>A (START until the Play menu is live, then A)"""
import sys, json, os, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from m64h.core import Emulator
from tools.common import default_rom, default_sram
from hm64 import route as R
from hm64 import addresses as A
from hm64.lcg import index
MASK = {"START": 0x10, "A": 0x80}
buttons = sys.argv[1]
periods = [int(x) for x in sys.argv[2].split(",")]
press_arg, phase_arg = sys.argv[3], sys.argv[4]
S0_VI = 600
with Emulator(default_rom(), sram=default_sram()) as emu:
    emu.schedule_hard_reset(121)
    emu.advance(S0_VI)
    fd, s0 = tempfile.mkstemp(suffix=".st", dir="/dev/shm"); os.close(fd)
    emu.save_state(s0)
    st = {"vi": 0, "on": False, "play": False, "T": 1, "h": 0, "ph": 0}
    def listen(e):
        st["vi"] = e.vi
        if e.u8(A.TITLE_MODE) == 3:
            st["play"] = True
    def poll(n):
        if not st["on"]:
            return 0
        if ((st["vi"] + st["ph"]) % st["T"]) >= st["h"]:
            return 0
        if buttons == "START+A":
            return MASK["START"] | MASK["A"]
        if buttons == "START>A":
            return MASK["A"] if st["play"] else MASK["START"]
        return MASK[buttons]
    emu.add_listener(listen)
    emu.set_poll_callback(poll)
    for T in periods:
        h = max(1, T // 2) if press_arg == "half" else int(press_arg)
        for ph in (range(T) if phase_arg == "all" else [int(x) for x in phase_arg.split(",")]):
            emu.load_state(s0)
            st.update(vi=emu.vi, on=True, play=False, T=T, h=h, ph=ph)
            house = None
            while emu.vi < 2400:
                emu.advance(1)
                if emu.u16(R.MAP_CTRL) == R.MAP_HOUSE:
                    house = emu.vi
                    break
            st["on"] = False
            out = {"buttons": buttons, "T": T, "h": h, "ph": ph, "house_vi": house}
            if house:
                out["draw_house"] = index(emu.u32(A.RAND_SEED))
                emu.advance(40)
                out["draw_house40"] = index(emu.u32(A.RAND_SEED))
            print(json.dumps(out), flush=True)
