"""
Experiment: from the dog-visible pier state (QuickSave2(1) -> states/qs2.st),
whistle for the dog k times (C-right) and then cast / hold / release B.
Every input is applied at an exact controller poll inside the input plugin,
so this is real input timing - no RAM edits. Outcome per job: nut / fish /
no catch, plus bite poll and RNG index at the end.

Edit GRID below, then:
  python3 tools/seed_sweep.py experiments/qs2_whistle_cast_grid.py --out results/qs2_grid.jsonl

Poll numbering: 0-based from the instant the state finishes loading (verified
8/8 against the recorded QuickSave2 outcomes, tools/regress_qs2.py).
"""
import itertools

from _base import A, ROOT
from hm64.lcg import index
from hm64.observe import DogObserver

STATE = "states/qs2.st"
NUT_BITS = 0x80215EB8
WHISTLE_HOLD = 2          # polls C-right is held per whistle
WHISTLE_GAP = 60          # polls between whistle presses (whistle animation is ~40+ VIs)

# k whistles starting at poll W0, then cast at poll P, release at poll R.
GRID = {
    "k": [0, 1, 2],
    "w0": [20],
    "cast": [424, 440],
    "release": [1634],
}


def jobs():
    keys = list(GRID)
    for combo in itertools.product(*(GRID[k] for k in keys)):
        yield dict(zip(keys, combo))


def schedule_for(j):
    ev = []
    for i in range(j["k"]):
        p = j["w0"] + i * WHISTLE_GAP
        ev += [(p, ["CR"]), (p + WHISTLE_HOLD, [])]
    if ev and j["cast"] <= ev[-1][0]:
        raise ValueError("cast scheduled before the last whistle finished")
    ev += [(j["cast"], ["B"]), (j["release"], [])]
    return ev


def job(emu, j):
    emu.schedule_polls(schedule_for(j))
    emu.load_state(ROOT / STATE)
    obs = DogObserver(emu)
    emu.add_listener(obs)
    bite = None
    try:
        while emu.polls() < j["release"] + 600:
            emu.advance(1)
            if bite is None and emu.u16(A.PLAYER + 0x64) == 22 and emu.u8(A.PLAYER + 0x6A) >= 3:
                bite = emu.polls()
            if emu.u32(NUT_BITS) & 4:
                break
    finally:
        emu.remove_listener(obs)
        emu.clear_schedule()
    held = emu.u8(A.PLAYER + 0x2C)
    nut = bool(emu.u32(NUT_BITS) & 4)
    return {**j, "outcome": "nut" if nut else ("fish" if held in (37, 38, 39) else "no catch"),
            "bite_poll": bite, "end_idx": index(emu.u32(A.RAND_SEED)),
            "dog_visible": obs.visible_sequence()[:12]}
