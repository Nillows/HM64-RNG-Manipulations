"""
Experiment: build the pool of realistic dock "fishing ready" arrival scenarios.

For each route recipe (cold boot -> carry route -> dock, see hm64/route.py):
  1. run it from real power-on, save the ready savestate to states/ready/<label>.st
  2. let the game run with NO input for HORIZON VIs and record the natural
     future: every dog decision (what a human would see) + RNG stream position
  3. hash that future -> "natural signature". Arrivals with the same signature
     are the same scenario as far as the oracle can ever tell them apart over
     that horizon; group them with rng-analyst afterwards.

Recipes: data/routes/50156_TIMING_RECIPES_UNCLASSIFIED.csv (or the measured
ROUTE_TO_CHECKPOINT_LINKS.csv). Pick with env vars:
  HM64_POOL_SOURCE = recipes|links (default links)   HM64_POOL_N (default 48)
  HM64_POOL_SEED (default 1)   HM64_POOL_HORIZON (VIs, default 1800)
  HM64_POOL_LABELS = comma list of exact labels (overrides sampling)

  python3 tools/seed_sweep.py experiments/arrival_pool.py --out results/<date>-arrival-pool/raw.jsonl
Note: standing still long enough triggers the player's idle nap (action 9);
that is part of the natural future and is recorded (player_action column).
"""
import csv
import hashlib
import json
import os
import random

from _base import ROOT, A
from hm64.lcg import index
from hm64.observe import DogObserver
from hm64.route import RouteCase, run_route

FRESH_BOOT = True
ROUTES = ROOT / "data" / "routes"


def _rows():
    src = os.environ.get("HM64_POOL_SOURCE", "links")
    name = "ROUTE_TO_CHECKPOINT_LINKS.csv" if src == "links" else "50156_TIMING_RECIPES_UNCLASSIFIED.csv"
    with open(ROUTES / name) as f:
        return list(csv.DictReader(f))


def jobs():
    rows = _rows()
    want = os.environ.get("HM64_POOL_LABELS")
    if want:
        keep = set(want.split(","))
        rows = [r for r in rows if r["label"] in keep]
    else:
        rng = random.Random(int(os.environ.get("HM64_POOL_SEED", "1")))
        rows = rng.sample(rows, min(int(os.environ.get("HM64_POOL_N", "48")), len(rows)))
    keys = ("menu0", "menu1", "menu2", "menu3", "h", "c", "p", "d") if "menu0" in rows[0] \
        else ("d0", "d1", "d2", "d3", "H", "C", "P", "D")
    return [{"label": r["label"], "case": [int(r[k]) for k in keys]} for r in rows]


def job(emu, j):
    horizon = int(os.environ.get("HM64_POOL_HORIZON", "1800"))
    out_dir = ROOT / "states" / "ready"
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"{j['label']}.st"
    res = run_route(emu, RouteCase(*j["case"]), max_vi=3600, ready_state_path=path)
    if res["outcome"] != "ready":
        return {"label": j["label"], "outcome": res["outcome"]}
    fr = res["stages"]["fishing_ready"]
    obs = DogObserver(emu)
    emu.add_listener(obs)
    traj = []
    emu.add_listener(lambda e: traj.append((e.u32(A.RAND_SEED), e.u16(A.PLAYER + 0x64))))
    emu.advance(horizon)
    decisions = [(e["t"], e["state"], e["dir"]) for e in obs.events if e["kind"] == "decision"]
    sig = hashlib.sha256(json.dumps([decisions, traj]).encode()).hexdigest()[:16]
    naps = [i for i, (_, act) in enumerate(traj) if act == 9]
    return {"label": j["label"], "outcome": "ready", "ready_vi": fr["vi"],
            "draw_index": index(fr["rng"]), "dog_at_ready": [fr["dog_action"], fr["dog_direction"],
                                                             fr["dog_timer"]],
            "state": str(path.relative_to(ROOT)), "natural_signature": sig,
            "visible": obs.visible_sequence()[:20], "decisions": decisions[:60],
            "first_idle_nap_vi": naps[0] if naps else None, "horizon": horizon}
