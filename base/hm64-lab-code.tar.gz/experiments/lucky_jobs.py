"""
Lucky Timer experiment (blind attempts): the runner mashes C-right from READY until the k-th whistle starts,
then casts at a fixed time on a stopwatch started at READY. No observation.

Human input model ("mash, stop at the k-th whistle"):
  C-right press edges every `period` polls (held period/2), the first edge `phase` polls after the arrival's
  READY (the runner is already mashing during the put-down). The game reads C-right once per game frame
  (checkButtonPressed, player.c:1148) and ignores it during the 40-poll whistle animation
  (handleWhistleForDogAnimation, player.c:3653); handleWhistleForDog (animals.c:10488) runs when it ends.
  Input goes quiet as soon as the k-th whistle has started (player action 18 begins).   [DECOMP] [EMU]

Everything is in the representative arrival's polls ("path polls"): an arrival at offset o has its READY at
path poll o, so its mash starts at path poll o + phase.

mash_job        realized whistle starts/handlers + a hash of everything a cast depends on (RNG seed,
                dogInfo, dog entity, player position/facing/action) at every cast-grid poll up to `until`.
                Equal (poll, hash) => identical future => one cast evaluation serves every job that has it.
lucky_cast_job  replays one mash plan to a temporary rung and evaluates a list of casts (bites 1 and 2),
                checking first that the state before each cast has the expected hash.
"""
from __future__ import annotations

import hashlib
import os
import tempfile

from _base import ROOT, A

WHISTLING_FOR_DOG = 18
CAST_AFTER = 46            # a cast < ~44 polls after a whistle press does not start (TECH_REFERENCE)
ENT_DOG = A.ENTITIES + A.ENTITY_DOG * A.ENTITY_SIZE
GLOBAL_SPRITES, SPRITE_SIZE = 0x801FD630, 0x9C    # SpriteObject globalSprites[] (globalSprites.h; stride checked in RAM)


def state_hash(e) -> str:
    h = hashlib.blake2b(digest_size=8)
    h.update(e.read(A.RAND_SEED, 4))
    h.update(e.read(A.DOG, 0x20))                 # dogInfo (actionState, timer, direction, flags, position)
    h.update(e.read(ENT_DOG, A.ENTITY_SIZE))      # dog entity (sprite, animation, facing, coordinates)
    spr = GLOBAL_SPRITES + e.u16(ENT_DOG + 0x52) * SPRITE_SIZE
    h.update(e.read(spr + 0x04, 4))               # dog sprite: current animation data
    h.update(e.read(spr + 0x28, 4))               # frame metadata (count, duration)
    h.update(e.read(spr + 0x90, 12))              # frame, tick counter, audio, palette, counters, flags (cycle end)
    h.update(e.read(A.PLAYER + 0x48, 12))         # player x, y, z
    h.update(e.read(A.PLAYER + 0x64, 8))          # action/animation handler, phase counter, phase
    h.update(e.read(A.PLAYER + 0x6D, 1))          # direction
    return h.hexdigest()


class MashController:
    """C-right edges every `period` polls from `start` until `quiet` is set; SE stay-awake pushes; B from `cast`."""

    def __init__(self, start, period, wake=(), edges=None, quiet_at=None):
        from hm64.fishing import _CR, _SE, WAKE_POLLS
        self.CR, self.SE, self.WP = _CR, _SE, WAKE_POLLS
        self.start, self.period = int(start), int(period)
        self.hold = max(1, self.period // 2)
        self.wake = [int(w) for w in wake]
        self.fixed = None if edges is None else sorted(int(x) for x in edges)
        self.quiet = False
        self.quiet_at = None if quiet_at is None else int(quiet_at)
        self.edges = []

    def __call__(self, n):
        if self.fixed is not None:
            if self.quiet_at is None or n < self.quiet_at:
                for e in self.fixed:
                    if e <= n < e + self.hold:
                        return self.CR
        elif not self.quiet and n >= self.start:
            k, r = divmod(n - self.start, self.period)
            if r < self.hold:
                e = self.start + k * self.period
                if not self.edges or self.edges[-1] != e:
                    self.edges.append(e)
                return self.CR
        for w in self.wake:
            if w <= n < w + self.WP:
                return self.SE
        return 0


def in_grid(p, grid):
    """grid = [[step, end], ...]: poll p is a cast-grid poll if p % step == 0 in the first segment with p < end."""
    for step, end in grid:
        if p < end:
            return p % step == 0
    return False


def mash_job(emu, j):
    """j: path (index), signature, state (path rep READY), start (path poll of the first edge), period,
    whistles (k), until (last cast poll), grid [[step, end], ...], wake; o / w (arrival offset, weight) echoed.
    Returns whistle starts / handler polls (path polls), the edges actually pressed, and hashes on the cast grid."""
    k, until = int(j["whistles"]), int(j["until"])
    grid = j.get("grid", [[4, until + 1]])
    ctl = MashController(j["start"], j["period"], j.get("wake", []))
    emu.set_poll_callback(ctl)
    emu.load_state(ROOT / j["state"])
    starts, handlers, rows = [], [], []
    st = {"prev_act": emu.u16(A.PLAYER + 0x64), "first_cast": None, "quiet_at": None}
    wake = [int(w) for w in j.get("wake", [])]
    near_push = lambda p: any(w <= p < w + 30 for w in wake)     # a runner never pushes right before casting

    def watch(e):
        act = e.u16(A.PLAYER + 0x64)
        if act == WHISTLING_FOR_DOG and st["prev_act"] != WHISTLING_FOR_DOG:
            starts.append(e.polls() - 1)
            if len(starts) >= k and not ctl.quiet:
                ctl.quiet = True
                st["quiet_at"] = e.polls()
        if st["prev_act"] == WHISTLING_FOR_DOG and act != WHISTLING_FOR_DOG:
            handlers.append(e.polls() - 1)
            if len(handlers) >= k and st["first_cast"] is None:
                st["first_cast"] = starts[k - 1] + CAST_AFTER
        st["prev_act"] = act
        fc = st["first_cast"]
        if fc is not None:
            p = e.polls()
            if p >= fc and in_grid(p, grid) and (not rows or rows[-1][0] != p) and not near_push(p):
                rows.append((p, state_hash(e)))
    rec = emu.add_listener(watch)
    try:
        emu.advance_until(lambda e: e.polls() > until, until + 600)
    finally:
        emu.remove_listener(rec)
        emu.set_poll_callback(None)
    edges = [x for x in ctl.edges if not starts or x <= starts[-1]]
    return {"path": j["path"], "signature": j["signature"], "start": j["start"], "period": j["period"],
            "whistles": k, "starts": starts, "handlers": handlers, "edges": edges, "quiet_at": st["quiet_at"],
            "first_cast": st["first_cast"], "o": j.get("o"), "w": j.get("w"),
            "hashes": [[p, h] for p, h in rows if p <= until]}


def lucky_cast_job(emu, j):
    """j: path, signature, state, edges, period, wake, casts [[poll, hash], ...] (one chunk), tag.
    Replays the mash, saves a temporary rung 2 polls before the first cast, evaluates each cast from it."""
    from hm64.fishing import eval_cast
    casts = sorted((int(c), h) for c, h in j["casts"])
    wake = [int(w) for w in j.get("wake", [])]
    p0 = casts[0][0] - 2
    tmp = tempfile.mkdtemp(prefix="lucky-", dir="/dev/shm" if os.path.isdir("/dev/shm") else None)
    rung = os.path.join(tmp, "rung.st")
    out = []
    try:
        emu.set_poll_callback(MashController(0, j["period"], wake, edges=j["edges"], quiet_at=j.get("quiet_at")))
        emu.load_state(ROOT / j["state"])
        emu.advance_until(lambda e: e.polls() >= p0, p0 + 600)
        p0 = emu.polls()
        emu.save_state(rung)
        emu.set_poll_callback(None)
        for n, (c, h) in enumerate(casts):
            ok = None                               # replay check on the first, last and every 8th cast of the chunk
            if n == 0 or n == len(casts) - 1 or n % 8 == 0:
                emu.set_poll_callback(MashController(0, 2, [w - p0 for w in wake if w >= p0 and w + 30 <= c], edges=[]))
                emu.load_state(rung)
                emu.advance_until(lambda e: e.polls() >= c - p0, 600)
                ok = state_hash(emu) == h
            r = eval_cast(emu, rung, c - p0, hold_bites=2, map_window=False, probes=(4, 12),
                          wake=[w - p0 for w in wake if w >= p0 and w + 30 <= c], tmpdir=tmp)
            bites = [{"bite_poll": None if b.get("bite_poll") is None else b["bite_poll"] + p0,
                      "nut": bool(b.get("nut"))} for b in r.get("bites", [])]
            out.append({"cast": c, "hash": h, "hash_ok": ok, "status": r["status"], "bites": bites})
    finally:
        emu.set_poll_callback(None)
        for f in os.listdir(tmp):
            os.remove(os.path.join(tmp, f))
        os.rmdir(tmp)
    return {"path": j["path"], "signature": j["signature"], "tag": j["tag"], "casts": out}
