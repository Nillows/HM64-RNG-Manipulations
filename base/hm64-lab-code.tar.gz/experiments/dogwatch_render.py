"""Dog-watch pilot (2026-11-16, v30 groundwork): render a zig-zag route to READY with the real renderer (rice; run under
xvfb-run), then keep going with no input (Jack stands at the dock end, as during the wait before the cast) and save a
frame every `every` VIs plus the dog's state each VI. Answers: is the dog on screen from the dock end, and how often
does what you can see change?
  xvfb-run -a -s "-screen 0 640x480x24" python3 experiments/dogwatch_render.py <outdir> '<json spec>' [after_vi] [every]
spec: T h ph style U V C D B [W]. SaveRAM from HM64_SRAM. Writes <outdir>/sheet.png (frames after READY, labelled),
<outdir>/dog.json (per VI after READY: base, facing, visual class, actionState, direction, stateTimer, x, z, on the
visibility grid) and prints a summary."""
import sys, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / "experiments"))
from PIL import Image, ImageDraw, ImageFont
from m64h.core import Emulator
from tools.common import default_rom, default_sram
from hm64 import addresses as A
from hm64.zigzag import ZigZagInput, Mash, RESET_VI, player_xz, ENT_DOG
from hm64.sprites import visual_class
from zigzag_jobs import dog_visible

out = Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=True)
sp = json.loads(sys.argv[2])
after = int(sys.argv[3]) if len(sys.argv) > 3 else 1200
every = int(sys.argv[4]) if len(sys.argv) > 4 else 60
FONT = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", 11)
inp = ZigZagInput(Mash(sp["T"], sp["h"], sp["ph"], sp["style"]), U=sp["U"], V=sp["V"], C=sp["C"], D=sp["D"], B=sp["B"],
                  W=sp.get("W", 0))
st = {"ready": None, "still": 0, "last": None, "frames": [], "dog": []}


def poll(n):
    return 0 if inp.released else inp(n)


def listen(e):
    inp.sample(e)
    if inp.stage != 5:
        return
    p = player_xz(e)
    t = inp.t()
    if st["ready"] is None and t is not None and t > inp.D + inp.B:
        st["still"] = st["still"] + 1 if p == st["last"] else 0
        if st["still"] >= 4 and p[0] > -100:
            st["ready"] = e.vi - 4
            inp.released = True
    st["last"] = p
    if st["ready"] is None:
        return
    k = e.vi - st["ready"]
    base, scr = e.u16(ENT_DOG + 0x54), e.u8(ENT_DOG + 0x67)
    st["dog"].append([k, base, scr, visual_class(base, scr), e.u8(A.DOG + 0x17), e.u8(A.DOG + 0x18), e.u8(A.DOG + 0x1A),
                      round(e.f32(ENT_DOG + 0x28), 1), round(e.f32(ENT_DOG + 0x30), 1), bool(dog_visible(e))])
    if k % every == 0:
        try:
            st["frames"].append((k, e.frame_image().resize((320, 240), Image.BILINEAR), st["dog"][-1]))
        except Exception:
            pass


with Emulator(default_rom(), sram=default_sram(), mode="visual") as emu:
    emu.set_poll_callback(poll)
    emu.add_listener(listen)
    emu.schedule_hard_reset(RESET_VI)
    while emu.vi < 9000 and (st["ready"] is None or emu.vi < st["ready"] + after):
        emu.advance(1)

cols = 4
rows = (len(st["frames"]) + cols - 1) // cols
sheet = Image.new("RGB", (cols * 320, rows * 256), (16, 16, 20))
for i, (k, im, d) in enumerate(st["frames"]):
    x, y = (i % cols) * 320, (i // cols) * 256
    sheet.paste(im, (x, y))
    ImageDraw.Draw(sheet).text((x + 4, y + 241), f"READY+{k / 60:.1f}s base {d[1]} face {d[2]} {'on grid' if d[9] else 'OFF grid'}",
                               font=FONT, fill=(255, 230, 120))
sheet.save(out / "sheet.png")
json.dump({"spec": sp, "ready_vi": st["ready"], "cols": ["k", "base", "screen", "class", "act", "dir", "timer", "x", "z", "on_grid"],
           "dog": st["dog"]}, open(out / "dog.json", "w"))
d = st["dog"]
chg = sum(1 for a, b in zip(d, d[1:]) if (a[3], a[2]) != (b[3], b[2]))
print(json.dumps({"ready_vi": st["ready"], "vis_after_ready": len(d), "on_grid_share": round(sum(x[9] for x in d) / max(1, len(d)), 3),
                  "visible_changes": chg, "changes_per_min": round(chg / max(1, len(d)) * 3600, 1),
                  "dog_xz_range": [min(x[7] for x in d), max(x[7] for x in d), min(x[8] for x in d), max(x[8] for x in d)] if d else None}))
