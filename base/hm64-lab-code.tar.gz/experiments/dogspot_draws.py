#!/usr/bin/env python3
"""Dog-spot lab: how many RNG draws the beach adds, beach load -> READY -> 40 s standing at the pier (2026-11-15).

  python3 experiments/dogspot_draws.py <results dir> <state store> <SaveRAM> [members per line] [label]

For every dog line (its representative) and a spread of members per line, replay the route from its ranch state:
hold down-right to the beach load, the two cuts (D, B), READY at the dock end, then stand still (no input, no cast)
for 2,400 VIs. Logged: the draw index at the beach load, at READY, and every 60 VIs after READY; when dogInfo / the dog
entity first change on the beach; whether the dog's entity is loaded at the beach load and at READY.
Without a dog on screen the game draws 1 per game frame (the clock), so 'extra' = draws - game frames is what the dog
adds. Writes <results dir>/dog_draws.json and prints a summary.
"""
from __future__ import annotations

import json
import random
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "experiments"))


def probe_job(emu, j):
    import os
    os.environ["HM64_ZZ_STORE"] = j["store"]
    import zigzag_jobs as ZJ
    from hm64 import addresses as A
    from hm64.lcg import index
    from hm64.zigzag import ZigZagInput, drive, dog_sig
    rp = Path(j["store"]) / "r" / f"{j['r']}.st"
    m = ZJ._meta(rp)
    inp = ZigZagInput(D=j["D"], B=j["B"], start_stage=4, stage_start_vi=m["stage_start"])
    log = {}

    def lis(e):
        log[e.vi] = index(e.u32(A.RAND_SEED))
    h = emu.add_listener(lis)
    try:
        rec = drive(emu, inp, ready=True, max_vi=1400, load=str(rp), blocked_still=60, track_wake=True)
        r = rec["ready"]
        if not r or 5 not in rec["stages"]:
            return {"ok": False, "j": j, "end": rec["end"]}
        load_vi, load_draw = rec["stages"][5]["vi"], rec["stages"][5]["draw"]
        dog_loaded_load = None
        R = load_vi + r["vi"]
        dog_loaded_ready = bool(emu.u16(A.DOG + 0x1E) & 4)
        dog_at_ready = [round(emu.f32(A.DOG + 0x08), 1), round(emu.f32(A.DOG + 0x10), 1)]
        emu.set_poll_callback(None)
        d0 = dog_sig(emu)
        moves = 0
        for _ in range(2400):
            emu.advance(1)
            s = dog_sig(emu)
            if s != d0:
                moves += 1
                d0 = s
        after = [log.get(R + k) for k in range(0, 2401, 60)]
        return {"ok": True, "b": j["b"], "D": j["D"], "B": j["B"], "line": j.get("line"),
                "load_vi": load_vi, "load_draw": load_draw, "ready_rel": r["vi"], "ready_draw": log.get(R),
                "ready_pos": r["pos"], "dog_first_change": rec["wake"]["vi"] if rec["wake"] else None,
                "dog_loaded_ready": dog_loaded_ready, "dog_at_ready": dog_at_ready, "dog_changes_40s": moves,
                "after": after}
    finally:
        emu.remove_listener(h)
        emu.set_poll_callback(None)


def main():
    res_dir, store, sram = Path(sys.argv[1]), sys.argv[2], sys.argv[3]
    per_line = int(sys.argv[4]) if len(sys.argv) > 4 else 4
    label = sys.argv[5] if len(sys.argv) > 5 else res_dir.name
    from m64h.pool import run_jobs
    from tools.common import default_rom
    lines = json.loads((res_dir / "zz_lines.json").read_text())
    b2r = {}
    for l in open(res_dir / "Z4_ranch.jsonl"):
        x = json.loads(l)
        if x.get("b"):
            b2r.setdefault(x["b"], x["r"])
    rnd = random.Random(11)
    jobs = []
    for lid, L in sorted(lines.items(), key=lambda kv: -kv[1]["w"]):
        rep = L["rep"]
        picks = [rep] + rnd.sample([m for m in L["members"] if m is not rep], min(per_line, len(L["members"]) - 1))
        for m in picks:
            if m["b"] in b2r:
                jobs.append({"r": b2r[m["b"]], "b": m["b"], "D": m["D"], "B": m["B"], "line": lid, "store": store,
                             "w": m["w"]})
    import dogspot_draws as me                               # job functions must come from an importable module
    out = [r for r in run_jobs(me.probe_job, jobs, rom=default_rom(), sram=sram, workers=2) if r.get("ok")]
    (res_dir / "dog_draws.json").write_text(json.dumps(out, indent=1))
    print(f"== {label}: {len(out)} routes replayed ({len(lines)} lines)")
    walk = Counter()
    for r in out:
        frames = r["ready_rel"] // 2
        walk[(r["ready_draw"] - r["load_draw"]) - frames] += 1
    print("  beach load -> READY: draws minus game frames (dog extra), count of routes:", sorted(walk.items()))
    for s in (10, 20, 40):
        c = Counter(r["after"][s] - r["after"][0] - s * 30 for r in out if r["after"][s] is not None)
        print(f"  READY -> +{s} s standing: draws minus game frames ({s * 30}), count of routes:", sorted(c.items()))
    print("  READY draw index range:", min(r["ready_draw"] for r in out), "-", max(r["ready_draw"] for r in out),
          "| beach load draw range:", min(r["load_draw"] for r in out), "-", max(r["load_draw"] for r in out))
    print("  dog entity loaded at READY:", Counter(r["dog_loaded_ready"] for r in out),
          "| dog first change after the load (VIs):", sorted(Counter(r["dog_first_change"] for r in out).items())[:8],
          "| dog RAM changes in 40 s:", sorted(Counter(r["dog_changes_40s"] // 100 * 100 for r in out).items()))


if __name__ == "__main__":
    main()
