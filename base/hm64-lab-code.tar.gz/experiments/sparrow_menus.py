"""House arrivals of a zigzag preset's menu stage with the farm-sparrow roll (slot 4 spawnVariant, see sparrow_probe.py).
  HM64_SRAM=<dog-beach save> python3 -I experiments/sparrow_menus.py zigzag-full OUT.jsonl
Every (style, period T, hold, phase) of the preset, mashed from VI 600 to the house load (same driver as zz_menu_job).
One row per config: house VI, draw, strict stage hash, slot-4 variant (1 = pair at the door, 2 = far east pair)."""
import json
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from m64h.core import Emulator                                    # noqa: E402
from tools.common import default_rom, default_sram                # noqa: E402
from tools.zigzag_campaign import PRESETS, hold_of                # noqa: E402
from hm64 import addresses as A                                   # noqa: E402
from hm64.lcg import index                                        # noqa: E402
from hm64.zigzag import ZigZagInput, Mash, Session, stage_hash, RESET_VI, MASH_FROM  # noqa: E402

SLOT4_VARIANT = 0x8016FB08 + 4 * 0x1C + 0x16


def main():
    cfg = PRESETS[sys.argv[1]]
    out = open(sys.argv[2], "w")
    jobs = sorted({(s, T, hold_of(h, T)) for s in cfg["styles"] for T in cfg["periods"] for h in cfg["holds"]})
    tmp = tempfile.mkdtemp()
    with Emulator(default_rom(), sram=default_sram()) as emu:
        emu.schedule_hard_reset(RESET_VI)
        emu.advance(MASH_FROM)
        s600 = os.path.join(tmp, "s600.st")
        emu.save_state(s600)
        for style, T, h in jobs:
            for ph in range(T):
                inp = ZigZagInput(Mash(T, h, ph, style))
                inp.vi = MASH_FROM
                ses = Session(emu, inp, load=s600)
                ok = ses.until_stage(1, max_vi=1600)
                row = {"style": style, "T": T, "h": h, "ph": ph, "house_vi": None}
                if ok:
                    row.update(house_vi=emu.vi, draw=index(emu.u32(A.RAND_SEED)), house=stage_hash(emu),
                               slot4=emu.u8(SLOT4_VARIANT))
                ses.close()
                out.write(json.dumps(row) + "\n")
                out.flush()


if __name__ == "__main__":
    main()
