"""Thomas's 3-leg beach route from a beach-entry state: wait W, DR a, DL b, DR held until Jack stands still.
a and W are counted from the beach map change (Jack first moves ~64 VIs in). One JSON line per (W, a, b):
final position, VI of the stop, whether it is the pier end, and positions at a few checkpoints.
  python3 experiments/beach_zigzag_grid.py <entry.st> W1,W2 a_lo:a_hi:a_step b_lo:b_hi:b_step"""
import sys, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from m64h.core import Emulator
from tools.common import default_rom, default_sram
from hm64 import addresses as A
ent = A.ENTITIES + A.ENTITY_PLAYER * A.ENTITY_SIZE
PIER = (-92.993, 178.257)
st = sys.argv[1]
Ws = [int(x) for x in sys.argv[2].split(",")]
alo, ahi, ast = (int(x) for x in sys.argv[3].split(":"))
blo, bhi, bst = (int(x) for x in sys.argv[4].split(":"))
with Emulator(default_rom(), sram=default_sram()) as emu:
    def pos():
        return (round(emu.f32(ent + 0x28), 3), round(emu.f32(ent + 0x30), 3))
    for W in Ws:
        for a in range(alo, ahi + 1, ast):
            for b in range(blo, bhi + 1, bst):
                emu.load_state(st)
                emu.release(); emu.advance(W)
                emu.set_input(x=80, y=-80); emu.advance(a)
                p_a = pos()
                emu.set_input(x=-80, y=-80); emu.advance(b)
                p_b = pos()
                emu.set_input(x=80, y=-80)
                last, still, n, stop = pos(), 0, 0, None
                while n < 900:
                    emu.advance(1); n += 1
                    p = pos()
                    still = still + 1 if p == last else 0
                    last = p
                    if still >= 6:
                        stop = W + a + b + n - 6
                        break
                emu.release()
                print(json.dumps({"W": W, "a": a, "b": b, "after_DR": p_a, "after_DL": p_b, "final": last,
                                  "stop_vi": stop, "pier": abs(last[0] - PIER[0]) < 0.01 and abs(last[1] - PIER[1]) < 0.01}),
                      flush=True)
