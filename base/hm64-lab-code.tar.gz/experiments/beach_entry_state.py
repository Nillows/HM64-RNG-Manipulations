"""Drive the legacy route (Spring 9 save, dog carried) to the first VI of the beach map and save a state there.
Used only for beach geometry tests (walls, pier lane, timing); not for dog lines.
  python3 experiments/beach_entry_state.py <out.st>"""
import sys, json, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from m64h.core import Emulator
from tools.common import default_rom, default_sram
from hm64 import route as R
from hm64 import addresses as A
ent = A.ENTITIES + A.ENTITY_PLAYER * A.ENTITY_SIZE
case = R.RouteCase()
route = R.RouteInput(case)
t0 = time.time()
with Emulator(default_rom(), sram=default_sram()) as emu:
    emu.schedule_hard_reset(case.reset_at_callback + 1)
    emu.add_listener(route.sample_map)
    emu.set_poll_callback(route)
    while emu.vi < 4000 and route.stage < 5:
        emu.advance(1)
    vi = emu.vi
    emu.set_poll_callback(None)
    emu.remove_listener(route.sample_map)
    emu.release()
    pos = (emu.f32(ent + 0x28), emu.f32(ent + 0x30))
    emu.save_state(sys.argv[1])
print(json.dumps({"beach_vi": vi, "pos": pos, "secs": round(time.time() - t0, 1)}))
