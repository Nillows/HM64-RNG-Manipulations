"""
Recast pilot (2026-11-20, Thomas): what is known about the dog and the random numbers AFTER a cast has ended, and what
a second cast from there is worth. Thomas: "i wonder if there is a way to continue entering dog behaviour to get back on
track and get another attempt ... with an unknown extra time in cast variable. rng draws are different when casting".

Game facts [DECOMP src/game/player.c]:
  handleFishingAction      phase 2 (float out, B held): one getRandomNumberInRange(0, 400) per game update; 0 = a bite
                           (phase 3 -> 4 -> 5 -> back to 1 / 2 while B stays down). B let go in phase 3..5 -> 6 (catch),
                           in any other phase -> 8 (line in, nothing). No draw in phases 1, 3-9.
  handleFishingRodAnimation phase 7: the fish roll, then the ocean Nut roll; the fish becomes the HELD ITEM.
  with an item in hand     B does nothing (tool use needs gPlayer.heldItem == 0). Hands are emptied by A (throw / drop in
                           the water), C-up (rucksack, when it has room) or C-down (eat).
So after a cast two things can have happened: an EMPTY release (between bites) at some frame, or a CATCH at a bite.
Sandbox probe (stand-in save, one line): after a catch the random numbers and the dog are the same whether the fish is
thrown, stored or eaten, early or late, and whether B came up 4 or 14 polls into the bite; after an empty release they
differ from one release frame to the next. This pilot measures both at scale and what recasts are worth.

Two jobs per (dog line, cast frame k); both replay the line from its stored beach state like fullday_jobs:

  rc_rel_job   hold B from k (one unbroken run) for `hold` VIs and to the 2nd bite; then
               - EMPTY releases: two blocks of `dense` consecutive game frames (2 s and 10 s after the float lands), two
                 odd VI labels, and four single ones; each followed `post` VIs with no input: the dog, when Jack can act
                 again, and the dog-line hash (RNG + dog) every 30 VIs;
               - CATCHES at bites 1-3: B up 4 / 14 polls into the bite and the fish left in hand, thrown early / late (A),
                 stored (C-up), eaten (C-down); the same recordings.
  rc_src_job   one source state (bite i caught and the fish thrown at once | empty release `dr` VIs after the float
               landed) and from it `n` second casts, one per `step` VIs from the first frame Jack can cast, each held to
               its 2nd bite with the release at every bite (fullday_jobs._one_cast): Nut / fish. For a catch source also
               6 second casts after STORING the fish instead (must give the same bites).

Labels are VIs after the line's READY, as everywhere in the full-day lab.
"""
from __future__ import annotations

import os
import time

from _base import ROOT, A  # noqa: F401
from hm64.fishing import FISHING, FISH, NUT_BITS, _B, _enc
from hm64.zigzag import cast_hash, line_hash
import fullday_jobs as FJ

BTN = {"A": _enc(["A"]), "CU": _enc(["CU"]), "CD": _enc(["CD"])}
HASH_EVERY = 30
HOLD_CAP = 5400                  # a hold that has not shown two bites 90 s after the cast is given up
VARIANTS = [                     # (B up this many polls into the bite, button, VIs after the bite)
    (4, None, 0), (14, None, 0), (4, "A", 60), (4, "A", 240), (4, "CU", 120), (4, "CD", 90)]
THROW_AT = 60                    # source of the recasts: the fish thrown 60 VIs after the bite (in hand from +56)
SRC_FREE = 84                    # ... Jack can cast again about then (probe: idle 14 VIs after the throw); the job waits for it
ALT_AT, ALT_FREE = 60, 104       # the same with the fish stored (C-up): idle ~34 VIs after the press
EMPTY_FREE = 40                  # empty release: idle 36 VIs after B comes up


def _pl(e):
    return e.u16(A.PLAYER + 0x64), e.u8(A.PLAYER + 0x6A), e.u8(A.PLAYER + 0x2C)


def _hold(emu, rung, k0, k, R, ref, tmp, hold, plan):
    """B from label k, one unbroken run. `plan(p2)` -> labels at which a state is wanted (called once, when the float
    lands at label p2). Returns {p2, bites [[label, file]], ck {label: file}, end, fail}."""
    st = {"p2": None, "want": set(), "inw": False, "end": None, "hash": None}
    bites, ck = [], {}
    w = FJ._Watch(R, ref)

    def watch(e):
        w(e)
        if e.vi - R == k:
            st["hash"] = cast_hash(e)

    def stop(e):
        kk = e.vi - R
        if w.fail:
            st["end"] = "beach check: " + w.fail[1]
            return True
        a, ph, _ = _pl(e)
        if a != FISHING:
            if kk > k + 60:
                st["end"] = f"not fishing at +{kk - k} (action {a})"
                return True
            return False
        if st["p2"] is None and ph == 2:
            st["p2"] = kk
            st["want"] = set(plan(kk))
            st["last"] = max(list(st["want"]) + [k + hold])
        inw = 3 <= ph <= 5
        new = inw and not st["inw"]
        st["inw"] = inw
        if new or kk in st["want"]:
            st["new"] = new
            return True
        if st["p2"] is not None and kk > st["last"] and (len(bites) >= 2 or kk > k + HOLD_CAP):
            st["end"] = "done"
            return True
        return False

    emu.set_poll_callback(FJ.DayController(k0, 0, cast=k, push=False))
    emu.load_state(rung)
    h = emu.add_listener(watch)
    try:
        while True:
            if not emu.advance_until(stop, HOLD_CAP + 400):
                st["end"] = "no end in the time limit"
                break
            if st["end"]:
                break
            lab = emu.vi - R
            f = os.path.join(tmp, f"h{lab}.st")
            emu.save_state(f)
            if st.pop("new", False):
                bites.append([lab, f])
            if lab in st["want"]:
                ck[lab] = f
    finally:
        emu.remove_listener(h)
        emu.set_poll_callback(None)
    return {"p2": st["p2"], "bites": bites, "ck": ck, "end": st["end"], "hash": st["hash"]}


def _follow(emu, ck, q0, cb, R, ref, t0, post):
    """Load `ck` (label q0) with the poll callback cb(q) and run to label t0 + post. Recorded from t0 on: the dog's
    visible runs, Jack's (action, phase, held item) changes, the dog-line hash every HASH_EVERY VIs."""
    w = FJ._Watch(R, ref)
    pl, hs, last = [], [], [None]
    nut0 = [None]

    def watch(e):
        w(e)
        kk = e.vi - R
        if kk < t0:
            return
        cur = _pl(e)
        if cur != last[0]:
            pl.append([kk - t0, cur[0], cur[1], cur[2]])
            last[0] = cur
        if kk > t0 and (kk - t0) % HASH_EVERY == 0:
            hs.append(line_hash(e))

    emu.set_poll_callback(lambda n: cb(q0 + n))
    emu.load_state(ck)
    nut0[0] = emu.u32(NUT_BITS) & 4
    h = emu.add_listener(watch)
    try:
        emu.advance_until(lambda e: w.fail is not None, t0 + post - q0)
    finally:
        emu.remove_listener(h)
        emu.set_poll_callback(None)
    runs, keep, prev = w.runs, [], None
    for i in range(0, len(runs), 2):                      # the run showing at t0, then every change after it
        if runs[i] <= t0:
            prev = [t0, runs[i + 1]]
        else:
            if prev:
                keep += prev
                prev = None
            keep += [runs[i], runs[i + 1]]
    if prev:
        keep += prev
    free = next((p[0] for p in pl[1:] if p[1] == 0 and p[3] == 0), None)        # first moment: idle, hands empty
    if pl and pl[0][1] == 0 and pl[0][3] == 0:
        free = 0
    got = "N" if (emu.u32(NUT_BITS) & 4) and not nut0[0] else next((FJ.KIND.get(p[3], "?") for p in pl if p[3] in FISH), None)
    return {"d": FJ._delta(keep), "pl": pl[:14], "hs": hs, "free": free, "got": got, "fail": w.fail}


def _start(emu, j, tmp):
    R, ref, err = FJ._to_ready(emu, j)
    if err:
        return None, err
    k = int(j["k"])
    k0 = k - 2
    if emu.vi - R > k0:
        return None, f"cast before READY+{emu.vi - R}"
    emu.set_poll_callback(None)
    emu.advance(R + k0 - emu.vi)
    a = emu.u16(A.PLAYER + 0x64)
    if a != 0:
        return None, f"player action {a} at READY+{k0}"
    rung = os.path.join(tmp, "rung.st")
    emu.save_state(rung)
    return (R, ref, k, k0, rung), None


def _before(ck, lab):
    """The latest held-path state at or before label lab - 2: (label, file)."""
    best = max((q for q in ck if q <= lab - 2), default=None)
    return (best, ck[best]) if best is not None else (None, None)


# ---------------------------------------------------------------------------------------------- hold + what follows
def rc_rel_job(emu, j):
    """j: key, b, D, B, dog_at, k, hold (VIs, default 1300), dense (16), post (1200), tag."""
    t_0 = time.time()
    dense, post = int(j.get("dense", 16)), int(j.get("post", 1200))
    tmp = FJ._tmpdir()
    out = {"key": j["key"], "tag": j.get("tag"), "k": int(j["k"])}
    try:
        s, err = _start(emu, j, tmp)
        if err:
            return dict(out, error=err)
        R, ref, k, k0, rung = s

        def labels(p2):
            d1, d2 = p2 + 120, p2 + 600
            lst = [("d1", d1 + 2 * i) for i in range(dense)] + [("d2", d2 + 2 * i) for i in range(dense)]
            lst += [("odd", d1 + 1), ("odd", d1 + 3)] + [("s", p2 + x) for x in (30, 300, 900, 1200)]
            return lst
        rel = []

        def plan(p2):
            rel.extend(labels(p2))
            want = {p2 + 118, p2 + 598} | {r - 2 for g, r in rel if g == "s"}
            return want
        H = _hold(emu, rung, k0, k, R, ref, tmp, int(j.get("hold", 1300)), plan)
        out.update(p2=H["p2"], hold_end=H["end"], cast_hash=H["hash"], bites=[b[0] for b in H["bites"]])
        if H["p2"] is None:
            return dict(out, error=f"the float never landed ({H['end']})")
        ck = dict(H["ck"])
        ck[k0] = rung
        E = []
        for grp, r in rel:
            q0, f = _before(ck, r)
            if f is None:
                continue
            ph = [None]

            def cb(q, r=r):
                return _B if k <= q < r else 0
            res = _follow(emu, f, q0, cb, R, ref, r, post)
            p = res["pl"][0] if res["pl"] else [0, None, None, None]
            E.append({"g": grp, "r": r, "ph": p[2], "free": res["free"], "got": res["got"], "d": res["d"],
                      "hs": res["hs"], "pl": res["pl"][:6]})
        out["empty"] = E
        Bv = []
        for i, (lab, f) in enumerate(H["bites"][:3]):
            vs = []
            for off, btn, at in VARIANTS:
                def cb(q, lab=lab, off=off, btn=btn, at=at):
                    if q < lab + off:
                        return _B
                    if btn and lab + at <= q < lab + at + 2:
                        return BTN[btn]
                    return 0
                res = _follow(emu, f, lab, cb, R, ref, lab, post)
                vs.append({"off": off, "btn": btn, "at": at, "free": res["free"], "got": res["got"], "hs": res["hs"],
                           "pl": res["pl"], "d": res["d"] if btn is None and off == 4 else None})
            Bv.append({"i": i, "lab": lab, "v": vs})
        out["bite"] = Bv
        out["secs"] = round(time.time() - t_0, 1)
        return out
    finally:
        emu.set_poll_callback(None)
        FJ._cleanup(tmp)


# ---------------------------------------------------------------------------------------------- recasts from a source
def rc_src_job(emu, j):
    """j: key, b, D, B, dog_at, k, src {"t": "bite", "i": 0} | {"t": "empty", "dr": 120}, n (360), step (2), tag."""
    t_0 = time.time()
    n, step = int(j.get("n", 360)), int(j.get("step", 2))
    src = j["src"]
    tmp = FJ._tmpdir()
    out = {"key": j["key"], "tag": j.get("tag"), "k": int(j["k"]), "src": src}
    try:
        s, err = _start(emu, j, tmp)
        if err:
            return dict(out, error=err)
        R, ref, k, k0, rung = s
        want_r = [None]

        def plan(p2):
            if src["t"] == "empty":
                want_r[0] = p2 + int(src["dr"])
                return {want_r[0] - 2}
            return set()
        hold = 200 if src["t"] == "bite" else int(src["dr"]) + 80
        H = _hold_until(emu, rung, k0, k, R, ref, tmp, hold, plan, src)
        if H["p2"] is None:
            return dict(out, error=f"the float never landed ({H['end']})")
        out["p2"] = H["p2"]

        def source(btn, at, free_at):
            """-> (label, state file) of the source with Jack free to cast, or (None, why)."""
            if src["t"] == "bite":
                if len(H["bites"]) <= src["i"]:
                    return None, "no such bite"
                lab, f = H["bites"][src["i"]]

                def cb(q):
                    if q < lab + 4:
                        return _B
                    return BTN[btn] if lab + at <= q < lab + at + 2 else 0
                q0, g0 = lab, lab + free_at
            else:
                r = want_r[0]
                cks = dict(H["ck"])
                cks[k0] = rung
                q0, f = _before(cks, r)
                lab = r

                def cb(q):
                    return _B if k <= q < r else 0
                g0 = r + EMPTY_FREE
            emu.set_poll_callback(lambda nn: cb(q0 + nn))
            emu.load_state(f)
            nut0 = emu.u32(NUT_BITS) & 4
            emu.advance(g0 - 30 - q0)                     # then wait for "idle, hands empty" (at most 4 s)
            emu.advance_until(lambda e: _pl(e)[0] == 0 and _pl(e)[2] == 0 and (e.vi - R) % 2 == 0, 240)
            emu.set_poll_callback(None)
            g0 = emu.vi - R
            a, ph, it = _pl(emu)
            if (emu.u32(NUT_BITS) & 4) and not nut0:
                return None, "nut"                        # that bite was the Nut: nothing to recast for
            if a != 0 or it != 0 or g0 % 2:
                return None, f"not free at +{g0 - lab} (action {a}, phase {ph}, item {it})"
            p = os.path.join(tmp, f"src{btn}.st")
            emu.save_state(p)
            return (lab, g0, line_hash(emu)), p
        info, p = source("A", THROW_AT, SRC_FREE)
        if info is None:
            return dict(out, skip=p, secs=round(time.time() - t_0, 1))
        lab, g0, h0 = info
        out.update(lab=lab, g0=g0, h0=h0)
        t_1 = time.time()
        rows = []
        for i in range(n):
            c = g0 + 2 + i * step
            r = FJ._one_cast(emu, p, g0, c, None, R, ref, 0, tmp, c, False)
            rows.append([c, [[b[0], b[1]] for b in r["b"]], r["e"][1] if r.get("e") else None])
        out["rc"] = rows
        out["rc_secs"] = round(time.time() - t_1, 1)
        if src["t"] == "bite":                            # the same second casts after storing the fish instead
            info2, p2 = source("CU", ALT_AT, ALT_FREE)
            if info2 is None:
                out["alt_skip"] = p2
            else:
                alt = []
                for i in range(6):
                    c = info2[1] + 2 + i * 40
                    r = FJ._one_cast(emu, p2, info2[1], c, None, R, ref, 0, tmp, c, False)
                    alt.append([c, [[b[0], b[1]] for b in r["b"]]])
                out["alt"] = alt
        out["secs"] = round(time.time() - t_0, 1)
        return out
    finally:
        emu.set_poll_callback(None)
        FJ._cleanup(tmp)


def _hold_until(emu, rung, k0, k, R, ref, tmp, hold, plan, src):
    """_hold, stopped as soon as the source's state is in hand (a bite source: its bite; an empty one: its label)."""
    need = src["i"] + 1 if src["t"] == "bite" else 0
    H = {"p2": None, "bites": [], "ck": {}, "end": None}
    st = {"inw": False, "want": set()}
    w = FJ._Watch(R, ref)

    def stop(e):
        kk = e.vi - R
        if w.fail:
            H["end"] = "beach check: " + w.fail[1]
            return True
        a, ph, _ = _pl(e)
        if a != FISHING:
            if kk > k + 60:
                H["end"] = f"not fishing at +{kk - k} (action {a})"
                return True
            return False
        if H["p2"] is None and ph == 2:
            H["p2"] = kk
            st["want"] = set(plan(kk))
        inw = 3 <= ph <= 5
        new = inw and not st["inw"]
        st["inw"] = inw
        if new or kk in st["want"]:
            st["new"] = new
            return True
        if kk > k + HOLD_CAP:
            H["end"] = "no such bite in 90 s"
            return True
        return False

    emu.set_poll_callback(FJ.DayController(k0, 0, cast=k, push=False))
    emu.load_state(rung)
    h = emu.add_listener(w)
    try:
        while True:
            if not emu.advance_until(stop, HOLD_CAP + 400) or H["end"]:
                H["end"] = H["end"] or "no end in the time limit"
                break
            lab = emu.vi - R
            f = os.path.join(tmp, f"h{lab}.st")
            emu.save_state(f)
            if st.pop("new", False):
                H["bites"].append([lab, f])
            if lab in st["want"]:
                H["ck"][lab] = f
            if (need and len(H["bites"]) >= need) or (not need and st["want"] and lab >= max(st["want"])):
                H["end"] = "done"
                break
    finally:
        emu.remove_listener(h)
        emu.set_poll_callback(None)
    return H
