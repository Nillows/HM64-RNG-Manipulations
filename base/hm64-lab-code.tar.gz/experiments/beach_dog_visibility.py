"""When would the dog-beach save's sleeping dog (-197.57, 142.43) come onto the visibility grid, for a given beach walk?
Reads mainMap.visibilityGrid (decomp map.h: mainMap 0x8013DC40, grid +0x19E28 [38][42], mapState origin +0x1A608,
mapGrid tile size +0x2C) every VI and tests the dog's tile the way entity.c updateEntities does
(tile = (coord + tileSize/2 + origin) / tileSize). Works from any beach-entry state (geometry/camera only).
  python3 experiments/beach_dog_visibility.py <entry.st> <legs> [<legs> ...]   legs as in beach_walk_geometry.py"""
import sys, json, struct
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from m64h.core import Emulator
from tools.common import default_rom, default_sram
from hm64 import addresses as A
ent = A.ENTITIES + A.ENTITY_PLAYER * A.ENTITY_SIZE
MAINMAP = 0x8013DC40
GRID = MAINMAP + 0x19E28
TSX, TSZ = 0x8013DC6C, 0x8013DC6D
ORX, ORZ = MAINMAP + 0x1A608, MAINMAP + 0x1A608 + 4
DOG = (-197.57, 142.43)
STICK = {"N": (0, 0), "DR": (80, -80), "DL": (-80, -80), "D": (0, -80), "L": (-80, 0), "R": (80, 0)}
st = sys.argv[1]
with Emulator(default_rom(), sram=default_sram()) as emu:
    for spec in sys.argv[2:]:
        emu.load_state(st)
        legs = [(n, int(t)) for n, t in (p.split(":") for p in spec.split(","))]
        seq = []
        for n, t in legs:
            x, y = STICK[n]
            emu.set_input(x=x, y=y)
            for _ in range(t):
                emu.advance(1)
                tsx, tsz = emu.u8(TSX), emu.u8(TSZ)
                ox, oz = emu.f32(ORX), emu.f32(ORZ)
                tx = int((DOG[0] + tsx // 2 + ox) / tsx) if tsx else -1
                tz = int((DOG[1] + tsz // 2 + oz) / tsz) if tsz else -1
                vis = emu.u8(GRID + tz * 42 + tx) if 0 <= tx < 42 and 0 <= tz < 38 else -1
                seq.append((vis, round(emu.f32(ent + 0x28), 1), round(emu.f32(ent + 0x30), 1), tx, tz, tsx, tsz, round(ox, 1), round(oz, 1)))
        emu.release()
        first = next((i + 1 for i, s in enumerate(seq) if s[0] > 0), None)
        print(json.dumps({"legs": spec, "first_visible_vi": first, "at": seq[first - 1] if first else None,
                          "tile_info": seq[-1][3:], "samples": [seq[i] for i in range(0, len(seq), 20)]}))
