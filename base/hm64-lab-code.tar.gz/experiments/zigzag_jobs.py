"""
Preset zigzag (dog-beach save, Thomas's zig-zag route, 2026-11-14): job functions for tools/zigzag_campaign.py.

Stages and merge points (hm64/zigzag.py): each job starts from a stored stage state and writes the next stage's
distinct states to states/zigzag/<stage>/<strict hash>.st (equal strict hash => same future, so one copy runs on).
  menu   cold boot, mash a square wave (style, period T, held h, every phase)        -> house entry   (h/)
  house  up-left from the house load, cut down-left at U, down at U+V              -> farm  +104 VIs (f/)
  cross  farm left held; crossroads left from the load, cut down-left at C          -> ranch +40 VIs  (r/)
  ranch  down-right held                                                            -> beach +40 VIs  (b/)
  beach  down-right, cut down-left at D (the dog wakes during this leg): line key = position-free cast hash
         KEY_AFTER_WAKE VIs after the dog's first move; then cut down-right at D+B for every B -> READY / blocked
  line   one representative (b, D, B) per line key: READY, release, natural path; position-free hash every game
         frame (2 VIs) 4..2398 VIs after READY; a savestate rung every 60 VIs
  cast   casts from the rungs (hold B; bite 1 released; bite 1 held -> bite 2 released; probes +4/+12)
All times are VIs; one poll per VI on these screens (checked: `polls_per_vi` in the line rows).
"""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
from pathlib import Path

from _base import ROOT, A
from hm64.lcg import index
from hm64.zigzag import (ZigZagInput, Mash, Session, stage_hash, cast_hash, line_hash, dog_sig, player_xz, drive,
                         MERGE, KEY_AFTER_WAKE, MASH_FROM, RESET_VI, READY_STILL, MAP_CTRL, map_is, ENT_DOG)

BIG = 10 ** 6
# dog-spot lab: one state store per save (env HM64_ZZ_STORE, set by the runner); default = the zigzag store
STORE = Path(os.environ["HM64_ZZ_STORE"]) if os.environ.get("HM64_ZZ_STORE") else ROOT / "states" / "zigzag"


def _store(kind):
    d = STORE / kind
    d.mkdir(parents=True, exist_ok=True)
    return d


def _save_once(emu, kind, key, meta):
    """Atomically save the current state as states/zigzag/<kind>/<key>.st unless it exists. Returns its path."""
    d = _store(kind)
    final = d / f"{key}.st"
    if not final.exists():
        fd, tmp = tempfile.mkstemp(suffix=".st", dir=str(d))
        os.close(fd)
        emu.save_state(tmp, meta=meta)
        if os.path.exists(tmp + ".json"):
            os.replace(tmp + ".json", str(final) + ".json")
        os.replace(tmp, final)
    return final


def _meta(path):
    import json
    with open(str(path) + ".json") as f:
        return json.load(f)


def _tmpdir():
    return tempfile.mkdtemp(prefix="zz-", dir="/dev/shm" if os.path.isdir("/dev/shm") else None)


def _cleanup(tmp):
    for f in os.listdir(tmp):
        os.remove(os.path.join(tmp, f))
    os.rmdir(tmp)


def _here(emu):
    return {"vi": emu.vi, "draw": index(emu.u32(A.RAND_SEED)), "clock": [emu.u8(A.HOUR), emu.u8(A.MINUTES), emu.u8(A.SECONDS)]}


def _where(emu):
    """where Jack is now (for failure rows): x, z, map, VI."""
    x, z = player_xz(emu)
    return [round(x, 2), round(z, 2), emu.u16(MAP_CTRL), emu.vi]


def _bkey(b):
    """beach key -> (stored beach state key, beach wait W). Lineup lab (2026-11-15): "<key>@w<W>" = the same beach
    state with Jack standing still W VIs longer before his first step (ZigZagInput W)."""
    if "@w" in b:
        k, w = b.split("@w")
        return k, int(w)
    return b, 0


MAINMAP = 0x8013DC40                  # decomp map.h; entity.c updateEntities animates an entity only on a visible tile
VIS_GRID, VIS_TSX, VIS_TSZ = MAINMAP + 0x19E28, 0x8013DC6C, 0x8013DC6D
VIS_ORX, VIS_ORZ = MAINMAP + 0x1A608, MAINMAP + 0x1A60C


def dog_visible(emu):
    """Is the dog's tile on the visibility grid now (camera view quad, map.c checkTileVisible)? Off it, the dog's
    animation is reset every frame, so updateDog never sees an animation cycle end and draws nothing."""
    from hm64.zigzag import ENT_DOG
    tsx, tsz = emu.u8(VIS_TSX), emu.u8(VIS_TSZ)
    if not tsx or not tsz:
        return False
    x, z = emu.f32(ENT_DOG + 0x28), emu.f32(ENT_DOG + 0x30)
    tx = int((x + tsx // 2 + emu.f32(VIS_ORX)) / tsx)
    tz = int((z + tsz // 2 + emu.f32(VIS_ORZ)) / tsz)
    return bool(0 <= tx < 42 and 0 <= tz < 38 and emu.u8(VIS_GRID + tz * 42 + tx))


def _test_dog_poke(emu):
    """SANDBOX TEST ONLY (env HM64_ZZ_TEST_DOG, never set by the runners): overwrite dogInfo at the house entry to
    stand in for a dog-spot save in lab self-tests, e.g. "loc=41" (dog off the route) or "loc=9,x=-150,z=120".
    The real lab reads the dog from the SaveRAM."""
    spec = os.environ.get("HM64_ZZ_TEST_DOG")
    if not spec:
        return
    import struct
    kv = dict(p.split("=") for p in spec.split(","))
    if "loc" in kv:
        emu.w8(A.DOG + 0x16, int(kv["loc"]))
    for k, off in (("x", 0x08), ("y", 0x0C), ("z", 0x10)):
        if k in kv:
            emu.w32(A.DOG + off, struct.unpack(">I", struct.pack(">f", float(kv[k])))[0])


# ------------------------------------------------------------------------------------------------ menus
def zz_menu_job(emu, j):
    """fresh emulator. j: style, T, h, phases (optional). Every phase: mash until the house map loads."""
    T, h, style = int(j["T"]), int(j["h"]), j["style"]
    phases = j.get("phases") or list(range(T))
    tmp = _tmpdir()
    rows = []
    try:
        emu.schedule_hard_reset(RESET_VI)
        emu.advance(MASH_FROM)
        s600 = os.path.join(tmp, "s600.st")
        emu.save_state(s600)
        for ph in phases:
            inp = ZigZagInput(Mash(T, h, ph, style))
            inp.vi = MASH_FROM                           # the load VI's poll sees the same VI as the cold run
            ses = Session(emu, inp, load=s600)
            ok = ses.until_stage(1, max_vi=1600)
            if not ok:
                ses.close()
                rows.append({"ph": ph, "house": None})
                continue
            ss = inp.stage_start
            ses.close()
            _test_dog_poke(emu)
            key = stage_hash(emu)
            here = _here(emu)
            _save_once(emu, "h", key, {"stage": 1, "stage_start": ss, "entry_vi": ss, **here})
            rows.append({"ph": ph, "house": key, "house_vi": here["vi"], "draw": here["draw"]})
    finally:
        _cleanup(tmp)
    return {"style": style, "T": T, "h": h, "rows": rows}


# ------------------------------------------------------------------------------------------------ house
def zz_sparrow_scan_job(emu, j):
    """j: items [[kind, key], ...] of stored states (h house entry, f farm +104). Loads each and reports
    [kind, key, on_expected_map, slot4_roll, live_sparrows]. (A stored state is the snapshot one VI after its key was
    taken, so the key itself cannot be recomputed from the file; the roll and the live sparrows do not change in a VI.)"""
    from hm64.zigzag import sparrow_part, MISC_ANIMALS, MISC_SIZE, MAP_CTRL, MAP_HOUSE, MAP_FARM
    out = []
    for kind, key in j["items"]:
        p = STORE / kind / f"{key}.st"
        if not p.exists():
            out.append([kind, key, None, None, None])
            continue
        emu.load_state(str(p))
        want = MAP_HOUSE if kind == "h" else MAP_FARM
        out.append([kind, key, emu.u16(MAP_CTRL) == want, emu.u8(MISC_ANIMALS + 4 * MISC_SIZE + 0x16),
                    len(sparrow_part(emu)) // MISC_SIZE])
    return {"items": out}


def zz_house_job(emu, j):
    """j: h (house state), Us, Vs. Up-left from the load; cut down-left at U, down at U+V -> farm merge point."""
    hp = STORE / "h" / f"{j['h']}.st"
    m = _meta(hp)
    Us, Vs = sorted(int(u) for u in j["Us"]), sorted(int(v) for v in j["Vs"])
    tmp = _tmpdir()
    rows, fails = [], []
    try:
        ses = Session(emu, ZigZagInput(U=BIG, V=0, start_stage=1, stage_start_vi=m["stage_start"]), load=hp)
        cps = {}
        for U in Us:                                     # up-left prefix checkpoints (t = U-1; resumes at t = U)
            if not ses.until_t(U - 1):
                break
            p = os.path.join(tmp, f"u{U}.st")
            emu.save_state(p)
            cps[U] = p
        ses.close()
        for U in Us:
            if U not in cps:
                continue
            for V in Vs:
                ses = Session(emu, ZigZagInput(U=U, V=V, start_stage=1, stage_start_vi=m["stage_start"]),
                              load=cps[U])
                ok = ses.until_stage(2, max_vi=900)
                if not ok:
                    ses.close()
                    rows.append([U, V, None, None, None])
                    fails.append([U, V] + _where(emu))
                    continue
                entry = emu.vi
                emu.advance(MERGE[2])
                ss = ses.inp.stage_start
                ses.close()
                key = stage_hash(emu)
                here = _here(emu)
                _save_once(emu, "f", key, {"stage": 2, "stage_start": ss, "entry_vi": entry, **here})
                rows.append([U, V, entry - m["entry_vi"], key, here["draw"]])
    finally:
        _cleanup(tmp)
    return {"h": j["h"], "rows": rows, "fails": fails}


# ------------------------------------------------------------------------------------------------ crossroads
def zz_cross_job(emu, j):
    """j: f (farm state), Cs. Farm: left held; crossroads: left from the load, cut down-left at C -> ranch merge."""
    fp = STORE / "f" / f"{j['f']}.st"
    m = _meta(fp)
    Cs = sorted(int(c) for c in j["Cs"])
    tmp = _tmpdir()
    rows, fails, farm_fail = [], [], None
    try:
        ses = Session(emu, ZigZagInput(C=BIG, start_stage=2, stage_start_vi=m["stage_start"]), load=fp)
        ok = ses.until_stage(3, max_vi=1200)
        cross_entry = emu.vi
        cs = ses.inp.stage_start
        if not ok:
            farm_fail = _where(emu)                      # walking left on the farm never reached the crossroads
        cps = {}
        if ok:
            for C in Cs:
                if not ses.until_t(C - 1):
                    break
                p = os.path.join(tmp, f"c{C}.st")
                emu.save_state(p)
                cps[C] = p
        ses.close()
        for C in Cs:
            if C not in cps:
                continue
            ses = Session(emu, ZigZagInput(C=C, start_stage=3, stage_start_vi=cs), load=cps[C])
            ok = ses.until_stage(4, max_vi=900)
            if not ok:
                ses.close()
                rows.append([C, None, None, None])
                fails.append([C] + _where(emu))
                continue
            entry = emu.vi
            emu.advance(MERGE[4])
            ss = ses.inp.stage_start
            ses.close()
            key = stage_hash(emu)
            here = _here(emu)
            _save_once(emu, "r", key, {"stage": 4, "stage_start": ss, "entry_vi": entry, **here})
            rows.append([C, entry - m["entry_vi"], key, here["draw"]])
    finally:
        _cleanup(tmp)
    return {"f": j["f"], "cross_vi": None if farm_fail else cross_entry - m["entry_vi"], "rows": rows, "fails": fails,
            "farm_fail": farm_fail}


# ------------------------------------------------------------------------------------------------ ranch
def zz_ranch_job(emu, j):
    """j: r (ranch state). Down-right held -> beach merge point (entry + 40 VIs)."""
    rp = STORE / "r" / f"{j['r']}.st"
    m = _meta(rp)
    ses = Session(emu, ZigZagInput(D=BIG, B=0, start_stage=4, stage_start_vi=m["stage_start"]), load=rp)
    ok = ses.until_stage(5, max_vi=900)
    if not ok:
        ses.close()
        return {"r": j["r"], "b": None, "fail": _where(emu)}
    entry = emu.vi
    emu.advance(MERGE[5])
    ss = ses.inp.stage_start
    ses.close()
    key = stage_hash(emu)
    here = _here(emu)
    _save_once(emu, "b", key, {"stage": 5, "stage_start": ss, "entry_vi": entry, "dog0": dog_sig(emu).hex(), **here})
    return {"r": j["r"], "b": key, "beach_rel": entry - m["entry_vi"], "draw": here["draw"]}


# ------------------------------------------------------------------------------------------------ beach
def zz_beach_job(emu, j):
    """j: b (beach state), Ds, Bs. For each D: wake + line key; then every B -> READY (VIs after beach entry, spot)
    or blocked (where Jack stopped). Rows: [D, wake_rel, wake_draw, key_off, key, late, [[B, ready_rel, x, z,
    ready_draw] or [B, None, x, z, None], ...]]."""
    bp = STORE / "b" / f"{j['b']}.st"
    m = _meta(bp)
    Ds, Bs = sorted(int(d) for d in j["Ds"]), sorted(int(b) for b in j["Bs"])
    b0 = Bs[0]
    dog0 = bytes.fromhex(m["dog0"])
    entry = m["entry_vi"]
    tmp = _tmpdir()
    rows = []
    try:
        bs = m["stage_start"]
        ses = Session(emu, ZigZagInput(D=BIG, B=0, start_stage=5, stage_start_vi=bs), load=bp)
        cps = {}
        for D in Ds:
            if not ses.until_t(D - 1):
                break
            if dog_sig(emu) != dog0:                     # dog already awake before this cut: stop (outside model)
                break
            p = os.path.join(tmp, f"d{D}.st")
            emu.save_state(p)
            cps[D] = p
        ses.close()
        for D in Ds:
            if D not in cps:
                continue
            ses = Session(emu, ZigZagInput(D=D, B=BIG, start_stage=5, stage_start_vi=bs), load=cps[D])
            wake = None
            key = None
            late = False
            last_t = D + b0 - 1
            while ses.t() is None or ses.t() < last_t:
                emu.advance(1)
                if wake is None and dog_sig(emu) != dog0:
                    wake = (emu.vi, index(emu.u32(A.RAND_SEED)))
                if wake is not None and key is None and emu.vi - wake[0] >= KEY_AFTER_WAKE:
                    key = (emu.vi - wake[0], line_hash(emu))
                if emu.vi - entry > 1200:
                    break
            if key is None:                               # the dog woke too late (or not at all) before the cut
                late = True
                key = ((emu.vi - wake[0]) if wake else None, line_hash(emu))
            p = os.path.join(tmp, "pre_b.st")
            ok = ses.t() == last_t
            brow = []
            if ok:
                emu.save_state(p)
            ses.close()
            if ok:
                for B in Bs:
                    inp = ZigZagInput(D=D, B=B, start_stage=5, stage_start_vi=bs)
                    rec = drive(emu, inp, ready=True, beach_vi0=entry, max_vi=700, load=p)
                    r = rec["ready"]
                    if r and r["pier"] and wake is not None:
                        s_chk = emu.vi - wake[0]                # VIs since the wake at the READY detection
                        brow.append([B, r["vi"], r["pos"][0], r["pos"][1], r["draw"], s_chk, line_hash(emu)])
                    else:
                        e = rec["end"]["pos"]
                        brow.append([B, None, e[0], e[1], None, None, None])
            rows.append([D, None if wake is None else wake[0] - entry, None if wake is None else wake[1],
                         key[0], key[1], late, brow])
    finally:
        _cleanup(tmp)
    return {"b": j["b"], "rows": rows}


WINDOW_HINT = {84: 130, 86: 126}       # first B that reaches the dock end per (even) D on the zigzag-fast data


def zz_beach_scan_job(emu, j):
    """zigzag-3 beach job (2026-11-15): the same rows as zz_beach_job with ~10x fewer walks. Two rules measured on the
    zigzag-fast data: (1) the stick is read once per game frame, so B and B+1 give the same result when D+B is even
    (8,888/8,888 pairs), and D+1 (D even) gives D's row with every B shifted by -1 (264/264); (2) the B that reach the
    dock end form one unbroken window (484/484, 14 VIs). So only even D and even D+B are walked, around the window
    until 2 misses past each end, and the rest is copied. Both rules are walked for real once per job (an odd B at
    the window start; the D+1 row at one B); if either differs, the job walks every B of every D instead.
    The dog-awake rule of zz_beach_job (no row for a D whose cut comes after the dog woke) is kept exactly.
    j: b, Ds (wanted D), Bs (the B grid; only its range is used). Returns rows + "covered" (Ds decided, rows or not)."""
    bp = STORE / "b" / f"{j['b']}.st"
    m = _meta(bp)
    want = sorted({int(d) for d in j["Ds"]})
    Blo, Bhi = min(int(x) for x in j["Bs"]), max(int(x) for x in j["Bs"])
    dog0 = bytes.fromhex(m["dog0"])
    entry, bs = m["entry_vi"], m["stage_start"]
    tmp = _tmpdir()
    stats = {"walks": 0, "fallback": False}
    try:
        evens = sorted({d - d % 2 for d in want})
        ses = Session(emu, ZigZagInput(D=BIG, B=0, start_stage=5, stage_start_vi=bs), load=bp)
        cps, ok_d = {}, set()
        for D in evens:                                 # as zz_beach_job: stop at the first D cut after the wake
            if not ses.until_t(D - 1) or dog_sig(emu) != dog0:
                break
            p = os.path.join(tmp, f"d{D}.st")
            emu.save_state(p)
            cps[D] = p
            ok_d.add(D)
            if not ses.until_t(D) or dog_sig(emu) != dog0:   # D+1 is cut at t = D+1: dog checked at t = D, as before
                break
            ok_d.add(D + 1)
        ses.close()

        def per_d(D, cp):
            """wake + line key, then the pre-B checkpoint at t = D + Blo - 1 (as zz_beach_job)."""
            ses = Session(emu, ZigZagInput(D=D, B=BIG, start_stage=5, stage_start_vi=bs), load=cp)
            wake = key = None
            late = False
            last_t = D + Blo - 1
            while ses.t() is None or ses.t() < last_t:
                emu.advance(1)
                if wake is None and dog_sig(emu) != dog0:
                    wake = (emu.vi, index(emu.u32(A.RAND_SEED)))
                if wake is not None and key is None and emu.vi - wake[0] >= KEY_AFTER_WAKE:
                    key = (emu.vi - wake[0], line_hash(emu))
                if emu.vi - entry > 1200:
                    break
            if key is None:
                late = True
                key = ((emu.vi - wake[0]) if wake else None, line_hash(emu))
            pb = os.path.join(tmp, f"pre_b{D}.st")
            ok = ses.t() == last_t
            if ok:
                emu.save_state(pb)
            ses.close()
            head = [D, None if wake is None else wake[0] - entry, None if wake is None else wake[1], key[0], key[1], late]
            return head, (pb if ok else None), wake

        def walk(D, B, pb, wake):
            stats["walks"] += 1
            inp = ZigZagInput(D=D, B=B, start_stage=5, stage_start_vi=bs)
            rec = drive(emu, inp, ready=True, beach_vi0=entry, max_vi=700, load=pb, blocked_still=20)
            r = rec["ready"]
            if r and r["pier"] and wake is not None:
                return [B, r["vi"], r["pos"][0], r["pos"][1], r["draw"], emu.vi - wake[0], line_hash(emu)]
            e = rec["end"]["pos"]
            return [B, None, e[0], e[1], None, None, None]

        def scan(D, pb, wake, hint):
            """even-D+B walks around the READY window; returns {B: entry} for both parities (pairs copied)."""
            par = D % 2
            cand = [B for B in range(Blo, Bhi + 1) if (D + B) % 2 == 0]
            if not cand:
                return {}
            res = {}
            get = lambda B: res[B] if B in res else res.setdefault(B, walk(D, B, pb, wake))
            h = min(cand, key=lambda B: abs(B - (hint if hint is not None else Blo)))
            order = sorted(cand, key=lambda B: (abs(B - h), B))
            first = None
            for B in order:                              # nearest READY to the hint (worst case: every candidate)
                if get(B)[1] is not None:
                    first = B
                    break
            if first is not None:
                for step in (-2, 2):                     # widen both ways until 2 misses in a row
                    B, miss = first + step, 0
                    while Blo <= B <= Bhi and miss < 2:
                        miss = 0 if get(B)[1] is not None else miss + 1
                        B += step
            out = {}
            for B, e in res.items():
                out[B] = e
                if B + 1 <= Bhi:
                    out[B + 1] = [B + 1] + e[1:]
            return out

        rows, hint, checked = [], None, False
        for D in evens:
            if D not in cps:
                continue
            head, pb, wake = per_d(D, cps[D])
            entries = scan(D, pb, wake, hint if hint is not None else WINDOW_HINT.get(D, WINDOW_HINT[86])) if pb else {}
            ready = sorted(B for B, e in entries.items() if e[1] is not None)
            if ready:
                hint = ready[0]
            if pb and ready and not checked:            # walk both copy rules for real once per job
                checked = True
                w0 = ready[0] if (D + ready[0]) % 2 == 0 else ready[0] - 1
                odd = walk(D, w0 + 1, pb, wake)
                rule1 = odd == [w0 + 1] + entries[w0][1:]
                rule2, head1 = True, None
                if D + 1 in ok_d and D + 1 in want:
                    head1, pb1, wake1 = per_d(D + 1, cps[D])
                    same_head = head1[1:] == head[1:] if not head[5] else head1[1:3] == head[1:3]
                    rule2 = same_head and pb1 is not None and \
                        walk(D + 1, w0 - 1, pb1, wake1) == [w0 - 1] + entries[w0][1:]
                if not (rule1 and rule2):
                    stats["fallback"] = True
                    stats["check"] = {"D": D, "w0": w0, "even": entries[w0], "odd": odd, "rule1": rule1, "rule2": rule2,
                                      "head": head, "head1": head1 if D + 1 in ok_d and D + 1 in want else None}
                    break
            if D in want:
                rows.append(head + [[entries[B] for B in sorted(entries)]])
            if D + 1 in want and D + 1 in ok_d:
                sh = {B - 1: [B - 1] + e[1:] for B, e in entries.items() if B - 1 >= Blo}
                h1 = head[1:]
                if head[5]:
                    # "late" key (taken when the B grid starts, before wake + KEY_AFTER_WAKE): it is read one VI later
                    # for D+1, so D+1 reads its own key, exactly as zz_beach_job does; the walks are still copied
                    stats["late_d1"] = stats.get("late_d1", 0) + 1
                    h1 = per_d(D + 1, cps[D])[0][1:]
                rows.append([D + 1] + h1 + [[sh[B] for B in sorted(sh)]])
        if stats["fallback"]:                           # rules did not hold here: the old full job for these D
            old = zz_beach_job(emu, {"b": j["b"], "Ds": want, "Bs": list(range(Blo, Bhi + 1))})
            rows = old["rows"]
    finally:
        _cleanup(tmp)
    rows.sort(key=lambda r: r[0])
    return {"b": j["b"], "rows": rows, "covered": want, "scan": stats}


READY_X_MIN = -96.0       # the dock end: every READY on the zigzag-fast data stopped at x -94.6..-92.0 (z 170-196)


def zz_beach_neutral_job(emu, j):
    """Dog-neutral beach job (dog-spot lab, 2026-11-15). Makes no assumption about the dog: no dog-wake rule (every D is
    walked), no wake key, no READY-window contiguity. Line anchor = the beach load (the beach state's stage start).
    Walks every even D and every B with D+B even across the whole B range, and copies the other parity by the two
    input-timing rules (the stick is read once per game frame): B+1 = B when D+B is even, D+1 = D with B-1. Both rules
    are walked for real (rule 1 at every D, rule 2 once per job); if either fails, every (D, B) is walked.
    Rows: [D, dog_move (VIs after the beach load when dogInfo / the dog entity first changed, or None), beach-state draw,
    0, beach state key, False, brow]; brow entries:
      READY  [B, ready_rel, x, z, ready_draw, det_rel, h_det, [h_det, h_det+1, h_det+2], "ready"]
      else   [B, None, x, z, None, None, None, None, why]   why: blocked (still >= blocked_still VIs short of the pier)
             / short (stopped on the pier short of the dock end, x < READY_X_MIN) / timeout
    (det = the READY detection VI = READY + 4; h = line_hash, the dog line identity; the 3 hashes pin the game-frame
    phase when members are matched to a line's natural path.)"""
    real, Wt = _bkey(j["b"])
    bp = STORE / "b" / f"{real}.st"
    m = _meta(bp)
    want = sorted({int(d) for d in j["Ds"]})
    Blo, Bhi = min(int(x) for x in j["Bs"]), max(int(x) for x in j["Bs"])
    Wlo, Whi = Blo - 1, Bhi + 1                         # walked range: one more B each side so both copies fill [Blo, Bhi]
    still = int(j.get("blocked_still", 60))
    dog0 = bytes.fromhex(m["dog0"])
    entry, bs = m["entry_vi"], m["stage_start"]
    tmp = _tmpdir()
    stats = {"walks": 0, "fallback": False, "rule1": 0, "rule1_bad": [], "rule2": None, "W": Wt}
    vis0 = {}

    def see(e, slot):                                    # first VI the dog's tile is visible, and where Jack is
        if "vi" not in slot and dog_visible(e):
            x, z = player_xz(e)
            slot.update(vi=e.vi - entry, x=round(x, 1), z=round(z, 1))
    try:
        evens = sorted({d - (d + Wt) % 2 for d in want})  # the walked first cut: cut VI D + W even (copy rule 2)
        ses = Session(emu, ZigZagInput(D=BIG, B=0, start_stage=5, stage_start_vi=bs, W=Wt), load=bp)
        see(emu, vis0)
        hv = emu.add_listener(lambda e: see(e, vis0))
        cps = {}
        for D in evens:
            if not ses.until_t(D - 1 + Wt):
                break
            p = os.path.join(tmp, f"d{D}.st")
            emu.save_state(p)
            cps[D] = (p, dict(vis0))
        emu.remove_listener(hv)
        ses.close()

        def per_d(D, cpv):
            cp, v0 = cpv
            vis = dict(v0)
            ses = Session(emu, ZigZagInput(D=D, B=BIG, start_stage=5, stage_start_vi=bs, W=Wt), load=cp)
            hv = emu.add_listener(lambda e: see(e, vis))
            move = None
            last_t = D + Wlo - 1 + Wt
            while ses.t() is None or ses.t() < last_t:
                emu.advance(1)
                if move is None and dog_sig(emu) != dog0:
                    move = emu.vi - entry
                if emu.vi - entry > 1200:
                    break
            emu.remove_listener(hv)
            pb = os.path.join(tmp, f"pre_b{D}.st")
            ok = ses.t() == last_t
            if ok:
                emu.save_state(pb)
            ses.close()
            return [D, move, m["draw"], 0, j["b"], False], ((pb, vis) if ok else None)

        def walk(D, B, pbv):
            pb, v0 = pbv
            vis = dict(v0)
            stats["walks"] += 1
            inp = ZigZagInput(D=D, B=B, start_stage=5, stage_start_vi=bs, W=Wt)
            hv = emu.add_listener(lambda e: see(e, vis))
            try:
                rec = drive(emu, inp, ready=True, beach_vi0=entry, max_vi=900, load=pb, blocked_still=still)
            finally:
                emu.remove_listener(hv)
            r = rec["ready"]
            vrow = [vis.get("vi"), vis.get("x"), vis.get("z"), dog_visible(emu)]   # dog activation; visible at the end
            if r and r["pier"] and r["pos"][0] >= READY_X_MIN:
                det = emu.vi - entry
                h0 = line_hash(emu)
                emu.set_poll_callback(None)              # released, as zz_line_job after READY
                emu.advance(1)
                h1 = line_hash(emu)
                emu.advance(1)
                h2 = line_hash(emu)
                return [B, r["vi"], r["pos"][0], r["pos"][1], r["draw"], det, h0, [h0, h1, h2], "ready", vrow]
            emu.set_poll_callback(None)
            if r:
                return [B, None, r["pos"][0], r["pos"][1], None, None, None, None, "short", vrow]
            e = rec["end"]["pos"]
            return [B, None, e[0], e[1], None, None, None, None, "blocked" if rec.get("blocked") else "timeout", vrow]

        def full(D, pb):
            return {B: walk(D, B, pb) for B in range(Blo, Bhi + 1)}

        def scan(D, pb):
            """walk B with D+B even over the whole range; copy B+1 (rule 1) and check it at one B for real."""
            res = {B: walk(D, B, pb) for B in range(Wlo, Whi + 1) if (D + B + Wt) % 2 == 0}
            out = {}
            for B, e in res.items():
                out[B] = e
                out[B + 1] = [B + 1] + e[1:]
            ready = sorted(B for B, e in res.items() if e[1] is not None)
            w0 = ready[0] if ready else min(res)          # the window start (or any B when none reaches)
            if True:
                stats["rule1"] += 1
                odd = walk(D, w0 + 1, pb)
                if odd != out[w0 + 1]:
                    stats["rule1_bad"].append({"D": D, "B": w0 + 1, "walked": odd, "copied": out[w0 + 1]})
            return out

        rows = []
        heads = {}
        if j.get("force_full"):                          # self-test: the full walk (no copies) for comparison
            stats["fallback"] = True
        for D in (evens if not stats["fallback"] else []):
            if D not in cps:
                continue
            head, pb = per_d(D, cps[D])
            heads[D] = (head, pb)
            entries = scan(D, pb) if pb else {}
            if stats["rule1_bad"]:
                stats["fallback"] = True
                break
            if stats["rule2"] is None and pb and D + 1 in want:   # rule 2 once per job: D+1 for real at one B
                h1, pb1 = per_d(D + 1, cps[D])
                ready = sorted(B for B, e in entries.items() if e[1] is not None and (D + B + Wt) % 2 == 0)
                cands = [B for B in ready if B - 1 >= Wlo] or \
                    sorted(B for B in entries if (D + B + Wt) % 2 == 0 and B - 1 >= Wlo)
                b0 = cands[0]
                ok2 = h1[1:] == head[1:] and pb1 is not None and \
                    walk(D + 1, b0 - 1, pb1) == [b0 - 1] + entries[b0][1:]
                stats["rule2"] = {"D": D, "B": b0, "ok": bool(ok2)}
                if not ok2:
                    stats["fallback"] = True
                    break
            if D in want:
                rows.append(head + [[entries[B] for B in range(Blo, Bhi + 1)]] if pb else head + [[]])
            if D + 1 in want:
                if pb:
                    sh = {B - 1: [B - 1] + e[1:] for B, e in entries.items()}
                    rows.append([D + 1] + head[1:] + [[sh[B] for B in range(Blo, Bhi + 1)]])
                else:
                    rows.append([D + 1] + head[1:] + [[]])
        if stats["fallback"]:                            # a copy rule failed here: walk every (D, B) for real
            rows = []
            for D in want:
                cp = cps.get(D - (D + Wt) % 2)
                if cp is None:
                    continue
                if (D + Wt) % 2 == 0 and D in heads:
                    head, pb = heads[D]
                else:
                    head, pb = per_d(D, cp)
                ent = full(D, pb) if pb else {}
                rows.append(head + [[ent[B] for B in sorted(ent)]])
    finally:
        emu.set_poll_callback(None)
        _cleanup(tmp)
    rows.sort(key=lambda r: r[0])
    return {"b": j["b"], "rows": rows, "covered": want, "scan": stats, "neutral": True}


def zz_bench_job(emu, j):
    """CPU-core benchmark (fresh emulator): the reference route from power-on, then 12 walks each from a reloaded
    savestate (the lab's typical load-heavy work) taken at the furthest screen the route reached on this save (the
    beach on the dog-beach save, as before; the dog-spot saves may stop earlier). Returns the seconds inside the job
    and a hash of all results (both cores must give the same hash)."""
    import time
    t0 = time.time()
    sp = REFERENCE["spec"]
    inp = ZigZagInput(Mash(sp["T"], sp["h"], sp["ph"], sp["style"]), U=sp["U"], V=sp["V"], C=sp["C"], D=sp["D"],
                      B=sp["B"])
    emu.schedule_hard_reset(RESET_VI)
    tmp = _tmpdir()
    try:
        held = {}

        def on_stage(e, stage, rec):
            if stage == 1:
                _test_dog_poke(e)
            p = os.path.join(tmp, f"s{stage}.st")
            e.save_state(p)
            held[stage] = (p, e.vi)
        rec0 = drive(emu, inp, until_stage=6, ready=True, on_stage=on_stage, max_vi=6000)
        st = max(held) if held else 0
        h = hashlib.blake2b(digest_size=8)
        h.update(json.dumps([st, rec0["end"]]).encode())
        p, vi = held.get(st, (None, None))
        for k in range(12 if held else 0):
            inp = ZigZagInput(U=sp["U"] + k % 4, V=sp["V"] + k % 3, C=sp["C"] + k % 6, D=84 + 2 * (k % 6),
                              B=126 + 2 * (k % 7), start_stage=st, stage_start_vi=vi)
            rec = drive(emu, inp, ready=True, beach_vi0=vi if st == 5 else None, max_vi=700, load=p, blocked_still=20)
            r = rec["ready"] or rec["end"]
            h.update(json.dumps([r.get("vi"), r.get("pos"), r.get("draw"), index(emu.u32(A.RAND_SEED))]).encode())
    finally:
        emu.set_poll_callback(None)
        _cleanup(tmp)
    return {"t": round(time.time() - t0, 2), "h": h.hexdigest(), "cpu": emu.cpu, "stage": st}


MAP_NAMES = {0: "ranch", 1: "ranch", 2: "ranch", 3: "ranch", 4: "Ann's room", 5: "ranch barn", 6: "ranch store",
             7: "ranch house", 9: "beach", 10: "beach", 11: "beach", 12: "beach", 13: "race track", 14: "race track",
             15: "race track", 16: "race track", 17: "mountain 1", 18: "mountain 1", 19: "mountain 1", 20: "mountain 1",
             21: "mountain 2", 22: "mountain 2", 23: "mountain 2", 24: "mountain 2", 25: "top of mountain",
             26: "top of mountain", 27: "top of mountain", 28: "top of mountain", 29: "moon mountain",
             30: "moon mountain", 31: "moon mountain", 32: "moon mountain", 33: "carpenter hut", 34: "dumpling house",
             35: "pond", 36: "pond", 37: "pond", 38: "pond", 39: "Elli's room", 40: "bakery", 41: "village 1",
             42: "village 1", 43: "village 1", 44: "village 1", 45: "village 2", 46: "village 2", 47: "village 2",
             48: "village 2", 49: "Popuri's room", 50: "flower shop", 51: "church", 52: "souvenir shop", 53: "square",
             54: "square", 55: "square", 56: "square", 57: "Rick's store", 58: "midwife house", 59: "tavern",
             60: "library", 61: "Maria's room", 62: "mayor's house", 63: "potion shop bedroom", 64: "potion shop",
             66: "harvest sprite cave", 67: "cave", 68: "mine", 69: "mine 2", 70: "Karen's room", 71: "vineyard",
             72: "vineyard", 73: "vineyard", 74: "vineyard", 75: "vineyard house", 76: "vineyard cellar",
             77: "vineyard cellar basement", 78: "crossroads", 79: "crossroads", 80: "crossroads", 81: "crossroads",
             82: "farm", 83: "farm", 84: "farm", 85: "farm", 86: "greenhouse", 87: "house", 88: "barn", 89: "coop",
             90: "kitchen", 91: "bathroom"}         # src/assetIndices/maps.h (the 4 values of a map = the seasons)
SEASON_NAMES = {1: "spring", 2: "summer", 3: "autumn", 4: "winter"}


def _dog_info(emu):
    loc = emu.u8(A.DOG + 0x16)
    fl = emu.u16(A.DOG + 0x1E)
    return {"location": loc, "map": MAP_NAMES.get(loc, f"map {loc}"), "x": round(emu.f32(A.DOG + 0x08), 2),
            "y": round(emu.f32(A.DOG + 0x0C), 2), "z": round(emu.f32(A.DOG + 0x10), 2),
            "direction": emu.u8(A.DOG + 0x18), "action": emu.u8(A.DOG + 0x17), "flags": fl,
            "flag_names": [n for b, n in A.DOG_FLAGS.items() if fl & b], "affection": emu.u8(A.DOG)}


def zz_record_job(emu, j):
    """Dog-spot lab Z0 (fresh emulator): the reference route of the zigzag check (mash 10/s START>A, U276 V52 C80 D86
    B134) from power-on on this save, recorded instead of checked: the date, weather, clock and tool at the house load,
    where the dog is (dogInfo) at every map load, the dog's first move on the beach, READY or where Jack stopped.
    Run twice in fresh emulators: the two records must be equal (the save is deterministic in the lab)."""
    sp = REFERENCE["spec"]
    inp = ZigZagInput(Mash(sp["T"], sp["h"], sp["ph"], sp["style"]), U=sp["U"], V=sp["V"], C=sp["C"], D=sp["D"],
                      B=sp["B"])
    emu.schedule_hard_reset(RESET_VI)
    info = {"stages": {}}

    def on_stage(e, stage, rec):
        if stage == 1:
            _test_dog_poke(e)
            se = e.u8(A.SEASON)
            info["save"] = {"season": se, "season_name": SEASON_NAMES.get(se, str(se)), "day": e.u8(A.DAY_OF_MONTH),
                            "year": e.u8(A.YEAR), "weather": e.u8(A.WEATHER), "hour": e.u8(A.HOUR),
                            "minutes": e.u8(A.MINUTES), "tool_slot": e.u8(A.PLAYER + 0x15),
                            "current_tool": e.u8(A.PLAYER + 0x1D),
                            "rod_in_hand": e.u8(A.PLAYER + 0x1D) == A.FISHING_ROD_TOOL,   # dog-beach save: 0x18
                            "held_item": e.u8(A.PLAYER + 0x2C)}
        d = _dog_info(e)
        info["stages"][str(stage)] = {"vi": e.vi, "map": e.u16(MAP_CTRL), "draw": index(e.u32(A.RAND_SEED)), "dog": d,
                                      "dog_here": map_is(d["location"], e.u16(MAP_CTRL))}
    rec = drive(emu, inp, ready=True, track_wake=True, on_stage=on_stage, max_vi=6000)
    r = rec["ready"]
    got = {"house": [rec["stages"][1]["vi"], rec["stages"][1]["draw"]] if 1 in rec["stages"] else None,
           "farm": [rec["stages"][2]["vi"], rec["stages"][2]["draw"]] if 2 in rec["stages"] else None,
           "beach": [rec["stages"][5]["vi"], rec["stages"][5]["draw"]] if 5 in rec["stages"] else None,
           "wake": [rec["wake"]["vi"], rec["wake"]["draw"]] if rec["wake"] else None,
           "ready": [r["vi"], r["pos"][0], r["pos"][1], r["draw"]] if r else None}
    end = rec["end"]
    info["end"] = {"stage": end["stage"], "pos": end["pos"], "vi": end["vi"], "map": emu.u16(MAP_CTRL),
                   "blocked": rec.get("blocked"), "ready_at_dock_end": bool(r and r["pos"][0] >= READY_X_MIN),
                   "why": "ready" if r and r["pos"][0] >= READY_X_MIN else "short" if r else
                   "blocked" if rec.get("blocked") else "max time (6000 VIs from power-on)"}
    info["dog_end"] = _dog_info(emu)
    return {"got": got, "info": info, "stage_hashes": {str(k): v["hash"] for k, v in rec["stages"].items()}}


# ------------------------------------------------------------------------------------------------ line
def zz_line_job(emu, j):
    """j: key, b, D, B (representative), wake_rel, until (VIs after READY), rung (VIs), step (VIs).
    Replays the representative from its beach state, releases at READY, records the natural path.
    Also (2026-11-15): the RNG draw index every 60 VIs after READY and the VIs the dog's tile is visible."""
    from hm64.lcg import index as _index
    real, Wt = _bkey(j["b"])
    bp = STORE / "b" / f"{real}.st"
    m = _meta(bp)
    D, B = int(j["D"]), int(j["B"])
    until, rung_every, step = int(j.get("until", 2398)), int(j.get("rung", 60)), int(j.get("step", 2))
    entry = m["entry_vi"]
    dog0 = bytes.fromhex(m["dog0"])
    inp = ZigZagInput(D=D, B=B, start_stage=5, stage_start_vi=m["stage_start"], W=Wt)
    wake = {}

    def watch(e):
        if "vi" not in wake and e.vi > m["vi"] + 1 and dog_sig(e) != dog0:
            wake["vi"] = e.vi
    h = emu.add_listener(watch)
    rec = drive(emu, inp, ready=True, beach_vi0=entry, max_vi=900, load=bp)
    emu.remove_listener(h)
    r = rec["ready"]
    if not r or not r["pier"]:
        emu.set_poll_callback(None)
        return {"key": j["key"], "ok": False, "why": "no READY", "end": rec["end"]}
    R = r["abs_vi"]
    emu.set_poll_callback(None)                          # stick released at READY (drive set released; now none)
    hashes, rungs = [], []
    n0 = emu.polls()
    v0 = emu.vi
    key_check = None
    k = emu.vi - R                                       # READY is detected READY_STILL VIs after Jack stops
    lhashes = []
    draws, vis_n = [], [0]
    R_draw = None

    obs = [] if j.get("observe") else None               # dog-watch (2026-11-16): what the runner could see, per VI
    ent = ENT_DOG

    def record(k):                                       # line hash every VI (member checks), cast hash on the grid
        if k >= 4:
            lhashes.append([k, line_hash(emu)])
            if k % step == 0:
                hashes.append([k, cast_hash(emu)])
        if k % 60 == 4:
            draws.append([k, _index(emu.u32(A.RAND_SEED))])
        vis = dog_visible(emu)
        if vis:
            vis_n[0] += 1
        if obs is not None and k >= 1:
            obs.append((k, emu.u16(ent + 0x54), emu.u16(ent + 0x56), emu.u8(ent + 0x67), emu.u32(A.RAND_SEED),
                        emu.u8(A.DOG + 0x17), emu.u8(A.DOG + 0x18), emu.u8(A.DOG + 0x1A),
                        round(emu.f32(ent + 0x28), 1), round(emu.f32(ent + 0x30), 1), bool(vis)))

    record(k)
    while emu.vi - R < until:
        emu.advance(1)
        record(emu.vi - R)
    ppv = (emu.polls() - n0) / max(1, emu.vi - v0)
    return {"key": j["key"], "ok": True, "b": j["b"], "D": D, "B": B, "ready_rel": R - entry,
            "wake_rel": (wake["vi"] - entry) if "vi" in wake else None, "spot": r["pos"], "key_check": key_check,
            "polls_per_vi": round(ppv, 4), "hashes": hashes, "lhashes": lhashes, "rungs": rungs,
            "draws": draws, "dog_visible_vis": vis_n[0], "W": Wt, **({"obs": obs_pack(obs)} if obs is not None else {})}


def obs_pack(rows):
    """Dog-watch trace from per-VI rows (k, base, shown, screen, seed, act, dir, timer, x, z, on_grid), k = VIs after the
    line's READY. Same conventions as campaign_jobs.observe_job (O_observe), plus position and the shown animation:
      vis    [[k0, k1, screen, visual_class, base]]   runs of what is on screen (animationIndex +0x54 + facing +0x67)
      shown  [[k, base]]          when the displayed animation (+0x56, what the TV draws) changes
      dog    [[k, act, dir, timer]]  dogInfo actionState (the NEXT state) / direction / stateTimer, when any changes
      draw   [[k, index]]         absolute rand() count whenever the dog adds draws beyond the main loop's 1 per frame
                                  (and every 60 VIs)
      pos    [[k, x, z]]          dog position when it moves (>= 0.5 units) and every 60 VIs
      grid   [[k0, k1]]           runs with the dog's tile on the visibility grid (it animates only then)
    The decision moment (actionState / draws) precedes the visible change; the lag is measured from these fields."""
    from hm64.lcg import MASK, step as lcg_step, index as _ix
    from hm64.sprites import visual_class
    vis, shown, dog, draw, pos, grid = [], [], [], [], [], []
    if not rows:
        return {"vis": vis, "shown": shown, "dog": dog, "draw": draw, "pos": pos, "grid": grid}
    seed = rows[0][4]
    d = _ix(seed)
    last_pos = None
    for k, base, shw, scr, s, act, dr, tm, x, z, on in rows:
        cls = visual_class(base, scr)
        if vis and vis[-1][2] == scr and vis[-1][3] == cls and vis[-1][4] == base:
            vis[-1][1] = k + 1
        else:
            vis.append([k, k + 1, scr, cls, base])
        if not shown or shown[-1][1] != shw:
            shown.append([k, shw])
        n = 0
        while seed != s and n < 100000:
            seed = lcg_step(seed) & MASK
            n += 1
        if seed != s:
            d, seed = _ix(s), s
        else:
            d += n
        if n > 1 or k % 60 == 0 or not draw:
            draw.append([k, d])
        if not dog or dog[-1][1:] != [act, dr, tm]:
            dog.append([k, act, dr, tm])
        if last_pos is None or abs(x - last_pos[0]) + abs(z - last_pos[1]) >= 0.5 or k % 60 == 0:
            pos.append([k, x, z])
            last_pos = (x, z)
        if on:
            if grid and grid[-1][1] == k:
                grid[-1][1] = k + 1
            else:
                grid.append([k, k + 1])
    return {"vis": vis, "shown": shown, "dog": dog, "draw": draw, "pos": pos, "grid": grid}


# ------------------------------------------------------------------------------------------------ casts
def zz_cast_job(emu, j):
    """j: key, b, D, B (the line's representative route), casts [[k, hash], ...] (k = VIs after its READY), tag.
    Replays the representative from its beach state to READY (stick released), runs to min(k)-2, checks the hash
    before each cast (first, last, every 8th) and evaluates it (no stored rungs: replay costs ~3% of the casts)."""
    from hm64.fishing import eval_cast
    casts = sorted((int(k), h) for k, h in j["casts"])
    real, Wt = _bkey(j["b"])
    bp = STORE / "b" / f"{real}.st"
    m = _meta(bp)
    tmp = _tmpdir()
    out = []
    try:
        inp = ZigZagInput(D=int(j["D"]), B=int(j["B"]), start_stage=5, stage_start_vi=m["stage_start"], W=Wt)
        rec = drive(emu, inp, ready=True, beach_vi0=m["entry_vi"], max_vi=900, load=bp)
        emu.set_poll_callback(None)
        r = rec["ready"]
        if not r or not r["pier"]:
            return {"key": j["key"], "tag": j.get("tag"), "error": "no READY on replay"}
        R = r["abs_vi"]
        k0 = casts[0][0] - 2
        if emu.vi - R > k0:
            return {"key": j["key"], "tag": j.get("tag"), "error": f"cast before READY+{emu.vi - R}"}
        emu.advance(R + k0 - emu.vi)
        rung = os.path.join(tmp, "rung.st")
        emu.save_state(rung)
        for n, (k, h) in enumerate(casts):
            ok = None
            if n == 0 or n == len(casts) - 1 or n % 8 == 0:
                emu.set_poll_callback(None)
                emu.load_state(rung)
                emu.advance(k - k0)
                ok = cast_hash(emu) == h
            bu = j.get("bite_until")                      # 2026-11-16: every bite up to this many VIs after READY
            r2 = eval_cast(emu, rung, k - k0, hold_bites=int(j.get("bites_max", 2)), map_window=False, probes=(4, 12),
                           tmpdir=tmp, hold_until=None if bu is None else int(bu) - k0, always_bites=2,
                           probes_more=(4,))
            bites = [{"bite": None if b.get("bite_poll") is None else b["bite_poll"] + k0, "nut": bool(b.get("nut"))}
                     for b in r2.get("bites", [])]
            out.append({"k": k, "hash": h, "hash_ok": ok, "status": r2["status"], "bites": bites})
    finally:
        emu.set_poll_callback(None)
        _cleanup(tmp)
    return {"key": j["key"], "tag": j.get("tag"), "casts": out}


# ------------------------------------------------------------------------------------------------ health check
REFERENCE = {"spec": {"T": 6, "h": 3, "ph": 0, "style": "START>A", "U": 276, "V": 52, "C": 80, "D": 86, "B": 134},
             "expect": {"house": [1036, 499], "farm": [1448, 704], "beach": [2264, 1073], "wake": [191, 1169],
                        "ready": [339, -92.0, 194.0, 1263]}}


def zz_check_job(emu, j):
    """fresh emulator: the reference route from power-on must reproduce the sandbox numbers (2026-11-14)."""
    sp = REFERENCE["spec"]
    inp = ZigZagInput(Mash(sp["T"], sp["h"], sp["ph"], sp["style"]), U=sp["U"], V=sp["V"], C=sp["C"], D=sp["D"],
                      B=sp["B"])
    emu.schedule_hard_reset(RESET_VI)
    rec = drive(emu, inp, ready=True, track_wake=True, max_vi=6000)
    got = {"house": [rec["stages"][1]["vi"], rec["stages"][1]["draw"]] if 1 in rec["stages"] else None,
           "farm": [rec["stages"][2]["vi"], rec["stages"][2]["draw"]] if 2 in rec["stages"] else None,
           "beach": [rec["stages"][5]["vi"], rec["stages"][5]["draw"]] if 5 in rec["stages"] else None,
           "wake": [rec["wake"]["vi"], rec["wake"]["draw"]] if rec["wake"] else None,
           "ready": [rec["ready"]["vi"], rec["ready"]["pos"][0], rec["ready"]["pos"][1], rec["ready"]["draw"]]
           if rec["ready"] else None}
    return {"got": got, "expect": REFERENCE["expect"], "ok": got == REFERENCE["expect"]}


# ------------------------------------------------------------------------------------------------ member recast check
def zz_member_cast_job(emu, j):
    """Verification of shared casts: replay one member route (b, D, B) from its beach state to its own READY,
    release, then cast at each tau (VIs after its READY) from its own state. Returns bites relative to the cast."""
    from hm64.fishing import eval_cast
    real, Wt = _bkey(j["b"])
    bp = STORE / "b" / f"{real}.st"
    m = _meta(bp)
    tmp = _tmpdir()
    out = []
    try:
        for tau in sorted(int(t) for t in j["taus"]):
            inp = ZigZagInput(D=int(j["D"]), B=int(j["B"]), start_stage=5, stage_start_vi=m["stage_start"], W=Wt)
            rec = drive(emu, inp, ready=True, beach_vi0=m["entry_vi"], max_vi=900, load=bp)
            r = rec["ready"]
            emu.set_poll_callback(None)
            if not r or not r["pier"]:
                out.append({"tau": tau, "status": "no READY"})
                continue
            R = r["abs_vi"]
            emu.advance(max(0, R + tau - 2 - emu.vi))
            p = os.path.join(tmp, "m.st")
            emu.save_state(p)
            c = eval_cast(emu, p, 2, hold_bites=2, map_window=False, probes=(4, 12), tmpdir=tmp)
            b = c.get("bites", [])
            out.append({"tau": tau, "status": c["status"],
                        "d1": None if len(b) < 1 or b[0].get("bite_poll") is None else b[0]["bite_poll"] - 2,
                        "n1": bool(b and b[0].get("nut")),
                        "d2": None if len(b) < 2 or b[1].get("bite_poll") is None else b[1]["bite_poll"] - 2,
                        "n2": bool(len(b) > 1 and b[1].get("nut"))})
    finally:
        emu.set_poll_callback(None)
        _cleanup(tmp)
    return {"line": j["line"], "b": j["b"], "D": j["D"], "B": j["B"], "casts": out}
