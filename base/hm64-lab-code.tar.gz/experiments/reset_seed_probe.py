import sys, json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from m64h.core import Emulator
from tools.common import default_rom, default_sram
from hm64 import addresses as A
from hm64.lcg import index
res = {}
for mode in ("reset", "noreset"):
    rows = {}
    with Emulator(default_rom(), sram=default_sram()) as emu:
        if mode == "reset":
            emu.schedule_hard_reset(121)
        emu.add_listener(lambda e: rows.__setitem__(e.vi, index(e.u32(A.RAND_SEED))))
        emu.advance(700)
    res[mode] = {v: rows.get(v) for v in (60, 100, 118, 120, 122, 124, 130, 160, 200, 240, 300, 400, 500, 600, 700)}
print(json.dumps(res))
