#!/bin/bash
# Strategy lab on the Mac, natively (no Docker, no emulation): tests observation strategies
# (strategies/*.json) and search algorithms against data your campaign runs already recorded.
#
#   cd ~/Documents/hm64 && bash run_strategy_lab.sh                 all strategies in strategy-lab/strategies/
#   bash run_strategy_lab.sh strategies/02_ad_every_10s_60s.json    just one (path relative to strategy-lab/)
#
# Needs python3 with numpy (conda base has it). Edit or add JSON files in strategy-lab/strategies/ and rerun;
# your strategy files are never overwritten. Results: strategy-lab/truth/STRATEGY.md (+ CSV/JSON).
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
LAB="$HERE/strategy-lab"
die() { echo "ERROR: $*" >&2; exit 1; }
[ -f "$HERE/hm64-lab.tar.gz" ] || die "hm64-lab.tar.gz not next to this script"
PY="${HM64_PYTHON:-python3}"
"$PY" -c "import numpy" 2>/dev/null || die "$PY has no numpy (try: conda activate base, or pip3 install numpy)"
TMP="$(mktemp -d)"
tar -xzf "$HERE/hm64-lab.tar.gz" -C "$TMP"
mkdir -p "$LAB" "$LAB/data/routes" "$LAB/truth"
rm -rf "$LAB/tools" "$LAB/hm64"
cp -R "$TMP/hm64-lab/tools" "$TMP/hm64-lab/hm64" "$LAB/"
[ -d "$LAB/strategies" ] || cp -R "$TMP/hm64-lab/strategies" "$LAB/"
rm -rf "$TMP"
CSV="$(find -L "$HERE/sourcefiles" -iname '*ROUTE_TO_CHECKPOINT_LINKS*.csv' 2>/dev/null | head -1 || true)"
if [ -n "$CSV" ]; then cp "$CSV" "$LAB/data/routes/ROUTE_TO_CHECKPOINT_LINKS.csv"
else echo "note: ROUTE_TO_CHECKPOINT_LINKS.csv not found in sourcefiles - arrivals will not be route-weighted"; fi
DATA=""
for d in $(ls -dt "$HERE"/runs/*/hm64-lab/results/campaign-* 2>/dev/null); do
  if [ -f "$d/O_observe.jsonl" ] && [ -f "$d/W_single.jsonl" ]; then DATA="$d"; break; fi
done
[ -n "$DATA" ] || die "no run folder with O_observe.jsonl + W_single.jsonl under $HERE/runs (run the observe and pulse presets first)"
echo "==> ground truth: $DATA"
for f in A_routes.jsonl O_observe.jsonl W_single.jsonl W_lines.json W_ladder.jsonl; do
  [ -f "$DATA/$f" ] && ln -sf "$DATA/$f" "$LAB/truth/$f"
done
cd "$LAB"
if [ "$#" -gt 0 ]; then "$PY" tools/strategy_lab.py truth "$@"
else "$PY" tools/strategy_lab.py truth strategies/*.json; fi
echo "==> results: $LAB/truth/STRATEGY.md"
