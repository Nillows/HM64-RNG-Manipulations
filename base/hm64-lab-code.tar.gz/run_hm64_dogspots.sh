#!/usr/bin/env bash
# HM64 Power Nut lab - dog-spot lab (2026-11-15): Thomas's dog-placement SaveRAMs through the zigzag-fast recipe of
# route delays, dog-neutral, one save after the other.
#
#   bash run_hm64_dogspots.sh [workers]
#
# Put the dog-spot saves (*.SaveRAM / *.sra / *.sav / *.srm, also inside .zip files) in <script dir>/sourcefiles/dogspots/
# - in numbered folders 1/, 2/, 3/ ... to set the order (folder number, then file name) - and the ROM (*.z64) in
# <script dir>/sourcefiles/ (as for the zigzag runs). Each save gets its own label (<folder number>-<spot name>-<sha256
# first 8>), its own state store and its own results folder; a finished save is not redone and a stopped one continues
# (Ctrl-C any time, run the same command again). After each save: its fast results are printed and its own zip
# runs/hm64-dogspots-<label>-<timestamp>.zip is written, then the next save starts.
# Work folder: <script dir>/runs/dogspots/hm64-lab (results/<preset>/<label>). Per save: runs/hm64-<preset>-<label>-
# <timestamp>.zip; at the end runs/hm64-<preset>-<timestamp>.zip (DOGSPOTS.md comparison + every save's folder:
# ZIGZAG.md, failure map, cast tables; no ROM, saves or savestates inside).
# Env: HM64_DOGSPOTS_PRESET=lineup-fast (default dogspot-fast; results in results/<preset>/<label>),
#      HM64_DOGSPOTS_DIR=lineup (saves from sourcefiles/<dir>, default dogspots), HM64_DOGSPOTS_WAIT=1 (queue: wait for
#      the run now going, then start), HM64_LAB_TARBALL (lab code tarball, default hm64-lab-dogspots.tar.gz), HM64_DOGSPOTS_CONTROL=1 (also run the dog-beach save 0d78b95b as the control), HM64_DOGSPOTS_ONLY=<text> (only
#      saves whose label contains it), HM64_ZZ_STOP_AFTER=Z6 (route recipe + lines only, no casts), HM64_DRY_RUN=1
#      (find inputs, stop), M64H_CPU, M64H_RECYCLE, INSTALL_CLAUDE=0, HM64_RUN_ROOT.
set -euo pipefail

say() { printf '\n==> %s\n' "$*"; }
die() { printf '\nSTOP: %s\n' "$*" >&2; exit 1; }

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKERS=${1:-}
PRESET=${HM64_DOGSPOTS_PRESET:-dogspot-fast}
RES="results/$PRESET"
TARBALL="${HM64_LAB_TARBALL:-$HERE/hm64-lab-dogspots.tar.gz}"
INPUTS="$HERE/sourcefiles"
SPOTS="$INPUTS/${HM64_DOGSPOTS_DIR:-dogspots}"
DOGBEACH_SHA=0d78b95b78e4a988570b3648d9bc16021df59a5faccdc00d06b01273975d8387
SPRING9_SHA=db2c29ace807ab980ebbc7eccad11e30e37ea3dad53113c3fb1bdc073b759d63
ROM_SHA=15c570120bfaa97b4580762f5ee5939a56ba054e696925ea81ccfa55a022d2a6
[ -f "$TARBALL" ] || die "$(basename "$TARBALL") is not next to this script ($HERE)"
mkdir -p "$INPUTS" "$SPOTS"

if [ "${HM64_DRY_RUN:-0}" != 1 ]; then
  command -v docker >/dev/null || die "docker not found"
  docker info >/dev/null 2>&1 || die "Docker is not running (start Docker Desktop)"
fi

RUN_ROOT=${HM64_RUN_ROOT:-$HERE/runs}
WORK="$RUN_ROOT/dogspots"
LAB="$WORK/hm64-lab"
mkdir -p "$WORK"
LOCK="$WORK/.running"
WAITED=0
while :; do                                    # one lab run at a time; HM64_DOGSPOTS_WAIT=1: queue behind the current one
  if [ -d "$RUN_ROOT/zigzag/.running" ]; then busy="a zigzag run ($RUN_ROOT/zigzag/.running)"
  elif mkdir "$LOCK" 2>/dev/null; then break
  else busy="the dog-spot / lineup run now going ($LOCK)"
  fi
  [ "${HM64_DOGSPOTS_WAIT:-0}" = 1 ] || die "$busy - start this one after it finishes (one lab run at a time; if none is running, delete that folder)"
  if [ $((WAITED % 15)) -eq 0 ]; then
    echo "  $(date +%H:%M) waiting for $busy to finish; this run starts by itself right after it (Ctrl-C cancels; if nothing is running, delete that folder)"
  fi
  WAITED=$((WAITED + 1))
  sleep 60
done
trap 'rmdir "$LOCK" 2>/dev/null || true' EXIT
STAMP=$(date +%Y%m%d-%H%M%S)
LOG="$WORK/run-$PRESET-$STAMP.log"
exec > >(tee -a "$LOG") 2>&1
say "work folder: $LAB  (preset $PRESET, saves from $SPOTS)"

say "1/6 lab code"
TMPX="$WORK/.code-$STAMP"
mkdir -p "$TMPX"
tar -xzf "$TARBALL" -C "$TMPX"
[ -f "$TMPX/hm64-lab/docker-compose.yml" ] || die "tarball does not contain hm64-lab/"
mkdir -p "$LAB"
for e in "$TMPX/hm64-lab/"* "$TMPX/hm64-lab/".[!.]*; do
  [ -e "$e" ] || continue
  b=$(basename "$e")
  case "$b" in states|results|data) continue ;; esac
  if [ -e "$LAB/$b" ]; then chmod -R u+w "$LAB/$b" 2>/dev/null || true; rm -rf "${LAB:?}/${b:?}"; fi
  cp -R "$e" "$LAB/$b"
done
mkdir -p "$LAB/data" "$LAB/states" "$LAB/results"
for d in "$TMPX/hm64-lab/data/"*; do
  [ -e "$LAB/data/$(basename "$d")" ] || cp -R "$d" "$LAB/data/"
done
chmod -R u+w "$TMPX" 2>/dev/null || true
rm -rf "${TMPX:?}"
echo "  lab code: $(grep -m1 "^ZZ_CODE" "$LAB/tools/zigzag_campaign.py" || echo unknown)"

say "2/6 inputs"
XTR="$WORK/extracted-inputs"; mkdir -p "$XTR"
sha() { shasum -a 256 "$1" | cut -d' ' -f1; }
ROM=$(find -L "$INPUTS" -type f -iname '*.z64' ! -path "*/runs/*" 2>/dev/null | head -n 1 || true)
if [ -z "$ROM" ]; then
  while IFS= read -r z; do
    m=$(unzip -Z1 "$z" 2>/dev/null | grep -i -E '\.z64$' | head -n 1 || true)
    if [ -n "$m" ]; then unzip -q -o -j "$z" "$m" -d "$XTR" && ROM="$XTR/$(basename "$m")" && break; fi
  done < <(find -L "$INPUTS" -type f -iname '*.zip' ! -path "*/runs/*" 2>/dev/null)
fi
[ -n "$ROM" ] || die "no *.z64 ROM under $INPUTS"
RS=$(sha "$ROM")
[ "$RS" = "$ROM_SHA" ] && echo "  ROM      $ROM  (sha256 OK, NYWE rev00)" || echo "  WARNING: ROM sha256 $RS is not the known NYWE rev00 dump ($ROM)"

SPX="$XTR/dogspots"; mkdir -p "$SPX"
LIST="$WORK/.saves-$STAMP.txt"; : > "$LIST"
while IFS= read -r z; do
  zn=$(basename "$z" .zip | tr -c 'A-Za-z0-9._-' '-')
  mkdir -p "$SPX/$zn"
  unzip -q -o "$z" -d "$SPX/$zn" >/dev/null 2>&1 || true
done < <(find -L "$SPOTS" -type f -iname '*.zip' 2>/dev/null)
order_of() {
  local b
  b=$(basename "$(dirname "$1")")
  case "$b" in ''|*[!0-9]*) echo 0 ;; *) echo "$((10#$b))" ;; esac
}
S9SAVE=""; DOGSAVE=""
while IFS= read -r f; do
  case "$f" in */__MACOSX/*|*/._*) continue ;; esac
  s=$(sha "$f")
  [ "$s" = "$SPRING9_SHA" ] && continue
  case "$f" in "$SPX"/*) src=1 ;; *) src=0 ;; esac
  printf '%06d|%s|%d|%s|%s\n' "$(order_of "$f")" "$(basename "$f")" "$src" "$s" "$f" >> "$LIST"
done < <(find -L "$SPOTS" "$SPX" -type f \( -iname '*.SaveRAM' -o -iname '*.sra' -o -iname '*.sav' -o -iname '*.srm' \) 2>/dev/null)
while IFS= read -r f; do
  s=$(sha "$f")
  [ "$s" = "$SPRING9_SHA" ] && [ -z "$S9SAVE" ] && S9SAVE="$f"
  [ "$s" = "$DOGBEACH_SHA" ] && [ -z "$DOGSAVE" ] && DOGSAVE="$f"
done < <(find -L "$INPUTS" -maxdepth 1 -type f \( -iname '*.SaveRAM' -o -iname '*.sra' -o -iname '*.sav' \) 2>/dev/null)
if [ "${HM64_DOGSPOTS_CONTROL:-0}" = 1 ]; then
  [ -n "$DOGSAVE" ] || die "HM64_DOGSPOTS_CONTROL=1 but the dog-beach save (sha256 0d78b95b...) is not in sourcefiles/"
  printf '%06d|%s|%d|%s|%s\n' 999999 control 0 "$DOGBEACH_SHA" "$DOGSAVE" >> "$LIST"
fi
mkdir -p "$LAB/data/rom" "$LAB/data/saves" "$LAB/data/saves_dogspots"
chmod -R u+w "$LAB/data" 2>/dev/null || true
cp "$ROM" "$LAB/data/rom/Harvest_Moon_64_USA.z64"
[ -n "$S9SAVE" ] && cp "$S9SAVE" "$LAB/data/saves/Harvest_Moon_64_USA3.SaveRAM"
echo "  order: numbered folders first by number (dogspots/1, 2, 3, ...), then file name"
LABELS=()
SEEN=" "
while IFS='|' read -r n bn src s f; do
  [ -n "$s" ] || continue
  case "$SEEN" in *" $s "*) echo "  skipping $f (same bytes as a save already listed)"; continue ;; esac
  SEEN="$SEEN$s "
  base=$(basename "$f"); base="${base%.*}"
  case "$base" in "Harvest Moon 64"*").") ;; "Harvest Moon 64"*")."*) base="${base#*).}" ;; esac
  num=$((10#$n))
  if [ "$s" = "$DOGBEACH_SHA" ] && { [ "$num" -eq 0 ] || [ "$num" -eq 999999 ]; }; then base="control-dogbeach"; fi
  clean=$(printf '%s' "$base" | tr -c 'A-Za-z0-9._-' '-' | sed 's/--*/-/g; s/^-//; s/-$//' | cut -c1-32)
  if [ "$num" -gt 0 ] && [ "$num" -lt 999999 ]; then label="$num-$clean-${s:0:8}"; else label="$clean-${s:0:8}"; fi
  if [ -n "${HM64_DOGSPOTS_ONLY:-}" ]; then
    case "$label" in *"$HM64_DOGSPOTS_ONLY"*) ;; *) continue ;; esac
  fi
  cp "$f" "$LAB/data/saves_dogspots/$label.SaveRAM"
  LABELS+=("$label")
  echo "  save $(( ${#LABELS[@]} ))   $label   <- $f"
done < <(sort -t'|' -k1,1 -k2,2 -k3,3n "$LIST")
rm -f "$LIST"
[ "${#LABELS[@]}" -gt 0 ] || die "no dog-spot saves found in $SPOTS (put your *.SaveRAM files there)"
echo "  ${#LABELS[@]} save(s), run in this order; each: the whole recipe + fast cast tables, then its results and zip are printed before the next starts"
if [ "${HM64_DRY_RUN:-0}" = 1 ]; then echo; echo "DRY RUN: inputs found as above; stopping before Docker."; exit 0; fi
chmod -R a+rwX "$LAB/states" "$LAB/results" "$LAB/experiments" 2>/dev/null || true

say "3/6 building the Docker image (first time: several minutes)"
cd "$LAB"
# shellcheck disable=SC2086
docker build --platform linux/amd64 -t hm64-lab:latest --build-arg INSTALL_CLAUDE="${INSTALL_CLAUDE:-1}" \
  ${HM64_DOCKER_BUILD_EXTRA:-} .
if [ -z "$WORKERS" ]; then
  NCPU=$(docker run --rm --platform linux/amd64 hm64-lab:latest nproc 2>/dev/null || echo 2)
  WORKERS=$(( NCPU > 1 ? NCPU - 1 : 1 ))
fi

say "4/6 lab health test"
if [ -n "$S9SAVE" ]; then
  docker compose run --rm -T lab bash -lc 'python3 tools/smoke_test.py' \
    || die "smoke test failed - see $LOG (results would not be trustworthy)"
else
  echo "  skipped (no Spring 9 save); every save starts with its own repeatability record (Z0)"
fi

say "5/6 dog-spot runs ($PRESET, $WORKERS workers), one save after the other"
mkdir -p "$LAB/$RES"
FAILED=()
SZIPS=()
i=0
for label in "${LABELS[@]}"; do
  i=$((i + 1))
  say "save $i/${#LABELS[@]}: $label"
  T0=$(date +%s)
  rc=0
  docker compose run --rm -T -e HM64_SRAM="/work/data/saves_dogspots/$label.SaveRAM" \
    -e HM64_ZZ_STORE="/work/states/dogspots/$label" -e HM64_CORE_FILE=/work/results/core.json \
    -e HM64_ZZ_STOP_AFTER="${HM64_ZZ_STOP_AFTER:-}" -e HM64_ZZ_MAX_LINES="${HM64_ZZ_MAX_LINES:-0}" \
    -e M64H_CPU="${M64H_CPU:-}" -e M64H_RECYCLE="${M64H_RECYCLE:-6}" lab \
    python3 tools/zigzag_campaign.py --preset "$PRESET" --workers "$WORKERS" --out "$RES/$label" \
    </dev/null || rc=$?
  if [ "$rc" != 0 ]; then
    echo "  save $label stopped (exit $rc) - see its ZIGZAG.md; going on with the next save"
    FAILED+=("$label")
  fi
  echo
  echo "------------------------------------------------------------------------------------------------"
  echo " FAST RESULTS  save $i/${#LABELS[@]}  $label   ($(( ($(date +%s) - T0) / 60 )) min)"
  echo "------------------------------------------------------------------------------------------------"
  docker compose run --rm -T lab python3 tools/dogspots_report.py --one "$RES/$label" </dev/null || true
  docker compose run --rm -T lab python3 tools/dogspots_report.py "$RES" </dev/null >/dev/null 2>&1 || true
  SZIP="$RUN_ROOT/hm64-$PRESET-$label-$STAMP.zip"
  if [ -d "$LAB/$RES/$label" ] && \
     ( cd "$LAB/$RES" && zip -q -r "$SZIP" "$label" $(ls DOGSPOTS.md dogspots.json 2>/dev/null) ); then
    SZIPS+=("$SZIP")
    echo "  report       $LAB/$RES/$label/ZIGZAG.md"
    echo "  zip          $SZIP"
  else
    echo "  (no results folder / zip for $label)"
  fi
  echo "------------------------------------------------------------------------------------------------"
done

say "6/6 comparison + results"
docker compose run --rm -T lab python3 tools/dogspots_report.py "$RES" </dev/null || echo "  (comparison report failed - the per-save reports are still in the zip)"
OUTZIP="$RUN_ROOT/hm64-$PRESET-$STAMP.zip"
cp "$LOG" "$LAB/$RES/run-$PRESET-$STAMP.log" 2>/dev/null || true
( cd "$LAB/results" && zip -q -r "$OUTZIP" "$PRESET" ) || die "zip failed"
echo
echo "DONE."
echo "  comparison : $LAB/$RES/DOGSPOTS.md"
if [ "${#FAILED[@]}" -gt 0 ]; then echo "  stopped    : ${FAILED[*]}"; fi
if [ "${#SZIPS[@]}" -gt 0 ]; then for z in "${SZIPS[@]}"; do echo "  per save   : $z"; done; fi
echo "  zip        : $OUTZIP   (all saves + comparison; no ROM/saves/savestates inside; send this one)"
