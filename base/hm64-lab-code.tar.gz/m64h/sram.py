"""
HM64 save conversion. Accepts any of:
  - BizHawk .SaveRAM (296960 bytes: eeprom 0x800 | mempaks 4x0x8000 | flash 0x20000 | SRAM 0x8000)
  - raw cart SRAM dump, big-endian (Joey64 / real cart order) - 32768 bytes
  - mupen64plus .sra (32-bit word-swapped) - 32768 bytes
and returns mupen64plus .sra bytes. Detection uses HM64's own signature
"PACKINSOFT FARM2" (gameFile.c: sramSignature), so it cannot silently pick
the wrong byte order.
"""
from __future__ import annotations

SIG = b"PACKINSOFT FARM2"
SRAM_SIZE = 0x8000
BIZHAWK_SAVERAM_SIZE = 0x48800
BIZHAWK_SRAM_OFFSET = 0x40800
SLOT_SIZE = 0x1000


def wordswap(b: bytes) -> bytes:
    if len(b) % 4:
        raise ValueError("length must be a multiple of 4")
    return b"".join(b[i:i + 4][::-1] for i in range(0, len(b), 4))


def _find_sig(be: bytes):
    return [i for i in range(0, len(be), SLOT_SIZE) if be[i:i + 16] == SIG]


def detect(data: bytes) -> tuple[str, bytes]:
    """Return (kind, big_endian_sram)."""
    if len(data) == BIZHAWK_SAVERAM_SIZE:
        region = data[BIZHAWK_SRAM_OFFSET:BIZHAWK_SRAM_OFFSET + SRAM_SIZE]
        for kind, be in (("bizhawk-saveram", wordswap(region)), ("bizhawk-saveram(be)", region)):
            if _find_sig(be):
                return kind, be
        raise ValueError("BizHawk SaveRAM has no HM64 diary signature in its SRAM region")
    if len(data) == SRAM_SIZE:
        if _find_sig(data):
            return "cart-sram-bigendian", data
        if _find_sig(wordswap(data)):
            return "mupen-sra", wordswap(data)
        raise ValueError("32 KB file has no 'PACKINSOFT FARM2' signature in either byte order")
    raise ValueError(f"unrecognised save size {len(data)} bytes")


def to_mupen_sra(data: bytes) -> bytes:
    _, be = detect(data)
    return wordswap(be)


def to_bigendian(data: bytes) -> bytes:
    return detect(data)[1]


def slots(data: bytes) -> list[int]:
    """Diary slots (0-based) that hold a valid signature."""
    return [i // SLOT_SIZE for i in _find_sig(detect(data)[1])]
