"""
m64h.core - a headless, VI-stepped mupen64plus driver for experiments.

One Emulator per *process* (libmupen64plus keeps global state). For parallel
work use m64h.pool, which forks worker processes.

Mental model (think of it like a debugger, not a player):
  - The emulator runs on a background thread.
  - Every vertical interrupt (VI = one BizHawk "frame", 60/s NTSC) the video
    hook calls back into Python. When the harness has no more VIs "budgeted",
    that callback blocks, which freezes the whole N64 between frames.
  - While frozen, the main thread can read/write RDRAM, change controller
    input, request savestates, etc. Then advance(n) lets n more VIs run.

Frame numbering: emu.vi is the count of VIs since power-on (or since the VI
stored with a loaded state). After advance(1) you are paused right after
VI number emu.vi was processed. Inputs set while paused are what the game
sees on its next controller poll.
"""
from __future__ import annotations

import ctypes as C
import json
import os
import shutil
import struct
import tempfile
import threading
from pathlib import Path
from typing import Callable, Iterable

from .buttons import encode_buttons

# ---------------------------------------------------------------- constants
M64ERR_SUCCESS = 0
M64PLUGIN_RSP, M64PLUGIN_GFX, M64PLUGIN_AUDIO, M64PLUGIN_INPUT = 1, 2, 3, 4
M64TYPE_INT, M64TYPE_FLOAT, M64TYPE_BOOL, M64TYPE_STRING = 1, 2, 3, 4
(M64CMD_NOP, M64CMD_ROM_OPEN, M64CMD_ROM_CLOSE, M64CMD_ROM_GET_HEADER,
 M64CMD_ROM_GET_SETTINGS, M64CMD_EXECUTE, M64CMD_STOP, M64CMD_PAUSE,
 M64CMD_RESUME, M64CMD_CORE_STATE_QUERY, M64CMD_STATE_LOAD, M64CMD_STATE_SAVE,
 M64CMD_STATE_SET_SLOT, M64CMD_SEND_SDL_KEYDOWN, M64CMD_SEND_SDL_KEYUP,
 M64CMD_SET_FRAME_CALLBACK, M64CMD_TAKE_NEXT_SCREENSHOT, M64CMD_CORE_STATE_SET,
 M64CMD_READ_SCREEN, M64CMD_RESET) = range(20)
M64CORE_EMU_STATE = 1
M64CORE_SPEED_LIMITER = 5
M64CORE_STATE_LOADCOMPLETE = 10
M64CORE_STATE_SAVECOMPLETE = 11
M64CORE_SCREENSHOT_CAPTURED = 12
M64P_DBG_PTR_RDRAM = 1
FRONTEND_API_VERSION = 0x020106
RDRAM_BYTES = 0x800000          # core always allocates 8 MB

DEBUG_CB = C.CFUNCTYPE(None, C.c_void_p, C.c_int, C.c_char_p)
STATE_CB = C.CFUNCTYPE(None, C.c_void_p, C.c_int, C.c_int)
VI_CB = C.CFUNCTYPE(None, C.c_uint)
POLL_CB = C.CFUNCTYPE(C.c_uint, C.c_int, C.c_uint)

HERE = Path(__file__).resolve().parent
DEFAULT_BUNDLE = Path(os.environ.get("M64H_BUNDLE", "/opt/mupen64plus"))
DEFAULT_NATIVE = Path(os.environ.get("M64H_NATIVE", HERE.parent / "native" / "build"))
REAL_VIDEO = {
    "rice": "mupen64plus-video-rice.so",
    "glide64mk2": "mupen64plus-video-glide64mk2.so",
}

_INSTANCE_ALIVE = False


class EmuError(RuntimeError):
    pass


class Emulator:
    """Headless HM64-ready mupen64plus instance.

    mode='fast'   : null renderer, no audio. Fastest; RAM-only experiments.
    mode='visual' : real renderer (rice by default) for screenshots. Needs an
                    X display (run under xvfb-run or with DISPLAY set).
    """

    def __init__(self, rom: str | Path, *, sram: str | Path | bytes | None = None,
                 mode: str = "fast", video: str = "rice", cpu: str = "dynarec",
                 workdir: str | Path | None = None, bundle: str | Path | None = None,
                 native: str | Path | None = None, verbose: bool = False,
                 timeout: float = 120.0, randomize_interrupt: bool = False):
        global _INSTANCE_ALIVE
        if _INSTANCE_ALIVE:
            raise EmuError("only one Emulator per process; use m64h.pool for parallel runs")
        self.rom_path = Path(rom)
        self.mode = mode
        self.video = video
        self.cpu = {"interpreter": 0, "cached": 1, "dynarec": 2}[cpu]
        self.bundle = Path(bundle or DEFAULT_BUNDLE)
        self.native = Path(native or DEFAULT_NATIVE)
        self.verbose = verbose
        self.timeout = timeout
        # mupen 2.6 defaults this to True and seeds it with srand(time(NULL)):
        # PI/SI interrupts get 0-63 cycles of wall-clock-random jitter. Keep it
        # False for reproducible science; True only to imitate legacy runs.
        self.randomize_interrupt = randomize_interrupt
        self._reset_at_vi = None
        self._until = None
        self._until_hit = False
        self._until_exc = None
        self._poll_fn = None
        self._poll_cb = None
        self._own_workdir = workdir is None
        self.workdir = Path(workdir or tempfile.mkdtemp(prefix="m64h-"))
        for sub in ("config", "save", "states", "shots"):
            (self.workdir / sub).mkdir(parents=True, exist_ok=True)
        self.log: list[str] = []
        self._sram = sram
        self.vi = 0
        self._budget = 0
        self._listeners: list[Callable[["Emulator"], None]] = []
        self._paused = threading.Event()
        self._go = threading.Event()
        self._task = None
        self._task_result = None
        self._task_done = threading.Event()
        self._stopped = threading.Event()
        self._state_events: dict[int, threading.Event] = {}
        self._state_results: dict[int, int] = {}
        self._pending_vi_after_load: int | None = None
        self._thread: threading.Thread | None = None
        self._exec_error: int | None = None
        self._ram8 = None
        self._ram32 = None
        self._ram16 = None
        self._plugins: dict[int, C.CDLL] = {}
        self.capture = mode == "visual"   # grab every rendered frame (visual mode)
        self._frame_buf = None
        self._last_frame = None
        _INSTANCE_ALIVE = True
        self._load_core()

    # ------------------------------------------------------------ lifecycle
    def _check(self, err, what):
        if err != M64ERR_SUCCESS:
            msg = self.core.CoreErrorMessage(err)
            raise EmuError(f"{what} failed: {err} {msg.decode() if msg else ''}")

    def _load_core(self):
        core_path = self.bundle / "libmupen64plus.so.2"
        self.core = C.CDLL(str(core_path), mode=C.RTLD_GLOBAL)
        self.core.CoreErrorMessage.restype = C.c_char_p
        self.core.DebugMemGetPointer.restype = C.c_void_p
        self.core.CoreDoCommand.argtypes = [C.c_int, C.c_int, C.c_void_p]
        self.core.ConfigSetParameter.argtypes = [C.c_void_p, C.c_char_p, C.c_int, C.c_void_p]
        self.core.ConfigOpenSection.argtypes = [C.c_char_p, C.POINTER(C.c_void_p)]

        self._debug_cb = DEBUG_CB(self._on_debug)
        self._state_cb = STATE_CB(self._on_state)
        self._vi_cb = VI_CB(self._on_vi)
        self._frame_cb = VI_CB(self._on_frame)
        err = self.core.CoreStartup(FRONTEND_API_VERSION,
                                    str(self.workdir / "config").encode(),
                                    str(self.bundle).encode(),
                                    None, self._debug_cb, None, self._state_cb)
        self._check(err, "CoreStartup")
        self._configure()

    def _set(self, section: str, name: str, value):
        h = C.c_void_p()
        self._check(self.core.ConfigOpenSection(section.encode(), C.byref(h)), f"open {section}")
        if isinstance(value, bool):
            v = C.c_int(int(value)); t = M64TYPE_BOOL
        elif isinstance(value, int):
            v = C.c_int(value); t = M64TYPE_INT
        elif isinstance(value, float):
            v = C.c_float(value); t = M64TYPE_FLOAT
        else:
            v = C.create_string_buffer(str(value).encode()); t = M64TYPE_STRING
        self._check(self.core.ConfigSetParameter(h, name.encode(), t, C.cast(C.pointer(v), C.c_void_p)
                                                 if t != M64TYPE_STRING else C.cast(v, C.c_void_p)),
                    f"set {section}/{name}")

    def _configure(self):
        w = self.workdir
        self._set("Core", "OnScreenDisplay", False)
        self._set("Core", "R4300Emulator", self.cpu)
        self._set("Core", "RandomizeInterrupt", bool(self.randomize_interrupt))   # 2.6 default True -> nondeterminism
        self._set("Core", "AutoStateSlotIncrement", False)
        self._set("Core", "SaveFilenameFormat", 0)        # <header name>.sra
        self._set("Core", "SaveSRAMPath", str(w / "save") + "/")
        self._set("Core", "SaveStatePath", str(w / "states") + "/")
        self._set("Core", "ScreenshotPath", str(w / "shots") + "/")
        self._set("Core", "SharedDataPath", str(self.bundle))
        self._set("Video-General", "Fullscreen", False)
        self._set("Video-General", "ScreenWidth", 640)
        self._set("Video-General", "ScreenHeight", 480)

    def _load_plugin(self, path: Path, ptype: int):
        lib = C.CDLL(str(path), mode=C.RTLD_LOCAL)
        err = lib.PluginStartup(C.c_void_p(self.core._handle), None, self._debug_cb)
        self._check(err, f"PluginStartup {path.name}")
        self._plugins[ptype] = lib
        return lib

    def start(self) -> "Emulator":
        """Open the ROM, attach plugins, boot, and pause at VI 1."""
        if self.mode == "visual":
            os.environ["M64H_REAL_VIDEO"] = str(self.bundle / REAL_VIDEO[self.video])
        else:
            os.environ.pop("M64H_REAL_VIDEO", None)
        rom = self.rom_path.read_bytes()
        if rom[:4] != b"\x80\x37\x12\x40":
            raise EmuError(f"{self.rom_path} is not a big-endian .z64 (got {rom[:4].hex()}); "
                           "convert .n64/.v64 to .z64 first")
        if self._sram is not None:
            header = rom[0x20:0x34].decode("ascii", "replace").strip()
            data = self._sram if isinstance(self._sram, (bytes, bytearray)) else Path(self._sram).read_bytes()
            from .sram import to_mupen_sra
            (self.workdir / "save" / f"{header}.sra").write_bytes(to_mupen_sra(data))

        self.gfx = self._load_plugin(self.native / "mupen64plus-video-hook.so", M64PLUGIN_GFX)
        self.inp = self._load_plugin(self.native / "mupen64plus-input-script.so", M64PLUGIN_INPUT)
        self.rsp = self._load_plugin(self.bundle / "mupen64plus-rsp-hle.so", M64PLUGIN_RSP)
        self._buttons = (C.c_uint * 4).in_dll(self.inp, "script_buttons")
        self._polls = (C.c_uint * 4).in_dll(self.inp, "script_poll_count")
        self._sched_poll = (C.c_uint * 8192).in_dll(self.inp, "script_sched_poll")
        self._sched_value = (C.c_uint * 8192).in_dll(self.inp, "script_sched_value")
        self._sched_len = C.c_int.in_dll(self.inp, "script_sched_len")
        self._sched_pos = C.c_int.in_dll(self.inp, "script_sched_pos")
        self._sched_armed = C.c_int.in_dll(self.inp, "script_sched_armed")
        self._sched_pending = False
        self.gfx.hook_set_vi_callback(self._vi_cb)

        self._rom_buf = C.create_string_buffer(rom, len(rom))
        self._check(self.core.CoreDoCommand(M64CMD_ROM_OPEN, len(rom), self._rom_buf), "ROM_OPEN")
        for ptype in (M64PLUGIN_GFX, M64PLUGIN_INPUT, M64PLUGIN_RSP):   # audio stays dummy
            self._check(self.core.CoreAttachPlugin(ptype, C.c_void_p(self._plugins[ptype]._handle)),
                        f"attach plugin {ptype}")

        if self.mode == "visual":
            self._check(self.core.CoreDoCommand(M64CMD_SET_FRAME_CALLBACK, 0,
                                                C.cast(self._frame_cb, C.c_void_p)), "SET_FRAME_CALLBACK")
        self._thread = threading.Thread(target=self._exec, name="m64p-exec", daemon=True)
        self._thread.start()
        self._wait_paused()
        limiter = C.c_int(0)
        self.core.CoreDoCommand(M64CMD_CORE_STATE_SET, M64CORE_SPEED_LIMITER, C.byref(limiter))
        ptr = self.core.DebugMemGetPointer(M64P_DBG_PTR_RDRAM)
        if not ptr:
            raise EmuError("DebugMemGetPointer(RDRAM) returned NULL")
        self._ram8 = (C.c_uint8 * RDRAM_BYTES).from_address(ptr)
        self._ram16 = (C.c_uint16 * (RDRAM_BYTES // 2)).from_address(ptr)
        self._ram32 = (C.c_uint32 * (RDRAM_BYTES // 4)).from_address(ptr)
        return self

    def _exec(self):
        try:
            self._exec_error = self.core.CoreDoCommand(M64CMD_EXECUTE, 0, None)
        finally:
            self._stopped.set()
            self._paused.set()

    def close(self):
        global _INSTANCE_ALIVE
        if self._thread and self._thread.is_alive():
            self.core.CoreDoCommand(M64CMD_STOP, 0, None)
            self._budget = 1 << 30
            self._go.set()
            self._thread.join(timeout=10)
        if self._thread:
            for ptype in (M64PLUGIN_GFX, M64PLUGIN_INPUT, M64PLUGIN_RSP):
                self.core.CoreDetachPlugin(ptype)
            self.core.CoreDoCommand(M64CMD_ROM_CLOSE, 0, None)
        for lib in self._plugins.values():
            lib.PluginShutdown()
        self.core.CoreShutdown()
        if self._own_workdir:
            shutil.rmtree(self.workdir, ignore_errors=True)
        _INSTANCE_ALIVE = False

    def __enter__(self):
        return self.start()

    def __exit__(self, *exc):
        self.close()

    # ------------------------------------------------------------ callbacks
    def _on_debug(self, _ctx, level, msg):
        text = msg.decode(errors="replace") if msg else ""
        self.log.append(f"{level}: {text}")
        if self.verbose or level == 1:
            print(f"[m64p {level}] {text}", flush=True)

    def _on_state(self, _ctx, param, value):
        if param == M64CORE_STATE_LOADCOMPLETE and value:
            # runs on the emu thread inside savestates_load(): nothing has
            # polled the controller yet, so this is the exact poll origin
            for i in range(4):
                self._polls[i] = 0
            self._sched_pos.value = 0
            self._sched_armed.value = 1 if self._sched_pending else 0
            self._buttons[0] = 0
            if self._pending_vi_after_load is not None:
                self.vi = self._pending_vi_after_load
                self._pending_vi_after_load = None
        ev = self._state_events.get(param)
        if ev is not None:
            self._state_results[param] = value
            ev.set()

    def _on_vi(self, _hook_count):
        self.vi += 1
        if self._reset_at_vi is not None and self.vi == self._reset_at_vi:
            self._reset_at_vi = None
            self.core.CoreDoCommand(M64CMD_RESET, 1, None)   # hard reset, on the emu thread
        for fn in self._listeners:
            fn(self)
        if self._until is not None:
            try:
                hit = self._until(self)
            except Exception as exc:              # surface on the main thread
                hit, self._until_exc = True, exc
            if hit:
                self._until_hit = True
                self._until = None
                self._budget = 1                  # pause right after this VI
        if self._budget > 1:
            self._budget -= 1
            return
        self._budget = 0
        self._paused.set()
        # Paused between VIs. The main thread may hand us small jobs that must
        # run on this thread (anything touching the GL context, e.g. screenshots).
        while True:
            self._go.wait()
            self._go.clear()
            task, self._task = self._task, None
            if task is None:
                break
            try:
                self._task_result = task()
            except Exception as exc:          # surfaced in _on_emu_thread
                self._task_result = exc
            self._task_done.set()

    def _on_emu_thread(self, fn):
        """Run fn() on the emulator thread while paused; return its result."""
        self._task_done.clear()
        self._task = fn
        self._go.set()
        if not self._task_done.wait(self.timeout):
            raise EmuError("emulator thread did not run the task")
        result = self._task_result
        if isinstance(result, Exception):
            raise result
        return result

    def _wait_paused(self):
        if not self._paused.wait(self.timeout):
            raise EmuError(f"emulator did not reach a VI within {self.timeout}s")
        if self._stopped.is_set():
            raise EmuError(f"emulation stopped (EXECUTE returned {self._exec_error}); "
                           f"last log: {self.log[-5:]}")

    # ------------------------------------------------------------ stepping
    def advance(self, n: int = 1) -> "Emulator":
        """Run exactly n VIs, then pause."""
        if n <= 0:
            return self
        self._paused.clear()
        self._budget = n
        self._go.set()
        self._wait_paused()
        return self

    def advance_until(self, predicate: Callable[["Emulator"], bool], max_vi: int) -> bool:
        """Run up to max_vi VIs, evaluating predicate(emu) on the emulator thread
        after every VI; pause right after the first VI where it is true.
        Much faster than a Python loop of advance(1). Returns True if hit."""
        self._until_hit = False
        self._until_exc = None
        self._until = predicate
        try:
            self.advance(max_vi)
        finally:
            self._until = None
        if self._until_exc is not None:
            raise self._until_exc
        return self._until_hit

    def run_until(self, predicate: Callable[["Emulator"], bool], max_vi: int,
                  step: int = 1) -> int:
        """Advance until predicate(emu) is true. Returns VIs advanced, or -1."""
        start = self.vi
        while self.vi - start < max_vi:
            if predicate(self):
                return self.vi - start
            self.advance(step)
        return self.vi - start if predicate(self) else -1

    def add_listener(self, fn: Callable[["Emulator"], None]):
        """fn(emu) runs on the emulator thread after every VI (cheap per-VI logging)."""
        self._listeners.append(fn)
        return fn

    def remove_listener(self, fn):
        self._listeners.remove(fn)

    # ------------------------------------------------------------ input
    def set_input(self, *buttons: str, x: int = 0, y: int = 0, port: int = 0):
        """Hold these buttons (A B Z START L R DU DD DL DR CU CD CL CR) and stick until changed."""
        self._buttons[port] = encode_buttons(buttons, x, y)

    def release(self, port: int = 0):
        self._buttons[port] = 0

    def press(self, *buttons: str, hold: int = 2, after: int = 2, x: int = 0, y: int = 0):
        """Hold for `hold` VIs, release, then run `after` more VIs."""
        self.set_input(*buttons, x=x, y=y)
        self.advance(hold)
        self.release()
        self.advance(after)

    def schedule_polls(self, events, arm_on_load: bool = True):
        """Poll-exact input for controller 0, applied inside the input plugin.

        events: iterable of (poll_index, buttons, x, y) or (poll_index, buttons)
        where buttons is a list of names. poll_index is 0-based, counted from
        the moment the NEXT load_state completes (arm_on_load=True) or from
        now (arm_on_load=False, counter reset immediately).
        Example (QuickSave2 'win424'): [(424, ['B']), (1634, [])]
        """
        evs = sorted(((e[0], encode_buttons(e[1], *(e[2:4] if len(e) > 2 else (0, 0))))
                      for e in events), key=lambda t: t[0])
        if len(evs) > 8192:
            raise EmuError("too many scheduled events")
        self._sched_armed.value = 0
        for i, (p, v) in enumerate(evs):
            self._sched_poll[i] = p
            self._sched_value[i] = v
        self._sched_len.value = len(evs)
        self._sched_pos.value = 0
        if arm_on_load:
            self._sched_pending = True
        else:
            self._polls[0] = 0
            self._sched_armed.value = 1

    def clear_schedule(self):
        self._sched_armed.value = 0
        self._sched_len.value = 0
        self._sched_pending = False

    def schedule_hard_reset(self, at_vi: int):
        """Hard-reset the console inside VI number `at_vi` (emu thread), like the
        legacy runner's HM64_CORE_RESET_AT (its callback k == our VI k+1)."""
        self._reset_at_vi = at_vi

    def set_poll_callback(self, fn):
        """fn(poll_index) -> BUTTONS value (int), called by the input plugin at
        every controller-0 read, on the emulator thread. None to remove."""
        if fn is None:
            self._poll_fn = None
            self._poll_cb = None
            self.inp.script_set_poll_callback(None)
            return
        self._poll_fn = fn

        def cb(_port, n):
            try:
                return int(self._poll_fn(n)) & 0xFFFFFFFF
            except Exception as exc:          # never let an exception cross into C
                self.log.append(f"poll callback error at poll {n}: {exc!r}")
                return 0
        self._poll_cb = POLL_CB(cb)
        self.inp.script_set_poll_callback(self._poll_cb)

    def polls(self, port: int = 0) -> int:
        """How many times the game has read this controller (detect lag / poll timing)."""
        return self._polls[port]

    # ------------------------------------------------------------ memory
    @staticmethod
    def _phys(addr: int) -> int:
        return addr & 0x7FFFFF

    def u8(self, addr: int) -> int:
        return self._ram8[self._phys(addr) ^ 3]

    def u16(self, addr: int) -> int:
        return self._ram16[(self._phys(addr) ^ 2) >> 1]

    def u32(self, addr: int) -> int:
        return self._ram32[self._phys(addr) >> 2]

    def s8(self, addr): v = self.u8(addr); return v - 0x100 if v & 0x80 else v
    def s16(self, addr): v = self.u16(addr); return v - 0x10000 if v & 0x8000 else v
    def s32(self, addr): v = self.u32(addr); return v - 0x100000000 if v & 0x80000000 else v

    def f32(self, addr: int) -> float:
        return struct.unpack("<f", struct.pack("<I", self.u32(addr)))[0]

    def w8(self, addr: int, v: int): self._ram8[self._phys(addr) ^ 3] = v & 0xFF
    def w16(self, addr: int, v: int): self._ram16[(self._phys(addr) ^ 2) >> 1] = v & 0xFFFF
    def w32(self, addr: int, v: int): self._ram32[self._phys(addr) >> 2] = v & 0xFFFFFFFF

    def read(self, addr: int, length: int) -> bytes:
        """Big-endian (N64 order) bytes, as you'd see them in a hex editor / decomp."""
        a = self._phys(addr)
        start, end = a & ~3, (a + length + 3) & ~3
        raw = bytes(self._ram8[start:end])
        be = b"".join(raw[i:i + 4][::-1] for i in range(0, len(raw), 4))
        return be[a - start:a - start + length]

    # ------------------------------------------------------------ savestates
    def _wait_state(self, param: int, what: str) -> int:
        ev = threading.Event()
        self._state_events[param] = ev
        try:
            for _ in range(600):           # count steps, not self.vi (a load rewrites it)
                self.advance(1)
                if ev.is_set():
                    return self._state_results.pop(param)
            raise EmuError(f"{what} never completed")
        finally:
            self._state_events.pop(param, None)

    def save_state(self, path: str | Path, meta: dict | None = None) -> Path:
        """Snapshot taken right after the current VI. Leaves you exactly 1 VI later.

        mupen64plus 2.6 captures the machine state synchronously at the end of
        the current VI interrupt, then gzips/writes the file on a worker
        thread. So: advance exactly one VI (capture happens), then wait for the
        worker WITHOUT emulating further - otherwise the number of VIs that
        pass depends on disk/CPU speed and determinism is lost.
        """
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        vi_at = self.vi
        ev = threading.Event()
        self._state_events[M64CORE_STATE_SAVECOMPLETE] = ev
        try:
            buf = C.create_string_buffer(str(path).encode())
            self._check(self.core.CoreDoCommand(M64CMD_STATE_SAVE, 1, buf), "STATE_SAVE")
            self.advance(1)
            if not ev.wait(self.timeout):
                raise EmuError(f"save_state({path}): writer thread never finished")
            if not self._state_results.pop(M64CORE_STATE_SAVECOMPLETE):
                raise EmuError(f"save_state({path}) failed")
        finally:
            self._state_events.pop(M64CORE_STATE_SAVECOMPLETE, None)
        info = {"vi": vi_at, "rom": self.rom_path.name, **(meta or {})}
        path.with_suffix(path.suffix + ".json").write_text(json.dumps(info, indent=1))
        return path

    def load_state(self, path: str | Path) -> dict:
        """Restore a state; afterwards you are paused at the VI after the saved one."""
        path = Path(path)
        info = json.loads(path.with_suffix(path.suffix + ".json").read_text()) \
            if path.with_suffix(path.suffix + ".json").exists() else {"vi": 0}
        self._pending_vi_after_load = info["vi"]
        buf = C.create_string_buffer(str(path).encode())
        self._check(self.core.CoreDoCommand(M64CMD_STATE_LOAD, 0, buf), "STATE_LOAD")
        ok = self._wait_state(M64CORE_STATE_LOADCOMPLETE, "load_state")
        if not ok:
            raise EmuError(f"load_state({path}) failed")
        self._sched_pending = False
        if not self._sched_armed.value:
            self.release()
        return info

    # ------------------------------------------------------------ video
    def _on_frame(self, _frame_index):
        """Core frame callback (emu thread, right after a display list renders,
        before the buffer swap) - the only reliable moment to read pixels."""
        if not self.capture:
            return
        w, h = C.c_int(0), C.c_int(0)
        self.gfx.ReadScreen2(None, C.byref(w), C.byref(h), 0)
        if w.value <= 0:
            return
        need = w.value * h.value * 3
        if self._frame_buf is None or len(self._frame_buf) != need:
            self._frame_buf = (C.c_uint8 * need)()
        self.gfx.ReadScreen2(self._frame_buf, C.byref(w), C.byref(h), 0)
        self._last_frame = (w.value, h.value, bytes(self._frame_buf), self.vi)

    def frame_image(self):
        """PIL image of the most recently rendered frame (visual mode)."""
        if self.mode != "visual":
            raise EmuError("frame capture needs mode='visual'")
        if self._last_frame is None:
            raise EmuError("no frame rendered yet")
        from PIL import Image
        w, h, raw, _ = self._last_frame
        img = Image.frombuffer("RGB", (w, h), raw, "raw", "RGB", 0, 1)
        return img.transpose(Image.FLIP_TOP_BOTTOM)

    def screenshot(self, path: str | Path) -> Path:
        """Save the most recently rendered frame as PNG (visual mode only)."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        self.frame_image().save(path)
        return path

    # ------------------------------------------------------------ misc
    def dump_sram(self) -> bytes:
        """The .sra the core has written so far (mupen word-swapped order)."""
        files = list((self.workdir / "save").glob("*.sra"))
        return files[0].read_bytes() if files else b""


def boot(rom, **kw) -> Emulator:
    return Emulator(rom, **kw).start()
