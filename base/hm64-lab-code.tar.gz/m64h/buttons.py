"""N64 controller encoding for mupen64plus BUTTONS.Value."""

BIT = {
    "DR": 0, "DL": 1, "DD": 2, "DU": 3, "START": 4, "Z": 5, "B": 6, "A": 7,
    "CR": 8, "CL": 9, "CD": 10, "CU": 11, "R": 12, "L": 13,
}
ALIASES = {
    "C_RIGHT": "CR", "C-RIGHT": "CR", "CRIGHT": "CR",
    "C_LEFT": "CL", "C-LEFT": "CL", "C_UP": "CU", "C_DOWN": "CD",
    "D_RIGHT": "DR", "D_LEFT": "DL", "D_UP": "DU", "D_DOWN": "DD", "S": "START",
}


def encode_buttons(buttons, x: int = 0, y: int = 0) -> int:
    """buttons: iterable of names. x/y: analog stick -128..127 (y>0 = up)."""
    v = 0
    for b in buttons:
        key = ALIASES.get(b.upper(), b.upper())
        if key not in BIT:
            raise ValueError(f"unknown button {b!r}; use one of {sorted(BIT)}")
        v |= 1 << BIT[key]
    v |= (int(x) & 0xFF) << 16
    v |= (int(y) & 0xFF) << 24
    return v


def decode_buttons(value: int):
    names = [n for n, b in BIT.items() if value & (1 << b)]
    x = (value >> 16) & 0xFF
    y = (value >> 24) & 0xFF
    x = x - 256 if x & 0x80 else x
    y = y - 256 if y & 0x80 else y
    return names, x, y
