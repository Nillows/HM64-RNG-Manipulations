"""
Run many emulator jobs in parallel: one Emulator per worker *process*
(libmupen64plus is a process-wide singleton).

    from m64h.pool import run_jobs
    for result in run_jobs(job_fn, jobs, rom=..., sram=..., workers=8):
        ...

job_fn(emu, job) -> dict  must be a top-level (importable) function.
Results stream back in completion order. Each result gets "_job" = job.
"""
from __future__ import annotations

import multiprocessing as mp
import os
import traceback

_emu = None
_fn = None


def _init(rom, sram, mode, fn_module, fn_name, extra_path, emu_kwargs=None):
    global _emu, _fn
    import importlib
    import sys
    for p in extra_path:
        if p not in sys.path:
            sys.path.insert(0, p)
    from m64h import Emulator
    _emu = Emulator(rom, sram=sram, mode=mode, **(emu_kwargs or {})).start()
    _fn = getattr(importlib.import_module(fn_module), fn_name)


def _run(job):
    try:
        out = _fn(_emu, job)
        out = dict(out or {})
    except Exception:
        out = {"_error": traceback.format_exc()}
    out["_job"] = job
    return out


def _worker_main(conn, rom, sram, mode, fn_module, fn_name, extra_path, emu_kwargs):
    _init(rom, sram, mode, fn_module, fn_name, extra_path, emu_kwargs)
    while True:
        try:
            job = conn.recv()
        except (EOFError, OSError):
            break
        if job is None:
            break
        conn.send(_run(job))


def run_jobs(job_fn, jobs, *, rom, sram=None, workers=None, mode="fast", chunksize=1,
             fresh=False, emu_kwargs=None, recycle=None, retries=3):
    """Supervised pool (2026-11-15). Each worker process owns one emulator and runs one job at a time.
    - A worker that dies (crash, abort, out of memory) costs only its current job: that job is given to a fresh
      worker again, up to `retries` times, then reported as an error row; nothing is lost and nothing hangs
      (multiprocessing.Pool silently lost such jobs and waited for them forever).
    - Workers are replaced after `recycle` jobs (env M64H_RECYCLE, default 6), so per-process memory that only grows
      (e.g. Rosetta's VmTracker under Docker on Apple silicon) is given back.
    - fresh=True: every job gets a brand-new process + emulator, paused at power-on VI 1 (cold-boot route jobs).
    - The CPU core comes from emu_kwargs["cpu"] or env M64H_CPU (dynarec | cached | interpreter)."""
    import collections
    from multiprocessing.connection import wait
    workers = workers or max(1, (os.cpu_count() or 2) - 1)
    ctx = mp.get_context("spawn")
    mod = job_fn.__module__
    if mod == "__main__":
        raise ValueError("job_fn must live in an importable module, not __main__")
    import sys
    kw = dict(emu_kwargs or {})
    if "cpu" not in kw and os.environ.get("M64H_CPU"):
        kw["cpu"] = os.environ["M64H_CPU"]
    recycle = 1 if fresh else int(recycle or os.environ.get("M64H_RECYCLE", "6"))
    args = (str(rom), str(sram) if sram else None, mode, mod, job_fn.__name__, list(sys.path), kw)
    queue = collections.deque(enumerate(jobs))
    tries = collections.Counter()
    left = len(queue)

    def spawn():
        a, b = ctx.Pipe()
        proc = ctx.Process(target=_worker_main, args=(b,) + args, daemon=True)
        proc.start()
        b.close()
        return {"p": proc, "c": a, "job": None, "n": 0}

    def retire(w, hard=False):
        try:
            if not hard:
                w["c"].send(None)
        except (OSError, BrokenPipeError):
            pass
        w["p"].join(timeout=0 if hard else 10)
        if w["p"].is_alive():
            w["p"].terminate()
            w["p"].join(timeout=5)
        try:
            w["c"].close()
        except OSError:
            pass

    pool = [spawn() for _ in range(min(workers, left))]
    try:
        while left:
            for k, w in enumerate(pool):
                if w["job"] is None and queue:
                    if w["n"] >= recycle:
                        retire(w)
                        w = pool[k] = spawn()
                    w["job"] = queue.popleft()
                    w["n"] += 1
                    try:
                        w["c"].send(w["job"][1])
                    except (OSError, BrokenPipeError):
                        pass                               # dead already: handled below
            busy = [w for w in pool if w["job"] is not None]
            if not busy:
                continue
            wait([w["c"] for w in busy] + [w["p"].sentinel for w in busy], timeout=30)
            for k, w in enumerate(pool):
                if w["job"] is None:
                    continue
                res = None
                try:
                    if w["c"].poll():
                        res = w["c"].recv()
                except (EOFError, OSError):
                    res = None
                if res is not None:
                    w["job"] = None
                    left -= 1
                    yield res
                    continue
                if not w["p"].is_alive():
                    i, job = w["job"]
                    tries[i] += 1
                    code = w["p"].exitcode
                    retire(w, hard=True)
                    pool[k] = spawn()
                    if tries[i] > retries:
                        left -= 1
                        yield {"_error": f"worker process died {tries[i]} times on this job (last exit code {code})",
                               "_job": job}
                    else:
                        print(f"[pool] a worker died (exit code {code}) - giving its job to a fresh worker "
                              f"(try {tries[i] + 1})", flush=True)
                        queue.appendleft((i, job))
    finally:
        for w in pool:
            retire(w, hard=w["job"] is not None)
