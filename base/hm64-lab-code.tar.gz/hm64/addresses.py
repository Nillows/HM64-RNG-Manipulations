"""
HM64 (USA, NYWE, sha1 90631460f1876a14849df0541d534012b410a34c) RAM map.

Every address here comes from the decomp (config/us/symbol_addrs.txt and the
struct definitions it names) or, where marked, from disassembling the ROM.
Struct offsets are hand-derived from the C structs - if you add one, cite it.
"""

# --- RNG -------------------------------------------------------------------
RAND_SEED = 0x8013CDF0        # libkmc sRandNext (static); from rand() disasm @ROM 0xEB810
RAND_FUNC = 0x80110410        # rand()
RANGE_FUNC = None             # getRandomNumberInRange - look up in symbol_addrs if needed

# --- main loop / screens ---------------------------------------------------
MAIN_LOOP_INDEX = 0x8020564A  # u16 mainLoopCallbackCurrentIndex (src/mainLoop.h ids)
MAIN_LOOP_NAMES = {
    0x00: "NO_OP", 0x01: "MAIN_GAME", 0x02: "MAP_LOAD", 0x03: "DREAM_CUTSCENES",
    0x04: "SET_AUDIO_AND_LIGHTING", 0x05: "LEVEL_LOAD", 0x06: "EXIT_LEVEL",
    0x07: "OVERLAY_SCREEN_LOAD", 0x08: "ROTATING", 0x09: "DIALOGUE", 0x0A: "MESSAGE_BOX",
    0x0B: "END_CUTSCENE", 0x0C: "DIALOGUE_SELECTION", 0x0D: "END_OF_DAY_1",
    0x0E: "END_OF_DAY_2", 0x0F: "WAIT_AUDIO_FINISH", 0x14: "PAUSE_SCREEN_LOAD",
    0x23: "PAUSE_SCREEN", 0x32: "TITLE_SCREEN", 0x33: "NAMING_SCREEN_LOAD",
    0x34: "NAMING_SCREEN", 0x35: "SELECT_GAME", 0x36: "FARM_RANKING_SCREEN",
}
TITLE_CTX = 0x80126570        # TitleContext (src/game/title.h)
TITLE_MODE = TITLE_CTX + 0x0  # u8: 0 = waiting for START, 3 = Play/How-to-Play menu live
LOAD_GAME_CTX = 0x801D6238    # LoadGameScreenContext (src/game/gameFile.h)

# --- time / world ------------------------------------------------------------
BASE_MAP_INDEX = 0x80170458   # u8 gBaseMapIndex
HOUR = 0x801FB5CA             # u8 gHour
MINUTES = 0x8017027F          # u8 gMinutes
SECONDS = 0x80215DF2          # gSeconds
SEASON = 0x80182DB1           # u8 gSeason
DAY_OF_MONTH = 0x80158260     # u8 gDayOfMonth
YEAR = 0x801F6F30             # gYear
WEATHER = 0x802373A9          # u8 gWeather

# --- player: Player gPlayer (src/game/player.h), size 0x78 -------------------
PLAYER = 0x80189060
PLAYER_OFF = {
    "currentStamina": (0x00, "u8"),
    "toolSlot0": (0x15, "u8"),            # equipped tool; GS 80189075 0018 = fishing rod
    "currentTool": (0x1D, "u8"),          # 0x18 = fishing rod in hand (dog-beach save at the house load)
    "heldItem": (0x2C, "u8"),
    "x": (0x48, "f32"), "y": (0x4C, "f32"), "z": (0x50, "f32"),
    "velocity": (0x60, "f32"),
    "actionHandler": (0x64, "u16"),       # fishing: 22
    "animationHandler": (0x66, "u16"),
    "actionPhaseFrameCounter": (0x68, "u16"),
    "actionPhase": (0x6A, "u8"),          # fishing: 3 = bite, 7 = catch, 8 = miss
    "direction": (0x6D, "u8"),
    "actionTimer": (0x6F, "u8"),
    "fishingSpotType": (0x74, "u8"),
    "flags": (0x76, "u16"),
}
FISHING_ROD_TOOL = 0x18

# --- dog: Dog dogInfo (src/game/animals.h), size 0x20 ------------------------
DOG = 0x801886B0
DOG_OFF = {
    "affection": (0x00, "u8"),
    "x": (0x08, "f32"), "y": (0x0C, "f32"), "z": (0x10, "f32"),
    "entityIndex": (0x14, "u16"),
    "location": (0x16, "u8"),             # map index the dog is on
    "actionState": (0x17, "u8"),          # NEXT state to run (see hm64.dog)
    "direction": (0x18, "u8"),            # world direction 0-7
    "speed": (0x19, "u8"),
    "stateTimer": (0x1A, "u8"),           # animation loops left before next decision
    "unk_1B": (0x1B, "u8"),
    "bestRacePlacement": (0x1C, "u8"),
    "flags": (0x1E, "u16"),
}
DOG_FLAGS = {
    0x01: "ACTIVE", 0x02: "STATE_CHANGED", 0x04: "ENTITY_LOADED", 0x08: "HELD",
    0x10: "FOLLOWING", 0x20: "COLLISION_WITH_PLAYER", 0x40: "HELD_DAILY",
    0x80: "WHISTLED_FOR_DAILY",
}
HORSE = 0x8016FDD0            # horseInfo, size 0x24

# --- entities: Entity entities[49] (src/system/entity.h), stride 0x6C ---------
ENTITIES = 0x801FC160
ENTITY_SIZE = 0x6C
ENTITY_PLAYER = 0
ENTITY_DOG = 1                # initializeDogEntity() always uses slot 1
ENTITY_OFF = {
    "x": (0x28, "f32"), "y": (0x2C, "f32"), "z": (0x30, "f32"),
    "speed": (0x4C, "f32"),
    "entityAssetIndex": (0x50, "u16"),
    "animationIndex": (0x54, "u16"),      # current animation (directional base + dir)
    "nextAnimationIndex": (0x56, "u16"),
    "direction": (0x67, "u8"),
    "flags": (0x6A, "u16"),
}

# --- controllers --------------------------------------------------------------
CONTROLLERS = 0x8013D440      # size 0x110
G_CONTROLLERS = 0x8018A738    # size 0x110


def read_struct(emu, base: int, layout: dict) -> dict:
    out = {}
    for name, (off, kind) in layout.items():
        a = base + off
        out[name] = getattr(emu, kind)(a)
    return out
