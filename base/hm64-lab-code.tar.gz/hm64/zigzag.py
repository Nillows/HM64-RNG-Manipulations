"""
Thomas's zig-zag route on the dog-beach save (no horse, dog asleep on the beach, rod in hand), 2026-11-14.

Human input model, controller only:
  menus      mash a square wave until the house loads: period T VIs, held h VIs, phase ph (from VI MASH_FROM).
             style "START>A": START until the Play menu is live (title mode 3), then A.  "START+A": both together.
             (START alone never loads the house - the diary needs A; A alone never skips the intro.)
  house      up-left held from the house map change (through the fade), cut down-left at poll U, cut down at U+V,
             down held until the farm loads.
  farm       left held.
  crossroads left held from the map change, cut down-left at poll C, held until the ranch loads.
  ranch      down-right held.
  beach      down-right held from the map change, cut down-left at poll D, cut down-right at D+B, held until Jack
             stands still at the dock end (READY = 4 still VIs, x > -100); the stick is released at READY.
All cut times are polls after that screen's map change (the poll the route logic first sees the new map), so they
include the screen's fade (Jack answers the stick from ~262 polls in the house, 65-66 on the other screens).

Stage boundaries: `stage_hash` (strict: RNG, full clock, dogInfo, dog entity, player block) at the first VI of a map.
`lucky_state_hash` (experiments/lucky_jobs.py) is the cast-sharing hash.
"""
from __future__ import annotations

import hashlib

from . import addresses as A
from .route import MAP_CTRL, MAP_HOUSE, MAP_FARM, MAP_CROSSROADS, MAP_RANCH, MAP_BEACH, _stick

MASH_FROM = 600                 # VI the mash square wave is phased from (after the lab's hard reset at VI 121)
RESET_VI = 121                  # hard reset inside VI 121, as the legacy runner (harmless: before the first rand())
MASK_A, MASK_START = 0x80, 0x10
STAGES = ((0, MAP_HOUSE), (1, MAP_FARM), (2, MAP_CROSSROADS), (3, MAP_RANCH), (4, MAP_BEACH))
STAGE_NAME = {1: "house", 2: "farm", 3: "crossroads", 4: "ranch", 5: "beach"}
SEASONAL = {MAP_FARM, MAP_CROSSROADS, MAP_RANCH, MAP_BEACH}   # spring index; +1/+2/+3 = summer/autumn/winter (maps.h)


def map_is(m, base):
    """m is the map `base` in any season (the dog-spot saves may be made on another day; spring maps are base+0)."""
    return m == base or (base in SEASONAL and base <= m <= base + 3)
ENT_PLAYER = A.ENTITIES + A.ENTITY_PLAYER * A.ENTITY_SIZE
ENT_DOG = A.ENTITIES + A.ENTITY_DOG * A.ENTITY_SIZE


MISC_ANIMALS = 0x8016FB08      # gMiscAnimals[7], 0x1C each (decomp config/us/symbol_addrs.txt; animals.h MiscAnimal)
MISC_SIZE, MISC_SPARROW = 0x1C, 11


def sparrow_part(e) -> bytes:
    """Live farm sparrows (gMiscAnimals slots of type MISC_ANIMAL_SPARROW with the active flag), spawnVariant byte
    (+0x16, a start-of-day roll) blanked. Empty when there are none. The door pair (slot-4 roll 1) keeps drawing
    random numbers on the farm after the merge point (+6..8 draws before the stick goes live, ~+14 over the farm),
    so two mornings with equal RNG at farm +104 can still have different futures (2026-11-14)."""
    out = b""
    for i in range(7):
        a = MISC_ANIMALS + i * MISC_SIZE
        if e.u8(a + 0x15) == MISC_SPARROW and e.u16(a + 0x18) & 1:
            raw = bytearray(e.read(a, MISC_SIZE))
            raw[0x16] = 0
            out += bytes(raw)
    return out


def stage_hash(e, legacy=False) -> str:
    """Strict state fingerprint for merging routes at a map change: equal hash at the same stage => same future.
    Since zigzag-2 (2026-11-14) live sparrows count too (sparrow_part); states without sparrows hash exactly as
    before. legacy=True: the zigzag-1 fingerprint (for checking states stored by older runs)."""
    h = hashlib.blake2b(digest_size=8)
    h.update(e.read(A.RAND_SEED, 4))
    h.update(bytes([e.u8(A.HOUR), e.u8(A.MINUTES), e.u8(A.SECONDS), e.u8(A.DAY_OF_MONTH), e.u8(A.SEASON)]))
    h.update(e.read(A.DOG, 0x20))
    h.update(e.read(ENT_DOG, A.ENTITY_SIZE))
    h.update(e.read(A.PLAYER, 0x80))
    h.update(e.read(ENT_PLAYER, A.ENTITY_SIZE))
    h.update(e.read(A.MAIN_LOOP_INDEX, 2))
    if not legacy:
        sp = sparrow_part(e)
        if sp:
            h.update(b"sparrows")
            h.update(sp)
    return h.hexdigest()


class Mash:
    def __init__(self, T, h, ph, style="START>A"):
        self.T, self.h, self.ph, self.style = int(T), int(h), int(ph), style

    def buttons(self, vi, play_live):
        if vi < MASH_FROM or ((vi - MASH_FROM + self.ph) % self.T) >= self.h:
            return 0
        if self.style == "START+A":
            return MASK_START | MASK_A
        return MASK_A if play_live else MASK_START


class ZigZagInput:
    """Poll callback. Call `sample(emu)` once per VI (listener) so the map / title mode / VI are current.
    Timing is by VI label (t = VIs since the stage's first VI), not by poll count: a savestate load polls the
    controller more than once while it is processed, but VI labels are restored exactly (checked against cold runs).
    Resume a stage with start_stage + stage_start_vi + vi (the snapshot's VI label, = the state's json "vi")."""

    def __init__(self, mash=None, U=None, V=None, C=None, D=None, B=None, stop_stage=None, beach_tail="DR",
                 start_stage=0, stage_start_vi=None, vi=None, W=0):
        self.mash = mash
        self.U, self.V, self.C, self.D, self.B = U, V, C, D, B
        self.W = int(W or 0)                 # beach wait (2026-11-15): stick neutral until BEACH_LIVE + W, then the legs late by W
        self.stop_stage = stop_stage
        self.beach_tail = beach_tail
        self.stage, self.stage_start, self.map = start_stage, stage_start_vi, 999
        self.vi = 0 if vi is None else int(vi)
        if start_stage:
            self.map = dict(STAGES)[start_stage - 1]
        self.play_live = start_stage > 0
        self.released = False
        self.log = []

    def sample(self, e):
        self.map = e.u16(MAP_CTRL)
        self.vi = e.vi
        if not self.play_live and e.u8(A.TITLE_MODE) == 3:
            self.play_live = True

    def t(self):
        """stage time of the last completed VI (its poll used this t)"""
        return None if self.stage_start is None else self.vi - self.stage_start

    def _leg(self, t):
        s = self.stage
        if s == 1:
            if self.U is None:
                return "N"
            if t < self.U:
                return "UL"
            return "DL" if t < self.U + self.V else "D"
        if s == 2:
            return "L"
        if s == 3:
            return "L" if self.C is None or t < self.C else "DL"
        if s == 4:
            return "DR"
        if s == 5:
            if self.D is None or self.released:
                return "N"
            if self.W:
                if t < BEACH_LIVE + self.W:
                    return "N"
                t -= self.W
            if t < self.D:
                return "DR"
            return "DL" if t < self.D + self.B else self.beach_tail
        return "N"

    def __call__(self, n):
        v = self.vi + 1                                  # the VI this poll belongs to
        old = self.stage
        for st, mp in STAGES:
            if self.stage == st and map_is(self.map, mp):
                self.stage, self.stage_start = st + 1, v
        if self.stage != old:
            self.log.append((n, v, self.stage))
        if self.stage == 0:
            return self.mash.buttons(v - 1, self.play_live) if self.mash else 0
        if self.stop_stage is not None and self.stage >= self.stop_stage:
            return 0
        return _stick(self._leg(v - self.stage_start))


def player_xz(e):
    return e.f32(ENT_PLAYER + 0x28), e.f32(ENT_PLAYER + 0x30)


def dog_sig(e):
    return bytes(e.read(A.DOG, 0x20)) + bytes(e.read(ENT_DOG + 0x28, 12))


READY_STILL = 4
BEACH_LIVE = 67          # Jack first moves 67 VIs after the beach map change with down-right held through the load
BLOCKED_STILL = 60          # still this long short of the dock end (x <= -100) = blocked


def drive(emu, inp, *, until_stage=None, ready=False, max_vi=6000, on_stage=None, beach_vi0=None, track_wake=False,
          load=None, blocked_still=BLOCKED_STILL):
    """Run `inp` (already installed as nothing; this installs it) until `until_stage` is entered or READY.
    on_stage(emu, stage, rec) is called (from the driving thread, never inside a listener: savestates there would
    deadlock) right after the VI in which a new stage starts = the stage-entry point; a state saved there resumes with
    the stage start VI (resume with stage_start_vi). Returns rec: stages {k: {vi, draw, hash, clock}}, wake, ready, end."""
    from .lcg import index
    rec = {"stages": {}, "wake": None, "ready": None, "end": None}
    st = {"stage": inp.stage, "last": None, "still": 0, "dog0": None, "beach_vi": beach_vi0, "done": False,
          "pending": []}

    def watch(e):
        inp.sample(e)
        p = player_xz(e)
        if inp.stage != st["stage"]:
            st["stage"] = inp.stage
            rec["stages"][inp.stage] = {"vi": e.vi, "draw": index(e.u32(A.RAND_SEED)), "hash": stage_hash(e),
                                        "clock": [e.u8(A.HOUR), e.u8(A.MINUTES), e.u8(A.SECONDS)]}
            if inp.stage == 5:
                st["beach_vi"] = e.vi
                st["dog0"] = dog_sig(e)
            if on_stage:
                st["pending"].append(inp.stage)
            if until_stage is not None and inp.stage >= until_stage:
                st["done"] = True
            st["last"] = p
            return
        if inp.stage == 5:
            if track_wake and rec["wake"] is None and st["dog0"] is not None and dog_sig(e) != st["dog0"]:
                rec["wake"] = {"vi": e.vi - st["beach_vi"], "draw": index(e.u32(A.RAND_SEED)),
                               "pos": [round(x, 3) for x in p]}
            if ready and rec["ready"] is None and inp.D is not None and inp.t() is not None \
                    and inp.t() > inp.D + inp.B + getattr(inp, "W", 0):
                st["still"] = st["still"] + 1 if p == st["last"] else 0
                if st["still"] >= READY_STILL and p[0] > -100:
                    rec["ready"] = {"vi": e.vi - READY_STILL - st["beach_vi"], "abs_vi": e.vi - READY_STILL,
                                    "pos": [round(x, 3) for x in p], "draw": index(e.u32(A.RAND_SEED)),
                                    "pier": True}
                    inp.released = True
                    st["done"] = True
                elif st["still"] >= blocked_still:          # stuck short of the dock end (wall or the dog)
                    rec["blocked"] = {"vi": e.vi - st["beach_vi"], "pos": [round(x, 3) for x in p]}
                    st["done"] = True
        st["last"] = p

    if load is not None:
        import json as _json
        with open(str(load) + ".json") as f:
            inp.vi = int(_json.load(f)["vi"])
    emu.set_poll_callback(inp)
    h = emu.add_listener(watch)
    if load is not None:
        emu.load_state(str(load))                   # callback first: see Session
    if inp.stage == 5 and track_wake and st["dog0"] is None:
        st["dog0"] = dog_sig(emu)
    try:
        v0 = emu.vi
        while not st["done"] and emu.vi - v0 < max_vi:
            emu.advance(1)
            while st["pending"]:
                on_stage(emu, st["pending"].pop(0), rec)
    finally:
        emu.remove_listener(h)
    rec["end"] = {"vi": emu.vi, "pos": [round(x, 3) for x in player_xz(emu)], "stage": inp.stage}
    return rec


# merge points: VIs after the stage-entry VI where routes are compared (player already placed, stick not yet live)
MERGE = {1: 0, 2: 104, 3: 40, 4: 40, 5: 40}
KEY_AFTER_WAKE = 8           # line key = cast_hash this many VIs after the dog's first move (wake)


def cast_hash(e) -> str:
    """Position-free version of the lucky state hash (RNG, dogInfo, dog entity + sprite, player action/facing):
    the pier spot does not change the dog's line or the bites (measured 2026-11-14), so casts are shared across spots."""
    h = hashlib.blake2b(digest_size=8)
    _dog_part(e, h)
    h.update(e.read(A.PLAYER + 0x64, 8))
    h.update(e.read(A.PLAYER + 0x6D, 1))
    return h.hexdigest()


def line_hash(e) -> str:
    """Dog line identity: RNG + dogInfo + dog entity + dog sprite (no player fields: Jack's idle counters differ
    between members that stopped at different moments and do not change the dog or the bites)."""
    h = hashlib.blake2b(digest_size=8)
    _dog_part(e, h)
    return h.hexdigest()


def _dog_part(e, h):
    """RNG + dogInfo + dog entity without viewSpacePosition (0x40-0x4B: coordinates minus the camera, render only -
    entity.c; it differs with Jack's spot because the camera follows him) + dog sprite animation state."""
    h.update(e.read(A.RAND_SEED, 4))
    h.update(e.read(A.DOG, 0x20))
    h.update(e.read(ENT_DOG, 0x40))
    h.update(e.read(ENT_DOG + 0x4C, A.ENTITY_SIZE - 0x4C))
    spr = 0x801FD630 + e.u16(ENT_DOG + 0x52) * 0x9C
    h.update(e.read(spr + 0x04, 4))
    h.update(e.read(spr + 0x28, 4))
    h.update(e.read(spr + 0x90, 12))


class Session:
    """Install a ZigZagInput on the emulator (poll callback + per-VI sample) and step it by stage VIs."""

    def __init__(self, emu, inp, load=None):
        """load: savestate to resume. The session is installed BEFORE the load on purpose: the VI that processes a
        load polls the controller; without the callback those polls are neutral and a walking Jack stops for one
        game frame (measured 2026-11-14). inp.vi is set to the snapshot's VI label first."""
        import json as _json
        self.emu, self.inp = emu, inp
        if load is not None:
            with open(str(load) + ".json") as f:
                inp.vi = int(_json.load(f)["vi"])
        emu.set_poll_callback(inp)
        self._h = emu.add_listener(inp.sample)
        if load is not None:
            emu.load_state(str(load))

    def t(self):
        return self.inp.t()

    def until_t(self, t, max_vi=3000):
        """Advance until the VI with stage time t has run (a state saved now resumes at t + 1)."""
        v0 = self.emu.vi
        while (self.t() is None or self.t() < t) and self.emu.vi - v0 < max_vi:
            self.emu.advance(1)
        return self.t() == t

    def until_stage(self, k, max_vi=3000):
        v0 = self.emu.vi
        while self.inp.stage < k and self.emu.vi - v0 < max_vi:
            self.emu.advance(1)
        return self.inp.stage >= k

    def close(self):
        self.emu.remove_listener(self._h)
        self.emu.set_poll_callback(None)
