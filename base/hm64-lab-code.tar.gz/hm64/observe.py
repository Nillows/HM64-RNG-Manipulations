"""
Per-VI listeners that turn raw RAM into "what a human would see".

DogObserver labels every dog decision exactly, by replaying hm64.dog.decide()
from the seed at the start of the VI (validated: the dog's rand() calls are
always the first ones in a VI - tools/validate_dog_model.py, 0 unexplained).
"""
from __future__ import annotations

from . import addresses as A
from .dog import ANIM, decide
from .lcg import index

DOG_ENTITY = A.ENTITIES + A.ENTITY_DOG * A.ENTITY_SIZE


class DogObserver:
    """emu.add_listener(obs) ; later read obs.events

    events: dicts with
      t        VI offset from when the observer was attached
      kind     'decision' | 'whistle-reset' | 'unexplained'
      state    executed state (what is now animating)  [decision]
      anim     human name of that animation
      next     state queued for the next decision
      dir      direction after the decision
      idx      RNG stream index at the end of this VI
    """

    def __init__(self, emu):
        self.t0 = emu.vi
        self.events: list[dict] = []
        self._prev = self._read(emu)

    @staticmethod
    def _read(emu):
        return {
            "seed": emu.u32(A.RAND_SEED),
            "state": emu.u8(A.DOG + 0x17),
            "dir": emu.u8(A.DOG + 0x18),
            "timer": emu.u8(A.DOG + 0x1A),
            "flags": emu.u16(A.DOG + 0x1E),
            "mode": emu.u16(A.MAIN_LOOP_INDEX),
        }

    def __call__(self, emu):
        cur = self._read(emu)
        prev = self._prev
        self._prev = cur
        if not (prev["flags"] & 0x04) or prev["mode"] != 0x01:
            return
        changed = (cur["state"], cur["timer"], cur["dir"]) != (prev["state"], prev["timer"], prev["dir"])
        if prev["timer"] == 0:
            d = decide(prev["state"], prev["seed"], bool(prev["flags"] & 0x10))
            if (d.next_state == cur["state"] and d.state_timer == cur["timer"]
                    and (d.direction is None or d.direction == cur["dir"])
                    and (d.calls > 0 or changed)):
                # a d.calls==0 decision with no visible change is indistinguishable from no decision
                self.events.append({"t": emu.vi - self.t0, "kind": "decision", "state": d.executed,
                                    "anim": d.animation, "next": d.next_state, "dir": cur["dir"],
                                    "idx": index(cur["seed"])})
                return
        if changed and cur["state"] == 0 and cur["flags"] & 0x10:
            self.events.append({"t": emu.vi - self.t0, "kind": "whistle-reset", "idx": index(cur["seed"])})
        elif changed and prev["timer"] == 0:
            self.events.append({"t": emu.vi - self.t0, "kind": "unexplained", "prev": prev["state"],
                                "cur": cur["state"], "idx": index(cur["seed"])})

    def visible_sequence(self, collapse=True):
        """Animation names in order; collapse=True merges repeats (a human sees one long bark)."""
        seq = [e["anim"] for e in self.events if e["kind"] == "decision"]
        if collapse:
            out = []
            for s in seq:
                if not out or out[-1] != s:
                    out.append(s)
            return out
        return seq
