"""
HM64's RNG, exactly as decompiled.

libkmc rand() (lib/libkmc/src/rand.c, ROM 0xEB810 / VRAM 0x80110410):
    sRandNext = sRandNext * 1103515245 + 12345;          // state at 0x8013CDF0
    return ((sRandNext + 1) >> 16) & 0x7FFF;

getRandomNumberInRange(min, max) (src/system/math.c) calls rand() TWICE and
throws the first result away:
    rand();
    temp = (u16)rand() * (max - min + 1);
    return min + (temp >> 15);

Stream position ("index"): boot seed is 0, so every seed the game ever has is
step^n(0) for a unique n < 2^32. index(seed) recovers n in 32 iterations
using the standard power-of-two jump trick for full-period LCGs - no table,
no search. Analogy: it's like reading the odometer instead of counting
every mile driven.
"""
from __future__ import annotations

A = 1103515245
C = 12345
MASK = 0xFFFFFFFF
SEED_ADDR = 0x8013CDF0

# (mult, add) for jumping 2^i steps, i = 0..31
_JUMPS = []
_a, _c = A, C
for _ in range(32):
    _JUMPS.append((_a, _c))
    _a, _c = (_a * _a) & MASK, (_c * (_a + 1)) & MASK if False else ((_c * (_a + 1)) & MASK)
# recompute cleanly (the line above is easy to get wrong; keep the explicit loop as truth)
_JUMPS = []
_a, _c = A, C
for _ in range(32):
    _JUMPS.append((_a, _c))
    _c = (_c * (_a + 1)) & MASK
    _a = (_a * _a) & MASK


def step(seed: int, n: int = 1) -> int:
    """Advance n rand() calls (n may be huge or negative-wrapped mod 2^32)."""
    n &= MASK
    s = seed & MASK
    i = 0
    while n:
        if n & 1:
            a, c = _JUMPS[i]
            s = (a * s + c) & MASK
        n >>= 1
        i += 1
    return s


def index(seed: int, origin: int = 0) -> int:
    """Number of rand() calls to get from `origin` (default boot seed 0) to `seed`."""
    s = origin & MASK
    target = seed & MASK
    n = 0
    for i in range(32):
        if ((s ^ target) >> i) & 1:
            a, c = _JUMPS[i]
            s = (a * s + c) & MASK
            n |= 1 << i
    assert s == target
    return n


def distance(a: int, b: int) -> int:
    """rand() calls from seed a to seed b (mod 2^32; small numbers = b is just after a)."""
    return (index(b) - index(a)) & MASK


def rand_out(new_seed: int) -> int:
    """Value rand() returns, given the seed AFTER its step."""
    return (((new_seed + 1) & MASK) >> 16) & 0x7FFF


def rand(seed: int) -> tuple[int, int]:
    """(value, new_seed)"""
    s = (seed * A + C) & MASK
    return rand_out(s), s


def range_roll(seed: int, lo: int, hi: int) -> tuple[int, int]:
    """getRandomNumberInRange(lo, hi): (value, new_seed); consumes 2 rand() calls."""
    _, s = rand(seed)
    r, s = rand(s)
    return (lo + ((r * (hi - lo + 1)) >> 15)) & 0xFFFF, s


def seed_at(n: int) -> int:
    """Seed after n rand() calls from boot."""
    return step(0, n)


if __name__ == "__main__":
    assert rand(0) == (rand_out(12345), 12345)
    for n in (0, 1, 2, 1219, 25110, 10**6, 2**31 + 7):
        assert index(seed_at(n)) == n, n
    print("lcg ok; index(0x8FDA0F1F) =", index(0x8FDA0F1F))
