"""
Player dog AI, transcribed from updateDogActionState() in
src/game/animals.c (decomp). Pure Python, no emulator needed.

How the real game uses it (updateDog, same file):
  every game tick, IF the dog entity's animation reports a state change
  (or the player bumped it):
      if stateTimer == 0: updateDogActionState()   <- the only RNG consumer here
      else:               stateTimer -= 1

updateDogActionState() looks at dogInfo.actionState (call it S), plays S's
animation, sets speed/stateTimer for S, then rolls RNG to pick the NEXT
state, which it stores back into actionState. So:
    animation on screen right now  = the state that was just EXECUTED
    dogInfo.actionState in RAM     = the state that will run at the next decision

Every getRandomNumberInRange() costs 2 rand() calls (the first is discarded).
"""
from __future__ import annotations

from dataclasses import dataclass

from .lcg import range_roll

ANIM = {
    0: "standing", 1: "walking", 2: "sitting-down(2)", 3: "standing(2)", 4: "running",
    5: "barking", 6: "eating", 7: "sniffing", 8: "urinating", 9: "cut(184)",
    10: "digging", 11: "sitting", 12: "on-belly", 13: "ear-flapping",
    14: "sitting-sniffing", 16: "sitting", 17: "sitting-happy", 18: "sleeping",
    19: "scratching", 20: "sitting-looking", 21: "jump-1", 22: "jump-2",
    23: "running(2)", 24: "looking-around", 25: "barking(2)", 26: "cut(192)",
    27: "sitting-down(2)", 32: "standing", 34: "barking(2)+sfx",
}
SPEED = {0: 0, 1: 1, 4: 2, 21: 1, 22: 2, 23: 1}
TIMER = {0: 10, 1: 10, 3: 10, 10: 10, 11: 10, 12: 10, 16: 10, 20: 10}
# states whose only branch is "repeat with prob 1/3 else go to X"
STAY_OR = {5: 3, 6: 0, 7: 0, 10: 0, 11: 3, 12: 3, 13: 3, 14: 3, 17: 16, 18: 16,
           19: 16, 20: 16, 24: 0, 25: 0}
FIXED = {2: 16, 9: 26, 21: 22, 22: 23, 23: 0, 26: 0, 27: 0, 34: 0}
STATE0_PICK = {0: 1, 1: 2, 2: 3, 3: 4, 4: 5, 5: 6, 6: 7, 7: 8, 8: 10, 9: 24, 10: 25}


@dataclass
class Decision:
    executed: int          # state run now -> its animation is what you see
    animation: str
    next_state: int        # value written to dogInfo.actionState
    direction: int | None  # new world direction, or None if unchanged / set toward player
    speed: int
    state_timer: int
    seed_after: int
    calls: int             # rand() calls consumed
    stop_following: bool = False


def decide(state: int, seed: int, following: bool = False, direction: int | None = None) -> Decision:
    """Run one updateDogActionState() from `seed`."""
    s = seed
    calls = 0
    new_dir = None
    nxt = state
    stop = False

    def roll(lo, hi):
        nonlocal s, calls
        v, s = range_roll(s, lo, hi)
        calls += 2
        return v

    if state == 0:
        if following:
            nxt = 4                                   # face player, start running (no RNG)
        elif roll(0, 60) < 40:
            nxt = 0
        else:
            t = roll(0, 20)
            if t < 7:
                new_dir = t
            t = roll(0, 10)
            nxt = STATE0_PICK.get(t, state)
    elif state == 1:
        t = roll(0, 19)
        nxt = 1 if t < 10 else (4 if t >= 15 else 0)
    elif state == 3:
        t = roll(0, 20)
        if t < 10: nxt = 3
        elif t < 12: nxt = 0
        elif t < 14: nxt = 11
        elif t < 16: nxt = 12
        elif t < 18: nxt = 13
        elif t < 20: nxt = 14
        # t == 20: actionState left untouched (stays 3)
    elif state == 4:
        if following:
            if roll(0, 20) == 0:
                stop = True                           # clears DOG_FOLLOWING; state stays 4
        else:
            t = roll(0, 19)
            if t < 10: nxt = 4
            elif t < 13: nxt = 0
            elif t < 16: nxt = 1
            elif t < 19: nxt = 21
            # t == 19: untouched (stays 4)
    elif state == 8:
        nxt = 0 if roll(0, 2) else 8                  # note: inverted vs the others
    elif state == 16:
        t = roll(0, 14)
        nxt = {10: 27, 11: 17, 12: 18, 13: 19, 14: 20}.get(t, 16)
    elif state in STAY_OR:
        nxt = state if roll(0, 2) == 0 else STAY_OR[state]
    elif state in FIXED:
        nxt = FIXED[state]
    # 32: no transition; 15/others: switch has no case -> nothing happens

    return Decision(executed=state, animation=ANIM.get(state, f"state{state}"),
                    next_state=nxt, direction=new_dir, speed=SPEED.get(state, 0),
                    state_timer=TIMER.get(state, 0), seed_after=s, calls=calls,
                    stop_following=stop)


def rng_cost(state: int, following: bool = False) -> set[int]:
    """Possible rand() costs of one decision from `state` (for sanity checks)."""
    if state == 0:
        return {0} if following else {2, 6}
    if state in FIXED or state == 32:
        return {0}
    return {2}
