"""
Native fishing search: for a starting state, an optional prefix of inputs
(e.g. whistles) and a cast poll, find every bite window while B is held and
branch EVERY release poll across each window. Real controller input only.

Mechanics (src/game/player.c handleFishingAction / handleFishingRodAnimation):
  phase 1 cast -> 2 waiting: each game update rolls getRandomNumberInRange(0,400);
  0 -> 3 (bite) -> 4 -> 5 -> back to 1/2 if B is still held (next bite later).
  B released while phase 3..5 -> 6 reel -> 7 catch: fish type roll, then the
  ocean (spot 3) Nut roll !getRandomNumberInRange(0,50). Released elsewhere -> 8.
Measured on QuickSave2: a window spans ~22 polls (4 for ~20, 5 for ~2).

Poll numbers: absolute, 0 = first controller read after the START state
finished loading (same convention as tools/regress_qs2.py).
"""
from __future__ import annotations

import os
import tempfile
from pathlib import Path

from . import addresses as A

NUT_BITS = 0x80215EB8
FISH = {37: "small", 38: "medium", 39: "large"}
POWER_NUT_ITEM = 87
FISHING = 22


def _phase(emu):
    return emu.u16(A.PLAYER + 0x64), emu.u8(A.PLAYER + 0x6A)


def _tmpdir():
    return tempfile.mkdtemp(prefix="fish-", dir="/dev/shm" if os.path.isdir("/dev/shm") else None)


def find_bites(emu, state, prefix, cast, max_vi=5000, max_bites=2):
    """Hold B from `cast`; return [(first_poll_in_window, last_poll_in_window, vi)]."""
    emu.schedule_polls(list(prefix) + [(cast, ["B"])])
    emu.load_state(state)
    bites, inwin, start = [], False, None
    try:
        for _ in range(max_vi):
            emu.advance(1)
            act, ph = _phase(emu)
            if act == FISHING and 3 <= ph <= 5:
                if not inwin:
                    inwin, start = True, (emu.polls(), emu.vi)
            elif inwin:
                bites.append((start[0], emu.polls() - 1, start[1]))
                inwin = False
                if len(bites) >= max_bites:
                    break
            if act != FISHING and emu.polls() > cast + 30:
                break                                # cast never started / something else happened
    finally:
        emu.clear_schedule()
    return bites


def _resolve(emu, max_vi=400):
    """Run until the catch resolves. Returns outcome string + held item."""
    seen_window = False
    for _ in range(max_vi):
        emu.advance(1)
        if emu.u32(NUT_BITS) & 4:
            return "nut", POWER_NUT_ITEM
        act, ph = _phase(emu)
        item = emu.u8(A.PLAYER + 0x2C)
        if item in FISH:
            return "fish", item
        if act == FISHING:
            if ph == 8:
                return "miss", 0
            if 3 <= ph <= 5:
                seen_window = True
            elif seen_window and ph in (1, 2):
                return "held_through", 0
        elif act == 0:
            return "idle", 0
    return "timeout", 0


def solve_cast(emu, state, cast, prefix=(), max_bites=2, max_wait_vi=5000, pad_before=6, pad_after=2):
    """All release outcomes for one cast poll. Returns dict with bites and per-release results."""
    bites = find_bites(emu, state, prefix, cast, max_wait_vi, max_bites)
    out = {"cast": cast, "prefix": [list(e) for e in prefix], "bites": [], "nut_releases": []}
    if not bites:
        return out
    tmp = _tmpdir()
    try:
        # pass 2: replay holding B, checkpoint shortly before each window
        emu.schedule_polls(list(prefix) + [(cast, ["B"])])
        emu.load_state(state)
        ckpts = []
        for i, (p_first, p_last, vi_first) in enumerate(bites):
            target_vi = vi_first - pad_before
            emu.advance(max(0, target_vi - emu.vi))
            p_req = emu.polls()
            ck = os.path.join(tmp, f"bite{i}.st")
            emu.save_state(ck)
            ckpts.append((ck, p_req))
        emu.clear_schedule()
        for (p_first, p_last, vi_first), (ck, p_req) in zip(bites, ckpts):
            rel = []
            for r in range(max(p_req, p_first - pad_before), p_last + pad_after + 1):
                emu.schedule_polls([(0, ["B"]), (r - p_req, [])])
                emu.load_state(ck)
                res, item = _resolve(emu)
                emu.clear_schedule()
                rel.append({"release": r, "outcome": res, "item": item})
                if res == "nut":
                    out["nut_releases"].append(r)
            out["bites"].append({"window": [p_first, p_last], "releases": rel})
    finally:
        for f in Path(tmp).glob("*"):
            f.unlink()
        os.rmdir(tmp)
    return out


def whistle_prefix(polls, hold=2):
    """C-right presses at the given absolute polls."""
    ev = []
    for p in sorted(polls):
        ev += [(p, ["CR"]), (p + hold, [])]
    return ev


# ----------------------------------------------------------------------------
# Fast path: per-poll controller + emulator-thread stop conditions.
# ----------------------------------------------------------------------------
from m64h.buttons import encode_buttons as _enc  # noqa: E402

_CR = _enc(["CR"])
_B = _enc(["B"])
_SE = _enc([], 35, -35)        # stay-awake push: stick south-east (walk), blocked by the water at the dock
WAKE_POLLS = 4


class FishController:
    """Poll callback: C-right for `hold` polls at each whistle poll, B held from
    `cast` until `release` (exclusive; None = keep holding). Polls are counted
    from the last state load (the harness zeroes the counter at load)."""

    def __init__(self, whistles=(), cast=None, release=None, hold=2, wake=()):
        self.wh = [(w, w + hold) for w in whistles]
        self.cast = cast
        self.release = release
        self.wake = [(w, w + WAKE_POLLS) for w in wake]    # Thomas's SE push (v27.6u): resets playerIdleCounter

    def __call__(self, n):
        for a, b in self.wh:
            if a <= n < b:
                return _CR
        if self.cast is None or n < self.cast:
            for a, b in self.wake:
                if a <= n < b:
                    return _SE
        if self.cast is not None and n >= self.cast and (self.release is None or n < self.release):
            return _B
        return 0


def _in_window(emu):
    return emu.u16(A.PLAYER + 0x64) == FISHING and 3 <= emu.u8(A.PLAYER + 0x6A) <= 5


def _resolver():
    st = {"left_window": False}

    def pred(emu):
        if emu.u32(NUT_BITS) & 4:
            return True
        act, ph = _phase(emu)
        if emu.u8(A.PLAYER + 0x2C) in FISH:
            return True
        if act == FISHING:
            if ph == 8:
                return True
            if ph in (1, 2):
                st["left_window"] = True
                return True
        elif act == 0:
            return True
        return False
    return pred


def _classify(emu):
    if emu.u32(NUT_BITS) & 4:
        return "nut"
    if emu.u8(A.PLAYER + 0x2C) in FISH:
        return "fish"
    act, ph = _phase(emu)
    if act == FISHING and ph == 8:
        return "miss"
    if act == FISHING and ph in (1, 2):
        return "held_through"
    return "other"


def _next_window(emu, max_vi):
    """Keep holding B: leave the current bite window, wait for the next one. True if a new bite shows."""
    st = {"left": False}

    def pred(e):
        inw = _in_window(e)
        if not inw:
            st["left"] = True
            if e.u16(A.PLAYER + 0x64) != FISHING:
                return True
        return st["left"] and inw
    return bool(emu.advance_until(pred, max_vi)) and _in_window(emu)


def eval_cast(emu, state, cast, whistles=(), probes=(4, 12), map_window=True,
              max_wait_vi=6000, window_span=26, tmpdir=None, hold_bites=1, wake=(), hold_until=None, always_bites=2,
              probes_more=None):
    """One cast plan from `state`: hold B from `cast` (after optional whistles),
    detect the first bite, checkpoint there, then release at window-relative
    `probes`; if any probe gives the Nut (and map_window), try every release
    poll across the window. Returns a JSON-able dict.

    Release polls are absolute (relative to the START state load). The 1-3
    polls before the bite becomes visible in RAM are not branchable from the
    checkpoint; on every window mapped so far they give fish, not Nut.

    hold_bites > 1: also keep holding B through the first bite (phase 5 -> 1 -> 2, the
    wait resumes and rolls range(0,400) again) and probe the release on bites 2..n.
    out["bites"] = [{"bite_poll", "probes", "nut"}, ...] (bite 1 first).
    hold_until (poll, same base as bite_poll; 2026-11-16, Thomas: every bite in the forecast time): bites after the
    first `always_bites` are only followed while they show by this poll; `probes_more` = release probes for those
    (one is enough: every release in the window gives the same catch, 1,824/1,824).
    """
    import os
    import tempfile
    own = tmpdir is None
    tmp = tmpdir or tempfile.mkdtemp(prefix="cast-", dir="/dev/shm" if os.path.isdir("/dev/shm") else None)
    ck = os.path.join(tmp, "bite.st")
    out = {"cast": cast, "whistles": list(whistles), "bite_poll": None, "bite_vi": None,
           "probes": {}, "nut_releases": [], "window_outcomes": None, "status": "ok"}
    try:
        emu.set_poll_callback(FishController(whistles, cast, None, wake=wake))
        emu.load_state(state)

        started = {}

        def bite_or_fail(e):
            if "poll" not in started and e.u16(A.PLAYER + 0x64) == FISHING:
                started["poll"] = e.polls()
            if _in_window(e):
                return True
            return e.polls() > cast + 60 and e.u16(A.PLAYER + 0x64) != FISHING
        hit = emu.advance_until(bite_or_fail, max_wait_vi)
        out["cast_started_poll"] = started.get("poll")
        if not hit:
            out["status"] = "no_bite_in_horizon"
            return out
        if not _in_window(emu):
            out["status"] = "cast_failed"          # never entered fishing (e.g. busy, wrong spot)
            out["player_action"] = emu.u16(A.PLAYER + 0x64)
            return out
        p_first = emu.polls()
        out["bite_poll"], out["bite_vi"] = p_first, emu.vi
        p_req = emu.polls()
        emu.save_state(ck)                          # B still held through this VI

        def branch(r):
            emu.set_poll_callback(FishController((), 0, max(0, r - p_req)))
            emu.load_state(ck)
            emu.advance_until(_resolver(), 600)
            return _classify(emu)

        for off in probes:
            out["probes"][str(off)] = branch(p_first + off)
        if map_window and "nut" in out["probes"].values():
            res = []
            for r in range(p_req, p_first + window_span):
                o = branch(r)
                res.append(o[0])
                if o == "nut":
                    out["nut_releases"].append(r)
            out["window_outcomes"] = {"from_poll": p_req, "codes": "".join(res)}
        out["bites"] = [{"bite_poll": p_first, "probes": dict(out["probes"]),
                         "nut": "nut" in out["probes"].values()}]
        ck_now, p_now = ck, p_req
        for k in range(1, int(hold_bites)):
            emu.set_poll_callback(FishController((), 0, None))      # never release: hold through
            emu.load_state(ck_now)
            late = hold_until is not None and k >= always_bites
            budget = max_wait_vi if not late else max(1, min(max_wait_vi, hold_until - p_now + 2))
            if not _next_window(emu, budget):
                if not late:
                    out["bites"].append({"bite_poll": None, "status": "no_next_bite"})
                break
            p_b = p_now + emu.polls()
            if late and p_b > hold_until:
                break
            ck_b = os.path.join(tmp, f"bite{k + 1}.st")
            emu.save_state(ck_b)

            def branch_b(r, ck_b=ck_b, p_b=p_b):
                emu.set_poll_callback(FishController((), 0, max(0, r - p_b)))
                emu.load_state(ck_b)
                emu.advance_until(_resolver(), 600)
                return _classify(emu)
            pr = {str(off): branch_b(p_b + off) for off in (probes_more if (late and probes_more) else probes)}
            out["bites"].append({"bite_poll": p_b, "probes": pr, "nut": "nut" in pr.values()})
            if ck_now != ck:
                for q in (ck_now, ck_now + ".json"):
                    if os.path.exists(q):
                        os.remove(q)
            ck_now, p_now = ck_b, p_b
        if ck_now != ck:
            for q in (ck_now, ck_now + ".json"):
                if os.path.exists(q):
                    os.remove(q)
        return out
    finally:
        emu.set_poll_callback(None)
        if os.path.exists(ck):
            os.remove(ck)
        if os.path.exists(ck + ".json"):
            os.remove(ck + ".json")
        if own:
            os.rmdir(tmp)
