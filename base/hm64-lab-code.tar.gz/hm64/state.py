"""Structured per-VI snapshots of the parts of HM64 the RNG research cares about."""
from __future__ import annotations

from . import addresses as A
from .lcg import index


def dog(emu) -> dict:
    d = A.read_struct(emu, A.DOG, A.DOG_OFF)
    d["following"] = bool(d["flags"] & 0x10)
    d["loaded"] = bool(d["flags"] & 0x04)
    ent = A.ENTITIES + A.ENTITY_DOG * A.ENTITY_SIZE
    d["anim"] = emu.u16(ent + 0x54)
    d["ex"], d["ez"] = emu.f32(ent + 0x28), emu.f32(ent + 0x30)
    return d


def player(emu) -> dict:
    return A.read_struct(emu, A.PLAYER, A.PLAYER_OFF)


def snapshot(emu) -> dict:
    seed = emu.u32(A.RAND_SEED)
    p = player(emu)
    d = dog(emu)
    return {
        "vi": emu.vi,
        "seed": seed,
        "idx": index(seed),
        "mode": emu.u16(A.MAIN_LOOP_INDEX),
        "map": emu.u8(A.BASE_MAP_INDEX),
        "hour": emu.u8(A.HOUR), "min": emu.u8(A.MINUTES),
        "polls": emu.polls(),
        "p_x": round(p["x"], 3), "p_z": round(p["z"], 3),
        "p_action": p["actionHandler"], "p_phase": p["actionPhase"],
        "p_held": p["heldItem"], "p_tool": p["toolSlot0"],
        "dog_state": d["actionState"], "dog_dir": d["direction"],
        "dog_speed": d["speed"], "dog_timer": d["stateTimer"],
        "dog_flags": d["flags"], "dog_anim": d["anim"],
        "dog_loc": d["location"], "dog_aff": d["affection"],
        "dog_x": round(d["ex"], 3), "dog_z": round(d["ez"], 3),
    }


def control_regained(emu, probe_vis: int = 4,
                     sticks=((80, 0), (-80, 0), (0, -80), (0, 80))) -> bool:
    """True if holding the stick right now would move the player entity.

    Non-destructive: snapshot, try each stick direction (rolling back after
    each), restore. Leaves you exactly 1 VI later than when called (the
    savestate itself costs one VI), with game state otherwise untouched.
    Position is read from the player *entity* (entities[0]); gPlayer.coordinates
    is only synced at certain points and does not move while walking.
    """
    import os
    import tempfile
    ent = A.ENTITIES + A.ENTITY_PLAYER * A.ENTITY_SIZE
    fd, path = tempfile.mkstemp(suffix=".st", dir="/dev/shm" if os.path.isdir("/dev/shm") else None); os.close(fd)
    try:
        emu.save_state(path)
        here = (emu.f32(ent + 0x28), emu.f32(ent + 0x30))
        for x, y in sticks:
            emu.set_input(x=x, y=y)
            emu.advance(probe_vis)
            emu.release()
            moved = (emu.f32(ent + 0x28), emu.f32(ent + 0x30)) != here
            emu.load_state(path)
            if moved:
                return True
        return False
    finally:
        for p in (path, path + ".json"):
            if os.path.exists(p):
                os.remove(p)
