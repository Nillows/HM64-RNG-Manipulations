"""
ROM-derived dog sprite equivalence (sprite_equivalence.json from Thomas's
Layer 1 exporter: SHA-256-equal-file classes of 200 ROM-extracted dog GIFs,
no pixels). visual_class(base, screen) is what a human can actually tell
apart; the same class numbering is used by the Layer 1 index.

base   = dog entity animationIndex (entities[1] +0x54), multiples of 8
screen = dog entity direction byte (+0x67) = rendered facing,
         index into S,SW,W,NW,N,NE,E,SE (verified: baseline READY -> 3 = NW,
         matching Layer 1 anchor 2).
"""
import json
from pathlib import Path

_EQ = json.loads((Path(__file__).parent / "data" / "sprite_equivalence.json").read_text())
CLASSES = _EQ["class_by_pose_and_direction"]
DIRS = _EQ["dirs_index"].split(",")


def visual_class(base: int, screen: int):
    return CLASSES.get(f"{base}_{screen}")
