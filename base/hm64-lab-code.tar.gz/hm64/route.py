"""
Cold boot -> diary -> carry the dog -> beach dock "fishing ready".

A faithful port of Thomas's legacy route recipe:
  - input logic: hm64_carry_route_input.c (identical in v13 and v14/v17/v27.7b)
  - schedule + stage/ready analysis: run_frontier(_corrected).py
  - hard core reset at legacy graphics callback 120 (= our VI 121)
Route, in words: power on, hard reset ("Ctrl+R"), START/START/A/A through the
menus, in the house wait, step up, A to pick up the dog, up-left, down-left,
down out the door; farm: hold straight LEFT; crossroads (map 78): wait, left
78 polls, then down-left; Green Ranch (map 0): wait, then DOWN+RIGHT; beach
(map 9): scripted steps to the dock, A to put the dog down, face south-east.

A case is 8 delays (d0,d1,d2,d3,H,C,P,D), budgets d0+..+d3 <= 30, H+C <= 60,
P+D <= 60, all in controller polls (~1 per VI):
  d0..d3  extra polls before each menu press      H  house wait before exiting
  C       wait on entering the crossroads          P  wait before picking up dog
  D       wait after putting the dog down (beach)
Everything is driven by controller input only - no RAM writes.

Conventions verified against the legacy native runner (see tools/route_run.py
--check-v13): legacy trace "vi" k == our emu.vi k+1; polls are absolute from
power-on (they continue across the hard reset).
"""
from __future__ import annotations

from dataclasses import dataclass, field

from . import addresses as A

MAP_CTRL = 0x802055D8 + 0x42      # u16: the map value the legacy route logic keyed on
PLAYER_ACTION = 0x801890C4        # gPlayer.actionHandler
MAP_HOUSE, MAP_FARM, MAP_CROSSROADS, MAP_RANCH, MAP_BEACH = 87, 82, 78, 0, 9
READY_X, READY_Z = "-101.993", "178.257"   # exact dock tile (legacy %.3f strings)

BEACH_V13 = "v13"
BEACH_V14 = "v14_two_poll_DR_finish"     # used by the v17 frontier / Windows export / v27.7b


def beach_steps(D: int, variant: str = BEACH_V14) -> str:
    parts = ["DR:86", "DL:34", "D:100", "L:35", "DR:70", "UL:1", "A:2"]
    if D:
        parts.append(f"N:{D}")
    if variant == BEACH_V13:
        parts += ["R:1", "N:20", "DR:1", "N:155"]
    else:
        parts += ["N:20", "DR:2", "N:155"]
    return ",".join(parts)


def _stick(name: str):
    x = y = 0
    if name in ("L", "UL", "DL"):
        x = -80
    if name in ("R", "UR", "DR"):
        x = 80
    if name in ("U", "UL", "UR"):
        y = 80
    if name in ("D", "DL", "DR"):
        y = -80
    if x and y:
        x = -70 if x < 0 else 70
        y = -70 if y < 0 else 70
    mask = {"A": 0x80, "B": 0x40, "START": 0x10}.get(name, 0)
    return mask | ((x & 0xFF) << 16) | ((y & 0xFF) << 24)


@dataclass
class RouteCase:
    d0: int = 0
    d1: int = 0
    d2: int = 0
    d3: int = 0
    H: int = 0
    C: int = 0
    P: int = 0
    D: int = 0
    variant: str = BEACH_V14
    reset_at_callback: int = 120      # legacy HM64_CORE_RESET_AT
    menu_hold: int = 3
    breakfast_extra: int = 74
    cross_left: int = 78
    ul: int = 20
    dl: int = 35

    @property
    def label(self):
        return (f"m{self.d0:02}{self.d1:02}{self.d2:02}{self.d3:02}_h{self.H:02}c{self.C:02}"
                f"_p{self.P:02}d{self.D:02}")

    def within_budget(self):
        return (min(self.d0, self.d1, self.d2, self.d3, self.H, self.C, self.P, self.D) >= 0
                and self.d0 + self.d1 + self.d2 + self.d3 <= 30 and self.H + self.C <= 60
                and self.P + self.D <= 60)


class RouteInput:
    """Per-poll controller logic (port of hm64_carry_route_input.c, boot_mode 0)."""

    def __init__(self, case: RouteCase):
        c = case
        self.case = c
        self.delay0 = c.reset_at_callback + c.d0     # legacy ROUTE_MENU_DELAY_0 = 120 + d0
        self.stage = 0
        self.stage_start = 0
        self.map = 999                               # legacy: 999 until the first VI sample
        self.beach = []
        at = 0
        for part in beach_steps(c.D, c.variant).split(","):
            name, t = part.split(":")
            self.beach.append((at, at + int(t), name))
            at += int(t)
        self.log = []                                # (poll, stage) transitions

    def sample_map(self, emu):
        """Call once per VI (legacy updated its shared map at every graphics callback)."""
        self.map = emu.u16(MAP_CTRL)

    def __call__(self, n: int) -> int:
        c = self.case
        m = self.map
        old = self.stage
        name = "N"
        d0, d1, d2, d3, hold = self.delay0, c.d1, c.d2, c.d3, c.menu_hold
        if (561 + d0 <= n < 561 + d0 + hold) or (633 + d0 + d1 <= n < 633 + d0 + d1 + hold):
            name = "START"
        if (767 + d0 + d1 + d2 <= n < 767 + d0 + d1 + d2 + hold) or \
           (855 + d0 + d1 + d2 + d3 <= n < 855 + d0 + d1 + d2 + d3 + hold):
            name = "A"
        if self.stage == 0 and m == MAP_HOUSE:
            self.stage, self.stage_start = 1, n
        if self.stage == 1 and m == MAP_FARM:
            self.stage, self.stage_start = 2, n
        if self.stage == 2 and m == MAP_CROSSROADS:
            self.stage, self.stage_start = 3, n
        if self.stage == 3 and m == MAP_RANCH:
            self.stage, self.stage_start = 4, n
        if self.stage == 4 and m == MAP_BEACH:
            self.stage, self.stage_start = 5, n
        if self.stage != old:
            self.log.append((n, self.stage))
        t = n - self.stage_start
        if self.stage == 1:
            u = 192 + c.P + c.breakfast_extra
            if t < u: name = "N"
            elif t < u + 4: name = "U"
            elif t < u + 8: name = "A"
            elif t < u + 22: name = "N"
            elif t < u + 22 + c.ul: name = "UL"
            elif t < u + 22 + c.ul + c.dl: name = "DL"
            elif t < u + 22 + c.ul + c.dl + c.H: name = "N"
            else: name = "D"
        elif self.stage == 2:
            name = "L"
        elif self.stage == 3:
            name = "N" if t < c.C else ("L" if t < c.C + c.cross_left else "DL")
        elif self.stage == 4:
            name = "DR"                              # legacy ranch_wait is always 0
        elif self.stage == 5:
            name = "N"
            for a, b, nm in self.beach:
                if a <= t < b:
                    name = nm
                    break
        return _stick(name)


@dataclass
class StageTracker:
    """Per-VI rows + legacy analyze(): cabin, breakfast, pickup, farm, crossroads,
    ranch, beach_held, dog_placed, fishing_ready."""
    rows: list = field(default_factory=list)

    def __call__(self, emu):
        p = A.PLAYER
        dflags = emu.u16(A.DOG + 0x1E)
        self.rows.append({
            "vi": emu.vi - 1,                       # legacy numbering
            "rng": emu.u32(A.RAND_SEED),
            "map": emu.u16(MAP_CTRL),
            "px": f"{emu.f32(A.ENTITIES + 0x28):.3f}", "pz": f"{emu.f32(A.ENTITIES + 0x30):.3f}",
            "dog_flags": dflags, "dog_held": 1 if dflags & 8 else 0,
            "dog_action": emu.u8(A.DOG + 0x17), "dog_direction": emu.u8(A.DOG + 0x18),
            "dog_timer": emu.u8(A.DOG + 0x1A),
            "player_dir": emu.u8(p + 0x6D), "tool": emu.u8(p + 0x1D), "held_item": emu.u8(p + 0x2C),
            "player_action": emu.u16(PLAYER_ACTION),
        })

    def analyze(self):
        rows = self.rows
        by_vi = {r["vi"]: i for i, r in enumerate(rows)}

        def after(vi, fn):
            for r in rows[by_vi.get(vi, 0) if vi is not None else 0:]:
                if fn(r):
                    return r
            return None

        def v(r):
            return r["vi"] if r else None
        st = {}
        st["cabin"] = after(rows[0]["vi"] if rows else 0, lambda r: r["map"] == MAP_HOUSE)
        cab = v(st["cabin"]) or 0
        st["breakfast"] = after(cab + 74, lambda r: r["map"] == MAP_HOUSE) if st["cabin"] else None
        st["pickup"] = after(cab, lambda r: r["map"] == MAP_HOUSE and r["dog_held"]) if st["cabin"] else None
        st["farm"] = after(v(st["pickup"]) or cab, lambda r: r["map"] == MAP_FARM) if st["pickup"] else None
        st["crossroads"] = after(v(st["farm"]) or cab, lambda r: r["map"] == MAP_CROSSROADS) if st["farm"] else None
        st["ranch"] = after(v(st["crossroads"]) or cab, lambda r: r["map"] == MAP_RANCH) if st["crossroads"] else None
        st["beach_held"] = after(v(st["ranch"]) or cab, lambda r: r["map"] == MAP_BEACH) if st["ranch"] else None
        st["dog_placed"] = after(v(st["beach_held"]) or cab, lambda r: r["map"] == MAP_BEACH and not r["dog_held"]
                                 and r["dog_flags"] & 4) if st["beach_held"] else None
        st["fishing_ready"] = after((v(st["dog_placed"]) or 0) + 16, lambda r: (
            r["map"] == MAP_BEACH and not r["dog_held"] and r["dog_flags"] & 4 and r["player_dir"] == 6
            and r["tool"] == 24 and r["held_item"] == 0 and r["player_action"] == 0
            and r["px"] == READY_X and r["pz"] == READY_Z)) if st["dog_placed"] else None
        return {k: ({kk: r[kk] for kk in ("vi", "rng", "dog_flags", "dog_held", "dog_action",
                                           "dog_direction", "dog_timer")} | {"player_x": r["px"],
                                                                              "player_z": r["pz"]})
                if r else None for k, r in st.items()}


def outcome(stages: dict) -> str:
    order = ["cabin", "pickup", "farm", "crossroads", "ranch", "beach_held", "dog_placed", "fishing_ready"]
    names = {"cabin": "no_cabin", "pickup": "no_pickup", "farm": "no_farm", "crossroads": "farm_blocked",
             "ranch": "no_ranch", "beach_held": "no_beach", "dog_placed": "not_placed",
             "fishing_ready": "not_fishing_ready"}
    for k in order:
        if not stages.get(k):
            return names[k]
    return "ready"


def run_route(emu, case: RouteCase, max_vi: int = 3600, stop_at_ready: bool = True,
              ready_state_path=None, settle_vi: int = 0):
    """Drive a freshly started (paused at VI 1, not yet run) Emulator through the route.

    Returns dict(case, outcome, stages, polls, stage_log). If ready_state_path is
    given and the route reaches fishing_ready, a savestate is written at that
    exact VI (+settle_vi) with the stage table in its .json sidecar.
    """
    route = RouteInput(case)
    track = StageTracker()
    emu.schedule_hard_reset(case.reset_at_callback + 1)
    emu.add_listener(route.sample_map)
    emu.add_listener(track)
    emu.set_poll_callback(route)
    ready_vi = None
    try:
        while emu.vi < max_vi:
            emu.advance(1)
            if stop_at_ready and track.rows[-1]["map"] == MAP_BEACH and track.rows[-1]["px"] == READY_X:
                st = track.analyze()
                if st["fishing_ready"]:
                    ready_vi = st["fishing_ready"]["vi"]
                    break
    finally:
        emu.remove_listener(track)
        emu.remove_listener(route.sample_map)
    stages = track.analyze()
    result = {"label": case.label, "case": case.__dict__, "outcome": outcome(stages),
              "stages": stages, "stage_log": route.log, "polls_at_end": emu.polls()}
    if ready_state_path and ready_vi is not None:
        # we are paused right after legacy VI ready_vi (our emu.vi == ready_vi + 1)
        if settle_vi:
            emu.advance(settle_vi)
        emu.save_state(ready_state_path, meta={"kind": "fishing-ready", **{k: result[k] for k in
                                                                           ("label", "case", "stages")},
                                               "poll_at_save": emu.polls()})
        result["ready_state"] = str(ready_state_path)
    emu.set_poll_callback(None)
    return result
