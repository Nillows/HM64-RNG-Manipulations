#!/usr/bin/env bash
# HM64 Power Nut lab - preset zigzag (Thomas's zig-zag route on the dog-beach save), 2026-11-14.
#
#   bash run_hm64_zigzag.sh zigzag-fast [workers]     tight windows first (fast mash, fastest cuts + a few frames)
#   bash run_hm64_zigzag.sh zigzag-mid [workers]      up to 9 frames late per screen (full grids, the states nearest
#                                                      the fast zone first); zigzag-full continues from it
#   bash run_hm64_zigzag.sh zigzag-full [workers]     wide windows; continues from zigzag-fast / -mid (nothing redone)
#
# Needs in <script dir>/sourcefiles/ (any names, also inside .zip files there): the ROM (*.z64) and the dog-beach
# SaveRAM (sha256 0d78b95b..., "nohorse-dogbeach-nopickup"). The save is also looked for in ~/Downloads, ~/Desktop
# and ~/Documents and copied into sourcefiles/ when found. The Spring 9 SaveRAM is optional (lab health test).
# Work folder: <script dir>/runs/zigzag/hm64-lab (kept: both presets and any re-run continue there; Ctrl-C any
# time and run the same command again to resume). Results: runs/hm64-campaign-<preset>-<timestamp>.zip
# (no ROM, save or savestates inside - send that one).
# Env: HM64_DRY_RUN=1 (find inputs, stop), HM64_ZZ_STOP_AFTER=Z5 (stop after a stage), HM64_ZZ_MAX_LINES=N (cast
#      only the N heaviest dog lines), INSTALL_CLAUDE=0, HM64_RUN_ROOT.
set -euo pipefail

say() { printf '\n==> %s\n' "$*"; }
die() { printf '\nSTOP: %s\n' "$*" >&2; exit 1; }

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PRESET=${1:-zigzag-fast}
WORKERS=${2:-}
case "$PRESET" in zigzag-fast|zigzag-mid|zigzag-full) ;; *) die "preset must be zigzag-fast, zigzag-mid or zigzag-full";; esac
TARBALL="$HERE/hm64-lab-zigzag.tar.gz"
INPUTS="$HERE/sourcefiles"
DOGBEACH_SHA=0d78b95b78e4a988570b3648d9bc16021df59a5faccdc00d06b01273975d8387
SPRING9_SHA=db2c29ace807ab980ebbc7eccad11e30e37ea3dad53113c3fb1bdc073b759d63
ROM_SHA=15c570120bfaa97b4580762f5ee5939a56ba054e696925ea81ccfa55a022d2a6
[ -f "$TARBALL" ] || die "hm64-lab-zigzag.tar.gz is not next to this script ($HERE)"
mkdir -p "$INPUTS"

if [ "${HM64_DRY_RUN:-0}" != 1 ]; then
  command -v docker >/dev/null || die "docker not found"
  docker info >/dev/null 2>&1 || die "Docker is not running (start Docker Desktop)"
fi

RUN_ROOT=${HM64_RUN_ROOT:-$HERE/runs}
WORK="$RUN_ROOT/zigzag"
LAB="$WORK/hm64-lab"
mkdir -p "$WORK"
LOCK="$WORK/.running"
if ! mkdir "$LOCK" 2>/dev/null; then
  die "another zigzag run is using $WORK (if none is running, delete the folder $LOCK)"
fi
trap 'rmdir "$LOCK" 2>/dev/null || true' EXIT
STAMP=$(date +%Y%m%d-%H%M%S)
LOG="$WORK/run-$PRESET-$STAMP.log"
exec > >(tee -a "$LOG") 2>&1
say "work folder: $LAB  (preset $PRESET)"

say "1/6 lab code"
TMPX="$WORK/.code-$STAMP"
mkdir -p "$TMPX"
tar -xzf "$TARBALL" -C "$TMPX"
[ -f "$TMPX/hm64-lab/docker-compose.yml" ] || die "tarball does not contain hm64-lab/"
mkdir -p "$LAB"
# code is replaced, work is kept: states/ results/ data/ stay as they are
for e in "$TMPX/hm64-lab/"* "$TMPX/hm64-lab/".[!.]*; do
  [ -e "$e" ] || continue
  b=$(basename "$e")
  case "$b" in states|results|data) continue ;; esac
  if [ -e "$LAB/$b" ]; then chmod -R u+w "$LAB/$b" 2>/dev/null || true; rm -rf "$LAB/$b"; fi
  cp -R "$e" "$LAB/$b"
done
mkdir -p "$LAB/data" "$LAB/states" "$LAB/results"
for d in "$TMPX/hm64-lab/data/"*; do
  [ -e "$LAB/data/$(basename "$d")" ] || cp -R "$d" "$LAB/data/"
done
chmod -R u+w "$TMPX" 2>/dev/null || true
rm -rf "$TMPX"
echo "  lab code: $(grep -m1 "^ZZ_CODE" "$LAB/tools/zigzag_campaign.py" || echo unknown)"

say "2/6 inputs"
XTR="$WORK/extracted-inputs"; mkdir -p "$XTR"
sha() { shasum -a 256 "$1" | cut -d' ' -f1; }
ROM=$(find -L "$INPUTS" -type f -iname '*.z64' ! -path "*/runs/*" 2>/dev/null | head -n 1 || true)
if [ -z "$ROM" ]; then
  while IFS= read -r z; do
    m=$(unzip -Z1 "$z" 2>/dev/null | grep -i -E '\.z64$' | head -n 1 || true)
    if [ -n "$m" ]; then unzip -q -o -j "$z" "$m" -d "$XTR" && ROM="$XTR/$(basename "$m")" && break; fi
  done < <(find -L "$INPUTS" -type f -iname '*.zip' ! -path "*/runs/*" 2>/dev/null)
fi
[ -n "$ROM" ] || die "no *.z64 ROM under $INPUTS"
# saves: every *.SaveRAM/*.sra/*.sav (also inside zips) under sourcefiles, then Downloads/Desktop/Documents
DOGSAVE=""; S9SAVE=""
check_save() {
  local f="$1" s; s=$(sha "$f")
  if [ "$s" = "$DOGBEACH_SHA" ] && [ -z "$DOGSAVE" ]; then DOGSAVE="$f"; fi
  if [ "$s" = "$SPRING9_SHA" ] && [ -z "$S9SAVE" ]; then S9SAVE="$f"; fi
}
while IFS= read -r f; do check_save "$f"; done < <(find -L "$INPUTS" -type f \( -iname '*.SaveRAM' -o -iname '*.sra' -o -iname '*.sav' \) ! -path "*/runs/*" 2>/dev/null)
if [ -z "$DOGSAVE" ] || [ -z "$S9SAVE" ]; then
  while IFS= read -r z; do
    while IFS= read -r m; do
      [ -n "$m" ] || continue
      unzip -q -o -j "$z" "$m" -d "$XTR" >/dev/null 2>&1 && check_save "$XTR/$(basename "$m")"
    done < <(unzip -Z1 "$z" 2>/dev/null | grep -i -E '\.(SaveRAM|sra|sav)$' || true)
  done < <(find -L "$INPUTS" -type f -iname '*.zip' ! -path "*/runs/*" 2>/dev/null)
fi
if [ -z "$DOGSAVE" ]; then
  for d in "$HOME/Downloads" "$HOME/Desktop" "$HOME/Documents"; do
    [ -d "$d" ] || continue
    while IFS= read -r f; do check_save "$f"; done < <(find "$d" -maxdepth 2 -type f \( -iname '*.SaveRAM' -o -iname '*.sra' \) 2>/dev/null)
    [ -n "$DOGSAVE" ] && break
  done
  if [ -n "$DOGSAVE" ]; then
    cp "$DOGSAVE" "$INPUTS/nohorse-dogbeach-nopickup_0d78b95b.SaveRAM"
    echo "  copied the dog-beach save into sourcefiles/ (from $DOGSAVE)"
    DOGSAVE="$INPUTS/nohorse-dogbeach-nopickup_0d78b95b.SaveRAM"
  fi
fi
[ -n "$DOGSAVE" ] || die "the dog-beach SaveRAM (sha256 0d78b95b...) is not in sourcefiles/, Downloads, Desktop or Documents"
RS=$(sha "$ROM")
[ "$RS" = "$ROM_SHA" ] && echo "  ROM      $ROM  (sha256 OK, NYWE rev00)" || echo "  WARNING: ROM sha256 $RS is not the known NYWE rev00 dump ($ROM)"
echo "  save     $DOGSAVE  (dog-beach, sha256 OK)"
echo "  spring9  ${S9SAVE:-none (lab health test skipped)}"
mkdir -p "$LAB/data/rom" "$LAB/data/saves" "$LAB/data/saves_dogbeach"
chmod -R u+w "$LAB/data" 2>/dev/null || true
cp "$ROM" "$LAB/data/rom/Harvest_Moon_64_USA.z64"
cp "$DOGSAVE" "$LAB/data/saves_dogbeach/nohorse-dogbeach-nopickup.SaveRAM"
[ -n "$S9SAVE" ] && cp "$S9SAVE" "$LAB/data/saves/Harvest_Moon_64_USA3.SaveRAM"
OUTDIR="$LAB/results/campaign-zigzag"
if [ -d "$OUTDIR" ]; then
  echo "  continuing: $(ls "$OUTDIR"/Z*_*.jsonl 2>/dev/null | wc -l | tr -d ' ') stage files already in $OUTDIR"
else
  echo "  new run"
fi
if [ "${HM64_DRY_RUN:-0}" = 1 ]; then echo; echo "DRY RUN: inputs found as above; stopping before Docker."; exit 0; fi
chmod -R a+rwX "$LAB/states" "$LAB/results" "$LAB/experiments" 2>/dev/null || true

say "3/6 building the Docker image (first time: several minutes)"
cd "$LAB"
# shellcheck disable=SC2086
docker build --platform linux/amd64 -t hm64-lab:latest --build-arg INSTALL_CLAUDE="${INSTALL_CLAUDE:-1}" \
  ${HM64_DOCKER_BUILD_EXTRA:-} .
if [ -z "$WORKERS" ]; then
  NCPU=$(docker run --rm --platform linux/amd64 hm64-lab:latest nproc 2>/dev/null || echo 2)
  WORKERS=$(( NCPU > 1 ? NCPU - 1 : 1 ))
fi

say "4/6 lab health test"
if [ -n "$S9SAVE" ]; then
  docker compose run --rm -T lab bash -lc 'python3 tools/smoke_test.py' \
    || die "smoke test failed - see $LOG (results would not be trustworthy)"
else
  echo "  skipped (no Spring 9 save); the zigzag run starts with its own route check (Z0)"
fi

say "5/6 zigzag campaign ($PRESET, $WORKERS workers). Ctrl-C any time; the same command resumes."
SRAM_IN=/work/data/saves_dogbeach/nohorse-dogbeach-nopickup.SaveRAM
docker compose run --rm -T -e HM64_SRAM="$SRAM_IN" -e HM64_ZZ_STOP_AFTER="${HM64_ZZ_STOP_AFTER:-}" \
  -e HM64_ZZ_MAX_LINES="${HM64_ZZ_MAX_LINES:-0}" -e M64H_CPU="${M64H_CPU:-}" -e M64H_RECYCLE="${M64H_RECYCLE:-6}" lab \
  python3 tools/zigzag_campaign.py --preset "$PRESET" --workers "$WORKERS" --out results/campaign-zigzag

say "6/6 collecting results"
OUTZIP="$RUN_ROOT/hm64-campaign-$PRESET-$STAMP.zip"
cp "$LOG" "$OUTDIR/run-$PRESET-$STAMP.log" 2>/dev/null || true
( cd "$LAB/results" && zip -q -r "$OUTZIP" "campaign-zigzag" ) || die "zip failed"
echo
echo "DONE."
echo "  report : $OUTDIR/ZIGZAG.md"
echo "  zip    : $OUTZIP   (no ROM/save/savestates inside; send this one)"
