# HM64 RNG Lab: Claude Code + headless mupen64plus in Docker

An Ubuntu 24.04 container where Claude Code agents can drive Harvest Moon 64
frame by frame: read the RNG and dog state every VI, branch from savestates,
press buttons at exact controller polls, sweep thousands of RNG positions in
parallel, and test whistle → cast → hold → release plans for the ocean Power Nut.

Your ROM, saves and notes stay on your Mac in `data/`, mounted read-only.
Nothing copyrighted is baked into the image.

## 0. One command (deploy + verify + run the campaign + collect results)

Put your files in one folder (any names): the ROM (`*.z64`), the Spring 9
SaveRAM, `ROUTE_TO_CHECKPOINT_LINKS.csv` (from the reset-to-ready kit),
optionally `QuickSave2(1).State`, the 50156 recipes CSV and the decomp zip. Then:

```bash
bash run_hm64_campaign.sh ~/Downloads/hm64-lab.tar.gz ~/HM64_inputs quick
```

It extracts the lab to `~/hm64-lab-runs/<timestamp>/` and builds the image,
then runs the 10-check smoke test (it stops if anything fails). After that it
runs `tools/campaign.py` and writes `~/hm64-lab-runs/hm64-campaign-<preset>-<timestamp>.zip`.
The zip holds REPORT.md, the CSVs, `oracle_table.json` and the raw JSONL, with
no ROM, save or savestates. Presets: `smoke` (minutes), `quick` (121 routes),
`oracle` (quick's routes, casts over the first 20 s, ladder, oracle simulation,
Layer 1 link), `standard` (1,000 routes), `full` (all 36,014 routes, many hours).
The run is resumable; the script prints the resume command. Finished rows and
READY states from the richest earlier run are reused (`HM64_REUSE=0` to start
clean). The Layer 1 index is mounted read-only from
`HM64_LAYER1` (default `<script dir>/HM64_Layer1_Mac_Generator/output`).

## 1. One-time setup (Mac mini M4 Pro)

1. **Docker Desktop**: in *Settings → General*, enable **Use Rosetta for
   x86_64/amd64 emulation on Apple Silicon**. The mupen64plus bundle is
   x86-64, so the image is `linux/amd64`. In *Resources*, give it several CPUs
   (sweeps use one emulator per CPU) and 8 GB+ RAM.
2. **Put your files in `data/`** (see `data/README.md`):
   ```
   data/rom/Harvest_Moon_64_USA.z64
   data/saves/Harvest_Moon_64_USA3.SaveRAM        # or a raw Joey64 SRAM dump
   data/states_bizhawk/Harvest Moon 64 (USA).Mupen64Plus.QuickSave2(1).State
   data/routes/            <- 50156_TIMING_RECIPES_UNCLASSIFIED.csv + ROUTE_TO_CHECKPOINT_LINKS.csv
   data/decomp/            <- unzip hm64-decomp-master.zip here
   data/knowledge/         <- restore your HM64_MASTER_BACKUP parts here (below)
   ```
   For the knowledge base, put `HM64_MASTER_BACKUP_2026-11-11_PART_00…05` and
   `PART_99_INDEX` in one folder. Unzip all of them into `data/knowledge/`
   (or use the backup's own `restore_and_verify.py`). You end up with
   `data/knowledge/LIBRARY/…`, `ORIGINAL_UPLOADS/…` and the index files.
   CLAUDE.md sends agents to the newest v27.7g whistle studies first.
   `vendor/` already contains your `mupen64plus-bundle-linux64-2.6.0.tar.gz`;
   the build checks its SHA-256.
3. **Build**:
   ```bash
   docker compose build
   ```

## 2. Every session

```bash
docker compose run --rm lab        # shell in /work as user 'lab'
make smoke                         # ~1-5 min; must say ALL PASSED
make qs2 && make regress           # converts QuickSave2(1), replays the 8 recorded Nut cases
claude                             # start Claude Code in the project
```

First `claude` run: log in. If the browser can't reach the container, it
shows a code: paste it at `Paste code here if prompted`. Your login lives
in the `claude-state` Docker volume, so it survives rebuilds. For
unattended runs, use `claude setup-token` on the Mac and
`export CLAUDE_CODE_OAUTH_TOKEN=...` before `docker compose run`. Compose
passes it through.

Permissions: `.claude/settings.json` auto-accepts edits and pre-approves
python/make/xvfb-run and read-only shell tools. It also denies writes to
`data/`, which is read-only at the mount level as well. If you want agents
fully unattended inside this container, `claude --dangerously-skip-permissions`
is the usual choice. Remember the container still has network access and
`/work` is your real project folder.

### Your beach pipeline

```bash
make ready      # cold boot -> reset -> menus -> carry route -> dock READY (baseline) -> states/ready/
make replay     # replay a stratified sample of your 36,014 measured routes and compare VI + draw index
python3 tools/route_run.py --case d0,d1,d2,d3,H,C,P,D --save states/ready/<label>.st
python3 tools/seed_sweep.py experiments/arrival_pool.py --out results/<date>-pool/raw.jsonl        # READY pool + natural futures
HM64_CASTS=0:600:2 python3 tools/seed_sweep.py experiments/ready_cast_sweep.py --out results/<date>-casts/raw.jsonl
HM64_WHISTLES="none;10;30" HM64_CASTS=40:400:2 python3 tools/seed_sweep.py experiments/ready_cast_sweep.py --out ...
```

### Things to ask Claude

- "Build the arrival pool from 2,000 recipes in data/routes, group by natural
  signature, then for every scenario find the earliest natural Nut cast and,
  where none exists before poll 600, the earliest whistle+cast rescue."
- "/new-experiment How many distinguishable dog behaviour classes are there in
  the first 15 s after the diary loads, for load index 480–1480?"
- "Use the decomp-analyst to list every rand() consumer active while standing
  on the pier with the rod out, in call order."
- "Extend experiments/qs2_whistle_cast_grid.py so release is relative to the
  bite, sweep k = 0..3 whistles × cast 40..900, and have rng-analyst map the
  Nut windows. Then have verifier re-check the three widest ones."

## 3. What's in the box

| Path | Purpose |
|---|---|
| `m64h/` | Python driver for libmupen64plus: VI-exact stepping, RDRAM read/write, savestates, poll-exact input schedules, screenshots, process pool |
| `native/` | Two small C plugins: scripted input (with poll schedule) and a per-VI video hook (headless or forwarding to rice/glide64mk2) |
| `hm64/` | Decomp-sourced RAM map, exact LCG maths (`index(seed)` → stream position), dog AI model, observers |
| `tools/` | `boot.py` (menu timing → anchors), `trace.py`, `seed_sweep.py`, `validate_dog_model.py`, `convert_bizhawk_state.py`, `regress_qs2.py`, `smoke_test.py` |
| `experiments/` | `dog_observation.py` (what the dog shows per RNG start), `qs2_whistle_cast_grid.py` (k whistles + cast/release on the pier) |
| `.claude/` | `CLAUDE.md` brief, 4 subagents (decomp-analyst, emu-experimenter, rng-analyst, verifier), skills `/smoke`, `/sweep`, `/new-experiment` |

## 4. Verified so far (in this container build)

- **Your route, ported exactly:** the cold-boot carry route reproduces the
  legacy v13 baseline at all 9 stages (cabin VI 1050 → fishing-ready VI 2668,
  RNG `0x37A2FD60`, draw 1312). It also reproduces **158/158** sampled routes
  from your 36,014-route measured cohort (ready VI + draw index), with
  interrupt randomisation off.
- **Fishing windows:** the solver finds every bite window and tries every
  release poll. Once the cast is right, the Nut release window is about
  20 polls wide; the cast poll is the sharp variable (QS2: 84 wins, 83 loses).
- **Intercept lever:** on the baseline arrival, Nut casts are +32 and +120
  (stride-4 scan). One C-right at poll 10 turns cast 120 into a fish and
  creates new Nut casts at +60 and +116.
- **Heads-up on the legacy corpus:** it ran with mupen's default
  `RandomizeInterrupt=True`, seeded from the wall clock, so runs were not
  strictly reproducible. The sampled routes all matched anyway, but suspect
  this first for one-off anomalies.

- Same RNG facts as your BizHawk work: boot seed 0, `0x8FDA0F1F` = stream
  index 1219, `0x705EE83C` (QuickSave2) = 1716, ambient 1 call per 2 VIs.
- **QuickSave2(1) Nut regression 8/8** with real button input: win84/85/424/470,
  fish 40/82/86, and the 83-fails / 84-wins one-poll boundary. Polls are 0-based
  from the moment the state finishes loading.
- `hm64/dog.py` reproduces every dog decision seen (hundreds, 0 unexplained),
  and the dog's RNG calls are always the first in their VI.
- Pressing the diary button later is bit-identical to poking the seed **at the
  map-load instant** (3,600 VIs, 5 delays). Poking after control returns is
  *not* equivalent, because the dog has already rolled during the fade-in.
- Runs are deterministic: three full boots matched VI for VI, and headless runs
  match rice-rendered runs exactly.

## 5. Caveats

- Emulator ≠ console timing. Lag and poll phase can differ on real hardware.
  Results keyed to RNG values and dog observations transfer better than raw
  frame counts. Check anything RTA-critical on the N64.
- Under Rosetta, expect slower emulation than the ~800–1500 VI/s per core
  measured natively. Time a pilot before a big sweep.
- `make native` rebuilds the C plugins into `native/build`. Point the harness
  at them with `export M64H_NATIVE=/work/native/build`.
