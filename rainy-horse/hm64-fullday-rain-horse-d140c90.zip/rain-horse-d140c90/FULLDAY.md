# HM64 full-day lab — the cast table and the dog to the end of the game day

## 1. The day without a cast (every dog line, stay-awake push every 33 s)

- 68 lines ran of 68; dog at READY: [-196.91, 222.09]
- Clock at READY: 06:48 – 06:51. Followed to 8398 VIs = 140 s after READY (the limit).
- Same paths as the dog-watch run? cast hashes of the first 33 s: **67660 equal, 0 different**.
- Ended by something else than the limit / the end of the day: 0
- The dog's visible changes over that time: 142 per line.
- **The dog leaves its spot** (moved 4 units or more) on 62 of 68 lines; earliest 3 s after READY, median 53 s.
- Its tile leaves the visibility grid (not on screen, not animating) on 11 lines.

## 2. Cast blocks (every cast held to the limit, or the end of the day)

| block | cast frames (s after READY) | lines | casts planned | done | job errors | hash check ok / failed / none | ended: as planned / beach check / other | bites per cast | casts with a Nut on some bite |
|---|---|---|---|---|---|---|---|---|---|
| 2 | 40.1 – 80.2 · heavy | 50 | 36008 | 36008 | 0 | 34958 / 0 / 1050 | 36008 / 0 / 0 | 6.2 | 1484 (4.1%) |
| 3 | 40.1 – 80.2 · other | 18 | 4015 | 4015 | 0 | 3637 / 0 / 378 | 4015 / 0 / 0 | 5.5 | 100 (2.5%) |
| 4 | 80.2 – 90.3 · heavy | 41 | 8287 | 8287 | 0 | 8287 / 0 / 0 | 8287 / 0 / 0 | 3.8 | 337 (4.1%) |
| 5 | 80.2 – 90.3 · other | 6 | 912 | 912 | 0 | 912 / 0 / 0 | 912 / 0 / 0 | 3.4 | 47 (5.2%) |

Blocks not started: 2 (53457 casts). Data so far: 52.1 MB.

## 3. The beach check

- 49222 casts: **49222 ran to the limit / the end of the day on the beach at the dock end**, 0 were stopped by the beach check, 0 ended another way.
- Cast hash = the dog-watch run's state at that frame: 47794 equal, **0 different**, 1428 not compared (cast frames inside a stay-awake push).

## 4. Bites and Nuts by game hour (on the held casts)

- 281262 bites; released 4 polls after the bite: m 99113, s 93797, l 86377, N 1975 (N Nut, s / m / l fish size, d the day ended before the catch, x miss, h held through, o other; a / b = the two release probes differ).
- The two release probes of bites 1-2 gave different catches on 0 bites.
- Nut by bite number: bite 1: 597, bite 2: 342, bite 3: 273, bite 4: 229, bite 5+: 534.

| game hour | bites | Nut bites | Nut share |
|---|---|---|---|
| 10:00 | 3157 | 58 | 1.84% |
| 11:00 | 12528 | 652 | 5.20% |
| 12:00 | 36380 | 1 | 0.00% |
| 13:00 | 50997 | 2 | 0.00% |
| 14:00 | 49562 | 252 | 0.51% |
| 15:00 | 37500 | 746 | 1.99% |
| 16:00 | 41112 | 245 | 0.60% |
| 17:00 | 33561 | 10 | 0.03% |
| 18:00 | 14874 | 0 | 0.00% |
| 19:00 | 1530 | 9 | 0.59% |
| 20:00 | 18 | 0 | 0.00% |
| 21:00 | 18 | 0 | 0.00% |
| 22:00 | 25 | 0 | 0.00% |

These are bites of casts HELD since the cast frame, not fresh casts at that hour: a later hour is
reached only by holding through every earlier bite.

## 5. Do the held casts run into each other?

- 281262 bite states, 34363 distinct (87.8% shared): a shared state has the same future, so its later bites need not be simulated twice.

## 6. The dog after the cast

- Visible changes recorded from the cast to the end of its run: 71 per cast; on the released paths (the 4 s after each bite): 4.9 per bite.
- The dog leaves its spot at some point of the run in 40274 of 49222 casts (82%).

## 7. Against the dog-watch run's cast table (same state hash)

- 0 casts are in both: bite times and Nut flags **equal in 0, different in 0**.

