# HM64 full-day lab — the cast table and the dog to the end of the game day

## 1. The day without a cast (every dog line, stay-awake push every 33 s)

- 68 lines ran of 68; dog at READY: [-196.91, 222.09]
- Clock at READY: 06:48 – 06:51. Followed to 10198 VIs = 170 s after READY (the limit).
- Same paths as the dog-watch run? cast hashes of the first 33 s: **67660 equal, 0 different**.
- Ended by something else than the limit / the end of the day: 0
- The dog's visible changes over that time: 169 per line.
- **The dog leaves its spot** (moved 4 units or more) on 62 of 68 lines; earliest 3 s after READY, median 53 s.
- Its tile leaves the visibility grid (not on screen, not animating) on 19 lines.

## 2. Cast blocks (every cast held to the limit, or the end of the day)

| block | cast frames (s after READY) | lines | casts planned | done | job errors | hash check ok / failed / none | ended: as planned / beach check / other | bites per cast | casts with a Nut on some bite |
|---|---|---|---|---|---|---|---|---|---|
| 4 | 80.2 – 120.3 · heavy | 50 | 31975 | 31975 | 0 | 30925 / 0 / 1050 | 31975 / 0 / 0 | 4.7 | 1591 (5.0%) |
| 5 | 80.2 – 120.3 · other | 18 | 4003 | 4003 | 0 | 3625 / 0 / 378 | 4003 / 0 / 0 | 4.5 | 88 (2.2%) |

Blocks not started: 4 (93480 casts). Data so far: 32.9 MB.

## 3. The beach check

- 35978 casts: **35978 ran to the limit / the end of the day on the beach at the dock end**, 0 were stopped by the beach check, 0 ended another way.
- Cast hash = the dog-watch run's state at that frame: 34550 equal, **0 different**, 1428 not compared (cast frames inside a stay-awake push).

## 4. Bites and Nuts by game hour (on the held casts)

- 167442 bites; released 4 polls after the bite: s 63766, m 52213, l 49777, N 1686 (N Nut, s / m / l fish size, d the day ended before the catch, x miss, h held through, o other; a / b = the two release probes differ).
- The two release probes of bites 1-2 gave different catches on 0 bites.
- Nut by bite number: bite 1: 284, bite 2: 441, bite 3: 476, bite 4: 236, bite 5+: 249.

| game hour | bites | Nut bites | Nut share |
|---|---|---|---|
| 13:00 | 610 | 2 | 0.33% |
| 14:00 | 9313 | 47 | 0.50% |
| 15:00 | 23657 | 325 | 1.37% |
| 16:00 | 21022 | 248 | 1.18% |
| 17:00 | 35952 | 337 | 0.94% |
| 18:00 | 11190 | 0 | 0.00% |
| 19:00 | 38971 | 725 | 1.86% |
| 20:00 | 24620 | 2 | 0.01% |
| 21:00 | 1369 | 0 | 0.00% |
| 22:00 | 604 | 0 | 0.00% |
| 23:00 | 128 | 0 | 0.00% |
| 00:00 | 6 | 0 | 0.00% |

These are bites of casts HELD since the cast frame, not fresh casts at that hour: a later hour is
reached only by holding through every earlier bite.

## 5. Do the held casts run into each other?

- 167442 bite states, 28098 distinct (83.2% shared): a shared state has the same future, so its later bites need not be simulated twice.

## 6. The dog after the cast

- Visible changes recorded from the cast to the end of its run: 63 per cast; on the released paths (the 4 s after each bite): 4.4 per bite.
- The dog leaves its spot at some point of the run in 31516 of 35978 casts (88%).

## 7. Against the dog-watch run's cast table (same state hash)

- 0 casts are in both: bite times and Nut flags **equal in 0, different in 0**.

