# Dog-spot lab (dogwatch): rain-lineup2-horse-287c11a6.SaveRAM

Zig-zag route with the zigzag-fast recipe of route delays, dog-neutral (no dog-wake rule or key: every first / second cut is walked and kept, lines are anchored at the beach load and matched by game state at READY).

## The save

- file `rain-lineup2-horse-287c11a6.SaveRAM` (sha256 287c11a65fa9745e)
- spring 9, year 1; weather 2; 6:00 at the house load; rod in hand: True
- dog at the house load: **beach** (map 9) x -196.91, z 222.09, facing 0, flags ACTIVE
- dog on screen at the load of: beach
- repeatable (two cold boots give the same record): **yes**
- reference route (mash 10/s START→A, house U276 V52, crossroads C80, beach D86 B134), map loads: house VI 1036, farm +412, crossroads +350, ranch +236, beach +230; READY 339 VIs after the beach load at x -92.0, z 194.0

## Failure map: where the recipe never reaches READY

Mass = uniform choices over this preset's grids (mash phase per rate, rates pooled; house U, V; crossroads C; first cut D; any second cut B). Each stage starts from the mass kept by the stage before.

| stage | runs | never reached | mass kept | outside the band (slower; or faster for a 5-9-frame preset) | never reached (mass) | where Jack stopped (most common) |
|---|---|---|---|---|---|---|
| menus | 144 | 0 | 0.6675 | 0.3325 | 0.0000 | - |
| house | 2548 | 462 | 0.2733 | 0.2733 | 0.1210 | 364× map 87 x≈96 z≈80; 28× map 87 x≈-24 z≈120; 28× map 87 x≈-32 z≈128 |
| crossroads | 324 | 9 | 0.2505 | 0.0152 | 0.0076 | 9× map 78 x≈120 z≈0 |
| ranch | 8 | 0 | 0.2505 | 0.0000 | 0.0000 | - |
| beach | 256 | 0 | 0.2505 | 0.0000 | 0.0000 | - |

- **mass of the recipe that reaches the dock end: 0.2505** (the D grid includes 82–83, which never clear the small wall on the dog-beach save)

| first cut D | P(some B reaches the dock end) | B in the window (VIs: count of beach states) | why the other B stop (D without a window) |
|---|---|---|---|
| 84 | 1.000 | 22: 128 | - |
| 86 | 1.000 | 22: 128 | - |

Second cut B by first cut D (share of the beach-state mass that reaches the dock end; else why Jack stopped, and where):

- D 84: 112–121 no READY (map 9 x≈-208 z≈120) · 122–143 READY · 144–151 no READY (map 9 x≈-224 z≈224)
- D 86: 112–117 no READY (map 9 x≈-208 z≈128) · 118–139 READY · 140–151 no READY (map 9 x≈-224 z≈224)

| 1st cut (web app bands) | share of the D grid | P(a 2nd cut reaches the dock end) |
|---|---|---|
| tight | 1.000 | 1.000 |

## Lines (dog-neutral: anchored at the beach load, matched by game state at READY)

- 68 lines from 128 beach states; lines per beach state (count of states): 3: 5, 4: 123; **0 of 128 beach states collapse to one line** (every first and second cut of that state shares one RNG trajectory, offset in time only)
- largest READY offset inside a line: 44 VIs; members not matched to any path: 0

## Cut timing, split as the web app does (cast spread 150 ms)

| preset | share of routes | release bite 1 | hold to bite 2 | either (upper bound) |
|---|---|---|---|---|
| All | 1.000 | 5.95% at 21.07 s | 4.54% at 7.53 s | 8.81% at 27.7 s |
| 1st cut tight | 1.000 | 5.95% at 21.07 s | 4.54% at 7.53 s | 8.81% at 27.7 s |
| 1st cut tight · 2nd cut early | 0.545 | 6.35% at 21.17 s | 4.83% at 7.6 s | 9.08% at 27.8 s |
| 1st cut tight · 2nd cut middle | 0.182 | 6.35% at 21.07 s | 4.89% at 7.53 s | 9.25% at 27.7 s |
| 1st cut tight · 2nd cut late | 0.273 | 6.19% at 20.93 s | 4.71% at 7.4 s | 9.12% at 27.53 s |
| 1st cut mid | 0.000 | - | - | - |
| 1st cut mid · 2nd cut early | 0.000 | - | - | - |
| 1st cut mid · 2nd cut middle | 0.000 | - | - | - |
| 1st cut mid · 2nd cut late | 0.000 | - | - | - |
| 1st cut loose | 0.000 | - | - | - |
| 1st cut loose · 2nd cut early | 0.000 | - | - | - |
| 1st cut loose · 2nd cut middle | 0.000 | - | - | - |
| 1st cut loose · 2nd cut late | 0.000 | - | - | - |

## Lineup: stability

- 68 lines; the heaviest holds 5.0% of the routes; 20 lines hold 50% and 50 hold 90% (fewer = steadier dog)
- one beach start (beach state + wait) across the full pier width: lines (count of starts) 3: 5, 4: 123; how the second cuts split: B 118-119 + B 120-123 + B 122-139 + B 126-143 (121 starts); B 118-143 + B 120-123 + B 122-139 (3 starts); B 118-119 + B 120-121 + B 122-139 + B 122-143 (2 starts); B 118-139 + B 120-123 + B 126-143 (2 starts)
- one wait + second cut across the beach states (the route before the beach): lines (count) 5: 160, 9: 48, 10: 208

## Lineup: does the dog keep drawing after READY (standing at the pier, no cast)?

- routes whose line has the dog drawing after READY: **100.0%**; extra draws over 39 s (above the 1-per-game-frame clock), route-weighted mean 20653; dog's tile visible 99% of the time

## Lineup: where the dog activates (its tile enters the camera's view; until then it draws nothing)

First VI after the beach load (share of routes): 205: 0.3%, 207: 0.9%, 209: 3.7%, 211: 6.3%, 213: 6.2%, 215: 6.3%, 217: 6.3%, 219: 6.3%, 221: 6.3%, 223: 6.3%, 225: 6.2%, 227: 6.3%, 229: 6.2%, 231: 6.3%, 233: 6.3%, 235: 6.3%, 237: 6.0%, 239: 5.4%, 241: 2.6%

| Jack at the activation (x, z; 8-unit cells) | share of routes | lines | release bite 1 | hold to bite 2 |
|---|---|---|---|---|
| x -456…-448, z 160…168 | 0.727 | 61 | 5.99% at 21.03 s (cover 0.98) | 4.55% at 7.5 s (cover 0.96) |
| x -448…-440, z 152…160 | 0.182 | 65 | 6.35% at 21.2 s (cover 0.97) | 4.81% at 7.67 s (cover 0.96) |
| x -448…-440, z 144…152 | 0.091 | 61 | 6.55% at 21.13 s (cover 0.97) | 5.00% at 7.57 s (cover 0.93) |

## Lineup: beach wait W (VIs Jack stands still at the beach load before his first step)

| W (VIs) | share of routes | lines | release bite 1 | hold to bite 2 |
|---|---|---|---|---|
| 0 | 0.062 | 18 | 8.71% at 20.2 s (cover 0.88) | 6.93% at 7.57 s (cover 0.83) |
| 2 | 0.062 | 16 | 9.13% at 21.23 s (cover 0.97) | 9.03% at 7.57 s (cover 0.95) |
| 4 | 0.062 | 17 | 11.26% at 11.7 s (cover 0.99) | 7.83% at 17.3 s (cover 0.99) |
| 6 | 0.062 | 17 | 7.26% at 20.03 s (cover 1.00) | 5.04% at 3.67 s (cover 1.00) |
| 8 | 0.062 | 17 | 8.60% at 24.63 s (cover 1.00) | 7.49% at 9.8 s (cover 1.00) |
| 10 | 0.062 | 17 | 9.20% at 24.53 s (cover 1.00) | 15.75% at 9.8 s (cover 1.00) |
| 12 | 0.062 | 17 | 9.18% at 9.43 s (cover 1.00) | 10.30% at 9.83 s (cover 1.00) |
| 14 | 0.062 | 17 | 11.00% at 8.17 s (cover 1.00) | 6.14% at 27.0 s (cover 1.00) |
| 16 | 0.062 | 18 | 8.78% at 8.2 s (cover 1.00) | 6.07% at 7.23 s (cover 1.00) |
| 18 | 0.062 | 18 | 6.48% at 21.07 s (cover 1.00) | 9.09% at 7.23 s (cover 1.00) |
| 20 | 0.062 | 17 | 8.31% at 31.03 s (cover 1.00) | 9.82% at 7.2 s (cover 1.00) |
| 22 | 0.062 | 17 | 12.46% at 4.0 s (cover 0.94) | 8.25% at 20.6 s (cover 1.00) |
| 24 | 0.062 | 17 | 9.49% at 20.97 s (cover 1.00) | 6.79% at 27.57 s (cover 1.00) |
| 26 | 0.062 | 18 | 11.21% at 21.83 s (cover 0.94) | 10.04% at 20.03 s (cover 0.94) |
| 28 | 0.062 | 18 | 9.39% at 24.37 s (cover 0.93) | 6.50% at 23.1 s (cover 0.93) |
| 30 | 0.062 | 18 | 9.81% at 21.93 s (cover 0.90) | 9.90% at 23.2 s (cover 0.93) |

## Lineup: first cut D (VIs of down-right after the beach load, before the cut down-left)

D 84 = the earliest cut that clears the small wall (scrapes its corner: Jack pushed to x -451.6); D 86 = one game frame later (clears the corner: x -452.0, still the wall column of the dog's view grid).

| first cut | share of routes | lines | of them shared with the other cut | dog wakes, VI after the beach load - W (share) | release bite 1 | hold to bite 2 |
|---|---|---|---|---|---|---|
| D 84 | 0.500 | 64 | 61 | 211 (82%), 207 (9%), 209 (9%) | 5.86% at 21.07 s (cover 0.98) | 4.57% at 7.53 s (cover 0.95) |
| D 86 | 0.500 | 65 | 61 | 209 (82%), 205 (9%), 207 (9%) | 6.07% at 21.1 s (cover 0.97) | 4.52% at 7.53 s (cover 0.97) |

## Lineup: wait band x second cut (full pier width; early / middle / late = dock-end spot z ≤178 / ≤190 / >190)

| wait | 2nd cut | share of routes | lines | release bite 1 | hold to bite 2 |
|---|---|---|---|---|---|
| wait 0-9 | any | 0.312 | 32 | 7.03% at 11.7 s (cover 0.95) | 5.63% at 7.53 s (cover 0.95) |
| wait 0-9 | Early | 0.170 | 32 | 7.70% at 11.77 s (cover 0.93) | 6.21% at 7.6 s (cover 0.93) |
| wait 0-9 | Middle | 0.057 | 24 | 7.54% at 11.67 s (cover 0.98) | 6.26% at 7.5 s (cover 0.98) |
| wait 0-9 | Late | 0.085 | 24 | 7.26% at 11.53 s (cover 0.98) | 5.94% at 7.4 s (cover 0.98) |
| wait 10-19 | any | 0.312 | 33 | 7.12% at 8.17 s (cover 1.00) | 6.27% at 9.83 s (cover 1.00) |
| wait 10-19 | Early | 0.170 | 33 | 7.61% at 8.27 s (cover 1.00) | 7.01% at 9.87 s (cover 1.00) |
| wait 10-19 | Middle | 0.057 | 25 | 7.83% at 8.17 s (cover 1.00) | 6.44% at 9.8 s (cover 1.00) |
| wait 10-19 | Late | 0.085 | 25 | 7.49% at 8.03 s (cover 1.00) | 6.16% at 9.67 s (cover 1.00) |
| wait 20-30 | any | 0.375 | 36 | 8.09% at 21.9 s (cover 0.97) | 6.15% at 20.13 s (cover 0.97) |
| wait 20-30 | Early | 0.205 | 36 | 8.53% at 22.0 s (cover 0.97) | 6.52% at 20.17 s (cover 0.97) |
| wait 20-30 | Middle | 0.068 | 29 | 8.95% at 21.9 s (cover 0.96) | 6.53% at 20.07 s (cover 0.96) |
| wait 20-30 | Late | 0.102 | 29 | 8.63% at 21.77 s (cover 0.96) | 6.24% at 19.97 s (cover 0.96) |
| any wait | any | 1.000 | 68 | 5.95% at 21.07 s (cover 0.98) | 4.54% at 7.53 s (cover 0.96) |
| any wait | Early | 0.545 | 68 | 6.35% at 21.17 s (cover 0.98) | 4.83% at 7.6 s (cover 0.96) |
| any wait | Middle | 0.182 | 61 | 6.35% at 21.07 s (cover 0.98) | 4.89% at 7.53 s (cover 0.96) |
| any wait | Late | 0.273 | 61 | 6.19% at 20.93 s (cover 0.98) | 4.71% at 7.4 s (cover 0.96) |

## Menus (mash until the house loads)

| style | presses/s | held VIs | house arrival VI (count of phases) |
|---|---|---|---|
| START+A | 15.0 | 2 | 1038×2, 1040×2 |
| START+A | 12.0 | 2 | 1042×2, 1044×2, 1046×1 |
| START+A | 10.0 | 3 | 1042×2, 1044×2, 1046×2 |
| START+A | 8.6 | 3 | 1042×1, 1044×1, 1046×1, 1048×1, 1050×1, 1052×1, 1054×1 |
| START+A | 7.5 | 4 | 1038×2, 1040×2, 1042×2, 1044×2 |
| START+A | 6.7 | 4 | 1038×1, 1040×2, 1042×2, 1044×2, 1046×1, 1056×1 |
| START+A | 6.0 | 5 | 1052×2, 1054×2, 1056×2, 1058×2, 1060×2 |
| START+A | 5.5 | 5 | 1050×2, 1052×2, 1054×2, 1056×2, 1058×2, 1060×1 |
| START+A | 5.0 | 6 | 1054×2, 1056×2, 1058×2, 1060×2, 1064×2, 1074×2 |
| START>A | 15.0 | 2 | 1038×2, 1040×2 |
| START>A | 12.0 | 2 | 1042×2, 1044×2, 1046×1 |
| START>A | 10.0 | 3 | 1036×1, 1038×1, 1040×1, 1042×1, 1044×1, 1046×1 |
| START>A | 8.6 | 3 | 1042×1, 1044×2, 1046×2, 1048×2 |
| START>A | 7.5 | 4 | 1038×2, 1040×2, 1042×2, 1044×2 |
| START>A | 6.7 | 4 | 1038×1, 1040×2, 1042×2, 1044×2, 1046×1, 1056×1 |
| START>A | 6.0 | 5 | 1052×2, 1054×2, 1056×2, 1058×2, 1060×2 |
| START>A | 5.5 | 5 | 1050×2, 1052×2, 1054×2, 1056×2, 1058×2, 1060×1 |
| START>A | 5.0 | 6 | 1042×2, 1044×2, 1046×2, 1048×2, 1052×2, 1062×2 |

## House (up-left U, down-left V, down) — farm arrival, VIs after the house load: count of (U, V) runs

412:28, 414:112, 416:336, 418:357, 420:210, 422:217, 424:224, 426:91, 428:70, 430:112, 432:56, 434:63, 436:56, 438:56, 440:35, 442:28, 444:28, 446:7, None:462

## Crossroads (left, cut down-left at C) — ranch arrival, VIs after the farm load: count of runs

586:90, 588:72, 590:90, 592:45, 594:18, None:9

## Beach (first cut D, second cut B; VIs after the beach load)

| D | dog first moved, VIs after the beach load (count) | B reaching the dock end (total) | READY windows (B) |
|---|---|---|---|
| 84 | None×128 | 2816 | 122–143 |
| 86 | None×128 | 2816 | 118–139 |

## Dog lines: 68 (members = beach state × D × B that reach the dock end)

- casts evaluated: 46479 distinct states; repeat checks agree 178, disagree 0

| line | weight | members | beach draw | READY spread (VIs) | casts | Nut casts b1 / b2 |
|---|---|---|---|---|---|---|
| f854da1e5bf380a1 | 0.050 | 298 | 7825 | 44 | 1197 | 23 / 22 |
| cb9af98637d4cee7 | 0.039 | 226 | 7825 | 28 | 1197 | 34 / 12 |
| d36cfa1545a26a52 | 0.039 | 220 | 7792 | 44 | 1197 | 22 / 25 |
| e75839ed20ac4d79 | 0.039 | 220 | 7792 | 30 | 1197 | 18 / 18 |
| fa44acfa1ef56ffd | 0.038 | 216 | 7792 | 44 | 1197 | 24 / 25 |
| dce416a41ee26f1d | 0.026 | 132 | 7777 | 30 | 1197 | 24 / 8 |
| e9a283665cb676ba | 0.023 | 136 | 7792 | 38 | 1197 | 28 / 7 |
| 9c4cf93a7bb3c937 | 0.022 | 132 | 7825 | 22 | 1197 | 33 / 16 |
| dcb5328da64d3999 | 0.022 | 132 | 7825 | 22 | 1197 | 24 / 18 |
| de0e6c3605d53567 | 0.022 | 132 | 7883 | 22 | 1197 | 26 / 20 |
| fdd8c8042e975e55 | 0.022 | 132 | 7825 | 22 | 1197 | 12 / 26 |
| e35872c0d15b7c55 | 0.022 | 132 | 7825 | 22 | 1197 | 25 / 13 |
| e87f369e249da52d | 0.022 | 132 | 7825 | 22 | 1197 | 22 / 18 |
| d789b381019018b2 | 0.021 | 126 | 7792 | 44 | 1197 | 26 / 23 |
| f5093b1ade932e47 | 0.020 | 114 | 7825 | 22 | 1197 | 18 / 11 |
| 6cc2bcd8bd5a5ade | 0.019 | 120 | 7883 | 22 | 1197 | 21 / 23 |
| 908cfa1221fd430d | 0.019 | 106 | 7792 | 44 | 1197 | 23 / 33 |
| 5df6e88f60d2cf63 | 0.017 | 88 | 7792 | 22 | 1197 | 26 / 18 |
| 8154ebac69d1d19f | 0.017 | 88 | 7792 | 22 | 1197 | 26 / 12 |
| b2bab17f1d18ce28 | 0.017 | 88 | 7792 | 22 | 1197 | 48 / 13 |
| c4e2c528f727c6f0 | 0.017 | 88 | 7792 | 22 | 1197 | 25 / 20 |
| dadf8e16a70d9060 | 0.017 | 88 | 7792 | 22 | 1197 | 30 / 9 |
| f806db990f1e14bb | 0.017 | 88 | 7792 | 22 | 1197 | 44 / 13 |
| b657682cd53fdbb4 | 0.016 | 84 | 7792 | 22 | 1197 | 29 / 8 |
| ef103b317540b5ca | 0.016 | 96 | 7858 | 22 | 1197 | 19 / 14 |
| 2645c7450d4c783b | 0.015 | 76 | 7792 | 22 | 1197 | 26 / 18 |
| aae24d9daca5a7c5 | 0.014 | 88 | 7858 | 22 | 1197 | 12 / 26 |
| 2653f09a996eea9a | 0.014 | 88 | 7858 | 22 | 1197 | 35 / 25 |
| 311f46766c66d290 | 0.014 | 88 | 7858 | 22 | 1197 | 28 / 17 |
| 382ac33976f70e6e | 0.014 | 88 | 7858 | 22 | 1197 | 17 / 14 |
| 5ead415cd2883527 | 0.014 | 88 | 7858 | 22 | 1197 | 26 / 16 |
| 77b8cbb8ace41c1c | 0.014 | 88 | 7858 | 22 | 1197 | 32 / 17 |
| 838d30de3c502d94 | 0.014 | 88 | 7858 | 22 | 1197 | 33 / 20 |
| 8e95668b98c0e1f0 | 0.014 | 88 | 7858 | 22 | 1197 | 28 / 18 |
| b57d57d0d3f39249 | 0.014 | 88 | 7858 | 22 | 1197 | 29 / 4 |
| bf93ce322514c180 | 0.014 | 88 | 7858 | 22 | 1197 | 35 / 16 |
| c2697fad3378ad31 | 0.014 | 88 | 7858 | 22 | 1197 | 24 / 11 |
| ee61e19a4e3dc6f0 | 0.014 | 88 | 7858 | 22 | 1197 | 27 / 18 |
| 8db4ed1bed8d2c21 | 0.014 | 84 | 7858 | 22 | 1197 | 17 / 17 |
| fe7f2f844d3b73ad | 0.012 | 76 | 7858 | 22 | 1197 | 31 / 15 |

## Lucky Timer, whole pool (aim = time after READY at the dock end; cast spread 1 s.d.)

| spread | release bite 1 | hold to bite 2 | either (smart, upper bound) | coverage at best |
|---|---|---|---|---|
| 0 ms | 6.9% at 21.13 s | 6.2% at 7.57 s | 9.8% at 27.63 s | 0.977 |
| 100 ms | 6.3% at 21.1 s | 4.9% at 7.57 s | 9.1% at 27.67 s | 0.977 |
| 150 ms | 5.9% at 21.07 s | 4.5% at 7.53 s | 8.8% at 27.7 s | 0.977 |
| 250 ms | 5.5% at 21.07 s | 4.4% at 7.43 s | 8.3% at 27.7 s | 0.977 |

- **Member recast check** (casts from members' own routes vs the shared line table): agree 612, disagree 10, no table entry 0

  - ['f5093b1ade932e47', 'a2754bf38d501b81@w2', 84, 129, 568, [904, False, 1638, False], [1638, False, 1718, False]]
  - ['e75839ed20ac4d79', 'b1f0b9bee181ee8c@w20', 86, 130, 1966, [3234, False, 3378, False], [3230, False, 4406, False]]
  - ['fdd8c8042e975e55', 'a2754bf38d501b81@w14', 86, 134, 2122, [3040, False, 5936, False], [3040, False, 4722, False]]
  - ['f5093b1ade932e47', 'a2754bf38d501b81@w2', 84, 136, 1410, [2396, False, 3208, False], [1790, False, 2396, False]]
  - ['6cc2bcd8bd5a5ade', 'a2754bf38d501b81@w30', 86, 139, 1450, [1776, False, 2382, False], [1768, False, 1814, False]]
  - ['6cc2bcd8bd5a5ade', 'a2754bf38d501b81@w30', 86, 139, 1678, [2406, False, 3218, False], [1796, False, 2056, False]]
  - ['6cc2bcd8bd5a5ade', 'a2754bf38d501b81@w30', 86, 139, 2304, [2476, False, 2772, False], [2450, False, 2668, False]]
  - ['6cc2bcd8bd5a5ade', 'a2754bf38d501b81@w28', 84, 140, 1424, [1772, False, 2378, False], [1772, False, 2544, False]]
  - ['6cc2bcd8bd5a5ade', 'a2754bf38d501b81@w28', 84, 140, 1760, [2414, False, 3226, False], [2064, False, 2708, False]]
  - ['6cc2bcd8bd5a5ade', 'a2754bf38d501b81@w28', 84, 140, 2304, [2394, False, 2624, False], [3040, False, 3250, False]]
