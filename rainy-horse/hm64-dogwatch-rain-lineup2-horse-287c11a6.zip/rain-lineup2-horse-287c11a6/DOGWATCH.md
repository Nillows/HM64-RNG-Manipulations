# Dog-watch report: rain-lineup2-horse-287c11a6

68 dog lines with traces (40 s after READY), 613 (line, READY offset) variants; route-weighted. Clock = the dock-end tap ±3 VI; logs from 1.0 s after READY; runner: changes >= 12 VI, reaction 10-25 VI, 15% missed. Odds: cast >= 2 s after the window, ±150 ms.

## What the dog does while you wait (after READY, route-weighted)

- dog's tile on the visibility grid (it animates only then): 99% of the time
- visible changes per minute: 61; changes lasting >= 12 VI: 88%
- facing on screen (share of the wait): SW 40%, NE 17%, SE 14%, W 9%, NW 9%, E 6%, N 5%; animations readable (dog faces S / N / NE / E / SE): 42%
- the dog moves (units, max over the trace): median 0.0
- decision (actionState change) -> next visible change: median 0 VI (p10 0, p90 30); animation set -> displayed: median 0 VI

## Telling the lines apart (simulated runners)

| logging | window | right line on top | posterior on it | >= 90% sure | lines left | logs | Nut (no logs -> logs) | known line |
|---|---|---|---|---|---|---|---|---|
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 3 s | 36% | 29% | 20% | 34.2 | 0.4 | 6.6% -> 15.4% | 41.2% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 5 s | 49% | 47% | 41% | 28.8 | 0.8 | 7.0% -> 21.4% | 41.6% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 10 s | 52% | 49% | 44% | 28.8 | 1.6 | 5.3% -> 21.8% | 38.4% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 15 s | 67% | 62% | 54% | 20.3 | 2.3 | 5.5% -> 24.5% | 37.3% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 20 s | 74% | 65% | 56% | 18.7 | 3.0 | 5.6% -> 21.5% | 31.7% |
| gear, arrows only (no arrow = same facing) | 3 s | 24% | 17% | 8% | 36.4 | 0.1 | 7.3% -> 12.8% | 43.0% |
| gear, arrows only (no arrow = same facing) | 5 s | 32% | 27% | 17% | 31.2 | 0.2 | 5.8% -> 14.5% | 41.3% |
| gear, arrows only (no arrow = same facing) | 10 s | 42% | 35% | 23% | 28.8 | 0.3 | 6.0% -> 16.7% | 38.6% |
| gear, arrows only (no arrow = same facing) | 15 s | 46% | 41% | 30% | 25.0 | 0.5 | 6.6% -> 18.9% | 38.1% |
| gear, arrows only (no arrow = same facing) | 20 s | 60% | 56% | 43% | 18.6 | 0.9 | 4.0% -> 19.7% | 31.1% |
| your logging (arrows always, letters for long animations facing S/N/E) | 3 s | 29% | 25% | 15% | 48.4 | 0.4 | 7.2% -> 15.3% | 41.9% |
| your logging (arrows always, letters for long animations facing S/N/E) | 5 s | 44% | 39% | 33% | 40.0 | 0.8 | 6.5% -> 19.1% | 42.4% |
| your logging (arrows always, letters for long animations facing S/N/E) | 10 s | 50% | 45% | 40% | 36.1 | 1.5 | 6.9% -> 21.0% | 39.1% |
| your logging (arrows always, letters for long animations facing S/N/E) | 15 s | 64% | 58% | 50% | 25.3 | 2.4 | 5.5% -> 23.3% | 35.8% |
| your logging (arrows always, letters for long animations facing S/N/E) | 20 s | 72% | 67% | 58% | 19.6 | 3.9 | 4.3% -> 22.3% | 30.9% |
| arrows only (facing track + durations) | 3 s | 15% | 12% | 7% | 59.8 | 0.1 | 6.5% -> 9.6% | 41.5% |
| arrows only (facing track + durations) | 5 s | 22% | 17% | 13% | 55.8 | 0.2 | 6.7% -> 12.5% | 41.3% |
| arrows only (facing track + durations) | 10 s | 28% | 22% | 16% | 51.8 | 0.3 | 5.4% -> 12.0% | 38.0% |
| arrows only (facing track + durations) | 15 s | 48% | 42% | 32% | 36.7 | 0.6 | 6.8% -> 18.0% | 37.1% |
| arrows only (facing track + durations) | 20 s | 54% | 47% | 38% | 32.4 | 0.9 | 4.2% -> 18.3% | 32.5% |
| every change, letter + arrow | 3 s | 66% | 62% | 44% | 12.0 | 1.4 | 6.2% -> 29.8% | 42.2% |
| every change, letter + arrow | 5 s | 92% | 88% | 74% | 1.8 | 3.1 | 7.9% -> 37.6% | 41.3% |
| every change, letter + arrow | 10 s | 96% | 94% | 86% | 1.2 | 6.7 | 5.7% -> 35.7% | 37.5% |
| every change, letter + arrow | 15 s | 95% | 94% | 87% | 1.3 | 10.3 | 6.7% -> 35.4% | 36.9% |
| every change, letter + arrow | 20 s | 97% | 96% | 92% | 1.3 | 14.3 | 4.0% -> 30.4% | 31.7% |
| every animation change, letter only | 3 s | 70% | 65% | 47% | 10.7 | 1.4 | 6.8% -> 30.6% | 41.9% |
| every animation change, letter only | 5 s | 90% | 88% | 76% | 2.4 | 3.0 | 7.0% -> 37.6% | 41.7% |
| every animation change, letter only | 10 s | 95% | 95% | 90% | 1.1 | 6.6 | 5.4% -> 36.8% | 38.3% |
| every animation change, letter only | 15 s | 95% | 94% | 86% | 1.3 | 10.3 | 5.1% -> 35.7% | 37.2% |
| every animation change, letter only | 20 s | 96% | 94% | 87% | 1.3 | 14.1 | 4.7% -> 29.9% | 31.2% |
| Space at every change | 3 s | 15% | 10% | 0% | 33.1 | 1.5 | 6.6% -> 9.1% | 41.2% |
| Space at every change | 5 s | 42% | 29% | 5% | 14.5 | 3.1 | 5.7% -> 20.4% | 42.3% |
| Space at every change | 10 s | 85% | 78% | 56% | 2.4 | 6.7 | 5.6% -> 31.9% | 37.3% |
| Space at every change | 15 s | 94% | 91% | 80% | 1.5 | 10.4 | 6.8% -> 34.4% | 36.4% |
| Space at every change | 20 s | 94% | 93% | 85% | 1.5 | 14.3 | 4.4% -> 30.0% | 31.4% |

Readability: *your logging* follows Thomas's TV check (facing always readable; animations only while the dog
faces S, N, NE, E or SE, and only animations lasting >= 1 s are logged). The other rows are for comparison.

## Duds before the cast (reset early)

Dud = the best cast for what your logs leave is under the threshold; you reset instead of casting. Odds per attempt; 'kept' = attempts you cast.

| logging | window | threshold | attempts called dud | Nut on kept attempts | Nut the resets threw away | all-cast Nut |
|---|---|---|---|---|---|---|
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 3 s | 5% | 0% | 15.4% | 0.00 pts | 15.4% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 3 s | 8% | 60% | 31.4% | 2.94 pts | 15.4% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 5 s | 5% | 0% | 21.4% | 0.00 pts | 21.4% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 5 s | 8% | 51% | 37.1% | 3.33 pts | 21.4% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 10 s | 5% | 0% | 21.8% | 0.00 pts | 21.8% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 10 s | 8% | 51% | 37.7% | 3.38 pts | 21.8% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 15 s | 5% | 1% | 24.8% | 0.00 pts | 24.5% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 15 s | 8% | 36% | 35.6% | 1.95 pts | 24.5% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 20 s | 5% | 2% | 21.9% | 0.00 pts | 21.5% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 20 s | 8% | 34% | 28.6% | 2.60 pts | 21.5% |
| gear, arrows only (no arrow = same facing) | 3 s | 5% | 0% | 12.8% | 0.00 pts | 12.8% |
| gear, arrows only (no arrow = same facing) | 3 s | 8% | 62% | 23.6% | 3.92 pts | 12.8% |
| gear, arrows only (no arrow = same facing) | 5 s | 5% | 0% | 14.5% | 0.00 pts | 14.5% |
| gear, arrows only (no arrow = same facing) | 5 s | 8% | 53% | 24.4% | 3.11 pts | 14.5% |
| gear, arrows only (no arrow = same facing) | 10 s | 5% | 0% | 16.7% | 0.00 pts | 16.7% |
| gear, arrows only (no arrow = same facing) | 10 s | 8% | 49% | 27.7% | 2.61 pts | 16.7% |
| gear, arrows only (no arrow = same facing) | 15 s | 5% | 0% | 18.9% | 0.00 pts | 18.9% |
| gear, arrows only (no arrow = same facing) | 15 s | 8% | 42% | 28.2% | 2.54 pts | 18.9% |
| gear, arrows only (no arrow = same facing) | 20 s | 5% | 1% | 19.9% | 0.00 pts | 19.7% |
| gear, arrows only (no arrow = same facing) | 20 s | 8% | 31% | 25.4% | 2.29 pts | 19.7% |

### Early dud signs, your logging, 10 s window, dud = best cast under 5%

2% of attempts are duds at this threshold (if the line were known). A sign = what you log in a 1-s slot after READY; seen = share of attempts showing it; dud share = how many of those are duds.

| you log | seconds after READY | seen | dud share |
|---|---|---|---|
| numpad 2 stand | 4-5 | 8.8% | 0% |
| numpad 2 stand | 7-8 | 6.9% | 0% |
| numpad 9 shoulder | 4-5 | 6.8% | 0% |
| numpad 7 sniff | 1-2 | 5.5% | 0% |
| numpad 3 rollover | 6-7 | 5.5% | 0% |
| numpad 0 idle | 3-4 | 5.5% | 0% |
| numpad 2 stand | 5-6 | 4.9% | 0% |
| numpad 3 rollover | 7-8 | 4.5% | 0% |
| numpad 8 bark | 1-2 | 4.4% | 0% |
| numpad 2 stand | 6-7 | 4.3% | 0% |
| numpad 2 stand | 9-10 | 4.3% | 0% |
| numpad 2 stand | 3-4 | 4.2% | 0% |
| numpad 0 idle | 1-2 | 3.9% | 0% |
| numpad 0 idle | 9-10 | 3.9% | 0% |
| numpad 8 bark | 3-4 | 3.8% | 0% |
| numpad 3 rollover | 9-10 | 3.8% | 0% |
| numpad 7 sniff | 3-4 | 3.8% | 0% |
| numpad 1 sit | 9-10 | 3.7% | 0% |
| faces SW | 7-8 | 3.6% | 0% |
| faces NW | 1-2 | 3.6% | 0% |

### Early dud signs, your logging, 10 s window, dud = best cast under 8%

2% of attempts are duds at this threshold (if the line were known). A sign = what you log in a 1-s slot after READY; seen = share of attempts showing it; dud share = how many of those are duds.

| you log | seconds after READY | seen | dud share |
|---|---|---|---|
| numpad 2 stand | 4-5 | 8.8% | 0% |
| numpad 2 stand | 7-8 | 6.9% | 0% |
| numpad 9 shoulder | 4-5 | 6.8% | 0% |
| numpad 7 sniff | 1-2 | 5.5% | 0% |
| numpad 3 rollover | 6-7 | 5.5% | 0% |
| numpad 0 idle | 3-4 | 5.5% | 0% |
| numpad 2 stand | 5-6 | 4.9% | 0% |
| numpad 3 rollover | 7-8 | 4.5% | 0% |
| numpad 8 bark | 1-2 | 4.4% | 0% |
| numpad 2 stand | 6-7 | 4.3% | 0% |
| numpad 2 stand | 9-10 | 4.3% | 0% |
| numpad 2 stand | 3-4 | 4.2% | 0% |
| numpad 0 idle | 1-2 | 3.9% | 0% |
| numpad 0 idle | 9-10 | 3.9% | 0% |
| numpad 8 bark | 3-4 | 3.8% | 0% |
| numpad 3 rollover | 9-10 | 3.8% | 0% |
| numpad 7 sniff | 3-4 | 3.8% | 0% |
| numpad 1 sit | 9-10 | 3.7% | 0% |
| faces SW | 7-8 | 3.6% | 0% |
| faces NW | 1-2 | 3.6% | 0% |
