# HM64 full-day lab — the cast table and the dog to the end of the game day

## 1. The day without a cast (every dog line, stay-awake push every 33 s)

- 68 lines ran of 68; dog at READY: [-196.91, 222.09]
- Clock at READY: 06:48 – 06:51. Followed to 5398 VIs = 90 s after READY (the limit).
- Same paths as the dog-watch run? cast hashes of the first 33 s: **67660 equal, 0 different**.
- Ended by something else than the limit / the end of the day: 0
- The dog's visible changes over that time: 90 per line.
- **The dog leaves its spot** (moved 4 units or more) on 37 of 68 lines; earliest 3 s after READY, median 39 s.
- Its tile leaves the visibility grid (not on screen, not animating) on 6 lines.

## 2. Cast blocks (every cast held to the limit, or the end of the day)

| block | cast frames (s after READY) | lines | casts planned | done | job errors | hash check ok / failed / none | ended: as planned / beach check / other | bites per cast | casts with a Nut on some bite |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 0.1 – 40.1 · heavy | 50 | 46822 | 46822 | 0 | 45772 / 0 / 1050 | 46822 / 0 / 0 | 6.7 | 2300 (4.9%) |
| 1 | 0.1 – 40.1 · other | 18 | 6635 | 6635 | 0 | 6257 / 0 / 378 | 6635 / 0 / 0 | 7.0 | 287 (4.3%) |

Blocks not started: 0 (0 casts). Data so far: 57.9 MB.

## 3. The beach check

- 53457 casts: **53457 ran to the limit / the end of the day on the beach at the dock end**, 0 were stopped by the beach check, 0 ended another way.
- Cast hash = the dog-watch run's state at that frame: 52029 equal, **0 different**, 1428 not compared (cast frames inside a stay-awake push).

## 4. Bites and Nuts by game hour (on the held casts)

- 359919 bites; released 4 polls after the bite: m 124656, l 120834, s 111786, N 2643 (N Nut, s / m / l fish size, d the day ended before the catch, x miss, h held through, o other; a / b = the two release probes differ).
- The two release probes of bites 1-2 gave different catches on 0 bites.
- Nut by bite number: bite 1: 1181, bite 2: 717, bite 3: 278, bite 4: 243, bite 5+: 224.

| game hour | bites | Nut bites | Nut share |
|---|---|---|---|
| 07:00 | 9463 | 191 | 2.02% |
| 08:00 | 30964 | 644 | 2.08% |
| 09:00 | 44221 | 1118 | 2.53% |
| 10:00 | 40728 | 22 | 0.05% |
| 11:00 | 49329 | 668 | 1.35% |
| 12:00 | 98131 | 0 | 0.00% |
| 13:00 | 83776 | 0 | 0.00% |
| 14:00 | 3066 | 0 | 0.00% |
| 15:00 | 43 | 0 | 0.00% |
| 16:00 | 183 | 0 | 0.00% |
| 18:00 | 15 | 0 | 0.00% |

These are bites of casts HELD since the cast frame, not fresh casts at that hour: a later hour is
reached only by holding through every earlier bite.

## 5. Do the held casts run into each other?

- 359919 bite states, 22570 distinct (93.7% shared): a shared state has the same future, so its later bites need not be simulated twice.

## 6. The dog after the cast

- Visible changes recorded from the cast to the end of its run: 70 per cast; on the released paths (the 4 s after each bite): 5.0 per bite.
- The dog leaves its spot at some point of the run in 32898 of 53457 casts (62%).

## 7. Against the dog-watch run's cast table (same state hash)

- 45830 casts are in both: bite times and Nut flags **equal in 45830, different in 0**.

