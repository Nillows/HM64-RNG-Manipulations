# Dog-spot lab (dogwatch): married-lineup2-sunny-237e3d1d.SaveRAM

Zig-zag route with the zigzag-fast recipe of route delays, dog-neutral (no dog-wake rule or key: every first / second cut is walked and kept, lines are anchored at the beach load and matched by game state at READY).

## The save

- file `married-lineup2-sunny-237e3d1d.SaveRAM` (sha256 237e3d1dfe5d220e)
- spring 9, year 1; weather 1; 6:00 at the house load; rod in hand: True
- dog at the house load: **beach** (map 9) x -197.27, z 222.24, facing 0, flags ACTIVE
- dog on screen at the load of: beach
- repeatable (two cold boots give the same record): **yes**
- reference route (mash 10/s START→A, house U276 V52, crossroads C80, beach D86 B134), map loads: house VI 1036, farm +412, crossroads +350, ranch +236, beach +230; READY 339 VIs after the beach load at x -92.0, z 194.0

## Failure map: where the recipe never reaches READY

Mass = uniform choices over this preset's grids (mash phase per rate, rates pooled; house U, V; crossroads C; first cut D; any second cut B). Each stage starts from the mass kept by the stage before.

| stage | runs | never reached | mass kept | outside the band (slower; or faster for a 5-9-frame preset) | never reached (mass) | where Jack stopped (most common) |
|---|---|---|---|---|---|---|
| menus | 144 | 0 | 0.6675 | 0.3325 | 0.0000 | - |
| house | 2548 | 462 | 0.2879 | 0.2586 | 0.1210 | 364× map 87 x≈96 z≈80; 28× map 87 x≈-24 z≈120; 28× map 87 x≈-32 z≈128 |
| crossroads | 792 | 22 | 0.2639 | 0.0160 | 0.0080 | 22× map 78 x≈120 z≈0 |
| ranch | 60 | 0 | 0.2639 | 0.0000 | 0.0000 | - |
| beach | 1920 | 0 | 0.2639 | 0.0000 | 0.0000 | - |

- **mass of the recipe that reaches the dock end: 0.2639** (the D grid includes 82–83, which never clear the small wall on the dog-beach save)

| first cut D | P(some B reaches the dock end) | B in the window (VIs: count of beach states) | why the other B stop (D without a window) |
|---|---|---|---|
| 84 | 1.000 | 22: 960 | - |
| 86 | 1.000 | 22: 960 | - |

Second cut B by first cut D (share of the beach-state mass that reaches the dock end; else why Jack stopped, and where):

- D 84: 112–121 no READY (map 9 x≈-208 z≈120) · 122–143 READY · 144–151 no READY (map 9 x≈-224 z≈224)
- D 86: 112–117 no READY (map 9 x≈-208 z≈128) · 118–139 READY · 140–151 no READY (map 9 x≈-224 z≈224)

| 1st cut (web app bands) | share of the D grid | P(a 2nd cut reaches the dock end) |
|---|---|---|
| tight | 1.000 | 1.000 |

## Lines (dog-neutral: anchored at the beach load, matched by game state at READY)

- 120 lines from 960 beach states; lines per beach state (count of states): 3: 81, 4: 851, 5: 28; **0 of 960 beach states collapse to one line** (every first and second cut of that state shares one RNG trajectory, offset in time only)
- largest READY offset inside a line: 98 VIs; members not matched to any path: 0

## Cut timing, split as the web app does (cast spread 150 ms)

| preset | share of routes | release bite 1 | hold to bite 2 | either (upper bound) |
|---|---|---|---|---|
| All | 1.000 | 6.49% at 0.3 s | 7.35% at 36.8 s | 10.71% at 19.9 s |
| 1st cut tight | 1.000 | 6.49% at 0.3 s | 7.35% at 36.8 s | 10.71% at 19.9 s |
| 1st cut tight · 2nd cut early | 0.545 | 6.63% at 0.37 s | 7.71% at 36.87 s | 10.73% at 22.07 s |
| 1st cut tight · 2nd cut middle | 0.182 | 7.27% at 0.1 s | 7.70% at 36.77 s | 10.80% at 21.97 s |
| 1st cut tight · 2nd cut late | 0.273 | 6.35% at 0.13 s | 7.55% at 36.63 s | 10.74% at 19.73 s |
| 1st cut mid | 0.000 | - | - | - |
| 1st cut mid · 2nd cut early | 0.000 | - | - | - |
| 1st cut mid · 2nd cut middle | 0.000 | - | - | - |
| 1st cut mid · 2nd cut late | 0.000 | - | - | - |
| 1st cut loose | 0.000 | - | - | - |
| 1st cut loose · 2nd cut early | 0.000 | - | - | - |
| 1st cut loose · 2nd cut middle | 0.000 | - | - | - |
| 1st cut loose · 2nd cut late | 0.000 | - | - | - |

## Lineup: stability

- 120 lines; the heaviest holds 12.6% of the routes; 7 lines hold 50% and 30 hold 90% (fewer = steadier dog)
- one beach start (beach state + wait) across the full pier width: lines (count of starts) 3: 81, 4: 851, 5: 28; how the second cuts split: B 118-119 + B 120-123 + B 122-139 + B 126-143 (845 starts); B 118-143 + B 120-123 + B 122-139 (81 starts); B 118-119 + B 120-123 + B 122-139 + B 126-137 + B 138-143 (12 starts); B 118-119 + B 120-123 + B 122-123 + B 124-139 + B 126-143 (9 starts)
- one wait + second cut across the beach states (the route before the beach): lines (count) 18: 26, 19: 14, 20: 22, 21: 38, 22: 30, 23: 16, 24: 14, 26: 16, 27: 18, 28: 62, 29: 18, 30: 58, 31: 52, 32: 18, 33: 14

## Lineup: does the dog keep drawing after READY (standing at the pier, no cast)?

- routes whose line has the dog drawing after READY: **100.0%**; extra draws over 39 s (above the 1-per-game-frame clock), route-weighted mean 173; dog's tile visible 100% of the time

## Lineup: where the dog activates (its tile enters the camera's view; until then it draws nothing)

First VI after the beach load (share of routes): 205: 0.3%, 207: 0.9%, 209: 3.7%, 211: 6.2%, 213: 6.2%, 215: 6.2%, 217: 6.2%, 219: 6.2%, 221: 6.2%, 223: 6.2%, 225: 6.2%, 227: 6.2%, 229: 6.2%, 231: 6.2%, 233: 6.2%, 235: 6.3%, 237: 6.0%, 239: 5.4%, 241: 2.6%

| Jack at the activation (x, z; 8-unit cells) | share of routes | lines | release bite 1 | hold to bite 2 |
|---|---|---|---|---|
| x -456…-448, z 160…168 | 0.727 | 112 | 6.53% at 0.23 s (cover 0.92) | 7.36% at 36.73 s (cover 1.00) |
| x -448…-440, z 152…160 | 0.182 | 116 | 6.63% at 0.4 s (cover 0.92) | 7.75% at 36.9 s (cover 1.00) |
| x -448…-440, z 144…152 | 0.091 | 111 | 6.67% at 0.33 s (cover 0.92) | 7.83% at 36.83 s (cover 1.00) |

## Lineup: beach wait W (VIs Jack stands still at the beach load before his first step)

| W (VIs) | share of routes | lines | release bite 1 | hold to bite 2 |
|---|---|---|---|---|
| 0 | 0.062 | 43 | 6.92% at 0.43 s (cover 0.92) | 7.24% at 36.9 s (cover 1.00) |
| 2 | 0.062 | 41 | 7.39% at 0.5 s (cover 0.94) | 8.56% at 36.83 s (cover 1.00) |
| 4 | 0.062 | 42 | 7.61% at 0.53 s (cover 0.95) | 8.78% at 36.8 s (cover 1.00) |
| 6 | 0.062 | 40 | 7.90% at 0.47 s (cover 0.92) | 8.09% at 36.8 s (cover 1.00) |
| 8 | 0.062 | 40 | 7.67% at 0.43 s (cover 0.91) | 7.73% at 21.93 s (cover 0.99) |
| 10 | 0.062 | 42 | 7.39% at 0.4 s (cover 0.92) | 8.06% at 21.93 s (cover 0.99) |
| 12 | 0.062 | 42 | 7.71% at 0.37 s (cover 0.94) | 8.36% at 21.9 s (cover 1.00) |
| 14 | 0.062 | 44 | 7.40% at 0.33 s (cover 0.93) | 8.49% at 21.97 s (cover 0.98) |
| 16 | 0.062 | 42 | 6.87% at 8.0 s (cover 0.94) | 7.88% at 22.03 s (cover 0.96) |
| 18 | 0.062 | 44 | 6.85% at 2.73 s (cover 0.94) | 7.57% at 19.83 s (cover 0.99) |
| 20 | 0.062 | 44 | 6.87% at 2.7 s (cover 0.94) | 7.83% at 36.87 s (cover 1.00) |
| 22 | 0.062 | 44 | 6.94% at 0.1 s (cover 0.90) | 8.49% at 36.77 s (cover 1.00) |
| 24 | 0.062 | 46 | 6.03% at 0.1 s (cover 0.91) | 7.64% at 36.7 s (cover 1.00) |
| 26 | 0.062 | 46 | 6.50% at 5.63 s (cover 0.96) | 7.62% at 36.63 s (cover 1.00) |
| 28 | 0.062 | 42 | 6.47% at 0.1 s (cover 0.92) | 7.87% at 36.53 s (cover 1.00) |
| 30 | 0.062 | 43 | 6.39% at 0.13 s (cover 0.93) | 7.60% at 36.47 s (cover 1.00) |

## Lineup: first cut D (VIs of down-right after the beach load, before the cut down-left)

D 84 = the earliest cut that clears the small wall (scrapes its corner: Jack pushed to x -451.6); D 86 = one game frame later (clears the corner: x -452.0, still the wall column of the dog's view grid).

| first cut | share of routes | lines | of them shared with the other cut | dog wakes, VI after the beach load - W (share) | release bite 1 | hold to bite 2 |
|---|---|---|---|---|---|---|
| D 84 | 0.500 | 116 | 111 | 211 (82%), 209 (9%), 207 (9%) | 6.48% at 0.27 s (cover 0.92) | 7.31% at 36.77 s (cover 1.00) |
| D 86 | 0.500 | 115 | 111 | 209 (82%), 205 (9%), 207 (9%) | 6.50% at 0.3 s (cover 0.92) | 7.39% at 36.8 s (cover 1.00) |

## Lineup: wait band x second cut (full pier width; early / middle / late = dock-end spot z ≤178 / ≤190 / >190)

| wait | 2nd cut | share of routes | lines | release bite 1 | hold to bite 2 |
|---|---|---|---|---|---|
| wait 0-9 | any | 0.312 | 63 | 7.46% at 0.47 s (cover 0.93) | 8.03% at 36.83 s (cover 1.00) |
| wait 0-9 | Early | 0.170 | 62 | 7.68% at 0.53 s (cover 0.93) | 8.46% at 36.9 s (cover 1.00) |
| wait 0-9 | Middle | 0.057 | 52 | 7.96% at 0.43 s (cover 0.92) | 8.61% at 36.8 s (cover 1.00) |
| wait 0-9 | Late | 0.085 | 53 | 7.90% at 0.27 s (cover 0.92) | 8.38% at 36.67 s (cover 1.00) |
| wait 10-19 | any | 0.312 | 67 | 6.81% at 0.33 s (cover 0.92) | 7.98% at 21.97 s (cover 0.98) |
| wait 10-19 | Early | 0.170 | 67 | 7.39% at 8.07 s (cover 0.95) | 8.32% at 22.07 s (cover 0.98) |
| wait 10-19 | Middle | 0.057 | 54 | 7.59% at 0.17 s (cover 0.91) | 8.38% at 27.4 s (cover 0.99) |
| wait 10-19 | Late | 0.085 | 55 | 7.18% at 7.83 s (cover 0.95) | 8.16% at 21.83 s (cover 0.98) |
| wait 20-30 | any | 0.375 | 72 | 6.39% at 0.1 s (cover 0.92) | 7.40% at 36.67 s (cover 1.00) |
| wait 20-30 | Early | 0.205 | 72 | 6.76% at 0.2 s (cover 0.91) | 7.66% at 36.77 s (cover 1.00) |
| wait 20-30 | Middle | 0.068 | 61 | 8.10% at 0.1 s (cover 0.92) | 7.68% at 36.63 s (cover 1.00) |
| wait 20-30 | Late | 0.102 | 61 | 5.65% at 22.23 s (cover 0.99) | 7.59% at 36.5 s (cover 1.00) |
| any wait | any | 1.000 | 120 | 6.49% at 0.3 s (cover 0.92) | 7.35% at 36.8 s (cover 1.00) |
| any wait | Early | 0.545 | 120 | 6.63% at 0.37 s (cover 0.92) | 7.71% at 36.87 s (cover 1.00) |
| any wait | Middle | 0.182 | 112 | 7.27% at 0.1 s (cover 0.91) | 7.70% at 36.77 s (cover 1.00) |
| any wait | Late | 0.273 | 112 | 6.35% at 0.13 s (cover 0.92) | 7.55% at 36.63 s (cover 1.00) |

## Menus (mash until the house loads)

| style | presses/s | held VIs | house arrival VI (count of phases) |
|---|---|---|---|
| START+A | 15.0 | 2 | 1038×2, 1040×2 |
| START+A | 12.0 | 2 | 1042×2, 1044×2, 1046×1 |
| START+A | 10.0 | 3 | 1042×2, 1044×2, 1046×2 |
| START+A | 8.6 | 3 | 1042×1, 1044×1, 1046×1, 1048×1, 1050×1, 1052×1, 1054×1 |
| START+A | 7.5 | 4 | 1038×2, 1040×2, 1042×2, 1044×2 |
| START+A | 6.7 | 4 | 1038×1, 1040×2, 1042×2, 1044×2, 1046×1, 1056×1 |
| START+A | 6.0 | 5 | 1052×2, 1054×2, 1056×2, 1058×2, 1060×2 |
| START+A | 5.5 | 5 | 1050×2, 1052×2, 1054×2, 1056×2, 1058×2, 1060×1 |
| START+A | 5.0 | 6 | 1054×2, 1056×2, 1058×2, 1060×2, 1064×2, 1074×2 |
| START>A | 15.0 | 2 | 1038×2, 1040×2 |
| START>A | 12.0 | 2 | 1042×2, 1044×2, 1046×1 |
| START>A | 10.0 | 3 | 1036×1, 1038×1, 1040×1, 1042×1, 1044×1, 1046×1 |
| START>A | 8.6 | 3 | 1042×1, 1044×2, 1046×2, 1048×2 |
| START>A | 7.5 | 4 | 1038×2, 1040×2, 1042×2, 1044×2 |
| START>A | 6.7 | 4 | 1038×1, 1040×2, 1042×2, 1044×2, 1046×1, 1056×1 |
| START>A | 6.0 | 5 | 1052×2, 1054×2, 1056×2, 1058×2, 1060×2 |
| START>A | 5.5 | 5 | 1050×2, 1052×2, 1054×2, 1056×2, 1058×2, 1060×1 |
| START>A | 5.0 | 6 | 1042×2, 1044×2, 1046×2, 1048×2, 1052×2, 1062×2 |

## House (up-left U, down-left V, down) — farm arrival, VIs after the house load: count of (U, V) runs

412:28, 414:112, 416:336, 418:357, 420:266, 422:189, 424:196, 426:147, 428:70, 430:84, 432:84, 434:63, 436:56, 438:56, 440:35, 442:7, None:462

## Crossroads (left, cut down-left at C) — ranch arrival, VIs after the farm load: count of runs

586:220, 588:176, 590:220, 592:110, 594:44, None:22

## Beach (first cut D, second cut B; VIs after the beach load)

| D | dog first moved, VIs after the beach load (count) | B reaching the dock end (total) | READY windows (B) |
|---|---|---|---|
| 84 | None×960 | 21120 | 122–143 |
| 86 | None×960 | 21120 | 118–139 |

## Dog lines: 120 (members = beach state × D × B that reach the dock end)

- casts evaluated: 16872 distinct states; repeat checks agree 351, disagree 0

| line | weight | members | beach draw | READY spread (VIs) | casts | Nut casts b1 / b2 |
|---|---|---|---|---|---|---|
| f33f2b3a43769070 | 0.126 | 5274 | 1088 | 66 | 1197 | 22 / 43 |
| f88084260f97fecc | 0.089 | 3822 | 1091 | 72 | 1197 | 29 / 31 |
| f8726e243b41ecde | 0.070 | 2674 | 1098 | 82 | 1197 | 55 / 38 |
| fb6402c362783c68 | 0.070 | 2866 | 1087 | 66 | 1197 | 72 / 70 |
| dfdfd7e1f03b1116 | 0.060 | 2480 | 1098 | 76 | 1197 | 31 / 27 |
| d2fe281c1567a875 | 0.059 | 2492 | 1088 | 98 | 1197 | 19 / 35 |
| ee55e51e951434c2 | 0.053 | 2312 | 1087 | 74 | 1197 | 3 / 19 |
| e985ed500a82e238 | 0.052 | 2136 | 1088 | 44 | 1197 | 17 / 43 |
| ff9f96124863f4dc | 0.051 | 2214 | 1092 | 66 | 1197 | 61 / 48 |
| fe8423efcf4310ab | 0.045 | 1948 | 1088 | 56 | 1197 | 19 / 35 |
| 6afca558e295f3f3 | 0.037 | 1580 | 1086 | 44 | 1197 | 55 / 57 |
| bf48b093a1f59845 | 0.037 | 1498 | 1086 | 44 | 1197 | 20 / 35 |
| f15a4df4fdb29bc9 | 0.019 | 906 | 1102 | 44 | 1197 | 16 / 35 |
| e2b9139eedbca97d | 0.017 | 824 | 1098 | 80 | 1197 | 42 / 62 |
| fed1753bb4448bf2 | 0.016 | 796 | 1107 | 44 | 1197 | 66 / 39 |
| fd180c0073574c4c | 0.013 | 670 | 1110 | 22 | 1197 | 8 / 44 |
| c9add3a7cd16344f | 0.012 | 470 | 1098 | 60 | 1197 | 52 / 53 |
| 9f7176686d53a087 | 0.011 | 390 | 1098 | 60 | 1197 | 4 / 25 |
| eeb412a83edbd72b | 0.010 | 594 | 1110 | 22 | 1197 | 48 / 53 |
| ee2639d8ff7ff3d2 | 0.010 | 328 | 1098 | 28 | 1197 | 16 / 35 |
| e8be7f745b9c8fa8 | 0.006 | 236 | 1116 | 22 | 1197 | 63 / 66 |
| 9ecccccc338b6812 | 0.006 | 200 | 1098 | 54 | 1197 | 49 / 63 |
| ad03f286a748b3ed | 0.005 | 184 | 1098 | 82 | 1197 | 4 / 19 |
| fdc308d5dabdef3c | 0.005 | 176 | 1098 | 22 | 1197 | 61 / 48 |
| 9ce4300f06a98203 | 0.005 | 410 | 1087 | 44 | 1197 | 47 / 25 |
| 004e35ab03a30c57 | 0.005 | 180 | 1086 | 88 | 1197 | 45 / 61 |
| 3e16206b389c9c32 | 0.004 | 152 | 1118 | 44 | 1197 | 17 / 35 |
| e5012d7715907874 | 0.002 | 96 | 1101 | 22 | 1197 | 61 / 63 |
| 64de7edc15392876 | 0.002 | 82 | 1115 | 56 | 1197 | 32 / 27 |
| 8b9aa70f3d05506b | 0.002 | 88 | 1101 | 22 | 1197 | 65 / 48 |
| 98d86bff025140f3 | 0.002 | 88 | 1101 | 22 | 1110 | 48 / 52 |
| 9a436f4f2c19152d | 0.002 | 88 | 1101 | 22 | 1037 | 55 / 38 |
| c30ba1d5824a84d0 | 0.002 | 88 | 1101 | 22 | 0 | 0 / 0 |
| d3f35b157216dbf8 | 0.002 | 88 | 1101 | 22 | 915 | 20 / 25 |
| e00d2c7cd95d96e8 | 0.002 | 88 | 1101 | 22 | 938 | 5 / 35 |
| f109e8dfb51645dd | 0.002 | 88 | 1101 | 22 | 1143 | 61 / 48 |
| 751a5207865b6e2a | 0.002 | 88 | 1101 | 22 | 937 | 5 / 35 |
| b37a5d606e89724b | 0.002 | 88 | 1101 | 22 | 938 | 5 / 35 |
| bb90edd14437771c | 0.002 | 88 | 1101 | 22 | 1136 | 61 / 48 |
| e8a29551b385b310 | 0.002 | 88 | 1101 | 22 | 1041 | 55 / 39 |

## Lucky Timer, whole pool (aim = time after READY at the dock end; cast spread 1 s.d.)

| spread | release bite 1 | hold to bite 2 | either (smart, upper bound) | coverage at best |
|---|---|---|---|---|
| 0 ms | 8.6% at 1.77 s | 9.2% at 36.87 s | 12.8% at 21.97 s | 0.984 |
| 100 ms | 6.7% at 0.3 s | 7.7% at 36.8 s | 10.9% at 22.0 s | 0.985 |
| 150 ms | 6.5% at 0.3 s | 7.3% at 36.8 s | 10.7% at 19.9 s | 0.994 |
| 250 ms | 6.3% at 0.2 s | 6.9% at 21.8 s | 10.6% at 19.93 s | 0.994 |

- **Member recast check** (casts from members' own routes vs the shared line table): agree 1754, disagree 22, no table entry 0

  - ['fb6402c362783c68', 'db9bf14e945a114c@w26', 86, 134, 844, [1948, False, 4516, False], [1948, False, 4316, False]]
  - ['ff9f96124863f4dc', '0b6bff2543100374@w10', 84, 136, 484, [3536, False, 4708, False], [4094, False, 4338, False]]
  - ['fb6402c362783c68', '1d0bc6dc11b19341@w8', 86, 127, 610, [1800, False, 2496, False], [1356, False, 3204, False]]
  - ['6afca558e295f3f3', '98e8509a8fc69b12@w26', 84, 137, 774, [1452, False, 1614, False], [1460, False, 3308, False]]
  - ['fb6402c362783c68', '24e07da33c0ab83a@w28', 86, 135, 862, [1956, False, 2652, False], [1686, False, 2286, False]]
  - ['eeb412a83edbd72b', '4135ce7490b0b37f@w8', 86, 135, 476, [1920, False, 2298, False], [1920, False, 3014, False]]
  - ['eeb412a83edbd72b', '4135ce7490b0b37f@w8', 86, 135, 480, [1924, False, 2314, False], [1262, False, 3110, False]]
  - ['eeb412a83edbd72b', '8b1b4c6a2203cd98@w30', 84, 142, 486, [1710, False, 2406, False], [1706, False, 2402, False]]
  - ['004e35ab03a30c57', '7693f2143191fe25@w30', 84, 132, 774, [1482, False, 1644, False], [1490, False, 3338, False]]
  - ['eeb412a83edbd72b', '03b781d7b2e9c99f@w10', 86, 134, 890, [1652, False, 2252, False], [1494, False, 2200, False]]
  - ['eeb412a83edbd72b', 'c643b779986f3f1b@w22', 86, 138, 404, [1630, False, 4046, False], [1630, False, 2660, False]]
  - ['ff9f96124863f4dc', 'a8508c8e8d0a2def@w22', 86, 124, 782, [1430, False, 1592, False], [1438, False, 3286, False]]
  - ['fb6402c362783c68', '0d8b7ea15c53477f@w26', 86, 129, 522, [1728, False, 4296, False], [1728, False, 4096, False]]
  - ['64de7edc15392876', '2f792acec657cb36@w30', 86, 131, 1434, [1878, False, 3320, False], [1878, False, 3694, False]]
  - ['eeb412a83edbd72b', '8b1b4c6a2203cd98@w30', 84, 133, 1350, [2874, False, 3272, False], [3582, False, 5022, False]]
  - ['eeb412a83edbd72b', '5026f95c370b5ee3@w14', 84, 133, 1286, [2170, False, 4028, False], [2170, False, 4586, False]]
  - ['eeb412a83edbd72b', '5026f95c370b5ee3@w14', 84, 133, 2226, [3048, False, 3434, False], [3048, False, 4700, False]]
  - ['f8726e243b41ecde', '24e07da33c0ab83a@w24', 84, 131, 1746, [2072, False, 3514, False], [2072, False, 3888, False]]
  - ['ff9f96124863f4dc', '2f0c632531b7a6cd@w18', 84, 130, 1210, [2126, False, 4694, False], [2126, False, 4494, False]]
  - ['fb6402c362783c68', '59e20511eea33031@w20', 84, 140, 1306, [2224, False, 4792, False], [2224, False, 4592, False]]
