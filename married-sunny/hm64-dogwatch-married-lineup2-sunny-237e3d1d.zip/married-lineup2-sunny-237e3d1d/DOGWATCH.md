# Dog-watch report: married-lineup2-sunny-237e3d1d

120 dog lines with traces (40 s after READY), 1392 (line, READY offset) variants; route-weighted. Clock = the dock-end tap ±3 VI; logs from 1.0 s after READY; runner: changes >= 12 VI, reaction 10-25 VI, 15% missed. Odds: cast >= 2 s after the window, ±150 ms.

## What the dog does while you wait (after READY, route-weighted)

- dog's tile on the visibility grid (it animates only then): 100% of the time
- visible changes per minute: 59; changes lasting >= 12 VI: 90%
- facing on screen (share of the wait): SW 38%, SE 19%, E 14%, NE 13%, NW 9%, N 6%, W 1%; animations readable (dog faces S / N / NE / E / SE): 52%
- the dog moves (units, max over the trace): median 0.0
- decision (actionState change) -> next visible change: median 0 VI (p10 0, p90 30); animation set -> displayed: median 0 VI

## Telling the lines apart (simulated runners)

| logging | window | right line on top | posterior on it | >= 90% sure | lines left | logs | Nut (no logs -> logs) | known line |
|---|---|---|---|---|---|---|---|---|
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 3 s | 34% | 24% | 4% | 45.0 | 0.3 | 7.4% -> 11.8% | 21.9% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 5 s | 36% | 26% | 5% | 45.7 | 0.5 | 7.2% -> 11.6% | 21.6% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 10 s | 53% | 43% | 14% | 32.8 | 1.3 | 6.9% -> 14.4% | 21.2% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 15 s | 63% | 51% | 27% | 29.9 | 2.1 | 7.7% -> 15.4% | 20.2% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 20 s | 65% | 54% | 30% | 27.0 | 3.8 | 7.4% -> 15.3% | 19.1% |
| gear, arrows only (no arrow = same facing) | 3 s | 28% | 19% | 3% | 49.4 | 0.0 | 6.6% -> 9.9% | 22.0% |
| gear, arrows only (no arrow = same facing) | 5 s | 30% | 20% | 2% | 48.8 | 0.0 | 6.8% -> 10.0% | 21.8% |
| gear, arrows only (no arrow = same facing) | 10 s | 40% | 31% | 8% | 40.5 | 0.2 | 7.5% -> 13.0% | 21.4% |
| gear, arrows only (no arrow = same facing) | 15 s | 63% | 52% | 34% | 28.3 | 0.7 | 6.7% -> 15.0% | 19.9% |
| gear, arrows only (no arrow = same facing) | 20 s | 62% | 51% | 29% | 28.5 | 1.0 | 7.2% -> 14.8% | 19.6% |
| your logging (arrows always, letters for long animations facing S/N/E) | 3 s | 24% | 13% | 2% | 100.2 | 0.2 | 7.7% -> 9.9% | 21.8% |
| your logging (arrows always, letters for long animations facing S/N/E) | 5 s | 27% | 15% | 3% | 94.5 | 0.5 | 7.6% -> 10.6% | 21.6% |
| your logging (arrows always, letters for long animations facing S/N/E) | 10 s | 38% | 27% | 9% | 75.2 | 1.2 | 7.4% -> 13.3% | 21.2% |
| your logging (arrows always, letters for long animations facing S/N/E) | 15 s | 57% | 43% | 23% | 54.2 | 2.6 | 6.8% -> 14.8% | 20.1% |
| your logging (arrows always, letters for long animations facing S/N/E) | 20 s | 68% | 51% | 29% | 41.3 | 4.5 | 7.4% -> 16.5% | 19.8% |
| arrows only (facing track + durations) | 3 s | 14% | 7% | 0% | 118.0 | 0.0 | 7.5% -> 7.8% | 22.3% |
| arrows only (facing track + durations) | 5 s | 14% | 7% | 1% | 117.7 | 0.0 | 7.0% -> 7.3% | 22.2% |
| arrows only (facing track + durations) | 10 s | 26% | 17% | 5% | 94.9 | 0.2 | 7.1% -> 10.6% | 21.2% |
| arrows only (facing track + durations) | 15 s | 41% | 28% | 13% | 78.5 | 0.5 | 7.6% -> 13.1% | 20.1% |
| arrows only (facing track + durations) | 20 s | 51% | 38% | 23% | 62.5 | 1.1 | 7.4% -> 14.4% | 19.8% |
| every change, letter + arrow | 3 s | 72% | 64% | 47% | 19.6 | 1.2 | 7.2% -> 17.4% | 21.7% |
| every change, letter + arrow | 5 s | 88% | 84% | 70% | 3.2 | 2.5 | 6.9% -> 20.0% | 21.5% |
| every change, letter + arrow | 10 s | 92% | 86% | 72% | 2.0 | 6.3 | 7.2% -> 20.6% | 21.3% |
| every change, letter + arrow | 15 s | 93% | 89% | 76% | 2.1 | 10.5 | 7.6% -> 19.7% | 20.4% |
| every change, letter + arrow | 20 s | 93% | 89% | 78% | 1.7 | 14.4 | 6.9% -> 18.9% | 19.6% |
| every animation change, letter only | 3 s | 69% | 62% | 45% | 18.2 | 1.2 | 7.3% -> 17.2% | 21.9% |
| every animation change, letter only | 5 s | 86% | 82% | 69% | 4.1 | 2.4 | 7.4% -> 20.0% | 21.9% |
| every animation change, letter only | 10 s | 90% | 86% | 76% | 1.9 | 6.4 | 7.1% -> 20.6% | 21.2% |
| every animation change, letter only | 15 s | 91% | 89% | 80% | 2.1 | 10.1 | 7.5% -> 19.6% | 20.2% |
| every animation change, letter only | 20 s | 90% | 88% | 78% | 1.8 | 14.0 | 7.5% -> 19.1% | 19.6% |
| Space at every change | 3 s | 27% | 13% | 0% | 66.8 | 1.2 | 7.3% -> 9.4% | 22.0% |
| Space at every change | 5 s | 50% | 31% | 2% | 33.6 | 2.5 | 8.0% -> 13.8% | 21.9% |
| Space at every change | 10 s | 79% | 73% | 52% | 5.0 | 6.5 | 7.1% -> 19.5% | 21.5% |
| Space at every change | 15 s | 89% | 83% | 67% | 2.9 | 10.7 | 6.3% -> 19.2% | 19.8% |
| Space at every change | 20 s | 86% | 82% | 68% | 2.7 | 14.4 | 6.8% -> 18.6% | 19.2% |

Readability: *your logging* follows Thomas's TV check (facing always readable; animations only while the dog
faces S, N, NE, E or SE, and only animations lasting >= 1 s are logged). The other rows are for comparison.

## Duds before the cast (reset early)

Dud = the best cast for what your logs leave is under the threshold; you reset instead of casting. Odds per attempt; 'kept' = attempts you cast.

| logging | window | threshold | attempts called dud | Nut on kept attempts | Nut the resets threw away | all-cast Nut |
|---|---|---|---|---|---|---|
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 3 s | 5% | 0% | 11.8% | 0.00 pts | 11.8% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 3 s | 8% | 0% | 11.8% | 0.00 pts | 11.8% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 5 s | 5% | 0% | 11.6% | 0.00 pts | 11.6% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 5 s | 8% | 0% | 11.6% | 0.00 pts | 11.6% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 10 s | 5% | 1% | 14.6% | 0.00 pts | 14.4% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 10 s | 8% | 1% | 14.6% | 0.00 pts | 14.4% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 15 s | 5% | 0% | 15.5% | 0.00 pts | 15.4% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 15 s | 8% | 0% | 15.5% | 0.00 pts | 15.4% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 20 s | 5% | 1% | 15.4% | 0.00 pts | 15.3% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 20 s | 8% | 8% | 15.9% | 0.60 pts | 15.3% |
| gear, arrows only (no arrow = same facing) | 3 s | 5% | 0% | 9.9% | 0.00 pts | 9.9% |
| gear, arrows only (no arrow = same facing) | 3 s | 8% | 0% | 9.9% | 0.00 pts | 9.9% |
| gear, arrows only (no arrow = same facing) | 5 s | 5% | 0% | 10.0% | 0.00 pts | 10.0% |
| gear, arrows only (no arrow = same facing) | 5 s | 8% | 0% | 10.0% | 0.00 pts | 10.0% |
| gear, arrows only (no arrow = same facing) | 10 s | 5% | 0% | 13.0% | 0.00 pts | 13.0% |
| gear, arrows only (no arrow = same facing) | 10 s | 8% | 0% | 13.0% | 0.00 pts | 13.0% |
| gear, arrows only (no arrow = same facing) | 15 s | 5% | 1% | 15.1% | 0.00 pts | 15.0% |
| gear, arrows only (no arrow = same facing) | 15 s | 8% | 17% | 16.6% | 1.21 pts | 15.0% |
| gear, arrows only (no arrow = same facing) | 20 s | 5% | 1% | 15.0% | 0.00 pts | 14.8% |
| gear, arrows only (no arrow = same facing) | 20 s | 8% | 22% | 17.3% | 1.33 pts | 14.8% |

### Early dud signs, your logging, 10 s window, dud = best cast under 5%

0% of attempts are duds at this threshold (if the line were known). A sign = what you log in a 1-s slot after READY; seen = share of attempts showing it; dud share = how many of those are duds.

| you log | seconds after READY | seen | dud share |
|---|---|---|---|
| numpad 1 sit | 9-10 | 17.1% | 0% |
| numpad 0 idle | 2-3 | 15.4% | 0% |
| numpad 5 run | 4-5 | 13.8% | 0% |
| numpad 4 walk | 6-7 | 13.8% | 0% |
| numpad 1 sit | 8-9 | 11.2% | 0% |
| faces NE | 5-6 | 8.7% | 0% |
| numpad 7 sniff | 1-2 | 6.4% | 0% |
| numpad 2 stand | 9-10 | 6.3% | 0% |
| numpad 2 stand | 5-6 | 6.2% | 0% |
| faces NW | 6-7 | 4.1% | 0% |
| faces SE | 8-9 | 3.8% | 0% |
| numpad 2 stand | 6-7 | 3.6% | 0% |
| numpad 6 sleep | 9-10 | 3.0% | 0% |
| numpad 0 idle | 1-2 | 3.0% | 0% |
| numpad 0 idle | 5-6 | 2.7% | 0% |
| faces NW | 5-6 | 2.5% | 0% |
| numpad 2 stand | 8-9 | 2.1% | 0% |
| numpad 9 shoulder | 6-7 | 2.0% | 0% |
| faces N | 5-6 | 2.0% | 0% |
| numpad 0 idle | 9-10 | 1.9% | 0% |

### Early dud signs, your logging, 10 s window, dud = best cast under 8%

0% of attempts are duds at this threshold (if the line were known). A sign = what you log in a 1-s slot after READY; seen = share of attempts showing it; dud share = how many of those are duds.

| you log | seconds after READY | seen | dud share |
|---|---|---|---|
| numpad 1 sit | 9-10 | 17.1% | 0% |
| numpad 0 idle | 2-3 | 15.4% | 0% |
| numpad 5 run | 4-5 | 13.8% | 0% |
| numpad 4 walk | 6-7 | 13.8% | 0% |
| numpad 1 sit | 8-9 | 11.2% | 0% |
| faces NE | 5-6 | 8.7% | 0% |
| numpad 7 sniff | 1-2 | 6.4% | 0% |
| numpad 2 stand | 9-10 | 6.3% | 0% |
| numpad 2 stand | 5-6 | 6.2% | 0% |
| faces NW | 6-7 | 4.1% | 0% |
| faces SE | 8-9 | 3.8% | 0% |
| numpad 2 stand | 6-7 | 3.6% | 0% |
| numpad 6 sleep | 9-10 | 3.0% | 0% |
| numpad 0 idle | 1-2 | 3.0% | 0% |
| numpad 0 idle | 5-6 | 2.7% | 0% |
| faces NW | 5-6 | 2.5% | 0% |
| numpad 2 stand | 8-9 | 2.1% | 0% |
| numpad 9 shoulder | 6-7 | 2.0% | 0% |
| faces N | 5-6 | 2.0% | 0% |
| numpad 0 idle | 9-10 | 1.9% | 0% |
