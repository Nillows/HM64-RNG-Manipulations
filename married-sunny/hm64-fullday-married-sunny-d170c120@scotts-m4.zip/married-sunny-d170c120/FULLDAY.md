# HM64 full-day lab — the cast table and the dog to the end of the game day

## 1. The day without a cast (every dog line, stay-awake push every 33 s)

- 120 lines ran of 120; dog at READY: [-197.27, 222.24]
- Clock at READY: 06:48 – 06:52. Followed to 10198 VIs = 170 s after READY (the limit).
- Same paths as the dog-watch run? cast hashes of the first 33 s: **119400 equal, 0 different**.
- Ended by something else than the limit / the end of the day: 0
- The dog's visible changes over that time: 171 per line.
- **The dog leaves its spot** (moved 4 units or more) on 92 of 120 lines; earliest 8 s after READY, median 101 s.
- Its tile leaves the visibility grid (not on screen, not animating) on 9 lines.

## 2. Cast blocks (every cast held to the limit, or the end of the day)

| block | cast frames (s after READY) | lines | casts planned | done | job errors | hash check ok / failed / none | ended: as planned / beach check / other | bites per cast | casts with a Nut on some bite |
|---|---|---|---|---|---|---|---|---|---|

Blocks not started: 6 (75833 casts). Data so far: 0.0 MB.

