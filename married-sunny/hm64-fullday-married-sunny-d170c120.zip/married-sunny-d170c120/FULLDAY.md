# HM64 full-day lab — the cast table and the dog to the end of the game day

## 1. The day without a cast (every dog line, stay-awake push every 33 s)

- 120 lines ran of 120; dog at READY: [-197.27, 222.24]
- Clock at READY: 06:48 – 06:52. Followed to 10198 VIs = 170 s after READY (the limit).
- Same paths as the dog-watch run? cast hashes of the first 33 s: **119400 equal, 0 different**.
- Ended by something else than the limit / the end of the day: 0
- The dog's visible changes over that time: 171 per line.
- **The dog leaves its spot** (moved 4 units or more) on 92 of 120 lines; earliest 8 s after READY, median 101 s.
- Its tile leaves the visibility grid (not on screen, not animating) on 9 lines.

## 2. Cast blocks (every cast held to the limit, or the end of the day)

| block | cast frames (s after READY) | lines | casts planned | done | job errors | hash check ok / failed / none | ended: as planned / beach check / other | bites per cast | casts with a Nut on some bite |
|---|---|---|---|---|---|---|---|---|---|
| 4 | 80.2 – 120.3 · heavy | 30 | 6807 | 6807 | 0 | 6177 / 0 / 630 | 6807 / 0 / 0 | 4.8 | 2 (0.0%) |
| 5 | 80.2 – 120.3 · other | 90 | 9828 | 9828 | 0 | 7938 / 0 / 1890 | 9828 / 0 / 0 | 4.9 | 0 (0.0%) |

Blocks not started: 4 (59198 casts). Data so far: 15.5 MB.

## 3. The beach check

- 16635 casts: **16635 ran to the limit / the end of the day on the beach at the dock end**, 0 were stopped by the beach check, 0 ended another way.
- Cast hash = the dog-watch run's state at that frame: 14115 equal, **0 different**, 2520 not compared (cast frames inside a stay-awake push).

## 4. Bites and Nuts by game hour (on the held casts)

- 80427 bites; released 4 polls after the bite: l 33105, s 29134, m 18186, N 2 (N Nut, s / m / l fish size, d the day ended before the catch, x miss, h held through, o other; a / b = the two release probes differ).
- The two release probes of bites 1-2 gave different catches on 0 bites.
- Nut by bite number: bite 4: 2.

| game hour | bites | Nut bites | Nut share |
|---|---|---|---|
| 13:00 | 236 | 0 | 0.00% |
| 14:00 | 2348 | 0 | 0.00% |
| 15:00 | 4594 | 0 | 0.00% |
| 16:00 | 7878 | 0 | 0.00% |
| 17:00 | 17802 | 0 | 0.00% |
| 18:00 | 19745 | 0 | 0.00% |
| 19:00 | 14672 | 0 | 0.00% |
| 20:00 | 12977 | 2 | 0.02% |
| 21:00 | 53 | 0 | 0.00% |
| 22:00 | 88 | 0 | 0.00% |
| 23:00 | 34 | 0 | 0.00% |

These are bites of casts HELD since the cast frame, not fresh casts at that hour: a later hour is
reached only by holding through every earlier bite.

## 5. Do the held casts run into each other?

- 80427 bite states, 7970 distinct (90.1% shared): a shared state has the same future, so its later bites need not be simulated twice.

## 6. The dog after the cast

- Visible changes recorded from the cast to the end of its run: 64 per cast; on the released paths (the 4 s after each bite): 4.5 per bite.
- The dog leaves its spot at some point of the run in 13845 of 16635 casts (83%).

## 7. Against the dog-watch run's cast table (same state hash)

- 0 casts are in both: bite times and Nut flags **equal in 0, different in 0**.

