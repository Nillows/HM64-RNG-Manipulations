# HM64 full-day lab — the cast table and the dog to the end of the game day

## 1. The day without a cast (every dog line, stay-awake push every 33 s)

- 120 lines ran of 120; dog at READY: [-197.27, 222.24]
- Clock at READY: 06:48 – 06:52. Followed to 5398 VIs = 90 s after READY (the limit).
- Same paths as the dog-watch run? cast hashes of the first 33 s: **119400 equal, 0 different**.
- Ended by something else than the limit / the end of the day: 0
- The dog's visible changes over that time: 93 per line.
- **The dog leaves its spot** (moved 4 units or more) on 19 of 120 lines; earliest 8 s after READY, median 30 s.
- Its tile leaves the visibility grid (not on screen, not animating) on 3 lines.

## 2. Cast blocks (every cast held to the limit, or the end of the day)

| block | cast frames (s after READY) | lines | casts planned | done | job errors | hash check ok / failed / none | ended: as planned / beach check / other | bites per cast | casts with a Nut on some bite |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 0.1 – 40.1 · heavy | 30 | 17378 | 17378 | 0 | 16748 / 0 / 630 | 17378 / 0 / 0 | 4.7 | 1144 (6.6%) |
| 1 | 0.1 – 40.1 · other | 90 | 21683 | 21683 | 0 | 19793 / 0 / 1890 | 21683 / 0 / 0 | 4.7 | 1271 (5.9%) |

Blocks not started: 0 (0 casts). Data so far: 39.9 MB.

## 3. The beach check

- 39061 casts: **39061 ran to the limit / the end of the day on the beach at the dock end**, 0 were stopped by the beach check, 0 ended another way.
- Cast hash = the dog-watch run's state at that frame: 36541 equal, **0 different**, 2520 not compared (cast frames inside a stay-awake push).

## 4. Bites and Nuts by game hour (on the held casts)

- 183567 bites; released 4 polls after the bite: s 80335, l 63756, m 37061, N 2415 (N Nut, s / m / l fish size, d the day ended before the catch, x miss, h held through, o other; a / b = the two release probes differ).
- The two release probes of bites 1-2 gave different catches on 0 bites.
- Nut by bite number: bite 1: 1252, bite 2: 991, bite 3: 172.

| game hour | bites | Nut bites | Nut share |
|---|---|---|---|
| 08:00 | 18544 | 0 | 0.00% |
| 09:00 | 25975 | 1252 | 4.82% |
| 10:00 | 24372 | 1039 | 4.26% |
| 11:00 | 17336 | 124 | 0.72% |
| 12:00 | 32022 | 0 | 0.00% |
| 13:00 | 47683 | 0 | 0.00% |
| 14:00 | 17393 | 0 | 0.00% |
| 15:00 | 239 | 0 | 0.00% |
| 16:00 | 3 | 0 | 0.00% |

These are bites of casts HELD since the cast frame, not fresh casts at that hour: a later hour is
reached only by holding through every earlier bite.

## 5. Do the held casts run into each other?

- 183567 bite states, 7491 distinct (95.9% shared): a shared state has the same future, so its later bites need not be simulated twice.

## 6. The dog after the cast

- Visible changes recorded from the cast to the end of its run: 76 per cast; on the released paths (the 4 s after each bite): 5.2 per bite.
- The dog leaves its spot at some point of the run in 26397 of 39061 casts (68%).

## 7. Against the dog-watch run's cast table (same state hash)

- 16824 casts are in both: bite times and Nut flags **equal in 16817, different in 7**.
  - ('fb6402c3', 2066, [(340, False), (896, False), (1632, False)], [(340, False), (896, False), (1632, False)])
  - ('fb6402c3', 2044, [(204, False), (1642, False), (1972, False)], [(204, False), (1642, False), (1972, False)])
  - ('6afca558', 2050, [(340, False), (896, False), (1632, False)], [(340, False), (896, False), (1632, False)])
  - ('bf48b093', 2046, [(378, False), (1666, False), (2506, False)], [(378, False), (1666, False), (2506, False)])
  - ('e2b9139e', 2052, [(904, False), (1640, False), (2496, False)], [(904, False), (1640, False), (2496, False)])

