# Dog-spot lab (dogwatch): married-horse-lineup2-sunny-0f33f322.SaveRAM

Zig-zag route with the zigzag-fast recipe of route delays, dog-neutral (no dog-wake rule or key: every first / second cut is walked and kept, lines are anchored at the beach load and matched by game state at READY).

## The save

- file `married-horse-lineup2-sunny-0f33f322.SaveRAM` (sha256 0f33f322f65546b2)
- spring 13, year 1; weather 1; 6:00 at the house load; rod in hand: True
- dog at the house load: **beach** (map 9) x -197.27, z 222.24, facing 0, flags ACTIVE
- dog on screen at the load of: beach
- repeatable (two cold boots give the same record): **yes**
- reference route (mash 10/s START→A, house U276 V52, crossroads C80, beach D86 B134), map loads: house VI 1036, farm +412, crossroads +350, ranch +236, beach +230; READY 339 VIs after the beach load at x -92.0, z 194.0

## Failure map: where the recipe never reaches READY

Mass = uniform choices over this preset's grids (mash phase per rate, rates pooled; house U, V; crossroads C; first cut D; any second cut B). Each stage starts from the mass kept by the stage before.

| stage | runs | never reached | mass kept | outside the band (slower; or faster for a 5-9-frame preset) | never reached (mass) | where Jack stopped (most common) |
|---|---|---|---|---|---|---|
| menus | 144 | 0 | 0.6675 | 0.3325 | 0.0000 | - |
| house | 2548 | 462 | 0.2879 | 0.2586 | 0.1210 | 364× map 87 x≈96 z≈80; 28× map 87 x≈-24 z≈120; 28× map 87 x≈-32 z≈128 |
| crossroads | 684 | 19 | 0.2639 | 0.0160 | 0.0080 | 19× map 78 x≈120 z≈0 |
| ranch | 50 | 0 | 0.2639 | 0.0000 | 0.0000 | - |
| beach | 1504 | 0 | 0.2639 | 0.0000 | 0.0000 | - |

- **mass of the recipe that reaches the dock end: 0.2639** (the D grid includes 82–83, which never clear the small wall on the dog-beach save)

| first cut D | P(some B reaches the dock end) | B in the window (VIs: count of beach states) | why the other B stop (D without a window) |
|---|---|---|---|
| 84 | 1.000 | 22: 752 | - |
| 86 | 1.000 | 22: 752 | - |

Second cut B by first cut D (share of the beach-state mass that reaches the dock end; else why Jack stopped, and where):

- D 84: 112–121 no READY (map 9 x≈-208 z≈120) · 122–143 READY · 144–151 no READY (map 9 x≈-224 z≈224)
- D 86: 112–117 no READY (map 9 x≈-208 z≈128) · 118–139 READY · 140–151 no READY (map 9 x≈-224 z≈224)

| 1st cut (web app bands) | share of the D grid | P(a 2nd cut reaches the dock end) |
|---|---|---|
| tight | 1.000 | 1.000 |

## Lines (dog-neutral: anchored at the beach load, matched by game state at READY)

- 156 lines from 752 beach states; lines per beach state (count of states): 3: 45, 4: 641, 5: 44, 6: 22; **0 of 752 beach states collapse to one line** (every first and second cut of that state shares one RNG trajectory, offset in time only)
- largest READY offset inside a line: 104 VIs; members not matched to any path: 0

## Cut timing, split as the web app does (cast spread 150 ms)

| preset | share of routes | release bite 1 | hold to bite 2 | either (upper bound) |
|---|---|---|---|---|
| All | 1.000 | 5.66% at 2.63 s | 6.86% at 19.6 s | 11.14% at 21.93 s |
| 1st cut tight | 1.000 | 5.66% at 2.63 s | 6.86% at 19.6 s | 11.14% at 21.93 s |
| 1st cut tight · 2nd cut early | 0.545 | 5.75% at 2.73 s | 7.04% at 19.7 s | 11.42% at 22.0 s |
| 1st cut tight · 2nd cut middle | 0.182 | 6.35% at 0.1 s | 7.07% at 19.6 s | 11.57% at 21.9 s |
| 1st cut tight · 2nd cut late | 0.273 | 5.70% at 2.5 s | 6.98% at 19.47 s | 11.38% at 21.8 s |
| 1st cut mid | 0.000 | - | - | - |
| 1st cut mid · 2nd cut early | 0.000 | - | - | - |
| 1st cut mid · 2nd cut middle | 0.000 | - | - | - |
| 1st cut mid · 2nd cut late | 0.000 | - | - | - |
| 1st cut loose | 0.000 | - | - | - |
| 1st cut loose · 2nd cut early | 0.000 | - | - | - |
| 1st cut loose · 2nd cut middle | 0.000 | - | - | - |
| 1st cut loose · 2nd cut late | 0.000 | - | - | - |

## Lineup: stability

- 156 lines; the heaviest holds 9.5% of the routes; 9 lines hold 50% and 57 hold 90% (fewer = steadier dog)
- one beach start (beach state + wait) across the full pier width: lines (count of starts) 3: 45, 4: 641, 5: 44, 6: 22; how the second cuts split: B 118-119 + B 120-123 + B 122-139 + B 126-143 (632 starts); B 118-143 + B 120-123 + B 122-139 (22 starts); B 118-119 + B 120-123 + B 122-139 + B 126-137 + B 138-141 + B 142-143 (20 starts); B 118-119 + B 120-123 + B 122-123 + B 124-139 + B 126-143 (18 starts)
- one wait + second cut across the beach states (the route before the beach): lines (count) 19: 2, 20: 6, 21: 18, 22: 44, 23: 52, 24: 20, 25: 8, 26: 10, 33: 14, 34: 18, 35: 28, 36: 104, 37: 22, 38: 54, 39: 14, 40: 2

## Lineup: does the dog keep drawing after READY (standing at the pier, no cast)?

- routes whose line has the dog drawing after READY: **100.0%**; extra draws over 39 s (above the 1-per-game-frame clock), route-weighted mean 176; dog's tile visible 100% of the time

## Lineup: where the dog activates (its tile enters the camera's view; until then it draws nothing)

First VI after the beach load (share of routes): 205: 0.3%, 207: 0.9%, 209: 3.7%, 211: 6.3%, 213: 6.3%, 215: 6.3%, 217: 6.3%, 219: 6.3%, 221: 6.3%, 223: 6.3%, 225: 6.3%, 227: 6.3%, 229: 6.3%, 231: 6.3%, 233: 6.3%, 235: 6.2%, 237: 6.0%, 239: 5.4%, 241: 2.6%

| Jack at the activation (x, z; 8-unit cells) | share of routes | lines | release bite 1 | hold to bite 2 |
|---|---|---|---|---|
| x -456…-448, z 160…168 | 0.727 | 148 | 5.65% at 2.6 s (cover 0.94) | 6.88% at 19.53 s (cover 0.98) |
| x -448…-440, z 152…160 | 0.182 | 152 | 5.74% at 2.8 s (cover 0.94) | 7.06% at 19.73 s (cover 0.98) |
| x -448…-440, z 144…152 | 0.091 | 140 | 5.85% at 2.7 s (cover 0.93) | 7.05% at 19.67 s (cover 0.98) |

## Lineup: beach wait W (VIs Jack stands still at the beach load before his first step)

| W (VIs) | share of routes | lines | release bite 1 | hold to bite 2 |
|---|---|---|---|---|
| 0 | 0.062 | 54 | 5.97% at 0.1 s (cover 0.83) | 8.53% at 36.8 s (cover 1.00) |
| 2 | 0.062 | 52 | 6.17% at 0.1 s (cover 0.89) | 8.28% at 36.73 s (cover 1.00) |
| 4 | 0.062 | 54 | 6.42% at 0.1 s (cover 0.91) | 7.89% at 36.63 s (cover 1.00) |
| 6 | 0.062 | 54 | 6.68% at 21.93 s (cover 0.98) | 7.58% at 36.5 s (cover 1.00) |
| 8 | 0.062 | 57 | 7.07% at 0.17 s (cover 0.93) | 7.68% at 36.43 s (cover 1.00) |
| 10 | 0.062 | 59 | 7.08% at 0.13 s (cover 0.90) | 8.39% at 36.43 s (cover 1.00) |
| 12 | 0.062 | 58 | 6.57% at 2.53 s (cover 0.94) | 8.22% at 36.4 s (cover 1.00) |
| 14 | 0.062 | 58 | 7.32% at 7.57 s (cover 0.99) | 8.26% at 21.7 s (cover 0.99) |
| 16 | 0.062 | 56 | 8.28% at 7.57 s (cover 0.98) | 8.84% at 21.73 s (cover 0.98) |
| 18 | 0.062 | 55 | 8.62% at 7.57 s (cover 0.98) | 8.03% at 21.73 s (cover 0.98) |
| 20 | 0.062 | 55 | 8.29% at 2.7 s (cover 0.96) | 7.72% at 19.6 s (cover 0.99) |
| 22 | 0.062 | 56 | 8.01% at 2.63 s (cover 0.96) | 7.09% at 19.6 s (cover 0.99) |
| 24 | 0.062 | 55 | 7.86% at 6.07 s (cover 0.97) | 7.53% at 21.93 s (cover 0.98) |
| 26 | 0.062 | 59 | 8.04% at 6.07 s (cover 0.96) | 7.57% at 21.97 s (cover 0.96) |
| 28 | 0.062 | 55 | 7.39% at 6.13 s (cover 0.98) | 7.42% at 22.0 s (cover 0.98) |
| 30 | 0.062 | 60 | 6.20% at 5.33 s (cover 0.98) | 7.50% at 20.47 s (cover 1.00) |

## Lineup: first cut D (VIs of down-right after the beach load, before the cut down-left)

D 84 = the earliest cut that clears the small wall (scrapes its corner: Jack pushed to x -451.6); D 86 = one game frame later (clears the corner: x -452.0, still the wall column of the dog's view grid).

| first cut | share of routes | lines | of them shared with the other cut | dog wakes, VI after the beach load - W (share) | release bite 1 | hold to bite 2 |
|---|---|---|---|---|---|---|
| D 84 | 0.500 | 152 | 147 | 211 (82%), 209 (9%), 207 (9%) | 5.70% at 5.4 s (cover 0.97) | 6.88% at 19.6 s (cover 0.99) |
| D 86 | 0.500 | 151 | 147 | 209 (82%), 205 (9%), 207 (9%) | 5.68% at 2.6 s (cover 0.94) | 6.84% at 19.6 s (cover 0.98) |

## Lineup: wait band x second cut (full pier width; early / middle / late = dock-end spot z ≤178 / ≤190 / >190)

| wait | 2nd cut | share of routes | lines | release bite 1 | hold to bite 2 |
|---|---|---|---|---|---|
| wait 0-9 | any | 0.312 | 85 | 6.41% at 0.1 s (cover 0.90) | 7.44% at 36.63 s (cover 1.00) |
| wait 0-9 | Early | 0.170 | 85 | 6.65% at 0.2 s (cover 0.89) | 7.76% at 36.73 s (cover 1.00) |
| wait 0-9 | Middle | 0.057 | 73 | 7.83% at 0.1 s (cover 0.90) | 7.78% at 36.57 s (cover 1.00) |
| wait 0-9 | Late | 0.085 | 73 | 6.14% at 22.2 s (cover 0.97) | 7.68% at 36.43 s (cover 1.00) |
| wait 10-19 | any | 0.312 | 90 | 6.97% at 7.53 s (cover 0.98) | 7.60% at 21.7 s (cover 0.98) |
| wait 10-19 | Early | 0.170 | 89 | 7.32% at 7.6 s (cover 0.98) | 7.94% at 36.47 s (cover 1.00) |
| wait 10-19 | Middle | 0.057 | 71 | 7.96% at 7.53 s (cover 0.98) | 7.98% at 21.67 s (cover 0.98) |
| wait 10-19 | Late | 0.085 | 73 | 7.61% at 7.4 s (cover 0.98) | 7.84% at 21.53 s (cover 0.98) |
| wait 20-30 | any | 0.375 | 96 | 7.18% at 6.07 s (cover 0.98) | 7.15% at 21.97 s (cover 0.98) |
| wait 20-30 | Early | 0.205 | 94 | 7.47% at 6.13 s (cover 0.98) | 7.43% at 22.0 s (cover 0.98) |
| wait 20-30 | Middle | 0.068 | 82 | 7.53% at 6.07 s (cover 0.98) | 7.46% at 21.93 s (cover 0.98) |
| wait 20-30 | Late | 0.102 | 85 | 7.35% at 5.93 s (cover 0.98) | 7.26% at 21.8 s (cover 0.98) |
| any wait | any | 1.000 | 156 | 5.66% at 2.63 s (cover 0.94) | 6.86% at 19.6 s (cover 0.98) |
| any wait | Early | 0.545 | 156 | 5.75% at 2.73 s (cover 0.94) | 7.04% at 19.7 s (cover 0.98) |
| any wait | Middle | 0.182 | 148 | 6.35% at 0.1 s (cover 0.92) | 7.07% at 19.6 s (cover 0.98) |
| any wait | Late | 0.273 | 148 | 5.70% at 2.5 s (cover 0.94) | 6.98% at 19.47 s (cover 0.98) |

## Menus (mash until the house loads)

| style | presses/s | held VIs | house arrival VI (count of phases) |
|---|---|---|---|
| START+A | 15.0 | 2 | 1038×2, 1040×2 |
| START+A | 12.0 | 2 | 1042×2, 1044×2, 1046×1 |
| START+A | 10.0 | 3 | 1042×2, 1044×2, 1046×2 |
| START+A | 8.6 | 3 | 1042×1, 1044×1, 1046×1, 1048×1, 1050×1, 1052×1, 1054×1 |
| START+A | 7.5 | 4 | 1038×2, 1040×2, 1042×2, 1044×2 |
| START+A | 6.7 | 4 | 1038×1, 1040×2, 1042×2, 1044×2, 1046×1, 1056×1 |
| START+A | 6.0 | 5 | 1052×2, 1054×2, 1056×2, 1058×2, 1060×2 |
| START+A | 5.5 | 5 | 1050×2, 1052×2, 1054×2, 1056×2, 1058×2, 1060×1 |
| START+A | 5.0 | 6 | 1054×2, 1056×2, 1058×2, 1060×2, 1064×2, 1074×2 |
| START>A | 15.0 | 2 | 1038×2, 1040×2 |
| START>A | 12.0 | 2 | 1042×2, 1044×2, 1046×1 |
| START>A | 10.0 | 3 | 1036×1, 1038×1, 1040×1, 1042×1, 1044×1, 1046×1 |
| START>A | 8.6 | 3 | 1042×1, 1044×2, 1046×2, 1048×2 |
| START>A | 7.5 | 4 | 1038×2, 1040×2, 1042×2, 1044×2 |
| START>A | 6.7 | 4 | 1038×1, 1040×2, 1042×2, 1044×2, 1046×1, 1056×1 |
| START>A | 6.0 | 5 | 1052×2, 1054×2, 1056×2, 1058×2, 1060×2 |
| START>A | 5.5 | 5 | 1050×2, 1052×2, 1054×2, 1056×2, 1058×2, 1060×1 |
| START>A | 5.0 | 6 | 1042×2, 1044×2, 1046×2, 1048×2, 1052×2, 1062×2 |

## House (up-left U, down-left V, down) — farm arrival, VIs after the house load: count of (U, V) runs

412:28, 414:112, 416:336, 418:357, 420:266, 422:189, 424:196, 426:147, 428:70, 430:84, 432:84, 434:63, 436:56, 438:56, 440:35, 442:7, None:462

## Crossroads (left, cut down-left at C) — ranch arrival, VIs after the farm load: count of runs

586:190, 588:152, 590:190, 592:95, 594:38, None:19

## Beach (first cut D, second cut B; VIs after the beach load)

| D | dog first moved, VIs after the beach load (count) | B reaching the dock end (total) | READY windows (B) |
|---|---|---|---|
| 84 | None×752 | 16544 | 122–143 |
| 86 | None×752 | 16544 | 118–139 |

## Dog lines: 156 (members = beach state × D × B that reach the dock end)

- casts evaluated: 26663 distinct states; repeat checks agree 640, disagree 0

| line | weight | members | beach draw | READY spread (VIs) | casts | Nut casts b1 / b2 |
|---|---|---|---|---|---|---|
| f65b300384cafe38 | 0.095 | 2546 | 1098 | 104 | 1197 | 22 / 43 |
| 9a6c5474c6803fcf | 0.074 | 2216 | 1098 | 104 | 1197 | 55 / 38 |
| 8984a33a478e2a71 | 0.063 | 1738 | 1098 | 98 | 1197 | 31 / 27 |
| 5199cbe24823d77f | 0.057 | 1682 | 1098 | 94 | 1197 | 28 / 31 |
| fb157057066cfe8c | 0.055 | 1388 | 1102 | 44 | 1197 | 73 / 71 |
| f67264ba9bd47fae | 0.045 | 1168 | 1098 | 80 | 1197 | 42 / 62 |
| fb79434d2476c93f | 0.045 | 1186 | 1101 | 64 | 1197 | 66 / 39 |
| f5d1e4c2445f3534 | 0.039 | 936 | 1099 | 94 | 1197 | 61 / 48 |
| fb91026056c19fe4 | 0.039 | 928 | 1104 | 74 | 1197 | 16 / 35 |
| f531446902fa3269 | 0.038 | 880 | 1103 | 22 | 1197 | 48 / 53 |
| fd35ce86ae7efaf3 | 0.034 | 788 | 1116 | 22 | 1197 | 8 / 44 |
| 02817a16ca679b26 | 0.034 | 832 | 1115 | 28 | 1197 | 18 / 35 |
| f0f4d456fe93a3e4 | 0.028 | 646 | 1103 | 44 | 1197 | 17 / 43 |
| 92b3b22d0b0c0ae5 | 0.025 | 648 | 1098 | 34 | 1197 | 20 / 35 |
| 415a9c0309c6d7f3 | 0.024 | 1162 | 1118 | 64 | 1197 | 17 / 35 |
| 3036f0f6f96b4fea | 0.022 | 860 | 1098 | 82 | 1197 | 3 / 19 |
| e6fd3d5856f02528 | 0.014 | 626 | 1098 | 82 | 1197 | 52 / 53 |
| f94ca993ba36d32f | 0.011 | 548 | 1098 | 82 | 1197 | 4 / 25 |
| b4f6a31bd993f8cd | 0.009 | 362 | 1115 | 92 | 1197 | 47 / 43 |
| bf0a1aeb0acee50f | 0.008 | 400 | 1098 | 82 | 1197 | 4 / 19 |
| e7a29e2d0d354704 | 0.008 | 370 | 1108 | 40 | 1197 | 63 / 66 |
| bac910b77686ba76 | 0.006 | 298 | 1098 | 82 | 1197 | 49 / 63 |
| f7b4c3418491c02f | 0.006 | 440 | 1121 | 34 | 1197 | 63 / 40 |
| 35209a5de9cfdd2c | 0.006 | 346 | 1115 | 56 | 1197 | 63 / 65 |
| c3d3a1000573dbff | 0.006 | 284 | 1098 | 82 | 1197 | 61 / 48 |
| b2f61908ae6b594f | 0.005 | 264 | 1101 | 62 | 1197 | 63 / 39 |
| 8ba404db2e81ba6a | 0.005 | 268 | 1101 | 86 | 1197 | 24 / 35 |
| cda63f0497e2e839 | 0.005 | 224 | 1101 | 44 | 1197 | 54 / 63 |
| aff2d1ee6eec670b | 0.005 | 342 | 1124 | 42 | 1197 | 53 / 64 |
| ab91b1f38db565de | 0.004 | 270 | 1098 | 88 | 1197 | 16 / 35 |
| 2204f1e31803f631 | 0.004 | 220 | 1115 | 56 | 1197 | 54 / 54 |
| 9e568694e0ee0852 | 0.004 | 192 | 1125 | 34 | 1197 | 50 / 28 |
| 28936a98d52d45f3 | 0.004 | 188 | 1115 | 72 | 1197 | 21 / 43 |
| f6185330e53c44f0 | 0.003 | 238 | 1121 | 34 | 1197 | 63 / 66 |
| 69fe2455e324e135 | 0.003 | 46 | 1102 | 36 | 1197 | 49 / 63 |
| 0c888ebd438cfe0f | 0.003 | 44 | 1102 | 22 | 1197 | 27 / 31 |
| 1bbe6f2d245066fb | 0.003 | 44 | 1102 | 22 | 1197 | 34 / 34 |
| 240c0fee29772a14 | 0.003 | 44 | 1102 | 22 | 1197 | 13 / 20 |
| 2c454720aee40ede | 0.003 | 44 | 1102 | 22 | 1197 | 4 / 26 |
| 42a520a975a6a6a0 | 0.003 | 44 | 1102 | 22 | 1197 | 3 / 26 |

## Lucky Timer, whole pool (aim = time after READY at the dock end; cast spread 1 s.d.)

| spread | release bite 1 | hold to bite 2 | either (smart, upper bound) | coverage at best |
|---|---|---|---|---|
| 0 ms | 7.8% at 4.5 s | 8.5% at 21.67 s | 13.7% at 22.0 s | 0.978 |
| 100 ms | 5.8% at 7.57 s | 7.0% at 19.63 s | 11.6% at 21.97 s | 0.978 |
| 150 ms | 5.7% at 2.63 s | 6.9% at 19.6 s | 11.1% at 21.93 s | 0.979 |
| 250 ms | 5.6% at 2.67 s | 6.7% at 19.57 s | 10.8% at 21.9 s | 0.979 |

- **Member recast check** (casts from members' own routes vs the shared line table): agree 1752, disagree 29, no table entry 0

  - ['fb157057066cfe8c', '4f23c28ee43fdba3@w6', 86, 138, 646, [1794, False, 4362, False], [1794, False, 4162, False]]
  - ['a6caf17a5122da73', 'd1d167b1b19b83e5@w26', 86, 139, 1138, [2112, False, 4680, False], [2112, False, 4480, False]]
  - ['f531446902fa3269', 'ca0d116ec5c7da90@w16', 86, 139, 470, [1924, False, 2314, False], [1262, False, 3110, False]]
  - ['f67264ba9bd47fae', '93b77f00cd67ce69@w22', 84, 141, 1080, [1674, False, 1836, False], [1682, False, 3530, False]]
  - ['f6185330e53c44f0', '4f3c2c20985f8262@w14', 86, 126, 996, [1980, False, 4348, False], [1980, False, 4720, False]]
  - ['f5d1e4c2445f3534', 'a391763f4f946e2b@w20', 86, 135, 558, [1732, False, 2428, False], [1462, False, 2062, False]]
  - ['f531446902fa3269', '1df213f845e0d2d0@w16', 84, 141, 734, [1532, False, 3664, False], [1532, False, 4222, False]]
  - ['fb157057066cfe8c', 'a78190bf35128db6@w6', 84, 137, 826, [1616, False, 2172, False], [1640, False, 2240, False]]
  - ['f531446902fa3269', 'a78190bf35128db6@w20', 86, 136, 848, [1600, False, 3732, False], [1600, False, 4290, False]]
  - ['fb157057066cfe8c', '9c826288fc0350df@w30', 86, 129, 844, [1494, False, 1656, False], [1502, False, 3350, False]]
  - ['28936a98d52d45f3', '8b13e0ec7169b12c@w24', 86, 136, 1028, [2052, False, 4620, False], [2052, False, 4420, False]]
  - ['ca35753ac8267ac2', '07a9ba1f92a4b5ad@w6', 84, 135, 614, [2010, False, 2388, False], [2010, False, 3104, False]]
  - ['2204f1e31803f631', '4f3c2c20985f8262@w22', 86, 135, 668, [1374, False, 1536, False], [1382, False, 3230, False]]
  - ['f531446902fa3269', '8a82f2b93b4400b8@w22', 86, 127, 24, [1406, False, 2102, False], [1410, False, 2106, False]]
  - ['5199cbe24823d77f', '1dfbe3197f51fafb@w4', 86, 131, 1442, [2312, False, 4880, False], [2312, False, 4680, False]]
  - ['a45eb30140279c89', 'f611b4a219197f17@w22', 84, 130, 1282, [2184, False, 4752, False], [2184, False, 4552, False]]
  - ['f531446902fa3269', '9c826288fc0350df@w16', 86, 131, 2262, [2794, False, 4652, False], [2794, False, 5210, False]]
  - ['eb1f949e24a3846e', 'f51ac2c7a1bdb6d1@w24', 84, 140, 1590, [2404, False, 4972, False], [2404, False, 4772, False]]
  - ['9821f44ae2007fcd', '2ba3c3c366e530bc@w6', 84, 138, 1728, [2074, False, 3516, False], [2074, False, 3890, False]]
  - ['d7d60c258b9276a8', '161b80d653f8d6de@w28', 84, 138, 1348, [2208, False, 4776, False], [2208, False, 4576, False]]
