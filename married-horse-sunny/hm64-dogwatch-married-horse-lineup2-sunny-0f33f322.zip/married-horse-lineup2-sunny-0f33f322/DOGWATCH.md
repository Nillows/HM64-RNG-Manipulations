# Dog-watch report: married-horse-lineup2-sunny-0f33f322

156 dog lines with traces (40 s after READY), 1959 (line, READY offset) variants; route-weighted. Clock = the dock-end tap ±3 VI; logs from 1.0 s after READY; runner: changes >= 12 VI, reaction 10-25 VI, 15% missed. Odds: cast >= 2 s after the window, ±150 ms.

## What the dog does while you wait (after READY, route-weighted)

- dog's tile on the visibility grid (it animates only then): 100% of the time
- visible changes per minute: 59; changes lasting >= 12 VI: 90%
- facing on screen (share of the wait): SW 36%, NE 15%, E 15%, SE 14%, N 10%, NW 8%, W 2%; animations readable (dog faces S / N / NE / E / SE): 54%
- the dog moves (units, max over the trace): median 0.0
- decision (actionState change) -> next visible change: median 0 VI (p10 0, p90 30); animation set -> displayed: median 0 VI

## Telling the lines apart (simulated runners)

| logging | window | right line on top | posterior on it | >= 90% sure | lines left | logs | Nut (no logs -> logs) | known line |
|---|---|---|---|---|---|---|---|---|
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 3 s | 32% | 24% | 14% | 56.1 | 0.2 | 6.9% -> 10.4% | 22.7% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 5 s | 32% | 24% | 13% | 59.0 | 0.3 | 6.0% -> 11.1% | 22.4% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 10 s | 53% | 44% | 24% | 39.7 | 1.5 | 6.9% -> 14.8% | 21.6% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 15 s | 64% | 54% | 30% | 29.8 | 2.6 | 6.7% -> 16.2% | 20.5% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 20 s | 68% | 60% | 39% | 27.1 | 4.4 | 6.6% -> 16.3% | 20.0% |
| gear, arrows only (no arrow = same facing) | 3 s | 28% | 19% | 11% | 60.0 | 0.0 | 6.9% -> 11.0% | 22.9% |
| gear, arrows only (no arrow = same facing) | 5 s | 29% | 19% | 11% | 61.8 | 0.1 | 6.6% -> 10.7% | 22.5% |
| gear, arrows only (no arrow = same facing) | 10 s | 40% | 33% | 20% | 46.3 | 0.2 | 6.5% -> 13.1% | 21.9% |
| gear, arrows only (no arrow = same facing) | 15 s | 62% | 51% | 30% | 32.2 | 0.8 | 6.5% -> 15.6% | 20.4% |
| gear, arrows only (no arrow = same facing) | 20 s | 63% | 54% | 31% | 28.8 | 1.3 | 7.0% -> 16.1% | 20.1% |
| your logging (arrows always, letters for long animations facing S/N/E) | 3 s | 20% | 12% | 2% | 131.2 | 0.2 | 6.8% -> 8.3% | 23.1% |
| your logging (arrows always, letters for long animations facing S/N/E) | 5 s | 25% | 18% | 8% | 121.3 | 0.4 | 6.8% -> 9.6% | 22.1% |
| your logging (arrows always, letters for long animations facing S/N/E) | 10 s | 50% | 37% | 18% | 77.1 | 1.6 | 6.4% -> 12.6% | 21.9% |
| your logging (arrows always, letters for long animations facing S/N/E) | 15 s | 60% | 49% | 28% | 54.0 | 3.3 | 7.0% -> 14.7% | 20.8% |
| your logging (arrows always, letters for long animations facing S/N/E) | 20 s | 63% | 49% | 28% | 51.5 | 4.7 | 7.2% -> 16.8% | 20.3% |
| arrows only (facing track + durations) | 3 s | 16% | 6% | 1% | 151.4 | 0.0 | 6.5% -> 6.7% | 22.8% |
| arrows only (facing track + durations) | 5 s | 11% | 5% | 0% | 149.6 | 0.0 | 6.4% -> 6.9% | 21.7% |
| arrows only (facing track + durations) | 10 s | 26% | 18% | 3% | 112.0 | 0.3 | 6.7% -> 9.6% | 22.1% |
| arrows only (facing track + durations) | 15 s | 40% | 28% | 11% | 84.0 | 0.8 | 6.7% -> 12.1% | 20.9% |
| arrows only (facing track + durations) | 20 s | 46% | 34% | 14% | 76.0 | 1.1 | 6.7% -> 14.5% | 20.3% |
| every change, letter + arrow | 3 s | 72% | 60% | 38% | 32.1 | 1.2 | 6.6% -> 17.3% | 23.2% |
| every change, letter + arrow | 5 s | 88% | 83% | 69% | 7.2 | 2.5 | 6.7% -> 20.2% | 22.4% |
| every change, letter + arrow | 10 s | 90% | 88% | 77% | 1.9 | 6.3 | 7.2% -> 21.2% | 22.0% |
| every change, letter + arrow | 15 s | 92% | 90% | 80% | 2.1 | 10.7 | 6.7% -> 20.1% | 20.7% |
| every change, letter + arrow | 20 s | 92% | 90% | 79% | 1.7 | 14.1 | 5.8% -> 18.6% | 19.3% |
| every animation change, letter only | 3 s | 67% | 58% | 41% | 39.3 | 1.1 | 6.8% -> 16.2% | 22.3% |
| every animation change, letter only | 5 s | 88% | 84% | 72% | 6.3 | 2.4 | 6.5% -> 20.4% | 22.4% |
| every animation change, letter only | 10 s | 90% | 88% | 78% | 2.1 | 6.2 | 7.1% -> 21.4% | 22.3% |
| every animation change, letter only | 15 s | 92% | 90% | 78% | 1.8 | 10.0 | 6.8% -> 19.9% | 20.7% |
| every animation change, letter only | 20 s | 90% | 88% | 77% | 1.8 | 13.5 | 6.7% -> 19.2% | 19.8% |
| Space at every change | 3 s | 34% | 11% | 0% | 91.7 | 1.2 | 6.0% -> 9.5% | 22.2% |
| Space at every change | 5 s | 46% | 24% | 0% | 44.4 | 2.5 | 6.3% -> 14.0% | 22.0% |
| Space at every change | 10 s | 79% | 70% | 49% | 7.0 | 6.5 | 6.5% -> 20.1% | 22.1% |
| Space at every change | 15 s | 85% | 80% | 64% | 3.2 | 10.6 | 6.9% -> 19.7% | 20.4% |
| Space at every change | 20 s | 85% | 81% | 64% | 3.3 | 14.2 | 7.3% -> 19.6% | 20.3% |

Readability: *your logging* follows Thomas's TV check (facing always readable; animations only while the dog
faces S, N, NE, E or SE, and only animations lasting >= 1 s are logged). The other rows are for comparison.

## Duds before the cast (reset early)

Dud = the best cast for what your logs leave is under the threshold; you reset instead of casting. Odds per attempt; 'kept' = attempts you cast.

| logging | window | threshold | attempts called dud | Nut on kept attempts | Nut the resets threw away | all-cast Nut |
|---|---|---|---|---|---|---|
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 3 s | 5% | 0% | 10.4% | 0.00 pts | 10.4% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 3 s | 8% | 0% | 10.4% | 0.00 pts | 10.4% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 5 s | 5% | 1% | 11.2% | 0.00 pts | 11.1% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 5 s | 8% | 1% | 11.2% | 0.00 pts | 11.1% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 10 s | 5% | 0% | 14.9% | 0.00 pts | 14.8% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 10 s | 8% | 0% | 14.9% | 0.00 pts | 14.8% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 15 s | 5% | 0% | 16.3% | 0.00 pts | 16.2% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 15 s | 8% | 0% | 16.3% | 0.00 pts | 16.2% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 20 s | 5% | 1% | 16.5% | 0.00 pts | 16.3% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 20 s | 8% | 3% | 16.7% | 0.21 pts | 16.3% |
| gear, arrows only (no arrow = same facing) | 3 s | 5% | 0% | 11.0% | 0.00 pts | 11.0% |
| gear, arrows only (no arrow = same facing) | 3 s | 8% | 0% | 11.0% | 0.00 pts | 11.0% |
| gear, arrows only (no arrow = same facing) | 5 s | 5% | 1% | 10.8% | 0.00 pts | 10.7% |
| gear, arrows only (no arrow = same facing) | 5 s | 8% | 1% | 10.8% | 0.00 pts | 10.7% |
| gear, arrows only (no arrow = same facing) | 10 s | 5% | 0% | 13.1% | 0.00 pts | 13.1% |
| gear, arrows only (no arrow = same facing) | 10 s | 8% | 0% | 13.1% | 0.00 pts | 13.1% |
| gear, arrows only (no arrow = same facing) | 15 s | 5% | 1% | 15.8% | 0.00 pts | 15.6% |
| gear, arrows only (no arrow = same facing) | 15 s | 8% | 11% | 16.8% | 0.66 pts | 15.6% |
| gear, arrows only (no arrow = same facing) | 20 s | 5% | 1% | 16.2% | 0.00 pts | 16.1% |
| gear, arrows only (no arrow = same facing) | 20 s | 8% | 15% | 17.8% | 0.91 pts | 16.1% |

### Early dud signs, your logging, 10 s window, dud = best cast under 5%

0% of attempts are duds at this threshold (if the line were known). A sign = what you log in a 1-s slot after READY; seen = share of attempts showing it; dud share = how many of those are duds.

| you log | seconds after READY | seen | dud share |
|---|---|---|---|
| numpad 1 sit | 8-9 | 20.8% | 0% |
| numpad 2 stand | 9-10 | 14.3% | 0% |
| numpad 2 stand | 5-6 | 10.1% | 0% |
| faces NE | 5-6 | 10.1% | 0% |
| numpad 0 idle | 5-6 | 7.8% | 0% |
| numpad 0 idle | 2-3 | 7.0% | 0% |
| numpad 6 sleep | 9-10 | 7.0% | 0% |
| numpad 0 idle | 1-2 | 6.8% | 0% |
| numpad 1 sit | 9-10 | 5.7% | 0% |
| faces SE | 8-9 | 4.9% | 0% |
| numpad 5 run | 3-4 | 4.9% | 0% |
| numpad 4 walk | 5-6 | 4.9% | 0% |
| numpad 4 walk | 6-7 | 4.7% | 0% |
| numpad 5 run | 4-5 | 4.6% | 0% |
| faces NW | 5-6 | 4.5% | 0% |
| numpad 9 shoulder | 4-5 | 4.1% | 0% |
| numpad 9 shoulder | 6-7 | 3.9% | 0% |
| numpad 2 stand | 8-9 | 3.8% | 0% |
| numpad 0 idle | 8-9 | 3.7% | 0% |
| numpad 0 idle | 9-10 | 3.6% | 0% |

### Early dud signs, your logging, 10 s window, dud = best cast under 8%

0% of attempts are duds at this threshold (if the line were known). A sign = what you log in a 1-s slot after READY; seen = share of attempts showing it; dud share = how many of those are duds.

| you log | seconds after READY | seen | dud share |
|---|---|---|---|
| numpad 1 sit | 8-9 | 20.8% | 0% |
| numpad 2 stand | 9-10 | 14.3% | 0% |
| numpad 2 stand | 5-6 | 10.1% | 0% |
| faces NE | 5-6 | 10.1% | 0% |
| numpad 0 idle | 5-6 | 7.8% | 0% |
| numpad 0 idle | 2-3 | 7.0% | 0% |
| numpad 6 sleep | 9-10 | 7.0% | 0% |
| numpad 0 idle | 1-2 | 6.8% | 0% |
| numpad 1 sit | 9-10 | 5.7% | 0% |
| faces SE | 8-9 | 4.9% | 0% |
| numpad 5 run | 3-4 | 4.9% | 0% |
| numpad 4 walk | 5-6 | 4.9% | 0% |
| numpad 4 walk | 6-7 | 4.7% | 0% |
| numpad 5 run | 4-5 | 4.6% | 0% |
| faces NW | 5-6 | 4.5% | 0% |
| numpad 9 shoulder | 4-5 | 4.1% | 0% |
| numpad 9 shoulder | 6-7 | 3.9% | 0% |
| numpad 2 stand | 8-9 | 3.8% | 0% |
| numpad 0 idle | 8-9 | 3.7% | 0% |
| numpad 0 idle | 9-10 | 3.6% | 0% |
