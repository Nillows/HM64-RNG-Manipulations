# HM64 full-day lab — the cast table and the dog to the end of the game day

## 1. The day without a cast (every dog line, stay-awake push every 33 s)

- 156 lines ran of 156; dog at READY: [-197.27, 222.24]
- Clock at READY: 06:48 – 06:52. Followed to 8398 VIs = 140 s after READY (the limit).
- Same paths as the dog-watch run? cast hashes of the first 33 s: **155220 equal, 0 different**.
- Ended by something else than the limit / the end of the day: 0
- The dog's visible changes over that time: 143 per line.
- **The dog leaves its spot** (moved 4 units or more) on 125 of 156 lines; earliest 1 s after READY, median 101 s.
- Its tile leaves the visibility grid (not on screen, not animating) on 16 lines.

## 2. Cast blocks (every cast held to the limit, or the end of the day)

| block | cast frames (s after READY) | lines | casts planned | done | job errors | hash check ok / failed / none | ended: as planned / beach check / other | bites per cast | casts with a Nut on some bite |
|---|---|---|---|---|---|---|---|---|---|
| 2 | 40.1 – 80.2 · heavy | 57 | 15502 | 15502 | 0 | 14305 / 0 / 1197 | 15502 / 0 / 0 | 5.3 | 618 (4.0%) |
| 3 | 40.1 – 80.2 · other | 99 | 6785 | 6785 | 0 | 4706 / 0 / 2079 | 6785 / 0 / 0 | 5.2 | 177 (2.6%) |
| 4 | 80.2 – 90.3 · heavy | 16 | 2921 | 2921 | 0 | 2921 / 0 / 0 | 2921 / 0 / 0 | 3.9 | 0 (0.0%) |
| 5 | 80.2 – 90.3 · other | 10 | 979 | 979 | 0 | 979 / 0 / 0 | 979 / 0 / 0 | 3.9 | 0 (0.0%) |

Blocks not started: 2 (46746 casts). Data so far: 26.3 MB.

## 3. The beach check

- 26187 casts: **26187 ran to the limit / the end of the day on the beach at the dock end**, 0 were stopped by the beach check, 0 ended another way.
- Cast hash = the dog-watch run's state at that frame: 22911 equal, **0 different**, 3276 not compared (cast frames inside a stay-awake push).

## 4. Bites and Nuts by game hour (on the held casts)

- 133025 bites; released 4 polls after the bite: s 52891, l 47360, m 31979, N 795 (N Nut, s / m / l fish size, d the day ended before the catch, x miss, h held through, o other; a / b = the two release probes differ).
- The two release probes of bites 1-2 gave different catches on 0 bites.
- Nut by bite number: bite 1: 656, bite 2: 128, bite 3: 11.

| game hour | bites | Nut bites | Nut share |
|---|---|---|---|
| 10:00 | 1806 | 0 | 0.00% |
| 11:00 | 5327 | 315 | 5.91% |
| 12:00 | 9265 | 477 | 5.15% |
| 13:00 | 10022 | 3 | 0.03% |
| 14:00 | 15463 | 0 | 0.00% |
| 15:00 | 24903 | 0 | 0.00% |
| 16:00 | 32882 | 0 | 0.00% |
| 17:00 | 24269 | 0 | 0.00% |
| 18:00 | 9086 | 0 | 0.00% |
| 19:00 | 1 | 0 | 0.00% |
| 22:00 | 1 | 0 | 0.00% |

These are bites of casts HELD since the cast frame, not fresh casts at that hour: a later hour is
reached only by holding through every earlier bite.

## 5. Do the held casts run into each other?

- 133025 bite states, 8744 distinct (93.4% shared): a shared state has the same future, so its later bites need not be simulated twice.

## 6. The dog after the cast

- Visible changes recorded from the cast to the end of its run: 71 per cast; on the released paths (the 4 s after each bite): 4.7 per bite.
- The dog leaves its spot at some point of the run in 21099 of 26187 casts (81%).

## 7. Against the dog-watch run's cast table (same state hash)

- 0 casts are in both: bite times and Nut flags **equal in 0, different in 0**.

