# HM64 full-day lab — the cast table and the dog to the end of the game day

## 1. The day without a cast (every dog line, stay-awake push every 33 s)

- 99 lines ran of 99; dog at READY: [-198.51, 223.49]
- Clock at READY: 06:48 – 06:52. Followed to 10198 VIs = 170 s after READY (the limit).
- Same paths as the dog-watch run? cast hashes of the first 33 s: **98505 equal, 0 different**.
- Ended by something else than the limit / the end of the day: 0
- The dog's visible changes over that time: 167 per line.
- **The dog leaves its spot** (moved 4 units or more) on 87 of 99 lines; earliest 3 s after READY, median 53 s.
- Its tile leaves the visibility grid (not on screen, not animating) on 29 lines.

## 2. Cast blocks (every cast held to the limit, or the end of the day)

| block | cast frames (s after READY) | lines | casts planned | done | job errors | hash check ok / failed / none | ended: as planned / beach check / other | bites per cast | casts with a Nut on some bite |
|---|---|---|---|---|---|---|---|---|---|
| 4 | 80.2 – 120.3 · heavy | 50 | 33260 | 33260 | 0 | 32210 / 0 / 1050 | 33260 / 0 / 0 | 4.7 | 1812 (5.4%) |
| 5 | 80.2 – 120.3 · other | 49 | 17724 | 17724 | 0 | 16695 / 0 / 1029 | 17724 / 0 / 0 | 4.6 | 701 (4.0%) |

Blocks not started: 4 (123690 casts). Data so far: 46.0 MB.

## 3. The beach check

- 50984 casts: **50984 ran to the limit / the end of the day on the beach at the dock end**, 0 were stopped by the beach check, 0 ended another way.
- Cast hash = the dog-watch run's state at that frame: 48905 equal, **0 different**, 2079 not compared (cast frames inside a stay-awake push).

## 4. Bites and Nuts by game hour (on the held casts)

- 237159 bites; released 4 polls after the bite: s 91086, m 73592, l 69952, N 2529 (N Nut, s / m / l fish size, d the day ended before the catch, x miss, h held through, o other; a / b = the two release probes differ).
- The two release probes of bites 1-2 gave different catches on 0 bites.
- Nut by bite number: bite 1: 421, bite 2: 607, bite 3: 734, bite 4: 366, bite 5+: 401.

| game hour | bites | Nut bites | Nut share |
|---|---|---|---|
| 13:00 | 828 | 3 | 0.36% |
| 14:00 | 12796 | 58 | 0.45% |
| 15:00 | 32999 | 445 | 1.35% |
| 16:00 | 29376 | 346 | 1.18% |
| 17:00 | 50440 | 479 | 0.95% |
| 18:00 | 15390 | 0 | 0.00% |
| 19:00 | 56279 | 1196 | 2.13% |
| 20:00 | 36106 | 2 | 0.01% |
| 21:00 | 1915 | 0 | 0.00% |
| 22:00 | 858 | 0 | 0.00% |
| 23:00 | 161 | 0 | 0.00% |
| 00:00 | 11 | 0 | 0.00% |

These are bites of casts HELD since the cast frame, not fresh casts at that hour: a later hour is
reached only by holding through every earlier bite.

## 5. Do the held casts run into each other?

- 237159 bite states, 37597 distinct (84.1% shared): a shared state has the same future, so its later bites need not be simulated twice.

## 6. The dog after the cast

- Visible changes recorded from the cast to the end of its run: 61 per cast; on the released paths (the 4 s after each bite): 4.3 per bite.
- The dog leaves its spot at some point of the run in 44880 of 50984 casts (88%).

## 7. Against the dog-watch run's cast table (same state hash)

- 0 casts are in both: bite times and Nut flags **equal in 0, different in 0**.

