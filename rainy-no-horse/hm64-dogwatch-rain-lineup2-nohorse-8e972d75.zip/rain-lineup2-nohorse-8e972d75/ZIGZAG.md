# Dog-spot lab (dogwatch): rain-lineup2-nohorse-8e972d75.SaveRAM

Zig-zag route with the zigzag-fast recipe of route delays, dog-neutral (no dog-wake rule or key: every first / second cut is walked and kept, lines are anchored at the beach load and matched by game state at READY).

## The save

- file `rain-lineup2-nohorse-8e972d75.SaveRAM` (sha256 8e972d756d3ef52f)
- spring 5, year 1; weather 2; 6:00 at the house load; rod in hand: True
- dog at the house load: **beach** (map 9) x -198.51, z 223.49, facing 0, flags ACTIVE
- dog on screen at the load of: beach
- repeatable (two cold boots give the same record): **yes**
- reference route (mash 10/s START→A, house U276 V52, crossroads C80, beach D86 B134), map loads: house VI 1036, farm +412, crossroads +350, ranch +236, beach +230; READY 339 VIs after the beach load at x -92.0, z 194.0

## Failure map: where the recipe never reaches READY

Mass = uniform choices over this preset's grids (mash phase per rate, rates pooled; house U, V; crossroads C; first cut D; any second cut B). Each stage starts from the mass kept by the stage before.

| stage | runs | never reached | mass kept | outside the band (slower; or faster for a 5-9-frame preset) | never reached (mass) | where Jack stopped (most common) |
|---|---|---|---|---|---|---|
| menus | 144 | 0 | 0.6675 | 0.3325 | 0.0000 | - |
| house | 2548 | 462 | 0.2733 | 0.2733 | 0.1210 | 364× map 87 x≈96 z≈80; 28× map 87 x≈-24 z≈120; 28× map 87 x≈-32 z≈128 |
| crossroads | 360 | 10 | 0.2505 | 0.0152 | 0.0076 | 10× map 78 x≈120 z≈0 |
| ranch | 12 | 0 | 0.2505 | 0.0000 | 0.0000 | - |
| beach | 384 | 0 | 0.2505 | 0.0000 | 0.0000 | - |

- **mass of the recipe that reaches the dock end: 0.2505** (the D grid includes 82–83, which never clear the small wall on the dog-beach save)

| first cut D | P(some B reaches the dock end) | B in the window (VIs: count of beach states) | why the other B stop (D without a window) |
|---|---|---|---|
| 84 | 1.000 | 22: 192 | - |
| 86 | 1.000 | 22: 192 | - |

Second cut B by first cut D (share of the beach-state mass that reaches the dock end; else why Jack stopped, and where):

- D 84: 112–121 no READY (map 9 x≈-208 z≈120) · 122–143 READY · 144–151 no READY (map 9 x≈-224 z≈224)
- D 86: 112–117 no READY (map 9 x≈-208 z≈128) · 118–139 READY · 140–151 no READY (map 9 x≈-224 z≈224)

| 1st cut (web app bands) | share of the D grid | P(a 2nd cut reaches the dock end) |
|---|---|---|
| tight | 1.000 | 1.000 |

## Lines (dog-neutral: anchored at the beach load, matched by game state at READY)

- 99 lines from 192 beach states; lines per beach state (count of states): 3: 6, 4: 174, 5: 12; **0 of 192 beach states collapse to one line** (every first and second cut of that state shares one RNG trajectory, offset in time only)
- largest READY offset inside a line: 64 VIs; members not matched to any path: 0

## Cut timing, split as the web app does (cast spread 150 ms)

| preset | share of routes | release bite 1 | hold to bite 2 | either (upper bound) |
|---|---|---|---|---|
| All | 1.000 | 6.14% at 21.07 s | 4.62% at 7.53 s | 9.05% at 27.7 s |
| 1st cut tight | 1.000 | 6.14% at 21.07 s | 4.62% at 7.53 s | 9.05% at 27.7 s |
| 1st cut tight · 2nd cut early | 0.545 | 6.54% at 21.17 s | 4.93% at 7.63 s | 9.28% at 27.8 s |
| 1st cut tight · 2nd cut middle | 0.182 | 6.55% at 21.07 s | 5.03% at 7.53 s | 9.52% at 27.7 s |
| 1st cut tight · 2nd cut late | 0.273 | 6.40% at 20.93 s | 4.77% at 7.37 s | 9.39% at 27.57 s |
| 1st cut mid | 0.000 | - | - | - |
| 1st cut mid · 2nd cut early | 0.000 | - | - | - |
| 1st cut mid · 2nd cut middle | 0.000 | - | - | - |
| 1st cut mid · 2nd cut late | 0.000 | - | - | - |
| 1st cut loose | 0.000 | - | - | - |
| 1st cut loose · 2nd cut early | 0.000 | - | - | - |
| 1st cut loose · 2nd cut middle | 0.000 | - | - | - |
| 1st cut loose · 2nd cut late | 0.000 | - | - | - |

## Lineup: stability

- 99 lines; the heaviest holds 5.0% of the routes; 20 lines hold 50% and 50 hold 90% (fewer = steadier dog)
- one beach start (beach state + wait) across the full pier width: lines (count of starts) 3: 6, 4: 174, 5: 12; how the second cuts split: B 118-119 + B 120-123 + B 122-139 + B 126-143 (172 starts); B 118-119 + B 120-121 + B 122-139 + B 122-123 + B 126-143 (4 starts); B 118-143 + B 120-123 + B 122-139 (4 starts); B 118-119 + B 120-123 + B 122-139 + B 126-143 + B 128-129 (4 starts)
- one wait + second cut across the beach states (the route before the beach): lines (count) 7: 22, 8: 138, 14: 80, 15: 174, 16: 2

## Lineup: does the dog keep drawing after READY (standing at the pier, no cast)?

- routes whose line has the dog drawing after READY: **100.0%**; extra draws over 39 s (above the 1-per-game-frame clock), route-weighted mean 20653; dog's tile visible 99% of the time

## Lineup: where the dog activates (its tile enters the camera's view; until then it draws nothing)

First VI after the beach load (share of routes): 205: 0.3%, 207: 0.9%, 209: 3.7%, 211: 6.2%, 213: 6.2%, 215: 6.2%, 217: 6.2%, 219: 6.2%, 221: 6.3%, 223: 6.3%, 225: 6.2%, 227: 6.2%, 229: 6.2%, 231: 6.2%, 233: 6.2%, 235: 6.2%, 237: 6.0%, 239: 5.4%, 241: 2.6%

| Jack at the activation (x, z; 8-unit cells) | share of routes | lines | release bite 1 | hold to bite 2 |
|---|---|---|---|---|
| x -456…-448, z 160…168 | 0.727 | 91 | 6.18% at 21.03 s (cover 0.96) | 4.62% at 7.5 s (cover 0.94) |
| x -448…-440, z 152…160 | 0.182 | 96 | 6.54% at 21.2 s (cover 0.95) | 4.90% at 7.67 s (cover 0.93) |
| x -448…-440, z 144…152 | 0.091 | 88 | 6.75% at 21.13 s (cover 0.95) | 5.16% at 7.57 s (cover 0.91) |

## Lineup: beach wait W (VIs Jack stands still at the beach load before his first step)

| W (VIs) | share of routes | lines | release bite 1 | hold to bite 2 |
|---|---|---|---|---|
| 0 | 0.062 | 27 | 8.36% at 20.2 s (cover 0.88) | 6.53% at 7.6 s (cover 0.81) |
| 2 | 0.062 | 25 | 9.11% at 21.23 s (cover 0.97) | 9.02% at 7.57 s (cover 0.95) |
| 4 | 0.062 | 26 | 11.24% at 11.7 s (cover 0.99) | 7.80% at 17.3 s (cover 0.99) |
| 6 | 0.062 | 26 | 7.71% at 20.03 s (cover 0.94) | 5.34% at 3.67 s (cover 0.94) |
| 8 | 0.062 | 25 | 8.27% at 33.37 s (cover 1.00) | 8.02% at 9.8 s (cover 0.93) |
| 10 | 0.062 | 27 | 9.64% at 21.17 s (cover 0.98) | 17.03% at 9.8 s (cover 0.98) |
| 12 | 0.062 | 25 | 10.27% at 21.17 s (cover 0.93) | 11.95% at 9.83 s (cover 0.93) |
| 14 | 0.062 | 25 | 10.04% at 8.17 s (cover 0.93) | 6.02% at 27.03 s (cover 0.93) |
| 16 | 0.062 | 27 | 8.51% at 8.2 s (cover 0.98) | 6.06% at 7.23 s (cover 0.98) |
| 18 | 0.062 | 26 | 6.52% at 21.07 s (cover 0.99) | 9.13% at 7.23 s (cover 0.99) |
| 20 | 0.062 | 26 | 8.28% at 31.03 s (cover 1.00) | 9.41% at 7.2 s (cover 0.98) |
| 22 | 0.062 | 27 | 12.08% at 4.03 s (cover 1.00) | 8.23% at 20.6 s (cover 1.00) |
| 24 | 0.062 | 27 | 9.50% at 20.93 s (cover 1.00) | 6.73% at 27.57 s (cover 1.00) |
| 26 | 0.062 | 28 | 11.19% at 21.83 s (cover 0.94) | 10.01% at 20.03 s (cover 0.94) |
| 28 | 0.062 | 27 | 9.36% at 24.37 s (cover 0.93) | 6.48% at 23.1 s (cover 0.93) |
| 30 | 0.062 | 28 | 10.03% at 21.93 s (cover 0.89) | 9.88% at 23.2 s (cover 0.92) |

## Lineup: first cut D (VIs of down-right after the beach load, before the cut down-left)

D 84 = the earliest cut that clears the small wall (scrapes its corner: Jack pushed to x -451.6); D 86 = one game frame later (clears the corner: x -452.0, still the wall column of the dog's view grid).

| first cut | share of routes | lines | of them shared with the other cut | dog wakes, VI after the beach load - W (share) | release bite 1 | hold to bite 2 |
|---|---|---|---|---|---|---|
| D 84 | 0.500 | 95 | 90 | 211 (82%), 209 (9%), 207 (9%) | 6.04% at 21.07 s (cover 0.96) | 4.62% at 7.53 s (cover 0.93) |
| D 86 | 0.500 | 94 | 90 | 209 (82%), 205 (9%), 207 (9%) | 6.26% at 21.1 s (cover 0.95) | 4.62% at 7.53 s (cover 0.95) |

## Lineup: wait band x second cut (full pier width; early / middle / late = dock-end spot z ≤178 / ≤190 / >190)

| wait | 2nd cut | share of routes | lines | release bite 1 | hold to bite 2 |
|---|---|---|---|---|---|
| wait 0-9 | any | 0.312 | 47 | 7.19% at 11.7 s (cover 0.92) | 5.71% at 7.57 s (cover 0.92) |
| wait 0-9 | Early | 0.170 | 47 | 7.83% at 11.77 s (cover 0.91) | 6.36% at 7.6 s (cover 0.91) |
| wait 0-9 | Middle | 0.057 | 37 | 7.71% at 11.67 s (cover 0.95) | 6.45% at 7.5 s (cover 0.95) |
| wait 0-9 | Late | 0.085 | 37 | 7.47% at 11.53 s (cover 0.94) | 5.87% at 7.37 s (cover 0.94) |
| wait 10-19 | any | 0.312 | 48 | 6.65% at 8.17 s (cover 0.96) | 6.71% at 9.83 s (cover 0.96) |
| wait 10-19 | Early | 0.170 | 47 | 6.94% at 8.23 s (cover 0.96) | 7.53% at 9.87 s (cover 0.96) |
| wait 10-19 | Middle | 0.057 | 37 | 7.32% at 8.17 s (cover 0.97) | 6.85% at 9.8 s (cover 0.97) |
| wait 10-19 | Late | 0.085 | 36 | 7.04% at 8.03 s (cover 0.97) | 6.56% at 9.67 s (cover 0.97) |
| wait 20-30 | any | 0.375 | 55 | 8.11% at 21.9 s (cover 0.96) | 6.14% at 20.13 s (cover 0.96) |
| wait 20-30 | Early | 0.205 | 55 | 8.54% at 22.0 s (cover 0.97) | 6.51% at 20.17 s (cover 0.97) |
| wait 20-30 | Middle | 0.068 | 43 | 8.97% at 21.9 s (cover 0.96) | 6.51% at 20.07 s (cover 0.96) |
| wait 20-30 | Late | 0.102 | 43 | 8.66% at 21.77 s (cover 0.95) | 6.23% at 19.97 s (cover 0.96) |
| any wait | any | 1.000 | 99 | 6.14% at 21.07 s (cover 0.96) | 4.62% at 7.53 s (cover 0.94) |
| any wait | Early | 0.545 | 99 | 6.54% at 21.17 s (cover 0.96) | 4.93% at 7.63 s (cover 0.93) |
| any wait | Middle | 0.182 | 91 | 6.55% at 21.07 s (cover 0.96) | 5.03% at 7.53 s (cover 0.94) |
| any wait | Late | 0.273 | 91 | 6.40% at 20.93 s (cover 0.96) | 4.77% at 7.37 s (cover 0.94) |

## Menus (mash until the house loads)

| style | presses/s | held VIs | house arrival VI (count of phases) |
|---|---|---|---|
| START+A | 15.0 | 2 | 1038×2, 1040×2 |
| START+A | 12.0 | 2 | 1042×2, 1044×2, 1046×1 |
| START+A | 10.0 | 3 | 1042×2, 1044×2, 1046×2 |
| START+A | 8.6 | 3 | 1042×1, 1044×1, 1046×1, 1048×1, 1050×1, 1052×1, 1054×1 |
| START+A | 7.5 | 4 | 1038×2, 1040×2, 1042×2, 1044×2 |
| START+A | 6.7 | 4 | 1038×1, 1040×2, 1042×2, 1044×2, 1046×1, 1056×1 |
| START+A | 6.0 | 5 | 1052×2, 1054×2, 1056×2, 1058×2, 1060×2 |
| START+A | 5.5 | 5 | 1050×2, 1052×2, 1054×2, 1056×2, 1058×2, 1060×1 |
| START+A | 5.0 | 6 | 1054×2, 1056×2, 1058×2, 1060×2, 1064×2, 1074×2 |
| START>A | 15.0 | 2 | 1038×2, 1040×2 |
| START>A | 12.0 | 2 | 1042×2, 1044×2, 1046×1 |
| START>A | 10.0 | 3 | 1036×1, 1038×1, 1040×1, 1042×1, 1044×1, 1046×1 |
| START>A | 8.6 | 3 | 1042×1, 1044×2, 1046×2, 1048×2 |
| START>A | 7.5 | 4 | 1038×2, 1040×2, 1042×2, 1044×2 |
| START>A | 6.7 | 4 | 1038×1, 1040×2, 1042×2, 1044×2, 1046×1, 1056×1 |
| START>A | 6.0 | 5 | 1052×2, 1054×2, 1056×2, 1058×2, 1060×2 |
| START>A | 5.5 | 5 | 1050×2, 1052×2, 1054×2, 1056×2, 1058×2, 1060×1 |
| START>A | 5.0 | 6 | 1042×2, 1044×2, 1046×2, 1048×2, 1052×2, 1062×2 |

## House (up-left U, down-left V, down) — farm arrival, VIs after the house load: count of (U, V) runs

412:28, 414:112, 416:336, 418:357, 420:210, 422:217, 424:224, 426:91, 428:70, 430:112, 432:56, 434:63, 436:56, 438:56, 440:35, 442:28, 444:28, 446:7, None:462

## Crossroads (left, cut down-left at C) — ranch arrival, VIs after the farm load: count of runs

586:100, 588:80, 590:100, 592:50, 594:20, None:10

## Beach (first cut D, second cut B; VIs after the beach load)

| D | dog first moved, VIs after the beach load (count) | B reaching the dock end (total) | READY windows (B) |
|---|---|---|---|
| 84 | None×192 | 4224 | 122–143 |
| 86 | None×192 | 4224 | 118–139 |

## Dog lines: 99 (members = beach state × D × B that reach the dock end)

- casts evaluated: 44699 distinct states; repeat checks agree 223, disagree 0

| line | weight | members | beach draw | READY spread (VIs) | casts | Nut casts b1 / b2 |
|---|---|---|---|---|---|---|
| d562ecfffa1cb4c0 | 0.050 | 342 | 7808 | 44 | 1197 | 23 / 22 |
| 5a82163b260293ce | 0.039 | 314 | 7825 | 28 | 1197 | 33 / 11 |
| 3d4dd0e51b5674a7 | 0.039 | 262 | 7792 | 30 | 1197 | 18 / 18 |
| f2817743a36fa2b3 | 0.038 | 254 | 7792 | 44 | 1197 | 24 / 25 |
| e97ca64b4d5dab58 | 0.036 | 244 | 7792 | 44 | 1197 | 22 / 25 |
| 6e703d284c2ef0a1 | 0.027 | 220 | 7777 | 30 | 1197 | 24 / 8 |
| d90aba3d6af26d56 | 0.023 | 182 | 7792 | 38 | 1197 | 28 / 7 |
| a28184dca31b8f0a | 0.022 | 220 | 7772 | 44 | 1197 | 25 / 13 |
| db2a37faaf97d4dc | 0.022 | 178 | 7772 | 38 | 1197 | 33 / 16 |
| c169782be6c5a455 | 0.022 | 176 | 7825 | 22 | 1197 | 24 / 18 |
| e3b5c8171f3a629a | 0.022 | 176 | 7825 | 22 | 1197 | 22 / 18 |
| ee7592d27ddb9961 | 0.022 | 176 | 7883 | 22 | 1197 | 26 / 20 |
| f53f281489421567 | 0.022 | 176 | 7825 | 22 | 1197 | 11 / 26 |
| 4943cdd76f7c3575 | 0.021 | 126 | 7792 | 44 | 1197 | 26 / 23 |
| 586b7d6715fdc540 | 0.020 | 158 | 7825 | 22 | 1197 | 18 / 11 |
| e3145bf1689ae563 | 0.019 | 138 | 7883 | 22 | 1197 | 20 / 23 |
| 8d17215306bb26a8 | 0.019 | 156 | 7772 | 64 | 1197 | 24 / 33 |
| 5f5e6f398405593c | 0.017 | 132 | 7792 | 38 | 1197 | 29 / 9 |
| fa6b1bf3cc912e0a | 0.017 | 114 | 7772 | 44 | 1197 | 26 / 12 |
| 0fcb48f27bee1a1c | 0.017 | 88 | 7792 | 22 | 1197 | 25 / 20 |
| 25ec21d65075c3ab | 0.017 | 88 | 7792 | 22 | 1197 | 48 / 13 |
| b4b3a0822265e9cc | 0.017 | 88 | 7792 | 22 | 1197 | 26 / 18 |
| f73175fb23ff1df9 | 0.017 | 88 | 7792 | 22 | 1197 | 44 / 13 |
| e25aefb09bb77710 | 0.016 | 84 | 7792 | 22 | 1197 | 29 / 8 |
| 8373808bcf4086b4 | 0.015 | 96 | 7858 | 22 | 1197 | 19 / 14 |
| d7c6190fb465f965 | 0.015 | 76 | 7792 | 22 | 1197 | 26 / 18 |
| c0d5c9c07cdef3da | 0.014 | 90 | 7858 | 30 | 1197 | 11 / 26 |
| 29743430a9439163 | 0.014 | 88 | 7858 | 22 | 1197 | 29 / 4 |
| 2a043a43a9aa1832 | 0.014 | 88 | 7858 | 22 | 1197 | 24 / 11 |
| 6312374898374ff1 | 0.014 | 88 | 7858 | 22 | 1197 | 26 / 16 |
| bdabc506c101e8da | 0.014 | 88 | 7858 | 22 | 1197 | 17 / 14 |
| 327ab88407bac48c | 0.014 | 88 | 7858 | 22 | 1197 | 35 / 25 |
| 3361df6af40dd619 | 0.014 | 88 | 7858 | 22 | 1197 | 35 / 16 |
| 6b7170cb40279559 | 0.014 | 88 | 7858 | 22 | 1197 | 27 / 18 |
| b5dbc514df0a3efd | 0.014 | 88 | 7858 | 22 | 1197 | 33 / 20 |
| cfccb76ab0ee925e | 0.014 | 88 | 7858 | 22 | 1197 | 32 / 17 |
| f1cb78cbe328482a | 0.014 | 88 | 7858 | 22 | 1197 | 28 / 17 |
| f66df6f4966541e4 | 0.014 | 88 | 7858 | 22 | 1197 | 28 / 18 |
| 9749e636f6cadcca | 0.013 | 84 | 7858 | 22 | 1197 | 17 / 17 |
| 884fe4530a60d934 | 0.012 | 76 | 7858 | 22 | 1197 | 31 / 15 |

## Lucky Timer, whole pool (aim = time after READY at the dock end; cast spread 1 s.d.)

| spread | release bite 1 | hold to bite 2 | either (smart, upper bound) | coverage at best |
|---|---|---|---|---|
| 0 ms | 7.1% at 21.13 s | 6.4% at 7.57 s | 10.1% at 27.63 s | 0.957 |
| 100 ms | 6.5% at 21.1 s | 5.0% at 7.57 s | 9.3% at 27.67 s | 0.957 |
| 150 ms | 6.1% at 21.07 s | 4.6% at 7.53 s | 9.0% at 27.7 s | 0.957 |
| 250 ms | 5.6% at 21.07 s | 4.4% at 7.43 s | 8.5% at 27.7 s | 0.957 |

- **Member recast check** (casts from members' own routes vs the shared line table): agree 752, disagree 13, no table entry 0

  - ['586b7d6715fdc540', '1c0a5f8290bd8f28@w6', 86, 124, 874, [1498, False, 1654, False], [2340, False, 3152, False]]
  - ['e3145bf1689ae563', '1f3463956dfb0a66@w26', 86, 126, 350, [1008, False, 1668, False], [1008, False, 1592, False]]
  - ['cfccb76ab0ee925e', '7451c46ea35241aa@w28', 86, 119, 68, [356, False, 984, False], [356, False, 1408, False]]
  - ['f1cb78cbe328482a', '13c72eb80394c076@w12', 84, 142, 548, [892, False, 1364, False], [892, False, 2514, False]]
  - ['5a82163b260293ce', '1c0a5f8290bd8f28@w2', 84, 133, 2374, [2792, False, 3298, False], [2500, False, 2796, False]]
  - ['5a82163b260293ce', '245806264aabe42c@w8', 86, 134, 1624, [1840, False, 2428, False], [1840, False, 2724, False]]
  - ['5a82163b260293ce', '245806264aabe42c@w8', 86, 134, 2304, [2492, False, 2788, False], [2788, False, 3294, False]]
  - ['3d4dd0e51b5674a7', '5e757df414180b12@w18', 84, 143, 2114, [3246, False, 3390, False], [3246, False, 3824, False]]
  - ['3d4dd0e51b5674a7', '5e757df414180b12@w18', 84, 143, 2136, [2748, False, 3254, False], [5932, False, 8678, False]]
  - ['3d4dd0e51b5674a7', '5e757df414180b12@w20', 86, 133, 2242, [3258, False, 3402, False], [3254, False, 4640, False]]
  - ['3d4dd0e51b5674a7', '1f3463956dfb0a66@w20', 84, 131, 2124, [3824, False, 5940, False], [3246, False, 3824, False]]
  - ['5f5e6f398405593c', '610de62faead8ee9@w24', 84, 128, 1290, [1448, False, 2396, False], [1448, False, 1790, False]]
  - ['4c8b3f52970d5f1e', '4979566ceff518bb@w8', 84, 138, 1232, [1836, False, 4026, False], [1836, False, 4114, False]]
