# Dog-watch report: rain-lineup2-nohorse-8e972d75

99 dog lines with traces (40 s after READY), 912 (line, READY offset) variants; route-weighted. Clock = the dock-end tap ±3 VI; logs from 1.0 s after READY; runner: changes >= 12 VI, reaction 10-25 VI, 15% missed. Odds: cast >= 2 s after the window, ±150 ms.

## What the dog does while you wait (after READY, route-weighted)

- dog's tile on the visibility grid (it animates only then): 99% of the time
- visible changes per minute: 61; changes lasting >= 12 VI: 88%
- facing on screen (share of the wait): SW 40%, NE 17%, SE 14%, W 9%, NW 9%, E 6%, N 5%; animations readable (dog faces S / N / NE / E / SE): 42%
- the dog moves (units, max over the trace): median 0.0
- decision (actionState change) -> next visible change: median 0 VI (p10 0, p90 30); animation set -> displayed: median 0 VI

## Telling the lines apart (simulated runners)

| logging | window | right line on top | posterior on it | >= 90% sure | lines left | logs | Nut (no logs -> logs) | known line |
|---|---|---|---|---|---|---|---|---|
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 3 s | 32% | 26% | 16% | 49.4 | 0.3 | 6.1% -> 14.1% | 40.8% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 5 s | 50% | 47% | 41% | 39.7 | 0.8 | 4.8% -> 19.8% | 39.6% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 10 s | 53% | 50% | 46% | 39.5 | 1.5 | 6.2% -> 21.4% | 38.0% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 15 s | 70% | 64% | 55% | 25.5 | 2.3 | 6.8% -> 25.3% | 36.0% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 20 s | 74% | 68% | 60% | 23.5 | 3.5 | 4.5% -> 21.5% | 29.9% |
| gear, arrows only (no arrow = same facing) | 3 s | 22% | 16% | 5% | 51.6 | 0.1 | 6.8% -> 11.6% | 40.9% |
| gear, arrows only (no arrow = same facing) | 5 s | 31% | 25% | 15% | 46.3 | 0.2 | 5.6% -> 13.6% | 40.0% |
| gear, arrows only (no arrow = same facing) | 10 s | 35% | 30% | 21% | 45.7 | 0.3 | 5.9% -> 15.1% | 36.7% |
| gear, arrows only (no arrow = same facing) | 15 s | 50% | 44% | 31% | 33.0 | 0.6 | 5.3% -> 18.7% | 35.2% |
| gear, arrows only (no arrow = same facing) | 20 s | 61% | 57% | 48% | 25.9 | 1.0 | 6.2% -> 19.0% | 30.7% |
| your logging (arrows always, letters for long animations facing S/N/E) | 3 s | 32% | 25% | 16% | 70.3 | 0.4 | 5.7% -> 13.4% | 39.5% |
| your logging (arrows always, letters for long animations facing S/N/E) | 5 s | 42% | 36% | 31% | 61.2 | 0.7 | 5.3% -> 16.5% | 39.9% |
| your logging (arrows always, letters for long animations facing S/N/E) | 10 s | 54% | 50% | 45% | 48.7 | 1.7 | 5.7% -> 21.7% | 37.9% |
| your logging (arrows always, letters for long animations facing S/N/E) | 15 s | 59% | 54% | 46% | 40.3 | 2.2 | 6.9% -> 22.5% | 36.6% |
| your logging (arrows always, letters for long animations facing S/N/E) | 20 s | 70% | 64% | 56% | 31.8 | 3.5 | 4.6% -> 19.8% | 30.5% |
| arrows only (facing track + durations) | 3 s | 13% | 10% | 5% | 89.5 | 0.1 | 6.6% -> 9.1% | 40.6% |
| arrows only (facing track + durations) | 5 s | 21% | 17% | 13% | 81.4 | 0.2 | 3.9% -> 9.4% | 39.3% |
| arrows only (facing track + durations) | 10 s | 28% | 24% | 16% | 73.5 | 0.3 | 5.4% -> 12.8% | 37.0% |
| arrows only (facing track + durations) | 15 s | 42% | 33% | 21% | 61.7 | 0.5 | 6.1% -> 14.7% | 35.5% |
| arrows only (facing track + durations) | 20 s | 60% | 52% | 40% | 43.1 | 0.9 | 4.7% -> 17.2% | 30.8% |
| every change, letter + arrow | 3 s | 66% | 63% | 44% | 15.1 | 1.4 | 5.6% -> 30.5% | 40.8% |
| every change, letter + arrow | 5 s | 92% | 89% | 77% | 2.6 | 3.1 | 7.0% -> 37.2% | 41.0% |
| every change, letter + arrow | 10 s | 95% | 94% | 87% | 1.3 | 6.6 | 6.7% -> 36.2% | 38.0% |
| every change, letter + arrow | 15 s | 97% | 95% | 88% | 1.8 | 10.3 | 6.5% -> 35.0% | 36.5% |
| every change, letter + arrow | 20 s | 95% | 95% | 90% | 1.6 | 14.4 | 4.7% -> 29.1% | 30.3% |
| every animation change, letter only | 3 s | 66% | 63% | 46% | 17.8 | 1.3 | 5.4% -> 28.3% | 40.4% |
| every animation change, letter only | 5 s | 91% | 88% | 76% | 2.7 | 3.0 | 5.5% -> 36.3% | 39.8% |
| every animation change, letter only | 10 s | 97% | 95% | 89% | 1.3 | 6.7 | 5.3% -> 34.9% | 36.4% |
| every animation change, letter only | 15 s | 95% | 94% | 86% | 2.1 | 10.1 | 6.4% -> 34.2% | 35.8% |
| every animation change, letter only | 20 s | 95% | 94% | 87% | 1.3 | 13.9 | 4.8% -> 30.8% | 32.0% |
| Space at every change | 3 s | 12% | 8% | 0% | 52.0 | 1.4 | 6.9% -> 8.2% | 40.9% |
| Space at every change | 5 s | 43% | 30% | 7% | 19.5 | 3.1 | 6.6% -> 20.3% | 40.9% |
| Space at every change | 10 s | 85% | 77% | 56% | 3.2 | 6.6 | 5.4% -> 31.9% | 36.4% |
| Space at every change | 15 s | 94% | 92% | 82% | 1.7 | 10.7 | 5.5% -> 33.9% | 35.7% |
| Space at every change | 20 s | 96% | 93% | 85% | 1.4 | 14.4 | 4.8% -> 29.4% | 30.7% |

Readability: *your logging* follows Thomas's TV check (facing always readable; animations only while the dog
faces S, N, NE, E or SE, and only animations lasting >= 1 s are logged). The other rows are for comparison.

## Duds before the cast (reset early)

Dud = the best cast for what your logs leave is under the threshold; you reset instead of casting. Odds per attempt; 'kept' = attempts you cast.

| logging | window | threshold | attempts called dud | Nut on kept attempts | Nut the resets threw away | all-cast Nut |
|---|---|---|---|---|---|---|
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 3 s | 5% | 0% | 14.1% | 0.00 pts | 14.1% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 3 s | 8% | 61% | 30.0% | 2.50 pts | 14.1% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 5 s | 5% | 0% | 19.8% | 0.00 pts | 19.8% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 5 s | 8% | 50% | 34.5% | 2.57 pts | 19.8% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 10 s | 5% | 0% | 21.4% | 0.00 pts | 21.4% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 10 s | 8% | 50% | 38.0% | 2.34 pts | 21.4% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 15 s | 5% | 1% | 25.6% | 0.00 pts | 25.3% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 15 s | 8% | 32% | 33.8% | 2.47 pts | 25.3% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 20 s | 5% | 3% | 22.2% | 0.00 pts | 21.5% |
| gear: arrows at every facing change (no arrow = same facing) + numpad 0-9 for long animations facing S/N/E | 20 s | 8% | 32% | 28.3% | 2.19 pts | 21.5% |
| gear, arrows only (no arrow = same facing) | 3 s | 5% | 0% | 11.6% | 0.00 pts | 11.6% |
| gear, arrows only (no arrow = same facing) | 3 s | 8% | 62% | 20.6% | 3.85 pts | 11.6% |
| gear, arrows only (no arrow = same facing) | 5 s | 5% | 0% | 13.7% | 0.00 pts | 13.6% |
| gear, arrows only (no arrow = same facing) | 5 s | 8% | 56% | 24.3% | 2.99 pts | 13.6% |
| gear, arrows only (no arrow = same facing) | 10 s | 5% | 0% | 15.1% | 0.00 pts | 15.1% |
| gear, arrows only (no arrow = same facing) | 10 s | 8% | 56% | 27.0% | 3.21 pts | 15.1% |
| gear, arrows only (no arrow = same facing) | 15 s | 5% | 2% | 19.1% | 0.00 pts | 18.7% |
| gear, arrows only (no arrow = same facing) | 15 s | 8% | 40% | 28.0% | 2.08 pts | 18.7% |
| gear, arrows only (no arrow = same facing) | 20 s | 5% | 2% | 19.3% | 0.00 pts | 19.0% |
| gear, arrows only (no arrow = same facing) | 20 s | 8% | 32% | 25.0% | 2.01 pts | 19.0% |

### Early dud signs, your logging, 10 s window, dud = best cast under 5%

2% of attempts are duds at this threshold (if the line were known). A sign = what you log in a 1-s slot after READY; seen = share of attempts showing it; dud share = how many of those are duds.

| you log | seconds after READY | seen | dud share |
|---|---|---|---|
| numpad 0 idle | 4-5 | 1.3% | 0% |
| faces N | 8-9 | 1.0% | 0% |
| numpad 0 idle | 5-6 | 1.7% | 0% |
| numpad 2 stand | 7-8 | 7.0% | 0% |
| numpad 3 rollover | 9-10 | 3.8% | 0% |
| numpad 2 stand | 4-5 | 8.8% | 0% |
| numpad 9 shoulder | 4-5 | 6.8% | 0% |
| numpad 7 sniff | 1-2 | 5.6% | 0% |
| numpad 3 rollover | 6-7 | 5.6% | 0% |
| numpad 0 idle | 3-4 | 5.5% | 0% |
| numpad 2 stand | 5-6 | 4.9% | 0% |
| numpad 3 rollover | 7-8 | 4.6% | 0% |
| numpad 8 bark | 1-2 | 4.5% | 0% |
| numpad 2 stand | 6-7 | 4.3% | 0% |
| numpad 2 stand | 9-10 | 4.3% | 0% |
| numpad 0 idle | 9-10 | 4.2% | 0% |
| numpad 2 stand | 3-4 | 4.2% | 0% |
| numpad 0 idle | 1-2 | 3.9% | 0% |
| numpad 7 sniff | 3-4 | 3.8% | 0% |
| numpad 8 bark | 3-4 | 3.8% | 0% |

### Early dud signs, your logging, 10 s window, dud = best cast under 8%

2% of attempts are duds at this threshold (if the line were known). A sign = what you log in a 1-s slot after READY; seen = share of attempts showing it; dud share = how many of those are duds.

| you log | seconds after READY | seen | dud share |
|---|---|---|---|
| numpad 0 idle | 4-5 | 1.3% | 0% |
| faces N | 8-9 | 1.0% | 0% |
| numpad 0 idle | 5-6 | 1.7% | 0% |
| numpad 2 stand | 7-8 | 7.0% | 0% |
| numpad 3 rollover | 9-10 | 3.8% | 0% |
| numpad 2 stand | 4-5 | 8.8% | 0% |
| numpad 9 shoulder | 4-5 | 6.8% | 0% |
| numpad 7 sniff | 1-2 | 5.6% | 0% |
| numpad 3 rollover | 6-7 | 5.6% | 0% |
| numpad 0 idle | 3-4 | 5.5% | 0% |
| numpad 2 stand | 5-6 | 4.9% | 0% |
| numpad 3 rollover | 7-8 | 4.6% | 0% |
| numpad 8 bark | 1-2 | 4.5% | 0% |
| numpad 2 stand | 6-7 | 4.3% | 0% |
| numpad 2 stand | 9-10 | 4.3% | 0% |
| numpad 0 idle | 9-10 | 4.2% | 0% |
| numpad 2 stand | 3-4 | 4.2% | 0% |
| numpad 0 idle | 1-2 | 3.9% | 0% |
| numpad 7 sniff | 3-4 | 3.8% | 0% |
| numpad 8 bark | 3-4 | 3.8% | 0% |
