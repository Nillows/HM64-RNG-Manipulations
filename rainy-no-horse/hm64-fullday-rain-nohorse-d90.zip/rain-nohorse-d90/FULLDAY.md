# HM64 full-day lab — the cast table and the dog to the end of the game day

## 1. The day without a cast (every dog line, stay-awake push every 33 s)

- 99 lines ran of 99; dog at READY: [-198.51, 223.49]
- Clock at READY: 06:48 – 06:52. Followed to 5398 VIs = 90 s after READY (the limit).
- Same paths as the dog-watch run? cast hashes of the first 33 s: **98505 equal, 0 different**.
- Ended by something else than the limit / the end of the day: 0
- The dog's visible changes over that time: 90 per line.
- **The dog leaves its spot** (moved 4 units or more) on 56 of 99 lines; earliest 3 s after READY, median 37 s.
- Its tile leaves the visibility grid (not on screen, not animating) on 8 lines.

## 2. Cast blocks (every cast held to the limit, or the end of the day)

| block | cast frames (s after READY) | lines | casts planned | done | job errors | hash check ok / failed / none | ended: as planned / beach check / other | bites per cast | casts with a Nut on some bite |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 0.1 – 40.1 · heavy | 50 | 45088 | 45088 | 0 | 44038 / 0 / 1050 | 45088 / 0 / 0 | 6.7 | 2188 (4.9%) |
| 1 | 0.1 – 40.1 · other | 49 | 24281 | 24281 | 0 | 23252 / 0 / 1029 | 24281 / 0 / 0 | 6.8 | 1063 (4.4%) |

Blocks not started: 0 (0 casts). Data so far: 75.8 MB.

## 3. The beach check

- 69369 casts: **69369 ran to the limit / the end of the day on the beach at the dock end**, 0 were stopped by the beach check, 0 ended another way.
- Cast hash = the dog-watch run's state at that frame: 67290 equal, **0 different**, 2079 not compared (cast frames inside a stay-awake push).

## 4. Bites and Nuts by game hour (on the held casts)

- 466691 bites; released 4 polls after the bite: m 163028, l 155937, s 144402, N 3324 (N Nut, s / m / l fish size, d the day ended before the catch, x miss, h held through, o other; a / b = the two release probes differ).
- The two release probes of bites 1-2 gave different catches on 0 bites.
- Nut by bite number: bite 1: 1453, bite 2: 864, bite 3: 381, bite 4: 322, bite 5+: 304.

| game hour | bites | Nut bites | Nut share |
|---|---|---|---|
| 07:00 | 12347 | 242 | 1.96% |
| 08:00 | 39985 | 779 | 1.95% |
| 09:00 | 57321 | 1342 | 2.34% |
| 10:00 | 53462 | 28 | 0.05% |
| 11:00 | 63715 | 933 | 1.46% |
| 12:00 | 128158 | 0 | 0.00% |
| 13:00 | 107326 | 0 | 0.00% |
| 14:00 | 4056 | 0 | 0.00% |
| 15:00 | 76 | 0 | 0.00% |
| 16:00 | 222 | 0 | 0.00% |
| 18:00 | 23 | 0 | 0.00% |

These are bites of casts HELD since the cast frame, not fresh casts at that hour: a later hour is
reached only by holding through every earlier bite.

## 5. Do the held casts run into each other?

- 466691 bite states, 31306 distinct (93.3% shared): a shared state has the same future, so its later bites need not be simulated twice.

## 6. The dog after the cast

- Visible changes recorded from the cast to the end of its run: 70 per cast; on the released paths (the 4 s after each bite): 5.0 per bite.
- The dog leaves its spot at some point of the run in 43844 of 69369 casts (63%).

## 7. Against the dog-watch run's cast table (same state hash)

- 44121 casts are in both: bite times and Nut flags **equal in 44121, different in 0**.

