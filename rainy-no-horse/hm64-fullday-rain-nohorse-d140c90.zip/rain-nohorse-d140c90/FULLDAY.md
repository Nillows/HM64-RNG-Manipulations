# HM64 full-day lab — the cast table and the dog to the end of the game day

## 1. The day without a cast (every dog line, stay-awake push every 33 s)

- 99 lines ran of 99; dog at READY: [-198.51, 223.49]
- Clock at READY: 06:48 – 06:52. Followed to 8398 VIs = 140 s after READY (the limit).
- Same paths as the dog-watch run? cast hashes of the first 33 s: **98505 equal, 0 different**.
- Ended by something else than the limit / the end of the day: 0
- The dog's visible changes over that time: 142 per line.
- **The dog leaves its spot** (moved 4 units or more) on 87 of 99 lines; earliest 3 s after READY, median 53 s.
- Its tile leaves the visibility grid (not on screen, not animating) on 22 lines.

## 2. Cast blocks (every cast held to the limit, or the end of the day)

| block | cast frames (s after READY) | lines | casts planned | done | job errors | hash check ok / failed / none | ended: as planned / beach check / other | bites per cast | casts with a Nut on some bite |
|---|---|---|---|---|---|---|---|---|---|
| 2 | 40.1 – 80.2 · heavy | 50 | 35997 | 35997 | 0 | 34947 / 0 / 1050 | 35997 / 0 / 0 | 6.1 | 1395 (3.9%) |
| 3 | 40.1 – 80.2 · other | 49 | 18324 | 18324 | 0 | 17295 / 0 / 1029 | 18324 / 0 / 0 | 6.2 | 680 (3.7%) |
| 4 | 80.2 – 90.3 · heavy | 40 | 8367 | 8367 | 0 | 8367 / 0 / 0 | 8367 / 0 / 0 | 3.7 | 313 (3.7%) |
| 5 | 80.2 – 90.3 · other | 24 | 4250 | 4250 | 0 | 4250 / 0 / 0 | 4250 / 0 / 0 | 3.7 | 204 (4.8%) |

Blocks not started: 2 (69369 casts). Data so far: 70.5 MB.

## 3. The beach check

- 66938 casts: **66938 ran to the limit / the end of the day on the beach at the dock end**, 0 were stopped by the beach check, 0 ended another way.
- Cast hash = the dog-watch run's state at that frame: 64859 equal, **0 different**, 2079 not compared (cast frames inside a stay-awake push).

## 4. Bites and Nuts by game hour (on the held casts)

- 379102 bites; released 4 polls after the bite: m 133518, s 127112, l 115872, N 2600 (N Nut, s / m / l fish size, d the day ended before the catch, x miss, h held through, o other; a / b = the two release probes differ).
- The two release probes of bites 1-2 gave different catches on 0 bites.
- Nut by bite number: bite 1: 771, bite 2: 447, bite 3: 361, bite 4: 338, bite 5+: 683.

| game hour | bites | Nut bites | Nut share |
|---|---|---|---|
| 10:00 | 4287 | 75 | 1.75% |
| 11:00 | 17129 | 838 | 4.89% |
| 12:00 | 49360 | 0 | 0.00% |
| 13:00 | 68828 | 4 | 0.01% |
| 14:00 | 67203 | 286 | 0.43% |
| 15:00 | 51187 | 1035 | 2.02% |
| 16:00 | 54471 | 335 | 0.62% |
| 17:00 | 45161 | 12 | 0.03% |
| 18:00 | 19095 | 0 | 0.00% |
| 19:00 | 2252 | 15 | 0.67% |
| 20:00 | 65 | 0 | 0.00% |
| 21:00 | 19 | 0 | 0.00% |
| 22:00 | 44 | 0 | 0.00% |
| 23:00 | 1 | 0 | 0.00% |

These are bites of casts HELD since the cast frame, not fresh casts at that hour: a later hour is
reached only by holding through every earlier bite.

## 5. Do the held casts run into each other?

- 379102 bite states, 47804 distinct (87.4% shared): a shared state has the same future, so its later bites need not be simulated twice.

## 6. The dog after the cast

- Visible changes recorded from the cast to the end of its run: 69 per cast; on the released paths (the 4 s after each bite): 4.9 per bite.
- The dog leaves its spot at some point of the run in 56034 of 66938 casts (84%).

## 7. Against the dog-watch run's cast table (same state hash)

- 0 casts are in both: bite times and Nut flags **equal in 0, different in 0**.

